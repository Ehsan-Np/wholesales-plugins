# ZarinCode Wholesale — release-readiness record

**Current source:** plugin header/version `0.9.19`  
**Assessment:** not yet production-release accepted. Code and automated tests are not evidence of PSP certification, legal tax compliance, or compatibility with every store theme/checkout configuration.

## Automated evidence in this workspace

- Node contract suite: `node --test tests/*.test.js` — **100/100 passed** after the 0.9.19 Store API price privacy change (including the CSV importer and taxonomy-discount contracts).
- WordPress Playground integration (PHP 8.2): `tests/playground.woocommerce.blueprint.json` exited **0** after the 0.9.18 changes. The suite executes CSV parsing, unauthorized-user rejection without mutation, valid price/tier persistence, invalid overlapping-tier rejection, custom brand-taxonomy discount resolution and admin parser acceptance/rejection, plus Store API hidden-price scrubbing/no-store and wholesale-customer visibility checks, alongside the broader WooCommerce matrix. PHP-WASM is not a real MySQL/production runtime.
- Release archive smoke for 0.9.19: the allowlisted ZIP was extracted and mounted into Playground; plugin activation, version check, and core schema smoke exited **0** using `tests/playground.release-smoke.blueprint.json`.
- PHP CLI/PHPCS are unavailable in this environment. The Playground CLI previously warned that Node 20 was below the preferred engine for some packages; this run still exited 0. Rerun with supported Node/npm before production release.
- WordPress Playground integration (PHP 8.2):

```sh
npx --yes @wp-playground/cli run-blueprint \
  --blueprint tests/playground.woocommerce.blueprint.json \
  --blueprint-may-read-adjacent-files \
  --mount-dir "$PWD" /wordpress/wp-content/plugins/zcws-wholesale \
  --php 8.2 --verbosity quiet
```

- The 0.9.14 PHP-WASM integration previously covered wholesale prices, credit/refunds/installments, historical mixed-settlement and cheque flows, privacy export/erasure, invoices, REST, reports and workbook generation. The 0.9.15 rerun retains that matrix and adds the new credential and gateway-registration checks.
- PHP-WASM uses `token_get_all(..., TOKEN_PARSE)` over plugin-owned PHP files (excluding the nested WooCommerce development copy); this is a syntax gate, not WordPress Coding Standards.
- The 0.9.19 allowlisted candidate ZIP `artifacts/zcws-wholesale-0.9.19-candidate.zip` contains 110 files (286,537 bytes); `unzip -t` passed. Archive audit confirmed the plugin entry point, CSV importer, taxonomy pricing and Store API price filtering are present; tests, nested WooCommerce and `.env` are excluded. The archive was mounted and smoke-tested on WordPress Playground PHP 8.2; activation/version/schema checks exited **0**. This remains a test candidate, not production release acceptance.
- JavaScript E2E runner syntax checks pass. The real staging matrix has **not** run: no configured Storefront/Astra/Blocksy/Flatsome/Woodmart targets or PSP credentials.
- This environment did not provide PHP CLI, Composer or PHPCS. The PHP-only standalone tests and WordPress Coding Standards have therefore **not** been run here. Playground parses/executes covered plugin paths; it is not a substitute for linting every PHP file or a real MySQL runtime.

- Tax-authority credential text is stored as AES-256-GCM ciphertext under a separate option and can be retrieved by a future adapter. No tax API protocol, network sender, sandbox acceptance or legal validation is implemented. The official [electronic-billing service page](https://www.intamedia.ir/electronic-billing) was found, but the available result did not establish a current technical API/schema; the direct page fetch failed, so no endpoint/format was inferred. The site owner must protect WP salts and back up/rotate them carefully.
- New wholesale orders use only the installed WooCommerce payment methods, except the existing internal account-credit feature; the separate mixed-settlement checkout gateway/Blocks entry point is no longer registered. Conditional payment callbacks remain for already-created mixed-settlement orders. The mixed settlement builder requirement is therefore deliberately unavailable for new orders pending a design that does not introduce a separate checkout method.

## Release gates (must be completed by store owner/release engineer)

1. **Build and source audit:** build the plugin ZIP from an explicit allowlist; confirm it excludes the nested `woocommerce/` development copy, tests, fixtures, credentials, caches, and unrelated files. Inspect the ZIP contents and install it on a clean site.
2. **Static QA:** run PHP 8.2/8.3 syntax checks, Composer validation, WordPress Coding Standards/PHPCS, and a dependency/security scan. Record the exact tool versions and output.
3. **Compatibility:** test the target WordPress/WooCommerce minimum and current production versions; HPOS enabled and disabled; Classic checkout and Checkout Block; PHP 8.2 and 8.3; RTL and LTR; supported multilingual plugins; multisite if claimed.
4. **Themes and browser:** execute `tests/e2e/theme-checkout-matrix.mjs` on disposable staging targets. Review keyboard/screen-reader behavior, responsive layouts, print output, admin screens and WC notice behavior. Save redacted evidence.
5. **Financial correctness:** run the CR-01–CR-12 matrix in `tests/manual-test-plan.md` on MySQL/MariaDB with controlled concurrent requests. Test online settlement success/decline/cancel/timeout/replay, partial/full refunds, chargebacks, cancellation, zero-decimal and fractional currencies. Verify every ledger/account/order/child-order balance against an independently calculated expected result.
6. **External services:** verify the actual WooCommerce PSP lifecycle and 3-D Secure; real email transport; SMS provider/carrier; webhook HMAC delivery/retries; and any official-tax adapter in sandbox. Playground mocks do not constitute provider acceptance.
7. **Legal/accounting:** obtain written approval for credit terms, cheque/manual payment lifecycle, VAT exemption, document retention/deletion, privacy policy, invoice numbering and any tax-authority integration. Internal printable HTML is not an official tax invoice.
8. **Data lifecycle:** test backup/restore, migration from each supported prior schema, uninstall with cleanup both disabled/enabled, privacy export and erasure, retention policy, and recovery of stale queue/worker rows.
9. **Package/upgrade:** install/upgrade/deactivate/reactivate/uninstall the built ZIP against disposable copies of each supported release. Confirm no unrelated WooCommerce source is shipped and no user/product/order data is unexpectedly removed.

## Backlog state

The priority-S entries AC-02, AC-03, AD-04–AD-08, AP-01 and CR-01–CR-12 have implemented code paths and varying levels of contract/Playground evidence. They remain **Partially implemented** until the relevant staging, legal, external-provider and operational gates above are completed. In particular:

- AC-02's PDF path is browser print/save, not a bundled server-side PDF renderer.
- AD-08 / I-02's invoice output is printable HTML; the external tax adapter is not proof of official registration.
- AP-01's API requires an authentication/client compatibility review against the target store's policies.
- Credit/cheque flows are ledgered in WooCommerce; no bank cheque clearing/reconciliation integration is included.
- Credit refunds are capped cumulatively at the original credit charge; a valid refund may exceed the remaining receivable when it returns a previously paid share. Transaction start/commit, schedule/cheque lookup and linked installment-order failures fail closed. This is source + Playground evidence, not cross-process MySQL stress or PSP reconciliation.
- Credit ledger, installment, mixed-settlement, cheque and private REST rate-limit mutations now fail closed when transaction boundaries or critical reads fail. Foreign-currency credit receipts/refunds/installment callbacks are rejected. Source contracts + Playground cover selected paths; this is not database fault-injection or concurrent MySQL stress certification.
- Tax submissions now check queue/claim commits and persist provider outcomes transactionally before firing registration actions; stale worker writes are conditional. The authority protocol/SDK, provider sandbox and legal acceptance remain outstanding.
- AP-03 exports/upserts WooCommerce business data; it is not a preconfigured, bidirectional connector for a named ERP.
- T-01's Playwright matrix is a runner only until actual targets are configured and run.

Do not change these statuses to Done merely because a source-level contract or a mocked Playground scenario passes.

## Build notes

The top-level `woocommerce/` directory is a full WooCommerce development/dependency copy, not a ZCWS runtime dependency. A release artifact must exclude that directory and include only ZCWS plugin code, templates, assets, readme/license and required metadata. Never distribute store data, secrets, local staging targets, generated test artifacts or the Playground fixture as plugin runtime content.
