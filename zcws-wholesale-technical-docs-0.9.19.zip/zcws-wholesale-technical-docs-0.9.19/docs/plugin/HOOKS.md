# Extension hooks and integration contracts

This reference lists the ZCWS extension points currently present in source. Hook signatures can change between plugin releases; pin and test against the installed ZCWS version. Provider integrations must use HTTPS, protect credentials outside source control, validate provider responses, and never report delivery/registration as successful without a positive provider acknowledgment.

## SMS adapter

Filter: `zcws_send_sms`

```php
$accepted = apply_filters( 'zcws_send_sms', false, $normalized_phone, $plain_text, $context );
```

- Return **boolean `true` only** after the provider accepts the message. Any other value is failure/retry.
- `$normalized_phone` is the adapter-normalized destination; `$plain_text` is plain text and at most 1,600 characters.
- `$context` includes a purpose (`otp` or `queued_notification`) and non-secret correlation details. Do not log OTP content, secrets, tokens or full message bodies.
- OTP delivery is fail-closed when no adapter accepts. Queued SMS uses bounded retries; delivery is still subject to the provider/carrier's semantics and may not be exactly-once after a network timeout.

Example skeleton (replace with a real provider client and secret manager):

```php
add_filter( 'zcws_send_sms', function ( $accepted, $phone, $message, $context ) {
    if ( true === $accepted ) {
        return true;
    }
    // Call the provider using HTTPS and credentials from a secure store.
    // Return true only for a documented accepted response; otherwise return false.
    return false;
}, 10, 4 );
```

## Payment method behavior

Wholesale orders use payment methods already installed and configured in WooCommerce; group-level restrictions only remove gateway IDs that the store owner explicitly disables. The plugin does not register a separate mixed-settlement checkout gateway for new orders. Existing mixed-settlement child-order payment callbacks remain available for previously created orders, and the account-credit ledger gateway is an internal credit feature rather than a PSP.

## Official invoice adapter

Filter: `zcws_invoice_tax_authority_adapter`

Return an object implementing `ZCWS\Wholesale\Invoice\TaxAuthorityAdapterInterface`, or return the supplied value unchanged when no adapter is configured. The service performs a local legal-data preflight and passes the immutable invoice snapshot plus a stable request ID to the adapter. The adapter must:

- Implement the interface in `includes/Invoice/TaxAuthorityAdapterInterface.php` exactly.
- Use the stable request ID for provider-side idempotency. A timeout must be treated as ambiguous/retryable, never as successful registration.
- Return only the documented accepted/rejected/retry status shape. For accepted submissions, return a provider reference matching the service's bounded identifier policy.
- Avoid returning credentials, access tokens, full identity data or unbounded provider payloads. The service sanitizes responses but the adapter remains responsible for minimization.
- Be tested against the authority sandbox and current legal schema by the store's tax/accounting adviser. Registering this adapter does not make an internal invoice legally official by itself.

### Tax credential storage contract

The WooCommerce settings page accepts an opaque credential payload supplied by the store owner from the official, current tax-authority credential package. It encrypts the exact submitted text with AES-256-GCM, a random nonce and a key derived from the site's WordPress `secure_auth` salt; the plaintext is never rendered back or placed in `zcws_settings`. Leaving the field blank preserves the existing bundle; an explicit checkbox deletes it. If encryption support, validation or option persistence fails, the previous value is retained and the UI reports an error. Changing WordPress salts or the site URL can make existing ciphertext undecryptable; back up WordPress salts securely before rotating them.

An adapter may retrieve the decrypted opaque string with `ZCWS\Wholesale\Invoice\TaxAuthorityCredentials::get()`. The bundle's schema is deliberately opaque until an authoritative current protocol document is confirmed. Credential storage is **not** a submission client: no network request uses this bundle in the current release, and no official tax registration is implied. The site owner remains responsible for permissions, backups and secret rotation.

## Application lifecycle actions

- `zcws_application_submitted` — fired after a wholesale application is persisted.
- `zcws_application_reviewed` — fired after a review transition is persisted.

WooCommerce native webhooks can subscribe to the corresponding `zcws.application_submitted` and `zcws.application_reviewed` topics. Payloads are intentionally minimized; delivery/signature/retry behavior is provided by WooCommerce. Test actual endpoint delivery and secret rotation before production use.

## Other actions

- `zcws_invoice_tax_registered` — fired only after the tax adapter returns an accepted result with a valid authority reference.
- `zcws_quote_converted` — emitted after a quote is converted to an order.
- `zcws_product_deleted` — emits a product tombstone for downstream synchronization after product deletion.

## WooCommerce / multilingual integration points

The plugin also uses WooCommerce public filters/actions and optional WPML/Polylang APIs. These are integration dependencies, not ZCWS-specific guarantees. Verify hook ordering and translated object IDs on the exact WooCommerce and multilingual-plugin versions used by the store.
