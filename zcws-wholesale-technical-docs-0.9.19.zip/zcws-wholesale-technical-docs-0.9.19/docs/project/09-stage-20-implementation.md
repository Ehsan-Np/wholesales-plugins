# مرحلهٔ اجرایی ۲۰ شناسه از backlog مصوب

مبنای انتخاب: `01-requirements.md`، `02-woocommerce-capability-map.md`، `03-architecture-roadmap.md` و `backlog.csv`. سند ۰۴ و شناسه‌های X-01 تا X-20 خارج از دامنه‌اند. این فایل tracker اجرای مرحله است، نه اعلام Done.

## ۲۰ شناسهٔ انتخاب‌شده

1. C-02 — schema/dbDelta و نسخهٔ اسکیما
2. C-04 — تنظیمات native ووکامرس
3. C-06 — cache درون‌درخواست و پایدار
4. G-01 — گروه‌های نقش‌محور پویا
5. G-02 — انتساب/لغو گروه و همگام‌سازی نقش/تأیید
6. O-01 — فرم و فیلدهای اطلاعات کسب‌وکار
7. O-02 — ذخیره و دریافت امن مدارک
8. O-03 — رویدادهای گردش کار درخواست
9. O-04 — ثبت ایمیل‌های تراکنشی ووکامرس
10. O-05 — کنترل خرید متقاضی تأییدنشده
11. P-01 — قیمت پایه/ویژهٔ عمدهٔ محصول ساده و variation
12. P-02 — فیلدها و ذخیرهٔ تب محصول/variation
13. P-03 — tier محصول و variation
14. P-05 — حل قیمت پیکربندی‌شده و تست
15. P-06 — نمایش جدول tier برای مشتری مجاز
16. P-07 — کنترل نمایش قیمت برای کاربر غیرمجاز
17. P-12 — اولویت قیمت variation و ارث‌بری اختیاری والد
18. P-13 — tier مستقل variation
19. P-14 — ویرایش گروهی variation
20. R-01 — MOQ، حداکثر، گام و بسته‌بندی در اعتبارسنجی سبد

## تغییر کد در این مرحله

- `includes/Support/Cache.php`: علاوه بر object cache، transient پایدار به‌عنوان fallback برای نصب‌هایی که persistent object-cache drop-in ندارند نوشته/خوانده/پاک می‌شود؛ generation قبلی همچنان مبنای invalidation است.
- `includes/Pricing/PriceResolver.php`: پاسخ‌های REST محصول/variation هم اکنون در شرایطی که قیمت باید پنهان باشد فیلدهای price, regular_price, sale_price, price_html, on_sale و price_range را پاک/خنثی می‌کنند.
- `tests/playground.integration.php` و `tests/playground.woocommerce.blueprint.json`: تست‌های runtime توسعه یافتند تا CRUD واقعی محصول و variation، nonce و ذخیرهٔ فیلدهای محصول، bulk price/sale/date/quantity/tier، محدودهٔ والد، inheritance، tier اختصاصی، cache/transient invalidation، migration، group assignment، application fields/events، ایمیل‌های WooCommerce، کنترل pending applicant، رد دانلود ناشناس مدرک، قواعد classic/Store API و CRUD سفارش از مسیر WooCommerce را اجرا کنند.
- `tests/admin-contracts.test.js`: یک آزمون قرارداد برای hookهای REST قیمت افزوده شد.
- `tests/manual-test-plan.md`: شواهد و محدودیت‌های runtime به‌روز شده‌اند.

## کدنویسی تکمیلی پس از انتخاب ۲۰ شناسه (خارج از فهرست انتخاب، هنوز تأیید/Done نیست)

- `includes/Checkout/CheckoutFields.php`: ثبت رسمی فیلدهای Blocks با sanitize/validate، حذف attribute نامعتبر maxlength و محدودکردن registration به خریدار عمدهٔ تأییدشده؛ فیلدهای classic و ذخیرهٔ classic از WC_Order CRUD نیز پیاده‌سازی شده‌اند. این کار مرتبط با C-13 است اما C-13 جزو ۲۰ انتخاب این tracker نیست.
- `includes/Admin/GroupsPage.php` و `includes/Groups/GroupRepository.php`: تنظیم/اعتبارسنجی/نگهداری آستانهٔ حداقل مبلغ و تعداد برای هر گروه.
- `includes/Cart/CartRules.php`: خطای مشترک بررسی سبد classic و Store API برای حداقل تعداد کل و مبلغ کالای پس از کوپن و پیش از مالیات/حمل. این کار R-02 را پوشش می‌دهد، اما هنوز رندر/Checkout Block واقعی و سناریوهای سبدهای غیرخالی روی مرورگر تأیید نشده‌اند.
- `tests/playground.integration.php` و `tests/admin-contracts.test.js`: assertion ثبت فیلدهای Blocks برای کاربر مجاز و عدم ثبت برای ادمین غیرعمده، ذخیرهٔ classic، حداقل‌های گروه، اعتبارسنجی هر دو مسیر cart و محدودسازی gatewayهای پرداخت برای گروه افزوده شد.
- `includes/Admin/GroupsPage.php`, `includes/Groups/GroupRepository.php`, `includes/Cart/CartRules.php`: C-15 نیز جزئاً کدنویسی شد؛ مدیر gatewayهای محدود گروه را انتخاب می‌کند، ذخیره فقط شناسه‌های ثبت‌شده توسط WooCommerce را می‌پذیرد و filter فقط برای عمده‌فروش تأییدشده gatewayهای علامت‌خورده را حذف می‌کند.
- اجرای تازهٔ Playground exit code 0 و Node tests برابر ۴۰/۴۰ (۲۶ phase-1 feature contracts)؛ notice مربوط به maxlength برطرف شد. Playground همچنان پیام عمومی unexpected output در فعال‌سازی WooCommerce دارد. اجرای lint PHP سراسری پس از آخرین تغییرات هنوز لازم است؛ اعلام HPOS/Blocks اکنون در کد اضافه شده اما تا اجرای ماتریس واقعی HPOS و رندر/ارسال Checkout Blocks provisional است.

## آخرین شواهد اجرا

- Playground: WordPress 7.1.4 / WooCommerce 11.3.0 / PHP 8.2؛ Blueprint و تست integration خروجی موفق داشتند.
- تست‌های Node آخرین اجرا: ۴۰/۴۰ موفق؛ ۲۶ قرارداد فاز ۱ در فایل مستقل افزوده شده است.
- تست‌های PHP-WASM: `bulk-variation-editor.test.php`، `order-snapshot.test.php` و `price-resolver.test.php` موفق؛ PriceResolver شامل ۲۳ سناریو است.
- PHP-WASM lint: ۵۱ فایل PHP بدون خطای syntax.

## باقی‌ماندهٔ صریح — هیچ‌یک از ۲۰ شناسه هنوز Done نیست

آزمون‌ها کامل بودن معیارهای پذیرش را اثبات نمی‌کنند. هنوز لازم است: رندر UI و رفتار واقعی تمام مسیرهای ثبت‌نام؛ اجرای upload واقعی با فایل HTTP و اعتبارسنجی MIME/حجم؛ تصمیم‌های approve/reject/needs_info از admin handler و آزمون هم‌زمانی؛ ارسال واقعی ایمیل و override قالب؛ تست REST/RSS/Blocks/قالب برای عدم نشت قیمت؛ matrix واقعی HPOS؛ و پوشش کامل checkout. آزمون DB-order فعلی با WooCommerce CRUD اجرا شده اما فعال‌بودن HPOS در آن site صریحاً اثبات نشده است. همچنین C-03 (اعلام سازگاری) عمداً از این انتخاب حذف است؛ تا قبل از آزمون واقعی نباید compatibility را اعلام کرد.

- پس از audit سطح سورس، `includes/Compatibility.php` و hook `before_woocommerce_init` برای declarationهای رسمی `custom_order_tables` و `cart_checkout_blocks` افزوده شد. این declaration در کد است و «تأیید سازگاری» محسوب نمی‌شود تا HPOS واقعی و checkout block روی staging ماتریس شوند.

- در `includes/Admin/WholesaleDashboard.php` صفحهٔ فرود «فروش عمده» با capability check، لینک‌های موجود و شمارش‌های گروه/درخواست به C-05 افزوده شد؛ Node contract test آن اضافه شد.

- `tests/phase1-feature-contracts.test.js` اکنون ۲۶ قرارداد ساختاری برای شناسه‌های فاز ۱ دارد؛ کل تست‌های Node ۴۰/۴۰ هستند. آخرین Playground run با exit code 0، ثبت رسمی compatibility و persistence audit/redaction گروه را نیز assertion می‌کند.

- ارزیابی شواهد جدید: Playground برای P-01/P-03/P-12/P-13/R-01/R-06 زیرمعیارهای price CRUD/tier/inheritance/quantity را اجرا می‌کند؛ طبقه‌بندی‌شان از «پایه/تست‌نشده» به «جزئی» تغییر کرده، بدون اعلام Done.

## ادامهٔ پیاده‌سازی — قواعد فاز ۲ و My Account

- در یک نوبت توسعه، ۲۰ شناسهٔ یکتا با تغییر کد و شواهد مجزا پیش رفتند: C-06/C-10/C-11/C-12/C-14/C-17/P-04/P-05/P-08/P-09/P-10/P-11/P-15/R-07/O-06/MK-01/AC-01/AC-02/AD-02/AD-03. ۱۴ مورد جدید partial شدند و ۶ مورد قبلاً partial گسترش یافتند؛ Done=0.
- کد تازه در `Frontend/WholesaleAccount.php`, `Pricing/CustomerPricing.php`, `Pricing/CategoryTiers.php`, `Market/IranAdapter.php`, `Admin/WholesaleUserProfile.php`, `Admin/WholesaleOrderFields.php` و سرویس‌های Pricing/Product/Cart bootstrap شده است.
- Node suite: ۴۹/۴۹. Playground integration: exit code 0 (WP 7.1.4/WC 11.3.0/PHP 8.2). activation خود WooCommerce همچنان warning عمومی unexpected output دارد.
- این اجرا HPOS را صریحاً فعال نکرد، HTTP file upload و مرورگر/قالب را اجرا نکرد، پس Checkout/HPOS/قالب و پذیرش end-to-end همچنان باز است. شمارش کد: ۵۱/۹۷ جزئی، ۴۶ بدون شواهد، ۰ Done.

## بستهٔ بعدی ۲۰ شناسه — فاکتور، اعتبار، RFQ و دسترسی گروهی

- شناسه‌های پیش‌رفته: I-01/I-07/I-09/I-10/AD-08/N-03/AP-01/AC-01/C-16/R-05/Q-01/Q-02/CR-01/CR-02/CR-11/AD-07/AC-03/AD-04/N-01/N-02. ۱۸ تازه جزئی؛ دو شناسهٔ قبلی AC-01/N-01 عمیق‌تر شدند. P-08 نیز تاریخ‌دار شد و در شمار ۲۰ منظور نشد.
- کلاس‌های جدید: `Invoice/InvoiceRepository`, `Quote/QuoteRepository`, `Credit/LedgerService`, `Support/NotificationQueue`, `Api/WholesaleRoutes`, `Groups/ProductVisibility`, و صفحات admin/account همراه hookهای bootstrap.
- Node tests ۶۱/۶۱؛ Playground integration exit code 0 شامل quote conversion، credit balance/limit, installment ownership, invoice sequence/void, cash discount و product group restriction. PHP system CLI موجود نیست؛ اجرای Playground PHP runtime فایل‌های load‌شده را parse/اجرا کرد.
- شمارش workbook: ۶۹ جزئی/۲۸ بدون شواهد/۰ Done. Official invoice/PDF، correction document، credit gateway، آنلاین‌پرداخت قسط، report download در مرورگر، HPOS واقعی و load/race باقی‌اند.
