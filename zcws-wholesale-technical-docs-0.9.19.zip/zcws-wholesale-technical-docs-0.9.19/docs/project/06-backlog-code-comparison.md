# مقایسهٔ سورس فعلی با سند توسعه

این گزارش ابتدا به‌عنوان baseline تاریخی نوشته شده بود؛ برای آخرین وضعیت، بخش‌های «ادامهٔ فاز مالی» در انتهای سند و workbook را مرجع بگیرید. هیچ ردیفی صرفاً به‌علت وجود کد Done نیست.

بررسی مبنا: `01-requirements.md`، `02-woocommerce-capability-map.md`، `03-architecture-roadmap.md` و هر ۹۷ ردیف `backlog.csv` با شواهد workbook تطبیق داده شدند. سند `04-product-completeness-roadmap.md` پیشنهاد تکمیلی است و تا تصویب، الزام قطعی baseline نیست. **آخرین بازشماری در ۱۱ نوامبر ۲۰۲۶: ۰ پایهٔ جداگانه، ۹۷ جزئی، ۰ مشاهده‌نشده؛ ۰ Done.** شناسه‌های جزئی نیازمند معیار پذیرش‌اند و این نسبت درصد آمادگی/تکمیل محصول نیست.

- پایهٔ موجود ولی runtime-test نشده (دستهٔ مستقل): **0**
- جزئی/ناقص: **97**
- مشاهده‌نشده/پیاده‌سازی‌نشده: **0**
- دارای حداقل بخشی از کد: **97 از 97 = 100%**؛ این فقط حضور شواهد کد است، نه درصد تکمیل یا پذیرش. این شمارش بر اساس تعداد شناسه است، نه effort/معیار پذیرش؛ **Done: 0**.

تطبیق ریز هر ۹۷ کد، شواهد و شکاف آن در فایل Excel کنار این گزارش قرار دارد. شمارش بالا وضعیت پوشش کد است، نه تکمیل پذیرش؛ هیچ شناسه‌ای Done نیست. اجرای بخشی از integration با WordPress Playground ممکن است، اما اجرای staging واقعی/HPOS/نمایش UI هنوز محدودیت دارد.

## نتیجهٔ بررسی

- افزونه فقط بخشی از مرحلهٔ اولیه را دارد: onboarding پایه، یک endpoint My Account، قیمت پایه/ویژه و درصدی، tier/variation و بعضی MOQ/step.
- در کد فاز ۱، Schema::install و dbDelta برای جداول groups، rules, ledger, installments, cheques, quotes, invoices, notifications و logs اضافه شده؛ اجرای migration روی WordPress runtime هنوز آزموده نشده و repository/feature logic همهٔ این جداول هنوز وجود ندارد.
- در بررسی قبلی تنظیمات class سفارشی بود؛ در تغییر اخیر تب `WC_Settings_Page` اضافه و فرم/ذخیره به صفحهٔ native متصل شد. هنوز UI، ذخیره با nonce ووکامرس، حفظ فیلدهای سفارشی و مسیر URL قدیمی در WooCommerce runtime تأیید نشده‌اند.
- در نسخهٔ جاری declaration رسمی FeaturesUtil برای HPOS/Blocks وجود دارد؛ اجرای واقعی HPOS روشن، Checkout Block کامل و آزمون ماتریسی هنوز لازم است.
- ModuleRegistry اولیه برای ۶ ماژول فعلی اضافه شده؛ customer_groups و onboarding تعریف وابستگی دارند. سرویس‌های مستقل دامنه و adapterهای Woo/Regional/Finance هنوز تکمیل نشده‌اند.
- زیرسیستم گروه مشتری دارای جدول/نقش، صفحهٔ WooCommerce برای ایجاد/ویرایش/حذف امن گروه، انتساب گروه در پروفایل کاربر و اتصال کنترل wholesale eligibility به roleهای ثبت‌شده است. هنوز ruleهای قیمت/MOQ اختصاصی هر گروه، migration نقش‌های موجود و آزمون runtime باقی است.
- رویدادهای application submitted/status_changed در جدول audit ذخیره و timeline پایه در فهرست مدیر نمایش داده می‌شود. وضعیت needs_info می‌تواند با راهنمایی مدیر درخواست اطلاعات تکمیلی کند و کاربر واردشده فرم را با مقادیر قبلی دریافت کرده و درخواست تازه ارسال کند؛ کل این چرخه نیازمند آزمون WordPress واقعی است.
- برای O-04 سه کلاس `WC_Email` به صفحهٔ تنظیمات ایمیل ووکامرس متصل شده‌اند: رسید ثبت برای مدیر، تأیید دریافت برای متقاضی و ایمیل نتیجه به متقاضی، با subject/heading (و گیرندهٔ مدیر) قابل تنظیم، قالب HTML/plain قابل override و logging هنگام شکست ارسال. ارسال واقعی هنوز تست نشده و قابلیت صف/retry در scope این پیاده‌سازی نیست.
- یادداشت تاریخی: آن بررسی اولیه پیش از پیاده‌سازی‌های بعدی انجام شده بود؛ اکنون بخشی از checkout fields, WC_Email, REST, credit settlement, invoice lifecycle و reports پیاده‌سازی شده‌اند، اما همچنان معیار پذیرش کامل را نگذرانده‌اند.

## ترتیب اجرای کدنویسی براساس وابستگی backlog

1. Core: module registry، schema migrations، logger/cache، WC_Settings_Page، HPOS/Blocks declaration و تست bootstrap.
2. Groups + Membership + My Account: گروه پویا، lifecycle درخواست/audit، account endpoints استاندارد و پروفایل.
3. Pricing: Price Resolver/precedence، group/category/customer rules، tier/variation، cache و bulk/CSV.
4. Rules + Checkout: validator واحد classic/Store API، checkout fields دو API و order snapshots.
5. Finance: credit/ledger/installments/cheques/settlement idempotent.
6. Invoices + notifications: document series/PDF، WC_Email، adapterهای پیامک/مودیان.
7. Sales/operations: RFQ/quick-order/lists/reports؛ موارد سند 04 تنها پس از تأیید scope.
8. Acceptance matrix: PHP/WP/WC واقعی، HPOS، Blocks و قالب‌ها؛ فقط بعد از آزمون هر آیتم Done شود.

## به‌روزرسانی پس از بررسی ادامهٔ کدنویسی

- `C-01`: bootstrap serviceها پس از `woocommerce_init` اجرا می‌شود؛ تست runtime ترتیب بارگذاری و مسیر نبود WooCommerce هنوز لازم است.
- `C-04`: تب native از `WC_Settings_Page` اضافه شده؛ حفظ گزینه‌ها و رندر واقعی هنوز باید در WooCommerce آزمایش شود.
- `P-14` / `FR-2.1` تاریخ‌های bulk variation: کدهای client/server برای ISO date، clear/cancel و ترتیب بازه به مسیر callback متصل شده‌اند؛ validator helper و resolver قیمت تست PHP-WASM دارند، اما callback/CRUD/cache در WP/WC runtime هنوز آزمون نشده.
- `P-05`: تست PHP-WASM افزوده‌شده ۲۳ حالت resolver قیمت پایه/قدیمی/ویژه/درصدی/ارث‌بری و بازهٔ تاریخ را اجرا می‌کند؛ این پوشش، تست کامل تعارض قواعد/tier و suite PHPUnit موردنیاز را جایگزین نمی‌کند.
- `C-14`: snapshot ردیف سفارش اکنون بر اساس customer خود سفارش است و group/source/unit price/parent/variation/SKU/attributes را نگه می‌دارد؛ تست مستقل با stub برای ردیف wholesale/retail پاس، اما HPOS و checkout واقعی تست نشده.
- بررسی جاری: grammar PHP 8.2 با `php-parser` برای ۵۱ فایل پاس شد؛ `php-wasm-cli -l` روی ۵۱ فایل PHP و `node --check` روی همهٔ JSها پاس شدند. ۸ تست Node قرارداد/mock، validator/ModuleRegistry، ۲۳ سناریوی resolver و تست snapshot با PHP-WASM موفق‌اند. این‌ها جایگزین آزمون integration در WordPress/WooCommerce نیستند.
- هیچ شناسه‌ای صرفاً به دلیل این تغییرات Done علامت نخورده و شمارش ۶/۲۷/۶۴ در بالای سند همچنان فقط snapshot قبلی است.


## وضعیت جاری — CR-07 و O-07 (۱۱ نوامبر ۲۰۲۶)

- CR-07: checkout کلاسیک و Checkout Block برای درگاه `zcws_mixed_settlement`، validator سروری، ذخیرهٔ plan و رزرو اعتباری اتمیک؛ Playground سناریوی ۲۰٪ نقدی + ۵۰٪ چک + ۳۰٪ اعتبار، عدم تغییر total سفارش، سفارش پرداخت مرتبط سهم آنلاین و callback تکراری را می‌گذراند. PSP واقعی/۳DS، refund/chargeback و ماتریس قالب/نسخه باز است؛ جزئی، نه Done.
- O-07: OTP اختیاری درخواست عمده با endpoint nonce-protected، کد HMAC‌شده، انقضای ۱۰ دقیقه، سقف پنج تلاش، cooldown و rate limit شماره/IP؛ adapter پیامک با فیلتر `zcws_send_sms` و fail-closed، کنترل نهایی در server submit و مصرف یک‌باره پس از ذخیره. Playground mock provider را با کد اشتباه/درست، ارقام محلی، cooldown، lockout، مصرف دوباره و نبود provider می‌آزماید. هیچ سرویس پیامکی/credential واقعی bundled نیست؛ carrier delivery, consent, production adapter و مرورگر/staging بازند؛ جزئی، نه Done.
- N-04: صف SMS به صف durable اعلان اضافه شد؛ شماره نرمال و مقصد نامعتبر رد می‌شود، متن plain تا ۱۶۰۰ نویسه است، enqueue idempotent و worker با claim شرطی و retry محدود کار می‌کند. Playground رفض provider، retry/success و dedupe را تست می‌کند. Provider/carrier واقعی، consent/quiet-hours و ambiguous timeout باز است؛ جزئی، نه Done.
- Node tests: **72/72**؛ WordPress Playground: **exit code 0**. پیام عمومی unexpected output در activation ووکامرس مشاهده می‌شود. OTP/SMS/PSP واقعی تأیید نشده‌اند.
- AP-02: دو custom topic چرخهٔ درخواست به سیستم native Webhooks ووکامرس متصل شدند؛ valid resource/event و topic hookها ثبت می‌شوند و payload حداقلیِ application بدون تلفن/شناسه کسب‌وکار/مدارک تولید می‌شود. امضا و delivery async را خود WooCommerce مدیریت می‌کند. Playground ثبت topic و payload را پاس کرد؛ endpoint واقعی، signature receiver، retry/network و staging باز است؛ جزئی، نه Done.
- Node tests: **73/73**؛ WordPress Playground: **exit code 0**. پیام عمومی unexpected output در activation ووکامرس مشاهده می‌شود. SMS/PSP/webhook واقعی هنوز تأیید نشده‌اند.
- I-02: snapshot نسخهٔ ۲ اکنون اقلام/SKU/تعداد/مالیات/تخفیف/ارسال/صورتحساب و تسویه را هنگام ساخت سند نگه می‌دارد؛ admin و مالک مشتری لینک nonceدار به قالب چاپ A4 HTML قابل override دارند. کنترل capability/مالکیت و non-draft برای مشتری برقرار است. Playground snapshot و template render را آزمود؛ server-side PDF، browser/theme/print matrix و موارد مالیاتی همچنان بازند؛ جزئی، نه Done.
- Node tests: **74/74**؛ WordPress Playground: **exit code 0**. پیام عمومی unexpected output هنگام activation ووکامرس مشاهده می‌شود. PSP/SMS/webhook شبکه‌ای واقعی و PDF سرور هنوز تأیید نشده‌اند.
- Workbook بازشماری شد: **84 جزئی، 13 بدون شواهد، 0 Done از 97**.
- چک‌لیست‌ها: `zcws-wholesale/tests/phone-otp-test-plan.md`, `zcws-wholesale/tests/sms-adapter-test-plan.md`, `zcws-wholesale/tests/webhook-test-plan.md`, `zcws-wholesale/tests/invoice-print-test-plan.md` و `zcws-wholesale/tests/manual-test-plan.md`.

## ادامهٔ کدنویسی و شمارش آخرین پیشرفت

- `C-13` اکنون پیاده‌سازی جزئی دارد: Classic + Blocks registration، محدودکردن فیلدهای Blocks به عمده‌فروش تأییدشده، validation و ذخیرهٔ Classic از مسیر WC_Order CRUD؛ رندر و ثبت نهایی Checkout Block/HPOS هنوز بررسی نشده‌اند.
- `R-02` اکنون پیاده‌سازی جزئی دارد: فیلدهای حداقل تعداد/مبلغ در مدیریت گروه و اعتبارسنجی هر دو مسیر سبد. تست Playground زیر حداقل را برای Classic و Store API آزمایش می‌کند؛ سناریوهای مبلغ مرزی/کوپن و UI هنوز بازند.
- پس از این تغییرها: ۶ پایه/تست‌نشده + ۲۹ جزئی = ۳۵ از ۹۷ شناسه (۳۶٫۱٪) دارای بخشی از کد؛ ۶۲ مورد هنوز مشاهده/پیاده‌سازی نشده‌اند؛ ۰ مورد Done. این نسبت وزن نیازمندی و معیارهای قبولی را منظور نمی‌کند و بنابراین «درصد تکمیل محصول» نیست.

- `C-15`: تنظیم روش‌های پرداخت محدودشده به گروه و فیلتر `woocommerce_available_payment_gateways` افزوده شد؛ در integration برای wholesale حذف gateway انتخاب‌شده و برای guest حفظ gateway آزمایش می‌شود. پرداخت واقعی/HPOS و edge caseهای gateway هنوز تست نشده‌اند.
- پس از این مورد: ۶ پایه/تست‌نشده + ۳۰ جزئی = ۳۶ از ۹۷ شناسه (۳۷٫۱٪) دارای بخشی از کد؛ ۶۱ مشاهده/پیاده‌سازی نشده؛ هیچ مورد Done نیست.

- `C-03`: declarationهای رسمی WooCommerce برای HPOS و Cart/Checkout Blocks در `before_woocommerce_init` اضافه شد؛ با این حال اجرای تازهٔ Playground فقط integration عمومی را پاس کرده و HPOS واقعی/checkout block واقعی را صریحاً فعال نکرده، پس declaration از نظر release هنوز provisional است.
- شمارش فعلی: ۰ پایهٔ جداگانه + ۳۷ جزئی = ۳۷ از ۹۷ (۳۸٫۱٪) دارای بخشی از کد؛ ۶۰ مورد بدون کد شواهدی؛ Done همچنان صفر.


آخرین کدنویسی متمرکز فاز ۱: Compatibility API پیش از init و آزمون ثبت آن؛ داشبورد capability-protected زیر WooCommerce؛ audit پایدار و redacted برای تغییر نقش/گروه؛ و ۲۶ contract test برای تمام شناسه‌های فاز ۱. وضعیت تکمیل هیچ شناسه‌ای ارتقا نیافته؛ runtime HPOS/Checkout Block هنوز باقی است.

- integration فعلی اکنون زیرمعیارهای P-01/P-03/P-12/P-13/R-01/R-06 را هم روی Woo CRUD/Playground exercise می‌کند؛ به همین دلیل آن‌ها از «پایه/تست‌نشده» به «جزئی» منتقل شدند، نه Done. شمارش: ۳۷ جزئی، ۶۰ مشاهده‌نشده، ۰ Done.

## فاز ۲ — بستهٔ My Account و Quick Order (ادامهٔ ۱۱ نوامبر ۲۰۲۶)

- `includes/Frontend/WholesaleAccount.php` اکنون در `Plugin` با ماژول مستقل و dependencyهای `customer_groups`، `pricing` و `quantity_rules` boot می‌شود؛ Installer endpointهای `/zcws-wholesale/` و `/zcws-quick-order/` را هم ثبت می‌کند.
- قابلیت‌های دارای کد/شاهد جزئی در این دور: `C-10` سفارش سریع SKU/quantity؛ `C-11` دریافت CSV سفارش؛ `C-12` سفارش مجدد از سفارش متعلق به همان کاربر؛ `C-17` جست‌وجو/جدول variation با pagination؛ `P-11` خروجی CSV قیمت (فقط export)؛ `AC-02` لیست CSV مختص خریدار عمده. `AC-01` و `P-15` از قبل جزئی بودند؛ شواهد حساب/variation در این فایل افزوده شده اما شمارش شناسه را دوباره افزایش نمی‌دهد.
- امنیت/مرزها: endpointهای منو فقط به عمده‌فروش تأییدشده؛ nonce برای quick order/CSV/reorder/export؛ CSV ورودی فقط فایل آپلودشده با پسوند CSV، سقف ۲ MiB/۲۵۰ ردیف و دو ستون؛ SKU/تعداد و موجودی/قابلیت خرید اعتبارسنجی می‌شود و خطوط پیش از افزودن به سبد resolve می‌شوند؛ خروجی CSV BOM UTF-8 و neutralize فرمول spreadsheet دارد. duplicate SKUها تجمیع و تعداد تجمعی محدود می‌شود.
- جدول variation، قیمت کاربر جاری را از WooCommerce می‌خواند و موجودی/MOQ/step را نشان می‌دهد؛ پنجرهٔ صفحه‌بندی حداکثر پنج صفحه است. CSV قیمت اکنون محصول ساده و variation را به‌شکل صفحه‌ای query می‌کند.
- تست: `node --test tests/*.test.js` برابر ۴۱/۴۱؛ Blueprint Playground WP 7.1.4 / WC 11.3.0 / PHP 8.2 با integration و account endpoint/CSV formula security assertion exit code صفر. پیام unexpected output هنگام activation خود WooCommerce باقی است. این smoke-test، فایل واقعی multipart، رندر قالب، submit/cart/order lifecycle واقعیِ مرورگر یا HPOS فعال را اثبات نمی‌کند.
- معیارهای باز: CSV price import، preview/rollback، PDF، قرارداد قیمت اختصاصی، receipt/account invoice/credit/installment tabs، HTTP upload واقعی، تست سفارش سریع با cart کامل و replay/atomic rollback، چرخهٔ order/refund کامل، UI/accessibility و matrix performance/theme.
- Snapshot میان‌مرحله‌ای بعد از اولین بخش حساب/سفارش: ۴۳ جزئی، ۵۴ بدون شواهد کد. پس از آن، همین نوبت کدنویسی گسترش یافت و ۲۰ شناسهٔ یکتا را با تغییرات کد معنادار پیش برد؛ ۱۴ مورد جدید به دستهٔ جزئی اضافه شد و ۶ شناسهٔ قبلاً جزئی نیز پیشرفت جداگانه گرفتند.
- Snapshot پایان بستهٔ My Account پیش از بستهٔ فاکتور/اعتبار: **۵۱ جزئی، ۴۶ بدون شواهد کد، ۰ Done**. شناسه‌های progressed: C-06, C-10, C-11, C-12, C-14, C-17, P-04, P-05, P-08, P-09, P-10, P-11, P-15, R-07, O-06, MK-01, AC-01, AC-02, AD-02, AD-03. این وضعیت فقط پوشش کد/شواهد جزئی است؛ هیچ‌یک از این ۲۰ به‌عنوان پذیرش کامل/Done گزارش نمی‌شود.

## ادامهٔ فاز ۲ — صورتحساب، اعتبار، RFQ و دسترسی گروهی (آخرین بسته)

- این بسته ۲۰ شناسهٔ یکتا را با کد معنادار پیش برد: `I-01`, `I-07`, `I-09`, `I-10`, `AD-08`, `N-03`, `AP-01`, `AC-01`, `C-16`, `R-05`, `Q-01`, `Q-02`, `CR-01`, `CR-02`, `CR-11`, `AD-07`, `AC-03`, `AD-04`, `N-01`, `N-02`. ۱۸ مورد تازه از بدون شواهد به جزئی منتقل شدند؛ `AC-01` و `N-01` که قبلاً جزئی بودند، عمق جدید گرفتند. `P-08` نیز قرارداد تاریخ‌دار گرفت، ولی به‌عنوان ID بیست‌ویکم شمارش نشده است.
- invoice repository/admin/account از WooCommerce CRUD snapshot می‌گیرد، شمارهٔ سری/سال/توالی صادر می‌کند، تغییر وضعیت ابطال و audit history را نگه می‌دارد و برای مشتری فقط رکوردهای خودش را می‌خواند. نوع رسمی در وضعیت فعلی قابل صدور نیست چون اتصال/اعتبارسنجی سامانهٔ مالیاتی وجود ندارد؛ PDF، اصلاح واقعی و رقابت هم‌زمان صدور نیازمند پذیرش‌اند.
- quote flow درخواست محدود محصول/تعداد، پیشنهاد قیمت هر ردیف با تاریخ انقضا و پذیرش یک‌باره برای ساخت WC_Order دارد. credit admin/ledger سقف، بدهکار/بستانکار و statement کاربر را پیاده می‌کند اما هنوز gateway نسیه، ثبت خودکار سفارش/پرداخت، lock واقعی checkout، پرداخت اقساط و مدیریت چک‌ها ندارد.
- افزوده‌ها: REST محدود به کاربر عمدهٔ تأییدشده؛ صف ایمیل با retry و اتصال ایمیل‌های درخواست؛ CSV گزارش سفارش عمده با سقف ۱۰۰۰ و neutralize فرمول؛ تخفیف غیرمشمول مالیات با gateway انتخاب‌شده؛ allow-list گروه روی محصول در visibility/purchasability؛ فهرست اقساط مختص کاربر؛ تاریخ شروع/پایان قرارداد مشتری.
- Snapshot جاری workbook: **۶۹ جزئی، ۲۸ بدون پیاده‌سازی مستند، ۰ Done از ۹۷**. جزئی مساوی پذیرش یا آمادگی نیست.
- تست‌ها: Node `61/61`; Playground integration `exit code 0` (WP 7.1.4 / WC 11.3.0 / PHP 8.2). Worker به‌دلیل ۲ CPU روی یک کارگر محدود شد؛ activation ووکامرس پیام عمومی unexpected output دارد. مرورگر/قالب، HPOS فعال صریح، HTTP CSV download/upload، gateway واقعی و آزمون race هم‌زمان اجرا نشده‌اند.

### اصلاح رویکرد: بستن vertical slice پیش از گسترش شمارش

پس از بازخورد کاربر، مسیر کار تغییر کرد: در ادامه شناسه‌ها با تست/feature اضافه به‌تنهایی شمرده نمی‌شوند؛ ابتدا دامنه و معیار قبولی یک قابلیت بسته می‌شود، سپس کدنویسی، integration، امنیت/خطا و acceptance/manual gap ثبت می‌شود. در همین نوبت P-08 عمقی شد: UI واقعی ویرایش/حذف ردیف قراردادی، validation اتمیک batch، تاریخ شروع/پایان و تست runtime اضافه شد؛ چون پذیرش دستی هنوز انجام نشده، وضعیت آن صادقانه «جزئی» می‌ماند. شمارش کل workbook تغییر نکرده: ۶۹ جزئی، ۲۸ بدون شواهد، ۰ Done.


## جدیدترین بسته — اعتبار حساب عمده (۱۱ نوامبر ۲۰۲۶)

- کد افزوده‌شده: `CreditGateway` برای روش `zcws_account_credit`; درگاه فقط به کاربر عمدهٔ واردشده با سقف کافی و بدون بدهی سررسیدگذشته عرضه می‌شود. `process_payment` سفارش را اعتبارسنجی می‌کند، رزرو را ثبت می‌کند و WooCommerce payment event را کامل می‌کند، در حالی که دریافتنی در ledger تا تسویه می‌ماند.
- دفترکل/حساب: جدول `zcws_credit_accounts` برای مانده و سقف اتمیک؛ ledger دارای `idempotency_key` یکتا است. رزرو سفارش و ثبت پرداخت جزئی/کامل داخل تراکنش‌اند. settlement ابتدا ردیف حساب را قفل منطقی می‌کند و سپس ماندهٔ همان سفارش را بررسی می‌کند تا پرداخت همزمان از ماندهٔ بیش از حد جلوگیری شود. schema ارتقا از نسخهٔ قبلی تحت آزمون Playground انجام شده است.
- مدیریت: پنل اعتبار سفارش‌های باز اعتباری را نشان می‌دهد و فرم ثبت پرداخت سفارش با nonce مختص سفارش/کاربر، capability و تطبیق customer دارد. دادهٔ اعتباری هنگام uninstall تنها طبق گزینهٔ حذف داده پاک می‌شود.
- معیارهای تازهٔ Playground: gateway واقعی ساخته می‌شود و پرداخت را به حالت باز می‌برد؛ account balance و order outstanding با مبلغ سفارش هم‌خوانی دارند؛ پرداخت جزئی و نهایی state و مانده را اصلاح می‌کند؛ مرجع تکراری رد می‌شود؛ سررسید گذشته امکان اعتبار جدید را مسدود می‌کند؛ جدول حساب/ستون و ایندکس idempotency پس از upgrade موجودند.
- تست‌ها: `node --test tests/*.test.js` برابر **62/62** پاس؛ WordPress Playground blueprint با WP/WooCommerce/PHP 8.2 برابر **exit code 0**. هشدار worker یک‌کارگر به علت ۲ CPU و پیام عمومی unexpected output در activation خود WooCommerce مشاهده شد؛ PHP CLI محلی نصب نیست.
- وضعیت IDها در workbook: `CR-03`, `CR-05`, `CR-08`, `T-02` از «نیست» به **جزئی** ارتقا یافتند؛ عمق `CR-01`, `CR-02`, `CR-11`, `AD-07` نیز ثبت شد. آمار فعلی: **73 جزئی، 24 بدون شواهد، 0 Done از 97**. این بسته کمتر از حد هدف ۲۰ شناسه در هر نوبت را پیش برده؛ برای رعایت کیفیت هیچ شناسهٔ اضافی را صوری شمرده یا Done اعلام نکردم.
- بازمانده/عدم پذیرش: اجرا و مرور واقعی checkout classic/Blocks و قالب، رفتار refund/cancel/chargeback، آزمون race چند worker و deadlock/rollback، overflow/precision/ارزهای مختلف و fee/tax، قفل همهٔ gatewayها در UI، تاریخچهٔ تعدیل/تطبیق با PSP، UI accessibilty، ماتریس PHP/WP/WC/HPOS، پرداخت آنلاین installment، چرخهٔ واقعی چک و اعلان سررسید هنوز کامل نیستند. بنابرین `CR-03/05/08` جزئی هستند، نه Done؛ `CR-04/06/07/09/10/12` نیز باز هستند.

## ادامهٔ اعتبار — برنامه و تسویهٔ اقساط (۱۱ نوامبر ۲۰۲۶)

- نسخه به `0.4.0` رسید تا نصب موجود، ستون `paid_amount` جدول قسط را با مسیر upgrade بگیرد.
- `InstallmentService` برای سفارش اعتباری باز، ۲ تا ۲۴ قسط می‌سازد؛ تاریخ ISO ناممکن/گذشته یا غیرصعودی، مبلغ نامعتبر، مجموع متفاوت از مانده و برنامهٔ تکراری رد می‌شود. پرداخت قسط، ردیف حساب را قفل می‌کند و در یک تراکنش ماندهٔ account، ledger با کلید idempotency و وضعیت/مبلغ پرداخت‌شدهٔ قسط را به‌روز می‌کند.
- پنل مدیر اکنون برنامهٔ قسط و پرداخت جزئی/کامل را با capability، nonce مختص رکورد و تطبیق کاربر سفارش ارائه می‌کند؛ نتیجهٔ عملیات به‌صورت notice نمایش داده می‌شود. صفحهٔ مشتری همچنان فقط اطلاعات متعلق به همان کاربر را می‌خواند و مشخص می‌کند پرداخت آنلاین فعال نیست.
- تست Playground: migration `paid_amount`; رد مبلغ جمعی نادرست و تاریخ ناممکن؛ ساخت برنامه؛ رد برنامهٔ تکراری؛ پرداخت جزئی، رد مرجع تکراری، تکمیل قسط اول و پرداخت قسط دوم؛ ماندهٔ نهایی سفارش صفر و state `settled`. Node **63/63** و Playground **exit code 0**. هشدار worker یک‌کارگر/پیام عمومی activation WooCommerce پابرجاست.
- فقط `CR-06` از بدون شواهد به جزئی ارتقا یافت؛ `AC-03`, `AD-07`, `T-02` عمق گرفتند. شمارش workbook: **74 جزئی، 23 بدون شواهد، 0 Done**. سهمیهٔ هدف ۲۰ شناسه حاصل نشد و این بسته را به‌دلیل تغییر محدود دامنه به‌عنوان ۲۰ مورد جا نزدم.
- هنوز باز: پرداخت آنلاین و order-pay امن مشتری (`CR-12`)، سازندهٔ تسویهٔ ترکیبی در checkout (`CR-07`)، چرخهٔ واقعی چک/برگشتی (`CR-04/09`)، یادآوری سررسید از صف اعلان (`CR-10/N-05`)، تغییر/لغو برنامه، تست race چند process، rollback fault injection و مرورگر/دسترس‌پذیری. در نتیجه `CR-06` نیز جزئی است و Done نیست.

## پرداخت آنلاین قسط — ادامهٔ بازبینی عمقی (۱۱ نوامبر ۲۰۲۶، نسخهٔ 0.4.1)

- مشتری از ردیف قسط متعلق به خودش در My Account یک `order-pay` ووکامرس آغاز می‌کند. سرویس یک child order مجزا با یک fee line بدون مالیات و دقیقاً به مبلغ ماندهٔ همان قسط می‌سازد؛ سفارش اصلی و جمع/محاسبات آن دست‌کاری نمی‌شود.
- هر child به parent order و installment ID متصل و در جدول به‌عنوان payment order ثبت است؛ تکرار درخواست همان لینک را می‌دهد. تلاش ناموفق/لغوشده با child تازه جایگزین می‌شود و قبلی cancel می‌گردد. callback `woocommerce_payment_complete` فقط child واقعاً paid و مرتبط را می‌پذیرد؛ ledger/account/قسط در تراکنش با کلید idempotency به‌روز می‌شوند. callback تکراری امن است و عدم تطبیق به `on-hold` برای بررسی می‌رود.
- روش پرداخت اعتباری در order-pay این child هم از فهرست gatewayها حذف و هم در `process_payment` رد می‌شود تا پرداخت بدهی با ایجاد بدهی تازه ممکن نباشد. کاربری که دسترسی wholesale خود را از دست داده، همچنان می‌تواند بدهی قسط متعلق به خودش را بپردازد.
- Playground موارد زیر را اجرا کرد: عدم دسترسی کاربر دیگر؛ ساخت مبلغ دقیق و fee line؛ تکرار درخواست و reuse لینک؛ حذف gateway اعتباری؛ رد مسیر recursive credit؛ شبیه‌سازی decline و ساخت تلاش جایگزین؛ callback پرداخت آنلاین و تکرار idempotent آن؛ نهایی‌شدن order receivable. Node **63/63** و Playground **exit code 0**.
- `CR-12` به **جزئی** منتقل شد، نه Done. Snapshot workbook اکنون **75 جزئی، 22 بدون شواهد، 0 Done** است. تست واقعی PSP/3DS و refund/reversal و race دو callback دیررس روی محیط واقعی انجام نشده؛ ساخت و flow پایه در WooCommerce تست شده‌اند.
- گام‌های release باقیمانده برای پرداخت: gateway واقعی/خطاهای برگشت‌پذیر، تطبیق/تسویهٔ Refund و chargeback، سفارش‌های چندارزی/rounding، session/order-key در مرورگر، و رفتار callback دیررس پس از صدور تلاش جایگزین. ابزار Playground جای PSP sandbox و مرورگر واقعی را نمی‌گیرد.


## چرخهٔ چک و یادآوری بدهی/قسط — نسخهٔ 0.5.0

- مدیر می‌تواند چک را به قسط باز وصل کند؛ serial تکراری برای همان کاربر/بانک، تاریخ نامعتبر و مبلغ بیش از مانده یا مبلغ قبلاً رزروشده رد می‌شود. پرداخت تا زمان وصول وارد حساب نمی‌شود.
- چرخهٔ چک: pending به cleared/bounced/returned/cancelled؛ bounced/returned قابلیت ارائهٔ مجدد یا لغو دارند. `cleared` در تراکنش واحد ردیف حساب را کاهش می‌دهد، order-payment را با کلید یکتا به ledger می‌افزاید، paid_amount/status قسط و ledger_id چک را ثبت می‌کند. برگشت/عودت قسط را دوباره pending/overdue می‌کند و خرید اعتباری را مسدود می‌کند. مشتری وضعیت چک‌های خودش را می‌بیند.
- `has_overdue` اکنون چک pending گذشته از سررسید و وضعیت bounced/returned را هم مانع اعتبار جدید می‌داند.
- یادآور روزانهٔ WP-Cron، اقساط سررسیدشده/تا سه روز آینده و بدهی سفارش اعتباری بدون برنامهٔ اقساط را به صف ایمیل دارای retry می‌فرستد؛ برای صف ایمیل `idempotency_key` یکتا و کلید دوره‌ای هفتگی افزوده شد. وضعیت آخرین reminder در ردیف قسط/سفارش برای فاصلهٔ ارسال ثبت می‌شود. اجرای تکراری در Playground duplicate تولید نکرد.
- تست: Node **65/65**؛ Playground **exit code 0** شامل due-lock، ایجاد/رد serial تکراری و reserve بیش از مانده، bounce و re-present، returned و re-present، clear با تطبیق ledger/account/order، clear تکراری و final settlement، migration stateها، queue reminders قسط/بدهی و idempotency enqueue.
- چهار ID تازه از «بدون شواهد» به **جزئی** منتقل شدند: `CR-04`, `CR-09`, `CR-10`, `N-05`. آمار workbook: **79 جزئی، 18 بدون شواهد، 0 Done**. پنل `AD-07` و suite `T-02` عمق گرفتند. موارد جزئی پذیرفته/Done نیستند.
- هنوز باز: قوانین حقوقی هر بانک/حوزه و clearing واقعی، SMTP/cron واقعی و پایش deliverability/opt-out، concurrent provider callbacks، PHPUnit/parallel stress، gateway sandbox و ماتریس واقعی HPOS/Blocks/قالب. به‌خصوص job روزانه به WP-Cron وابسته است؛ production باید cron واقعی داشته باشد.


## I-03 — تنظیمات مالیاتی گروه مشتری (۱۱ نوامبر ۲۰۲۶، نسخهٔ 0.9.3)

- فرم گروه، کلاس مالیاتی محصول را روی حالت ارث‌بری (پیش‌فرض)، کلاس استاندارد یا یکی از کلاس‌های ثبت‌شدهٔ WooCommerce تنظیم می‌کند. اعتبارسنجی سرور فقط slugهای فعال `WC_Tax::get_tax_class_slugs()` را می‌پذیرد. این سیاست فقط برای مشتری عمدهٔ تأییدشدهٔ همان گروه اعمال می‌شود؛ مهمان و مشتری عادی دست‌نخورده‌اند.
- معافیت VAT گزینه‌ای مستقل و opt-in است و پیش‌فرض خاموش می‌ماند. setter رسمی `WC_Customer::set_is_vat_exempt()` فقط در بازهٔ hookهای before/after محاسبهٔ cart totals فعال است؛ مقدار قبلی customer بازگردانده می‌شود تا exemption گروه وارد session نشود و flag قبلی افزونه‌های دیگر حفظ شود. Snapshot موقت static در سطح request بین listener instanceهای این سرویس مشترک است تا hookهای تکراری مقدار را دوباره override نکنند. این گزینه احراز قانونی معافیت یا ثبت‌نام VAT نیست و نباید بدون مستندات مالیاتی کسب‌وکار فعال شود.
- کلاس و وضعیت معافیت هنگام ساخت سفارش با WooCommerce order CRUD در metadata snapshot می‌شوند؛ recalculation بعدی از snapshot تبعیت می‌کند، نه از تنظیم فعلی گروه. این مسیر هیچ fee/discount مصنوعی نمی‌سازد و total/درگاه پرداخت را دست‌کاری نمی‌کند.
- Node **76/76** و WordPress Playground **exit code 0**؛ آزمون runtime hookهای before/after و restore flag قبلی (با listenerهای تکراری سرویس)، کلاس استاندارد، عدم نشت به کاربر ناشناس/عادی، ثبت snapshot و ثابت‌ماندن معافیت سفارش پس از تغییر تنظیم گروه را پوشش می‌دهد.
- `I-03` از «بدون شواهد» به **جزئی** منتقل شد؛ در همان مرحله شمارش workbook **85 جزئی، 12 بدون شواهد، 0 Done از 97** بود؛ پس از تکمیل شواهد I-04، شمارش جاری **86 جزئی، 11 بدون شواهد، 0 Done** است.
- بازماندهٔ پذیرش: محاسبهٔ نرخ واقعی برای محصول مشمول/معاف و کلاس سفارشی در Classic و Checkout Blocks؛ tax-inclusive/exclusive، چندنرخ، rounding، tax shipping، coupon/refund، آزمون session واقعی/extensionهای VAT و پاکسازی sessionهای sticky احتمالی نسخه‌های توسعه‌ای پیشین، REST؛ تست پرداخت PSP و مرورگر/قالب در staging؛ و تأیید حسابدار/مشاور مالیاتی حوزهٔ واقعی فروشگاه. به همین دلیل I-03 جزئی است، نه Done یا گواهی انطباق.


## I-04 — فیلدهای خریدار و مبلغ به حروف در سند چاپی (نسخهٔ 0.9.2، ۱۱ نوامبر ۲۰۲۶)

- فرم درخواست و پروفایل مدیر مشتری عمده فیلدهای شناسه/کد ملی، کد اقتصادی و شماره ثبت را پشتیبانی می‌کنند؛ پس از تأیید درخواست، مقادیر معتبر به user profile منتقل می‌شوند. اعتبارسنجی کد ملی در market mode ایران از checksum موجود استفاده می‌کند و مقدار با checksum نامعتبر دادهٔ قبلی را overwrite نمی‌کند. در `InvoiceRepository` اطلاعات خریدار در snapshot نسخهٔ ۳ ثبت می‌شود؛ fee lineهای WooCommerce نیز جداگانه snapshot/render می‌شوند.
- `Invoice\AmountToWords` برای ارزهای IRR و IRT مبلغ صحیح را به حروف فارسی تبدیل می‌کند؛ ارزهای نامرتبط را به‌اشتباه به ریال/تومان تبدیل نمی‌کند. مبلغ `185 IRR` در runtime به `یکصد و هشتاد و پنج ریال` رسید.
- Node **76/76** و Playground **exit code 0**؛ داده‌های شناسهٔ مشتری، sync پس از approval، رد checksum نامعتبر، fee line، حروف مبلغ، رد ارز EUR برای converter ایرانی و نمایش نهایی قالب چاپ آزموده شدند.
- `I-04` از بدون شواهد به **جزئی** ارتقا یافت؛ شمارش workbook **86 جزئی، 11 بدون شواهد، 0 Done از 97** است.
- فاکتور رسمی/مودیان در این پیاده‌سازی ایجاد نمی‌شود. موارد باز: شناسهٔ قانونی فروشنده/عضویت مالیاتی، نسخهٔ جاری و رسمی schema/الگوی سامانه، نوع خریدار و الزامات conditional، شناسه و واحد کالا/خدمت، تمام وجوه/عوارض قانونی، اسناد مرجع، تاریخ/سریال/امضا، اصلاح/ابطال، پرداخت/تسویه و تأیید حسابدار/مشاور مالیاتی؛ پس عبارت «رسمی» به معنی ثبت قانونی نیست و I-04 Done نیست.


### I-03 — اصلاح ماندگاری exemption در نسخهٔ 0.9.3

معافیت گروه دیگر در `wp_loaded` به‌صورت دائمی روی `WC()->customer` ست نمی‌شود. hook آخر `woocommerce_before_calculate_totals` مقدار قبلی customer را نگه می‌دارد، setter را فقط برای tax calculation اعمال می‌کند و در `woocommerce_after_calculate_totals` مقدار قبلی را برمی‌گرداند. آزمون Playground از مسیر خود دو action استفاده می‌کند و بررسی می‌کند مقدار group exemption در session باقی نماند. این کار sessionهای احتمالیِ آلوده‌شده توسط نسخهٔ توسعه‌ای قبلی را به‌طور پس‌نگر پاک نمی‌کند؛ چنین sessionهایی و تعامل واقعی با افزونه‌های VAT در staging هنوز باید آزموده شوند.


## I-06 — برگهٔ بسته‌بندی/ارسال (نسخهٔ 0.9.4)

`packing_slip` به نوع‌های سند اضافه شد. `InvoiceRepository` آدرس ارسال سفارش را در snapshot ذخیره می‌کند و صفحهٔ مدیریت اجازهٔ ساخت سند را می‌دهد. قالب چاپ در این نوع سند فقط نشانی گیرنده و شرح کالا، SKU و مقدار را می‌نمایاند و فیلدهای قیمت، تخفیف، مالیات، هزینه و وضعیت تسویه را عمداً حذف می‌کند. پیش‌فاکتور در lifecycle قبلی قابل ساخت بود. Node **77/77** و Playground **exit code 0**؛ آزمون runtime ساخت snapshot و بررسی خروجی فاقد داده مالی انجام شد. I-06 از «نیست» به **جزئی** منتقل شد؛ شمارش جاری **87 جزئی، 10 بدون شواهد مستند و 0 Done از 97**. سند ارسال هنوز اثبات تحویل/بارنامه قانونی نیست؛ گردش‌کار انبار، حمل‌کننده، تحویل، قالب‌های جداگانه و ماتریس مرورگر/staging بازند.


## AD-05 — کارشناس فروش با دسترسی محدود (نسخهٔ 0.9.5)

`zcws_sales_rep` حداقل نقش و capability اختصاصی دارد. پروفایل مشتری تخصیص کارشناس را مدیریت می‌کند؛ صفحهٔ اختصاصی فهرست را به مشتریان عمدهٔ تأییدشده با meta assignment دقیق محدود می‌کند. Drill-down سفارش‌ها با WooCommerce CRUD و customer ID همان مشتری، سقف ۲۵ سفارش، بدون لینک ویرایش، ارائه می‌شود. `map_meta_cap` برای نقش sales rep دسترسی `manage_woocommerce` را بیرون این صفحه رد می‌کند و در route اختصاصی فقط capability محدود را map می‌کند. Node **78/78** و Playground **exit code 0** شامل رندر صفحه و سفارش آزمایشی. AD-05 از «نیست» به **جزئی** منتقل شد؛ کل backlog: **88 جزئی، 9 بدون شواهد مستند، 0 Done از 97**. staging برای چندنقشی، HPOS، theme، مسیرهای مستقیم/REST و حذف/تغییر تخصیص لازم است؛ سفارش‌گذاری از طرف مشتری AD-06 است و هنوز جزئی/مستند نشده.


## AD-06 — ثبت سفارش از طرف مشتری تخصیص‌یافته (نسخهٔ 0.9.6)

فرم scoped کارشناس SKU/تعداد می‌گیرد؛ handler `admin-post` nonce/capability و `SalesRepAccess::can_view_customer` را اعمال می‌کند. parsing محدود به ۵۰ ردیف و تعداد صحیح مثبت تا یک میلیون است؛ SKU تکراری تجمیع و قبل از ایجاد هر سفارش، محصول، visibility/purchasability، موجودی، quantity rules و حداقل‌های گروه اعتبارسنجی می‌شوند. `CustomerPricing` سپس `PriceResolver` و tierهای variation/تجمیع opt-in در context همان مشتری اعمال می‌شوند. سفارش pending، addresses، customer owner، salesperson provenance، order notes/audit و line price snapshots با API/CRUD ووکامرس ثبت می‌شوند؛ failure حین persistence order را پاک می‌کند. آزمون Playground قیمت عمده، total، ownership، snapshots و rejectهای invalid را پوشش می‌دهد؛ Node **79/79** و Playground **exit code 0**. AD-06 از «نیست» به **جزئی** منتقل شد؛ شمارش جاری **89 جزئی، 8 بدون شواهد، 0 Done از 97**. shipping/coupon/payment selection، concurrent stock، refund و staging HPOS/browser باقی است، پس Done نیست.


## وضعیت اجرای درخواست کاربر — نسخهٔ 0.9.9

کاربر تأکید کرده است که «جزئی» را نمی‌پذیرد؛ بنابراین هیچ وضعیت جزئی را تحویل یا تأیید تلقی نکنید. این مقایسهٔ backlog صرفاً ثبت فنی است و Done=0 باقی می‌ماند تا معیارهای کامل طی شوند.

بستهٔ جدید O-08 در `includes/Onboarding/CompanyAccounts.php`: فرم دعوت ایمیلی، token هش‌شده با انقضای ۷روزه، پذیرش فقط با ایمیل دقیق و claim یک‌باره، نقش شرکت و inheritance گروه عمده، سقف ماهانه در classic و Store API، رزرو با UPDATE شرطی داخل transaction، رد سفارش اضافه، آزادسازی refund/cancel idempotent، ACL فاکتور والد/زیرکاربر، و ارسال سند صادرشده به billing email شرکت با لینک bearer سی‌روزه و resend مدیر. Schema چهار جدول را می‌سازد؛ نسخه 0.9.9 مسیر upgrade دارد. Playground با ایمیل mock و order/refund واقعی در WooCommerce تمرین شد؛ Node **81/81** و Playground **exit 0**.

I-11 نیز اکنون coupon/shipping/payment method و tax-rate IDs را در snapshot چندسفارشی نگه می‌دارد؛ منفی‌های cross-customer/currency و شناسهٔ malformed هم در Playground رد می‌شوند.

Snapshot کد: **۹۱ نیازمندی دارای بخشی از کد/شواهد، ۶ نیازمندی بدون شواهد کد، صفر Done/پذیرفته‌شده از ۹۷**. برای O-08 هنوز SMTP/مرورگر واقعی و stress MySQL همزمانی و matrix HPOS/Blocks/theme لازم است؛ کار روی بقیهٔ ۹۷ مورد ادامه دارد.


## به‌روزرسانی بعدی — L-01 و نسخهٔ 0.9.10

`PersianDateFormatter` با تبدیل Jalali محاسباتی و رقم فارسی اضافه و به تاریخ‌های invoice، wholesale CSV/report، نمای کارشناس، application/admin history، ایمیل application/credit reminder، quote و حساب اعتباری متصل شد. تاریخ ISO در CSV نگه داشته می‌شود و ستون محلی جداگانه دارد. آزمون نوروز/کبیسه/locale/fa print در Playground exit 0؛ Node 82/82.

این وضعیت هنوز مورد تأییدشده نیست. گزارش جاری کد: **۹۲ شناسهٔ دارای پیاده‌سازی ناقص، ۵ شناسهٔ بدون کد مستند، ۰ Done**. طبق دستور کاربر «جزئی» معادل تحویل نیست؛ همهٔ ۹۷ شناسه همچنان نیاز به تکمیل دارند.


## پیشرفت کدنویسی I-08 — ۱۱ نوامبر ۲۰۲۶

در `/home/user/zcws-wholesale` فیلدهای پروفایل قانونی فروشنده به تنظیمات افزوده و sanitize شدند؛ فیلد شناسهٔ کالا/خدمت و کد واحد به محصول و variation افزوده شد (variation مقدار والد را به ارث می‌برد). Invoice snapshot اکنون داده‌های seller/buyer/item و نتیجهٔ preflightِ «حضور داده» را نگه می‌دارد؛ قالب چاپ آن‌ها را نشان می‌دهد و صریحاً می‌گوید اعتبار قانونی/پذیرش مرجع یا اتصال مؤدیان تأیید نشده است. موارد ناقص در preflight فهرست می‌شوند.

Node **83/83** و WordPress Playground با PHP 8.2/WP 7.1.4/WooCommerce 11.3.0 **exit code 0**؛ آزمون runtime snapshot، فیلدهای فروشنده/کالا، preflight کامل/ناقص و خروجی چاپ را بررسی می‌کند. هشدار چاپ خروجی غیرمنتظره هنگام فعال‌سازی WooCommerce در Playground باقی است؛ اجرای آزمون موفق بود. PHP CLI در محیط جاری نصب نیست و lint مستقل اجرا نشد؛ parser/runtime خود Playground فایل‌های PHP را بارگذاری و اجرا کرد.

I-08 از «بدون شواهد» به **جزئی** منتقل شد، نه Done. Snapshot جاری: **۹۳ جزئی، ۴ بدون شواهد (I-05, AP-03, L-02, T-01)، ۰ Done از ۹۷**. باقی‌ماندهٔ I-08 شامل اعتبارسنجی در برابر schema/مرجع رسمی، ارسال/پذیرش واقعی سامانهٔ مالیاتی، بازبینی حقوقی و آزمون پذیرش محیط عملیاتی است؛ این کار آن را تحویل‌پذیر یا صورتحساب رسمی نمی‌کند.


## پیشرفت کدنویسی I-05 — adapter boundary و صف ارسال

برای فاکتور نوع official، `TaxAuthorityAdapterInterface` و `TaxAuthoritySubmissionService` اضافه شدند. مدیر می‌تواند پیش‌نویس را فقط وقتی فیلدهای پایه حاضرند و provider از فیلتر `zcws_invoice_tax_authority_adapter` ارائه شده باشد صف کند. worker وضعیت را اتمیک claim می‌کند؛ request ID پایدار برای retry دارد؛ خطاهای موقت با backoff محدود تکرار و jobهای stale بازیابی می‌شوند. پاسخ‌های ذخیره‌شده محدود و فیلدهای اسرارآمیز حذف می‌شوند. سند فقط وقتی `registered` می‌شود که adapter وضعیت `accepted` و شناسهٔ مرجع برگرداند. دسترسی فاکتور/قالب چاپ شناسهٔ مرجع را هم پشتیبانی می‌کند.

Node **84/84** و WordPress Playground **exit code 0**؛ mock adapter مسیر fail-closed بدون provider، رد پیش‌نویس ناقص، پذیرش و ثبت مرجع، redaction پاسخ، و retry را آزمود.

این یک seam امن و گردش‌کار قابل‌اتصال است، نه آداپتر تولیدی سامانهٔ مؤدیان: mapping و امضا/گواهی، مدیریت امن credentials، اعتبارسنجی schema رسمی روز، inquiry status و پذیرش زنده پیاده‌سازی/تأیید نشده‌اند. هیچ درخواست شبکهٔ واقعی به مرجع مالیاتی ارسال نشد. بنابراین I-05 نیز فقط **جزئی** است. Snapshot جاری: **۹۴ جزئی، ۳ بدون شواهد (AP-03, L-02, T-01)، ۰ Done از ۹۷**.


## پیشرفت AP-03 — webhookهای قابل‌مصرف برای ERP

WooCommerce native signed webhook registry دو topic کمینهٔ `zcws.invoice_registered` و `zcws.quote_converted` گرفت. تبدیل quote فقط بعد از ثبت سفارش و commit وضعیت اجرا event می‌فرستد؛ ثبت invoice فقط بعد از پاسخ accepted آداپتر مالیاتی trigger می‌شود. payloadها فقط شناسه‌ها، وضعیت، مبلغ/واحد پول، order number و authority reference لازم را دارند و اطلاعات شخصی/اقلام حساس را dump نمی‌کنند.

Node **85/85** و Playground **exit code 0**؛ مسیر quote conversion event در WooCommerce runtime بررسی شد. این هنوز ERP connector محصولی نیست: mapping اختصاصی vendor، sync/import موجودی، endpoint/credential configuration و پذیرش live ERP لازم‌اند. بنابراین AP-03 فقط **جزئی** است. Snapshot جاری: **۹۵ جزئی، ۲ بدون شواهد (L-02, T-01)، ۰ Done از ۹۷**.


## پیشرفت L-02 — همگام‌سازی metadata چندزبانه

فایل ریشهٔ `wpml-config.xml` اکنون فیلدهای قیمت عمده، قواعد مقدار، tierها، واحدها، نقش‌های دسترسی و شناسه‌های کالا را برای product/variation با سیاست copy ثبت می‌کند و tierهای دسته‌بندی را نیز کپی می‌کند. `MultilingualAdapter` از WPML و Polylang برای یافتن ID زبان پیش‌فرض استفاده می‌کند؛ قیمت قراردادی مشتری و تخفیف‌های گروهی دسته، در صورت نبود ID ترجمه‌شده، به ID اصلی بازمی‌گردند.

Node **86/86** و Playground **exit code 0**؛ مسیر WPML `wpml_default_language`/`wpml_object_id` با mock filter برای ID قرارداد و دسته آزموده شد. اجرای واقعی translation jobهای WPML/Polylang، sync/update metadata بین زبان‌ها، سایت چندزبانهٔ واقعی و regression/theme matrix هنوز انجام نشده؛ L-02 فقط **جزئی** است. شمارش جاری: **۹۶ جزئی، ۱ بدون شواهد (T-01)، ۰ Done از ۹۷**.


## پیشرفت T-01 — Playwright matrix harness

`tests/e2e/theme-checkout-matrix.mjs` و نمونهٔ target JSON یک runner staging تعریف می‌کنند که برای Storefront، Astra، Blocksy، Flatsome و Woodmart هر دو checkout کلاسیک و Block را می‌طلبد. کنترل‌های پایه شامل fingerprint قالب فعال، محصول/قیمت مهمان، ورود عمده، markup checkout، پاسخ HTTP، متن fatal PHP و exceptionهای مرورگر است. فایل محلی target که باید URL/حساب آزمایشی داشته باشد در `.gitignore` قرار گرفته؛ test و راهنمای اجرای امن اضافه شده‌اند. Node **87/87** و `node --check` موفق‌اند.

هیچ staging URL/حساب یا نصب قالب‌های هدف در این workspace موجود نبود؛ بنابراین مرورگر matrix اجرا نشده و screenshot/visual, responsive/mobile, accessibility, actual purchase/Store API, HPOS/Legacy, Elementor و PHP matrix هنوز gate هستند. T-01 فقط **جزئی** است. Snapshot فعلی اکنون برای هر ۹۷ شناسه دست‌کم شواهد کد دارد، اما **۹۷ جزئی/ناقص، صفر Done/پذیرفته‌شده**؛ مطابق دستور کاربر هیچ مورد جزئی تحویل تلقی نمی‌شود.


### تکمیل جزئی L-02 — Polylang metadata hooks

برای کنار فایل WPML، `MultilingualAdapter` اکنون `pll_copy_post_metas` و `pll_copy_term_metas` را نیز ثبت می‌کند و فقط کلیدهای allow-list شدهٔ قیمت/قواعد محصول و tier دسته‌بندی را به Polylang می‌دهد. Plugin bootstrap این adapter را فعال می‌کند. آزمون Playground callbackهای allow-list را بررسی کرد؛ افزونهٔ Polylang واقعی و چرخهٔ ساخت/همگام‌سازی ترجمه در این محیط نصب/آزموده نشد. شمارش تغییر نکرد: **۹۷ مورد ناقص/جزئی، ۰ Done**؛ T-01 ماتریس staging همچنان اجرا نشده است.


### ادامهٔ AP-03 — API همگام‌سازی فروش و موجودی

`includes/Api/ErpRoutes.php` دو مسیر REST با capability `manage_woocommerce` اضافه می‌کند: `GET /zcws/v1/erp/orders` خروجی صفحه‌بندی‌شدهٔ سفارش‌های تغییرکرده از checkpoint RFC3339 با Woo CRUD می‌دهد؛ `POST /zcws/v1/erp/stock` موجودی مطلق محصول/variation را با product ID یا SKU به‌روزرسانی می‌کند. Batch تا ۱۰۰ مورد است؛ همهٔ ردیف‌ها پیش از اولین ذخیره validate می‌شوند، محصول تکراری یا stock management غیرفعال رد می‌شود و retry همان مقدار absolute دوباره inventory را افزایش نمی‌دهد. در ثبت سفارش/موجودی از postmeta خام استفاده نشده است.

Node **88/88** و Playground **exit code 0**؛ ثبت routeها، منع مهمان، update موجودی با retry، رد duplicate بدون تغییر stock و envelope صفحهٔ سفارش runtime آزموده شد. API ERP vendor-specific، reconciliation/ledger موجودی، احراز هویت/تبادل زنده با ERP و failure recovery بین چند product save هنوز لازم‌اند؛ AP-03 همچنان جزئی است. کل snapshot **۹۷ ناقص، ۰ Done** باقی می‌ماند.


### گسترش AP-03 — همگام‌سازی catalog

مسیر `GET /zcws/v1/erp/products` نیز اضافه شد: فهرست صفحه‌بندی‌شدهٔ کالاهای publish‌شدهٔ تغییرکرده را با SKU، parent/variation، موجودی، قیمت‌های خرده، tax-independent identity، دسته‌بندی و timestamp برمی‌گرداند. نقطهٔ checkpoint برای سفارش و محصول inclusive است تا تغییرهای هم‌ثانیه‌ای حذف نشوند؛ ERP مصرف‌کننده باید با شناسهٔ order/product upsert و duplicate boundary را deduplicate کند. Playground مسیر محصول را در کنار سفارش و stock update آزمود؛ Node **88/88** و Playground **exit code 0**. حذف/انتقال به trash هنوز tombstone ندارد و ERP اختصاصی/reconciliation زنده انجام نشده است؛ این همچنان پیاده‌سازی جزئی است.


### ادامهٔ AP-03 — tombstone حذف محصول برای webhook

افزوده شد `zcws.product_deleted` به registry رویدادهای WooCommerce. انتقال کالا/variation به زباله‌دان و حذف دائمیِ کالای زنده، از native signed webhook action استفاده می‌کند؛ حذف دائمی موردی که قبلاً trash شده دوباره event نمی‌فرستد و در یک request نیز callback تکراری deduplicate می‌شود. payload عمداً فقط `event`, `id`, `product_id`, `deleted` دارد تا تحویل async پس از حذف دائمی به خواندن post/product row متکی نباشد. Integration coverage شامل payload tombstone بدون رکورد وابسته و حذف تکراری trash→permanent است.

Node **89/89** و WordPress Playground **exit code 0** با PHP 8.2؛ این آزمون‌ها فقط اجرای کد و قرارداد محلی را تأیید می‌کنند. ERP vendor-specific mapping/auth, reconciliation, end-to-end webhook delivery/consumer ACK و پذیرش روی staging/ERP واقعی همچنان تأیید نشده‌اند. AP-03 همچنان **جزئی** است؛ شمارش کلی همچنان **۹۷ ناقص/جزئی، ۰ Done/پذیرفته‌شده**. این نتیجه، عبارت قبلیِ «حذف/انتقال به trash هنوز tombstone ندارد» در یادداشت catalog را supersede می‌کند.


### اصلاح دامنهٔ AP-03 طبق توضیح کاربر — گزارش یکپارچهٔ WooCommerce و افزونه

معیار این قابلیت اتصال به ERP بیرونی یا توسعهٔ حسابداری پیشرفته نیست. منبع سفارش/محصول WooCommerce و منبع داده‌های اختصاصی، جدول‌ها و snapshotهای افزونه است؛ خروجی باید گزارش مدیریتی یکپارچه و فایل واقعی `.xlsx` باشد. `includes/Admin/BusinessDataWorkbook.php` یک workbook چندبرگه‌ای می‌سازد: سفارش‌ها، ریزاقلام/metadata، تعدیلات/مرجوعی و اقلام مرجوعی، محصولات و موجودی، مشتریان فروشگاه، کدهای تخفیف، دسته/برچسب/ویژگی و metadataهای CRUD ووکامرس، تنظیمات غیرمحرمانهٔ افزونه، جدول‌های کسب‌وکاری افزونه، snapshot و ریزاقلام/مالیات فاکتور. جدول‌های افزونه به‌صورت sheetهای جداگانه صادر می‌شوند؛ ردیف‌های طولانی به sheet ادامه منتقل می‌شوند تا بی‌صدا بریده نشوند. `XlsxWriter` بدون وابستگی خارجی OOXML می‌سازد و متن‌ها را به‌صورت literal نگه می‌دارد؛ خروجی فقط با capability `manage_woocommerce` و nonce، بدون رمز/توکن، BLOB مدرک و log/محتوای اعلان است. خروجی CSV قبلی حفظ شده است.

Playground **exit code 0** و Node **90/90**؛ runtime، ساخت workbook چندمنبعی محلی، وجود سفارش/کالا/coupon/customer/taxonomy در خروجی، بسته‌بندی ZIP/OOXML، سلول متنیِ شبیه فرمول و انتقال مقدار بزرگ به Long Values sheet آزموده شد. هیچ فایل دادهٔ واقعی فروشگاه یا حجم تولیدی در این محیط وجود نداشت؛ پس بازبینی reconciliation با دادهٔ واقعی و آزمون export در hosting عملیاتی هنوز gate است. این مورد به‌خاطر اجرای تست محلی Done/پذیرفته‌شده اعلام نمی‌شود. این تعریف، یادداشت‌های قدیمی AP-03 دربارهٔ «ERP vendor-specific» را supersede می‌کند؛ routeهای قبلی خارج از معیار این گزارش‌اند.
