# نقشهٔ امکانات ووکامرس و وردپرس — چه چیزی را می‌توانیم بسازیم، چه چیزی را باید بسازیم

سند دوم از تحلیل. هدف: تعیین دقیق «چه چیزی را ووکامرس به ما می‌دهد» و «چه چیزی را باید خودمان بسازیم»، به‌همراه نام دقیق هوک/کلاس/API تا در فاز کدنویسی، حدس و آزمون‌وخطا نداشته باشیم.

مبنای بررسی: ووکامرس نسخهٔ ۱۰٫x/۱۱٫x (سال ۲۰۲۶)، وردپرس ۶٫۵+ (برای هدر `Requires Plugins`)، PHP 8.2/8.3. جایی که نام هوک در نسخهٔ هدف تأیید نشده، با «(تأیید در نسخهٔ هدف)» علامت خورده است.

---

## ۱. لایهٔ زیرساخت افزونه — چه چیزهایی رایگان به دست می‌آوریم

| نیاز | ابزار رسمی | تصمیم |
|---|---|---|
| وابستگی سخت به ووکامرس | هدر `Requires Plugins: woocommerce` (وردپرس ۶٫۵+) + هدرهای `WC requires at least` / `WC tested up to` | استفاده. فعال‌سازی بدون ووکامرس توسط هسته مسدود می‌شود |
| بارگذاری در زمان درست | `woocommerce_loaded` / `woocommerce_init` (نه `plugins_loaded`) | استفاده |
| اعلام سازگاری HPOS | `before_woocommerce_init` → `FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true )` | استفاده اجباری |
| اعلام سازگاری بلوک‌ها | همان کلاس با شناسهٔ `cart_checkout_blocks` | استفاده اجباری |
| ذخیره‌سازی سفارش | `wc_get_order()`, `wc_get_orders()`, `$order->get_meta()/update_meta_data()/save()` | استفاده؛ ممنوعیت مطلق `WP_Query`/`get_post_meta` روی سفارش |
| تشخیص حالت HPOS | `OrderUtil::custom_orders_table_usage_is_enabled()` و `OrderUtil::get_order_admin_screen()` | استفاده برای اسکرین‌های داینامیک |
| مهاجرت دیتابیس | `dbDelta()` + گزینهٔ `zcws_db_version` | استفاده |
| صفحهٔ تنظیمات بومی | کلاس `WC_Settings_Page` + فیلتر `woocommerce_get_settings_pages` | استفاده (نه صفحهٔ سفارشی) |
| منوی مدیریت در پنل ووکامرس | `add_submenu_page( 'woocommerce', ... )` + فیلتر `woocommerce_screen_ids` برای گرفتن استایل/اسکریپت ووکامرس | استفاده |
| ایمیل تراکنشی | ارث‌بری از `WC_Email` + فیلتر `woocommerce_email_classes` + `woocommerce_email_actions` | استفاده |
| قالب‌های قابل بازنویسی | `wc_get_template()`/`wc_get_template_html()` با مسیر `templates/` افزونه (قابل override در `theme/woocommerce/...`) | استفاده |
| زمان‌بندی کارها (یادآوری سررسید) | **Action Scheduler** (همراه ووکامرس) — `as_schedule_single_action` / `as_schedule_recurring_action` | استفاده برای یادآوری اقساط و retry مودیان |
| ابزارهای CLI | WP-CLI (`wp ws price import`) | اختیاری |

**نتیجه:** هیچ‌کدام از اینها را نباید دوباره بنویسیم؛ ۱۰۰٪ قابل استفاده است.

---

## ۲. کاربران، نقش‌ها و احراز هویت

| نیاز (از سند ۱) | آنچه ووکامرس/وردپرس می‌دهد | کافی است؟ | کار ما |
|---|---|---|---|
| نقش مشتری عمده و گروه‌ها | `add_role()` + capability API؛ نقش `customer` ووکامرس | بخشی | ساخت نقش‌های پویا `zcws_group_*` + جدول متادیتای گروه |
| فرم ثبت‌نام اختصاصی | `woocommerce_register_form` (اکشن/فیلتر)، `woocommerce_registration_errors`، `woocommerce_created_customer`، `register_form`/`register_post` وردپرس | بخشی | فیلدهای کسب‌وکار + صفحهٔ مستقل ثبت‌نام عمده با فرم خودمان (nonce + اعتبارسنجی) |
| آپلود مدارک و گردش‌کار تأیید | ❌ هیچ امکانی ندارد | خیر | ساخت کامل: جدول `zcws_applications`، آپلودر امن، صفحهٔ بررسی، وضعیت‌ها، اعلان‌ها |
| ورود/ثبت‌نام/بازیابی رمز | ووکامرس + `wp_signon`, `retrieve_password`، محدودیت تلاش | بله | فقط اتصال؛ OTP با فیلتر `authenticate` |
| OTP پیامکی | ❌ ندارد | خیر | آداپتر درگاه پیامک + جدول توکن + محدودیت نرخ |
| صفحهٔ حساب کاربری | `woocommerce_account_menu_items`، `woocommerce_get_query_vars`، اکشن `woocommerce_account_{endpoint}_endpoint`، `woocommerce_account_dashboard` | بله | افزودن endpointها و رندر محتوا با قالب‌های خودمان |
| کاربر زیرمجموعهٔ شرکت | ❌ ندارد (فقط نقش‌ها) | خیر | متای `_zcws_parent_company` + سقف خرید + بررسی در `woocommerce_check_cart_items` |
| محدودسازی دسترسی کارشناس فروش | `map_meta_cap` / `user_has_cap` | بله (با توسعه) | فیلتر `map_meta_cap` برای `edit_shop_order`/`edit_users` بر اساس `_zcws_rep_id` |

---

## ۳. قیمت‌گذاری — مهم‌ترین و پرریسک‌ترین بخش

| نیاز | ابزار ووکامرس | کافی است؟ | کار ما |
|---|---|---|---|
| قیمت متفاوت برای گروه | فیلترهای CRUD: `woocommerce_product_get_price`, `woocommerce_product_get_regular_price`, `woocommerce_product_get_sale_price`, `woocommerce_product_variation_get_price` | بله | موتور قواعد + محاسبه در همین فیلترها |
| قیمت پله‌ای بر اساس تعداد سبد | `woocommerce_before_calculate_totals` (تغییر قیمت ردیف‌های سبد) | بله | محاسبه در سطح ردیف + اعتبارسنجی بعدی |
| قیمت متغیرها (بدون کش اشتباه) | `woocommerce_variation_prices_price`، `woocommerce_get_variation_prices_hash`، `woocommerce_variation_is_visible` | بله | تزریق قیمت + افزودن group+qty به hash کش |
| نمایش قیمت (کاتالوگ/محصول) | `woocommerce_get_price_html`، `woocommerce_variable_price_html`، `woocommerce_get_price_suffix`، `woocommerce_cart_item_price` | بله | قالب نمایش: «قیمت شما»، جدول پله |
| مخفی‌کردن قیمت | بازگرداندن رشتهٔ خالی از `woocommerce_product_get_price` + فیلتر `woocommerce_is_purchasable` + `woocommerce_get_price_html` | بله | اعمال بر اساس گروه؛ **مهم:** همین فیلترها روی REST/Store API هم اجرا می‌شوند، پس لایهٔ داده امن است |
| پنهان‌کردن محصول | `woocommerce_product_is_visible` (فیلتر ۲ آرگومانی), `woocommerce_product_query` (اکشن), `woocommerce_variation_is_visible` | بله | فیلتر بر اساس گروه |
| فیلد قیمت در صفحهٔ محصول (ساده و متغیر) | `woocommerce_product_data_tabs` + `woocommerce_product_data_panels` + `woocommerce_admin_process_product_object`؛ برای متغیرها `woocommerce_product_after_variable_attributes` (اکشن) و `woocommerce_save_product_variation` | بله | تب «قیمت عمده» با repeater پله‌ها |
| ویرایش گروهی قیمت | `woocommerce_product_bulk_edit_start` / `woocommerce_product_bulk_edit_save` | بله | فیلد گروهی |
| ستون‌ها و فیلتر فهرست محصول | `manage_edit-product_columns`، `manage_product_posts_custom_column`، `restrict_manage_posts` | بله | ستون «قیمت عمده» |
| ایمپورت/اکسپورت CSV محصولات | `woocommerce_product_export_column_names`، `woocommerce_product_importer_...` (تأیید در نسخهٔ هدف) | بخشی | ابزار مستقل CSV قیمت عمده (ساده‌تر و امن‌تر) |
| اعتبار قیمت حراج/کوپن/مالیات | کلاس‌های `WC_Coupon`، `WC_Tax`، `WC_Discounts` | بله | رعایت ترتیب: قیمت گروه → حراج → کوپن → مالیات |
| کش قیمت | `wp_cache`/transient + `woocommerce_product_get_price` | بله | کش در سطح درخواست (static) + پاک‌سازی روی تغییر گروه/قاعده |

**قاعدهٔ طلایی Pricing:** قیمت ذخیره‌شده در محصول هرگز تغییر داده نمی‌شود. همیشه در زمان خواندن محاسبه می‌شود. این کار باعث می‌شود: (۱) قیمت خرده‌فروش سالم بماند، (۲) فاکتورهای قدیمی خراب نشوند، (۳) با انواع قالب و افزونه سازگار باشد.
**استثنا:** هنگام ثبت سفارش، قیمت **snapshot** می‌شود (در متای ردیف سفارش)، همان کاری که ووکامرس هم می‌کند.

### ۳.۱ محصولات متغیر: استفاده از هسته در برابر منطق عمده

ووکامرس هر variation را یک محصول فرزندِ قابل خرید با شناسه، ویژگی، SKU، قیمت، تصویر، وضعیت موجودی و در صورت تنظیم، موجودی مستقل می‌شناسد. بنابراین قیمت و موجودی خرده‌فروشی وارییشن‌ها را دوباره نمی‌سازیم؛ قیمت عمده و قواعد خرید را با `WC_Product_Variation` و شناسهٔ variation توسعه می‌دهیم.

| نیاز عمده‌فروشی برای variation | ابزار/دادهٔ موجود | منطق افزونه |
|---|---|---|
| قیمت خرده، قیمت حراج، SKU، تصویر، شناسهٔ variation | CRUD ووکامرس و `WC_Product_Variation` | حفظ کامل؛ قیمت عمده جدا و بدون نوشتن روی قیمت خرده |
| قیمت عمدهٔ مستقل هر variation | `woocommerce_product_variation_get_price` و CRUD variation؛ فرم مدیریت با `woocommerce_product_after_variable_attributes` / `woocommerce_save_product_variation` | مقدار variation بر مقدار والد مقدم؛ در صورت فعال‌بودن ارث‌بری و خالی‌بودن قیمت اختصاصی، مقدار عمدهٔ والد fallback است |
| قیمت گروه/مشتری و پله‌ها | `variation_id` در قواعد اختصاصی؛ `woocommerce_before_calculate_totals` برای قیمت نهایی سبد | تعداد هر variation جدا شمرده می‌شود؛ قواعد variation دقیق بر fallback والد مقدم‌اند |
| نمایش در انتخاب‌گر | `WC_Product_Variable::get_available_variations()` و `get_variation_prices()`؛ hookهای variation price و hash | پس از انتخاب، قیمت/تصویر/SKU/موجودی همان variation به‌روز شود؛ قیمت قبل از انتخاب فقط بازهٔ مجاز همان کاربر باشد |
| MOQ، max، step و بسته‌بندی | فیلترهای quantity input + اعتبارسنجی سمت سرور | تنظیم variation بر والد مقدم؛ خطا در کلاسیک و Store API یکسان؛ stock ووکامرس آخرین حد است |
| موجودی و backorder | مدیریت stock روی variation یا والد در ووکامرس | مرجع موجودی فقط ووکامرس؛ افزونه variation ناموجود را نپذیرد و موجودی جدید نسازد |
| جدول سفارش سریع variation | SKU و attributeها از دادهٔ variation | نمایش فهرست/جست‌وجو با صفحه‌بندی یا بارگذاری تنبل؛ افزودن بر اساس variation ID و attributes معتبر |
| فاکتور و سفارش | `WC_Order_Item_Product` و متای ردیف سفارش | snapshot شامل parent ID، variation ID، نام ویژگی‌ها، SKU، تعداد، قیمت عمدهٔ واحد، منبع/پله و مالیات باشد |

**سیاست پیشنهادی شمارش:** پیش‌فرض، MOQ و آستانهٔ قیمت پله‌ای برای هر variation جداست؛ خرید ۶۰ قرمز + ۴۰ آبی به‌طور خودکار «۱۰۰ عدد از یک وارییشن» نمی‌شود. برای کالاهای واقعاً قابل‌جایگزینی، مدیر می‌تواند صریحاً «تجمیع مقدار بین وارییشن‌های همین والد» را فعال کند؛ این حالت فقط وقتی مجاز است که قاعدهٔ قیمت مشترک و قابل‌مقایسه داشته باشد. هرگز تجمیع ضمنی انجام نمی‌شود.

**محدودیت عملکرد مهم:** `get_available_variations()` با حالت آرایه برای تعداد زیاد variation پرهزینه است؛ کد مرجع ووکامرس هشدار می‌دهد که برای هر variation داده‌هایی مانند قیمت، HTML موجودی، تصویر و وزن محاسبه می‌شود. بنابراین جدول سفارش عمده نباید همهٔ variationها را یک‌جا بارگذاری کند. همچنین رابط پیش‌فرض انتخاب ویژگی برای بیش از ۳۰ variation می‌تواند استاتیک شود؛ تست تجربهٔ انتخاب و جایگزین جدول/جست‌وجوی سریع لازم است.

منابع رسمی: [راهنمای محصولات متغیر ووکامرس](https://woocommerce.com/document/variable-product/) · [مرجع کد `WC_Product_Variable`](https://woocommerce.github.io/code-reference/classes/WC-Product-Variable.html)

---

## ۴. سبد، چک‌اوت و اعتبارسنجی (دو مسیر موازی)

این جدول کلید سازگاری با قالب‌ها و با بلوک‌های ووکامرس است:

| نیاز | مسیر کلاسیک (شورت‌کد) | مسیر بلوک / Store API | تصمیم |
|---|---|---|---|
| اعتبارسنجی MOQ/مبلغ کل | `woocommerce_check_cart_items` + `woocommerce_after_checkout_validation` | `woocommerce_store_api_cart_errors` (اکشن، `$errors, $cart`) | یک کلاس `Rule_Validator` که از هر دو هوک صدا زده می‌شود؛ منطق یکتا |
| حداقل/گام تعداد در ورودی | `woocommerce_quantity_input_args`، `woocommerce_quantity_input_min/max/step` | همان (بلوک افزودن به سبد ووکامرس از همین‌ها استفاده می‌کند) | استفاده |
| اعتبارسنجی افزودن به سبد | `woocommerce_add_to_cart_validation` (۵ آرگومان) | `woocommerce_store_api_add_to_cart_data` + همان اعتبارسنجی | استفاده |
| فیلدهای اضافی چک‌اوت | `woocommerce_checkout_fields` | `woocommerce_register_additional_checkout_field()` (تکست/سلکت/چک‌باکس/تاریخ) — از `woocommerce_init` | **هر دو را ثبت کنیم**؛ این تنها راه رسمی سازگاری است |
| ذخیرهٔ فیلد در سفارش | `woocommerce_checkout_create_order` / `woocommerce_checkout_update_order_meta` | خودکار در متای سفارش + `woocommerce_set_additional_field_value` (تأیید) | استفاده |
| هزینه/تخفیف سبد | `woocommerce_cart_calculate_fees` | همان (Store API از WC_Cart استفاده می‌کند) | استفاده؛ پرچم `taxable`/`tax_class` رعایت شود |
| محدودسازی روش پرداخت | `woocommerce_available_payment_gateways` | همان | استفاده |
| اطلاعات ردیف سفارش | `woocommerce_checkout_create_order_line_item` | همان | استفاده برای snapshot قیمت/گروه |
| نمایش در بلوک‌ها (برچسب/پیام) | — | JS: `registerCheckoutFilters` از `@woocommerce/blocks-checkout` | فقط برای متن‌ها؛ منطق در PHP بماند |
| افزودن دادهٔ اختصاصی به پاسخ Store API | — | `woocommerce_store_api_register_endpoint_data` | برای نمایش ماندهٔ اعتبار/گروه در بلوک |
| صفحهٔ سفارش سریع | شورت‌کد/قالب خودمان | بلوک اختصاصی (نیاز به build با `@wordpress/scripts`) | فاز ۲: اول شورت‌کد، بعد بلوک |

> نکتهٔ عملی: بلوک چک‌اوت **از `woocommerce_checkout_fields` استفاده نمی‌کند**. اگر فقط با آن کار کنیم، فیلدهای ما در نیمی از فروشگاه‌های امروزی دیده نمی‌شوند. این بزرگ‌ترین تلهٔ سازگاری است و در طراحی ما با ثبت دوگانه حل شده.

---

## ۵. سفارش، فاکتور، مالیات

| نیاز | ابزار | کافی است؟ | کار ما |
|---|---|---|---|
| CRUD سفارش سازگار HPOS | `WC_Order`, `WC_Order_Item_Product`, `wc_get_orders`, `WC_Order_Query` | بله | استفادهٔ کامل |
| متاباکس/ستون سفارش | `woocommerce_admin_order_data_after_billing_address`، `woocommerce_admin_order_data_after_order_details`؛ برای لیست: `manage_{$screen}_columns` + `manage_{$screen}_custom_column` که `$screen` با `OrderUtil::get_order_admin_screen()` گرفته شود | بله | استفاده با اسکرین داینامیک (نه `shop_order` هاردکد) |
| جست‌وجو در سفارش‌ها | `woocommerce_shop_order_search_fields` | بله | افزودن شناسهٔ ملی/کد اقتصادی |
| وضعیت سفارش جدید (مثلاً «در انتظار تأیید اعتبار») | `wc_get_order_statuses`/`woocommerce_order_statuses` (فیلتر) + `woocommerce_register_shop_order_post_statuses` (اکشن) | بله | فقط در صورت نیاز؛ ترجیح: استفاده از وضعیت‌های موجود + متای وضعیت داخلی |
| رویداد تغییر وضعیت | `woocommerce_order_status_changed` | بله | برای دفتر حساب و ایمیل |
| مالیات | کلاس `WC_Tax`، کلاس مالیاتی محصول (`get_tax_class`)، `WC_Customer::set_is_vat_exempt()` / `get_is_vat_exempt()` | بله | فیلتر/تنظیم کلاس مالیاتی بر اساس گروه + معافیت |
| شمارهٔ سفارش | `woocommerce_order_number` (فیلتر) + `WC_Order::get_order_number()` | بله | شمارهٔ سفارش از ووکامرس؛ شمارهٔ فاکتور جدا (پایین) |
| فاکتور PDF | ❌ ووکامرس مولد PDF ندارد | خیر | کتابخانه PDF (mPDF/DOMPDF) + تولید از قالب HTML خودمان با `wc_get_template`؛ یکپارچگی اختیاری با افزونهٔ فاکتور موجود |
| شماره‌گذاری فاکتور | ❌ ندارد (فقط شمارهٔ سفارش) | خیر | جدول `zcws_invoice_numbers` + قفل تراکنشی (`SELECT ... FOR UPDATE` یا `wc_get_lock`) |
| انواع سند (پیش‌فاکتور/غیررسمی/رسمی) | ❌ | خیر | جدول `zcws_invoices` با نوع و وضعیت (draft/issued/registered/cancelled) |
| چاپ/ارسال فاکتور در ایمیل | `WC_Email` + `woocommerce_email_attachments` | بله | پیوست PDF |
| فاکتور رسمی/مودیان | ❌ | خیر | آداپتر مستقل با اینترفیس `TaxAuthority` (فاز ۳) + صف retry با Action Scheduler |
| خلاصهٔ تسویه روی فاکتور | ❌ | خیر | داده از `zcws_payment_installments` در قالب فاکتور |

---

## ۶. پرداخت، تسویه چندمرحله‌ای، اعتبار، دفتر حساب

این بخش مهم‌ترین تحلیل جدید است. ووکامرس برای «پرداخت تک‌مرحله‌ای» ساخته شده؛ تسویه چندمرحله‌ای ترکیبی (نقدی + اعتباری + چکی) را باید روی آن لایه‌گذاری کنیم.

### ۶.۱ چه چیزی ووکامرس می‌دهد (قابل استفادهٔ مستقیم)

| نیاز | ابزار دقیق | نکتهٔ فنی |
|---|---|---|
| درگاه «خرید نسیه» | کلاس `WC_Payment_Gateway` + `is_available()` + `process_payment()` | درگاه در «پرداخت‌ها» دیده می‌شود؛ `process_payment` سفارش را `on-hold` می‌کند و `result => success` برمی‌گرداند |
| تکمیل پرداخت سفارش | `$order->payment_complete()` → اکشن‌های `woocommerce_order_payment_complete` و `woocommerce_order_set_paid` | فقط وقتی صدا زده می‌شود که تسویه **کامل** شده باشد (گیت تحقق) |
| وضعیت «در انتظار پرداخت» | وضعیت `on-hold` / `pending` | سفارش تسویه‌نشده در `on-hold` می‌ماند تا تسویه کامل شود |
| پرداخت سفارش موجود (پرداخت قسط) | endpoint پرداخت سفارش ووکامرس (`woocommerce_pay_for_order` / `order-pay`) + `$order->get_checkout_payment_url()` | برای «پرداخت قسط» از My Account؛ قسط آنلاین از همین مسیر پرداخت می‌شود |
| مبلغ پرداخت‌شده | `$order->get_total_paid()` و `$order->get_total_refunded()` | ⚠️ اینها دفتر اقساط نیستند؛ فقط بازتاب پرداخت/بازپرداخت ووکامرس‌اند. منبع حقیقت اقساط، جدول خود ماست |
| بازپرداخت | `wc_create_refund` / `wc_refund_payment` | برای برگشت وجه؛ در نسیه، سند اصلاحی در دفتر ثبت می‌شود |
| ثبت پرداخت دستی/قسط | `$order->payment_complete()` فقط برای تسویهٔ کامل سفارش؛ پرداخت یک قسط نباید سفارش اصلی را paid کند | سرویس Settlement پرداخت قسط را idempotent ثبت می‌کند، Ledger را به‌روز می‌کند و فقط پس از تحقق سیاست تسویه، `payment_complete()` را برای سفارش اصلی فراخوانی می‌کند؛ برای پرداخت آنلاین قسط، از آداپتر مبلغ جزئی یا سفارش پرداخت جداگانهٔ مرتبط استفاده می‌شود |
| هزینه/تخفیف سبد | `woocommerce_cart_calculate_fees` | برای تخفیف/هزینهٔ واقعی استفاده شود؛ **نه** برای تبدیل مبلغ کامل سفارش به مبلغ یک قسط، چون total سفارش/مالیات/فاکتور را مخدوش می‌کند |
| محدودسازی درگاه بر اساس گروه | `woocommerce_available_payment_gateways` | استفاده برای نمایش/عدم نمایش درگاه نسیه و روش‌های تسویه |
| یادآوری سررسید | **Action Scheduler** (`as_schedule_single_action`) | زمان‌بندی یادآوری T-3، روز سررسید، معوق +7/+14 برای هر قسط |
| رویداد تغییر وضعیت | `woocommerce_order_status_changed` | همگام‌سازی وضعیت پرداخت با وضعیت تحقق |
| ثبت زمان‌بندی در سفارش | `woocommerce_checkout_create_order` + متای سفارش | ذخیرهٔ خلاصهٔ تسویه (`_zcws_settlement`) در سفارش |

### ۶.۲ چه چیزی ووکامرس ندارد (باید بسازیم)

| نیاز | وضعیت در ووکامرس | راه‌حل ما |
|---|---|---|
| زمان‌بندی اقساط (چند قسط با روش و سررسید متفاوت) | ❌ هیچ موجودیتی ندارد | جدول `zcws_payment_installments` + سرویس `Settlement` |
| چند روش پرداخت در یک سفارش (ترکیبی) | ❌ هر سفارش دقیقاً یک `payment_method` دارد | روش هر قسط جدا ذخیره می‌شود؛ `payment_method` سفارش = روش قسط اول/اصلی |
| وضعیت «پرداخت جزئی» | ❌ وضعیت `partially-paid` در هسته نیست | وضعیت پرداخت در متای سفارش (`_zcws_payment_state`) + نمایش در پنل؛ وضعیت تحقق ووکامرس دست نمی‌خورد |
| چرخهٔ حیات چک (در جریان/وصول/برگشتی) | ❌ | جدول `zcws_cheques` با گردش‌کار وضعیت + اتصال به قسط |
| دفتر حساب و ماندهٔ مشتری | ❌ | جدول `zcws_ledger` (بدهکار/بستانکار) — منبع حقیقت مانده |
| صورتحساب/گردش حساب مشتری | ❌ | گزارش از `zcws_ledger` + خروجی PDF/Excel |
| یادآوری و قفل بدهکار | ❌ | Action Scheduler + صف اعلان + سیاست قفل در `woocommerce_available_payment_gateways` و اعتبارسنجی سبد |
| پرداخت آنلاین فقط بخشی از سفارش | ❌ قرارداد عمومی درگاه ووکامرس مبلغ جزئی را تضمین نمی‌کند؛ درگاه معمولاً از total سفارش استفاده می‌کند | آداپتر پرداخت قسط: درگاه با پشتیبانی واقعی مبلغ جزئی یا ایجاد سفارش پرداخت جداگانهٔ مرتبط با قسط؛ سفارش اصلی با مبلغ کامل باقی می‌ماند. پرداخت جزئی باید از نظر callback، بازپرداخت، idempotency و تطبیق تراکنش آزموده شود |

> **قاعدهٔ طلایی تسویه:** ووکامرس فقط «تسویهٔ کامل» را برای سفارش اصلی می‌بیند (`payment_complete`). همهٔ جزئیات اقساط، چک‌ها و مانده در جداول خود ماست و وضعیت پرداخت سفارش از آنها محاسبه می‌شود. پرداخت یک قسط هرگز نباید سفارش اصلی را paid کند. درگاه‌های عمومی معمولاً total سفارش را می‌گیرند؛ بنابراین پشتیبانی پرداخت جزئی باید در آداپتر هر درگاه تأیید شود، و در غیر این صورت از سفارش پرداخت جداگانه و پیوندخورده استفاده شود. ایجاد fee منفی برای دستکاری مبلغ شارژ ممنوع است.

---

## ۷. کاتالوگ، جست‌وجو، SEO

| نیاز | ابزار | کافی است؟ |
|---|---|---|
| پنهان‌سازی محصول از گروه‌ها | `woocommerce_product_is_visible` + `woocommerce_product_query` | بله |
| جلوگیری از نشت در نقشهٔ سایت/RSS | `wp_sitemaps_posts_query_args`، `pre_get_posts` | بله (با احتیاط و تست) |
| صفحه‌بندی و فیلترهای AJAX قالب‌ها | همان هوک‌های کوئری ووکامرس | بله |
| نمایش سریع قیمت در فهرست | `woocommerce_get_price_html` | بله |
| مدل فروشگاه ترکیبی/خالص | همان فیلترهای بالا + تنظیم سراسری | بله |

---

## ۸. مدیریت، گزارش، افزونه‌های جانبی

| نیاز | ابزار | کافی است؟ | کار ما |
|---|---|---|---|
| صفحهٔ مدیریت | `add_submenu_page` زیر `woocommerce` + `WP_List_Table` | بله | استفاده (استایل بومی ووکامرس) |
| گزارش‌ها | `wc_get_orders` + `WC_Order_Query` + خروجی CSV؛ کلاس `WC_Report` قدیمی‌تر است | بله | گزارش‌های خودمان با جدول بومی؛ Analytics ووکامرس با JS توسعه می‌یابد (پرهیز) |
| دسترسی/مجوز | `current_user_can('manage_woocommerce')`، `manage_woocommerce` برای مدیر فروش | بله | استفاده |
| REST | `register_rest_route` + `wc_rest_check_manager_permissions` | بله | فقط برای داده‌های خودمان؛ محصول/سفارش از REST خود ووکامرس |
| وبهوک | `woocommerce_webhook_topics`، `woocommerce_valid_webhook_events` | بله | افزودن رویدادهای ما |
| آپلود فایل امن | `wp_handle_upload` + `.htaccess`/`index.php` + محافظت با `readfile` در endpoint مجاز | بله | استفاده |
| WPML | `wpml_object_id`, `wpml_register_single_string` | بله | استفاده |
| حالت بازار ایران/عمومی | فیلترهای ارز ووکامرس (`woocommerce_currencies`, `woocommerce_currency_symbol`) + تنظیمات مالیات | بخشی | آداپتر ایران: تومان، کد ملی، شناسه کالا، مودیان |

---

## ۹. شکاف‌ها: چیزهایی که باید ۱۰۰٪ از صفر بنویسیم

1. موتور قواعد قیمت (اولویت، ترکیب، پله، اختصاصی، درصدی) — قلب افزونه
2. موتور قواعد سفارش/محدودیت (MOQ, step, سقف، محدودیت پرداخت)
3. فرم و گردش‌کار احراز هویت کسب‌وکار + آپلود امن مدارک + اعتبارسنجی شناسه ملی
4. **موتور تسویه چندمرحله‌ای:** زمان‌بندی اقساط، تسویه ترکیبی، وضعیت پرداخت سفارش، چرخهٔ حیات چک، یادآوری سررسید، صورتحساب/گردش حساب
5. درخواست استعلام قیمت (RFQ) + پیشنهاد + تبدیل به سفارش
6. سفارش سریع + آپلود CSV + سفارش مجدد
7. فاکتور PDF + شماره‌گذاری + انواع سند (پیش‌فاکتور/غیررسمی/رسمی) + (آداپتر مودیان)
8. حساب شرکتی چندکاربره
9. پیامک/OTP و صف اعلان
10. گزارش‌های تخصصی عمده و کنترل دسترسی کارشناس فروش
11. ابزار ایمپورت/اکسپورت قیمت عمده
12. آداپتر بازار ایران (تومان، کد ملی، شناسه کالا، نگاشت درگاه‌های ایرانی)

---

## ۱۰. جمع‌بندی: ماتریس «بسازیم یا استفاده کنیم»

| حوزه | پوشش با ووکامرس/وردپرس | حجم کار ما |
|---|---|---|
| زیرساخت، DB سفارش، ایمیل، تنظیمات، مالیات، زمان‌بندی کارها | ۹۵٪ | کم |
| نقش‌ها و حساب کاربری | ۷۵٪ | کم-متوسط |
| قیمت‌گذاری | ۴۰٪ (ابزار هوک هست، منطق نیست) | زیاد |
| قواعد سفارش/مقدار | ۳۰٪ | متوسط |
| احراز هویت کسب‌وکار | ۱۰٪ | متوسط-زیاد |
| فاکتور و مالیات رسمی | ۳۵٪ (مالیات بله، فاکتور خیر) | زیاد |
| تسویه چندمرحله‌ای/اعتبار/چک | ۱۵٪ (درگاه و وضعیت بله، اقساط و دفتر خیر) | زیاد |
| استعلام/سفارش سریع | ۱۵٪ | متوسط |
| گزارش و پنل | ۶۰٪ | متوسط |
| مدل فروشگاه ترکیبی/خالص و بازار ایران/عمومی | ۷۰٪ (نقش و فیلتر هست، آداپتر نیست) | کم-متوسط |

**جمع‌بندی:** می‌توانیم ۱۰۰٪ نیازها را پوشش دهیم، اما حدود ۴۵٪ کد از صفر نوشته می‌شود؛ بنابراین اولویت‌بندی فازها (سند ۰۳) اهمیت دارد.
