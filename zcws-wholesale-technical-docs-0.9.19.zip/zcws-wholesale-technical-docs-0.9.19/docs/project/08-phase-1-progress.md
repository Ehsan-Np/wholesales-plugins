# پیشرفت فاز ۱ — هسته و MVP عمده‌فروشی

> به‌روزرسانی ۱۱ نوامبر ۲۰۲۶: اجرای Playground برای تنظیمات، گروه/درخواست، variation CRUD و bulk، cache generation/transient، migration، کنترل applicant، قواعد classic/Store API و WooCommerce order CRUD موفق شد. تفصیل ۲۰ شناسهٔ انتخاب‌شده و شکاف‌های مانده در `09-stage-20-implementation.md` است. این اجرا هیچ شناسه‌ای را Done نمی‌کند.

**وضعیت: در حال انجام؛ فاز ۱ کامل/قابل انتشار نیست.** فاز ۱ شامل ۲۶ شناسهٔ backlog است؛ این یادداشت فقط اولین بخش زیرساخت را ثبت می‌کند.

## کدنویسی انجام‌شده در شروع فاز

- `includes/Modules/ModuleRegistry.php`: registry ماژول‌ها، ترجیحات پیش‌فرض، sanitizer، وابستگی و فعال‌سازی مؤثر.
- `includes/Plugin.php`: boot ماژول‌های فعلی به‌صورت شرطی؛ تنظیمات همواره در دسترس می‌ماند.
- `includes/Admin/SettingsPage.php` و `assets/css/admin.css`: کنترل responsive روشن/خاموش ماژول‌های موجود، با whitelist و escaping.
- `includes/Database/Schema.php`: مهاجرت dbDelta برای جداول گروه، درخواست/فایل/رویداد، قیمت/tiers، مشتری، ledger، اقساط، چک، quote، invoice، notification و logs؛ دادهٔ قبلی application حفظ می‌شود.
- `includes/Installer.php` و `uninstall.php`: نصب/ارتقای schema با نسخهٔ افزونه و پاک‌سازی whitelist جداول فقط در صورت انتخاب صریح حذف داده.
- `includes/Support/Cache.php`: request/object cache با generation invalidation و hookهای محصول/variation meta، قیمت، taxonomy، تنظیمات افزونه و user meta گروه/approval/status؛ hash قیمت variation و کلید resolver نیز نسل کش/نقش گروه را لحاظ می‌کنند.
- `includes/Support/Logger.php`: لاگ WooCommerce + جدول افزونه برای warning/error و redaction کلیدهای PII/secret.
- `includes/Pricing/PriceResolver.php` و `includes/Onboarding/Applications.php`: اتصال اولیهٔ cache قیمت و لاگ خطای ثبت درخواست.
- `includes/Groups/GroupRepository.php` و `includes/Admin/GroupsPage.php`: ساخت گروه نقش‌محور، ایجاد role با capabilities مشتری، مدیریت گروه، انتساب/تغییر/لغو گروه از پروفایل کاربر؛ خطا/تغییر انتساب در logger ثبت و تغییر group settings کش قیمت را باطل می‌کند.
- `includes/Onboarding/ApplicationEventsRepository.php`: ثبت رویدادهای ارسال و تغییر وضعیت و نمایش timeline در جدول مدیر؛ privacy eraser رویدادها را هم حذف می‌کند.
- `includes/Onboarding/ApplicationEmails.php` و کلاس‌های ApplicationEmail/Received/Submitted/Reviewed به‌همراه `templates/emails/`: سه ایمیل transactional در WooCommerce > Settings > Emails، قالب HTML/plain قابل override در پوسته و لاگ خطای ارسال.
- `includes/Onboarding/PurchaseAccess.php`: متقاضی pending/needs_info در صفحهٔ محصول، add-to-cart کلاسیک و Store API، سبد و checkout مسدود؛ قیمت‌فیلترها و purchasability برای این حساب‌ها نیز محدود شده است. ردشده در مدل ترکیبی می‌تواند خرید خرده داشته باشد.
- `includes/Pricing/TierPricing.php`: snapshot ردیف سفارش به‌جای نقش نشست مدیر، کاربر متصل به خود سفارش را ارزیابی می‌کند و group role، source، قیمت واحد، parent/variation ID، SKU و attributes را ذخیره می‌کند؛ تست مستقل با stub ووکامرس و سفارش عمده/خرده افزوده شد.
- `includes/Cart/CartRules.php`: اعتبارسنجی واحد قواعد مقدار در add-to-cart کلاسیک و Store API علاوه بر اعتبارسنجی سبد، با RouteException برای Store API؛ تعداد بسته نیز برای محصول/variation با fallback والد اعمال و با گام ترکیب می‌شود.
- `includes/Frontend/TierTable.php` و `assets/js/frontend-tiers.js`: جدول پله‌ها اکنون راهنمای زندهٔ تعداد باقی‌مانده تا پلهٔ بعد را برای محصول ساده/متغیر نمایش می‌دهد.
- `includes/Product/ProductFields.php`، `BulkVariationEditor.php`، `PriceResolver.php` و `assets/js/admin-variation-bulk.js`: تب محصول و bulk actionهای variation برای قیمت/قواعد مقدار، tier و تاریخ فروش ویژه؛ تاریخ‌ها در client/server اعتبارسنجی می‌شوند، پاک‌سازی پشتیبانی می‌شود، بازهٔ نامرتب ذخیره نمی‌شود و resolver نیز متای تاریخ نامعتبر/نامرتب را برای فعال‌کردن sale نمی‌پذیرد. در ۱۱ نوامبر، ذخیرهٔ متا با Woo CRUD و bulk edit قیمت/تاریخ/مقدار/tier در Playground اجرا شد؛ رندر کامل صفحهٔ مدیر و هر محصول/قالب واقعی هنوز آزمون acceptance می‌خواهد.
- `includes/Admin/WooSettingsPage.php` و `SettingsPage.php`: کلاس تب تنظیمات با API رسمی `WC_Settings_Page` اضافه شد؛ فرم قدیمی به فرم استاندارد WooCommerce منتقل شده، URL قدیمی هدایت می‌شود، همهٔ ماژول‌های خاموش‌نشده با marker قابل ذخیره‌اند و CSS/JS به تب جدید محدود شده است. ثبت native tab و persistence مستقیم callback در Playground موفق شد؛ رندر UI کامل و nonce از درخواست admin واقعی هنوز آزمون نشده.
- `zcws-wholesale.php`: bootstrap اکنون از `plugins_loaded` فقط برای بارگذاری ترجمه و زمان‌بندی استفاده می‌کند و boot سرویس‌ها را تا `woocommerce_init` عقب می‌اندازد؛ نبود WooCommerce پیام مدیریتی می‌دهد.
- `includes/Installer.php`: در ارتقا، نقش/وضعیت آخرین درخواست کاربران موجود به نشانگر applicant منتقل می‌شود تا درخواست‌های در انتظار قبلی نیز مشمول کنترل خرید شوند.

ماژول‌های فعلی: pricing، quantity_rules (وابسته به pricing)، customer_groups، onboarding (وابسته به customer_groups)، storefront_tools (وابسته به pricing)، privacy. غیرفعال‌کردن ماژول داده را پاک نمی‌کند. ماژول‌های هنوز پیاده‌سازی‌نشده عمداً به‌عنوان «قابل‌فعال» نمایش داده نمی‌شوند.

## بررسی ایستای فعلی

- همهٔ ۵۱ فایل PHP با grammar هدف PHP 8.2 توسط `php-parser` و نیز با `php-wasm-cli -l` (runtime WASM نسخهٔ PHP 8.5.12) بدون خطای parse شدند؛ PHP CLI بومی در محیط نصب نیست.
- `node --check` همهٔ JSها موفق؛ `node --test tests/admin-contracts.test.js`: ۸ آزمون موفق، شامل mock ورودی‌های bulk، bootstrap/settings و قرارداد snapshot.
- `php-wasm-cli -f tests/bulk-variation-editor.test.php`: validatorهای تاریخ/تعداد/بازه و sanitizer/dependencyهای ModuleRegistry موفق؛ `price-resolver.test.php`: ۲۳ سناریوی resolver موفق؛ `order-snapshot.test.php`: snapshot مسیر variation عمده، محصول سادهٔ عمده و ردیف خرده با stub ووکامرس موفق.
- بررسی wiring برای boot روی `woocommerce_init`، تب `WC_Settings_Page`، ذخیره‌سازی سفارشی، URL سازگاری عقب‌رو و enqueue CSS/JS موفق.
- WordPress/WooCommerce runtime اکنون از طریق Playground اجرا شده است (WP 7.1.4/WC 11.3.0/PHP 8.2)؛ integration smoke برای تب تنظیمات/ذخیره، product/variation CRUD، callback bulk، migration، cache، چند مسیر درخواست، قواعد classic/Store API و order CRUD موفق است. این جای staging ماتریس‌دار یا تأیید واقعی HPOS/Blocks را نمی‌گیرد.

## هنوز باز در فاز ۱

تطبیق اولیهٔ شناسه‌های همین فاز با برنامهٔ ۰۷ و ماتریس ۹۷تایی (پیش از اجرای Playground): ۱۹ مورد جزئی، ۶ مورد دارای کد ولی runtime-test نشده (P-01, P-03, P-12, P-13, R-01, R-06) و C-03 هنوز اعلام/آزمون سازگاری ندارد. این طبقه‌بندی برای مواردی که در مرحلهٔ ۲۰تایی دوباره آزموده شدند snapshot قدیمی است؛ هیچ شناسه‌ای به‌دلیل smoke test به Done ارتقا پیدا نکرده است.

طبق snapshot پیش از اجرای Playground: C-01 registry اولیه دارد و نیازمند مرزبندی کامل/تست است؛ C-02 schema شانزده جدول تعریف شده ولی dbDelta روی WP واقعی اجرا نشده؛ C-03 اعلام compatibility باید بعد از بازبینی و runtime test واقعی انجام شود؛ C-04 اکنون تب native مبتنی بر WC_Settings_Page دارد اما ذخیره/نمایش آن روی WooCommerce واقعی باید تأیید شود؛ C-06 logger/cache شروع شده و نیازمند مصرف در تمام سرویس‌ها، invalidation audit و تست backend است.

به‌روزرسانی ۱۱ نوامبر ۲۰۲۶: C-02 مسیر `maybe_upgrade()` روی Playground اجرا و وجود/حفظ دادهٔ applications و BLOB فایل بعد از dbDelta بررسی شد؛ C-04 تب و persistence callback بررسی شد؛ C-06 transient fallback و invalidation نسل cache بررسی شد. این‌ها صرفاً زیرمعیارهای اجرایی‌اند و ادعای Done نیستند. CRUD گروه و انتساب نقش پایه اضافه شده، اما تنظیمات اختصاصی گروه در pricing/rules، G02 audit/گزارش کامل و migration roleهای موجود باقی است. O03 اکنون event trail و جریان پایهٔ needs_info با note اجباری، prefill فیلدهای متنی و ثبت درخواست تازه دارد؛ حفظ مدارک قبلی/مقایسهٔ نسخه‌ها و آزمون end-to-end runtime باقی است. O04 اکنون سه کلاس Woo_Email برای رسید مدیر، تأیید دریافت متقاضی و نتیجهٔ بررسی دارد؛ تنظیم گیرنده/موضوع/عنوان، قالب HTML/plain قابل override و گزارش خطای ارسال فراهم شده و اعلان‌ها از hookهای lifecycle فراخوانی می‌شوند. فعال‌سازی emailer، ارسال واقعی، locale و قالب override در runtime تست نشده است. resolver/rule tests و validation کامل Cart/Store API هم باقی‌اند. بنابراین این پیشرفت هیچ‌یک از ۲۶ شناسه را به‌تنهایی «Done» نمی‌کند.


## ادامهٔ مرتب‌شدهٔ فاز ۱

- طبق ماتریس ۹۷ مورد، C-03 اکنون declarationهای FeaturesUtil برای HPOS و Cart/Checkout Blocks را در `before_woocommerce_init` دارد. این صرفاً کدنویسی اعلام است؛ تا آزمون فعال HPOS و رندر checkout block، compatibility/ID کامل نیست.
- تست Node اکنون ۱۳/۱۳ است و Playground integration exit code 0 دارد (در یک اجرای تازه با پیام عمومی unexpected output هنگام فعال‌سازی خود WooCommerce و هشدار سازگاری نسخهٔ Node/npm ابزار Playground). آزمون روی HPOS فعال اجرا نشده است.
- audit شمارشی ۲۶ شناسهٔ فاز ۱: ۲۶ جزئی، ۰ پایهٔ مجزا، ۰ بدون کد (براساس کد فعلی و زیرمعیارهای runtime؛ هیچ‌کدام Done نیستند)؛ هیچ‌کدام Done نیستند. برای P-01/P-03/P-12/P-13/R-01/R-06 اکنون زیرمعیارهای integration اجرا شده‌اند، اما معیارهای پذیرش کاملشان همچنان باز است.

- C-05 تقویت شد: صفحهٔ فرود فروش عمده زیر WooCommerce با کنترل capability و لینک به تنظیمات/گروه‌ها/درخواست‌ها و شمارش‌های پایه اضافه شده است؛ منوی زنده در staging هنوز باید مشاهده شود.
- آخرین تست Node: ۴۰/۴۰ (۲۶ قرارداد برای شناسه‌های فاز ۱)؛ Playground integration روی WP 7.1.4 / WC 11.3.0 / PHP 8.2 با exit code 0. این اجرا FeaturesUtil declarationهای HPOS و Blocks را از API رسمی WooCommerce assert می‌کند، ولی فعال‌سازی HPOS و رندر واقعی Checkout Block را انجام نمی‌دهد.

- `tests/phase1-feature-contracts.test.js` افزوده شد: برای همهٔ ۲۶ شناسهٔ فاز ۱ قراردادهای wiring/security/CRUD/Classic-Store API تعریف می‌کند؛ این‌ها assertionهای ساختاری‌اند و به‌تنهایی معیار runtime acceptance نیستند. Node suite اکنون ۴۰/۴۰ است.
- تکمیل کد در این نوبت: C-03 declaration رسمی و assertion runtime برای ثبت featureها؛ C-05 داشبورد capability-protected و assertion ثبت submenu؛ C-06/G-02 audit log پایدار با redaction و ثبت تغییر گروه، همراه integration assertion DB. این patch هنوز ۲۶ مورد را Done نمی‌کند.

## یادداشت ادامهٔ کار در فاز ۲ — ۱۱ نوامبر ۲۰۲۶

کدنویسی فراتر از هستهٔ فاز ۱ به قواعد تجاری/My Account پیش رفت؛ در یک بسته، ۲۰ شناسهٔ backlog با تغییر معنادار کد پیشرفت داده شدند. ۱۴ شناسهٔ تازه از «بدون کد مستند» به «جزئی» رفتند و ۶ شناسهٔ ازقبل جزئی زیرمعیارهای جدید گرفتند. شمارش رسمی در snapshot آن بسته ۵۱ جزئی، ۴۶ مشاهده‌نشده، ۰ Done بود؛ بستهٔ بعدی در ادامهٔ سند آمده است. تست Node ۴۹/۴۹ و Playground integration روی WP 7.1.4/WC 11.3.0/PHP 8.2 exit code 0؛ شواهد/محدودیت‌ها در `06-backlog-code-comparison.md` و `tests/manual-test-plan.md` ثبت شده‌اند. این پیشرفت، تأیید کامل فاز ۱ یا آمادگی انتشار نیست.

## Snapshot ادامهٔ فاز ۲ — صورتحساب/اعتبار/Quote (۱۱ نوامبر ۲۰۲۶)

بستهٔ جاری ۲۰ شناسهٔ یکتا را پیش برد: I-01/I-07/I-09/I-10/AD-08/N-03/AP-01/AC-01/C-16/R-05/Q-01/Q-02/CR-01/CR-02/CR-11/AD-07/AC-03/AD-04/N-01/N-02. ۱۸ مورد تازه جزئی شدند؛ AC-01/N-01 قبلاً جزئی بودند و گسترش یافتند. P-08 هم قرارداد تاریخ‌دار گرفت. Workbook: ۶۹ جزئی، ۲۸ مشاهده‌نشده، ۰ Done. Node ۶۱/۶۱؛ Playground exit code صفر (WP 7.1.4/WC 11.3.0/PHP 8.2). محدودیت‌های مالی/قالب/HPOS و پرداختی که در `06-backlog-code-comparison.md` آمده پابرجاست؛ این snapshot آمادگی انتشار را نشان نمی‌دهد.
