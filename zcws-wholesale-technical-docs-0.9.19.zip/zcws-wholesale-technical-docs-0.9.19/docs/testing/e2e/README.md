# Theme × checkout staging smoke matrix (T-01)

This is a browser smoke runner, not a substitute for full manual acceptance, accessibility review, HPOS/Legacy parity, payment processing, or visual regression. It does not install or activate themes. Prepare separate disposable WooCommerce staging URLs with the indicated active theme and checkout surface, seed a published product and an approved wholesale account, and use no production credentials or customer data.

## Matrix coverage

The runner requires all ten pairs:

- Themes: Storefront, Astra, Blocksy, Flatsome, Woodmart.
- Checkout: classic shortcode and WooCommerce Checkout Block.

A theme may need a distinct staging site per checkout mode. Premium themes/page builders must be installed and licensed by the site owner. Set a custom `themeFingerprint` if the active theme does not emit the default `wp-theme-{slug}` body class.

## Configure locally

1. Install Playwright locally (do not commit credentials):
   `npm install --no-save playwright && npx playwright install chromium`
2. Copy `theme-checkout-targets.example.json` to `theme-checkout-targets.json` and enter disposable staging URLs plus an approved test wholesale account for each pair. `theme-checkout-targets.json` is intentionally git-ignored by convention; never place secrets in a committed file.
3. Run from the plugin root:
   `node tests/e2e/theme-checkout-matrix.mjs`
   Or set `ZCWS_THEME_MATRIX_TARGETS=/secure/path/targets.json`.

The runner checks the expected theme fingerprint, product and price markup for guest and wholesale sessions, login controls, checkout surface markup, HTTP response failures, PHP fatal/warning text, and uncaught browser exceptions. It never places an order or submits payment. It writes a JSON summary to stdout and exits nonzero on any failure.

## Not yet accepted

No Astra, Blocksy, Flatsome, Woodmart, Elementor, or separate Checkout Block staging target is configured or run in this workspace. Screenshot review, mobile/responsive layouts, cart/add-to-cart behavior, Checkout Block Store API validation, admin screens, HPOS/Legacy comparison, accessibility, PHP 8.3, RTL/LTR, and theme-specific override review remain release gates. Keep T-01 **Partially implemented** until those target runs and manual evidence are recorded and approved.
