# CR-07 — Manual acceptance / staging checklist

Status: **Partially implemented and Playground-tested; not accepted / not Done.** Automated Playground scenario currently covers the planned 20% cash + 50% cheque + 30% credit split, server-side validation, unchanged parent total, credit/cheque/manual settlement, linked online child order, callback idempotency and parent settlement state. It does not replace the following real-store checks.

## Store setup
- Use a disposable staging store with the target production WordPress, WooCommerce, PHP version, active theme, HPOS setting and Checkout Block/classic checkout configuration.
- Configure a PSP sandbox gateway which supports the normal WooCommerce payment lifecycle; enable 3-D Secure if supported.
- Create an approved wholesale customer with a controlled credit limit and sufficient balance; create another customer with insufficient/overdue credit.
- Use a product/order total that divides exactly in the store currency; also prepare non-divisible and zero-decimal currency cases.

## Classic checkout and Checkout Block
- For each checkout surface, select the mixed gateway and enter 20% cash, 50% cheque (future due date), 30% credit. Confirm localized row labels/validation and that the displayed shares add to the WooCommerce order total.
- Submit with valid data. Confirm the original order's line items, taxes and total are unchanged; the persisted settlement rows sum exactly to the payable total and credit reservation is reflected exactly once.
- Attempt missing rows, duplicate/unknown methods, negative/zero amounts, excess rows, malformed dates, cheque date today/past, wrong sum by one minor currency unit, and credit above available limit. Expect server-side rejection and no partial ledger/schedule writes.
- Verify a standard non-mixed payment gateway still works as before and that the mixed gateway is only available to eligible wholesale customers.

## Online share / PSP
- Configure a non-zero online share. Verify the plugin creates/reuses a linked WooCommerce pay order for precisely that share, without changing parent order total or creating synthetic parent fees/discounts.
- Complete successful PSP payment, decline, customer cancellation, timeout, retry and 3DS challenge. Verify each callback settles only the linked online rows once and does not touch cash/cheque/credit rows.
- Replay duplicate and late callbacks; confirm idempotency, no duplicate ledger entries, no over-settlement and correct parent state. Verify failed/expired child order recovery and access control for the owning customer only.

## Manual methods, cancellation and refunds
- Record cash/bank transfer receipt and clear/return/re-present/cancel cheque through the authorized admin workflow. Verify account balance changes only for credit exposure and each transition is idempotent/audited.
- Cancel parent or child orders at each stage; verify reservations are released/reversed once and no paid share is lost.
- Test full/partial refund and PSP chargeback after mixed shares have been settled. Confirm allocation, ledger, cheque and installment states follow the approved accounting policy; stop if policy is unspecified.

## Release evidence
- Save redacted order IDs, gateway logs, expected/actual amounts, screenshots and WooCommerce/PHP/theme/HPOS/checkout versions.
- Run the full relevant browser/accessibility/theme matrix and concurrency/failure-injection tests. Record each criterion pass/fail and defects. Keep CR-07 **Partially implemented** until every required acceptance criterion is approved and tested; do not infer PSP certification from Playground.

# AD-05 — Sales representative access scope

Status: **Partially implemented and Playground-tested; not accepted / not Done.**

- In disposable staging, create a `zcws_sales_rep` account and confirm it has no `manage_woocommerce` capability outside its restricted route.
- Assign two approved wholesale customers to separate representatives using the customer user profile. Leave a third approved customer unassigned.
- Log in as each representative. Confirm `WooCommerce > مشتریان تخصیص‌یافته` lists only assigned approved customers; direct requests with another customer's ID must return 403.
- Open the customer order drill-down and verify only that customer's recent orders and bounded, read-only fields appear. Confirm the rep cannot edit the customer, edit/order-manage orders, visit WooCommerce settings, reports, invoices, credit, or another rep's page.
- Test revoked/reassigned reps, deleted/inactive rep accounts, customer downgrade/revocation, users with multiple roles, multisite, HPOS, and screen/menu behavior under the production admin theme.
- Keep AD-05 **Partially implemented** until the production access matrix, UI behavior, audit expectations and any sales-rep order-entry workflow are separately accepted. Order entry on behalf remains AD-06.

# AD-06 — Sales representative order entry on behalf of customer

Status: **Partially implemented and Playground-tested; not accepted / not Done.**

- Create two approved wholesale customers assigned to different reps, plus one unassigned customer. Submit the form as each rep and confirm the POST is rejected without nonce, with invalid nonce, for the other rep's customer, and after assignment revocation.
- Submit valid and invalid SKU/quantity CSV cases: blank rows, quoted SKU, duplicate SKU aggregation, unknown SKU, draft/private/hidden item, variation SKU, non-integer/zero/negative/oversize quantity, overstock and insufficient stock.
- Compare every created line with the customer's current contract/group/category/base and tier price. Test variation inheritance and explicit tier aggregation, customer contract priority, MOQ/max/step/pack, group minimum quantity/amount, tax class and VAT exemption. Verify no client-supplied price is accepted.
- Confirm WC_Order CRUD creates a pending order owned by the customer, copies billing/shipping addresses, records salesperson provenance, preserves line pricing snapshots, tax and order totals, and is visible only to the customer/authorized staff. Verify failed validation creates no orphan or partial order.
- Test refunds, canceled/deleted customer, product status/visibility changes between form display and submit, concurrent stock reduction, HPOS, Classic admin order screen, notifications, and audit log.
- The order-entry UI currently accepts SKU and quantity only; shipping choice, coupons, purchase-order notes, partial settlement selection and manager approval policy need explicit business acceptance before AD-06 can be marked Done.
