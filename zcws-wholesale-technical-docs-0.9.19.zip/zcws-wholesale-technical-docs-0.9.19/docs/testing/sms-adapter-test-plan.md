# N-04 — SMS queue / adapter acceptance checklist

Status: **Partially implemented**. Durable SMS enqueue/worker handling now shares `zcws_send_sms` with OTP, validates/normalizes numbers, caps plain-text payload length, supports idempotency keys and uses the notification worker's conditional claim and bounded exponential retry. Playground verifies enqueue deduplication, invalid destination rejection, provider decline/retry and accepted retry. No provider is bundled or enabled by default.

## Adapter contract

The provider filter receives: previous result, normalized E.164-like destination, plain-text message, and a small context array (`purpose`, internal notification ID, template). It must return strict `true` only after provider acceptance. Do not log the body, OTP, or raw provider credentials. Store provider credentials in the provider extension/environment, not public plugin options. Return `false` on transport/provider rejection; the queue will retry up to five attempts then mark the record failed.

## Manual staging checks
- Install/configure the selected SMS-provider extension and verify the adapter can send a test message in the provider sandbox.
- Enqueue localized Persian text, Unicode, multi-part messages and maximum-length content; verify encoding, segmentation, sender ID and recipient normalization against the provider's actual contract.
- Test success, timeout, throttling, provider 4xx/5xx, malformed adapter return, worker overlap, queue restart, retry schedule and terminal failure state.
- Replay the same idempotency key during concurrent enqueue; confirm one queue record and at-most-one active worker claim. Verify downstream provider idempotency policy because a timeout after provider acceptance can still make an external delivery ambiguous.
- Confirm message body/phone/provider response never leaks to logs, admin notices, analytics or unauthorized users; check retention and deletion policy for queued/sent notifications.
- Verify cron reliability/monitoring on production hosting and establish opt-out/consent, sender-registration, quiet-hour and jurisdictional rules before enabling transactional or marketing SMS.

Do not mark N-04 Done until the actual provider adapter, delivery, retry/timeout ambiguity, consent, locale/country rules and staging/browser checks pass. Playground uses a mock filter only.
