# I-02 — Printable invoice / browser-PDF acceptance

Status: **Partially implemented**. Invoice creation now snapshots order number/date, seller and billing identity, line-item name/SKU/quantity/subtotal/tax/total, tax lines, discounts, shipping, currency and settlement summary. Managers can preview drafts; customers can print only issued/void/corrected invoices they own. The overridable HTML template includes inline A4 print styling, localized labels and a browser “Print / Save to PDF” control. It is not a server-side PDF generator and does not constitute an official Iranian tax invoice.

## Manual staging checks
- Create draft informal invoice and proforma from an order containing products/variations, tax classes, coupons, shipping, partial/full payment, refund, non-default currency and long/non-Latin product names. Verify every amount and order-time snapshot; subsequent order edits must not mutate an issued invoice.
- As customer A, print an issued invoice owned by A. Try customer B, guest, logged-out user, missing/bad nonce, altered invoice ID and another order's invoice. Expect denial/no data leakage. Confirm managers with `manage_woocommerce` can preview drafts and all statuses.
- Verify canceled/void watermark, draft marker, localized currency, RTL/LTR, responsive view and A4 output in supported browsers; save as PDF and compare pagination/headers/footers against the issued number and totals.
- Test theme override at `yourtheme/woocommerce/zcws/invoices/document.php`; ensure overrides preserve escaping and no external font/CSS dependency.
- Check browser print/PDF accessibility, contrast, page breaks, long addresses, very large item lists, zero-decimal currencies, negative/zero values, restored/void status and snapshot v1 compatibility.
- Verify cache headers/noindex, private data handling, retention/deletion policy, no-cache behavior and that generated output never claims official tax validity where it is not configured.

A server-side PDF library, font embedding and PDF output are not bundled. Do not mark I-02 Done until the required output format is explicitly accepted and the browser/theme/security/money matrix passes; if server-generated PDF is mandatory, add and test a maintained PDF dependency separately.

## I-03 — Group tax policy manual acceptance (still open)
- Enable WooCommerce taxes and create controlled standard/reduced/custom rates. Set groups separately to inherit product class, standard class, custom registered class, and VAT-exempt. Verify group admin accepts only live registered classes and defaults to inheritance/no exemption.
- In Classic checkout and Checkout Blocks/Store API, compare taxable product, variation, shipping, coupons, inclusive/exclusive pricing, multiple rates, rounding and refunds for wholesale group, ordinary customer and guest. Confirm no payment gateway amount/selection or order total is altered through synthetic fees/discounts.
- Turn a group's exemption on and run cart totals. Verify the customer VAT flag is restored to its previous value immediately after totals; existing exemption from another plugin must remain unchanged. Recalculate the order and confirm its immutable snapshot is honored. Repeat on Classic and Store API/Blocks. A session previously written by the older development behavior must also be tested explicitly; this backward cleanup case remains open.
- Only enable exemptions after store-specific legal confirmation; the setting is a WooCommerce behavior switch, not proof of legal eligibility.

## I-04 — Buyer fields and amount-in-words manual acceptance (still open)
- Submit a wholesale application with national ID, economic code and registration number; approve it and verify only valid fields are copied to the protected profile. Invalid Iranian national-ID checksum must not overwrite the prior profile value. Edit fields in the manager profile and verify escaping and capability checks.
- Create IRR and IRT orders with zero, half-up rounding, negative/credit-note values, thousands/millions, maximum supported amount and overflow; compare the Persian words against an accountant-reviewed reference. EUR and other non-Iranian currencies must not be mislabeled as Rial/Toman.
- Add positive/negative fee lines, discounts, shipping taxes and multiple tax lines; reconcile rendered item and totals sections against WooCommerce order totals with no duplicate or omitted amounts. Verify the legal identifiers in the immutable snapshot do not change after a profile edit.
- Do not issue/use this output as an Iranian official tax invoice. Before I-04 can meet official requirements, confirm the current tax authority version/schema, seller legal/tax identity, buyer type-specific requirements, product/service codes and units, other statutory charges, serial/signature and correction/cancellation workflow with the store's tax adviser.
