# AP-02 — Native WooCommerce webhook acceptance

Status: **Partially implemented**. Two application lifecycle topics are registered with WooCommerce's native Webhooks UI: `zcws.application_submitted` and `zcws.application_reviewed`. The plugin registers valid resources/events and maps topics to existing application actions. The custom payload is minimal (`event`, application ID, customer ID, status and timestamps); it excludes phone, business ID, review note and document content. WooCommerce provides asynchronous delivery, webhook secret/HMAC signature, safe HTTP request behavior and delivery logs. Playground validates topic registration and payload construction only; no remote endpoint delivery was performed.

## Configure in staging
- Open WooCommerce → Settings → Advanced → Webhooks; add a webhook with one custom ZCWS topic, HTTPS delivery URL and a random secret. Keep status paused until the receiver is ready.
- Receiver must verify `X-WC-Webhook-Signature` with HMAC-SHA256 over the exact raw request body and the configured secret, then acknowledge with 2xx. Make its event handler idempotent using delivery ID + application ID + event.
- Use a controlled test account and a disposable HTTPS receiver; do not include or log sensitive applicant data in test payloads.

## Acceptance checks
- Verify both custom topics appear/select/save in WooCommerce UI and remain available after plugin upgrade; reject unknown ZCWS topics.
- Submit an application and trigger each review transition. Confirm exactly the expected topic, HTTP signature, event ID, minimal payload and no OTP/phone/document/business-id leakage.
- Test async queue delivery, endpoint 2xx/4xx/5xx, timeout, DNS failure, TLS validation, redirect handling, retry/failure disabling and replay/duplicate delivery semantics in the installed WooCommerce version.
- Test deleted/missing application rows, customer deletion, plugin/module disable and webhook pause/disable behavior.
- Confirm remote URL and secret are configured solely through WooCommerce's webhook UI, and delivery logs/receiver logs respect PII retention policies.

Do not mark AP-02 Done until real signed delivery and receiver verification pass in staging across the supported WooCommerce matrix. Playground construction tests do not prove network delivery or retry behavior.
