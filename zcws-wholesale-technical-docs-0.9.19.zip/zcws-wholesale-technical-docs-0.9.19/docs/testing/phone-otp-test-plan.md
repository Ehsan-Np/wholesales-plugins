# O-07 — Phone OTP acceptance / SMS adapter checklist

Current code status: **Partially implemented**. The plugin now provides opt-in OTP for wholesale applications, a nonce-protected AJAX send endpoint, HMAC-hashed short-lived code state, five-minute? No: challenge lifetime is 10 minutes, at most five sends per phone/IP per hour, a 60-second resend cooldown, five verification attempts, Persian/Arabic digit normalization, one-time consumption after successful application persistence, and a strict SMS adapter contract (`zcws_send_sms`). Playground tests use a mock adapter only. No real SMS provider is bundled or certified.

## SMS adapter contract

Register a WordPress filter with four accepted arguments:

```php
add_filter( 'zcws_send_sms', function ( $sent, $phone, $message, $context ) {
    // Send through the site's chosen SMS provider over its official HTTPS API.
    // Return strict true only after the provider accepts the message.
    // Do not log/store $message or provider secrets; return false on failure.
    return $provider->send( $phone, $message ) === true;
}, 10, 4 );
```

Store API credentials in the provider's protected configuration/environment, not the plugin's public settings. Ensure provider error messages and request/response logs redact phone numbers and OTPs. This adapter contract is deliberately fail-closed: if the filter is absent or does not return strict `true`, no challenge is accepted.

## Manual acceptance

- Activate “Require phone OTP” only after installing/configuring a tested provider adapter. Verify delivery for the supported countries/formats and sender ID/encoding (including Persian text or numeric template rules).
- On guest WooCommerce registration and the standalone logged-in/new-account application form, request a code; verify translated numerals, phone spacing and `+` handling; confirm the same validated phone is attached to the application.
- Enter valid, wrong, expired, consumed, malformed and localized-digit codes. Confirm only valid, unexpired codes are accepted, after five wrong attempts the challenge is invalid, and a successful application cannot replay its code.
- Verify cooldown, per-phone and per-IP limits, concurrent send attempts, proxy/IP configuration, provider timeout/throttle, database/transient failure, SMS delivery delay and resend behavior. Confirm no OTP appears in HTML, JSON responses, PHP logs, Woo logs, analytics or application data.
- Verify users cannot submit an application with OTP enabled when provider delivery failed or when no provider is configured; disable OTP and confirm existing application forms still work unchanged.
- Test provider outage recovery and the actual SMS-provider sandbox/production credentials in staging; record country, sender, template and provider acceptance IDs without exposing OTP values.

Do not mark O-07 Done until an actual provider adapter is configured and these browser/SMS/staging checks pass. Playground mocks do not validate carrier delivery, sender registration, international routing, provider SLA or legal consent requirements.
