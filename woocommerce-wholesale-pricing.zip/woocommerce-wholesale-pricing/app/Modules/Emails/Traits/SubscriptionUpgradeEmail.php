<?php
/**
 * Trait SubscriptionUpgradeEmail
 *
 * Handles sending notification emails when a user's wholesale subscription role is upgraded.
 * Utilizes the EmailHelper trait for email preparation and sending.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Emails\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Emails\Traits;

trait SubscriptionUpgradeEmail {

	use EmailHelper;

	/**
	 * Sends a notification email when a user's subscription role is upgraded.
	 *
	 * Checks if the notification setting is enabled, prepares subject and body using user data
	 * and the upgraded role, applies filters for customization, and sends the email.
	 *
	 * @param int    $user_id The ID of the user whose role has been upgraded.
	 * @param string $role    The new upgraded role assigned to the user.
	 *
	 * @return void
	 */
	public function subscription_role_upgraded( $user_id, $role ) {
		if ('yes' !== get_option('wwp_wholesale_subscription_role_notification') ) {
			return;
		}

		$user = get_user_by('ID', $user_id);
		if (is_wp_error($user) ) {
return;
		}

		$subject = get_option('wwp_wholesale_subscription_role_subject');
		$subject = ! empty($subject) ? $subject : esc_html__('Your Role Is Upgraded', 'woocommerce-wholesale-pricing');

		$subject = $this->prepare_subject(
			$subject,
			$user,
			'wwp_wholesale_subscription_role_upgraded_subject'
		);

		$body = $this->prepare_body(
			get_option('wwp_wholesale_subscription_role_body'),
			$user,
			'wwp_wholesale_subscription_role_upgraded_tag',
			array( 'role' => $role )
		);

		$headers = $this->get_headers( 
			/**
			 * Filter 
			 * 
			 * @var string email
			 * 
			 * @since 1.8.0
			 */
			apply_filters('wwp_custom_sender_email', get_option('admin_email')),
			'wwp_wholesale_subscription_role_upgraded_user'
		);
		/**
		 * Filter 
		 * 
		 * @var string email
		 * 
		 * @since 1.8.0
		 */
		$to      = apply_filters('wwp_wholesale_subscription_role_upgraded_reciver_email', $user->user_email);

		$this->send_mail($to, $subject, $body, $headers);
	}
}
