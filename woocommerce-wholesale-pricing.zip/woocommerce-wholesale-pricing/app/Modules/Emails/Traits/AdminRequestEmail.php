<?php
/**
 * Trait AdminRequestEmail
 *
 * Handles sending notification emails to admins when a new wholesale user request is received.
 * Uses EmailHelper trait to prepare and send emails.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Emails\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Emails\Traits;

trait AdminRequestEmail {

	use EmailHelper;

	/**
	 * Sends an admin notification email when a new wholesale user request is submitted.
	 *
	 * Checks plugin settings to determine whether notifications are enabled,
	 * determines the recipient email based on settings, prepares subject and body
	 * with user data, applies relevant filters, and sends the email.
	 *
	 * @param int $user_id The ID of the user who made the wholesale request.
	 *
	 * @return void
	 */
	public function admin_request_notification( $user_id ) {
		if ('yes' !== get_option('wwp_wholesale_admin_request_notification') ) {
			return;
		}

		$user = get_user_by('ID', $user_id);
		if (is_wp_error($user) ) {
return;
		}
		$value = '';
		$reciver_email = '';
		if (! empty(get_option('wwp_wholesale_stop_admin_notification', 'no')) && 'yes' == get_option('wwp_wholesale_stop_admin_notification') ) {
			$value = get_option('wwp_wholesale_admin_request_recipient');
		} else {
			$reciver_email = get_option('admin_email');
		}

		if (! empty($value) ) {
			$reciver_email = $value;
		}

		$subject = get_option('wwp_wholesale_admin_request_subject');
		$subject = ! empty($subject) ? $subject : esc_html__('New Requested Received', 'woocommerce-wholesale-pricing');

		$subject = $this->prepare_subject(
			$subject,
			$user,
			'wwp_wholesale_admin_request_notification_subject'
		);

		$body = $this->prepare_body(
			get_option('wwp_wholesale_admin_request_body'),
			$user,
			'wwp_wholesale_admin_request_notification_tag',
			$this->get_wholesale_placeholders($user_id)
		);

		$headers = $this->get_headers( 
			/**
			 * Filter 
			 * 
			 * @var string Email
			 * 
			 * @since 1.8.0
			 */
			apply_filters('wwp_custom_sender_email', get_option('admin_email')),
			'wwp_wholesale_approval_email_header_user'
		);
		/**
		 * Filter 
		 * 
		 * @var string Email
		 * 
		 * @since 1.8.0
		 */
		$to      = apply_filters('wwp_wholesale_admin_request_notification_reciver_email', $reciver_email);

		$this->send_mail($to, $subject, $body, $headers);
	}
}
