<?php
/**
 * Trait EmailHelper
 *
 * Provides helper methods to prepare email subjects, bodies, headers,
 * and to send emails within the WooCommerce Wholesale Pricing plugin.
 *
 * Methods apply WordPress filters to allow customization of email content.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Emails\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Emails\Traits;

trait EmailHelper {

	/**
	 * Prepare the email subject with user-specific placeholders replaced.
	 *
	 * Replaces placeholders like {first_name} and {last_name} in the subject,
	 * applies default subject if empty, and filters the result.
	 *
	 * @param string $subject     The email subject template.
	 * @param object $user        User object containing user info.
	 * @param string $filter_hook The WordPress filter hook name to apply.
	 *
	 * @return string Filtered and prepared email subject.
	 */
	protected function prepare_subject( $subject, $user, $filter_hook ) {
		$subject = ! empty($subject) ? $subject : __('Notification', 'woocommerce-wholesale-pricing');
		$subject = stripslashes(html_entity_decode($subject, ENT_QUOTES, 'UTF-8'));
		$subject = str_replace('{first_name}', $user->first_name, $subject);
		$subject = str_replace('{last_name}', $user->last_name, $subject);
		/**
		 * Filter 
		 * 
		 * @var string $subject
		 * @var WP_User $user
		 * 
		 * @since 1.8.0
		 */
		return apply_filters($filter_hook, $subject, $user);
	}

	/**
	 * Prepare the email body by replacing placeholders with user data and extra tags.
	 *
	 * Supports common placeholders such as {email}, {first_name}, {last_name}, {username}, {date}, {time}.
	 * Additional placeholders can be provided via $extra_tags.
	 * Applies a filter to allow further customization.
	 *
	 * @param string $body       The email body template.
	 * @param object $user       User object containing user info.
	 * @param string $hook       The WordPress filter hook name to apply.
	 * @param array  $extra_tags Optional associative array of extra placeholders and their values.
	 *
	 * @return string Filtered and prepared email body.
	 */
	protected function prepare_body( $body, $user, $hook, $extra_tags = array() ) {
		$body = str_replace('{email}', $user->user_email, $body);
		$body = str_replace('{first_name}', $user->first_name, $body);
		$body = str_replace('{last_name}', $user->last_name, $body);
		$body = str_replace('{username}', $user->user_login, $body);
		$body = str_replace('{date}', gmdate('Y-m-d', strtotime($user->user_registered)), $body);
		$body = str_replace('{time}', gmdate('H:i:s', strtotime($user->user_registered)), $body);

		foreach ( $extra_tags as $tag => $value ) {
			$body = str_replace('{' . $tag . '}', $value, $body);
		}

		/**
		 * Filter 
		 * 
		 * @var string $body
		 * 
		 * @since 1.8.0
		 */
		return apply_filters($hook, $body);
	}

	/**
	 * Get the email headers for sending HTML emails.
	 *
	 * Sets the From header based on blog name and sender email,
	 * specifies MIME version and content type for HTML emails.
	 * Applies a filter for customization.
	 *
	 * @param string $sender_email The sender's email address.
	 * @param string $hook         The WordPress filter hook name to apply.
	 *
	 * @return string Filtered email headers string.
	 */
	protected function get_headers( $sender_email, $hook ) {
		$sender   = esc_html(get_option('blogname')) . ' <' . esc_html($sender_email) . '>';
		$headers  = 'From: ' . $sender . PHP_EOL;
		$headers .= 'MIME-Version: 1.0' . PHP_EOL;
		$headers .= 'Content-Type: text/html; charset=UTF-8';

		/**
		 * Filter 
		 * 
		 * @var string $headers
		 * @var string $sender_email
		 * 
		 * @since 1.8.0
		 */
		return apply_filters($hook, $headers, $sender_email);
	}
	
	 /**
	  * Send the email using WordPress wp_mail function.
	  *
	  * @param string $to      Recipient email address.
	  * @param string $subject Email subject.
	  * @param string $body    Email body content.
	  * @param array  $headers Email headers.
	  *
	  * @return bool True if mail was sent successfully, false otherwise.
	  */
	protected function send_mail( $to, $subject, $body, $headers ) {
		return wp_mail($to, $subject, $body, $headers);
	}

	/**
	 * Get all wholesale-related placeholders for a user, including billing, shipping, and extra fields.
	 *
	 * @param int $user_id The user ID.
	 * @return array Associative array of placeholders and their values.
	 */
	protected function get_wholesale_placeholders( $user_id ) {
		$placeholders = array();
		$user = get_user_by('ID', $user_id);

		if (!$user) {
			return $placeholders;
		}

		// Billing Address Fields
		$billing_fields = array(
			'billing_first_name',
			'billing_last_name',
			'billing_company',
			'billing_address_1',
			'billing_address_2',
			'billing_city',
			'billing_state',
			'billing_postcode',
			'billing_country',
			'billing_phone',
		);

		foreach ($billing_fields as $field) {
			$placeholders[$field] = get_user_meta($user_id, $field, true);
		}

		// Shipping Address Fields
		$shipping_fields = array(
			'shipping_first_name',
			'shipping_last_name',
			'shipping_company',
			'shipping_address_1',
			'shipping_address_2',
			'shipping_city',
			'shipping_state',
			'shipping_postcode',
			'shipping_country',
			'shipping_phone',
		);

		foreach ($shipping_fields as $field) {
			$placeholders[$field] = get_user_meta($user_id, $field, true);
		}

		// Tax ID
		$placeholders['tax_id'] = get_user_meta($user_id, 'wwp_wholesaler_tax_id', true);

		// Extra fields from form builder
		$extra_placeholders = $this->get_form_builder_placeholders($user_id);
		$placeholders = array_merge($placeholders, $extra_placeholders);

		return $placeholders;
	}

	/**
	 * Extract form builder fields as ID-based placeholders (e.g., {extra_field_1}).
	 *
	 * @param int $user_id The user ID.
	 * @return array Associative array of extra placeholders.
	 */
	protected function get_form_builder_placeholders( $user_id ) {
		$placeholders = array();
		$form_data = get_user_meta($user_id, 'wwp_form_data_json', true);

		if (empty($form_data)) {
			return $placeholders;
		}

		foreach ($form_data as $key => $value) {
			$placeholders[$key] = $this->stringify_form_builder_value($value);
		}

		return $placeholders;
	}

	/**
	 * Convert a form-builder field value into a string for email placeholders.
	 *
	 * File fields are stored as arrays of objects (url/name), so implode()
	 * would trigger "Array to string conversion".
	 *
	 * @param mixed $value Raw user-meta value.
	 * @return string
	 */
	protected function stringify_form_builder_value( $value ) {
		if ( is_bool( $value ) ) {
			return $value ? 'yes' : 'no';
		}

		if ( ! is_array( $value ) ) {
			return is_scalar( $value ) ? (string) $value : '';
		}

		if ( function_exists( 'wwp_is_formio_file_value' ) && wwp_is_formio_file_value( $value ) ) {
			$files = isset( $value[0] ) ? $value : array( $value );
			$parts = array();

			foreach ( $files as $file ) {
				if ( ! is_array( $file ) ) {
					continue;
				}

				$name = '';
				if ( ! empty( $file['originalName'] ) ) {
					$name = $file['originalName'];
				} elseif ( ! empty( $file['name'] ) ) {
					$name = $file['name'];
				}

				$url = ! empty( $file['url'] ) ? $file['url'] : '';
				if ( $url && 0 !== strpos( $url, 'data:' ) ) {
					$parts[] = $name ? $name . ' (' . $url . ')' : $url;
				} elseif ( $name ) {
					$parts[] = $name;
				}
			}

			return implode( ', ', $parts );
		}

		$flat = array();
		foreach ( $value as $item ) {
			$flat[] = is_array( $item ) ? $this->stringify_form_builder_value( $item ) : (string) $item;
		}

		return implode( ', ', array_filter( $flat, 'strlen' ) );
	}
}
