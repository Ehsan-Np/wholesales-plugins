<?php
/**
 * ShippingService class for managing which shipping methods are available to a wholesale user.
 *
 * This class applies restrictions to WooCommerce package rates based on the
 * currently logged-in user's wholesale role, groups, or temporary store access settings.
 *
 * @package    WooCommerceWholesalePricing\App\Modules\Wholesale
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Service class for handling shipping restrictions for wholesale users.
 */
class ShippingService {

	/**
	 * Includes methods for retrieving general wholesale settings.
	 */
	use WholesaleSettings;

	/**
	 * Initializes hooks.
	 */
	public function __construct() {
		add_filter('woocommerce_package_rates', array( $this, 'wwp_restrict_shipping_wholesaler' ), 10, 2);
	}

	/**
	 * Primary filter callback: determines the user's restrictions and applies them to the rates.
	 *
	 * @param  array $rates   Array of shipping rates.
	 * @param  array $package Package data.
	 * @return array Filtered shipping rates.
	 */
	public function wwp_restrict_shipping_wholesaler( $rates, $package ) {
		if (is_admin() && ! defined('DOING_AJAX') ) {
			return $rates;
		}
		$settings   = self::get_pricing_settings();
		$term       = '';
		$restricted_shipping_group = array();
		$restricted_shipping_role  = array();

		if (isset($settings['restrict_store_access']) && 'yes' == $settings['restrict_store_access'] ) {
			if (isset($_COOKIE['access_store_id']) && ! empty($_COOKIE['access_store_id']) ) {
				$term = get_term_by('id', sanitize_text_field($_COOKIE['access_store_id']), 'wholesale_user_roles');
			}
		} else {
			$user_info  = get_userdata(get_current_user_id());

			$ws_group = wwp_get_group_post_by_proid(0, get_current_user_id());
			if (! empty($ws_group) ) { 
				foreach ( $ws_group as $group_id ) {
					$group_meta = get_post_meta( $group_id, '_disable_shipping_methods', true );
					if ( ! empty( $group_meta ) && is_array( $group_meta ) ) {
						$restricted_shipping_group = array_merge( $restricted_shipping_group, $group_meta );
					}
				}
				
			}

			$user_roles = ( isset($user_info->roles) ? array_values( $user_info->roles ) : array() );
			if (empty($user_roles) ) {
				return $rates;
			}
			$term = isset($user_roles[0]) ? get_term_by('slug', $user_roles[0], 'wholesale_user_roles') : '';
		}

		if (! empty($term) && ! is_wp_error($term) ) {
			$restricted_shipping_role = get_term_meta($term->term_id, 'wwp_restricted_smethods_wholesaler', true);
		}

		$restricted_method_ids   = array_unique(array_map('strval', (array) $restricted_shipping_group));
		$restricted_instance_ids = array_unique(array_map('strval', array_filter((array) $restricted_shipping_role, 'strlen')));
		if (empty($restricted_method_ids) && empty($restricted_instance_ids) ) {
			return $rates;
		}

		$rates = $this->apply_rate_restrictions($rates, $restricted_method_ids, $restricted_instance_ids);
		if (! empty($rates) ) {
			return $rates;
		}

		// If restrictions removed every rate from the selected zone, try another matching zone
		// (e.g. country-specific B2B zone after hiding a broader B2C free-shipping zone).
		$fallback_rates = $this->get_fallback_zone_rates($package, $restricted_method_ids, $restricted_instance_ids);
		if (! empty($fallback_rates) ) {
			return $fallback_rates;
		}

		return $this->get_any_available_zone_rates($package, $restricted_method_ids, $restricted_instance_ids);
	}

	/**
	 * Remove restricted rates by method ID and/or instance ID.
	 *
	 * @param array $rates Shipping rates.
	 * @param array $restricted_method_ids Restricted method IDs (e.g. free_shipping).
	 * @param array $restricted_instance_ids Restricted instance IDs (zone method instances).
	 * @return array
	 */
	private function apply_rate_restrictions( array $rates, array $restricted_method_ids, array $restricted_instance_ids ) {
		foreach ( $rates as $rate_key => $rate ) {
			$method_id   = isset($rate->method_id) ? (string) $rate->method_id : '';
			$instance_id = method_exists($rate, 'get_instance_id') ? (string) $rate->get_instance_id() : '';

			if (in_array($method_id, $restricted_method_ids, true) || in_array($instance_id, $restricted_instance_ids, true) ) {
				unset($rates[ $rate_key ]);
			}
		}

		return $rates;
	}

	/**
	 * Build rates from other matching zones when primary zone becomes empty after restrictions.
	 *
	 * @param array $package WooCommerce shipping package.
	 * @param array $restricted_method_ids Restricted method IDs.
	 * @param array $restricted_instance_ids Restricted instance IDs.
	 * @return array
	 */
	private function get_fallback_zone_rates( array $package, array $restricted_method_ids, array $restricted_instance_ids ) {
		if ( ! class_exists('WC_Shipping_Zones') ) {
			return array();
		}

		$matched_zone    = \WC_Shipping_Zones::get_zone_matching_package($package);
		$matched_zone_id = ( $matched_zone && method_exists($matched_zone, 'get_id') ) ? (int) $matched_zone->get_id() : 0;
		$fallback_rates  = array();

		$zones = \WC_Shipping_Zones::get_zones();
		$zones[] = array(
			'zone_id' => 0,
		);

		foreach ( $zones as $zone_data ) {
			$zone_id = isset($zone_data['zone_id']) ? (int) $zone_data['zone_id'] : 0;
			if ($zone_id === $matched_zone_id ) {
				continue;
			}

			$zone = \WC_Shipping_Zones::get_zone($zone_id);
			if ( ! $zone || ! $this->zone_matches_package($zone, $package) ) {
				continue;
			}

			$methods = $zone->get_shipping_methods(true);
			if (empty($methods) ) {
				continue;
			}

			foreach ( $methods as $method ) {
				if ( ! is_object($method) || ! method_exists($method, 'get_rates_for_package') ) {
					continue;
				}
				$zone_rates     = (array) $method->get_rates_for_package($package);
				$filtered_rates = $this->apply_rate_restrictions($zone_rates, $restricted_method_ids, $restricted_instance_ids);
				if (! empty($filtered_rates) ) {
					$fallback_rates = array_merge($fallback_rates, $filtered_rates);
				}
			}

			if (! empty($fallback_rates) ) {
				return $fallback_rates;
			}
		}

		return $fallback_rates;
	}

	/**
	 * Last-resort fallback: scan enabled zone methods and return non-restricted available rates.
	 *
	 * @param array $package WooCommerce shipping package.
	 * @param array $restricted_method_ids Restricted method IDs.
	 * @param array $restricted_instance_ids Restricted instance IDs.
	 * @return array
	 */
	private function get_any_available_zone_rates( array $package, array $restricted_method_ids, array $restricted_instance_ids ) {
		if ( ! class_exists('WC_Shipping_Zones') ) {
			return array();
		}

		$zones = \WC_Shipping_Zones::get_zones();
		$zones[] = array(
			'zone_id' => 0,
		);

		foreach ( $zones as $zone_data ) {
			$zone_id = isset($zone_data['zone_id']) ? (int) $zone_data['zone_id'] : 0;
			$zone    = \WC_Shipping_Zones::get_zone($zone_id);
			if ( ! $zone ) {
				continue;
			}

			$methods = $zone->get_shipping_methods(true);
			if (empty($methods) ) {
				continue;
			}

			foreach ( $methods as $method ) {
				if ( ! is_object($method) || ! method_exists($method, 'get_rates_for_package') ) {
					continue;
				}
				if (method_exists($method, 'is_available') && ! $method->is_available($package) ) {
					continue;
				}

				$zone_rates     = (array) $method->get_rates_for_package($package);
				$filtered_rates = $this->apply_rate_restrictions($zone_rates, $restricted_method_ids, $restricted_instance_ids);
				if (! empty($filtered_rates) ) {
					return $filtered_rates;
				}
			}
		}

		return array();
	}

	/**
	 * Check if a shipping zone can match the destination package.
	 *
	 * @param \WC_Shipping_Zone $zone Zone object.
	 * @param array             $package Shipping package.
	 * @return bool
	 */
	private function zone_matches_package( $zone, array $package ) {
		$destination = isset($package['destination']) && is_array($package['destination']) ? $package['destination'] : array();
		$country     = strtoupper(isset($destination['country']) ? (string) $destination['country'] : '');
		$state       = strtoupper(isset($destination['state']) ? (string) $destination['state'] : '');
		$postcode    = strtoupper(str_replace(' ', '', (string) ( isset($destination['postcode']) ? $destination['postcode'] : '' )));

		if ('' === $country ) {
			return false;
		}

		$locations = method_exists($zone, 'get_zone_locations') ? (array) $zone->get_zone_locations() : array();
		if (empty($locations) ) {
			return true;
		}

		foreach ( $locations as $location ) {
			$type = isset($location->type) ? (string) $location->type : '';
			$code = strtoupper(isset($location->code) ? (string) $location->code : '');

			if ('country' === $type && $country === $code ) {
				return true;
			}
			if ('state' === $type && strtoupper($country . ':' . $state) === $code ) {
				return true;
			}
			if ('continent' === $type && function_exists('WC') ) {
				$continents = WC()->countries->get_continents();
				if (isset($continents[ $code ]['countries']) && in_array($country, (array) $continents[ $code ]['countries'], true) ) {
					return true;
				}
			}
			if ('postcode' === $type && '' !== $postcode && $this->postcode_matches_zone_rule($postcode, $code) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Basic postcode matching for zone rules (supports wildcard prefix).
	 *
	 * @param string $postcode Destination postcode.
	 * @param string $rule Zone postcode rule.
	 * @return bool
	 */
	private function postcode_matches_zone_rule( $postcode, $rule ) {
		$postcode = strtoupper(str_replace(' ', '', (string) $postcode));
		$rule     = strtoupper(str_replace(' ', '', (string) $rule));

		if ('' === $rule ) {
			return false;
		}

		if (false !== strpos($rule, '*') ) {
			$prefix = rtrim($rule, '*');
			return '' !== $prefix && 0 === strpos($postcode, $prefix);
		}

		return $postcode === $rule;
	}
}
