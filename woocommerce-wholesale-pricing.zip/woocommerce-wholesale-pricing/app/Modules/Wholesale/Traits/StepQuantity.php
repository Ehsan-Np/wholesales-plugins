<?php
/**
 * Trait StepQuantity.
 *
 * This trait handles filtering the WooCommerce quantity input arguments to enforce
 * wholesale-specific minimum and step quantities based on the product, category,
 * or variation settings for the current user's wholesale role.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

trait StepQuantity {


	/**
	 * Trait containing utility methods.
	 */
	use WholesaleSettings;
	use IsWholesale;

	/**
	 * Filters the arguments passed to the quantity input field template.
	 *
	 * This method applies the wholesale pricing hierarchy to set:
	 * 1. 'input_value': The initial quantity shown (usually set to min).
	 * 2. 'step': The increment/decrement value.
	 * 3. 'min_value': The minimum quantity allowed.
	 *
	 * Hierarchy: Variation (for variable products) > Product > Category > Global (not directly checked here, handled by absence).
	 *
	 * @param  array       $wp_parse_args The original arguments for the quantity input.
	 * @param  \WC_Product $product       The product object (can be a variation).
	 * @return array The modified arguments.
	 */
	public function wwp_filter_woocommerce_quantity_input_args( $wp_parse_args, $product ) {
		if ($this->is_wholesale($product->get_id()) ) {
			$role     = get_current_user_role_id();
			$settings = self::get_pricing_settings();
			if (( 'object' == gettype($product) ) ) {
				if (isset($settings['wholesaler_allow_minimum_qty']) && 'yes' == $settings['wholesaler_allow_minimum_qty'] ) {
					if ('simple' == $product->get_type() || 'bundle' == $product->get_type() ) {
						$terms = get_the_terms($product->get_id(), 'product_cat');
						if (! is_wp_error($terms) && ! empty($terms) ) {
							foreach ( $terms as $term ) {
	
								$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
								if (isset($data[$role]['min_quatity']) && !empty($data[$role]['min_quatity']) ) {
									if (!defined('WOOCOMMERCE_CART') && !defined( 'WOODMART_THEME_DIR' ) ) {
										$wp_parse_args['input_value'] = $data[$role]['min_quatity'];
									}
								}
								
								if (isset($data[$role]['step_quantity']) && !empty($data[$role]['step_quantity']) ) {
									$wp_parse_args['step'] = $data[$role]['step_quantity'];
									if (isset($data[$role]['min_quatity']) && !empty($data[$role]['min_quatity']) ) {
										$wp_parse_args['min_value'] = $data[$role]['min_quatity'];
										$wp_parse_args['quantity']  = $data[$role]['step_quantity'];
									}
								}
							}
						}
						
						$data = get_post_meta($product->get_id(), 'wholesale_multi_user_pricing', true);
						
						if (isset($data[$role]['min_quatity']) && !empty($data[$role]['min_quatity']) ) { 
							if (!defined('WOOCOMMERCE_CART') && !defined( 'WOODMART_THEME_DIR' ) ) {
								$wp_parse_args['input_value'] = $data[$role]['min_quatity'];
							} 
						}
						if (isset($data[$role]['step_quantity']) && !empty($data[$role]['step_quantity']) ) {
							$wp_parse_args['step'] = $data[$role]['step_quantity'];
							if (isset($data[$role]['min_quatity']) && !empty($data[$role]['min_quatity']) ) {
								$wp_parse_args['min_value'] = $data[$role]['min_quatity'];
								$wp_parse_args['quantity']  = $data[$role]['step_quantity'];
							}
						} 
					} elseif ('variation' == $product->get_type() ) { 
					
						$product_id = wp_get_post_parent_id($product->get_id());
						$terms      = get_the_terms($product_id, 'product_cat');
						if (! is_wp_error($terms) && ! empty($terms) ) {
							foreach ( $terms as $term ) {
	
								$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
								if (isset($data[$role]['min_quatity']) && !empty($data[$role]['min_quatity']) ) {
									if (!defined('WOOCOMMERCE_CART') && !defined( 'WOODMART_THEME_DIR' ) ) {
										$wp_parse_args['input_value'] = $data[$role]['min_quatity'];
									}
								}
								
								if (isset($data[$role]['step_quantity']) && !empty($data[$role]['step_quantity']) ) {
									$wp_parse_args['step'] = $data[$role]['step_quantity'];
									if (isset($data[$role]['min_quatity']) && !empty($data[$role]['min_quatity']) ) {
										$wp_parse_args['min_value'] = $data[$role]['min_quatity'];
										$wp_parse_args['quantity']  = $data[$role]['step_quantity'];
									}
								}
							}
						}
						
						$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
						if (isset($data[$role][$product->get_id()]['qty']) && !empty($data[$role][$product->get_id()]['qty']) ) {
							if (!defined('WOOCOMMERCE_CART') && !defined( 'WOODMART_THEME_DIR' ) ) {
								$wp_parse_args['input_value'] = $data[$role][$product->get_id()]['qty'];
							} 
						}
						if (isset($data[$role][$product->get_id()]['step']) && !empty($data[$role][$product->get_id()]['step']) ) {
							$wp_parse_args['step'] = $data[$role][$product->get_id()]['step'];
							if (isset($data[$role][$product->get_id()]['qty']) && !empty($data[$role][$product->get_id()]['qty']) ) {
								$wp_parse_args['min_value'] = $data[$role][$product->get_id()]['qty'];
								if (isset($data[$role]['step_quantity']) ) {
									$wp_parse_args['quantity'] = $data[$role]['step_quantity'];
								}
							}
						}
					
					}
				} elseif ('simple' == $product->get_type() || 'bundle' == $product->get_type()) {
						$terms = get_the_terms($product->get_id(), 'product_cat');
					if (! is_wp_error($terms) && ! empty($terms) ) {
						foreach ( $terms as $term ) {
							$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
								
							if (isset($data[$role]['step_quantity']) && !empty($data[$role]['step_quantity']) ) {
								$wp_parse_args['step']      = $data[$role]['step_quantity'];
								$wp_parse_args['min_value'] = $data[$role]['step_quantity'];
								$wp_parse_args['quantity']  = $data[$role]['step_quantity'];
							}
						}
					}
						
						$data = get_post_meta($product->get_id(), 'wholesale_multi_user_pricing', true);
						
					if (isset($data[$role]['step_quantity']) && !empty($data[$role]['step_quantity']) ) {
						$wp_parse_args['step'] = $data[$role]['step_quantity'];
						$wp_parse_args['min_value'] = $data[$role]['step_quantity'];
						$wp_parse_args['quantity']  = $data[$role]['step_quantity'];
					} 
				} elseif ('variation' == $product->get_type() ) { 
					
					$product_id = wp_get_post_parent_id($product->get_id());
					$terms      = get_the_terms($product_id, 'product_cat');
					if (! is_wp_error($terms) && ! empty($terms) ) {
						foreach ( $terms as $term ) {
	
							$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
							if (isset($data[$role]['step_quantity']) && !empty($data[$role]['step_quantity']) ) {
								$wp_parse_args['step'] = $data[$role]['step_quantity'];
								$wp_parse_args['min_value'] = $data[$role]['step_quantity'];
								$wp_parse_args['quantity']  = $data[$role]['step_quantity'];
							}
						}
					}
						
					$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
					if (isset($data[$role][$product->get_id()]['step']) && !empty($data[$role][$product->get_id()]['step']) ) {
						$wp_parse_args['step'] = $data[$role][$product->get_id()]['step'];
						if (isset($data[$role][$product->get_id()]['qty']) && !empty($data[$role][$product->get_id()]['qty']) ) {
							$wp_parse_args['min_value'] = $data[$role][$product->get_id()]['qty'];
							if (isset($data[$role]['step_quantity']) ) {
								$wp_parse_args['quantity'] = $data[$role]['step_quantity'];
							}
						}
					}
				}
			}
		}
 
		return $wp_parse_args; 
	}
}
