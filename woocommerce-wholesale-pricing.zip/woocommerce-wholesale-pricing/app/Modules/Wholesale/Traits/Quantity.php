<?php
/**
 * Trait Quantity.
 *
 * Provides methods for validating minimum wholesale quantity requirements.
 * This trait is typically used in the cart and add-to-cart validation processes
 * to ensure a user meets the minimum purchase threshold to qualify for wholesale pricing.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

trait Quantity {


   
	/**
	 * Checks if the product quantity meets the minimum wholesale quantity requirement.
	 *
	 * Note: This function contains several checks to bypass quantity validation
	 * based on the request context (e.g., REST API, cart/checkout pages, admin).
	 *
	 * @param  int|float $qty           The quantity being checked (e.g., quantity added to cart).
	 * @param  int|float $wholesale_qty The minimum quantity required for the wholesale price to apply.
	 * @return bool True if the quantity passes validation (or validation is bypassed), false otherwise.
	 */
	public function quantity( $qty, $wholesale_qty ) {
		if (( isset($_SERVER['REQUEST_URI']) && '/wp-json/wc/store/v1/batch?_locale=user' == sanitize_text_field($_SERVER['REQUEST_URI']) ) ) {
			return true;
		}
		/**
		 * Hooks: wwp_quantity_min_check
		 *
		 * Allows external code to bypass the quantity check logic entirely.
		 * The $this->product_obj property must be set in the calling class/method.
		 *
		 * @since 3.0.0
		 * @param bool $skip_check Whether to skip the check. Default: false.
		 * @param int|float $qty The quantity being checked.
		 * @param int|float $wholesale_qty The minimum wholesale quantity.
		 * @param \WC_Product $product_obj The product object associated with the check.
		 */
		if (apply_filters('wwp_quantity_min_check', false, $qty, $wholesale_qty, $this->product_obj) ) {
			return true;
		}

		if (( is_cart() || is_checkout() ) ) {
			return true;
		}
		if (is_admin() && '' != $qty && $qty < $wholesale_qty ) {
			return true;
		}

		if ('' != $qty && $qty < $wholesale_qty ) {
			return false;
		}
	}
}
