<?php
/**
 * Trait VariableWholesalePrice.
 *
 * This trait contains the logic for calculating the final wholesale price
 * for a specific product variation ID based on the configured wholesale settings.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

trait VariableWholesalePrice {


   

	/**
	 * Calculates the actual wholesale price for a variable product's variation.
	 *
	 * This function is expected to be called by pricing display logic to get the final
	 * price used on product pages and variation selections.
	 *
	 * @param  array $arr          Array of wholesale pricing data for the variation (expected to contain 'wholesaleprice').
	 * @param  int   $variation_id The ID of the product variation.
	 * @return float|bool The calculated wholesale price, or false if no price is determined.
	 */
	public function get_variable_wholesale_price( $arr, $variation_id ) {
		if (empty($arr) ) {
			return false;
		}

		if (wwp_guest_wholesale_pricing_enabled() ) { 
				return false;
		}
		
		$role           = get_current_user_role_id();
		$data           = get_post_meta(wp_get_post_parent_id($variation_id), 'wholesale_multi_user_pricing', true);
		$variable_price = isset($arr['wholesaleprice']) ? $arr['wholesaleprice'] : 0;

		$wholesale_amount_type        = $data[ $role ]['discount_type'];
		$wc_get_product               = wc_get_product($variation_id);
		$wwp_variation_explode_eneble = get_post_meta($wc_get_product->get_parent_id(), 'wwp_variation_explode_eneble', true);
		if ('fixed' === $wholesale_amount_type ) {
			if ('yes' == $wwp_variation_explode_eneble && 'excl' == get_option('woocommerce_tax_display_shop') ) {
				$variable_price = wwp_get_price_including_tax($wc_get_product, array( 'price' => $variable_price ));
			}
			return $variable_price;
		} else {
			/**
			 * Filter
			 * 
			 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
			 * 
			 * @since 3.1.0
			 */
			$product_price   = get_post_meta($variation_id, apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' ), true);
			$product_price   = ( isset($product_price) && is_numeric($product_price) ) ? $product_price : 0;
			$variable_price  = ( isset($variable_price) && is_numeric($variable_price) ) ? $variable_price : 0;
			$wholesale_price = $product_price * $variable_price / 100;
			if ('yes' == $wwp_variation_explode_eneble && 'excl' == get_option('woocommerce_tax_display_shop') ) {
				$wholesale_price = wwp_get_price_including_tax($wc_get_product, array( 'price' => $wholesale_price ));
			}
			return $wholesale_price;
		}
	}
}
