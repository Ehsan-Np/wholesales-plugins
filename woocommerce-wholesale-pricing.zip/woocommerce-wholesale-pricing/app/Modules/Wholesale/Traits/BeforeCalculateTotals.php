<?php
/**
 * Trait BeforeCalculateTotals.
 *
 * This trait is responsible for overriding the product price in the WooCommerce
 * cart before totals are calculated, applying the appropriate wholesale discount
 * based on a strict hierarchy of pricing rules (Product Group, Product, Category, Global)
 * and discount types (Tiered vs. General).
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

trait BeforeCalculateTotals {


	/**
	 * Uses: Logic for cart subtotal discounts (if applicable).
	 */
	use WholesaleCartSubtotalDiscount;

	/**
	 * Uses: Logic for fetching and applying wholesale price to variable products.
	 */
	use VariableWholesalePrice;

	/**
	 * Uses: Core logic for modifying a price based on general discount type (percent/fixed).
	 */
	use ModifyPrice;
	
	/**
	 * Uses: Placeholder/Helper methods related to discount data retrieval.
	 */
	use DiscountedPrice;

	/**
	 * Uses: Logic for changing the regular price of a product.
	 */
	use RegularPriceChange;

	/**
	 * Uses: Logic for modifying product price HTML display.
	 */
	use ProductPriceHTML;

	/**
	 * Filters and overrides the product price in the cart item data if a wholesale
	 * discount is applicable, following a strict, prioritized hierarchy.
	 *
	 * Hierarchy of Discount Application (Highest to Lowest Priority):
	 * 1. Product Group (Tiered)
	 * 2. Product Level (Tiered)
	 * 3. Product Level (General)
	 * 4. Category Level (Tiered)
	 * 5. Category Level (General)
	 * 6. Global Level (Tiered)
	 * 7. Global Level (General)
	 *
	 * @param  \WC_Cart $_cart The WooCommerce Cart object passed by reference.
	 * @return void
	 */
	public function wwp_override_product_price_cart( $_cart ) {

		global $productService;

		if (is_admin() && ! defined('DOING_AJAX') ) {
			return;
		}

		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

		if (! $this->wholesale_pricing_cart_based_on_subtotal() ) {
			foreach ( $_cart->cart_contents as $key => $item ) {
				$item['data']->set_price(get_post_meta($item['data']->get_id(), $price_key, true));
			}
			return;
		}
		
		remove_filter('woocommerce_product_get_price', array( $productService, 'wwp_regular_price_change' ), 200, 2);
		remove_filter('woocommerce_product_get_regular_price', array( $productService, 'wwp_regular_price_change' ), 200, 2);
		remove_filter('woocommerce_product_variation_get_regular_price', array( $productService, 'wwp_regular_price_change' ), 200, 2);
		remove_filter('woocommerce_get_price_html', array( $this, 'wwp_change_product_price_display' ), 200, 2);
		remove_filter('woocommerce_cart_item_price', array( $this, 'wwp_change_product_price_display' ), 200, 2);
		
		global $woocommerce;
		$items = $woocommerce->cart->get_cart();
		$ws_group = wwp_get_group_post_by_proid(0, get_current_user_id());
		$role  = get_current_user_role_id();
		if (empty($role) && ! $ws_group ) {
			return;
		}
		foreach ( $_cart->cart_contents as $key => $item ) {

			$return_check = false;
			$variation_id = $item['variation_id'];

			$product_id =  $item['product_id'];
			$product = wc_get_product($product_id);
			if (! empty($variation_id) ) {

				$ws_group = wwp_get_group_post_by_proid($item['product_id'], get_current_user_id());
				if ($ws_group ) { 
					$group_id = isset($ws_group[0]) ? $ws_group[0] : '';
					
					if (! empty($group_id) ) {
						$discount_type = get_post_meta($group_id, '_discount_type', true);
						$min_quantity = get_post_meta($group_id, '_min_quantity', true);
						$max_quantity = get_post_meta($group_id, '_max_quantity', true);
						$wwp_price = get_post_meta($group_id, '_wwp_group_price', true);

						if (! empty($discount_type) && ! empty($wwp_price) && ! empty($min_quantity) && false === $return_check ) { 
							
							$regular_price = get_post_meta($variation_id, $price_key, true);
							
							if (empty($regular_price) || empty($wwp_price) ) {
								/**
								* Hooks
								*
								* @since 3.0
								*/
								$price = apply_filters('wwp_override_product_price_cart_price', $regular_price, $item);
								$item['data']->set_price($price);

								continue;
							}
							
							if ('fixed' == $discount_type ) {
								$price = $wwp_price;
							} else {
								$price = $regular_price * $wwp_price / 100;
							}
							$qty            = $item['quantity'];
							if ($qty >= $min_quantity && $qty <= $max_quantity ) {  
								/**
								* Filter
								*
								* @since 2.4
								*/
								$price = apply_filters('wwp_override_product_price_cart_price', $price, $item);
								$item['data']->set_price($price);
								$return_check = true;
								continue;
							}
						}
					}
				}
					
				$data = get_post_meta($item['product_id'], 'wholesale_multi_user_pricing', true);
				if (isset($data[ $role ]) ) { 
				
					if (tire_variable_wholesale_product_price($item['variation_id'], wc_get_product($item['variation_id']), 'product') ) {
						$price = tire_variable_wholesale_product_price($item['variation_id'], wc_get_product($item['variation_id']), 'product');
						
						/**
						* Hooks
						*
						* @since 3.0
						*/
						$price = apply_filters('wwp_override_product_price_cart_price', $price, $item);
						$item['data']->set_price($price);
						$return_check = true;
						continue;
					}
					if (isset($data[ $role ][ $variation_id ]) && false === $return_check ) {
					
						$min_quantity = $data[ $role ][ $variation_id ]['qty'];
						if (empty($min_quantity) || ! isset($min_quantity) ) { // IF MIN QUANTITY NOT SET OR DOESN't EXIST ON DB
							$min_quantity = 1;
						}

						if ($min_quantity <= $item['quantity'] ) {
							if (! empty($this->get_variable_wholesale_price($data[ $role ][ $variation_id ], $variation_id)) ) {
								
								/**
								* Hooks
								*
								* @since 3.0
								*/
								$price = apply_filters('wwp_override_product_price_cart_price', $this->get_variable_wholesale_price($data[ $role ][ $variation_id ], $variation_id), $item);
								$item['data']->set_price($price);
								$return_check = true;
								continue;
							} else {
							
								/**
								* Hooks
								*
								* @since 3.0
								*/
								$price = apply_filters('wwp_override_product_price_cart_price', get_post_meta($item['variation_id'], $price_key, true), $item);
								$item['data']->set_price($price);
								$return_check = true;
								continue;
							}
						} else {
						
							/**
							* Hooks
							*
							* @since 3.0
							*/
							$price = apply_filters('wwp_override_product_price_cart_price', get_post_meta($item['variation_id'], $price_key, true), $item);
							$item['data']->set_price($price);
							$return_check = true;
							continue;
						}
						if (true === $return_check ) {
							continue;
						}
					} else {
					
						/**
						* Hooks
						*
						* @since 3.0
						*/
						$price = apply_filters('wwp_override_product_price_cart_price', get_post_meta($item['variation_id'], $price_key, true), $item);
						$item['data']->set_price($price);
						$return_check = true;
					}
				}
					
				$terms = get_the_terms($item['product_id'], 'product_cat');
				if (! is_wp_error($terms) && ! empty($terms) ) {
					foreach ( $terms as $term ) {
						$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
						
						if (isset($data[ $role ]) ) {
						
							if (tire_variable_wholesale_product_price($item['variation_id'], wc_get_product($item['variation_id']), 'category') ) {
								$price = tire_variable_wholesale_product_price($item['variation_id'], wc_get_product($item['variation_id']), 'category');
								
								/**
								* Hooks
								*
								* @since 3.0
								*/
								$price = apply_filters('wwp_override_product_price_cart_price', $price, $item);
								$item['data']->set_price($price);
								$return_check = true;
								continue;
							}
						
						}
						
						if (isset($data[ $role ]) ) {

							if (isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) && false === $return_check ) {
							
								$my = $data[ $role ];
								if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
									$wholesale_qty = (int) $my['min_quatity'];
								}
								if ($wholesale_qty <= $item['quantity'] ) {
								
									/**
									* Hooks
									*
									* @since 3.0
									*/
									$price = apply_filters('wwp_override_product_price_cart_price', $this->change_price(get_post_meta($item['variation_id'], $price_key, true), $my['discount_type'], $my['wholesale_price']), $item);
									$item['data']->set_price($price);
									$return_check = true;
									continue;
								} else {
								
									/**
									* Hooks
									*
									* @since 3.0
									*/
									$price = apply_filters('wwp_override_product_price_cart_price', get_post_meta($item['variation_id'], $price_key, true), $item);
									$item['data']->set_price($price);
									$return_check = true;
									continue;
								}
							}   
						}   
					}
					if (true === $return_check ) {
						continue;
					}
				}
				
				$data = get_option('wholesale_multi_user_pricing');
				if (isset($data[ $role ]) ) {
					if (tire_variable_wholesale_product_price($item['variation_id'], wc_get_product($item['variation_id']), 'global') ) { 
						$price = tire_variable_wholesale_product_price($item['variation_id'], wc_get_product($item['variation_id']), 'global');
						
						/**
						* Hooks
						*
						* @since 3.0
						*/
						$price = apply_filters('wwp_override_product_price_cart_price', $price, $item);
						$item['data']->set_price($price);
						$return_check = true;
						continue;
					}
				}
				
				if (isset($data[ $role ]) ) {
				
					if (isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
						$product_id = $item['product_id'];

						if ( is_product_category_excluded_global($product_id) ) {
							continue;
						}
						$my = $data[ $role ];
						if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
							$wholesale_qty = $my['min_quatity'];
						}
						if ($wholesale_qty <= $item['quantity'] ) {
						
							/**
							* Hooks
							*
							* @since 3.0
							*/
							$price = apply_filters('wwp_override_product_price_cart_price', $this->change_price(get_post_meta($item['variation_id'], $price_key, true), $my['discount_type'], $my['wholesale_price']), $item);
							$item['data']->set_price($price);
							continue;
						} else {
						
							/**
							* Hooks
							*
							* @since 3.0
							*/
							$price = apply_filters('wwp_override_product_price_cart_price', get_post_meta($item['variation_id'], $price_key, true), $item);
							$item['data']->set_price($price);
							$return_check = true;
						}
						if (true === $return_check ) {
							continue;
						}
					} else {
					
						/**
						* Hooks
						*
						* @since 3.0
						*/
						$price = apply_filters('wwp_override_product_price_cart_price', get_post_meta($item['variation_id'], $price_key, true), $item);
						$item['data']->set_price($price);
						$return_check = true;
						continue;
					}

				}
			} else {

				$ws_group = wwp_get_group_post_by_proid($product_id, get_current_user_id());
				if ($ws_group ) { 
					$group_id = isset($ws_group[0]) ? $ws_group[0] : '';
					if (! empty($group_id) ) {
						$discount_type  = get_post_meta($group_id, '_discount_type', true);
						$min_quantity   = (int) get_post_meta($group_id, '_min_quantity', true);
						$min_quantity   = $min_quantity ? $min_quantity : 1;
						
						$max_quantity   = (int) get_post_meta($group_id, '_max_quantity', true);
						$max_quantity   = $max_quantity ? $max_quantity : PHP_INT_MAX;
						$wwp_price      = (float) get_post_meta($group_id, '_wwp_group_price', true);

						if (! empty($discount_type) && ! empty($wwp_price) && ! empty($min_quantity) && false === $return_check ) { 
							$regular_price = get_post_meta($item['product_id'], $price_key, true);
							if (empty($regular_price) || empty($wwp_price) ) {
								/**
								* Hooks
								*
								* @since 3.0
								*/
								$price = apply_filters('wwp_override_product_price_cart_price', $regular_price, $item);
								$item['data']->set_price($price);

								continue;
							}
							
							if ('fixed' == $discount_type ) {
								$price = $wwp_price;
							} else {
								$price = $regular_price * $wwp_price / 100;
							}
							$qty            = $item['quantity'];
							if ($qty >= $min_quantity && $qty <= $max_quantity ) {  
								/**
								* Filter
								*
								* @since 2.4
								*/
								$price = apply_filters('wwp_override_product_price_cart_price', $price, $item);
								$item['data']->set_price($price);
								$return_check = true;
								continue;
							}
						}
					}
				}
				$data = get_post_meta($item['product_id'], 'wholesale_multi_user_pricing', true);
				
				if (isset($data[ $role ]) ) {
					if (tire_variable_wholesale_product_price($item['product_id'], wc_get_product($item['product_id']), 'product') ) {
						$price = tire_variable_wholesale_product_price($item['product_id'], wc_get_product($item['product_id']), 'product');
						
						/**
						* Hooks
						*
						* @since 3.0
						*/
						$price = apply_filters('wwp_override_product_price_cart_price', $price, $item);
						$item['data']->set_price($price);
						$return_check = true;
						continue;
					}
				
					$my = $data[ $role ];
					if (isset($my['discount_type']) && ! empty($my['discount_type']) && isset($my['wholesale_price']) && ! empty($my['wholesale_price']) && isset($my['min_quatity']) && ! empty($my['min_quatity']) && false === $return_check ) {
						
						if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
							$wholesale_qty = (int) $my['min_quatity'];
						}
						if ($wholesale_qty <= $item['quantity'] ) {
							$price = $this->get_wholesale_price_multi($my['discount_type'], $my['wholesale_price'], $item['product_id']);

							if ('bundle' == $product->get_type() && 0 == $price ) {
								$item['data']->set_price($price);
								$return_check = true;
								continue;
							}
								
							if (! empty($price) ) {
							
								/**
								* Hooks
								*
								* @since 3.0
								*/
								$price = apply_filters('wwp_override_product_price_cart_price', $price, $item);
								$item['data']->set_price($price);
								$return_check = true;
								continue;
							}
						} else {
						
							/**
							* Hooks
							*
							* @since 3.0
							*/
							$price = apply_filters('wwp_override_product_price_cart_price', get_post_meta($item['product_id'], $price_key, true), $item);
							$item['data']->set_price($price);
							$return_check = true;
							continue;
						}
					} else {
						/**
						* Hooks
						*
						* @since 3.0
						*/
						$price = apply_filters('wwp_override_product_price_cart_price', get_post_meta($item['product_id'], $price_key, true), $item);
						$item['data']->set_price($price);
						$return_check = true;
						continue;
					}
				}

				$terms = get_the_terms($item['product_id'], 'product_cat');
				if (! is_wp_error($terms) && ! empty($terms) ) {

					foreach ( $terms as $term ) {
						$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);

						if (isset($data[ $role ]) ) {
						
							if (tire_variable_wholesale_product_price($item['product_id'], wc_get_product($item['product_id']), 'category') ) {
								$price = tire_variable_wholesale_product_price($item['product_id'], wc_get_product($item['product_id']), 'category');
								
								/**
								* Hooks
								*
								* @since 3.0
								*/
								$price = apply_filters('wwp_override_product_price_cart_price', $price, $item);
								$item['data']->set_price($price);
								$return_check = true;
								break;
							}
						}

						if (isset($data[ $role ]) ) {

							if (isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) && false === $return_check ) {
								$my = $data[ $role ];
								if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
									$wholesale_qty = (int) $my['min_quatity'];
								}
								if ($wholesale_qty <= $item['quantity'] ) {

									/**
									* Hooks
									*
									* @since 3.0
									*/                                      
									$price = apply_filters('wwp_override_product_price_cart_price', $this->change_price(get_post_meta($item['product_id'], $price_key, true), $my['discount_type'], $my['wholesale_price']), $item);
									$item['data']->set_price($price);
									$return_check = true;
									break;
								} else {
									/**
									* Hooks
									*
									* @since 3.0
									*/
									$price = apply_filters('wwp_override_product_price_cart_price', get_post_meta($item['product_id'], $price_key, true), $item);
									$item['data']->set_price($price);
									$return_check = true;
									continue;
								}
							
							} else {
							
								/**
								* Hooks
								*
								* @since 3.0
								*/
								$price = apply_filters('wwp_override_product_price_cart_price', get_post_meta($item['product_id'], $price_key, true), $item);
								$item['data']->set_price($price);
								$return_check = true;
								continue;
							}
							
						}
					}
					if (true === $return_check ) {
						continue;
					}
				}
				
				$data = get_option('wholesale_multi_user_pricing');
				
				if (isset($data[ $role ]) ) {
					if ( is_product_category_excluded_global($item['product_id']) ) {
						continue;
					}
					if (tire_variable_wholesale_product_price($item['product_id'], wc_get_product($item['product_id']), 'global') ) { 
						$price = tire_variable_wholesale_product_price($item['product_id'], wc_get_product($item['product_id']), 'global');
						/**
						* Hooks
						*
						* @since 3.0
						*/
						$price = apply_filters('wwp_override_product_price_cart_price', $price, $item);
						$item['data']->set_price($price);
						$return_check = true;
						continue;
					}
				}

				if (isset($data[ $role ]) ) {
				
					if (isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
						$product_id = $item['product_id'];

						if ( is_product_category_excluded_global($product_id) ) {
							continue;
						}
						$my = $data[ $role ];
						if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
							$wholesale_qty = $my['min_quatity'];
						}

						if ($wholesale_qty <= $item['quantity'] ) {
						
							/**
							* Hooks
							*
							* @since 3.0
							*/
							$price = apply_filters('wwp_override_product_price_cart_price', $this->change_price(get_post_meta($item['product_id'], $price_key, true), $my['discount_type'], $my['wholesale_price']), $item);

							//compatibility for bundle products
							if ('bundle' === $product->get_type() && !empty($product->get_price()) ) {
								/**
								 * Hooks
								 * 
								 *  @since 3.0
								 */
								$price = apply_filters('wwp_override_product_price_cart_price', $this->change_price($product->get_price(), $my['discount_type'], $my['wholesale_price']), $item);
								$item['data']->set_price($price);
							}
							
							if ('bundle' != $product->get_type() ) {
								$item['data']->set_price($price);
							}

							continue;
						} else {
						
							/**
							* Hooks
							*
							* @since 3.0
							*/
							$price = apply_filters('wwp_override_product_price_cart_price', get_post_meta($item['product_id'], $price_key, true), $item);

							$item['data']->set_price($price);
							$return_check = true;
							continue;
						}
						if (true === $return_check ) {
							continue;
						}
					} else {
					
						/**
						* Hooks
						*
						* @since 3.0
						*/
						$price = apply_filters('wwp_override_product_price_cart_price', get_post_meta($item['product_id'], $price_key, true), $item);
						$item['data']->set_price($price);
						$return_check = true;
						continue;
					}
				}
			}
		}
	}
}
