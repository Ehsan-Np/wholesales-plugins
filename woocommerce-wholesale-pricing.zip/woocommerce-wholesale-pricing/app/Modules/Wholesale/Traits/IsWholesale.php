<?php
/**
 * Trait IsWholesale.
 *
 * Provides a core method to determine if wholesale pricing rules should be applied
 * to a specific product for the currently logged-in user or the determined guest role.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

trait IsWholesale {


	/**
	 * Trait containing methods for accessing global and multi-user wholesale settings.
	 */
	use WholesaleSettings;

	/**
	 * Checks if a product qualifies for wholesale pricing based on a hierarchy:
	 * Product > Category > Global settings.
	 *
	 * @param  int $product_id The ID of the product to check.
	 * @return bool True if wholesale pricing applies to the product, false otherwise.
	 */
	public function is_wholesale( $product_id ) {
		$role = get_current_user_role_id();
		if (wwp_guest_wholesale_pricing_enabled() ) {
			if (( is_shop() && ! wwp_guest_wholesale_pricing_enabled('display_on_shop') ) || ( is_product() && ! wwp_guest_wholesale_pricing_enabled('display_on_single') ) ) {
				return false;
			}
			$role = wwp_guest_wholesale_pricing_enabled('role');
		}
		$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
		if (isset($data[ $role ]) ) {
			return true;
		}
		
		$terms = get_the_terms($product_id, 'product_cat');
		if (! is_wp_error($terms) && ! empty($terms) ) {
			foreach ( $terms as $term ) {
				$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
				if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
					return true;
				}
			}
		}
		$data = self::get_multiuser_pricing_settings();
		if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
			return true;
		}
		return false;
	}
}
