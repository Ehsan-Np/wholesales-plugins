<?php
/**
 * Trait WholesaleCartSubtotalDiscount.
 *
 * This trait contains the logic for validating the cart contents against
 * global wholesale requirements, specifically minimum order subtotal and
 * individual product minimum quantities.
 *
 * It is typically used to determine if wholesale prices should be applied
 * at the cart level or if retail prices should be enforced.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

trait WholesaleCartSubtotalDiscount {

	/**
	 * Trait to access general wholesale settings.
	 */
	use WholesalePrice;

	/**
	 * Checks if the current user's cart meets the wholesale requirements
	 * based on minimum subtotal and minimum item quantities.
	 *
	 * @param  string $context Determines the return type:
	 *                         - '' (empty): Returns boolean (true/false) for logic checks.
	 *                         - 'view': Returns an array or string of messages for frontend display.
	 * @return bool|array|string True if all conditions are met, false if not met (default context),
	 * or formatted messages/string if context is 'view'.
	 */
	public function wholesale_pricing_cart_based_on_subtotal( $context = '' ) {

		$global_settings    = get_option('wholesale_multi_user_pricing');
		$role               = get_current_user_role_id();
		
		if (is_admin() && ! defined('DOING_AJAX') ) {
			return true;
		}

		if (! is_user_logged_in() && ! is_wholesaler_user(get_current_user_id()) ) {
			return true;
		}

		// return if Min Subtotal featured is disabled
		if (! isset($global_settings[$role]) || ! isset($global_settings[$role]['min_subtotal']) || empty($global_settings[$role]['min_subtotal']) || 0 == $global_settings[$role]['min_subtotal'] ) {
			return true;
		}

		$cart_total     = 0;
		$cart_items     = 0;
		$min_quantity   = 0;
		$min_subtotal   = $global_settings[$role]['min_subtotal'];
		$quantity_check =  false;

		foreach ( WC()->cart->cart_contents as $cart_item_key => $cart_item ) {

			$wholesale_price = '';

			if ($cart_item['data'] instanceof \WC_Product ) {
				$wholesale_price = (float) $this->wwp_get_wholesale_price($cart_item['data']);
				$quantity = (int) $cart_item['quantity'];
				$cart_total += $wholesale_price * $quantity;
				$cart_items += $quantity;

				if (! empty($global_settings[$role]['min_quatity']) && $global_settings[$role]['min_quatity'] > 0 ) {
					$min_quantity = $global_settings[$role]['min_quatity'];
				}

				// min quantity check in category discount
				$terms = get_the_terms($cart_item['data']->get_id(), 'product_cat');

				if (! is_wp_error($terms) && ! empty($terms) ) {

					foreach ( $terms as $term ) {
						$category_discount = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);

						if (isset($category_discount[$role]['min_quatity']) ) {
							$min_quantity = $category_discount[$role]['min_quatity'];
						}
					}
				}
				
				// min quantity check in product discount
				$product_discount = get_post_meta($cart_item['data']->get_id(), 'wholesale_multi_user_pricing', true);

				if (isset($product_discount[$role]['min_quatity']) ) {
					$min_quantity = $product_discount[$role]['min_quatity'];
				}

			}

			$flag = false;
			if (! ( $cart_total >= $min_subtotal ) && 0 != $cart_total ) {
				$flag = true;
				continue;
			}

			if ('view' == $context && true == $flag ) {
				$min_qty_messages['min_order_subtotal'] = sprintf(
					/* translators: 1: Minimum order subtotal, 2: Current wholesale subtotal */
					__(
						'You have not met the minimum order subtotal of <strong>(%1$s)</strong> to activate adjusted pricing. Retail prices will be shown below until the minimum order threshold is met. The cart subtotal calculated with wholesale prices is <strong>(%2$s)</strong>',
						'woocommerce-wholesale-pricing'
					),
					wc_price( $min_subtotal ),
					wc_price( $cart_total )
				);
			}

			if (( ! empty($min_quantity) && $min_quantity > 0 ) && ! ( (int) $cart_item['quantity'] >= $min_quantity ) ) {
				$min_qty_messages[] = sprintf(
					/* translators: 1: Minimum quantity, 2: Product title */
					__(
						'You have not met the minimum quantity <strong>(%1$s)</strong> for the product %2$s.',
						'woocommerce-wholesale-pricing'
					),
					$min_quantity,
					$cart_item['data']->get_title()
				);
			}
		}

		if (! empty($min_qty_messages) && count($min_qty_messages) > 0 ) {
			if ('view' == $context ) {
				return $min_qty_messages;
			}
			return false;

		} elseif (! ( $cart_total >= $min_subtotal ) && 0 != $cart_total ) {
			if ('view' == $context ) {
				$message = sprintf(
					/* translators: 1: Minimum order subtotal, 2: Current wholesale subtotal */
					__(
						'You have not met the minimum order subtotal of <strong>(%1$s)</strong> to activate adjusted pricing. Retail prices will be shown below until the minimum order threshold is met. The cart subtotal calculated with wholesale prices is <strong>(%2$s)</strong>',
						'woocommerce-wholesale-pricing'
					),
					wc_price( $min_subtotal ),
					wc_price( $cart_total )
				);
				return $message;
			}
			return false;
		} else {
			return true;
		}
	}
}
