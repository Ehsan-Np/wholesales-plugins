<?php
/**
 * Trait CartValidation.
 *
 * Provides methods for validating cart items, specifically ensuring that a
 * wholesale user meets the minimum quantity requirements before the item is
 * successfully added to the cart.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Traits
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Traits;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

trait CartValidation {


	/**
	 * Trait to access general wholesale settings.
	 */
	use WholesaleSettings;

	/**
	 * Trait containing helper methods to check if an item is under wholesale rules.
	 */
	use IsWholesale;

	/**
	 * Validates if the quantity of the product being added to the cart meets
	 * the minimum required quantity for wholesale pricing.
	 *
	 * Note: The function name "add_the_date_validation" seems to be a legacy name
	 * and its purpose is quantity validation.
	 *
	 * The hierarchy checks for minimum quantity requirements:
	 * 1. Variation Level (if applicable)
	 * 2. Product Level (Simple Product)
	 * 3. Category Level
	 * 4. Global Level
	 *
	 * @since  2.4.0
	 * @param  bool   $passed       Whether the validation has already passed.
	 * @param  int    $product_id   The product ID (parent product ID for variations).
	 * @param  int    $quantity     The quantity being added to the cart.
	 * @param  string $variation_id The variation ID, if applicable.
	 * @param  string $variations   Array of variation attributes, if applicable (unused).
	 * @return bool True if validation passes, false otherwise (and adds a WooCommerce notice).
	 */
	public function add_the_date_validation( $passed, $product_id, $quantity, $variation_id = '', $variations = '' ) {
		
		if ($this->is_wholesale($product_id) ) {
			
			$settings = self::get_pricing_settings();
			if ('yes' == $settings['wholesaler_allow_minimum_qty'] ) {
				$role         = get_current_user_role_id();
				$min_quantity = 1;
				
				if (! empty($variation_id) ) {
					$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);

					if (isset($data[ $role ][ $variation_id ]['qty']) ) {
						$min_quantity = $data[ $role ][ $variation_id ]['qty'];

						if (empty($min_quantity) || ! isset($min_quantity) ) {
							$min_quantity = 1;
						}
						if ($min_quantity > $quantity ) {

							/* translators: %s: wholesale price on minmum */
							$textqty = sprintf(esc_html__('Wholesale price will only be applied to a minimum quantity of %1$s products', 'woocommerce-wholesale-pricing'), $min_quantity);
							
							/**
							* Hooks
							*
							* @since 3.0
							*/
							wc_add_notice(__(apply_filters('wwp_product_minimum_quantity_text', $textqty, $min_quantity), 'woocommerce'), 'error');
							return false;

						} else {
							return true;
						}
					}

					$terms = get_the_terms($product_id, 'product_cat');

					if (! is_wp_error($terms) && ! empty($terms) ) {
						foreach ( $terms as $term ) {

							$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);

							if (isset($data[ $role ]['min_quatity']) ) {
								$min_quantity = (int) $data[ $role ]['min_quatity'];

								if (empty($min_quantity) || ! isset($min_quantity) ) {
									$min_quantity = 1;
								}

								if ($min_quantity > $quantity ) {

									/* translators: %s: wholesale price on minmum */
									$textqty = sprintf(esc_html__('Wholesale price will only be applied to a minimum quantity of %1$s products', 'woocommerce-wholesale-pricing'), $min_quantity);
									
									/**
									* Hooks
									*
									* @since 3.0
									*/                      
									wc_add_notice(__(apply_filters('wwp_product_minimum_quantity_text', $textqty, $min_quantity), 'woocommerce'), 'error');
									return false;
								} else {
									return true;
								}
							}
						}
					}
					$data = get_option('wholesale_multi_user_pricing');
					if (isset($data[ $role ]['min_quatity']) ) {
						$min_quantity = $data[ $role ]['min_quatity'];

						if (empty($min_quantity) || ! isset($min_quantity) ) {
							$min_quantity = 1;
						}
						if ($min_quantity > $quantity ) {
							/* translators: %s: wholesale price on minmum */
							$textqty = sprintf(esc_html__('Wholesale price will only be applied to a minimum quantity of %1$s products', 'woocommerce-wholesale-pricing'), $min_quantity);
							
							/**
							* Hooks
							*
							* @since 3.0
							*/
							wc_add_notice(__(apply_filters('wwp_product_minimum_quantity_text', $textqty, $min_quantity), 'woocommerce'), 'error');
							return false;
						} else {
							return true;
						}
					}
				} else {

					$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);

					if (isset($data[ $role ]['min_quatity']) ) {
						$min_quantity = $data[ $role ]['min_quatity'];

						if (empty($min_quantity) || ! isset($min_quantity) ) {
							$min_quantity = 1;
						}
						if ($min_quantity > $quantity ) {

							/* translators: %s: wholesale price on minmum */
							$textqty = sprintf(esc_html__('Wholesale price will only be applied to a minimum quantity of %1$s products', 'woocommerce-wholesale-pricing'), $min_quantity);
							
							/**
							* Hooks
							*
							* @since 3.0
							*/                              
							wc_add_notice(__(apply_filters('wwp_product_minimum_quantity_text', $textqty, $min_quantity), 'woocommerce'), 'error');
							return false;
						} else {
							return true;
						}
					}

					$terms = get_the_terms($product_id, 'product_cat');
					if (! is_wp_error($terms) && ! empty($terms) ) {
						foreach ( $terms as $term ) {
							$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);

							if (isset($data[ $role ]['min_quatity']) ) {
								$min_quantity = $data[ $role ]['min_quatity'];

								if (empty($min_quantity) || ! isset($min_quantity) ) {
									$min_quantity = 1;
								}
								if ($min_quantity > $quantity ) {

									/* translators: %s: wholesale price on minmum */
									$textqty = sprintf(esc_html__('Wholesale price will only be applied to a minimum quantity of %1$s products', 'woocommerce-wholesale-pricing'), $min_quantity);
									
									/**
									* Hooks
									*
									* @since 3.0
									*/
									wc_add_notice(__(apply_filters('wwp_product_minimum_quantity_text', $textqty, $min_quantity), 'woocommerce'), 'error');
									return false;

								} else {
									return true;
								}
							}
						}
					}

					$data = get_option('wholesale_multi_user_pricing');
					if (isset($data[ $role ]['min_quatity']) ) {
						$min_quantity = $data[ $role ]['min_quatity'];

						if (empty($min_quantity) || ! isset($min_quantity) ) {
							$min_quantity = 1;
						}
						if ($min_quantity > $quantity ) {

							/* translators: %s: wholesale price on minmum */
							$textqty = sprintf(esc_html__('Wholesale price will only be applied to a minimum quantity of %1$s products', 'woocommerce-wholesale-pricing'), $min_quantity);
							/**
							* Hooks
							*
							* @since 3.0
							*/
							wc_add_notice(__(apply_filters('wwp_product_minimum_quantity_text', $textqty, $min_quantity), 'woocommerce'), 'error');
							return false;

						} else {
							return true;
						}
					}
				}/// else end
			}
		}
		return true;
	}
}
