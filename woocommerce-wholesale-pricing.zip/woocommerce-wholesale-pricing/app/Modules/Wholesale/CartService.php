<?php
/**
 * CartService class for handling wholesale pricing logic within the WooCommerce cart flow.
 *
 * This class orchestrates various pricing modifications, quantity validation, and compatibility
 * features for wholesale users across the product, cart, and checkout pages.
 *
 * @package    WooCommerceWholesalePricing\App\Modules\Wholesale
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale;

use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\IsWholesale;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\StepQuantity;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\CartValidation;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Compatibility\MixMatch;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\RegularPriceChange;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Compatibility\Subscription;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\ProductPriceHTML;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\VariablePriceHTML;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Compatibility\ProductAddons;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Compatibility\ProductBundle;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\BeforeCalculateTotals;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\ReflectionPrivateInvokation;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\WholesaleCartSubtotalDiscount;

/**
 * Class CartService
 *
 * Handles all cart and product display related functionalities for wholesale pricing.
 */
class CartService {


	// Use utility traits to handle specific aspects of the wholesale cart logic.
	use ProductPriceHTML;
	use VariablePriceHTML;
	use RegularPriceChange;
	use BeforeCalculateTotals;
	use CartValidation;
	use IsWholesale;
	use WholesaleCartSubtotalDiscount;
	use Subscription;
	use ReflectionPrivateInvokation;
	use StepQuantity;

	/**
	 * Array of compatibility modules to be loaded.
	 *
	 * @var Hookable[]
	 */
	protected $modules = array();

	/**
	 * Flag to indicate if a tier pricing table should be displayed.
	 *
	 * @var bool
	 */
	private $tier_table = false;

	/**
	 * Holds a reference to a WC_Product object for temporary use.
	 *
	 * @var \WC_Product|null
	 */
	private $product_obj = null;

	/**
	 * CartService constructor.
	 *
	 * Initializes the class and registers all necessary WordPress/WooCommerce hooks.
	 */    
	public function __construct() {
		
		$this->modules = array(
			new MixMatch(),
			new ProductBundle(),
			new ProductAddons(),
		);

		// Product and Price Display Hooks
		add_filter('woocommerce_get_price_html', array( $this, 'wwp_change_product_price_display' ), 200, 2);

		// Cart Calculation Hooks
		add_action('woocommerce_before_calculate_totals', array( $this, 'wwp_override_product_price_cart' ), 200);
		add_action('woocommerce_after_calculate_totals', array( $this, 'wwp_override_price_filter_on' ), 200);

		// Temporary Price Filter Removal/Re-addition for Cart Display
		add_filter('woocommerce_before_cart', array( $this, 'woocommerce_before_cart' ), 200);
		add_filter('woocommerce_after_cart_table', array( $this, 'woocommerce_after_cart_table' ), 200);

		// Add to Cart Validation
		add_filter('woocommerce_add_to_cart_validation', array( $this, 'add_the_date_validation' ), 200, 5);

		// Quantity Step Hooks
		add_filter('woocommerce_quantity_input_args', array( $this, 'wwp_filter_woocommerce_quantity_input_args' ), 10, 2);
		add_filter('woocommerce_loop_add_to_cart_args', array( $this, 'wwp_filter_woocommerce_quantity_input_args' ), 10, 2);
		add_filter('woocommerce_store_api_product_quantity_multiple_of', array( $this, 'wwp_filter_woocommerce_quantity_step_block_cart' ), 10, 2);
		add_action('woocommerce_cart_contents', array( $this, 'woocommerce_cart_contents' ));

		// Tier Pricing Table Hooks
		add_action('woocommerce_single_variation', array( $this, 'variation_load_tire_priceing_table' ));
		add_action('woocommerce_before_add_to_cart_form', array( $this, 'simple_load_tire_priceing_table' ));
		add_action('woocommerce_before_mini_cart_contents', array( $this, 'woocommerce_before_mini_cart_contents' ));
		add_action('woocommerce_store_api_cart_errors', array( $this, 'woocommerce_cart_min_subtotal_errors' ));

		/**
		 * Filter 
		 * 
		 * @var string hook
		 * 
		 * @since 2.1.0
		 */
		$hook = apply_filters('wwp_hook_for_min_subtotal', 'woocommerce_before_cart_table');
		add_action($hook, array( $this, 'woocommerce_cart_min_subtotal_errors' ));
		
		// Subscription Compatibility Hook
		add_filter('woocommerce_subscriptions_product_price_string', array( $this, 'woocommerce_subscriptions_product' ), 10, 3);

		// Request for Sample Feature Hook
		add_action('woocommerce_after_add_to_cart_button', array( $this, 'show_content_after_add_to_cart' ));

		// Exploded Variation Display Hooks
		add_filter('woocommerce_dropdown_variation_attribute_options_html', array( $this, 'wwp_explode_variation_display' ), 10, 2);
		add_action('wp_loaded', array( $this, 'add_to_cart_multiple_variation' ), 10);

		// Custom Body Class for styling
		add_filter('body_class', array( $this, 'wwp_custom_class' ));
		add_action('template_redirect', array( $this, 'request_sample_template_redirect' ));

		// Cart Total Discount Hook
		add_action('woocommerce_cart_calculate_fees', array( $this, 'discount_based_on_total' ), 10, 1);

		$this->loadModules();
	}

	/**
	 * Removes wholesale price display filters before the cart table is rendered.
	 *
	 * This is typically done to prevent the cart page's item price from showing the
	 * single-product price HTML, allowing cart templates to handle pricing correctly.
	 *
	 * @hook woocommerce_before_cart
	 *
	 * @return void
	 */
	public function woocommerce_before_cart() {
		remove_filter('woocommerce_get_price_html', array( $this, 'wwp_change_product_price_display' ), 200, 2);
		remove_filter('woocommerce_variable_sale_price_html', array( $this, 'wwp_variable_price_format' ), 200, 2);
		remove_filter('woocommerce_variable_price_html', array( $this, 'wwp_variable_price_format' ), 200, 2);
		remove_filter('woocommerce_cart_item_price', array( $this, 'wwp_change_product_price_display' ), 200, 2);
	}

	/**
	 * Re-adds wholesale price display filters after the cart table is rendered.
	 *
	 * Ensures that the price display filters are active again for other elements
	 * on the page outside the main cart table.
	 *
	 * @hook woocommerce_after_cart_table
	 *
	 * @return void
	 */
	public function woocommerce_after_cart_table() {
		add_filter('woocommerce_get_price_html', array( $this, 'wwp_change_product_price_display' ), 200, 2);
		add_filter('woocommerce_variable_sale_price_html', array( $this, 'wwp_variable_price_format' ), 200, 2);
		add_filter('woocommerce_variable_price_html', array( $this, 'wwp_variable_price_format' ), 200, 2);
		add_filter('woocommerce_cart_item_price', array( $this, 'wwp_change_product_price_display' ), 200, 2);
	}

	/**
	 * Turns price filter hooks back on after cart totals have been calculated.
	 *
	 * These filters are typically removed during cart calculation to prevent recursion,
	 * but need to be active for subsequent price lookups.
	 *
	 * @hook woocommerce_after_calculate_totals
	 *
	 * @return void
	 */
	public function wwp_override_price_filter_on() {
		// Skip for WooCommerce Store API requests where the locale is 'site'.
		if (isset($_REQUEST['_locale']) && 'site' == $_REQUEST['_locale'] ) { 
			return;
		}
		// Re-add filters to apply wholesale price as the "regular" price.
		add_filter('woocommerce_product_get_price', array( $this, 'wwp_regular_price_change' ), 200, 2);
		add_filter('woocommerce_product_variation_get_price', array( $this, 'wwp_regular_price_change' ), 200, 2);
		add_filter('woocommerce_product_get_regular_price', array( $this, 'wwp_regular_price_change' ), 200, 2);
		add_filter('woocommerce_product_variation_get_regular_price', array( $this, 'wwp_regular_price_change' ), 200, 2);
		add_filter('woocommerce_get_price_html', array( $this, 'wwp_change_product_price_display' ), 200, 2);
		add_filter('woocommerce_cart_item_price', array( $this, 'wwp_change_product_price_display' ), 200, 2);
	}

	/**
	 * Removes the quantity input arguments filter during cart contents display.
	 *
	 * This is done to prevent the filter from interfering with cart item quantity fields,
	 * where minimum/step quantities are often handled differently than on the product page.
	 *
	 * @hook woocommerce_cart_contents
	 *
	 * @return void
	 */
	public function woocommerce_cart_contents() {
		remove_filter('woocommerce_quantity_input_args', array( $this, 'wwp_filter_woocommerce_quantity_input_args' ), 10, 2);
	}

	/**
	 * Filters the quantity step value for products in the WooCommerce Store API (e.g., Blocks).
	 *
	 * Applies wholesale step quantities based on product or category settings for the current user role.
	 *
	 * @hook woocommerce_store_api_product_quantity_multiple_of
	 *
	 * @param  int|float   $value   The current quantity multiple of value.
	 * @param  \WC_Product $product The product object.
	 * @return int|float The modified step quantity value.
	 */
	public function wwp_filter_woocommerce_quantity_step_block_cart( $value, $product ) {
		if ($this->is_wholesale($product->get_id()) ) {
			$role     = get_current_user_role_id();
			if (( 'object' == gettype($product) ) ) {
				if ('simple' == $product->get_type() ) {
					$terms = get_the_terms($product->get_id(), 'product_cat');
					if (! is_wp_error($terms) && ! empty($terms) ) {
						foreach ( $terms as $term ) {
							$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
							if (isset($data[$role]['step_quantity']) && !empty($data[$role]['step_quantity']) ) {
								$wp_parse_args['step'] = $data[$role]['step_quantity'];
								if (isset($data[$role]['min_quatity']) && !empty($data[$role]['min_quatity']) ) {
									return $data[$role]['step_quantity'];
								}
							}
						}
					}
					$data = get_post_meta($product->get_id(), 'wholesale_multi_user_pricing', true);
					if (isset($data[$role]['step_quantity']) && !empty($data[$role]['step_quantity']) ) {
						$wp_parse_args['step'] = $data[$role]['step_quantity'];
						if (isset($data[$role]['min_quatity']) && !empty($data[$role]['min_quatity']) ) {
							$wp_parse_args['min_value'] = $data[$role]['min_quatity'];
							return $data[$role]['step_quantity'];
						}
					} 
				} elseif ('variation' == $product->get_type() ) { 
				
					$product_id = wp_get_post_parent_id($product->get_id());
					$terms      = get_the_terms($product_id, 'product_cat');
					if (! is_wp_error($terms) && ! empty($terms) ) {
						foreach ( $terms as $term ) {
							$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
							if (isset($data[$role]['step_quantity']) && !empty($data[$role]['step_quantity']) ) {
								$wp_parse_args['step'] = $data[$role]['step_quantity'];
								if (isset($data[$role]['min_quatity']) && !empty($data[$role]['min_quatity']) ) {
									$wp_parse_args['min_value'] = $data[$role]['min_quatity'];
									return $data[$role]['step_quantity'];
								}
							}
						}
					}
					
					$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
					if (isset($data[$role][$product->get_id()]['step']) && !empty($data[$role][$product->get_id()]['step']) ) {
						$wp_parse_args['step'] = $data[$role][$product->get_id()]['step'];
						if (isset($data[$role][$product->get_id()]['qty']) && !empty($data[$role][$product->get_id()]['qty']) ) {
							$wp_parse_args['min_value'] = $data[$role][$product->get_id()]['qty'];
							if (isset($data[$role]['step_quantity']) ) {
								return $data[$role]['step_quantity'];
							}
						}
					}
				
				}
			}
		} 
		return $value;
	}

	 /**
	  * Loads the tier pricing table for a variable product variation.
	  *
	  * Renders a placeholder table that will be dynamically populated via JavaScript
	  * when a variation is selected.
	  *
	  * @hook woocommerce_single_variation
	  *
	  * @param  int|string $p_id Optional. The ID of the product variation.
	  * @return void
	  */
	public function variation_load_tire_priceing_table( $p_id = '' ) {
		
		$curent_veration_id = !empty($p_id) ? $p_id : get_the_ID();
		$product            = new \WC_Product_Variable($curent_veration_id);
		$role               = get_current_user_role_id();
		$variables          = $product->get_available_variations();

		if ($product->get_type() == 'simple' ) {
			return;
		}

		$product_tier_pricing = wholesale_tire_prices($product);
		if (!empty($product_tier_pricing) && $this->is_tier_pricing_enabled($product) ) { 
			if (! empty($variables) ) {
				wp_nonce_field('wwp_tier_load', 'wwp_tier_load');
				?>
				<table id="wholesale_tire_price" style="width:100%; display:none;">
					<tr></tr>
				</table>
				<?php
			}
		}
	}

	/**
	 * Loads and displays the tier pricing table for a simple product.
	 *
	 * Renders the full tier pricing table directly for simple products.
	 *
	 * @hook woocommerce_before_add_to_cart_form
	 *
	 * @param  int|string $p_id Optional. The ID of the product.
	 * @return void
	 */
	public function simple_load_tire_priceing_table( $p_id = '' ) {
			
		$product_id = !empty($p_id) ? $p_id : get_the_ID();
		$product    = wc_get_product($product_id);

		// Bulk Order Compatibility
		if (! $product ) {
			return;
		}

		if ($product->get_type() == 'variable' || $product->get_type() == 'variable-subscription' ) {
			return;
		}
		$table_product = $product;
		$role = get_current_user_role_id();
		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );
		$product_tier_pricing = wholesale_tire_prices($product);

		if (! empty($product_tier_pricing) && $this->is_tier_pricing_enabled($product) ) {
			?>
			<table id="wholesale_tire_price" style="width:100%">
				<tr>
					<th><?php esc_html_e('Quantity', 'woocommerce-wholesale-pricing'); ?></th>
					<th><?php esc_html_e('Save Discount', 'woocommerce-wholesale-pricing'); ?></th>
					<th><?php esc_html_e('Price per unit', 'woocommerce-wholesale-pricing'); ?></th>
				</tr>
				<?php
				foreach ( $product_tier_pricing[ $role ] as $product_data ) {
					if (isset($product_data['price']) && ! empty($product_data['price']) ) {
						$max_original_variation_price = get_post_meta($product_id, $price_key, true);
						if (empty($max_original_variation_price) ) { 
							$max_original_variation_price = 1;
						}
						$max_wholesale_price          = tire_get_type($product_id, $product, $product_data['price'], $max_original_variation_price, $product_tier_pricing[ $role ]['discount_type']);
						$max_wholesale_price          = $this->apply_dynamic_raise_to_tier_price( $max_wholesale_price, $table_product );
						$max_saving_percent           = ( $max_original_variation_price - $max_wholesale_price ) / $max_original_variation_price * 100;
						$max_saving_percent           = round($max_saving_percent);
						$max_wholesale_price          = wwp_get_price_including_tax($product, array( 'price' => $max_wholesale_price ));
						$max_wholesale_price          = wc_price($max_wholesale_price);
							
						if (!empty($product_data['min']) || !empty($product_data['max']) || 0 != $max_saving_percent) {
							?>
									<tr class="wrap_<?php esc_attr_e($product_id); ?> row_tire" data-id="<?php esc_attr_e($product_id); ?>" data-min="<?php esc_attr_e($product_data['min']); ?>" data-max="<?php esc_attr_e($product_data['max']); ?>">
										<td> <?php echo wp_kses_post($product_data['min'] . '-' . $product_data['max']); ?> </td>
										<td> <?php esc_attr_e($max_saving_percent); ?>% </td>
										<td> <?php echo wp_kses_post($max_wholesale_price); ?> </td>
									</tr>
								<?php
						}
					}
				}
				?>
			</table>
			<?php
		}
	}

	/**
	 * Displays a "Request For Sample" button after the add-to-cart button.
	 *
	 * Checks settings and product meta to determine if the sample request feature is enabled.
	 *
	 * @hook woocommerce_after_add_to_cart_button
	 *
	 * @return void
	 */
	public function show_content_after_add_to_cart() {
		$settings          = self::get_pricing_settings();
		$enable            = get_post_meta(get_the_ID(), 'request_for_sample_enable', true);
		$sample_product_id = get_post_meta(get_the_ID(), 'sample_product_id_hidden', true);
		if (isset($settings['request_for_sample_enable']) && 'yes' == $settings['request_for_sample_enable'] && 'yes' == $enable && !empty($sample_product_id)) {
			$label = ! empty($settings['request_for_sample_label']) ? esc_attr($settings['request_for_sample_label']) : esc_html__('Get Sample', 'woocommerce-wholesale-pricing');
			?>
				<a href="?add-to-cart-sample=<?php echo esc_attr($sample_product_id); ?>&sample=request" class="button"><?php esc_html_e($label, 'woocommerce-wholesale-pricing'); ?></a>
			<?php
		}
	}

	/**
	 * Hooks into the mini-cart contents action to force recalculation of totals if needed.
	 *
	 * This is useful when mini-cart contents might be cached or require fresh data after
	 * an action that affects prices/totals (like a wholesale price change).
	 *
	 * @hook woocommerce_before_mini_cart_contents
	 *
	 * @return void
	 */
	public function woocommerce_before_mini_cart_contents() {
		/** 
		 * Filter Hook: wwp_before_mini_cart_contents
		 * 
		 * @since 2.4.7
		 * 
		 * Type: action
		 */
		if (apply_filters('wwp_before_mini_cart_contents', false) ) {
			if (! defined('WOOCOMMERCE_CART') ) { 
				define('WOOCOMMERCE_CART', true);
				WC()->cart->calculate_totals();
				WC()->cart->set_session();
				WC()->cart->maybe_set_cart_cookies();
			}   
		}
	}

	/**
	 * Displays cart min subtotal errors on the cart page or via the Store API.
	 *
	 * Uses the subtotal discount trait method to check for minimum requirements
	 * and adds a WooCommerce notice if requirements are not met.
	 *
	 * @hook woocommerce_store_api_cart_errors
	 * @hook wwp_hook_for_min_subtotal (via woocommerce_before_cart_table by default)
	 *
	 * @param  \WP_Error|array $errors Current errors object or array (used by Store API).
	 * @return \WP_Error|array The modified errors object or array.
	 */
	public function woocommerce_cart_min_subtotal_errors( $errors ) {
		wc_clear_notices(); // clear previous notices to avoid duplicates
		$message = $this->wholesale_pricing_cart_based_on_subtotal('view');

		if ( is_bool( $message ) || empty($message) ) {

			wc_clear_notices();
	
			if ( $errors instanceof \WP_Error ) {
				$errors->errors = array();
				$errors->error_data = array();
			}
	
			return;
		}

		if (! WC()->session ) {
			wc_load_cart();
		}

		if (! is_bool($message) && ( is_cart() || ( defined('REST_REQUEST') && REST_REQUEST ) ) ) {
			if (is_array($message) ) {
				foreach ( $message as $m ) {
					wc_add_notice($m, 'error');
					if ($errors instanceof \WP_Error ) {
						$errors->add(uniqid(), $m);
					}
				}
			} else {
				wc_add_notice($message, 'error');
			}
		}
	}

	/**
	 * Displays an exploded view of product variations with quantity inputs and wholesale pricing.
	 *
	 * Replaces the standard dropdown for a specified attribute with a custom table layout
	 * showing wholesale prices and quantity fields for each variation.
	 *
	 * @hook woocommerce_dropdown_variation_attribute_options_html
	 *
	 * @param  string $html The original dropdown HTML.
	 * @param  array  $args Arguments passed to the function (options, product, attribute, etc.).
	 * @return string The modified HTML or original HTML if feature is disabled.
	 */
	public function wwp_explode_variation_display( $html, $args ) {
		$settings = self::get_pricing_settings();

		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );
		if (isset($settings['variation_table_enable']) && 'yes' == $settings['variation_table_enable']) {
			$options               = $args['options'];
			$product               = $args['product'];
			$attribute             = $args['attribute'];  
			$name                  = $args['name'] ? $args['name'] : 'attribute_' . sanitize_title($attribute);
			$id                    = $args['id'] ? $args['id'] : sanitize_title($attribute);
			$class                 = $args['class'];
			$show_option_none      = $args['show_option_none'] ? true : false;
			$show_option_none_text = $args['show_option_none'] ? $args['show_option_none'] : __('Choose an option', 'woocommerce');
			$available_variations  = $product->get_available_variations();
			
			$wwp_variation_explode_eneble     = get_post_meta($product->get_id(), 'wwp_variation_explode_eneble', true);
			$wwp_variation_attribute_with_qty = get_post_meta($product->get_id(), 'wwp_variation_attribute_with_qty', true);
			
			
			if ('yes' == $wwp_variation_explode_eneble && !empty($wwp_variation_attribute_with_qty)) {
				if (empty($options) && ! empty($product) && ! empty($attribute) ) {
					$attributes = $product->get_variation_attributes();
					$options    = $attributes[ $attribute ];
				}
				
				if ($args['attribute'] == $wwp_variation_attribute_with_qty) {
					foreach ($available_variations as $key => $value) {
						$attrs            = array();
						$outofstock_class = '';
						foreach (wc_get_product($value['variation_id'])->get_variation_attributes() as $keys => $attr) {
							$attribute_match = strtolower(str_replace(' ', '-', $wwp_variation_attribute_with_qty));
							if ('attribute_' . $attribute_match != $keys) { 
								$attrs[$keys] =$attr;
							}
						} 
						$price       = get_post_meta($value['variation_id'], $price_key, true);
						$product_obj = wc_get_product($value['variation_id']);
						$w_price     = $this->wwp_regular_price_change($price, $product_obj);
						
						$w_price_convert    = number_format((float) $w_price, 2, '.', '');
						$w_price_convert    = wc_price($w_price_convert);
						$tax_display_suffix = wwp_get_tax_price_display_suffix($value['variation_id']);
						
						if ('outofstock' == $product_obj->get_stock_status()) {
							$outofstock_class = 'wwp_disable_variation';
						}
						?>
						<div style="" class="wwp_variation_wrap <?php echo esc_attr($outofstock_class); ?>" data-w-p="<?php echo esc_attr($w_price); ?>"  date-variation-id="<?php echo esc_attr($value['variation_id']); ?>"  data-attr-slug='<?php echo json_encode($attrs); ?>' name="<?php echo esc_attr($name); ?>" data-attribute_name="attribute_<?php echo esc_attr(sanitize_title($attribute)); ?>">
							<div class="wwp_variation_lable">
								<?php echo esc_attr($value['attributes'][$name]); ?>: <span class="wwp_variation_wholesale_price"><?php echo wp_kses_post($w_price_convert . ' ' . $tax_display_suffix); ?></span>  
							</div>
							<div class="wwp_quantity_box">
								<button type="button" class="minus" >-</button>
								<input type="number" class="wwp_quantitys get_variation_qty_<?php echo esc_attr($value['variation_id']); ?>" name="quantitys" value="1" min="0" title="Qty" autocomplete="off">
								<button type="button" class="plus" >+</button>
							</div>
							<div class="wwp_quantity_box_availability_html">
							<?php echo wp_kses_post($value['availability_html']); ?>
							</div>
						</div>
						<?php 
					}
				} else {
					return $html;
				}
			} else {
				return $html;
			}
		} else {
			return $html;
		}
	}

	/**
	 * Handles adding multiple variations to the cart simultaneously.
	 *
	 * This custom handler processes cart requests containing multiple product/quantity pairs
	 * typically generated by the exploded variation display table.
	 *
	 * @hook wp_loaded
	 *
	 * @param  bool $url Optional. Whether to return the redirect URL. Default is false.
	 * @return bool|string|void Returns redirect URL if processed, otherwise void.
	 */
	public function add_to_cart_multiple_variation( $url = false ) {
		$request = $_REQUEST;
		if (!isset($request['wwp_variation_add_to_cart']) ) {
			return;
		}
		
		if (! class_exists('WC_Form_Handler') || empty($_REQUEST['add-to-cart']) ) {
			return;
		}
		remove_action('wp_loaded', array( 'WC_Form_Handler', 'add_to_cart_action' ), 20);
		remove_filter('woocommerce_add_to_cart_validation', array( $this, 'add_the_date_validation' ), 200, 5);
		$product_ids = explode(',', $request['add-to-cart']);
		
		$count  = count($product_ids);
		$number = 0;
	
		foreach ( $product_ids as $id_and_quantity ) {
			$id_and_quantity = explode(':', $id_and_quantity);
			$product_id      = $id_and_quantity[0];
	
			$_REQUEST['quantity'] = ! empty($id_and_quantity[1]) ? absint($id_and_quantity[1]) : 1;
			if (isset($_REQUEST['quantity']) ) {
				$qty = sanitize_text_field($_REQUEST['quantity']);
			}
			if (++$number === $count ) {
				$_REQUEST['variation_id'] = $product_id;
				return \WC_Form_Handler::add_to_cart_action($url);
			}
			/**
			* Hooks
			*
			* @since 3.0
			*/
			$product_id        = apply_filters('woocommerce_add_to_cart_product_id', absint($product_id));
			$was_added_to_cart = false;
			$adding_to_cart    = wc_get_product($product_id);

			$variations_parent_id = wp_get_post_parent_id($product_id);
			$pass                 = $this->add_the_date_validation(true, $variations_parent_id, $qty, $product_id); 

			if (! $adding_to_cart || false == $pass ) {
				continue;
			}
			
			/**
			* Hooks
			*
			* @since 3.0
			*/
			$add_to_cart_handler = apply_filters('woocommerce_add_to_cart_handler', $adding_to_cart->get_type(), $adding_to_cart);
			
			if ('variable' === $add_to_cart_handler ) {
				$this->woo_hack_invoke_private_method('WC_Form_Handler', 'add_to_cart_handler_variable', $product_id);

			} elseif ('grouped' === $add_to_cart_handler ) {
				$this->woo_hack_invoke_private_method('WC_Form_Handler', 'add_to_cart_handler_grouped', $product_id);

			} elseif (has_action('woocommerce_add_to_cart_handler_' . $add_to_cart_handler) ) {
				/**
				* Hooks
				*
				* @since 3.0
				*/
				do_action('woocommerce_add_to_cart_handler_' . $add_to_cart_handler, $url);

			} else {
				$this->woo_hack_invoke_private_method('WC_Form_Handler', 'add_to_cart_handler_simple', $product_id);
			}
		}
	}

	/**
	 * Adds a custom body class to the `<body>` tag if the exploded variation feature is enabled.
	 *
	 * This class can be used for custom CSS styling specific to the exploded variation view.
	 *
	 * @hook body_class
	 *
	 * @param  string[] $classes Array of body classes.
	 * @return string[] Modified array of body classes.
	 */
	public function wwp_custom_class( $classes ) {
		$settings = self::get_pricing_settings();
		if (isset($settings['variation_table_enable']) && 'yes' == $settings['variation_table_enable']) {
			$wwp_variation_explode_eneble     = get_post_meta(get_the_ID(), 'wwp_variation_explode_eneble', true);
			$wwp_variation_attribute_with_qty = get_post_meta(get_the_ID(), 'wwp_variation_attribute_with_qty', true);
			if ('yes' == $wwp_variation_explode_eneble && !empty($wwp_variation_attribute_with_qty)) {
				$classes[] = 'wwp_variation_table_enable';
			}
		}
		return $classes;
	}

	/**
	 * Handles the redirection for the "Request for Sample" feature.
	 *
	 * Intercepts the `add-to-cart-sample` query string, adds the product to the cart,
	 * and redirects the user to the checkout page.
	 *
	 * @hook template_redirect
	 *
	 * @param  string $redirect_url The URL to redirect to (unused here, but part of hook signature).
	 * @return void
	 */
	public function request_sample_template_redirect( $redirect_url ) {
		$get = wwp_get_get_data();
		if (isset($get['sample']) && 'request' == $get['sample'] && !empty($get['add-to-cart-sample'])) {
			WC()->cart->add_to_cart($get['add-to-cart-sample']);
			wp_safe_redirect(wc_get_checkout_url());
			exit;
		}
	}

	/**
	 * Applies a discount to the cart total based on total price or total quantity.
	 *
	 * This is the Cart-Level Tiered Discount logic. It checks if the current cart total
	 * or quantity meets any configured discount tiers for the user's role and applies a fee.
	 *
	 * @hook woocommerce_cart_calculate_fees
	 *
	 * @param  \WC_Cart $cart The WooCommerce cart object.
	 * @return void
	 */
	public function discount_based_on_total( $cart ) {

		if (is_admin() && ! defined('DOING_AJAX') ) {
			return;
		}

		if (! is_user_logged_in() && ! is_wholesaler_user(is_user_logged_in()) ) {
			return;
		}
		$discount         = false;
		$cart_total       = $cart->cart_contents_total;
		$cart_quantity    = $cart->get_cart_contents_count();
		$role             = get_current_user_role_id();
		$data             = get_option('wholesale_multi_user_cart_discount');
		$settings         = get_option('cart_tire_preces', true);

		if (isset($data[$role]['discount_on']) && 'cart_discount_quantity' == $data[$role]['discount_on'] ) {
			$discount_on_cart = $cart_quantity;
			$cart_quantity_discount = true;
		} else {
			$discount_on_cart = $cart_total;
			$cart_quantity_discount = false;

		}
		

		if (isset($settings['tier_pricing'][ $role ]) && isset($data[ $role ]) ) {

			/**
			 * Filter Hooks
			 *
			 * @since 3.0
			 * @param bool $use_quantity Whether to force comparison by quantity.
			 * @param \WC_Cart $cart The cart object.
			 * @param string $role The current user role.
			 */
			$use_quantity   = apply_filters('wholesale_discount_use_quantity', false, $cart, $role);
			$compare_value  = $use_quantity || $cart_quantity_discount ? $cart_quantity : $cart_total;
			
			foreach ( $settings['tier_pricing'][ $role ] as $prices ) {
				$min_value = isset($prices['min']) ? (float) $prices['min'] : 0;
				$cart_max_value = isset($prices['cart_max']) ? $prices['cart_max'] : '';
				$max_value = isset($prices['max']) ? $prices['max'] : '';
				$label     = isset($prices['price']) && ! empty($prices['price']) ? $prices['price'] : __('Discount', 'woocommerce-wholesale-pricing');

				// for backword compatibilty
				if (empty($cart_max_value) ) {
					if ($compare_value >= $min_value && ! empty($max_value) ) {
						$discount        = wholesale_type_price($cart_total, $data[ $role ]['discount_type'], $max_value);
						$wholesale_label = $label;
					}
				} else if ($compare_value >= $min_value && $compare_value <= $cart_max_value && ! empty($max_value) ) {
					$discount        = wholesale_type_price($cart_total, $data[ $role ]['discount_type'], $max_value);
					$wholesale_label = $label;
				}
			}
			if ($discount ) {
				/**
				 * Hooks
				 *
				 * @since 3.0
				 * @param float $discount The calculated discount amount (negative value).
				 * @param \WC_Cart $cart The cart object.
				 * @param array $data Discount settings data.
				 */
				$cart->add_fee(__($wholesale_label, 'woocommerce-wholesale-pricing'), apply_filters('wholesale_discount_based_on_total_amount', -$discount, $cart, $data));
			} elseif (isset($data[$role]['cart_price']) && ! empty($data[$role]['cart_price']) ) {
				if (empty($data[$role]['cart_min_subtotal']) ) {
					$data[$role]['cart_min_subtotal'] = 1;
				}
				
				if ($discount_on_cart >= $data[$role]['cart_min_subtotal'] ) {
					$cartdiscount = wholesale_type_price($cart_total, $data[ $role ]['discount_type'], $data[$role]['cart_price']);
					/**
					 * Filter Hooks
					 *
					 * @since 2.7.0
					 * @param string $label Label for cart total discount.
					 */
					$label = apply_filters('wholesale_cart_label', 'Discount');
					/**
					 * Filter Hooks
					 *
					 * @since 2.7.0
					 * @param float $cartdiscount The calculated discount amount (negative value).
					 * @param \WC_Cart $cart The cart object.
					 * @param array $data Discount settings data.
					 */
					$cart->add_fee(__($label, 'woocommerce-wholesale-pricing'), apply_filters('wholesale_discount_based_on_total_cart', -$cartdiscount, $cart, $data));
				}
			}
		}
	}

	public function is_tier_pricing_enabled( $product ) {

		$type = $product->get_type();
		$function = 'tire_simple_wholesale_product_price_html';
		if ('variable' == $type) {
			$function = 'tire_variable_wholesale_product_price_html';
		}

		$wwp_group = wwp_get_group_post_by_proid($product->get_id(), get_current_user_id());

		if (! $this->is_wholesale($product->get_id()) && ! $wwp_group ) {
			return false;
		}

		$role   = get_current_user_role_id();
		if (wwp_guest_wholesale_pricing_enabled() ) {
			if (( is_shop() && ! wwp_guest_wholesale_pricing_enabled('display_on_shop') ) || ( is_product() && ! wwp_guest_wholesale_pricing_enabled('display_on_single') ) ) {
				return false;
			}
			$role = wwp_guest_wholesale_pricing_enabled('role');
		}

		if (wwp_get_group_post_by_proid($product->get_id(), get_current_user_id()) ) {
			return true;
		}
		
		$data   = get_post_meta($product->get_id(), 'wholesale_multi_user_pricing', true);

		if (isset($data[ $role ]) ) {
			
			if ($function($product->get_id(), $product, 'product') ) {
				return true;
			}
		}

		if ($function($product->get_id(), $product, 'category') ) {
			return true;
		}

		$data = get_option('wholesale_multi_user_pricing');
		if (isset($data[ $role ])) {
			if ($function($product->get_id(), $product, 'global') ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Loads and initializes all registered compatibility modules.
	 *
	 * Iterates over the `$modules` array and calls the `hooks()` method on each one.
	 *
	 * @return void
	 */
	public function loadModules() {
		foreach ( $this->modules as $module ) {
$module->hooks(); 
		}
	}

	/**
	 * Apply Raise Percentage dynamic rules to tier table unit price.
	 *
	 * Mirrors cart/runtime raise logic so tier price HTML matches checkout/cart.
	 *
	 * @param float|int|string $price   Tier wholesale unit price before raise.
	 * @param \WC_Product      $product Product context for rule matching.
	 * @return float
	 */
	private function apply_dynamic_raise_to_tier_price( $price, $product ) {
		$price = (float) $price;

		if ( ! $product instanceof \WC_Product || $price <= 0 ) {
			return $price;
		}

		$matcher_class = '\WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMatcher';
		if ( ! class_exists( $matcher_class ) ) {
			return $price;
		}

		if ( ! $matcher_class::has_wholesale_discount( $price, $product ) ) {
			return $price;
		}

		$matched = $matcher_class::get_matching_rules( 'raise-percentage', $product );
		if ( empty( $matched ) ) {
			return $price;
		}

		$raised = $price;
		foreach ( $matched as $rule ) {
			$increase = isset( $rule['price_increase'] ) ? absint( $rule['price_increase'] ) : 0;
			if ( $increase > 0 ) {
				$raised = $raised * ( 1 + ( $increase / 100 ) );
			}
		}

		/**
		 * Keep the same extension point used by RaisePercentageRule.
		 */
		return (float) apply_filters( 'wwp_dynamic_rule_raise_percentage_price', $raised, $price, $product, $matched );
	}
}
