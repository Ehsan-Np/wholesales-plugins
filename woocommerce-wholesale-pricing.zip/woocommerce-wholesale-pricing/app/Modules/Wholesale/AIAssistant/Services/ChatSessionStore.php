<?php
/**
 * Ephemeral encrypted chat session storage (24h TTL).
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Persists chat UI messages and AI history in protected upload files.
 */
class ChatSessionStore {

	/**
	 * Session lifetime in seconds.
	 */
	const TTL = DAY_IN_SECONDS;

	/**
	 * Upload subdirectory for chat sessions.
	 */
	const STORAGE_DIR = 'wwp-ai-chat-sessions';

	/**
	 * Load a session for the current user.
	 *
	 * @param string $session_id Client session id.
	 * @return array<string, mixed>|null
	 */
	public function load( $session_id ) {
		$path = $this->get_session_path( $session_id );

		if ( ! $path || ! file_exists( $path ) ) {
			return null;
		}

		$raw = file_get_contents( $path );

		if ( false === $raw || '' === $raw ) {
			return null;
		}

		$plaintext = ChatFileEncryption::decrypt( $raw );

		if ( false === $plaintext ) {
			$this->delete_file( $path );
			return null;
		}

		$data = json_decode( $plaintext, true );

		if ( ! is_array( $data ) ) {
			$this->delete_file( $path );
			return null;
		}

		$updated_at = isset( $data['updated_at'] ) ? (int) $data['updated_at'] : 0;

		if ( $updated_at <= 0 || ( time() - $updated_at ) > self::TTL ) {
			$this->delete_file( $path );
			return null;
		}

		return $data;
	}

	/**
	 * Save session data for the current user.
	 *
	 * @param string               $session_id Session id.
	 * @param array<string, mixed> $data       Session payload.
	 * @return bool
	 */
	public function save( $session_id, array $data ) {
		$path = $this->get_session_path( $session_id, true );

		if ( ! $path ) {
			return false;
		}

		$data['updated_at'] = time();
		$data['user_id']    = get_current_user_id();
		$data['session_id'] = $session_id;

		$encoded = ChatFileEncryption::encrypt( wp_json_encode( $data ) );

		if ( false === $encoded ) {
			return false;
		}

		return false !== file_put_contents( $path, $encoded, LOCK_EX );
	}

	/**
	 * Clear a session file.
	 *
	 * @param string $session_id Session id.
	 * @return bool
	 */
	public function clear( $session_id ) {
		$path = $this->get_session_path( $session_id );

		if ( ! $path || ! file_exists( $path ) ) {
			return true;
		}

		return $this->delete_file( $path );
	}

	/**
	 * Delete expired session and pending files.
	 *
	 * @return int Number of deleted files.
	 */
	public function cleanup_expired() {
		$root = $this->get_storage_root();

		if ( ! $root || ! is_dir( $root ) ) {
			return 0;
		}

		$deleted = 0;
		$cutoff  = time() - self::TTL;

		$iterator = new \RecursiveIteratorIterator(
			new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS )
		);

		foreach ( $iterator as $file_info ) {
			if ( ! $file_info instanceof \SplFileInfo || ! $file_info->isFile() ) {
				continue;
			}

			$filename = $file_info->getFilename();

			if ( 'index.php' === $filename || '.htaccess' === $filename ) {
				continue;
			}

			if ( $file_info->getMTime() < $cutoff ) {
				if ( @unlink( $file_info->getPathname() ) ) {
					++$deleted;
				}
			}
		}

		return $deleted;
	}

	/**
	 * Absolute storage root path.
	 *
	 * @return string|null
	 */
	public function get_storage_root() {
		$upload_dir = wp_upload_dir();

		if ( ! empty( $upload_dir['error'] ) ) {
			return null;
		}

		$root = trailingslashit( $upload_dir['basedir'] ) . self::STORAGE_DIR;
		$this->ensure_protected_directory( $root );

		return $root;
	}

	/**
	 * Resolve a session file path for the current user.
	 *
	 * @param string $session_id   Session id.
	 * @param bool   $create_dirs  Whether to create directories.
	 * @return string|null
	 */
	private function get_session_path( $session_id, $create_dirs = false ) {
		$user_id = get_current_user_id();

		if ( ! $user_id || '' === $session_id ) {
			return null;
		}

		$hash = hash( 'sha256', $user_id . '|' . $session_id );

		if ( ! preg_match( '/^[a-f0-9]{64}$/', $hash ) ) {
			return null;
		}

		$root = $this->get_storage_root();

		if ( ! $root ) {
			return null;
		}

		$user_dir = trailingslashit( $root ) . (string) $user_id;

		if ( $create_dirs ) {
			$this->ensure_protected_directory( $user_dir );
		}

		return trailingslashit( $user_dir ) . $hash . '.json';
	}

	/**
	 * Ensure a protected directory exists.
	 *
	 * @param string $dir Directory path.
	 * @return void
	 */
	private function ensure_protected_directory( $dir ) {
		if ( ! wp_mkdir_p( $dir ) ) {
			return;
		}

		$index = trailingslashit( $dir ) . 'index.php';

		if ( ! file_exists( $index ) ) {
			file_put_contents( $index, "<?php\n// Silence is golden.\n" );
		}

		$htaccess = trailingslashit( $dir ) . '.htaccess';

		if ( ! file_exists( $htaccess ) ) {
			file_put_contents( $htaccess, "Deny from all\n" );
		}
	}

	/**
	 * Delete a file if it exists.
	 *
	 * @param string $path File path.
	 * @return bool
	 */
	private function delete_file( $path ) {
		if ( ! file_exists( $path ) ) {
			return true;
		}

		return @unlink( $path );
	}
}
