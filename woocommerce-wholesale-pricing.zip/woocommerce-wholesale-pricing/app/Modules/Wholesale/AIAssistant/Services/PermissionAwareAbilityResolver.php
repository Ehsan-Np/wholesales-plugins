<?php
/**
 * Permission-aware wrapper around WP AI Client ability execution.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WordPress\AiClient\Messages\DTO\Message;
use WordPress\AiClient\Messages\DTO\MessagePart;
use WordPress\AiClient\Messages\DTO\UserMessage;
use WordPress\AiClient\Tools\DTO\FunctionCall;
use WordPress\AiClient\Tools\DTO\FunctionResponse;

/**
 * Enforces suggest / approval / auto behavior for ability tool calls.
 */
class PermissionAwareAbilityResolver {

	/**
	 * Read-only action verbs.
	 *
	 * @var list<string>
	 */
	const READONLY_ACTIONS = array( 'get', 'list' );

	/**
	 * Mutating action verbs.
	 *
	 * @var list<string>
	 */
	const MUTATION_ACTIONS = array( 'create', 'update', 'delete' );

	/**
	 * Underlying ability resolver.
	 *
	 * @var WP_AI_Client_Ability_Function_Resolver
	 */
	private $resolver;

	/**
	 * Permission mode.
	 *
	 * @var string
	 */
	private $permission;

	/**
	 * Pending action service.
	 *
	 * @var PendingActionService
	 */
	private $pending_service;

	/**
	 * Chat session id.
	 *
	 * @var string
	 */
	private $session_id;

	/**
	 * Pending mutation steps queued during this resolution pass.
	 *
	 * @var list<array{ability_key: string, args: array<string, mixed>}>
	 */
	private $pending_steps = array();

	/**
	 * Constructor.
	 *
	 * @param list<\WP_Ability>         $abilities       Allowed abilities.
	 * @param string                    $permission      Permission mode.
	 * @param string                    $session_id      Chat session id.
	 * @param PendingActionService|null $pending_service Optional pending service.
	 */
	public function __construct(
		array $abilities,
		$permission,
		$session_id,
		$pending_service = null
	) {
		$this->resolver        = new \WP_AI_Client_Ability_Function_Resolver( ...$abilities );
		$this->permission      = $permission;
		$this->session_id      = $session_id;
		$this->pending_service =( isset( $pending_service ) ? $pending_service : new PendingActionService() );
	}

	/**
	 * Whether a message contains ability calls.
	 *
	 * @param Message $message Model message.
	 * @return bool
	 */
	public function has_ability_calls( Message $message ) {
		return $this->resolver->has_ability_calls( $message );
	}

	/**
	 * Resolve ability calls in a model message.
	 *
	 * @param Message $message Model message with function calls.
	 * @return list<Message>
	 */
	public function resolve_messages( Message $message ) {
		$messages = array();

		foreach ( $message->getParts() as $part ) {
			if ( ! $part->getType()->isFunctionCall() ) {
				continue;
			}

			$function_call = $part->getFunctionCall();

			if ( ! $function_call instanceof FunctionCall || ! $this->resolver->is_ability_call( $function_call ) ) {
				continue;
			}

			$messages[] = new UserMessage(
				array(
					new MessagePart(
						$this->resolve_call( $function_call )
					),
				)
			);
		}

		return $messages;
	}

	/**
	 * Resolve ability calls in a model message.
	 *
	 * @deprecated 1.0.0 Use resolve_messages() for provider compatibility.
	 * @param Message $message Model message with function calls.
	 * @return Message
	 */
	public function resolve_message( Message $message ) {
		$messages = $this->resolve_messages( $message );

		if ( empty( $messages ) ) {
			return new UserMessage( array() );
		}

		return $messages[0];
	}

	/**
	 * Pending mutation steps collected in the latest resolve pass.
	 *
	 * @return list<array{ability_key: string, args: array<string, mixed>}>
	 */
	public function get_pending_steps() {
		return $this->pending_steps;
	}

	/**
	 * Reset pending steps collected during resolution.
	 *
	 * @return void
	 */
	public function reset_pending_actions() {
		$this->pending_steps = array();
	}

	/**
	 * Resolve a single ability function call.
	 *
	 * @param FunctionCall $call Function call.
	 * @return FunctionResponse
	 */
	private function resolve_call( FunctionCall $call ) {
		$_wwp_nc = $call->getName();
		$function_name = ( null !== ( $_wwp_nc ) ? $_wwp_nc : 'unknown' );
		$function_id   = ChatHistorySanitizer::resolve_call_id( $call );
		$is_mutation   = self::is_mutation_call( $call );
		$ability_name  = \WP_AI_Client_Ability_Function_Resolver::function_name_to_ability_name( $function_name );
		$args          = is_array( $call->getArgs() ) ? $call->getArgs() : array();

		ChatAiLogger::log(
			'ability_call',
			array(
				'session_id'   => $this->session_id,
				'permission'   => $this->permission,
				'ability_name' => $ability_name,
				'function_id'  => $function_id,
				'is_mutation'  => $is_mutation,
				'args'         => $args,
				'function_call'=> $call->toArray(),
			)
		);

		if ( 'suggest' === $this->permission && $is_mutation ) {
			$response = new FunctionResponse(
				$function_id,
				$function_name,
				array(
					'status'  => 'blocked',
					'code'    => 'mutation_not_allowed',
					'message' => __( 'Mutations are disabled in Suggest mode. Provide step-by-step admin navigation instead.', 'woocommerce-wholesale-pricing' ),
				)
			);

			ChatAiLogger::log(
				'ability_response',
				array(
					'session_id'   => $this->session_id,
					'ability_name' => $ability_name,
					'outcome'      => 'blocked_suggest',
					'response'     => $response->toArray(),
				)
			);

			return $response;
		}

		if ( 'approval' === $this->permission && $is_mutation ) {
			$ability_key = PendingActionService::ability_name_to_key( $ability_name );
			$ability     = wp_get_ability( $ability_name );

			if ( '' === $ability_key || empty( $args ) ) {
				$response = new FunctionResponse(
					$function_id,
					$function_name,
					array(
						'error' => __( 'Invalid mutation arguments.', 'woocommerce-wholesale-pricing' ),
						'code'  => 'invalid_mutation_args',
					)
				);

				return $response;
			}

			$this->pending_steps[] = array(
				'ability_key' => $ability_key,
				'args'        => $args,
			);

			$response = new FunctionResponse(
				$function_id,
				$function_name,
				array(
					'status'  => 'pending_approval',
					'message' => __( 'This change requires user approval before it can be applied.', 'woocommerce-wholesale-pricing' ),
				)
			);

			ChatAiLogger::log(
				'ability_response',
				array(
					'session_id'   => $this->session_id,
					'ability_name' => $ability_name,
					'outcome'      => 'queued_pending_step',
					'args'         => $args,
					'response'     => $response->toArray(),
				)
			);

			return $response;
		}

		$response = $this->resolver->execute_ability( $call );

		ChatAiLogger::log(
			'ability_response',
			array(
				'session_id'   => $this->session_id,
				'ability_name' => $ability_name,
				'outcome'      => 'executed',
				'response'     => $response->toArray(),
			)
		);

		return $response;
	}

	/**
	 * Whether a function call would mutate plugin data.
	 *
	 * @param FunctionCall $call Function call.
	 * @return bool
	 */
	public static function is_mutation_call( FunctionCall $call ) {
		$function_name = $call->getName();

		if ( ! is_string( $function_name ) || ! str_starts_with( $function_name, 'wpab__' ) ) {
			return false;
		}

		$ability_name = \WP_AI_Client_Ability_Function_Resolver::function_name_to_ability_name( $function_name );
		$ability      = wp_get_ability( $ability_name );

		if ( ! $ability instanceof \WP_Ability ) {
			return false;
		}

		$meta        = $ability->get_meta();
		$annotations = is_array(( isset( $meta['annotations'] ) ? $meta['annotations'] : null )) ? $meta['annotations'] : array();

		if ( ! empty( $annotations['readonly'] ) ) {
			return false;
		}

		$args   = is_array( $call->getArgs() ) ? $call->getArgs() : array();
		$action = isset( $args['action'] ) ? sanitize_key( (string) $args['action'] ) : '';

		if ( '' !== $action ) {
			if ( in_array( $action, self::READONLY_ACTIONS, true ) ) {
				return false;
			}

			if ( in_array( $action, self::MUTATION_ACTIONS, true ) ) {
				return true;
			}
		}

		if ( isset( $annotations['readonly'] ) && false === $annotations['readonly'] ) {
			return true;
		}

		return false;
	}
}
