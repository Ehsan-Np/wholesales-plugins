<?php
/**
 * Encrypts and decrypts ephemeral AI chat file payloads.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Symmetric encryption helper for chat session files.
 */
class ChatFileEncryption {

	/**
	 * Encryption scheme prefix stored in encoded payloads.
	 */
	const SCHEME_SODIUM = 's:';

	/**
	 * OpenSSL AES fallback scheme prefix.
	 */
	const SCHEME_OPENSSL = 'o:';

	/**
	 * Encrypt a plaintext string.
	 *
	 * @param string $plaintext Plaintext payload.
	 * @return string|false Base64-encoded ciphertext or false on failure.
	 */
	public static function encrypt( $plaintext ) {
		$key = self::get_key();

		if ( function_exists( 'sodium_crypto_secretbox' ) ) {
			$nonce  = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$cipher = sodium_crypto_secretbox( $plaintext, $nonce, $key );

			if ( false === $cipher ) {
				return false;
			}

			return base64_encode( self::SCHEME_SODIUM . $nonce . $cipher );
		}

		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return false;
		}

		$iv     = random_bytes( 16 );
		$cipher = openssl_encrypt( $plaintext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );

		if ( false === $cipher ) {
			return false;
		}

		return base64_encode( self::SCHEME_OPENSSL . $iv . $cipher );
	}

	/**
	 * Decrypt an encoded payload.
	 *
	 * @param string $encoded Base64-encoded ciphertext.
	 * @return string|false Plaintext or false on failure.
	 */
	public static function decrypt( $encoded ) {
		$raw = base64_decode( $encoded, true );

		if ( false === $raw || strlen( $raw ) < 3 ) {
			return false;
		}

		$key    = self::get_key();
		$scheme = substr( $raw, 0, 2 );

		if ( self::SCHEME_SODIUM === $scheme && function_exists( 'sodium_crypto_secretbox_open' ) ) {
			$nonce  = substr( $raw, 2, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
			$cipher = substr( $raw, 2 + SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );

			if ( strlen( $nonce ) !== SODIUM_CRYPTO_SECRETBOX_NONCEBYTES || '' === $cipher ) {
				return false;
			}

			$plaintext = sodium_crypto_secretbox_open( $cipher, $nonce, $key );

			return false === $plaintext ? false : $plaintext;
		}

		if ( self::SCHEME_OPENSSL === $scheme && function_exists( 'openssl_decrypt' ) ) {
			$iv     = substr( $raw, 2, 16 );
			$cipher = substr( $raw, 18 );

			if ( strlen( $iv ) !== 16 || '' === $cipher ) {
				return false;
			}

			$plaintext = openssl_decrypt( $cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );

			return false === $plaintext ? false : $plaintext;
		}

		return false;
	}

	/**
	 * Derive a binary encryption key.
	 *
	 * @return string
	 */
	private static function get_key() {
		return hash( 'sha256', wp_salt( 'auth' ) . 'wwp_ai_chat', true );
	}
}
