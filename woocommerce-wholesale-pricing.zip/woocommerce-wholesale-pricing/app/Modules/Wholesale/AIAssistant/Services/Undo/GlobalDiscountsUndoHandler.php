<?php
/**
 * Undo handler for global wholesale discounts and tier pricing.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo;

use WooCommerceWholesalePricing\App\Services\WholesaleGlobalDiscountService;

/**
 * Reverts update actions on global discount settings.
 */
class GlobalDiscountsUndoHandler implements UndoHandlerInterface {

	/**
	 * {@inheritDoc}
	 */
	public function supports( $action_type, $resource_type ) {
		return 'global_discounts' === $resource_type && 'update' === $action_type;
	}

	/**
	 * {@inheritDoc}
	 */
	public function undo( array $row ) {
		$before = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();

		if ( empty( $before ) ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo global discount update: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$service = new WholesaleGlobalDiscountService();

		return $service->restore_settings( $before );
	}
}
