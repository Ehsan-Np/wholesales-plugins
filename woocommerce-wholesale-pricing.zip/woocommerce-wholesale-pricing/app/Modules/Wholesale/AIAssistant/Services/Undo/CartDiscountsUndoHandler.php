<?php
/**
 * Undo handler for wholesale cart discounts and tier pricing.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo;

use WooCommerceWholesalePricing\App\Services\WholesaleCartDiscountService;

/**
 * Reverts update actions on cart discount settings.
 */
class CartDiscountsUndoHandler implements UndoHandlerInterface {

	/**
	 * {@inheritDoc}
	 */
	public function supports( $action_type, $resource_type ) {
		return 'cart_discounts' === $resource_type && 'update' === $action_type;
	}

	/**
	 * {@inheritDoc}
	 */
	public function undo( array $row ) {
		$before = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();

		if ( empty( $before ) ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo cart discount update: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$service = new WholesaleCartDiscountService();

		return $service->restore_settings( $before );
	}
}
