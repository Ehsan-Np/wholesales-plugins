<?php
/**
 * Undo handler for WooCommerce products.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo;

use WooCommerceWholesalePricing\App\Services\WholesaleProductMetaService;

/**
 * Reverts create/delete/update actions on products.
 */
class ProductUndoHandler implements UndoHandlerInterface {

	/**
	 * Wholesale product meta service.
	 *
	 * @var WholesaleProductMetaService
	 */
	private $meta_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleProductMetaService|null $meta_service Optional meta service.
	 */
	public function __construct( $meta_service = null ) {
		$this->meta_service =( isset( $meta_service ) ? $meta_service : new WholesaleProductMetaService() );
	}

	/**
	 * {@inheritDoc}
	 */
	public function supports( $action_type, $resource_type ) {
		return 'product' === $resource_type && in_array( $action_type, array( 'create', 'delete', 'update' ), true );
	}

	/**
	 * {@inheritDoc}
	 */
	public function undo( array $row ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return new \WP_Error(
				'wwp_ai_undo_woocommerce_missing',
				__( 'WooCommerce is required to undo product changes.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		$action_type = (string) ( ( isset( $row['action_type'] ) ? $row['action_type'] : '' ) );

		switch ( $action_type ) {
			case 'create':
				return $this->undo_create( $row );
			case 'delete':
				return $this->undo_delete( $row );
			case 'update':
				return $this->undo_update( $row );
		}

		return new \WP_Error(
			'wwp_ai_undo_unsupported_action',
			__( 'Unsupported undo action for product.', 'woocommerce-wholesale-pricing' ),
			array( 'status' => 400 )
		);
	}

	/**
	 * Undo product creation by force-deleting the product.
	 *
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_create( array $row ) {
		$resource   = is_array(( isset( $row['resource'] ) ? $row['resource'] : null )) ? $row['resource'] : array();
		$product_id = (int) ( ( isset( $resource['id'] ) ? $resource['id'] : ( isset( $resource['ID'] ) ? $resource['ID'] : 0 ) ) );

		if ( $product_id <= 0 ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_resource',
				__( 'Cannot undo product creation: missing product id.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return true;
		}

		$deleted = $product->delete( true );
		if ( ! $deleted ) {
			return new \WP_Error(
				'wwp_ai_undo_product_delete_failed',
				__( 'Failed to delete product while undoing creation.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		return true;
	}

	/**
	 * Undo product deletion by restoring from before state.
	 *
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_delete( array $row ) {
		$before = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();

		if ( empty( $before ) ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo product deletion: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$product_id = (int) ( ( isset( $before['id'] ) ? $before['id'] : 0 ) );
		if ( $product_id > 0 ) {
			$restored = wp_untrash_post( $product_id );
			if ( $restored ) {
				$this->restore_wholesale_snapshot( $before );
				return true;
			}
		}

		$post_args = array(
			'post_type'    => 'product',
			'post_status'  => (string) ( ( isset( $before['status'] ) ? $before['status'] : 'publish' ) ),
			'post_title'   => (string) ( ( isset( $before['name'] ) ? $before['name'] : '' ) ),
			'post_content' => (string) ( ( isset( $before['description'] ) ? $before['description'] : '' ) ),
			'post_excerpt' => (string) ( ( isset( $before['short_description'] ) ? $before['short_description'] : '' ) ),
		);

		if ( '' === $post_args['post_title'] ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo product deletion: missing product name.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$new_id = wp_insert_post( $post_args, true );
		if ( is_wp_error( $new_id ) ) {
			return $new_id;
		}

		$product = wc_get_product( $new_id );
		if ( ! $product ) {
			return new \WP_Error(
				'wwp_ai_undo_product_restore_failed',
				__( 'Failed to restore deleted product.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		if ( isset( $before['regular_price'] ) ) {
			$product->set_regular_price( (string) $before['regular_price'] );
		}
		if ( isset( $before['sale_price'] ) ) {
			$product->set_sale_price( (string) $before['sale_price'] );
		}
		if ( isset( $before['sku'] ) ) {
			$product->set_sku( (string) $before['sku'] );
		}
		if ( isset( $before['stock_status'] ) ) {
			$product->set_stock_status( (string) $before['stock_status'] );
		}

		$product->save();

		if ( ! empty( $before['meta'] ) && is_array( $before['meta'] ) ) {
			foreach ( $before['meta'] as $meta_key => $meta_value ) {
				update_post_meta( $new_id, $meta_key, $meta_value );
			}
		}

		$before['wholesale_snapshot']['product_id'] = $new_id;
		$this->restore_wholesale_snapshot( $before );

		return true;
	}

	/**
	 * Undo product update by restoring before state.
	 *
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_update( array $row ) {
		$before     = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();
		$product_id = (int) ( ( isset( $before['id'] ) ? $before['id'] : 0 ) );

		if ( $product_id <= 0 ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo product update: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return new \WP_Error(
				'wwp_ai_undo_product_not_found',
				__( 'Product not found while undoing update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		if ( isset( $before['name'] ) ) {
			$product->set_name( (string) $before['name'] );
		}
		if ( isset( $before['description'] ) ) {
			$product->set_description( (string) $before['description'] );
		}
		if ( isset( $before['short_description'] ) ) {
			$product->set_short_description( (string) $before['short_description'] );
		}
		if ( isset( $before['regular_price'] ) ) {
			$product->set_regular_price( (string) $before['regular_price'] );
		}
		if ( isset( $before['sale_price'] ) ) {
			$product->set_sale_price( (string) $before['sale_price'] );
		}
		if ( isset( $before['sku'] ) ) {
			$product->set_sku( (string) $before['sku'] );
		}
		if ( isset( $before['stock_status'] ) ) {
			$product->set_stock_status( (string) $before['stock_status'] );
		}
		if ( isset( $before['status'] ) ) {
			$product->set_status( (string) $before['status'] );
		}

		$product->save();

		if ( ! empty( $before['meta'] ) && is_array( $before['meta'] ) ) {
			foreach ( $before['meta'] as $meta_key => $meta_value ) {
				update_post_meta( $product_id, $meta_key, $meta_value );
			}
		}

		$this->restore_wholesale_snapshot( $before );

		return true;
	}

	/**
	 * Restore wholesale snapshot
	 * 
	 * @param array<string, mixed> $before Before state with optional wholesale_snapshot.
	 * @return void
	 */
	private function restore_wholesale_snapshot( array $before ) {
		if ( empty( $before['wholesale_snapshot'] ) || ! is_array( $before['wholesale_snapshot'] ) ) {
			return;
		}

		$result = $this->meta_service->restore_wholesale_settings( $before['wholesale_snapshot'] );
		if ( is_wp_error( $result ) ) {
			return;
		}
	}
}
