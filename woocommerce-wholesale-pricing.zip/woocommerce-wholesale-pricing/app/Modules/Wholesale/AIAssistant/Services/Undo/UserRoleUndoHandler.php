<?php
/**
 * Undo handler for wholesale user roles.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo;

use WooCommerceWholesalePricing\App\Services\WholesaleUserRoleService;

/**
 * Reverts create/delete/update actions on wholesale_user_roles taxonomy terms.
 */
class UserRoleUndoHandler implements UndoHandlerInterface {

	/**
	 * Role service.
	 *
	 * @var WholesaleUserRoleService
	 */
	private $role_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleUserRoleService|null $role_service Optional role service.
	 */
	public function __construct( $role_service = null ) {
		$this->role_service =( isset( $role_service ) ? $role_service : new WholesaleUserRoleService() );
	}

	/**
	 * {@inheritDoc}
	 */
	public function supports( $action_type, $resource_type ) {
		return 'user_role' === $resource_type && in_array( $action_type, array( 'create', 'delete', 'update' ), true );
	}

	/**
	 * {@inheritDoc}
	 */
	public function undo( array $row ) {
		$action_type = (string) ( ( isset( $row['action_type'] ) ? $row['action_type'] : '' ) );

		switch ( $action_type ) {
			case 'create':
				return $this->undo_create( $row );
			case 'delete':
				return $this->undo_delete( $row );
			case 'update':
				return $this->undo_update( $row );
		}

		return new \WP_Error(
			'wwp_ai_undo_unsupported_action',
			__( 'Unsupported undo action for user role.', 'woocommerce-wholesale-pricing' ),
			array( 'status' => 400 )
		);
	}

	/**
	 * Undo role creation by deleting the term and WP role.
	 *
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_create( array $row ) {
		$resource = is_array(( isset( $row['resource'] ) ? $row['resource'] : null )) ? $row['resource'] : array();
		$term_id  = (int) ( ( isset( $resource['term_id'] ) ? $resource['term_id'] : ( isset( $resource['id'] ) ? $resource['id'] : 0 ) ) );
		$slug     = (string) ( ( isset( $resource['slug'] ) ? $resource['slug'] : '' ) );

		if ( $term_id > 0 ) {
			$result = wp_delete_term( $term_id, $this->role_service->get_taxonomy() );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		} elseif ( '' !== $slug ) {
			$existing = term_exists( $slug, $this->role_service->get_taxonomy() );
			if ( $existing ) {
				$result = wp_delete_term( (int) $existing['term_id'], $this->role_service->get_taxonomy() );
				if ( is_wp_error( $result ) ) {
					return $result;
				}
			}
		} else {
			return new \WP_Error(
				'wwp_ai_undo_missing_resource',
				__( 'Cannot undo user role creation: missing term data.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( '' !== $slug && wp_roles()->is_role( $slug ) ) {
			remove_role( $slug );
		}

		return true;
	}

	/**
	 * Undo role deletion by recreating the term, meta, and WP role.
	 *
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_delete( array $row ) {
		$before = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();
		$args   = is_array(( isset( $before['args'] ) ? $before['args'] : null )) ? $before['args'] : array();
		$name   = (string) ( ( isset( $args['name'] ) ? $args['name'] : ( isset( $before['name'] ) ? $before['name'] : '' ) ) );
		$slug   = (string) ( ( isset( $args['slug'] ) ? $args['slug'] : ( isset( $before['slug'] ) ? $before['slug'] : '' ) ) );

		if ( '' === $name ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo user role deletion: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$insert_args = array();
		if ( '' !== $slug ) {
			$insert_args['slug'] = $slug;
		}
		if ( isset( $args['description'] ) ) {
			$insert_args['description'] = $args['description'];
		}

		$result = wp_insert_term( $name, $this->role_service->get_taxonomy(), $insert_args );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$term_id = (int) $result['term_id'];
		$term    = get_term( $term_id, $this->role_service->get_taxonomy() );
		if ( $term && ! is_wp_error( $term ) ) {
			$role_slug = '' !== $slug ? $slug : $term->slug;
			if ( ! wp_roles()->is_role( $role_slug ) ) {
				add_role(
					$role_slug,
					$term->name . esc_html__( ' - Wholesaler role', 'woocommerce-wholesale-pricing' ),
					array(
						'read'    => true,
						'level_0' => true,
					)
				);
			}
		}

		$meta = is_array(( isset( $before['meta'] ) ? $before['meta'] : null )) ? $before['meta'] : array();
		if ( ! empty( $meta ) ) {
			$this->role_service->restore_role_meta( $term_id, $meta );
		}

		return true;
	}

	/**
	 * Undo role update by restoring before state (term args + meta).
	 *
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_update( array $row ) {
		$before  = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();
		$term_id = (int) ( ( isset( $before['term_id'] ) ? $before['term_id'] : 0 ) );
		$args    = is_array(( isset( $before['args'] ) ? $before['args'] : null )) ? $before['args'] : array();
		$meta    = is_array(( isset( $before['meta'] ) ? $before['meta'] : null )) ? $before['meta'] : array();

		if ( $term_id <= 0 ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo user role update: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$current = get_term( $term_id, $this->role_service->get_taxonomy() );
		if ( ! $current || is_wp_error( $current ) ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_term',
				__( 'Cannot undo user role update: term no longer exists.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		$old_slug = $current->slug;
		$result   = wp_update_term( $term_id, $this->role_service->get_taxonomy(), $args );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$updated = get_term( $term_id, $this->role_service->get_taxonomy() );
		if ( $updated && ! is_wp_error( $updated ) ) {
			$new_slug = $updated->slug;
			$new_name = $updated->name;
			if ( $new_slug !== $old_slug || ( isset( $args['name'] ) && $args['name'] !== $current->name ) ) {
				$this->role_service->sync_wp_role( $old_slug, $new_slug, $new_name );
			}
		}

		if ( ! empty( $meta ) ) {
			$this->role_service->restore_role_meta( $term_id, $meta );
		}

		return true;
	}
}
