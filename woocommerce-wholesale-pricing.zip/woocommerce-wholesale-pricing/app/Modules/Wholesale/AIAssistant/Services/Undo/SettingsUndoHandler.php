<?php
/**
 * Undo handler for wholesale plugin settings.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\SettingsService;
use WooCommerceWholesalePricing\App\Providers\WholesaleOption;
use WooCommerceWholesalePricing\App\Services\WholesalePricingSettingsService;
use WooCommerceWholesalePricing\App\Services\WholesaleQuoteCustomizationSettingsService;

/**
 * Reverts update actions on plugin settings options.
 */
class SettingsUndoHandler implements UndoHandlerInterface {

	/**
	 * {@inheritDoc}
	 */
	public function supports( $action_type, $resource_type ) {
		return 'settings' === $resource_type && 'update' === $action_type;
	}

	/**
	 * {@inheritDoc}
	 */
	public function undo( array $row ) {
		$before = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();

		if ( isset( $before['pricing'] ) || isset( $before['quote_customization'] ) ) {
			return $this->restore_composite_snapshot( $before );
		}

		if ( empty( $before['option_key'] ) || ! isset( $before['value'] ) ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo settings update: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return $this->restore_legacy_snapshot( $before );
	}

	/**
	 * Restore composite wholesale settings snapshot.
	 *
	 * @param array<string, mixed> $before Composite before state.
	 * @return true|\WP_Error
	 */
	private function restore_composite_snapshot( array $before ) {
		if ( isset( $before['pricing'] ) && is_array( $before['pricing'] ) ) {
			$pricing_service = new WholesalePricingSettingsService();
			$restored        = $pricing_service->restore_settings( $before['pricing'] );

			if ( is_wp_error( $restored ) ) {
				return $restored;
			}
		}

		if ( isset( $before['quote_customization'] ) && is_array( $before['quote_customization'] ) ) {
			$customization_service = new WholesaleQuoteCustomizationSettingsService();
			$restored              = $customization_service->restore_settings( $before['quote_customization'] );

			if ( is_wp_error( $restored ) ) {
				return $restored;
			}
		}

		return true;
	}

	/**
	 * Restore legacy single-option snapshot.
	 *
	 * @param array<string, mixed> $before Legacy before state.
	 * @return true|\WP_Error
	 */
	private function restore_legacy_snapshot( array $before ) {
		$option_key = (string) $before['option_key'];
		$value      = $before['value'];

		$allowed_keys = array(
			WholesaleOption::AI_ASSISTANT_OPTION,
			WholesaleOption::PRICING_OPTION,
			WholesaleOption::REGISTRATION_OPTION,
			WholesaleOption::QUOTE_CUSTOMIZATION_OPTION,
		);

		if ( ! in_array( $option_key, $allowed_keys, true ) ) {
			return new \WP_Error(
				'wwp_ai_undo_settings_not_allowed',
				__( 'Cannot undo changes for this settings option.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( WholesaleOption::AI_ASSISTANT_OPTION === $option_key ) {
			$service = new SettingsService();
			$saved   = $service->save_settings( is_array( $value ) ? $value : array() );
			if ( is_wp_error( $saved ) ) {
				return $saved;
			}
			return true;
		}

		if ( WholesaleOption::QUOTE_CUSTOMIZATION_OPTION === $option_key ) {
			$service = new WholesaleQuoteCustomizationSettingsService();

			return $service->restore_settings(
				array(
					'option_key' => $option_key,
					'value'      => $value,
				)
			);
		}

		update_option( $option_key, $value );

		return true;
	}
}
