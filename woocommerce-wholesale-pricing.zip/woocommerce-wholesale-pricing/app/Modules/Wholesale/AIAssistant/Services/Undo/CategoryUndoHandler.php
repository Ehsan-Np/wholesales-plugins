<?php
/**
 * Undo handler for WooCommerce product categories.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\Undo;

use WooCommerceWholesalePricing\App\Services\WholesaleCategoryMetaService;

/**
 * Reverts create/delete/update actions on product categories.
 */
class CategoryUndoHandler implements UndoHandlerInterface {

	/**
	 * Wholesale category meta service.
	 *
	 * @var WholesaleCategoryMetaService
	 */
	private $meta_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleCategoryMetaService|null $meta_service Optional meta service.
	 */
	public function __construct( $meta_service = null ) {
		$this->meta_service =( isset( $meta_service ) ? $meta_service : new WholesaleCategoryMetaService() );
	}

	/**
	 * {@inheritDoc}
	 */
	public function supports( $action_type, $resource_type ) {
		return 'product_category' === $resource_type && in_array( $action_type, array( 'create', 'delete', 'update' ), true );
	}

	/**
	 * {@inheritDoc}
	 */
	public function undo( array $row ) {
		$action_type = (string) ( ( isset( $row['action_type'] ) ? $row['action_type'] : '' ) );

		switch ( $action_type ) {
			case 'create':
				return $this->undo_create( $row );
			case 'delete':
				return $this->undo_delete( $row );
			case 'update':
				return $this->undo_update( $row );
		}

		return new \WP_Error(
			'wwp_ai_undo_unsupported_action',
			__( 'Unsupported undo action for product category.', 'woocommerce-wholesale-pricing' ),
			array( 'status' => 400 )
		);
	}

	/**
	 * Undo create
	 * 
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_create( array $row ) {
		$resource = is_array(( isset( $row['resource'] ) ? $row['resource'] : null )) ? $row['resource'] : array();
		$term_id  = (int) ( ( isset( $resource['id'] ) ? $resource['id'] : 0 ) );

		if ( $term_id <= 0 ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_resource',
				__( 'Cannot undo category creation: missing term id.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$result = wp_delete_term( $term_id, 'product_cat' );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return true;
	}

	/**
	 * Undo delete
	 * 
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_delete( array $row ) {
		$before = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();

		if ( empty( $before['name'] ) ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo category deletion: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$insert = wp_insert_term(
			(string) $before['name'],
			'product_cat',
			array(
				'slug'        => (string) ( ( isset( $before['slug'] ) ? $before['slug'] : '' ) ),
				'description' => (string) ( ( isset( $before['description'] ) ? $before['description'] : '' ) ),
				'parent'      => (int) ( ( isset( $before['parent'] ) ? $before['parent'] : 0 ) ),
			)
		);

		if ( is_wp_error( $insert ) ) {
			return $insert;
		}

		$term_id = (int) $insert['term_id'];

		if ( ! empty( $before['wholesale_snapshot'] ) && is_array( $before['wholesale_snapshot'] ) ) {
			$snapshot = $before['wholesale_snapshot'];
			$snapshot['term_id'] = $term_id;
			$this->meta_service->restore_wholesale_settings( $snapshot );
		}

		return true;
	}

	/**
	 * Undo update
	 * 
	 * @param array<string, mixed> $row History row.
	 * @return true|\WP_Error
	 */
	private function undo_update( array $row ) {
		$before  = is_array(( isset( $row['before_state'] ) ? $row['before_state'] : null )) ? $row['before_state'] : array();
		$term_id = (int) ( ( isset( $before['id'] ) ? $before['id'] : 0 ) );

		if ( $term_id <= 0 ) {
			return new \WP_Error(
				'wwp_ai_undo_missing_before_state',
				__( 'Cannot undo category update: missing before state.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$args = array();
		if ( isset( $before['name'] ) ) {
			$args['name'] = (string) $before['name'];
		}
		if ( isset( $before['slug'] ) ) {
			$args['slug'] = (string) $before['slug'];
		}
		if ( isset( $before['description'] ) ) {
			$args['description'] = (string) $before['description'];
		}
		if ( isset( $before['parent'] ) ) {
			$args['parent'] = (int) $before['parent'];
		}

		if ( ! empty( $args ) ) {
			$result = wp_update_term( $term_id, 'product_cat', $args );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		if ( ! empty( $before['wholesale_snapshot'] ) && is_array( $before['wholesale_snapshot'] ) ) {
			$restore = $this->meta_service->restore_wholesale_settings( $before['wholesale_snapshot'] );
			if ( is_wp_error( $restore ) ) {
				return $restore;
			}
		}

		return true;
	}
}
