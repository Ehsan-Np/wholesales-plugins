<?php
/**
 * Maps user chat messages to ability keys for pre-flight checks.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities\AbilityCatalog;

/**
 * Lightweight keyword matcher for ability intent detection.
 */
class ChatAbilityIntentMatcher {

	/**
	 * Ability key => keyword phrases (case-insensitive substring match).
	 *
	 * @var array<string, list<string>>
	 */
	const KEYWORD_MAP = array(
		'wholesale_settings'              => array(
			'auto approv',
			'auto approve',
			'disable auto',
			'enable auto',
			'pricing mode',
			'default multi wholesale',
			'apply wholesale price',
			'price application',
			'wholesale price on',
			'multi wholesale role',
			'default wholesale role',
			'login restriction',
			'product visibility',
			'price display',
			'wholesale setting',
			'general setting',
			'registration approv',
			'registration approval',
			'manual approval',
			'wholesale registration',
			'wholeslae registration',
			'tier pricing mode',
			'minimum quantity',
			'enforce minimum',
			'requisition list',
			'registration link',
			'enable registration',
			'enable the',
			'disable the',
			'turn on',
			'turn off',
			'request again submit',
			'request again',
			'submit again',
			'upgrade request',
			'wholesale upgrade',
			'upgrade tab',
			'hide price',
			'hide add to cart',
			'strike through',
			'store access',
			'enable coupon',
			'wholesale coupon',
			'request for sample',
			'variation table',
			'login message',
			'private store',
			'non wholesale product',
		),
		'global_discounts'                => array(
			'global discount',
			'role discount',
			'wholesale discount',
			'tier pricing',
			'role_discounts',
			'percent off',
			'fixed discount',
			'exclude category',
			'min subtotal',
			'min quantity',
			'min qty',
			'global wholesale',
			'discount_type',
			'wholesale_price',
		),
		'cart_discounts'                  => array(
			'cart discount',
			'cart total discount',
			'tiered cart',
			'cart tier',
			'cart subtotal',
			'spend and save',
		),
		'b2b_user_roles'                 => array(
			'wholeasle role',
			'wholesale user role',
			'wholeasle user role',
			'b2b role',
			'create role',
			'add role',
			'create wholesale role',
			'add wholesale role',
			'new wholesale role',
			'user role',
			'new role',
			'reseller',
			'distributor role',
			'tax exempt',
			'disable coupon',
			'private store password',
			'role slug',
			'payment method restriction',
			'shipping method restriction',
		),
		'wholesale_registration'          => array(
			'registration form',
			'registration field',
			'tax id field',
			'tax id',
			'tax-id',
			'vat number',
			'file upload',
			'recaptcha',
			'captcha',
			'registration page',
			'billing field',
			'shipping field',
			'enable_billing',
			'enable_shipping',
			'enable_tex_id',
			'required_tex_id',
			'required field',
			'recaptcha v2',
			'recaptcha v3',
			'recaptcha_version',
		),
		'wholesale_email_notifications'   => array(
			'email notification',
			'email template',
			'registration email',
			'approval email',
			'rejection email',
			'subscription email',
			'subscription role',
			'admin request notification',
			'registration notification',
			'email recipient',
			'email subject',
			'email body',
			'notification_key',
		),
		'woocommerce_products'            => array(
			'product',
			'variable product',
			'wholesale price',
			'add product',
			'create product',
			'update product',
			'delete product',
			'sku',
			'variation',
			'product_variation',
			'step quantity',
			'product price',
			'regular_price',
			'stock',
			'product tier',
			'product_tier_pricing',
			'wholesale_multi_user',
		),
		'woocommerce_categories'          => array(
			'category',
			'categories',
			'product categor',
			'product categories',
			'product_cat',
			'create categor',
			'add categor',
			'woocommerce categor',
			'category pricing',
			'category visibility',
			'category discount',
			'category_tier',
			'product category',
			'wholesale_product_visibility',
		),
		'wholesale_account_requests'      => array(
			'account request',
			'registration request',
			'approve request',
			'reject request',
			'pending request',
			'application',
			'waiting',
			'applicant',
			'wwp_requests',
			'user_role_set',
			'rejected_note',
			'user_status',
		),
		'b2b_user_profiles'               => array(
			'user profile',
			'b2b user',
			'wholesale user',
			'assign role',
			'customer',
			'billing address',
			'shipping address',
			'create user',
			'update user',
			'user_email',
			'first_name',
			'last_name',
		),
		'quote_settings'                  => array(
			'quote setting',
			'quote pdf',
			'request a quote',
			'request a quote setting',
			'quote page',
			'quote expiry',
			'quote expire',
			'quote pdf logo',
			'build quote',
			'enable quote',
			'enable_pdf',
			'pdf_logo',
		),
		'quote_rules'                     => array(
			'quote rule',
			'wc-quote-rules',
			'quote restriction',
			'quote button',
			'include product',
			'exclude category',
			'quote priority',
			'user_scope',
			'enable_rule',
			'product_inclusions',
			'product_exclusions',
		),
		'modify_update_quotes'            => array(
			'update quote',
			'modify quote',
			'quote status',
			'wc-quote',
			'quote_contents',
			'quote_expired',
			'quote_quoted',
			'accepted',
			'converted',
			'rejected quote',
			'line item',
			'quote draft',
			'quote_new',
		),
		'dashboard'                       => array(
			'dashboard',
			'analytics',
			'sales report',
			'revenue',
			'wholesale sales',
			'aov',
			'average order',
			'refund',
			'top customer',
			'top product',
			'net total',
			'gross total',
			'order count',
		),
	);

	/**
	 * Match a user message to the most likely ability key.
	 *
	 * @param string $message User message.
	 * @return string|null Ability settings key or null.
	 */
	public static function match( $message ) {
		$normalized = strtolower( trim( $message ) );

		if ( '' === $normalized ) {
			return null;
		}

		$contextual = self::match_contextual_intent( $normalized );

		if ( null !== $contextual && AbilityCatalog::is_active( $contextual ) ) {
			return $contextual;
		}

		$best_key   = null;
		$best_score = 0;

		foreach ( self::KEYWORD_MAP as $key => $phrases ) {
			if ( ! AbilityCatalog::is_active( $key ) ) {
				continue;
			}

			$score = 0;

			foreach ( $phrases as $phrase ) {
				if ( str_contains( $normalized, strtolower( $phrase ) ) ) {
					$score += strlen( $phrase );
				}
			}

			foreach ( AbilityDataCatalog::get_extra_keywords( $key ) as $phrase ) {
				if ( str_contains( $normalized, $phrase ) && strlen( $phrase ) >= 4 ) {
					$score += (int) floor( strlen( $phrase ) * 0.75 );
				}
			}

			foreach ( AdminSettingsRegistry::get_matcher_keywords( $key ) as $phrase ) {
				if ( str_contains( $normalized, $phrase ) && strlen( $phrase ) >= 4 ) {
					$score += (int) floor( strlen( $phrase ) * 0.85 );
				}
			}

			if ( $score > $best_score ) {
				$best_score = $score;
				$best_key   = $key;
			}
		}

		return $best_key;
	}

	/**
	 * High-priority contextual routing before keyword scoring.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string|null
	 */
	private static function match_contextual_intent( $normalized ) {
		// wholesale_settings vs b2b_user_roles: setting assignment phrases win over bare "role".
		$mentions_settings_action = 1 === preg_match( '/\b(set|default|apply|change|update)\b/', $normalized );
		$mentions_pricing_setting   = 1 === preg_match(
			'/default\s+(?:multi\s+)?wholesale\s+role|multi\s+wholesale\s+role|apply\s+wholesale\s+price|wholesale\s+price\s+on|price\s+application/',
			$normalized
		);

		if ( $mentions_settings_action && $mentions_pricing_setting ) {
			return 'wholesale_settings';
		}

		if ( QuoteCustomizationCatalog::message_targets_customization( $normalized ) ) {
			return 'wholesale_settings';
		}

		if ( '' !== WholesaleSettingsCatalog::resolve_key_from_message( $normalized ) ) {
			return 'wholesale_settings';
		}

		if ( ! empty( WholesaleSettingsCatalog::build_combined_settings_patch( $normalized ) ) ) {
			return 'wholesale_settings';
		}

		// wholesale_settings vs woocommerce_products: guest/display price settings vs product CRUD.
		if ( $mentions_settings_action && str_contains( $normalized, 'wholesale price' )
			&& ! preg_match( '/\bproducts?\b/', $normalized ) ) {
			return 'wholesale_settings';
		}

		// b2b_user_profiles vs role assignment: require user/customer/profile context.
		if ( 1 === preg_match( '/\bassign\s+role\b/', $normalized )
			&& 1 === preg_match( '/\b(user|customer|profile)\b/', $normalized ) ) {
			return 'b2b_user_profiles';
		}

		$mentions_category = 1 === preg_match( '/\b(categor(?:y|ies)|product_cat|product categor)/', $normalized );
		$mentions_product  = 1 === preg_match( '/\bproducts?\b/', $normalized );
		$mentions_create   = 1 === preg_match( '/\b(create|add|new)\b/', $normalized );
		$mentions_role     = 1 === preg_match( '/\b(role|roles)\b/', $normalized );

		if ( $mentions_create && $mentions_category ) {
			return 'woocommerce_categories';
		}

		if ( $mentions_create && $mentions_product && ! $mentions_category ) {
			return 'woocommerce_products';
		}

		if ( $mentions_create && $mentions_role && ! $mentions_pricing_setting
			&& ! preg_match( '/\b(set|default|apply)\b.{0,60}\brole\s+to\b/', $normalized ) ) {
			return 'b2b_user_roles';
		}

		return null;
	}

	/**
	 * Match all abilities that score above a minimum threshold.
	 *
	 * @param string $message   User message.
	 * @param int    $min_score Minimum cumulative phrase length score.
	 * @return list<string>
	 */
	public static function match_all( $message, $min_score = 5 ) {
		$normalized = strtolower( trim( $message ) );

		if ( '' === $normalized ) {
			return array();
		}

		$matches = array();

		foreach ( self::KEYWORD_MAP as $key => $phrases ) {
			if ( ! AbilityCatalog::is_active( $key ) ) {
				continue;
			}

			$score = 0;

			foreach ( $phrases as $phrase ) {
				if ( str_contains( $normalized, strtolower( $phrase ) ) ) {
					$score += strlen( $phrase );
				}
			}

			foreach ( AbilityDataCatalog::get_extra_keywords( $key ) as $phrase ) {
				if ( str_contains( $normalized, $phrase ) && strlen( $phrase ) >= 4 ) {
					$score += (int) floor( strlen( $phrase ) * 0.75 );
				}
			}

			foreach ( AdminSettingsRegistry::get_matcher_keywords( $key ) as $phrase ) {
				if ( str_contains( $normalized, $phrase ) && strlen( $phrase ) >= 4 ) {
					$score += (int) floor( strlen( $phrase ) * 0.85 );
				}
			}

			if ( $score >= $min_score ) {
				$matches[ $key ] = $score;
			}
		}

		if ( empty( $matches ) ) {
			return array();
		}

		arsort( $matches, SORT_NUMERIC );

		return array_keys( $matches );
	}
}
