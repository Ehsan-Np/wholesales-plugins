<?php
/**
 * WooCommerce logger wrapper for AI chat / ability debugging.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Writes structured debug logs to WooCommerce > Status > Logs.
 */
class ChatAiLogger {

	/**
	 * Log source slug shown in WooCommerce logs UI.
	 */
	const SOURCE = 'wwp-ai-assistant';

	/**
	 * Log an AI chat / ability event.
	 *
	 * @param string               $event   Event name.
	 * @param array<string, mixed> $context Structured context payload.
	 * @param string               $level   Log level: debug|info|warning|error.
	 * @return void
	 */
	public static function log( $event, array $context = array(), $level = 'debug' ) {
		if ( ! function_exists( 'wc_get_logger' ) ) {
			return;
		}

		$payload = array_merge(
			array(
				'event'     => $event,
				'user_id'   => get_current_user_id(),
				'timestamp' => gmdate( 'c' ),
			),
			$context
		);

		$message = wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );

		if ( ! is_string( $message ) ) {
			$message = print_r( $payload, true );
		}

		$logger = wc_get_logger();

		switch ( $level ) {
			case 'error':
				$logger->error( $message, array( 'source' => self::SOURCE ) );
				break;
			case 'warning':
				$logger->warning( $message, array( 'source' => self::SOURCE ) );
				break;
			case 'info':
				$logger->info( $message, array( 'source' => self::SOURCE ) );
				break;
			default:
				$logger->debug( $message, array( 'source' => self::SOURCE ) );
				break;
		}
	}
}
