<?php
/**
 * Connector service for WordPress AI provider connectors.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WordPress\AiClient\AiClient;

/**
 * Reads and manages WordPress core AI connector state.
 */
class ConnectorService {

	/**
	 * UI provider id => WordPress connector id.
	 *
	 * @var array<string, string>
	 */
	const UI_TO_WP = array(
		'openai'    => 'openai',
		'anthropic' => 'anthropic',
		'gemini'    => 'google',
	);

	/**
	 * WordPress connector id => UI provider id.
	 *
	 * @var array<string, string>
	 */
	const WP_TO_UI = array(
		'openai'    => 'openai',
		'anthropic' => 'anthropic',
		'google'    => 'gemini',
	);

	/**
	 * Supported WordPress connector IDs.
	 *
	 * @var list<string>
	 */
	const PROVIDER_IDS = array( 'openai', 'anthropic', 'google' );

	/**
	 * Settings service.
	 *
	 * @var SettingsService
	 */
	private $settings_service;

	/**
	 * Constructor.
	 *
	 * @param SettingsService|null $settings_service Optional settings service instance.
	 */
	public function __construct( $settings_service = null ) {
		$this->settings_service =( isset( $settings_service ) ? $settings_service : new SettingsService() );
	}

	/**
	 * Get all AI connector statuses for the frontend.
	 *
	 * @return list<array<string, mixed>>
	 */
	public function get_connectors() {
		if ( ! function_exists( 'wp_get_connectors' ) ) {
			return array();
		}

		if ( ! function_exists( 'validate_plugin' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$all_connectors    = wp_get_connectors();
		$connectors        = array();
		$active_providers  = $this->settings_service->get_active_providers();

		foreach ( self::PROVIDER_IDS as $wp_id ) {
			if ( ! isset( $all_connectors[ $wp_id ] ) ) {
				continue;
			}

			$connectors[] = $this->build_connector_payload( $wp_id, $all_connectors[ $wp_id ], $active_providers );
		}

		return $connectors;
	}

	/**
	 * UI provider ids that have a valid WordPress connector API key.
	 *
	 * @return list<string>
	 */
	public function get_configured_provider_ids() {
		$configured = array();

		foreach ( $this->get_connectors() as $connector ) {
			if ( ! empty( $connector['isConfigured'] ) ) {
				$configured[] = $connector['id'];
			}
		}

		return $configured;
	}

	/**
	 * Whether at least one provider is active in the assistant.
	 *
	 * @return bool
	 */
	public function has_any_active_provider() {
		return ! empty( $this->get_connected_providers() );
	}

	/**
	 * Return providers that are configured in WordPress and active in the assistant.
	 *
	 * @return list<array<string, mixed>>
	 */
	public function get_connected_providers() {
		$connected = array();

		foreach ( $this->get_connectors() as $connector ) {
			if ( empty( $connector['isConfigured'] ) || empty( $connector['isActive'] ) ) {
				continue;
			}

			$connected[] = array(
				'id'        => $connector['id'],
				'name'      => $connector['name'],
				'keyMasked' => $connector['keyMasked'],
			);
		}

		return $connected;
	}

	/**
	 * Deactivate a provider in the assistant without removing the WordPress API key.
	 *
	 * @param string $ui_id UI provider id (openai, anthropic, gemini).
	 * @return array<string, mixed>|\WP_Error
	 */
	public function deactivate_provider( $ui_id ) {
		return $this->settings_service->deactivate_provider( $ui_id );
	}

	/**
	 * Activate a provider in the assistant without changing the WordPress API key.
	 *
	 * @param string $ui_id UI provider id (openai, anthropic, gemini).
	 * @return array<string, mixed>|\WP_Error
	 */
	public function activate_provider( $ui_id ) {
		$wp_id = $this->ui_to_wp_id( $ui_id );
		if ( ! $wp_id ) {
			return new \WP_Error( 'invalid_provider', __( 'Invalid provider.', 'woocommerce-wholesale-pricing' ), array( 'status' => 400 ) );
		}

		$all_connectors = function_exists( 'wp_get_connectors' ) ? wp_get_connectors() : array();
		if ( ! isset( $all_connectors[ $wp_id ] ) ) {
			return new \WP_Error( 'invalid_provider', __( 'Provider not found.', 'woocommerce-wholesale-pricing' ), array( 'status' => 400 ) );
		}

		$is_activated = ! empty( $all_connectors[ $wp_id ]['plugin']['is_active'] ) && is_callable( $all_connectors[ $wp_id ]['plugin']['is_active'] )
			? (bool) call_user_func( $all_connectors[ $wp_id ]['plugin']['is_active'] )
			: false;

		if ( ! $this->is_provider_configured( $wp_id, $is_activated ) ) {
			return new \WP_Error(
				'provider_not_configured',
				__( 'Connect this provider with a valid API key before enabling it.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return $this->settings_service->activate_provider( $ui_id );
	}

	/**
	 * Map UI provider id to WordPress connector id.
	 *
	 * @param string $ui_id UI provider id.
	 * @return string|null
	 */
	public function ui_to_wp_id( $ui_id ) {
return ( isset( self::UI_TO_WP[ $ui_id ] ) ? self::UI_TO_WP[ $ui_id ] : null );
	}

	/**
	 * Map WordPress connector id to UI provider id.
	 *
	 * @param string $wp_id WordPress connector id.
	 * @return string|null
	 */
	public function wp_to_ui_id( $wp_id ) {
return ( isset( self::WP_TO_UI[ $wp_id ] ) ? self::WP_TO_UI[ $wp_id ] : null );
	}

	/**
	 * Build connector payload for a single provider.
	 *
	 * @param string               $wp_id            WordPress connector id.
	 * @param array<string, mixed> $data             Connector registry data.
	 * @param list<string>         $active_providers UI provider ids active in assistant.
	 * @return array<string, mixed>
	 */
	private function build_connector_payload( $wp_id, array $data, array $active_providers ) {
		$_wwp_nc = $this->wp_to_ui_id( $wp_id );
		$ui_id        =( null !== ( $_wwp_nc ) ? $_wwp_nc : $wp_id );
		$auth         =( isset( $data['authentication'] ) ? $data['authentication'] : array() );
		$setting_name =( isset( $auth['setting_name'] ) ? $auth['setting_name'] : '' );
		$plugin_file  =( isset( $data['plugin']['file'] ) ? $data['plugin']['file'] : '' );
		$plugin_slug  = $this->get_plugin_slug( $plugin_file );
		$is_activated = ! empty( $data['plugin']['is_active'] ) && is_callable( $data['plugin']['is_active'] )
			? (bool) call_user_func( $data['plugin']['is_active'] )
			: false;
		$is_installed = $is_activated;

		if ( $plugin_file && function_exists( 'validate_plugin' ) ) {
			$is_installed = $is_activated || 0 === validate_plugin( $plugin_file );
		}

		$plugin_status = 'not-installed';
		if ( $is_activated ) {
			$plugin_status = 'active';
		} elseif ( $is_installed ) {
			$plugin_status = 'inactive';
		}

		$raw_key        = $setting_name ? (string) get_option( $setting_name, '' ) : '';
		$key_masked     = $raw_key ? $this->mask_api_key( $raw_key ) : '';
		$is_configured  = $this->is_provider_configured( $wp_id, $is_activated );
		$is_active      = in_array( $ui_id, $active_providers, true );

		return array(
			'id'            => $ui_id,
			'wpId'          => $wp_id,
			'name'          => ( isset( $data['name'] ) ? $data['name'] : ucfirst( $wp_id ) ),
			'pluginStatus'  => $plugin_status,
			'isConfigured'  => $is_configured,
			'isActive'      => $is_active,
			'isConnected'   => $is_configured && $is_active,
			'keyMasked'     => $key_masked,
			'settingName'   => $setting_name,
			'pluginFile'    => $plugin_file,
			'pluginSlug'    => $plugin_slug,
			'canInstall'    => current_user_can( 'install_plugins' ),
			'canActivate'   => current_user_can( 'activate_plugins' ),
		);
	}

	/**
	 * Check if provider plugin is active and API key is valid.
	 *
	 * @param string $wp_id       WordPress connector id.
	 * @param bool   $is_activated Whether plugin is active.
	 * @return bool
	 */
	private function is_provider_configured( $wp_id, $is_activated ) {
		if ( ! $is_activated || ! class_exists( AiClient::class ) ) {
			return false;
		}

		try {
			$registry = AiClient::defaultRegistry();
			return $registry->hasProvider( $wp_id ) && $registry->isProviderConfigured( $wp_id );
		} catch ( \Exception $e ) {
			return false;
		}
	}

	/**
	 * Extract plugin slug from plugin file path.
	 *
	 * @param string $plugin_file Plugin file path.
	 * @return string
	 */
	private function get_plugin_slug( $plugin_file ) {
		$basename = str_replace( '.php', '', $plugin_file );
		if ( str_contains( $basename, '/' ) ) {
			return explode( '/', $basename )[0];
		}

		return $basename;
	}

	/**
	 * Mask an API key the same way WordPress connectors do.
	 *
	 * @param string $key Raw API key.
	 * @return string
	 */
	private function mask_api_key( $key ) {
		if ( function_exists( '_wp_connectors_mask_api_key' ) ) {
			return _wp_connectors_mask_api_key( $key );
		}

		if ( strlen( $key ) <= 4 ) {
			return $key;
		}

		return str_repeat( "\u{2022}", min( strlen( $key ) - 4, 16 ) ) . substr( $key, -4 ); // phpcs:ignore PHPCompatibility.TextStrings.NewUnicodeEscapeSequence.Found
	}
}
