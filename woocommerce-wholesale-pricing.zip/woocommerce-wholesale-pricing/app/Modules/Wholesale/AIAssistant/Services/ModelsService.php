<?php
/**
 * Fetches text-generation models for connected AI providers.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WordPress\AiClient\AiClient;
use WordPress\AiClient\Providers\Models\DTO\ModelRequirements;
use WordPress\AiClient\Providers\Models\Enums\CapabilityEnum;

/**
 * Returns text_generation models for providers active in the AI Assistant.
 */
class ModelsService {

	/**
	 * Connector service.
	 *
	 * @var ConnectorService
	 */
	private $connector_service;

	/**
	 * Constructor.
	 *
	 * @param ConnectorService|null $connector_service Optional connector service instance.
	 */
	public function __construct( $connector_service = null ) {
		$this->connector_service =( isset( $connector_service ) ? $connector_service : new ConnectorService( new SettingsService() ) );
	}

	/**
	 * Get text-generation models for connected providers.
	 *
	 * @return list<array{
	 *     id: string,
	 *     wpId: string,
	 *     name: string,
	 *     models: list<array{id: string, name: string}>
	 * }>
	 */
	public function get_connected_text_generation_models() {
		if ( ! class_exists( AiClient::class ) ) {
			return array();
		}

		$connected = $this->connector_service->get_connected_providers();
		if ( empty( $connected ) ) {
			return array();
		}

		$registry     = AiClient::defaultRegistry();
		$requirements = new ModelRequirements(
			array( CapabilityEnum::textGeneration() ),
			array()
		);

		$providers = array();

		foreach ( $connected as $provider ) {
			$ui_id =( isset( $provider['id'] ) ? $provider['id'] : '' );
			$wp_id = $this->connector_service->ui_to_wp_id( $ui_id );

			if ( ! $wp_id ) {
				continue;
			}

			try {
				if ( ! $registry->isProviderConfigured( $wp_id ) ) {
					continue;
				}

				$models = $registry->findProviderModelsMetadataForSupport( $wp_id, $requirements );
				if ( empty( $models ) ) {
					continue;
				}

				$provider_class = $registry->getProviderClassName( $wp_id );
				$provider_name  = $provider_class::metadata()->getName();

				$model_items = array();
				foreach ( $models as $model ) {
					if ( $this->is_image_generation_model( $model ) ) {
						continue;
					}

					$model_items[] = array(
						'id'   => $model->getId(),
						'name' => $model->getName(),
					);
				}

				if ( empty( $model_items ) ) {
					continue;
				}

				$providers[] = array(
					'id'     => $ui_id,
					'wpId'   => $wp_id,
					'name'   => $provider_name,
					'models' => $model_items,
				);
			} catch ( \Throwable $e ) {
				continue;
			}
		}

		return $providers;
	}

	/**
	 * Whether a model should be excluded because it supports image generation.
	 *
	 * @param \WordPress\AiClient\Providers\Models\DTO\ModelMetadata $model Model metadata.
	 * @return bool
	 */
	private function is_image_generation_model( $model ) {
		foreach ( $model->getSupportedCapabilities() as $capability ) {
			if ( $capability->isImageGeneration() ) {
				return true;
			}
		}

		return false;
	}
}
