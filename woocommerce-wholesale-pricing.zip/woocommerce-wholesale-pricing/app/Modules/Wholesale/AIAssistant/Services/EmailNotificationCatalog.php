<?php
/**
 * Maps email notification phrases to wholesale_email_notifications keys.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Central catalog for wholesale_email_notifications intent matching.
 */
class EmailNotificationCatalog {

	use SettingCatalogTrait;

	/**
	 * Get Entries
	 * 
	 * @return array<string, array<string, mixed>>
	 */
	private static function get_entries() {
		static $entries = null;

		if ( null !== $entries ) {
			return $entries;
		}

		$entries = array(
			'admin_new_registration' => array(
				'key'              => 'admin_new_registration',
				'label'            => 'Admin New Registration Email',
				'notification_key' => 'admin_new_registration',
				'phrases'          => array(
					'admin registration notification',
					'admin new registration email',
					'new registration request admin email',
					'admin notification registration',
				),
			),
			'user_new_registration' => array(
				'key'              => 'user_new_registration',
				'label'            => 'User Registration Confirmation Email',
				'notification_key' => 'user_new_registration',
				'phrases'          => array(
					'user registration email',
					'registration confirmation email',
					'new registration user email',
				),
			),
			'user_registration_rejection' => array(
				'key'              => 'user_registration_rejection',
				'label'            => 'Registration Rejection Email',
				'notification_key' => 'user_registration_rejection',
				'phrases'          => array(
					'rejection email',
					'registration rejected email',
					'registration rejection notification',
				),
			),
			'user_registration_approval' => array(
				'key'              => 'user_registration_approval',
				'label'            => 'Registration Approval Email',
				'notification_key' => 'user_registration_approval',
				'phrases'          => array(
					'approval email',
					'registration approved email',
					'registration approval notification',
				),
			),
			'user_role_upgrade' => array(
				'key'              => 'user_role_upgrade',
				'label'            => 'Role Upgrade Email',
				'notification_key' => 'user_role_upgrade',
				'phrases'          => array(
					'role upgrade notification',
					'subscription upgrade email',
					'upgrade role email',
				),
			),
		);

		return $entries;
	}

	/**
	 * Resolve entry from message
	 * 
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	public static function resolve_entry_from_message( $normalized ) {
		return self::resolve_entry_from_phrases( $normalized, self::get_entries() );
	}

	/**
	 * Build mutation args
	 * 
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>
	 */
	public static function build_mutation_args( $normalized ) {
		$entry = self::resolve_entry_from_message( $normalized );

		if ( ! is_array( $entry ) ) {
			return array();
		}

		$args = array(
			'action'           => 'update',
			'notification_key' => (string) ( ( isset( $entry['notification_key'] ) ? $entry['notification_key'] : '' ) ),
		);

		if ( self::matches_enable_intent( $normalized ) && ! self::matches_disable_intent( $normalized ) ) {
			$args['enabled'] = true;
		} elseif ( self::matches_disable_intent( $normalized ) && ! self::matches_enable_intent( $normalized ) ) {
			$args['enabled'] = false;
		}

		if ( preg_match( '/subject(?:\s+to|\s+is|\s*:)\s*["\']?([^"\']+)["\']?/i', $normalized, $matches ) ) {
			$args['subject'] = trim( $matches[1] );
		}

		return $args;
	}

	/**
	 * Get matched keywords
	 * 
	 * @return list<string>
	 */
	public static function get_matcher_keywords() {
		return self::collect_matcher_keywords( self::get_entries() );
	}

	/**
	 * Get hint lines
	 * 
	 * @return list<string>
	 */
	public static function get_hint_lines() {
		return self::collect_hint_lines( self::get_entries() );
	}

	/**
	 * Format mutation summary
	 * 
	 * @param array<string, mixed> $args Mutation args.
	 * @return string
	 */
	public static function format_mutation_summary( array $args ) {
		$key = (string) ( ( isset( $args['notification_key'] ) ? $args['notification_key'] : '' ) );

		foreach ( self::get_entries() as $entry ) {
			if ( ( ( isset( $entry['notification_key'] ) ? $entry['notification_key'] : '' ) ) !== $key ) {
				continue;
			}

			$label = (string) $entry['label'];

			if ( isset( $args['enabled'] ) ) {
				if ( $args['enabled'] ) {
					/* translators: %s: notification label */
					return sprintf( __( 'Enable %s', 'woocommerce-wholesale-pricing' ), $label );
				}

				/* translators: %s: notification label */
				return sprintf( __( 'Disable %s', 'woocommerce-wholesale-pricing' ), $label );
			}

			if ( isset( $args['subject'] ) ) {
				/* translators: 1: notification label, 2: subject */
				return sprintf( __( 'Update subject for %1$s to "%2$s"', 'woocommerce-wholesale-pricing' ), $label, $args['subject'] );
			}

			return sprintf(
				/* translators: %s: notification label */
				__( 'Update %s', 'woocommerce-wholesale-pricing' ),
				$label
			);
		}

		return $key;
	}
}
