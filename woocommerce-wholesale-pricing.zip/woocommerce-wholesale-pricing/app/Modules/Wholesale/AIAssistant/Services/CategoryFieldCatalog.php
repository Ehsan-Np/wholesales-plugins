<?php
/**
 * Maps category-level wholesale field phrases to woocommerce_categories keys.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Catalog for category term meta fields.
 */
class CategoryFieldCatalog {

	use SettingCatalogTrait;

	/**
	 * Get Entries
	 * 
	 * @return array<string, array<string, mixed>>
	 */
	private static function get_entries() {
		static $entries = null;

		if ( null !== $entries ) {
			return $entries;
		}

		$entries = array(
			'visibility_multi' => array(
				'key'     => 'wholesale_product_visibility_multi',
				'label'   => 'Hide Category for Wholesaler Roles',
				'phrases' => array( 'hide category for wholesaler', 'category visibility wholesaler' ),
			),
			'visibility_customer' => array(
				'key'     => 'wholesale_product_visibility_multi_customer',
				'label'   => 'Hide Category for Non-Wholesale Users',
				'phrases' => array( 'hide category for customer', 'hide category non wholesale' ),
			),
			'wholesale_price' => array(
				'key'     => 'wholesale_price',
				'label'   => 'Category Wholesale Price',
				'phrases' => array( 'category wholesale price', 'wholesale price category' ),
			),
			'min_quantity' => array(
				'key'     => 'min_quatity',
				'label'   => 'Category Minimum Quantity',
				'phrases' => array( 'category min quantity', 'minimum quantity category' ),
			),
			'tier_pricing' => array(
				'key'     => 'category_tier_pricing',
				'label'   => 'Category Tier Pricing',
				'phrases' => array( 'category tier pricing', 'tier pricing category' ),
			),
		);

		return $entries;
	}

	/**
	 * Resolve entry from message
	 * 
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	public static function resolve_entry_from_message( $normalized ) {
		return self::resolve_entry_from_phrases( $normalized, self::get_entries() );
	}

	/**
	 * Build mutation args
	 * 
	 * @param string $message Original message.
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>
	 */
	public static function build_mutation_args( $message, $normalized ) {
		$entry = self::resolve_entry_from_message( $normalized );

		if ( ! is_array( $entry ) ) {
			return array();
		}

		$identifier = self::extract_identifier( $message );

		if ( null === $identifier ) {
			return array();
		}

		$key  = (string) ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) );
		$args = array(
			'action'     => 'update',
			'identifier' => $identifier,
		);

		if ( preg_match( '/(\d+(?:\.\d+)?)\s*%/', $normalized, $percent ) && 'wholesale_price' === $key ) {
			$args['wholesale_multi_user_pricing'] = array(
				'wholesale_price' => $percent[1],
				'discount_type'   => 'percent',
			);

			return $args;
		}

		if ( self::matches_enable_intent( $normalized ) || self::matches_disable_intent( $normalized ) ) {
			$enabled = self::matches_enable_intent( $normalized ) && ! self::matches_disable_intent( $normalized );
			$args['meta'] = array( $key => $enabled ? 'yes' : '' );

			return $args;
		}

		return array();
	}

	/**
	 * Extract indentifier
	 * 
	 * @param string $message Original message.
	 * @return int|string|null
	 */
	public static function extract_identifier( $message ) {
		if ( preg_match( '/\b(?:category|id)\s*#?\s*(\d+)\b/i', $message, $matches ) ) {
			return (int) $matches[1];
		}

		if ( preg_match( '/category\s+"([^"]+)"/i', $message, $matches ) ) {
			return $matches[1];
		}

		return null;
	}

	/**
	 * Get matched keywords
	 * 
	 * @return list<string>
	 */
	public static function get_matcher_keywords() {
		return self::collect_matcher_keywords( self::get_entries() );
	}

	/**
	 * Get hint lines
	 * 
	 * @return list<string>
	 */
	public static function get_hint_lines() {
		return self::collect_hint_lines( self::get_entries() );
	}

	/**
	 * Format mutation summary
	 * 
	 * @param array<string, mixed> $args Mutation args.
	 * @return string
	 */
	public static function format_mutation_summary( array $args ) {
		return sprintf(
			/* translators: %s: category identifier */
			__( 'Update category %s', 'woocommerce-wholesale-pricing' ),
( isset( $args['identifier'] ) ? $args['identifier'] : '' )
		);
	}
}
