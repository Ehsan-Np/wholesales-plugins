<?php
/**
 * Persists and retrieves AI Assistant change history rows.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleOption;

/**
 * Change history persistence service.
 */
class ChangeHistoryService {

	/**
	 * Settings service.
	 *
	 * @var SettingsService
	 */
	private $settings_service;

	/**
	 * Constructor.
	 *
	 * @param SettingsService|null $settings_service Optional settings service.
	 */
	public function __construct( $settings_service = null ) {
		$this->settings_service =( isset( $settings_service ) ? $settings_service : new SettingsService() );
	}

	/**
	 * Get the full table name including prefix.
	 *
	 * @return string
	 */
	public function get_table_name() {
		global $wpdb;

		return $wpdb->prefix . WholesaleOption::AI_CHANGE_HISTORY_TABLE;
	}

	/**
	 * Record a new change history entry.
	 *
	 * @param array<string, mixed> $entry Entry data.
	 * @return int|\WP_Error Inserted row id or error.
	 */
	public function record( array $entry ) {
		global $wpdb;

		if ( ChatExecutionContext::is_active() ) {
			if ( empty( $entry['prompt'] ) ) {
				$entry['prompt'] = ChatExecutionContext::get_prompt();
			}

			if ( empty( $entry['model'] ) ) {
				$entry['model'] = ChatExecutionContext::get_model();
			}
		}

		$user_id = get_current_user_id();
		if ( ! $user_id ) {
			$user_id = isset( $entry['user_id'] ) ? (int) $entry['user_id'] : 0;
		}

		$tool               = sanitize_text_field( (string) ( ( isset( $entry['tool'] ) ? $entry['tool'] : '' ) ) );
		$change_description = sanitize_textarea_field( (string) ( ( isset( $entry['change_description'] ) ? $entry['change_description'] : '' ) ) );
		$action_type        = sanitize_text_field( (string) ( ( isset( $entry['action_type'] ) ? $entry['action_type'] : '' ) ) );
		$resource_type      = sanitize_text_field( (string) ( ( isset( $entry['resource_type'] ) ? $entry['resource_type'] : '' ) ) );

		if ( '' === $tool || '' === $change_description || '' === $action_type || '' === $resource_type ) {
			return new \WP_Error(
				'wwp_ai_history_invalid_entry',
				__( 'Change history entry is missing required fields.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$resource     = $this->encode_json_field(( isset( $entry['resource'] ) ? $entry['resource'] : array() ));
		$before_state = isset( $entry['before_state'] ) && null !== $entry['before_state']
			? $this->encode_json_field( $entry['before_state'] )
			: null;

		$inserted = $wpdb->insert(
			$this->get_table_name(),
			array(
				'user_id'            => $user_id,
				'created_at'         => current_time( 'mysql' ),
				'tool'               => $tool,
				'change_description' => $change_description,
				'status'             => 1,
				'action_type'        => $action_type,
				'resource_type'      => $resource_type,
				'resource'           => $resource,
				'before_state'       => $before_state,
				'prompt'             => isset( $entry['prompt'] ) ? sanitize_textarea_field( (string) $entry['prompt'] ) : null,
				'ability'            => isset( $entry['ability'] ) ? sanitize_text_field( (string) $entry['ability'] ) : null,
				'model'              => isset( $entry['model'] ) ? sanitize_text_field( (string) $entry['model'] ) : null,
			),
			array(
				'%d',
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
			)
		);

		if ( false === $inserted ) {
			return new \WP_Error(
				'wwp_ai_history_insert_failed',
				__( 'Failed to record change history.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		$id = (int) $wpdb->insert_id;

		if ( ChatExecutionContext::is_active() ) {
			ChatExecutionContext::add_applied_change( $id );
		}

		$this->prune_excess();

		return $id;
	}

	/**
	 * List change history rows.
	 *
	 * @param int|null $limit Optional limit override.
	 * @return list<array<string, mixed>>
	 */
	public function list_records( $limit = null ) {
		global $wpdb;

		if ( null === $limit ) {
			$limit = $this->get_rollback_limit();
		}

		$limit = max( 1, min( 100, $limit ) );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$this->get_table_name()} ORDER BY created_at DESC, id DESC LIMIT %d",
				$limit
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( ! is_array( $rows ) ) {
			return array();
		}

		return array_map( array( $this, 'format_row_for_api' ), $rows );
	}

	/**
	 * Get a single row by id.
	 *
	 * @param int $id Row id.
	 * @return array<string, mixed>|null
	 */
	public function get( $id ) {
		global $wpdb;

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->get_table_name()} WHERE id = %d",
				$id
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( ! is_array( $row ) ) {
			return null;
		}

		return $this->format_row_for_api( $row, true );
	}

	/**
	 * Get raw row with decoded JSON for undo operations.
	 *
	 * @param int $id Row id.
	 * @return array<string, mixed>|null
	 */
	public function get_raw( $id ) {
		global $wpdb;

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->get_table_name()} WHERE id = %d",
				$id
			),
			ARRAY_A
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( ! is_array( $row ) ) {
			return null;
		}

		$row['resource']     = $this->decode_json_field(( isset( $row['resource'] ) ? $row['resource'] : '' ));
		$row['before_state'] = $this->decode_json_field(( isset( $row['before_state'] ) ? $row['before_state'] : '' ));

		return $row;
	}

	/**
	 * Mark a row as undone.
	 *
	 * @param int $id      Row id.
	 * @param int $user_id User performing undo.
	 * @return bool
	 */
	public function mark_undone( $id, $user_id ) {
		global $wpdb;

		$updated = $wpdb->update(
			$this->get_table_name(),
			array(
				'status'    => 0,
				'undone_at' => current_time( 'mysql' ),
				'undone_by' => $user_id,
			),
			array( 'id' => $id ),
			array( '%d', '%s', '%d' ),
			array( '%d' )
		);

		return false !== $updated;
	}

	/**
	 * Delete all change history rows.
	 *
	 * @return bool
	 */
	public function clear_all() {
		global $wpdb;

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$deleted = $wpdb->query( "DELETE FROM {$this->get_table_name()}" );
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		return false !== $deleted;
	}

	/**
	 * Delete rows beyond the rollback window.
	 *
	 * @return void
	 */
	public function prune_excess() {
		global $wpdb;

		$limit = $this->get_rollback_limit();

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ids_to_keep = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM {$this->get_table_name()} ORDER BY created_at DESC, id DESC LIMIT %d",
				$limit
			)
		);
		// phpcs:enable WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		if ( empty( $ids_to_keep ) ) {
			return;
		}

		$placeholders = implode( ',', array_fill( 0, count( $ids_to_keep ), '%d' ) );

		$wpdb->query(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
				"DELETE FROM {$this->get_table_name()} WHERE id NOT IN ({$placeholders})",
				...array_map( 'intval', $ids_to_keep )
			)
		);
	}

	/**
	 * Resolve the configured rollback window size.
	 *
	 * @return int
	 */
	private function get_rollback_limit() {
		$settings  = $this->settings_service->get_settings();
		$defaults  = $this->settings_service->get_defaults();
		$rollback  = (string) ( ( isset( $settings['rollback'] ) ? $settings['rollback'] : $defaults['rollback'] ) );

		return max( 1, (int) $rollback );
	}

	/**
	 * Format a database row for API output.
	 *
	 * @param array<string, mixed> $row         Database row.
	 * @param bool                 $include_raw Include decoded resource data.
	 * @return array<string, mixed>
	 */
	private function format_row_for_api( array $row, $include_raw = false ) {
		$is_active = (int) ( ( isset( $row['status'] ) ? $row['status'] : 0 ) ) === 1;

		$formatted = array(
			'id'                => (int) $row['id'],
			'userId'            => (int) ( ( isset( $row['user_id'] ) ? $row['user_id'] : 0 ) ),
			'createdAt'         => (string) ( ( isset( $row['created_at'] ) ? $row['created_at'] : '' ) ),
			'tool'              => (string) ( ( isset( $row['tool'] ) ? $row['tool'] : '' ) ),
			'changeDescription' => (string) ( ( isset( $row['change_description'] ) ? $row['change_description'] : '' ) ),
			'status'            => $is_active ? 'active' : 'undone',
			'actionType'        => (string) ( ( isset( $row['action_type'] ) ? $row['action_type'] : '' ) ),
			'resourceType'      => (string) ( ( isset( $row['resource_type'] ) ? $row['resource_type'] : '' ) ),
			'resourceSummary'   => $this->build_resource_summary( $row ),
			'ability'           => isset( $row['ability'] ) ? (string) $row['ability'] : null,
			'prompt'           => isset( $row['prompt'] ) ? (string) $row['prompt'] : null,
			'model'             => isset( $row['model'] ) ? (string) $row['model'] : null,
			'undoneAt'          => ! empty( $row['undone_at'] ) ? (string) $row['undone_at'] : null,
			'undoneBy'          => ! empty( $row['undone_by'] ) ? (int) $row['undone_by'] : null,
			'canUndo'           => $is_active,
		);

		if ( $include_raw ) {
			$formatted['resource']     = $this->decode_json_field(( isset( $row['resource'] ) ? $row['resource'] : '' ));
			$formatted['beforeState']  = $this->decode_json_field(( isset( $row['before_state'] ) ? $row['before_state'] : '' ));
			$formatted['prompt']       = isset( $row['prompt'] ) ? (string) $row['prompt'] : null;
		}

		return $formatted;
	}

	/**
	 * Build a short summary from stored resource JSON.
	 *
	 * @param array<string, mixed> $row Database row.
	 * @return string
	 */
	private function build_resource_summary( array $row ) {
		$resource = $this->decode_json_field(( isset( $row['resource'] ) ? $row['resource'] : '' ));
		if ( ! is_array( $resource ) || empty( $resource ) ) {
			return '';
		}

		if ( isset( $resource['name'] ) ) {
			return (string) $resource['name'];
		}

		if ( isset( $resource['slug'] ) ) {
			return (string) $resource['slug'];
		}

		if ( isset( $resource['id'] ) ) {
			return '#' . (string) $resource['id'];
		}

		if ( isset( $resource['user_email'] ) ) {
			return (string) $resource['user_email'];
		}

		return '';
	}

	/**
	 * Encode a value as JSON for storage.
	 *
	 * @param mixed $value Value to encode.
	 * @return string
	 */
	private function encode_json_field( $value ) {
		$encoded = wp_json_encode( $value );
		return is_string( $encoded ) ? $encoded : '{}';
	}

	/**
	 * Decode a JSON field from storage.
	 *
	 * @param string $value Stored JSON string.
	 * @return mixed
	 */
	private function decode_json_field( $value ) {
		if ( '' === $value ) {
			return null;
		}

		$decoded = json_decode( $value, true );
		return JSON_ERROR_NONE === json_last_error() ? $decoded : null;
	}
}
