<?php
/**
 * Maps B2B user role field phrases to b2b_user_roles keys.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Catalog for wholesale user role term meta fields.
 */
class RoleFieldCatalog {

	use SettingCatalogTrait;

	/**
	 * Get entries
	 * 
	 * @return array<string, array<string, mixed>>
	 */
	private static function get_entries() {
		static $entries = null;

		if ( null !== $entries ) {
			return $entries;
		}

		$entries = array(
			'tax_exempt' => array(
				'key'     => 'wwp_tax_exmept_wholesaler',
				'label'   => 'Tax Exempt',
				'phrases' => array( 'tax exempt', 'tax exemption role', 'exempt from tax' ),
			),
			'tax_class' => array(
				'key'     => 'wwp_wholesaler_tax_classes',
				'label'   => 'Tax Class',
				'phrases' => array( 'tax class role', 'wholesaler tax class' ),
			),
			'disable_coupons' => array(
				'key'     => 'wwp_wholesale_disable_coupons',
				'label'   => 'Disable Coupons',
				'phrases' => array( 'disable coupons role', 'role disable coupons' ),
			),
			'restricted_payment' => array(
				'key'     => 'wwp_restricted_pmethods_wholesaler',
				'label'   => 'Disable Payment Methods',
				'phrases' => array( 'disable payment methods role', 'restricted payment methods' ),
			),
			'restricted_shipping' => array(
				'key'     => 'wwp_restricted_smethods_wholesaler',
				'label'   => 'Disable Shipping Methods',
				'phrases' => array( 'disable shipping methods role', 'restricted shipping methods' ),
			),
			'store_password' => array(
				'key'     => 'password',
				'label'   => 'Store Access Password',
				'phrases' => array( 'store access password', 'wholesale store password role' ),
			),
			'subscription' => array(
				'key'     => 'wwp_wholesaler_subscription',
				'label'   => 'Subscription Variation',
				'phrases' => array( 'role subscription', 'subscription variation role' ),
			),
		);

		return $entries;
	}

	/**
	 * Resolve entry from message
	 * 
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>|null
	 */
	public static function resolve_entry_from_message( $normalized ) {
		return self::resolve_entry_from_phrases( $normalized, self::get_entries() );
	}

	/**
	 * Build mutation args
	 * 
	 * @param string $message Original message.
	 * @param string $normalized Lowercased message.
	 * @return array<string, mixed>
	 */
	public static function build_mutation_args( $message, $normalized ) {
		$entry = self::resolve_entry_from_message( $normalized );

		if ( ! is_array( $entry ) ) {
			return array();
		}

		$identifier = self::extract_role_identifier( $message, $normalized );

		if ( null === $identifier ) {
			return array();
		}

		$key  = (string) ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) );
		$args = array(
			'action'     => 'update',
			'identifier' => $identifier,
		);

		if ( self::matches_enable_intent( $normalized ) || self::matches_disable_intent( $normalized ) ) {
			$enabled = self::matches_enable_intent( $normalized ) && ! self::matches_disable_intent( $normalized );

			if ( 'wwp_tax_exmept_wholesaler' === $key || 'wwp_wholesale_disable_coupons' === $key ) {
				$args['role'] = array( str_replace( 'wwp_', '', str_replace( '_wholesaler', '', $key ) ) => $enabled ? 'yes' : '' );
			} else {
				$args['role'] = array( $key => $enabled ? 'yes' : '' );
			}

			return $args;
		}

		return array();
	}

	/**
	 * Extract role indentifier
	 * 
	 * @param string $message Original message.
	 * @param string $normalized Lowercased message.
	 * @return string|null
	 */
	public static function extract_role_identifier( $message, $normalized ) {
		if ( preg_match( '/\brole\s+([a-z0-9_-]+)\b/i', $message, $matches ) ) {
			return sanitize_key( $matches[1] );
		}

		if ( preg_match( '/\brole\s+"([^"]+)"/i', $message, $matches ) ) {
			return sanitize_title( $matches[1] );
		}

		return null;
	}

	/**
	 * Get matcher keywords
	 * 
	 * @return list<string>
	 */
	public static function get_matcher_keywords() {
		return self::collect_matcher_keywords( self::get_entries() );
	}

	/**
	 * Get hint lines
	 * 
	 * @return list<string>
	 */
	public static function get_hint_lines() {
		return self::collect_hint_lines( self::get_entries() );
	}

	/**
	 * Format mutation summary
	 * 
	 * @param array<string, mixed> $args Mutation args.
	 * @return string
	 */
	public static function format_mutation_summary( array $args ) {
		return sprintf(
			/* translators: %s: role identifier */
			__( 'Update role %s', 'woocommerce-wholesale-pricing' ),
( isset( $args['identifier'] ) ? $args['identifier'] : '' )
		);
	}
}
