<?php
/**
 * Maps admin-facing wholesale setting phrases to option keys.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Central catalog for wholesale_settings intent matching and approval summaries.
 */
class WholesaleSettingsCatalog {

	use SettingCatalogTrait;

	/**
	 * Settings stored as yes/no.
	 *
	 * @var list<string>
	 */
	const YES_NO_KEYS = array(
		'disable_auto_role',
		'enable_admin_new_order_item',
		'wwp_hide_add_to_cart',
		'advance_registration_form',
		'wwp_hide_price',
		'enable_strike_through_price',
		'enable_groups',
		'enable_registration_page',
		'over_right_wholesale_form',
		'wholesaler_prodcut_only',
		'enable_upgrade',
		'retailer_disabled',
		'save_price_disabled',
		'restrict_store_access',
		'wholesaler_allow_minimum_qty',
	);

	/**
	 * Settings stored as yes when enabled, empty when disabled.
	 *
	 * @var list<string>
	 */
	const YES_EMPTY_KEYS = array(
		'enable_coupon',
		'requisition_list',
		'requisition_list_cart_page',
		'variation_table_enable',
		'request_for_sample_enable',
		'enable_wholesale_price',
		'enable_non_logged_shop_page_wholesale_price',
		'enable_non_logged_product_page_wholesale_price',
		'enable_subscription',
		'retailer_price_disabled',
		'wholesaler_disabled',
		'wholesaler_price_disabled',
		'save_price_label_disabled',
		'price_hide',
		'wholesaler_login_restriction',
		'enable_store_access_cookie',
		'non_wholesale_product_hide',
		'request_again_submit',
		'enable_custom_payment_method',
	);

	/**
	 * Catalog entries keyed by setting key.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	private static function get_entries() {
		static $entries = null;

		if ( null !== $entries ) {
			return $entries;
		}

		$entries = array(
			'request_again_submit' => array(
				'key'     => 'request_again_submit',
				'label'   => 'Request Again Submit',
				'storage' => 'yes_empty',
				'phrases' => array( 'request again submit', 'request again', 'submit again', 'upgrade request' ),
			),
			'wholesaler_allow_minimum_qty' => array(
				'key'     => 'wholesaler_allow_minimum_qty',
				'label'   => 'Enforce minimum quantity rules',
				'storage' => 'yes_no',
				'phrases' => array( 'minimum quantity', 'enforce minimum', 'minimum qty rules' ),
			),
			'requisition_list' => array(
				'key'     => 'requisition_list',
				'label'   => 'Requisition list',
				'storage' => 'yes_empty',
				'phrases' => array( 'requisition list' ),
			),
			'requisition_list_cart_page' => array(
				'key'     => 'requisition_list_cart_page',
				'label'   => 'Requisition list on cart page',
				'storage' => 'yes_empty',
				'phrases' => array( 'requisition list cart', 'requisition on cart page' ),
			),
			'enable_registration_page' => array(
				'key'     => 'enable_registration_page',
				'label'   => 'Enable Registration Link',
				'storage' => 'yes_no',
				'phrases' => array( 'registration link', 'enable registration page', 'enable registration link' ),
			),
			'disable_auto_role' => array(
				'key'      => 'disable_auto_role',
				'label'    => 'Registration auto-approve',
				'storage'  => 'yes_no',
				'inverted' => true,
				'phrases'  => array( 'auto approv', 'auto approve', 'registration approv', 'registration approval', 'manual approval' ),
			),
			'enable_upgrade' => array(
				'key'     => 'enable_upgrade',
				'label'   => 'Wholesale upgrade tab',
				'storage' => 'yes_no',
				'phrases' => array( 'wholesale upgrade', 'upgrade tab', 'enable upgrade tab' ),
			),
			'wwp_hide_add_to_cart' => array(
				'key'     => 'wwp_hide_add_to_cart',
				'label'   => 'Hide add to cart',
				'storage' => 'yes_no',
				'phrases' => array( 'hide add to cart', 'hide add-to-cart' ),
			),
			'wwp_hide_price' => array(
				'key'     => 'wwp_hide_price',
				'label'   => 'Hide price',
				'storage' => 'yes_no',
				'phrases' => array( 'hide price' ),
			),
			'enable_strike_through_price' => array(
				'key'     => 'enable_strike_through_price',
				'label'   => 'Strike-through price',
				'storage' => 'yes_no',
				'phrases' => array( 'strike through', 'strikethrough price', 'strike-through price' ),
			),
			'wholesaler_login_restriction' => array(
				'key'     => 'wholesaler_login_restriction',
				'label'   => 'Login restriction',
				'storage' => 'yes_empty',
				'phrases' => array( 'login restriction', 'restrict wholesale store access', 'wholesaler login restriction' ),
			),
			'restrict_store_access' => array(
				'key'     => 'restrict_store_access',
				'label'   => 'Restrict store access',
				'storage' => 'yes_no',
				'phrases' => array( 'restrict store access', 'full store access restriction' ),
			),
			'enable_coupon' => array(
				'key'     => 'enable_coupon',
				'label'   => 'Wholesale coupons',
				'storage' => 'yes_empty',
				'phrases' => array( 'wholesale coupon', 'enable coupon', 'wholesale coupons' ),
			),
			'variation_table_enable' => array(
				'key'     => 'variation_table_enable',
				'label'   => 'Variation table',
				'storage' => 'yes_empty',
				'phrases' => array( 'variation table', 'enable variation table' ),
			),
			'request_for_sample_enable' => array(
				'key'     => 'request_for_sample_enable',
				'label'   => 'Request for sample',
				'storage' => 'yes_empty',
				'phrases' => array( 'request for sample', 'sample request' ),
			),
			'enable_wholesale_price' => array(
				'key'     => 'enable_wholesale_price',
				'label'   => 'Wholesale price for non-logged-in',
				'storage' => 'yes_empty',
				'phrases' => array( 'wholesale price for guest', 'non logged in wholesale price', 'display wholesaler price' ),
			),
			'enable_non_logged_shop_page_wholesale_price' => array(
				'key'     => 'enable_non_logged_shop_page_wholesale_price',
				'label'   => 'Shop page wholesale price for guests',
				'storage' => 'yes_empty',
				'phrases' => array( 'shop page wholesale price', 'guest shop page price' ),
			),
			'enable_non_logged_product_page_wholesale_price' => array(
				'key'     => 'enable_non_logged_product_page_wholesale_price',
				'label'   => 'Product page wholesale price for guests',
				'storage' => 'yes_empty',
				'phrases' => array( 'product page wholesale price', 'guest product page price' ),
			),
			'enable_subscription' => array(
				'key'     => 'enable_subscription',
				'label'   => 'Wholesale for subscription',
				'storage' => 'yes_empty',
				'phrases' => array( 'wholesale subscription', 'enable subscription wholesale' ),
			),
			'enable_groups' => array(
				'key'     => 'enable_groups',
				'label'   => 'Enable groups',
				'storage' => 'yes_no',
				'phrases' => array( 'enable group', 'enable groups', 'wholesale groups' ),
			),
			'advance_registration_form' => array(
				'key'     => 'advance_registration_form',
				'label'   => 'Advanced registration form',
				'storage' => 'yes_no',
				'phrases' => array( 'advance registration form', 'advanced registration form' ),
			),
			'over_right_wholesale_form' => array(
				'key'     => 'over_right_wholesale_form',
				'label'   => 'Override registration form',
				'storage' => 'yes_no',
				'phrases' => array( 'override registration form', 'registration form override', 'override my account registration' ),
			),
			'price_hide' => array(
				'key'     => 'price_hide',
				'label'   => 'Hide price until logged in',
				'storage' => 'yes_empty',
				'phrases' => array( 'hide price until login', 'price hide until logged in' ),
			),
			'enable_store_access_cookie' => array(
				'key'     => 'enable_store_access_cookie',
				'label'   => 'Store access cookie',
				'storage' => 'yes_empty',
				'phrases' => array( 'store access cookie', 'enable cookie access' ),
			),
			'non_wholesale_product_hide' => array(
				'key'     => 'non_wholesale_product_hide',
				'label'   => 'Hide wholesale products from non-wholesalers',
				'storage' => 'yes_empty',
				'phrases' => array( 'non wholesale product hide', 'hide wholesale from non wholesalers' ),
			),
			'wholesaler_prodcut_only' => array(
				'key'     => 'wholesaler_prodcut_only',
				'label'   => 'Wholesaler products only',
				'storage' => 'yes_no',
				'phrases' => array( 'wholesaler product only', 'wholesaler products only', 'restrict wholesale products visibility' ),
			),
			'enable_custom_payment_method' => array(
				'key'     => 'enable_custom_payment_method',
				'label'   => 'Custom payment method',
				'storage' => 'yes_empty',
				'phrases' => array( 'custom payment method', 'enable custom payment' ),
			),
			'retailer_disabled' => array(
				'key'     => 'retailer_disabled',
				'label'   => 'Hide retailer price label',
				'storage' => 'yes_no',
				'phrases' => array( 'hide retailer label', 'retailer label disabled' ),
			),
			'retailer_price_disabled' => array(
				'key'     => 'retailer_price_disabled',
				'label'   => 'Hide retailer price',
				'storage' => 'yes_empty',
				'phrases' => array( 'hide retailer price', 'retailer price disabled' ),
			),
			'wholesaler_disabled' => array(
				'key'     => 'wholesaler_disabled',
				'label'   => 'Hide wholesaler price label',
				'storage' => 'yes_empty',
				'phrases' => array( 'hide wholesaler label', 'wholesaler label disabled' ),
			),
			'wholesaler_price_disabled' => array(
				'key'     => 'wholesaler_price_disabled',
				'label'   => 'Hide wholesaler price',
				'storage' => 'yes_empty',
				'phrases' => array( 'hide wholesaler price', 'wholesaler price disabled' ),
			),
			'save_price_label_disabled' => array(
				'key'     => 'save_price_label_disabled',
				'label'   => 'Hide save price label',
				'storage' => 'yes_empty',
				'phrases' => array( 'hide save label', 'save price label disabled' ),
			),
			'save_price_disabled' => array(
				'key'     => 'save_price_disabled',
				'label'   => 'Hide save price',
				'storage' => 'yes_no',
				'phrases' => array( 'hide save price', 'save price disabled' ),
			),
			'enable_admin_new_order_item' => array(
				'key'     => 'enable_admin_new_order_item',
				'label'   => 'Admin new order item',
				'storage' => 'yes_no',
				'phrases' => array( 'admin new order item', 'enable admin order item' ),
			),
			'default_multipe_wholesale_roles' => array(
				'key'     => 'default_multipe_wholesale_roles',
				'label'   => 'Default Multi Wholesale Role',
				'storage' => 'role_slug',
				'phrases' => array(
					'default multi wholesale role',
					'default wholesale role',
					'multi wholesale role',
					'default role for wholesale',
				),
			),
			'wholesale_price_application' => array(
				'key'     => 'wholesale_price_application',
				'label'   => 'Apply Wholesale Price On',
				'storage' => 'price_application',
				'phrases' => array(
					'apply wholesale price on',
					'wholesale price on',
					'price application',
					'apply wholesale price',
				),
			),
			'wholesale_role' => array(
				'key'     => 'wholesale_role',
				'label'   => 'Wholesale Role Mode',
				'storage' => 'wholesale_role_mode',
				'phrases' => array(
					'single wholesale role',
					'multiple wholesale roles',
					'pricing mode',
				),
			),
		);

		return $entries;
	}

	/**
	 * Extra matcher keywords for wholesale_settings ability routing.
	 *
	 * @return list<string>
	 */
	public static function get_matcher_keywords() {
		return array_values(
			array_unique(
				array_merge(
					self::collect_matcher_keywords( self::get_entries() ),
					QuoteCustomizationCatalog::get_matcher_keywords()
				)
			)
		);
	}

	/**
	 * Get Hint lines
	 * 
	 * @return list<string>
	 */
	public static function get_hint_lines() {
		return array_merge(
			self::collect_hint_lines( self::get_entries() ),
			QuoteCustomizationCatalog::get_hint_lines()
		);
	}

	/**
	 * Resolve a setting key from a normalized user message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function resolve_key_from_message( $normalized ) {
		$quote_key = QuoteCustomizationCatalog::resolve_key_from_message( $normalized );

		if ( '' !== $quote_key ) {
			return QuoteCustomizationCatalog::PARENT_KEY;
		}

		$entry = self::resolve_entry_from_phrases( $normalized, self::get_entries() );

		return is_array( $entry ) ? (string) ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) ) : '';
	}

	/**
	 * Build settings patch from message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, string>
	 */
	public static function build_settings_patch( $normalized ) {
		$combined = self::build_combined_settings_patch( $normalized );

		if ( ! empty( $combined ) ) {
			return $combined;
		}

		$key = self::resolve_key_from_message( $normalized );

		if ( '' === $key ) {
			return array();
		}

		$entries = self::get_entries();

		if ( ! isset( $entries[ $key ] ) ) {
			return array();
		}

		return self::build_entry_patch( $normalized, $entries[ $key ] );
	}

	/**
	 * Build a settings patch resolving all matching entries in one message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, string>
	 */
	public static function build_combined_settings_patch( $normalized ) {
		$settings = array();
		$entries  = self::resolve_all_entries_from_phrases( $normalized, self::get_entries() );

		if ( empty( $entries ) ) {
			$single = self::resolve_entry_from_phrases( $normalized, self::get_entries() );

			if ( is_array( $single ) ) {
				$entries = array( $single );
			}
		}

		foreach ( $entries as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}

			$patch = self::build_entry_patch( $normalized, $entry );

			foreach ( $patch as $key => $value ) {
				$settings[ $key ] = $value;
			}
		}

		// Price-application phrases like "sale price" may not match entry phrases alone.
		if ( ! isset( $settings['wholesale_price_application'] ) ) {
			$price_app = self::resolve_price_application_from_message( $normalized );

			if ( '' !== $price_app && self::message_mentions_price_application( $normalized ) ) {
				$settings['wholesale_price_application'] = $price_app;
			}
		}

		$quote_patch = QuoteCustomizationCatalog::build_settings_patch_for_parent( $normalized );

		if ( ! empty( $quote_patch ) ) {
			if ( isset( $settings[ QuoteCustomizationCatalog::PARENT_KEY ] ) && is_array( $settings[ QuoteCustomizationCatalog::PARENT_KEY ] ) ) {
				$settings[ QuoteCustomizationCatalog::PARENT_KEY ] = array_merge(
					$settings[ QuoteCustomizationCatalog::PARENT_KEY ],
					$quote_patch[ QuoteCustomizationCatalog::PARENT_KEY ]
				);
			} else {
				$settings = array_merge( $settings, $quote_patch );
			}
		}

		return $settings;
	}

	/**
	 * Build a patch for a single catalog entry.
	 *
	 * @param string               $normalized Lowercased message.
	 * @param array<string, mixed> $entry      Catalog entry.
	 * @return array<string, string>
	 */
	private static function build_entry_patch( $normalized, array $entry ) {
		$key     = (string) ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) );
		$storage = (string) ( ( isset( $entry['storage'] ) ? $entry['storage'] : 'yes_empty' ) );

		if ( '' === $key ) {
			return array();
		}

		if ( 'role_slug' === $storage ) {
			$slug = self::resolve_role_slug_from_message( $normalized );

			return '' !== $slug ? array( $key => $slug ) : array();
		}

		if ( 'price_application' === $storage ) {
			$value = self::resolve_price_application_from_message( $normalized );

			return '' !== $value ? array( $key => $value ) : array();
		}

		if ( 'wholesale_role_mode' === $storage ) {
			$value = self::resolve_wholesale_role_mode_from_message( $normalized );

			return '' !== $value ? array( $key => $value ) : array();
		}

		return self::build_boolean_patch( $normalized, $entry );
	}

	/**
	 * Whether the message references wholesale price application.
	 *
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	private static function message_mentions_price_application( $normalized ) {
		return str_contains( $normalized, 'apply wholesale price' )
			|| str_contains( $normalized, 'wholesale price on' )
			|| str_contains( $normalized, 'price application' )
			|| ( str_contains( $normalized, 'wholesale price' ) && ( str_contains( $normalized, 'sale' ) || str_contains( $normalized, 'regular' ) ) );
	}

	/**
	 * Resolve a wholesale role slug from the user message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function resolve_role_slug_from_message( $normalized ) {
		if ( preg_match( '/\b([a-z0-9][a-z0-9_-]*_wholesaler)\b/', $normalized, $matches ) ) {
			return sanitize_key( $matches[1] );
		}

		if ( preg_match( '/\brole\s+to\s+([a-z0-9][a-z0-9\s_-]*?)(?:\s+and|\s+with|\s*$)/', $normalized, $matches ) ) {
			$slug = self::lookup_role_slug( trim( $matches[1] ) );

			if ( '' !== $slug ) {
				return $slug;
			}
		}

		if ( preg_match( '/\bto\s+([a-z0-9][a-z0-9\s_-]*?)(?:\s+and|\s+with|\s*$)/', $normalized, $matches ) ) {
			$slug = self::lookup_role_slug( trim( $matches[1] ) );

			if ( '' !== $slug ) {
				return $slug;
			}
		}

		return '';
	}

	/**
	 * Resolve wholesale_price_application value from message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string _price, _regular_price, or empty.
	 */
	public static function resolve_price_application_from_message( $normalized ) {
		if ( str_contains( $normalized, 'sale price' ) || preg_match( '/\bon\s+sale\b/', $normalized ) ) {
			return '_price';
		}

		if ( str_contains( $normalized, 'regular price' ) ) {
			return '_regular_price';
		}

		return '';
	}

	/**
	 * Resolve wholesale_role mode (single|multiple) from message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function resolve_wholesale_role_mode_from_message( $normalized ) {
		if ( str_contains( $normalized, 'multiple wholesale role' ) || str_contains( $normalized, 'multi wholesale role' ) ) {
			return 'multiple';
		}

		if ( str_contains( $normalized, 'single wholesale role' ) ) {
			return 'single';
		}

		return '';
	}

	/**
	 * Look up a wholesale role term slug by name or slug fragment.
	 *
	 * @param string $name_or_slug Role label or slug hint.
	 * @return string
	 */
	private static function lookup_role_slug( $name_or_slug ) {
		$name_or_slug = trim( strtolower( $name_or_slug ) );

		if ( '' === $name_or_slug ) {
			return '';
		}

		if ( 'wholesaler' === $name_or_slug || 'default wholesaler' === $name_or_slug ) {
			return 'default_wholesaler';
		}

		$taxonomy = function_exists( 'wwp_env' ) ? wwp_env()->get( 'role_taxonomy' ) : 'wholesale_user_roles';
		$slug     = sanitize_title( $name_or_slug );
		$exists   = term_exists( $slug, $taxonomy );

		if ( $exists && ! is_wp_error( $exists ) ) {
			return $slug;
		}

		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			)
		);

		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				if ( strtolower( $term->name ) === $name_or_slug || $term->slug === $slug ) {
					return (string) $term->slug;
				}
			}
		}

		return $slug;
	}

	/**
	 * Human-readable label for a wholesale role slug.
	 *
	 * @param string $slug Role slug.
	 * @return string
	 */
	private static function format_role_slug_display( $slug ) {
		$taxonomy = function_exists( 'wwp_env' ) ? wwp_env()->get( 'role_taxonomy' ) : 'wholesale_user_roles';
		$term     = get_term_by( 'slug', sanitize_key( $slug ), $taxonomy );

		if ( $term && ! is_wp_error( $term ) ) {
			return sprintf( '%s (%s)', $term->name, $term->slug );
		}

		return $slug;
	}

	/**
	 * Human-readable label for a setting key.
	 *
	 * @param string $key Setting key.
	 * @return string
	 */
	public static function get_setting_label( $key ) {
		if ( QuoteCustomizationCatalog::PARENT_KEY === $key ) {
			return __( 'Quote Customization', 'woocommerce-wholesale-pricing' );
		}

		if ( QuoteCustomizationCatalog::is_known_key( $key ) ) {
			return QuoteCustomizationCatalog::get_setting_label( $key );
		}

		$entries = self::get_entries();

		if ( isset( $entries[ $key ] ) ) {
			return (string) $entries[ $key ]['label'];
		}

		return ucwords( str_replace( '_', ' ', $key ) );
	}

	/**
	 * Format setting change for approval cards.
	 *
	 * @param string $key   Setting key.
	 * @param string $label Human-readable label.
	 * @param string $value Target value.
	 * @return string
	 */
	public static function format_setting_change_summary( $key, $label, $value ) {
		if ( 'disable_auto_role' === $key ) {
			if ( 'yes' === $value ) {
				return __( 'Disable registration auto-approve (require manual approval)', 'woocommerce-wholesale-pricing' );
			}

			if ( 'no' === $value ) {
				return __( 'Enable registration auto-approve', 'woocommerce-wholesale-pricing' );
			}
		}

		if ( 'default_multipe_wholesale_roles' === $key ) {
			return sprintf(
				/* translators: %1$s: setting label, %2$s: role display */
				__( 'Set %1$s to %2$s', 'woocommerce-wholesale-pricing' ),
				$label,
				self::format_role_slug_display( $value )
			);
		}

		if ( 'wholesale_price_application' === $key ) {
			$display = '_price' === $value
				? __( 'Sale Price', 'woocommerce-wholesale-pricing' )
				: ( '_regular_price' === $value ? __( 'Regular Price', 'woocommerce-wholesale-pricing' ) : $value );

			/* translators: 1: setting label, 2: price basis */
			return sprintf( __( 'Set %1$s to %2$s', 'woocommerce-wholesale-pricing' ), $label, $display );
		}

		if ( 'wholesale_role' === $key ) {
			$display = 'multiple' === $value
				? __( 'Multiple Wholesale Roles', 'woocommerce-wholesale-pricing' )
				: ( 'single' === $value ? __( 'Single Wholesale Role', 'woocommerce-wholesale-pricing' ) : $value );

			/* translators: 1: setting label, 2: mode */
			return sprintf( __( 'Set %1$s to %2$s', 'woocommerce-wholesale-pricing' ), $label, $display );
		}

		if ( 'yes' === $value ) {
			/* translators: %s: setting label */
			return sprintf( __( 'Enable %s', 'woocommerce-wholesale-pricing' ), $label );
		}

		if ( 'no' === $value ) {
			/* translators: %s: setting label */
			return sprintf( __( 'Disable %s', 'woocommerce-wholesale-pricing' ), $label );
		}

		if ( '' === $value ) {
			/* translators: %s: setting label */
			return sprintf( __( 'Disable %s', 'woocommerce-wholesale-pricing' ), $label );
		}

		/* translators: 1: setting label, 2: value */
		return sprintf( __( 'Set %1$s to %2$s', 'woocommerce-wholesale-pricing' ), $label, $value );
	}

	/**
	 * Format a wholesale settings patch for approval summaries.
	 *
	 * @param array<string, mixed> $settings Settings patch.
	 * @return string
	 */
	public static function format_settings_patch_summary( array $settings ) {
		$parts = array();

		foreach ( $settings as $key => $value ) {
			if ( QuoteCustomizationCatalog::PARENT_KEY === (string) $key && is_array( $value ) ) {
				foreach ( $value as $sub_key => $sub_value ) {
					$sub_label = QuoteCustomizationCatalog::get_setting_label( (string) $sub_key );
					$parts[]   = QuoteCustomizationCatalog::format_setting_change_summary(
						(string) $sub_key,
						$sub_label,
						(string) $sub_value
					);
				}
				continue;
			}

			$label   = self::get_setting_label( (string) $key );
			$parts[] = self::format_setting_change_summary( (string) $key, $label, (string) $value );
		}

		return implode( '; ', $parts );
	}

	/**
	 * Enabled/disabled storage value for a boolean setting.
	 *
	 * @param string $key     Setting key.
	 * @param bool   $enabled Whether to enable.
	 * @return string
	 */
	public static function get_boolean_value( $key, $enabled ) {
		if ( 'disable_auto_role' === $key ) {
			return $enabled ? 'no' : 'yes';
		}

		if ( in_array( $key, self::YES_NO_KEYS, true ) ) {
			return $enabled ? 'yes' : 'no';
		}

		if ( in_array( $key, self::YES_EMPTY_KEYS, true ) ) {
			return $enabled ? 'yes' : '';
		}

		return $enabled ? 'yes' : 'no';
	}
}
