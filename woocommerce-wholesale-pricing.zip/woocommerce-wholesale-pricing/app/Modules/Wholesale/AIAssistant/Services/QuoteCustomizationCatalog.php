<?php
/**
 * Maps quote customization phrases to wc_quote_customization keys.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services;

/**
 * Central catalog for quote label/color/position intent matching and approval summaries.
 */
class QuoteCustomizationCatalog {

	use SettingCatalogTrait;

	/**
	 * Parent settings key used by wholesale_settings ability.
	 */
	const PARENT_KEY = 'wc_quote_customization';

	/**
	 * Catalog entries keyed by setting key.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	private static function get_entries() {
		static $entries = null;

		if ( null !== $entries ) {
			return $entries;
		}

		$entries = array(
			'build_quote_text' => array(
				'key'     => 'build_quote_text',
				'label'   => 'Build a Quote Button Text',
				'storage' => 'text',
				'phrases' => array( 'build quote button text', 'build a quote button text', 'build a quote text' ),
			),
			'convert_cart_text' => array(
				'key'     => 'convert_cart_text',
				'label'   => 'Convert to Cart Button Text',
				'storage' => 'text',
				'phrases' => array( 'convert to cart button text', 'convert to cart text', 'convert cart button text' ),
			),
			'send_quote_text' => array(
				'key'     => 'send_quote_text',
				'label'   => 'Send Quote Button Text',
				'storage' => 'text',
				'phrases' => array( 'send quote button text', 'send quote text' ),
			),
			'add_quote_text' => array(
				'key'     => 'add_quote_text',
				'label'   => 'Add to Quote Button Text',
				'storage' => 'text',
				'phrases' => array( 'add to quote button text', 'add to quote text', 'add quote button text' ),
			),
			'browse_list_text' => array(
				'key'     => 'browse_list_text',
				'label'   => 'Browse the List Button Text',
				'storage' => 'text',
				'phrases' => array( 'browse the list button text', 'browse list button text', 'browse the list text' ),
			),
			'return_shop_text' => array(
				'key'     => 'return_shop_text',
				'label'   => 'Return to Shop Button Text',
				'storage' => 'text',
				'phrases' => array( 'return to shop button text', 'return to shop text', 'return shop button text' ),
			),
			'quote_counter_text' => array(
				'key'     => 'quote_counter_text',
				'label'   => 'Quote Counter Text',
				'storage' => 'text',
				'phrases' => array( 'quote counter text', 'quote counter label' ),
			),
			'quote_btn_positioning' => array(
				'key'     => 'quote_btn_positioning',
				'label'   => 'Add To Quote Button Positioning',
				'storage' => 'position',
				'phrases' => array(
					'add to quote button position',
					'quote button position',
					'quote button underneath',
					'quote button inline',
					'add to quote button underneath',
					'add to quote button inline',
				),
			),
			'add_quote_btn_color' => array(
				'key'     => 'add_quote_btn_color',
				'label'   => 'Add to Quote Button Color',
				'storage' => 'color',
				'phrases' => array( 'add to quote button color', 'add quote button color' ),
			),
			'add_quote_text_color' => array(
				'key'     => 'add_quote_text_color',
				'label'   => 'Add to Quote Button Text Color',
				'storage' => 'color',
				'phrases' => array( 'add to quote button text color', 'add quote text color' ),
			),
			'send_quote_btn_color' => array(
				'key'     => 'send_quote_btn_color',
				'label'   => 'Send Quote Button Color',
				'storage' => 'color',
				'phrases' => array( 'send quote button color' ),
			),
			'send_quote_text_color' => array(
				'key'     => 'send_quote_text_color',
				'label'   => 'Send Quote Button Text Color',
				'storage' => 'color',
				'phrases' => array( 'send quote button text color', 'send quote text color' ),
			),
			'quote_counter_text_color' => array(
				'key'     => 'quote_counter_text_color',
				'label'   => 'Quote Counter Text Color',
				'storage' => 'color',
				'phrases' => array( 'quote counter text color', 'quote counter color' ),
			),
		);

		return $entries;
	}

	/**
	 * Extra matcher keywords for wholesale_settings routing.
	 *
	 * @return list<string>
	 */
	public static function get_matcher_keywords() {
		return self::collect_matcher_keywords( self::get_entries() );
	}

	/**
	 * Get hint lines for system prompt injection.
	 *
	 * @return list<string>
	 */
	public static function get_hint_lines() {
		$lines = self::collect_hint_lines( self::get_entries(), 20 );

		foreach ( $lines as $index => $line ) {
			$lines[ $index ] = $line . ' (wc_quote_customization)';
		}

		return $lines;
	}

	/**
	 * Resolve a setting key from a normalized user message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function resolve_key_from_message( $normalized ) {
		$entry = self::resolve_entry_from_phrases( $normalized, self::get_entries() );

		return is_array( $entry ) ? (string) ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) ) : '';
	}

	/**
	 * Whether the message targets quote customization label/color settings.
	 *
	 * @param string $normalized Lowercased message.
	 * @return bool
	 */
	public static function message_targets_customization( $normalized ) {
		if ( '' !== self::resolve_key_from_message( $normalized ) ) {
			return true;
		}

		return str_contains( $normalized, 'button text' )
			|| str_contains( $normalized, 'button color' )
			|| str_contains( $normalized, 'text color' )
			|| str_contains( $normalized, 'quote counter' );
	}

	/**
	 * Build a flat patch of customization keys.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, string>
	 */
	public static function build_combined_settings_patch( $normalized ) {
		$settings = array();
		$entries  = self::resolve_all_entries_from_phrases( $normalized, self::get_entries() );

		if ( empty( $entries ) ) {
			$single = self::resolve_entry_from_phrases( $normalized, self::get_entries() );

			if ( is_array( $single ) ) {
				$entries = array( $single );
			}
		}

		foreach ( $entries as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}

			$patch = self::build_entry_patch( $normalized, $entry );

			foreach ( $patch as $key => $value ) {
				$settings[ $key ] = $value;
			}
		}

		return $settings;
	}

	/**
	 * Build patch wrapped for wholesale_settings ability args.
	 *
	 * @param string $normalized Lowercased message.
	 * @return array<string, array<string, string>>
	 */
	public static function build_settings_patch_for_parent( $normalized ) {
		$patch = self::build_combined_settings_patch( $normalized );

		if ( empty( $patch ) ) {
			return array();
		}

		return array(
			self::PARENT_KEY => $patch,
		);
	}

	/**
	 * Whether a key belongs to quote customization catalog.
	 *
	 * @param string $key Setting key.
	 * @return bool
	 */
	public static function is_known_key( $key ) {
		return isset( self::get_entries()[ $key ] );
	}

	/**
	 * Human-readable label for a setting key.
	 *
	 * @param string $key Setting key.
	 * @return string
	 */
	public static function get_setting_label( $key ) {
		$entries = self::get_entries();

		if ( isset( $entries[ $key ] ) ) {
			return (string) $entries[ $key ]['label'];
		}

		return ucwords( str_replace( '_', ' ', $key ) );
	}

	/**
	 * Format setting change for approval cards.
	 *
	 * @param string $key   Setting key.
	 * @param string $label Human-readable label.
	 * @param string $value Target value.
	 * @return string
	 */
	public static function format_setting_change_summary( $key, $label, $value ) {
		if ( 'quote_btn_positioning' === $key ) {
			$display = 'underneath' === $value
				? __( 'Underneath', 'woocommerce-wholesale-pricing' )
				: __( 'Inline', 'woocommerce-wholesale-pricing' );

			/* translators: 1: setting label, 2: position */
			return sprintf( __( 'Set %1$s to %2$s', 'woocommerce-wholesale-pricing' ), $label, $display );
		}

		/* translators: 1: setting label, 2: value */
		return sprintf( __( 'Set %1$s to %2$s', 'woocommerce-wholesale-pricing' ), $label, $value );
	}

	/**
	 * Build a patch for a single catalog entry.
	 *
	 * @param string               $normalized Lowercased message.
	 * @param array<string, mixed> $entry      Catalog entry.
	 * @return array<string, string>
	 */
	private static function build_entry_patch( $normalized, array $entry ) {
		$key     = (string) ( ( isset( $entry['key'] ) ? $entry['key'] : '' ) );
		$storage = (string) ( ( isset( $entry['storage'] ) ? $entry['storage'] : 'text' ) );

		if ( '' === $key ) {
			return array();
		}

		if ( 'position' === $storage ) {
			$value = self::resolve_position_from_message( $normalized );

			return '' !== $value ? array( $key => $value ) : array();
		}

		if ( 'color' === $storage ) {
			$value = self::extract_color_value( $normalized );

			return '' !== $value ? array( $key => $value ) : array();
		}

		$value = self::extract_text_value( $normalized );

		return '' !== $value ? array( $key => $value ) : array();
	}

	/**
	 * Extract a text value from quoted or trailing "to …" phrasing.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function extract_text_value( $normalized ) {
		if ( preg_match( '/\bto\s+"([^"]+)"/', $normalized, $matches ) ) {
			return sanitize_text_field( $matches[1] );
		}

		if ( preg_match( "/\bto\s+'([^']+)'/", $normalized, $matches ) ) {
			return sanitize_text_field( $matches[1] );
		}

		if ( preg_match( '/\bto\s+(.+)$/u', $normalized, $matches ) ) {
			$value = trim( $matches[1] );
			$value = preg_replace( '/\s+(and|with)\s+.+$/', '', $value );

			return sanitize_text_field( trim( (string) $value ) );
		}

		return '';
	}

	/**
	 * Extract a hex color from the message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string
	 */
	public static function extract_color_value( $normalized ) {
		if ( preg_match( '/#([0-9a-f]{3,8})\b/i', $normalized, $matches ) ) {
			$color = sanitize_hex_color( '#' . $matches[1] );

			return is_string( $color ) ? $color : '';
		}

		return '';
	}

	/**
	 * Resolve quote button positioning from message.
	 *
	 * @param string $normalized Lowercased message.
	 * @return string inline, underneath, or empty.
	 */
	public static function resolve_position_from_message( $normalized ) {
		if ( str_contains( $normalized, 'underneath' ) ) {
			return 'underneath';
		}

		if ( str_contains( $normalized, 'inline' ) ) {
			return 'inline';
		}

		return '';
	}
}
