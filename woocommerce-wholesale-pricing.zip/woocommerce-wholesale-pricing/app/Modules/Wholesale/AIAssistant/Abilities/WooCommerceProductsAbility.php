<?php
/**
 * WooCommerce Products ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Services\WholesaleProductMetaService;
use WooCommerceWholesalePricing\App\Services\WooCommerceRestDelegate;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * CRUD for WooCommerce products with wholesale pricing extensions.
 */
class WooCommerceProductsAbility extends AbstractAiAbility {

	/**
	 * REST delegate.
	 *
	 * @var WooCommerceRestDelegate
	 */
	private $rest_delegate;

	/**
	 * Wholesale product meta service.
	 *
	 * @var WholesaleProductMetaService
	 */
	private $meta_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Constructor.
	 *
	 * @param WooCommerceRestDelegate|null      $rest_delegate   Optional REST delegate.
	 * @param WholesaleProductMetaService|null  $meta_service    Optional meta service.
	 * @param ChangeHistoryService|null         $history_service Optional history service.
	 */
	public function __construct(
		$rest_delegate = null,
		$meta_service = null,
		$history_service = null
	) {
		$this->rest_delegate   =( isset( $rest_delegate ) ? $rest_delegate : new WooCommerceRestDelegate() );
		$this->meta_service    =( isset( $meta_service ) ? $meta_service : new WholesaleProductMetaService() );
		$this->history_service =( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
	}

	/**
	 * Get key
	 * 
	 * @inheritDoc
	 */
	public function get_key() {
		return 'woocommerce_products';
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'Manage WooCommerce Products', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 * 
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Full CRUD for WooCommerce products with wholesale pricing configuration. Per product and per role: activation toggle, discount type (fixed/percent), discount value, step quantity, and tier pricing (min qty, max qty, value). For variable products, same per-role wholesale settings apply per variation independently.', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 * 
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'wholesale';
	}

	/**
	 * Get input schema
	 * 
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'     => array(
					'type'        => 'string',
					'enum'        => array( 'list', 'get', 'create', 'update', 'delete' ),
					'description' => __( 'CRUD action to perform.', 'woocommerce-wholesale-pricing' ),
				),
				'identifier' => array(
					'type'        => 'integer',
					'description' => __( 'Product ID (required for get, update, delete).', 'woocommerce-wholesale-pricing' ),
				),
				'product'    => array(
					'type'                 => 'object',
					'description'          => __( 'WooCommerce REST product fields.', 'woocommerce-wholesale-pricing' ),
					'additionalProperties' => true,
				),
				'wholesale'  => $this->get_wholesale_schema(),
				'per_page'   => array( 'type' => 'integer' ),
				'page'       => array( 'type' => 'integer' ),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'products' => array( 'type' => 'array' ),
				'product'  => array( 'type' => 'object' ),
				'total'    => array( 'type' => 'integer' ),
				'deleted'  => array( 'type' => 'boolean' ),
			),
		);
	}

	/**
	 * Execute
	 * 
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'list':
				return $this->list_products( $payload );

			case 'get':
				return $this->get_product( $payload );

			case 'create':
				return $this->create_product( $payload );

			case 'update':
				return $this->update_product( $payload );

			case 'delete':
				return $this->delete_product( $payload );

			default:
				return new \WP_Error(
					'wwp_product_invalid_action',
					__( 'Invalid action. Use list, get, create, update, or delete.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 * 
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The Manage WooCommerce Products ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : 'list';

		return $this->rest_delegate->check_product_permission( $action );
	}

	/**
	 * Register ability with annotations.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/**
	 * List products
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function list_products( array $payload ) {
		$list_input = array(
			'per_page' => isset( $payload['per_page'] ) ? (int) $payload['per_page'] : 20,
			'page'     => isset( $payload['page'] ) ? (int) $payload['page'] : 1,
		);

		$result = $this->rest_delegate->execute_products( 'list', $list_input );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$items    = is_array(( isset( $result['data'] ) ? $result['data'] : null )) ? $result['data'] : array();
		$products = array();

		foreach ( $items as $item ) {
			if ( ! is_array( $item ) || empty( $item['id'] ) ) {
				continue;
			}
			$product_id = (int) $item['id'];
			$wholesale  = $this->meta_service->get_wholesale_settings( $product_id );
			$item['wholesale'] = is_wp_error( $wholesale ) ? array() : $wholesale;
			$products[] = $item;
		}

		return array(
			'products' => $products,
			'total'    => (int) ( ( isset( $result['total'] ) ? $result['total'] : count( $products ) ) ),
		);
	}

	/**
	 * Get product
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function get_product( array $payload ) {
		$product_id = $this->resolve_identifier( $payload );
		if ( is_wp_error( $product_id ) ) {
			return $product_id;
		}

		$product = $this->rest_delegate->execute_products( 'get', array( 'identifier' => $product_id ) );
		if ( is_wp_error( $product ) ) {
			return $product;
		}

		$wholesale = $this->meta_service->get_wholesale_settings( $product_id );
		if ( ! is_wp_error( $wholesale ) ) {
			$product['wholesale'] = $wholesale;
		}

		return array( 'product' => $product );
	}

	/**
	 * Create product
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function create_product( array $payload ) {
		$product_data = is_array(( isset( $payload['product'] ) ? $payload['product'] : null )) ? $payload['product'] : array();
		if ( empty( $product_data['name'] ) ) {
			return new \WP_Error(
				'wwp_product_missing_name',
				__( 'Product name is required for create.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$variations_to_create = is_array(( isset( $product_data['variations'] ) ? $product_data['variations'] : null )) ? $product_data['variations'] : array();
		$product_for_rest       = $product_data;
		unset( $product_for_rest['variations'] );

		$created = $this->rest_delegate->execute_products( 'create', array( 'product' => $product_for_rest ) );
		if ( is_wp_error( $created ) ) {
			return $created;
		}

		$product_id = (int) ( ( isset( $created['id'] ) ? $created['id'] : 0 ) );
		if ( $product_id <= 0 ) {
			return new \WP_Error(
				'wwp_product_create_failed',
				__( 'Product was created but no ID was returned.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		if ( ! empty( $variations_to_create ) ) {
			$variation_result = $this->rest_delegate->create_product_variations( $product_id, $variations_to_create );
			if ( is_wp_error( $variation_result ) ) {
				return $variation_result;
			}
			$created['variations'] = $variation_result;
		}

		if ( ! empty( $payload['wholesale'] ) && is_array( $payload['wholesale'] ) ) {
			$wholesale = $this->meta_service->update_wholesale_settings( $product_id, $payload['wholesale'] );
			if ( is_wp_error( $wholesale ) ) {
				return $wholesale;
			}
			$created['wholesale'] = $wholesale;
		} else {
			$wholesale = $this->meta_service->get_wholesale_settings( $product_id );
			if ( ! is_wp_error( $wholesale ) ) {
				$created['wholesale'] = $wholesale;
			}
		}

		$this->record_change(
			'create',
			array(
				'id'   => $product_id,
				'name' => ( isset( $created['name'] ) ? $created['name'] : '' ),
			),
			null,
			sprintf(
				/* translators: %s: product name */
				__( 'Created product "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $created['name'] ) ? $created['name'] : (string) $product_id )
			)
		);

		return array( 'product' => $created );
	}

	/**
	 * Update product
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function update_product( array $payload ) {
		$product_id = $this->resolve_identifier( $payload );
		if ( is_wp_error( $product_id ) ) {
			return $product_id;
		}

		$product_data = is_array(( isset( $payload['product'] ) ? $payload['product'] : null )) ? $payload['product'] : array();
		$wholesale    = is_array(( isset( $payload['wholesale'] ) ? $payload['wholesale'] : null )) ? $payload['wholesale'] : array();

		if ( empty( $product_data ) && empty( $wholesale ) ) {
			return new \WP_Error(
				'wwp_product_missing_data',
				__( 'Provide product and/or wholesale fields to update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$before = $this->build_before_snapshot( $product_id );

		if ( ! empty( $product_data ) ) {
			$updated = $this->rest_delegate->execute_products(
				'update',
				array(
					'identifier' => $product_id,
					'product'    => $product_data,
				)
			);
			if ( is_wp_error( $updated ) ) {
				return $updated;
			}
		} else {
			$updated = $this->rest_delegate->execute_products( 'get', array( 'identifier' => $product_id ) );
			if ( is_wp_error( $updated ) ) {
				return $updated;
			}
		}

		if ( ! empty( $wholesale ) ) {
			$wholesale_result = $this->meta_service->update_wholesale_settings( $product_id, $wholesale );
			if ( is_wp_error( $wholesale_result ) ) {
				return $wholesale_result;
			}
			$updated['wholesale'] = $wholesale_result;
		} else {
			$wholesale_get = $this->meta_service->get_wholesale_settings( $product_id );
			if ( ! is_wp_error( $wholesale_get ) ) {
				$updated['wholesale'] = $wholesale_get;
			}
		}

		$this->record_change(
			'update',
			array(
				'id'   => $product_id,
				'name' => ( isset( $updated['name'] ) ? $updated['name'] : '' ),
			),
			$before,
			sprintf(
				/* translators: %s: product name */
				__( 'Updated product "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $updated['name'] ) ? $updated['name'] : (string) $product_id )
			)
		);

		return array( 'product' => $updated );
	}

	/**
	 * Delete product
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function delete_product( array $payload ) {
		$product_id = $this->resolve_identifier( $payload );
		if ( is_wp_error( $product_id ) ) {
			return $product_id;
		}

		$before = $this->build_before_snapshot( $product_id );

		$deleted = $this->rest_delegate->execute_products( 'delete', array( 'identifier' => $product_id ) );
		if ( is_wp_error( $deleted ) ) {
			return $deleted;
		}

		$this->record_change(
			'delete',
			array( 'id' => $product_id ),
			$before,
			sprintf(
				/* translators: %d: product ID */
				__( 'Deleted product #%d.', 'woocommerce-wholesale-pricing' ),
				$product_id
			)
		);

		return array(
			'deleted' => true,
			'id'      => $product_id,
		);
	}

	/**
	 * Resolve identifier
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return int|\WP_Error
	 */
	private function resolve_identifier( array $payload ) {
		$product_id = isset( $payload['identifier'] ) ? (int) $payload['identifier'] : 0;

		if ( $product_id <= 0 ) {
			return new \WP_Error(
				'wwp_product_missing_identifier',
				__( 'Product identifier is required.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return $product_id;
	}

	/**
	 * Build before snapshot
	 * 
	 * @param int $product_id Product ID.
	 * @return array<string, mixed>|null
	 */
	private function build_before_snapshot( $product_id ) {
		$product = $this->rest_delegate->execute_products( 'get', array( 'identifier' => $product_id ) );
		$meta    = $this->meta_service->snapshot_wholesale_settings( $product_id );

		if ( is_wp_error( $product ) ) {
			return is_wp_error( $meta ) ? null : array( 'wholesale_snapshot' => $meta );
		}

		$snapshot = $product;
		if ( ! is_wp_error( $meta ) ) {
			$snapshot['wholesale_snapshot'] = $meta;
		}

		return $snapshot;
	}

	/**
	 * Get wholesale schema
	 * 
	 * @return array<string, mixed>
	 */
	private function get_wholesale_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'role_pricing' => array(
					'type'  => 'array',
					'items' => array(
						'type'       => 'object',
						'properties' => array(
							'role_slug'       => array( 'type' => 'string' ),
							'slug'            => array( 'type' => 'string' ),
							'role_id'         => array( 'type' => 'integer' ),
							'role_name'       => array( 'type' => 'string' ),
							'enabled'         => array( 'type' => 'boolean' ),
							'discount_type'   => array( 'type' => 'string' ),
							'wholesale_price' => array( 'type' => 'string' ),
							'min_quantity'    => array( 'type' => 'integer' ),
							'step_quantity'   => array( 'type' => 'string' ),
							'variations'      => array(
								'type'  => 'array',
								'items' => array(
									'type'       => 'object',
									'properties' => array(
										'variation_id'    => array( 'type' => 'integer' ),
										'wholesale_price' => array( 'type' => 'string' ),
										'qty'             => array( 'type' => 'integer' ),
										'step'            => array( 'type' => 'string' ),
									),
								),
							),
						),
					),
				),
				'tier_pricing'        => array( 'type' => 'object' ),
				'hide_for_customer'   => array( 'type' => 'boolean' ),
				'hide_for_visitor'    => array( 'type' => 'boolean' ),
				'hide_for_roles'      => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
			),
		);
	}

	/**
	 * Record change
	 * 
	 * @param string                    $action_type Action type.
	 * @param array<string, mixed>      $resource    Resource data.
	 * @param array<string, mixed>|null $before      Before state.
	 * @param string                    $description Description.
	 * @return void
	 */
	private function record_change( $action_type, array $resource, $before, $description ) {
		$this->history_service->record(
			array(
				'tool'               => 'woocommerce_products',
				'ability'            => $this->get_key(),
				'change_description' => $description,
				'action_type'        => $action_type,
				'resource_type'      => 'product',
				'resource'           => $resource,
				'before_state'       => $before,
			)
		);
	}
}
