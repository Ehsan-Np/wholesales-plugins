<?php
/**
 * Wholesale Account Requests ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Services\WholesaleAccountRequestService;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * Lis  t, get, update, and delete wholesale account registration requests.
 */
class WholesaleAccountRequestsAbility extends AbstractAiAbility {

	/**
	 * Account request service.
	 *
	 * @var WholesaleAccountRequestService
	 */
	private $request_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleAccountRequestService|null $request_service Optional service.
	 * @param ChangeHistoryService|null           $history_service Optional history service.
	 */
	public function __construct(
		$request_service = null,
		$history_service = null
	) {
		$this->request_service =( isset( $request_service ) ? $request_service : new WholesaleAccountRequestService() );
		$this->history_service =( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
	}

	/**
	 * Get key
	 * 
	 * @inheritDoc
	 */
	public function get_key() {
		return 'wholesale_account_requests';
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'Wholesale Account Requests', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 * 
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Reviews and processes wholesale account applications under Wholesale → Requests. Each request is created when a user submits the wholesale registration form. Supports listing pending requests and approving or rejecting applicants. Approval assigns a wholesale role; rejection denies access.', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 * 
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'wholesale';
	}

	/**
	 * Get input schema
	 * 
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'     => array(
					'type'        => 'string',
					'enum'        => array( 'list', 'get', 'update', 'delete' ),
					'description' => __( 'Action to perform.', 'woocommerce-wholesale-pricing' ),
				),
				'identifier' => array(
					'type'        => 'integer',
					'description' => __( 'Request post ID (required for get, update, delete).', 'woocommerce-wholesale-pricing' ),
				),
				'status'     => array(
					'type'        => 'string',
					'enum'        => array( 'waiting', 'active', 'rejected' ),
					'description' => __( 'Request status: waiting, active (approve), or rejected.', 'woocommerce-wholesale-pricing' ),
				),
				'role_slug'  => array(
					'type'        => 'string',
					'description' => __( 'Wholesale role slug to assign when approving.', 'woocommerce-wholesale-pricing' ),
				),
				'rejected_note' => array(
					'type'        => 'string',
					'description' => __( 'Note shown to the user when rejecting.', 'woocommerce-wholesale-pricing' ),
				),
				'per_page'   => array(
					'type'        => 'integer',
					'description' => __( 'Results per page for list (max 100).', 'woocommerce-wholesale-pricing' ),
				),
				'page'       => array(
					'type'        => 'integer',
					'description' => __( 'Page number for list.', 'woocommerce-wholesale-pricing' ),
				),
				'filter_status' => array(
					'type'        => 'string',
					'enum'        => array( 'waiting', 'active', 'rejected' ),
					'description' => __( 'Filter list by request status.', 'woocommerce-wholesale-pricing' ),
				),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'requests' => array(
					'type'  => 'array',
					'items' => $this->get_request_schema(),
				),
				'request'  => $this->get_request_schema(),
				'total'    => array( 'type' => 'integer' ),
				'deleted'  => array( 'type' => 'boolean' ),
				'request_id' => array( 'type' => 'integer' ),
			),
		);
	}

	/**
	 * Execute
	 * 
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'list':
				$list_args = array(
					'per_page' => isset( $payload['per_page'] ) ? (int) $payload['per_page'] : 20,
					'page'     => isset( $payload['page'] ) ? (int) $payload['page'] : 1,
				);
				if ( isset( $payload['filter_status'] ) ) {
					$list_args['status'] = sanitize_key( (string) $payload['filter_status'] );
				}

				return $this->request_service->list_requests( $list_args );

			case 'get':
				$request_id = $this->resolve_identifier( $payload );
				if ( is_wp_error( $request_id ) ) {
					return $request_id;
				}

				$request = $this->request_service->get_request( $request_id );
				return is_wp_error( $request ) ? $request : array( 'request' => $request );

			case 'update':
				$request_id = $this->resolve_identifier( $payload );
				if ( is_wp_error( $request_id ) ) {
					return $request_id;
				}

				$data = $this->build_update_payload( $payload );
				if ( is_wp_error( $data ) ) {
					return $data;
				}

				$before  = $this->request_service->snapshot_request( $request_id );
				$updated = $this->request_service->update_request( $request_id, $data );

				if ( is_wp_error( $updated ) ) {
					return $updated;
				}

				$description = $this->build_update_description( $data, $updated );
				$this->record_change(
					'update',
					array(
						'request_id' => $request_id,
						'title'      => ( isset( $updated['title'] ) ? $updated['title'] : '' ),
					),
					is_wp_error( $before ) ? null : $before,
					$description
				);

				return array( 'request' => $updated );

			case 'delete':
				$request_id = $this->resolve_identifier( $payload );
				if ( is_wp_error( $request_id ) ) {
					return $request_id;
				}

				$before  = $this->request_service->snapshot_request( $request_id );
				$deleted = $this->request_service->delete_request( $request_id );

				if ( is_wp_error( $deleted ) ) {
					return $deleted;
				}

				$this->record_change(
					'delete',
					array(
						'request_id' => $request_id,
					),
					is_wp_error( $before ) ? null : $before,
					sprintf(
						/* translators: %d: request post ID */
						__( 'Deleted account request #%d.', 'woocommerce-wholesale-pricing' ),
						$request_id
					)
				);

				return $deleted;

			case 'create':
				return new \WP_Error(
					'wwp_request_action_not_allowed',
					__( 'Create is not supported for account requests. Requests are created when users register.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);

			default:
				return new \WP_Error(
					'wwp_request_invalid_action',
					__( 'Invalid action. Use list, get, update, or delete.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 * 
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The Wholesale Account Requests ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'wwp_ability_forbidden',
				__( 'You do not have permission to manage wholesale account requests.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Register
	 * 
	 * Register ability with annotations.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/**
	 * 
	 * Resolve identifier
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return int|\WP_Error
	 */
	private function resolve_identifier( array $payload ) {
		$request_id = isset( $payload['identifier'] ) ? (int) $payload['identifier'] : 0;

		if ( $request_id <= 0 ) {
			return new \WP_Error(
				'wwp_request_missing_identifier',
				__( 'Request identifier (post ID) is required.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return $request_id;
	}

	/**
	 * Build update payload
	 * 
	 * @param array<string, mixed> $payload Input payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function build_update_payload( array $payload ) {
		$data = array();

		if ( isset( $payload['status'] ) ) {
			$data['status'] = sanitize_key( (string) $payload['status'] );
		}
		if ( isset( $payload['role_slug'] ) ) {
			$data['role_slug'] = sanitize_key( (string) $payload['role_slug'] );
		}
		if ( array_key_exists( 'rejected_note', $payload ) ) {
			$data['rejected_note'] = (string) $payload['rejected_note'];
		}

		if ( empty( $data ) ) {
			return new \WP_Error(
				'wwp_request_missing_data',
				__( 'Provide status, role_slug, and/or rejected_note to update a request.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return $data;
	}

	/**
	 * Build update description
	 * 
	 * @param array<string, mixed> $data    Update payload.
	 * @param array<string, mixed> $updated Updated request.
	 * @return string
	 */
	private function build_update_description( array $data, array $updated ) {
		if ( isset( $data['status'] ) && 'active' === $data['status'] ) {
			return sprintf(
				/* translators: %s: user email */
				__( 'Approved account request for %s.', 'woocommerce-wholesale-pricing' ),
( isset( $updated['user_email'] ) ? $updated['user_email'] : '' )
		  );
		}

		if ( isset( $data['status'] ) && 'rejected' === $data['status'] ) {
			return sprintf(
				/* translators: %s: user email */
				__( 'Rejected account request for %s.', 'woocommerce-wholesale-pricing' ),
( isset( $updated['user_email'] ) ? $updated['user_email'] : '' )
		  );
		}

		return sprintf(
			/* translators: %d: request post ID */
			__( 'Updated account request #%d.', 'woocommerce-wholesale-pricing' ),
			(int) ( ( isset( $updated['id'] ) ? $updated['id'] : 0 ) )
		);
	}

	/**
	 * Get request schema
	 * 
	 * @return array<string, mixed>
	 */
	private function get_request_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'id'            => array( 'type' => 'integer' ),
				'title'         => array( 'type' => 'string' ),
				'date'          => array( 'type' => 'string' ),
				'status'        => array( 'type' => 'string' ),
				'user_id'       => array( 'type' => 'integer' ),
				'user_email'    => array( 'type' => 'string' ),
				'display_name'  => array( 'type' => 'string' ),
				'username'      => array( 'type' => 'string' ),
				'current_role'  => array( 'type' => 'string' ),
				'role_slug'     => array( 'type' => 'string' ),
				'assigned_role' => array( 'type' => 'string' ),
				'rejected_note' => array( 'type' => 'string' ),
			),
		);
	}

	/**
	 * Record a mutating change in history.
	 *
	 * @param string                    $action_type Action type.
	 * @param array<string, mixed>      $resource    Resource snapshot.
	 * @param array<string, mixed>|null $before      Before state.
	 * @param string                    $description Change description.
	 * @return void
	 */
	private function record_change( $action_type, array $resource, $before, $description ) {
		$this->history_service->record(
			array(
				'tool'               => 'wholesale_account_requests',
				'ability'            => $this->get_key(),
				'change_description' => $description,
				'action_type'        => $action_type,
				'resource_type'      => 'account_request',
				'resource'           => $resource,
				'before_state'       => $before,
			)
		);
	}
}
