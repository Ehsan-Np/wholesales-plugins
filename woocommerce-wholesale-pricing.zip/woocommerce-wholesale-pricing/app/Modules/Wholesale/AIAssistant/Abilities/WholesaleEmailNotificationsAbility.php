<?php
/**
 * Wholesale Email Notifications ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Services\WholesaleEmailNotificationService;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * Get and update wholesale email notification settings.
 */
class WholesaleEmailNotificationsAbility extends AbstractAiAbility {

	/**
	 * Notification service.
	 *
	 * @var WholesaleEmailNotificationService
	 */
	private $notification_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleEmailNotificationService|null $notification_service Optional service.
	 * @param ChangeHistoryService|null              $history_service      Optional history service.
	 */
	public function __construct(
		$notification_service = null,
		$history_service = null
	) {
		$this->notification_service =( isset( $notification_service ) ? $notification_service : new WholesaleEmailNotificationService() );
		$this->history_service      =( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
	}

	/**
	 * Get key
	 * 
	 * @inheritDoc
	 */
	public function get_key() {
		return 'wholesale_email_notifications';
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'Manage Email Notifications', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 * 
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Reads and writes wholesale email notification templates under Wholesale → Notifications. Covers three tabs — Wholesale Registration Emails, Subscription Upgrade, and Quote Emails — each with multiple sub-type notifications. Per notification: enable toggle, subject line, and message body.', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 * 
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'wholesale';
	}

	/**
	 * Get input schema
	 * 
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'     => array(
					'type'        => 'string',
					'enum'        => array( 'list', 'get', 'update' ),
					'description' => __( 'Action to perform.', 'woocommerce-wholesale-pricing' ),
				),
				'identifier' => array(
					'type'        => 'string',
					'enum'        => array(
						'admin_new_registration',
						'user_new_registration',
						'user_registration_rejection',
						'user_registration_approval',
						'user_role_upgrade',
					),
					'description' => __( 'Notification id (required for get and update).', 'woocommerce-wholesale-pricing' ),
				),
				'settings'   => $this->get_settings_schema(),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'notifications' => array(
					'type'  => 'array',
					'items' => $this->get_notification_schema(),
				),
				'notification'  => $this->get_notification_schema(),
			),
		);
	}

	/**
	 * Execute
	 * 
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'list':
				return array( 'notifications' => $this->notification_service->list_notifications() );

			case 'get':
				$identifier = $this->resolve_identifier( $payload );
				if ( is_wp_error( $identifier ) ) {
					return $identifier;
				}

				$notification = $this->notification_service->get_notification( $identifier );
				return is_wp_error( $notification ) ? $notification : array( 'notification' => $notification );

			case 'update':
				$identifier = $this->resolve_identifier( $payload );
				if ( is_wp_error( $identifier ) ) {
					return $identifier;
				}

				$settings = is_array(( isset( $payload['settings'] ) ? $payload['settings'] : null )) ? $payload['settings'] : array();
				$before   = $this->notification_service->snapshot_notification( $identifier );
				if ( is_wp_error( $before ) ) {
					return $before;
				}

				$updated = $this->notification_service->update_notification( $identifier, $settings );
				if ( is_wp_error( $updated ) ) {
					return $updated;
				}

				$this->record_change(
					'update',
					array(
						'notification_id' => $identifier,
						'title'           => ( isset( $updated['title'] ) ? $updated['title'] : '' ),
					),
					$before,
					sprintf(
						/* translators: %s: notification title */
						__( 'Updated email notification "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $updated['title'] ) ? $updated['title'] : $identifier )
				   )
				);

				return array( 'notification' => $updated );

			case 'create':
			case 'delete':
				return new \WP_Error(
					'wwp_notification_action_not_allowed',
					__( 'Create and delete are not supported for email notifications.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);

			default:
				return new \WP_Error(
					'wwp_notification_invalid_action',
					__( 'Invalid action. Use list, get, or update.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 * 
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The Email Notifications ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'wwp_ability_forbidden',
				__( 'You do not have permission to manage wholesale email notifications.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Register ability with update annotations.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/**
	 * Resolve notification identifier from payload.
	 *
	 * @param array<string, mixed> $payload Input payload.
	 * @return string|\WP_Error
	 */
	private function resolve_identifier( array $payload ) {
		$identifier = isset( $payload['identifier'] ) ? sanitize_key( (string) $payload['identifier'] ) : '';

		if ( '' === $identifier ) {
			return new \WP_Error(
				'wwp_notification_missing_identifier',
				__( 'Notification identifier is required.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return $identifier;
	}

	/**
	 * JSON schema for notification settings on update.
	 *
	 * @return array<string, mixed>
	 */
	private function get_settings_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'enabled'                      => array( 'type' => 'boolean' ),
				'stop_site_admin_notification' => array( 'type' => 'boolean' ),
				'recipients'                   => array( 'type' => 'string' ),
				'subject'                      => array( 'type' => 'string' ),
				'body'                         => array( 'type' => 'string' ),
			),
		);
	}

	/**
	 * JSON schema fragment for a notification object.
	 *
	 * @return array<string, mixed>
	 */
	private function get_notification_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'id'        => array( 'type' => 'string' ),
				'title'     => array( 'type' => 'string' ),
				'available' => array( 'type' => 'boolean' ),
				'settings'  => $this->get_settings_schema(),
			),
		);
	}

	/**
	 * Record a mutating change in history.
	 *
	 * @param string                    $action_type Action type.
	 * @param array<string, mixed>      $resource    Resource snapshot.
	 * @param array<string, mixed>|null $before      Before state.
	 * @param string                    $description Change description.
	 * @return void
	 */
	private function record_change( $action_type, array $resource, $before, $description ) {
		$this->history_service->record(
			array(
				'tool'               => 'wholesale_email_notifications',
				'ability'            => $this->get_key(),
				'change_description' => $description,
				'action_type'        => $action_type,
				'resource_type'      => 'email_notification',
				'resource'           => $resource,
				'before_state'       => $before,
			)
		);
	}
}
