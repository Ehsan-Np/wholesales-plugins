<?php
/**
 * Dashboard & Analytics ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Services\DashboardAnalyticsService;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * Read wholesale dashboard analytics and sales reports.
 */
class DashboardAbility extends AbstractAiAbility {

	/**
	 * Dashboard analytics service.
	 *
	 * @var DashboardAnalyticsService
	 */
	private $analytics_service;

	/**
	 * Constructor.
	 *
	 * @param DashboardAnalyticsService|null $analytics_service Optional service.
	 */
	public function __construct( $analytics_service = null ) {
		$this->analytics_service =( isset( $analytics_service ) ? $analytics_service : new DashboardAnalyticsService() );
	}

	/**
	 * Get key
	 * 
	 * @inheritDoc
	 */
	public function get_key() {
		return 'dashboard';
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'Dashboard & Analytics', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 * 
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Reads B2B wholesale analytics data: net/gross revenue, order counts, AOV, revenue trends, refunds, customer data, top products, top customers, registration requests, and recent orders. Supports date and range filters.', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 * 
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'wholesale';
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'       => array(
					'type'        => 'string',
					'enum'        => array( 'get' ),
					'description' => __( 'Action to perform (read-only).', 'woocommerce-wholesale-pricing' ),
				),
				'report'       => array(
					'type'        => 'string',
					'enum'        => DashboardAnalyticsService::REPORT_TYPES,
					'description' => __( 'Dashboard report to retrieve.', 'woocommerce-wholesale-pricing' ),
				),
				'period'       => array(
					'type'        => 'string',
					'enum'        => DashboardAnalyticsService::PERIOD_TYPES,
					'description' => __( 'Date period filter.', 'woocommerce-wholesale-pricing' ),
				),
				'start_date'   => array(
					'type'        => 'string',
					'description' => __( 'Start date (Y-m-d) when period is custom.', 'woocommerce-wholesale-pricing' ),
				),
				'end_date'     => array(
					'type'        => 'string',
					'description' => __( 'End date (Y-m-d) when period is custom.', 'woocommerce-wholesale-pricing' ),
				),
				'chart_filter' => array(
					'type'        => 'string',
					'enum'        => DashboardAnalyticsService::CHART_FILTERS,
					'description' => __( 'Chart metric when report is chart.', 'woocommerce-wholesale-pricing' ),
				),
				'limit'        => array(
					'type'        => 'integer',
					'description' => __( 'Max rows for top_products, top_customers, or recent_orders.', 'woocommerce-wholesale-pricing' ),
				),
			),
			'required'             => array( 'action', 'report' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'report'       => array( 'type' => 'string' ),
				'period'       => array( 'type' => 'string' ),
				'chart_filter' => array(
					'type' => array( 'string', 'null' ),
				),
				'limit'        => array(
					'type' => array( 'integer', 'null' ),
				),
				'filters'      => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),
				'data'         => array(
					'type' => array( 'object', 'array' ),
				),
			),
			'required'   => array( 'report', 'period', 'filters', 'data' ),
		);
	}

	/**
	 * Execute
	 * 
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'get':
				return $this->analytics_service->get_report( $payload );

			default:
				return new \WP_Error(
					'wwp_dashboard_invalid_action',
					__( 'Invalid action. Use get with a report name.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 * 
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The Dashboard & Analytics ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return new \WP_Error(
				'wwp_ability_forbidden',
				__( 'You do not have permission to view wholesale dashboard analytics.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Register ability with read-only annotations.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}
}
