<?php
/**
 * Quote Rules ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Services\Quote\WholesaleQuoteRuleService;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * CRUD ability for wc-quote-rules posts.
 */
class QuoteRulesAbility extends AbstractAiAbility {

	/**
	 * Quote rule service.
	 *
	 * @var WholesaleQuoteRuleService
	 */
	private $rule_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleQuoteRuleService|null $rule_service    Optional service.
	 * @param ChangeHistoryService|null      $history_service Optional history service.
	 */
	public function __construct(
		$rule_service = null,
		$history_service = null
	) {
		$this->rule_service    =( isset( $rule_service ) ? $rule_service : new WholesaleQuoteRuleService() );
		$this->history_service =( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
	}

	/**
	 * Get key
	 * 
	 * @inheritDoc
	 */
	public function get_key() {
		return 'quote_rules';
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'Manage Quote Rules', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 * 
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Full CRUD for wholesale quote rules under Wholesale → Quote → Quote Rules. Per rule: enable toggle, user scope (all/specific roles/specific users), quote status, product inclusions (products, categories, tags), product exclusions (products, categories, tags), quote button display (single product/shop page), and priority. Rules determine which users see a quote button instead of add-to-cart. When including specific products/categories/tags, set include.mode (or include.products / include.categories / include.tags); mode is inferred automatically when target lists are provided.', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 * 
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'quote';
	}

	/**
	 * Get input schema
	 * 
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'     => array(
					'type'        => 'string',
					'enum'        => array( 'list', 'get', 'create', 'update', 'delete' ),
					'description' => __( 'CRUD action to perform.', 'woocommerce-wholesale-pricing' ),
				),
				'identifier' => array(
					'type'        => array( 'string', 'integer' ),
					'description' => __( 'Rule post ID or title (required for get, update, delete).', 'woocommerce-wholesale-pricing' ),
				),
				'rule'       => $this->get_rule_object_schema(),
				'search'     => array(
					'type'        => 'string',
					'description' => __( 'Search rules by title (list).', 'woocommerce-wholesale-pricing' ),
				),
				'enabled'    => array(
					'type'        => 'boolean',
					'description' => __( 'Filter list results by enabled state.', 'woocommerce-wholesale-pricing' ),
				),
				'per_page'   => array(
					'type'        => 'integer',
					'description' => __( 'Results per page for list (max 100).', 'woocommerce-wholesale-pricing' ),
				),
				'page'       => array(
					'type'        => 'integer',
					'description' => __( 'Page number for list.', 'woocommerce-wholesale-pricing' ),
				),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => true,
		);
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'rules'   => array(
					'type'  => 'array',
					'items' => $this->get_rule_object_schema(),
				),
				'rule'    => $this->get_rule_object_schema(),
				'total'   => array( 'type' => 'integer' ),
				'deleted' => array( 'type' => 'boolean' ),
				'rule_id' => array( 'type' => 'integer' ),
				'title'   => array( 'type' => 'string' ),
			),
		);
	}

	/**
	 * Execute
	 * 
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'list':
				return $this->rule_service->list_rules(
					array(
						'search'   => ( isset( $payload['search'] ) ? $payload['search'] : '' ),
						'enabled'  => isset( $payload['enabled'] ) ? (bool) $payload['enabled'] : null,
						'per_page' => isset( $payload['per_page'] ) ? (int) $payload['per_page'] : 20,
						'page'     => isset( $payload['page'] ) ? (int) $payload['page'] : 1,
					)
				);

			case 'get':
				$rule_id = $this->resolve_identifier( $payload );
				if ( is_wp_error( $rule_id ) ) {
					return $rule_id;
				}
				$rule = $this->rule_service->get_rule( $rule_id );
				return is_wp_error( $rule ) ? $rule : array( 'rule' => $rule );

			case 'create':
				$rule_data = $this->build_rule_payload( $payload );
				$created   = $this->rule_service->create_rule( $rule_data );
				if ( is_wp_error( $created ) ) {
					return $created;
				}
				$this->record_change(
					'create',
					array(
						'rule_id' => ( isset( $created['id'] ) ? $created['id'] : 0 ),
						'title'   => ( isset( $created['title'] ) ? $created['title'] : '' ),
					),
					null,
					sprintf(
						/* translators: %s: rule title */
						__( 'Created quote rule "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $created['title'] ) ? $created['title'] : '' )
					)
				);
				return array( 'rule' => $created );

			case 'update':
				$rule_id = $this->resolve_identifier( $payload );
				if ( is_wp_error( $rule_id ) ) {
					return $rule_id;
				}
				$rule_data = $this->build_rule_payload( $payload );
				if ( empty( $rule_data ) ) {
					return new \WP_Error(
						'wwp_quote_rule_missing_data',
						__( 'Rule data is required for update.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$before  = $this->rule_service->snapshot_rule( $rule_id );
				$updated = $this->rule_service->update_rule( $rule_id, $rule_data );
				if ( is_wp_error( $updated ) ) {
					return $updated;
				}
				$this->record_change(
					'update',
					array(
						'rule_id' => ( isset( $updated['id'] ) ? $updated['id'] : $rule_id ),
						'title'   => ( isset( $updated['title'] ) ? $updated['title'] : '' ),
					),
					is_wp_error( $before ) ? null : $before,
					sprintf(
						/* translators: %s: rule title */
						__( 'Updated quote rule "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $updated['title'] ) ? $updated['title'] : '' )
					)
				);
				return array( 'rule' => $updated );

			case 'delete':
				$rule_id = $this->resolve_identifier( $payload );
				if ( is_wp_error( $rule_id ) ) {
					return $rule_id;
				}
				$before  = $this->rule_service->snapshot_rule( $rule_id );
				$deleted = $this->rule_service->delete_rule( $rule_id );
				if ( is_wp_error( $deleted ) ) {
					return $deleted;
				}
				$this->record_change(
					'delete',
					array(
						'rule_id' => ( isset( $deleted['rule_id'] ) ? $deleted['rule_id'] : $rule_id ),
						'title'   => ( isset( $deleted['title'] ) ? $deleted['title'] : '' ),
					),
					is_wp_error( $before ) ? null : $before,
					sprintf(
						/* translators: %s: rule title */
						__( 'Deleted quote rule "%s".', 'woocommerce-wholesale-pricing' ),
( isset( $deleted['title'] ) ? $deleted['title'] : '' )
					)
				);
				return $deleted;

			default:
				return new \WP_Error(
					'wwp_quote_rule_invalid_action',
					__( 'Invalid action. Use list, get, create, update, or delete.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 * 
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The Manage Quote Rules ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'wwp_ability_forbidden',
				__( 'You do not have permission to manage quote rules.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Register ability with destructive annotations.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/**
	 * Rule object schema for input/output.
	 *
	 * @return array<string, mixed>
	 */
	private function get_rule_object_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'id'                 => array( 'type' => 'integer' ),
				'title'              => array( 'type' => 'string' ),
				'status'             => array( 'type' => 'string' ),
				'priority'           => array( 'type' => 'integer' ),
				'enabled'            => array( 'type' => 'boolean' ),
				'user_roles'         => array( 'type' => 'object' ),
				'include'            => array( 'type' => 'object' ),
				'exclude'            => array( 'type' => 'object' ),
				'quote_status'       => array( 'type' => 'string' ),
				'hide_price'         => array( 'type' => 'boolean' ),
				'hide_price_message' => array( 'type' => 'string' ),
				'show_single'        => array( 'type' => 'boolean' ),
				'show_shop'          => array( 'type' => 'boolean' ),
				'hide_cart_single'   => array( 'type' => 'boolean' ),
				'hide_cart_shop'     => array( 'type' => 'boolean' ),
				'hide_cart_all'      => array( 'type' => 'boolean' ),
				'rule'               => array( 'type' => 'object' ),
			),
		);
	}

	/**
	 * Build service payload from ability input.
	 *
	 * @param array<string, mixed> $payload Ability input.
	 * @return array<string, mixed>
	 */
	private function build_rule_payload( array $payload ) {
		$data = is_array(( isset( $payload['rule'] ) ? $payload['rule'] : null )) ? $payload['rule'] : array();

		foreach ( array( 'title', 'status', 'priority', 'enabled' ) as $field ) {
			if ( array_key_exists( $field, $payload ) && ! array_key_exists( $field, $data ) ) {
				$data[ $field ] = $payload[ $field ];
			}
		}

		foreach ( array(
			'user_roles',
			'include',
			'exclude',
			'quote_status',
			'hide_price',
			'hide_price_message',
			'show_single',
			'show_shop',
			'hide_cart_single',
			'hide_cart_shop',
			'hide_cart_all',
		) as $field ) {
			if ( array_key_exists( $field, $payload ) && ! array_key_exists( $field, $data ) ) {
				$data[ $field ] = $payload[ $field ];
			}
		}

		return $data;
	}

	/**
	 * Resolve rule ID from identifier.
	 *
	 * @param array<string, mixed> $payload Ability input.
	 * @return int|\WP_Error
	 */
	private function resolve_identifier( array $payload ) {
		$identifier =( isset( $payload['identifier'] ) ? $payload['identifier'] : ( ( isset( $payload['rule']['id'] ) ? $payload['rule']['id'] : null ) ) );
		if ( null === $identifier || '' === $identifier ) {
			return new \WP_Error(
				'wwp_quote_rule_missing_identifier',
				__( 'Rule identifier is required.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( is_numeric( $identifier ) ) {
			return (int) $identifier;
		}

		$post_type = $this->rule_service->get_post_type();
		$title     = sanitize_text_field( (string) $identifier );
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$post_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_title = %s AND post_status != 'trash' ORDER BY ID DESC LIMIT 1",
				$post_type,
				$title
			)
		);

		if ( $post_id <= 0 ) {
			$posts = get_posts(
				array(
					'post_type'      => $post_type,
					'post_status'    => 'any',
					's'              => $title,
					'posts_per_page' => 1,
					'fields'         => 'ids',
				)
			);
			$post_id = ! empty( $posts ) ? (int) $posts[0] : 0;
		}

		if ( $post_id <= 0 ) {
			return new \WP_Error(
				'wwp_quote_rule_not_found',
				__( 'Quote rule not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		return (int) $post_id;
	}

	/**
	 * Record a mutating change in history.
	 *
	 * @param string                    $action_type Action type.
	 * @param array<string, mixed>      $resource    Resource snapshot.
	 * @param array<string, mixed>|null $before      Before state.
	 * @param string                    $description Change description.
	 * @return void
	 */
	private function record_change( $action_type, array $resource, $before, $description ) {
		$this->history_service->record(
			array(
				'tool'               => 'quote_rules',
				'ability'            => $this->get_key(),
				'change_description' => $description,
				'action_type'        => $action_type,
				'resource_type'      => 'quote_rule',
				'resource'           => $resource,
				'before_state'       => $before,
			)
		);
	}
}
