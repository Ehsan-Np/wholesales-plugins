<?php
/**
 * Registers AI assistant abilities with WordPress.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\SettingsService;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * Boots ability category and class registration.
 */
class AbilityRegistry {

	/**
	 * Whether hooks were already attached.
	 *
	 * @var bool
	 */
	private static $booted = false;

	/**
	 * Ability class map keyed by settings key.
	 *
	 * @var array<string, class-string<AbstractAiAbility>>
	 */
	const ABILITY_CLASSES = array(
		'dashboard'                   => DashboardAbility::class,
		'wholesale_settings'          => WholesaleSettingsAbility::class,
		'global_discounts'            => GlobalDiscountsAbility::class,
		'cart_discounts'              => CartDiscountsAbility::class,
		'b2b_user_roles'              => B2bUserRolesAbility::class,
		'wholesale_email_notifications' => WholesaleEmailNotificationsAbility::class,
		'wholesale_registration'      => WholesaleRegistrationAbility::class,
		'woocommerce_products'        => WooCommerceProductsAbility::class,
		'woocommerce_categories'      => WooCommerceCategoriesAbility::class,
		'wholesale_account_requests'  => WholesaleAccountRequestsAbility::class,
		'b2b_user_profiles'           => B2bUserProfilesAbility::class,
		'quote_settings'              => QuoteSettingsAbility::class,
		'quote_rules'                 => QuoteRulesAbility::class,
		'modify_update_quotes'        => ModifyUpdateQuotesAbility::class,
	);

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( self::$booted ) {
			return;
		}

		self::$booted = true;

		add_action( 'wp_abilities_api_categories_init', array( $this, 'register_categories' ) );
		add_action( 'wp_abilities_api_init', array( $this, 'register_abilities' ) );
	}

	/**
	 * Register ability categories (must run on wp_abilities_api_categories_init).
	 *
	 * @return void
	 */
	public function register_categories() {
		if ( ! SettingsService::is_enabled() ) {
			return;
		}

		if ( ! function_exists( 'wp_register_ability_category' ) ) {
			return;
		}

		wp_register_ability_category(
			'wholesale',
			array(
				'label'       => __( 'Wholesale', 'woocommerce-wholesale-pricing' ),
				'description' => __( 'Abilities for the Wholesale for WooCommerce plugin.', 'woocommerce-wholesale-pricing' ),
			)
		);

		wp_register_ability_category(
			'quote',
			array(
				'label'       => __( 'Quote', 'woocommerce-wholesale-pricing' ),
				'description' => __( 'Abilities for the Request a Quote module.', 'woocommerce-wholesale-pricing' ),
			)
		);
	}

	/**
	 * Register active ability classes.
	 *
	 * @return void
	 */
	public function register_abilities() {
		if ( ! SettingsService::is_enabled() ) {
			return;
		}

		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		foreach ( AbilityCatalog::get_active_keys() as $key ) {
			$class =( isset( self::ABILITY_CLASSES[ $key ] ) ? self::ABILITY_CLASSES[ $key ] : null );
			if ( null === $class || ! class_exists( $class ) ) {
				continue;
			}

			$ability = new $class();
			$ability->register();
		}
	}
}
