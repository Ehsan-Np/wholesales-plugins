<?php
/**
 * Wholesale Settings ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\QuoteCustomizationCatalog;
use WooCommerceWholesalePricing\App\Providers\WholesaleOption;
use WooCommerceWholesalePricing\App\Services\WholesalePricingSettingsService;
use WooCommerceWholesalePricing\App\Services\WholesaleQuoteCustomizationSettingsService;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * Get and update wholesale pricing / general plugin settings.
 */
class WholesaleSettingsAbility extends AbstractAiAbility {

	/**
	 * Pricing settings service.
	 *
	 * @var WholesalePricingSettingsService
	 */
	private $settings_service;

	/**
	 * Quote customization settings service.
	 *
	 * @var WholesaleQuoteCustomizationSettingsService
	 */
	private $quote_customization_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Constructor.
	 *
	 * @param WholesalePricingSettingsService|null            $settings_service              Optional service.
	 * @param WholesaleQuoteCustomizationSettingsService|null $quote_customization_service   Optional quote customization service.
	 * @param ChangeHistoryService|null                       $history_service               Optional history service.
	 */
	public function __construct(
		$settings_service = null,
		$quote_customization_service = null,
		$history_service = null
	) {
		$this->settings_service            = ( isset( $settings_service ) ? $settings_service : new WholesalePricingSettingsService() );
		$this->quote_customization_service = ( isset( $quote_customization_service ) ? $quote_customization_service : new WholesaleQuoteCustomizationSettingsService() );
		$this->history_service             = ( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
	}

	/**
	 * Get key
	 *
	 * @inheritDoc
	 */
	public function get_key() {
		return 'wholesale_settings';
	}

	/**
	 * Get label
	 *
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'Wholesale Settings', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 *
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Reads and writes wholesale plugin settings under Wholesale → Settings (all tabs except Global Wholesale Pricing, Cart Total Discounts, Quote tab toggles, and Quote PDF). Covers pricing mode, login restrictions, product visibility, price display, registration, and quote label/color customization under settings.wc_quote_customization (build_quote_text, add_quote_text, quote_btn_positioning, button colors, etc.). Key settings include: disable_auto_role (yes = require manual approval for wholesale registration, no = auto-approve), wholesale_role, wholesale_price_application, enable_registration_page, wholesaler_login_restriction, wwp_hide_add_to_cart, wwp_hide_price, enable_coupon, and related yes/no toggles. Use action get to read current values and action update with a partial settings object to change them.', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 *
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'wholesale';
	}

	/**
	 * Get input schema
	 *
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'   => array(
					'type'        => 'string',
					'enum'        => array( 'get', 'update' ),
					'description' => __( 'Action to perform.', 'woocommerce-wholesale-pricing' ),
				),
				'settings' => array(
					'type'                 => 'object',
					'description'          => __( 'Partial wholesale settings patch (general, registration page, labels, login, visibility, payments, CSS, and wc_quote_customization quote labels/colors). Excludes global/cart role discounts, tier_pricing, and quote tab toggles.', 'woocommerce-wholesale-pricing' ),
					'additionalProperties' => true,
				),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * Get output schema
	 *
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'option_key' => array( 'type' => 'string' ),
				'settings'   => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),
			),
		);
	}

	/**
	 * Execute
	 *
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'get':
				return $this->get_merged_settings();

			case 'update':
				$settings = is_array( ( isset( $payload['settings'] ) ? $payload['settings'] : null ) ) ? $payload['settings'] : array();
				$before   = $this->snapshot_all_settings();
				$updated  = $this->apply_settings_patch( $settings );

				if ( is_wp_error( $updated ) ) {
					return $updated;
				}

				$this->record_change(
					'update',
					array(
						'option_key' => WholesaleOption::PRICING_OPTION,
					),
					$before,
					__( 'Updated wholesale settings.', 'woocommerce-wholesale-pricing' )
				);

				return $updated;

			case 'create':
			case 'delete':
				return new \WP_Error(
					'wwp_wholesale_settings_action_not_allowed',
					__( 'Create and delete are not supported for wholesale settings. Use update with false or empty values to disable options.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);

			default:
				return new \WP_Error(
					'wwp_wholesale_settings_invalid_action',
					__( 'Invalid action. Use get or update.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 *
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The Wholesale Settings ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'wwp_ability_forbidden',
				__( 'You do not have permission to manage wholesale settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Register ability with update annotations.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/**
	 * Get pricing settings merged with quote customization.
	 *
	 * @return array<string, mixed>
	 */
	private function get_merged_settings() {
		$result = $this->settings_service->get_settings();

		if ( ! is_array( $result ) ) {
			$result = array(
				'option_key' => WholesaleOption::PRICING_OPTION,
				'settings'   => array(),
			);
		}

		if ( ! isset( $result['settings'] ) || ! is_array( $result['settings'] ) ) {
			$result['settings'] = array();
		}

		$result['settings'][ QuoteCustomizationCatalog::PARENT_KEY ] = $this->quote_customization_service->get_settings();

		return $result;
	}

	/**
	 * Apply a settings patch to pricing and quote customization options.
	 *
	 * @param array<string, mixed> $settings Settings patch.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function apply_settings_patch( array $settings ) {
		if ( empty( $settings ) ) {
			return new \WP_Error(
				'wwp_wholesale_settings_missing',
				__( 'Settings are required for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$quote_patch    = array();
		$pricing_patch  = $settings;

		if ( array_key_exists( QuoteCustomizationCatalog::PARENT_KEY, $settings ) ) {
			$quote_patch = is_array( $settings[ QuoteCustomizationCatalog::PARENT_KEY ] )
				? $settings[ QuoteCustomizationCatalog::PARENT_KEY ]
				: array();
			unset( $pricing_patch[ QuoteCustomizationCatalog::PARENT_KEY ] );
		}

		if ( ! empty( $quote_patch ) ) {
			$quote_updated = $this->quote_customization_service->update_settings( $quote_patch );

			if ( is_wp_error( $quote_updated ) ) {
				return $quote_updated;
			}
		}

		if ( ! empty( $pricing_patch ) ) {
			$pricing_updated = $this->settings_service->update_settings( $pricing_patch );

			if ( is_wp_error( $pricing_updated ) ) {
				return $pricing_updated;
			}
		}

		return $this->get_merged_settings();
	}

	/**
	 * Snapshot pricing and quote customization for undo.
	 *
	 * @return array<string, mixed>
	 */
	private function snapshot_all_settings() {
		return array(
			'pricing'             => $this->settings_service->snapshot_settings(),
			'quote_customization' => $this->quote_customization_service->snapshot_settings(),
		);
	}

	/**
	 * Record a mutating change in history.
	 *
	 * @param string                    $action_type Action type.
	 * @param array<string, mixed>      $resource    Resource snapshot.
	 * @param array<string, mixed>|null $before      Before state.
	 * @param string                    $description Change description.
	 * @return void
	 */
	private function record_change( $action_type, array $resource, $before, $description ) {
		$this->history_service->record(
			array(
				'tool'               => 'wholesale_settings',
				'ability'            => $this->get_key(),
				'change_description' => $description,
				'action_type'        => $action_type,
				'resource_type'      => 'settings',
				'resource'           => $resource,
				'before_state'       => $before,
			)
		);
	}
}
