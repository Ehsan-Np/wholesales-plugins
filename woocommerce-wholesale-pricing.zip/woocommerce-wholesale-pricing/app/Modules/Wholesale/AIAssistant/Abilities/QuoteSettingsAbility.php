<?php
/**
 * Quote Settings ability.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Abilities;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\ChangeHistoryService;
use WooCommerceWholesalePricing\App\Providers\WholesaleOption;
use WooCommerceWholesalePricing\App\Services\WholesaleQuoteSettingsService;
use WooCommerceWholesalePricing\App\Strategies\AbstractAiAbility;

/**
 * Get and update quote module settings (Quote + Quote PDF tabs).
 */
class QuoteSettingsAbility extends AbstractAiAbility {

	/**
	 * Quote settings service.
	 *
	 * @var WholesaleQuoteSettingsService
	 */
	private $settings_service;

	/**
	 * Change history service.
	 *
	 * @var ChangeHistoryService
	 */
	private $history_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleQuoteSettingsService|null $settings_service Optional service.
	 * @param ChangeHistoryService|null          $history_service  Optional history service.
	 */
	public function __construct(
		$settings_service = null,
		$history_service = null
	) {
		$this->settings_service =( isset( $settings_service ) ? $settings_service : new WholesaleQuoteSettingsService() );
		$this->history_service  =( isset( $history_service ) ? $history_service : new ChangeHistoryService() );
	}

	/**
	 * Get key
	 * 
	 * @inheritDoc
	 */
	public function get_key() {
		return 'quote_settings';
	}

	/**
	 * Get label
	 * 
	 * @inheritDoc
	 */
	public function get_label() {
		return __( 'Manage Quote Settings', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get description
	 * 
	 * @inheritDoc
	 */
	public function get_description() {
		return __( 'Reads and writes all settings under Wholesale → Settings → Quote and Quote PDF tabs. Use action get to read current values. Use action update with settings grouped as enable_quote (top-level bool), general (wc_quote_general toggles and fields), notifications (wc_quote_notifications messages and redirects), and pdf (wc_quote_pdf: enable_pdf, enable_pdf_download, enable_pdf_attach, hide_product_list, pdf_logo_id, pdf_show_link, quote_pdf default|custom, custom bronze|darkblue|lightblue). Flat field keys at settings top level are also accepted and normalized into the correct group.', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Get plugin
	 * 
	 * @inheritDoc
	 */
	public function get_plugin() {
		return 'quote';
	}

	/**
	 * Get input schema
	 * 
	 * @inheritDoc
	 */
	public function get_input_schema() {
		return array(
			'type'                 => 'object',
			'properties'           => array(
				'action'   => array(
					'type'        => 'string',
					'enum'        => array( 'get', 'update' ),
					'description' => __( 'Action to perform.', 'woocommerce-wholesale-pricing' ),
				),
				'settings' => array(
					'type'        => 'object',
					'description' => __( 'Partial quote settings patch grouped by enable_quote, general, notifications, and pdf. PDF keys (enable_pdf, quote_pdf, custom, pdf_logo_id, etc.) belong under settings.pdf.', 'woocommerce-wholesale-pricing' ),
					'properties'  => array(
						'enable_quote'  => array( 'type' => 'boolean' ),
						'general'       => array(
							'type'                 => 'object',
							'additionalProperties' => true,
						),
						'notifications' => array(
							'type'                 => 'object',
							'additionalProperties' => true,
						),
						'pdf'           => array(
							'type'                 => 'object',
							'description'          => __( 'Quote PDF tab settings stored in wc_quote_pdf.', 'woocommerce-wholesale-pricing' ),
							'additionalProperties' => true,
						),
					),
					'additionalProperties' => true,
				),
			),
			'required'             => array( 'action' ),
			'additionalProperties' => false,
		);
	}

	/**
	 * Get output schema
	 * 
	 * @inheritDoc
	 */
	public function get_output_schema() {
		return array(
			'type'       => 'object',
			'properties' => array(
				'pricing_option_key'       => array( 'type' => 'string' ),
				'general_option_key'       => array( 'type' => 'string' ),
				'notifications_option_key' => array( 'type' => 'string' ),
				'pdf_option_key'           => array( 'type' => 'string' ),
				'settings'                 => array(
					'type'                 => 'object',
					'additionalProperties' => true,
				),
			),
		);
	}

	/**
	 * Execute
	 * 
	 * @inheritDoc
	 */
	public function execute( $input ) {
		$payload = is_array( $input ) ? $input : array();
		$action  = isset( $payload['action'] ) ? sanitize_key( (string) $payload['action'] ) : '';

		switch ( $action ) {
			case 'get':
				return $this->settings_service->get_settings();

			case 'update':
				$settings = is_array(( isset( $payload['settings'] ) ? $payload['settings'] : null )) ? $payload['settings'] : array();
				$before   = $this->settings_service->snapshot_settings();
				$updated  = $this->settings_service->update_settings( $settings );

				if ( is_wp_error( $updated ) ) {
					return $updated;
				}

				$this->record_change(
					'update',
					array(
						'pricing_option_key'       => WholesaleOption::PRICING_OPTION,
						'general_option_key'       => WholesaleOption::QUOTE_GENERAL_OPTION,
						'notifications_option_key' => WholesaleOption::QUOTE_NOTIFICATIONS_OPTION,
						'pdf_option_key'           => WholesaleOption::QUOTE_PDF_OPTION,
					),
					$before,
					__( 'Updated quote settings.', 'woocommerce-wholesale-pricing' )
				);

				return $updated;

			case 'create':
			case 'delete':
				return new \WP_Error(
					'wwp_quote_settings_action_not_allowed',
					__( 'Create and delete are not supported for quote settings. Use update with false or empty values to disable options.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);

			default:
				return new \WP_Error(
					'wwp_quote_settings_invalid_action',
					__( 'Invalid action. Use get or update.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
		}
	}

	/**
	 * Check permission
	 * 
	 * @inheritDoc
	 */
	public function check_permission( $input ) {
		if ( ! $this->is_enabled() ) {
			return new \WP_Error(
				'wwp_ability_disabled',
				__( 'The Manage Quote Settings ability is disabled in AI Assistant settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error(
				'wwp_ability_forbidden',
				__( 'You do not have permission to manage quote settings.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Register ability with update annotations.
	 *
	 * @return void
	 */
	public function register() {
		if ( ! function_exists( 'wp_register_ability' ) ) {
			return;
		}

		wp_register_ability(
			$this->get_ability_name(),
			array(
				'label'               => $this->get_label(),
				'description'         => $this->get_description(),
				'category'            => $this->get_plugin(),
				'input_schema'        => $this->get_input_schema(),
				'output_schema'       => $this->get_output_schema(),
				'execute_callback'    => array( $this, 'execute' ),
				'permission_callback' => array( $this, 'check_permission' ),
				'meta'                => array(
					'show_in_rest' => false,
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);
	}

	/**
	 * Record a mutating change in history.
	 *
	 * @param string                    $action_type Action type.
	 * @param array<string, mixed>      $resource    Resource snapshot.
	 * @param array<string, mixed>|null $before      Before state.
	 * @param string                    $description Change description.
	 * @return void
	 */
	private function record_change( $action_type, array $resource, $before, $description ) {
		$this->history_service->record(
			array(
				'tool'               => 'quote_settings',
				'ability'            => $this->get_key(),
				'change_description' => $description,
				'action_type'        => $action_type,
				'resource_type'      => 'quote_settings',
				'resource'           => $resource,
				'before_state'       => $before,
			)
		);
	}
}
