<?php
/**
 * ProductService class for handling product-specific display and pricing adjustments.
 *
 * This class applies wholesale pricing overrides to the product pages, shop loops,
 * and the cart price column, and handles the display of custom product attachments.
 *
 * @package    WooCommerceWholesalePricing\App\Modules\Wholesale
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale;

use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\RegularPriceChange;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\ProductPriceHTML;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\VariablePriceHTML;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Class ProductService
 *
 * Manages product pricing filters, price HTML display formats, and displays
 * custom product attachments based on wholesale settings.
 */
class ProductService {


   
	/**
	 * Holds a reference to a WC_Product object for temporary use (currently unused in this file).
	 *
	 * @var \WC_Product|null
	 */
	private $product_obj = null;

	/**
	 * Flag to indicate if a tier pricing table should be displayed (currently unused in this file).
	 *
	 * @var bool
	 */
	private $tier_table = false;

	/**
	 * Includes methods for retrieving general wholesale settings and price manipulation.
	 */
	use WholesaleSettings;
	use ProductPriceHTML;
	use VariablePriceHTML;
	use RegularPriceChange;

	/**
	 * ProductService constructor.
	 *
	 * Registers all necessary WordPress and WooCommerce hooks to filter product prices,
	 * modify price display HTML, and add custom attachments.
	 */
	public function __construct() {

		$settings = self::get_pricing_settings();

		// Price HTML Display Hooks
		add_filter('woocommerce_cart_item_price', array( $this, 'wwp_change_product_price_display' ), 200, 2);
		add_filter('woocommerce_variable_sale_price_html', array( $this, 'wwp_variable_price_format' ), 200, 2);
		add_filter('woocommerce_variable_price_html', array( $this, 'wwp_variable_price_format' ), 200, 2);

		// Raw Price Hooks (Applying the wholesale price logic)
		add_filter('woocommerce_product_get_price', array( $this, 'wwp_regular_price_change' ), 200, 2);
		add_filter('woocommerce_product_get_regular_price', array( $this, 'wwp_regular_price_change' ), 200, 2);
		// Product variations (of a variable product)
		add_filter('woocommerce_product_variation_get_price', array( $this, 'wwp_regular_price_change' ), 200, 2);
		add_filter('woocommerce_product_variation_get_regular_price', array( $this, 'wwp_regular_price_change' ), 200, 2);

		// Custom Product Attachment Hook
		if (isset($settings['wwp_attachment_location']) && !empty($settings['wwp_attachment_location']) ) {
			add_action($settings['wwp_attachment_location'], array( $this, 'product_attachment_location' ), 10, 1);
		}
	}

	/**
	 * Renders a custom attachment link on the single product page.
	 *
	 * The location is determined by the 'wwp_attachment_location' setting. It retrieves
	 * the icon, URL, title, and link text from the product's post meta and displays
	 * the attachment container if a URL is set.
	 *
	 * @hook wwp_attachment_location (User-defined action hook)
	 *
	 * @param  mixed $var Not directly used, but present due to action hook signature.
	 * @return void Outputs HTML directly.
	 */
	public function product_attachment_location( $var ) {
		$wwp_icon_url             = get_post_meta(get_the_ID(), 'wwp_icon_url', true);
		$wwp_attachment_url       = get_post_meta(get_the_ID(), 'wwp_image_url', true);
		$wwp_attachment_title     = get_post_meta(get_the_ID(), 'wwp_attachment_title', true);
		$wwp_attachment_text_link = get_post_meta(get_the_ID(), 'wwp_attachment_text_link', true);
		
		if (!empty($wwp_attachment_url) ) {
			?>
			<div class="wwp_attachment_container">
				<h3 class="wwp_attachment_title"> <?php echo esc_attr($wwp_attachment_title); ?></h3>
				<a href="<?php echo esc_attr($wwp_attachment_url); ?>" target="_blank">
					<?php if (!empty($wwp_icon_url) ) { ?>
					<img src="<?php echo esc_attr($wwp_icon_url); ?>">
					<?php } ?>
					<p><?php echo esc_attr($wwp_attachment_text_link); ?></p>
				</a>
				
			</div>
			<?php   
		}
	} 
}
