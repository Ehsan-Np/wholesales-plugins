<?php
/**
 * Purchase Order payment gateway.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\PaymentGateway
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\PaymentGateway;

use WooCommerceWholesalePricing\App\Services\PurchaseOrderGatewayService;

/**
 * Classic checkout gateway for wholesale purchase orders.
 *
 * @extends \WC_Payment_Gateway
 */
class PurchaseOrderPaymentMethod extends \WC_Payment_Gateway {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->id                 = PurchaseOrderGatewayService::GATEWAY_ID;
		$this->icon               = apply_filters( 'wwp_po_gateway_icon', '' );
		$this->has_fields         = true;
		$this->method_title       = __( 'Purchase Order', 'woocommerce-wholesale-pricing' );
		$this->method_description = __( 'Allow wholesale buyers to pay with a purchase order number and optional document.', 'woocommerce-wholesale-pricing' );
		$this->supports           = array( 'products' );

		$this->init_form_fields();
		$this->init_settings();

		$this->title       = $this->get_option( 'title', __( 'Purchase Order', 'woocommerce-wholesale-pricing' ) );
		$this->description = $this->get_option( 'description' );
		$this->enabled     = $this->get_option( 'enabled', 'yes' );

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'validate_checkout' ), 10, 2 );
		add_action( 'woocommerce_checkout_process', array( $this, 'validate_checkout_process' ) );
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( $this, 'validate_store_api_checkout' ), 10, 2 );
	}

	/**
	 * Gateway settings fields.
	 *
	 * @return void
	 */
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'     => array(
				'title'   => __( 'Enable/Disable', 'woocommerce-wholesale-pricing' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable Purchase Order', 'woocommerce-wholesale-pricing' ),
				'default' => 'yes',
			),
			'title'       => array(
				'title'       => __( 'Title', 'woocommerce-wholesale-pricing' ),
				'type'        => 'text',
				'description' => __( 'This controls the title the customer sees during checkout.', 'woocommerce-wholesale-pricing' ),
				'default'     => __( 'Purchase Order', 'woocommerce-wholesale-pricing' ),
				'desc_tip'    => true,
			),
			'description' => array(
				'title'       => __( 'Description', 'woocommerce-wholesale-pricing' ),
				'type'        => 'textarea',
				'description' => __( 'Payment method description that the customer will see on your checkout.', 'woocommerce-wholesale-pricing' ),
				'default'     => __( 'Pay using a purchase order.', 'woocommerce-wholesale-pricing' ),
				'desc_tip'    => true,
			),
		);
	}

	/**
	 * Whether the gateway is available for the current shopper.
	 *
	 * @return bool
	 */
	public function is_available() {
		if ( ! parent::is_available() ) {
			return false;
		}

		return PurchaseOrderGatewayService::is_po_enabled_for_user();
	}

	/**
	 * Payment fields on classic checkout.
	 *
	 * @return void
	 */
	public function payment_fields() {
		$description = $this->get_description();
		if ( $description ) {
			echo wp_kses_post( wpautop( wptexturize( $description ) ) );
		}

		$settings = PurchaseOrderGatewayService::get_po_settings_for_user();
		$accept   = '';
		if ( ! empty( $settings['file_types'] ) && is_array( $settings['file_types'] ) ) {
			$accept = '.' . implode( ',.', $settings['file_types'] );
		}

		echo '<fieldset id="wwp-po-fields" class="wwp-po-fields wc-payment-form">';

		if ( ! empty( $settings['require_number'] ) ) {
			?>
			<p class="form-row form-row-wide">
				<label for="wwp_po_number">
					<?php esc_html_e( 'PO number', 'woocommerce-wholesale-pricing' ); ?>&nbsp;<abbr class="required" title="<?php esc_attr_e( 'required', 'woocommerce-wholesale-pricing' ); ?>">*</abbr>
				</label>
				<input type="text" class="input-text" name="wwp_po_number" id="wwp_po_number" autocomplete="off" />
			</p>
			<?php
		}

		if ( ! empty( $settings['allow_upload'] ) ) {
			$required = ! empty( $settings['require_upload'] );
			?>
			<p class="form-row form-row-wide wwp-po-upload-row">
				<label for="wwp_po_document">
					<?php esc_html_e( 'PO document', 'woocommerce-wholesale-pricing' ); ?>
					<?php if ( $required ) : ?>
						&nbsp;<abbr class="required" title="<?php esc_attr_e( 'required', 'woocommerce-wholesale-pricing' ); ?>">*</abbr>
					<?php endif; ?>
				</label>
				<input type="file" name="wwp_po_document" id="wwp_po_document" <?php echo $accept ? 'accept="' . esc_attr( $accept ) . '"' : ''; ?> />
				<input type="hidden" name="wwp_po_attachment_id" id="wwp_po_attachment_id" value="" />
				<span class="description">
					<?php
					printf(
						/* translators: 1: allowed extensions, 2: max size in MB */
						esc_html__( 'Allowed types: %1$s. Max size: %2$d MB per file.', 'woocommerce-wholesale-pricing' ),
						esc_html( '.' . implode( ', .', $settings['file_types'] ) ),
						absint( $settings['max_file_size'] )
					);
					?>
				</span>
			</p>
			<?php
		}

		echo '</fieldset>';
	}

	/**
	 * Validate classic checkout (after_checkout_validation).
	 *
	 * @param array     $data   Posted data.
	 * @param \WP_Error $errors Validation errors.
	 * @return void
	 */
	public function validate_checkout( $data, $errors ) {
		if ( ! $this->is_selected_payment_method( $data ) ) {
			return;
		}

		foreach ( $this->collect_validation_errors() as $message ) {
			$errors->add( 'wwp_po', $message );
		}
	}

	/**
	 * Validate classic checkout before order creation.
	 *
	 * @return void
	 */
	public function validate_checkout_process() {
		if ( ! $this->is_selected_payment_method( $_POST ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return;
		}

		foreach ( $this->collect_validation_errors() as $message ) {
			wc_add_notice( $message, 'error' );
		}
	}

	/**
	 * Validate and persist PO data on block checkout.
	 *
	 * @param \WC_Order        $order   Order.
	 * @param \WP_REST_Request $request Request.
	 * @return void
	 */
	public function validate_store_api_checkout( $order, $request ) {
		if ( PurchaseOrderGatewayService::GATEWAY_ID !== $this->get_request_payment_method( $request ) ) {
			return;
		}

		$settings   = PurchaseOrderGatewayService::get_po_settings_for_user();
		$submission = PurchaseOrderGatewayService::get_submission_from_request( $request );
		$errors     = PurchaseOrderGatewayService::validate_po_submission( $settings, $submission['po_number'], $submission['attachment_id'] );

		if ( ! empty( $errors ) ) {
			PurchaseOrderGatewayService::throw_store_api_error( $errors[0] );
		}

		if ( $order instanceof \WC_Order ) {
			PurchaseOrderGatewayService::save_po_to_order( $order, $submission['po_number'], $submission['attachment_id'], $settings );
		}
	}

	/**
	 * Process the payment.
	 *
	 * @param int $order_id Order ID.
	 * @return array
	 */
	public function process_payment( $order_id ) {
		$order         = wc_get_order( $order_id );
		$settings      = PurchaseOrderGatewayService::get_po_settings_for_user();
		$submission    = PurchaseOrderGatewayService::get_submission_from_request();
		$attachment_id = $submission['attachment_id'];

		if ( $order instanceof \WC_Order && $attachment_id < 1 ) {
			$attachment_id = absint( $order->get_meta( '_wwp_po_attachment_id' ) );
		}

		$uploaded_file = PurchaseOrderGatewayService::get_uploaded_file_from_request();
		if ( ! empty( $uploaded_file['name'] ) ) {
			$created = PurchaseOrderGatewayService::create_attachment_from_file( $uploaded_file, $settings );
			if ( is_wp_error( $created ) ) {
				wc_add_notice( $created->get_error_message(), 'error' );
				return array(
					'result'   => 'failure',
					'messages' => $created->get_error_message(),
				);
			}
			$attachment_id = (int) $created;
		}

		$errors = PurchaseOrderGatewayService::validate_po_submission( $settings, $submission['po_number'], $attachment_id );
		if ( ! empty( $errors ) ) {
			wc_add_notice( $errors[0], 'error' );
			return array(
				'result'   => 'failure',
				'messages' => $errors[0],
			);
		}

		if ( $order instanceof \WC_Order ) {
			PurchaseOrderGatewayService::save_po_to_order( $order, $submission['po_number'], $attachment_id, $settings );
			$order->payment_complete();
		}

		if ( WC()->cart ) {
			WC()->cart->empty_cart();
		}

		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}

	/**
	 * Collect validation messages for the current request.
	 *
	 * @return string[]
	 */
	protected function collect_validation_errors() {
		$settings      = PurchaseOrderGatewayService::get_po_settings_for_user();
		$submission    = PurchaseOrderGatewayService::get_submission_from_request();
		$attachment_id = $submission['attachment_id'];

		$uploaded_file = PurchaseOrderGatewayService::get_uploaded_file_from_request();
		if ( ! empty( $uploaded_file['name'] ) ) {
			$valid = PurchaseOrderGatewayService::validate_uploaded_file( $uploaded_file, $settings );
			if ( is_wp_error( $valid ) ) {
				return array( $valid->get_error_message() );
			}
			$attachment_id = 1;
		}

		return PurchaseOrderGatewayService::validate_po_submission( $settings, $submission['po_number'], $attachment_id );
	}

	/**
	 * Whether this gateway is the selected payment method.
	 *
	 * @param mixed $source Posted data or request.
	 * @return bool
	 */
	protected function is_selected_payment_method( $source ) {
		return PurchaseOrderGatewayService::GATEWAY_ID === $this->get_request_payment_method( $source );
	}

	/**
	 * Extract payment method id from posted data or Store API request.
	 *
	 * @param mixed $request Request or posted checkout data.
	 * @return string
	 */
	protected function get_request_payment_method( $request ) {
		if ( is_array( $request ) && ! empty( $request['payment_method'] ) ) {
			return (string) $request['payment_method'];
		}

		if ( is_object( $request ) && method_exists( $request, 'get_param' ) ) {
			$method = $request->get_param( 'payment_method' );
			if ( ! empty( $method ) ) {
				return (string) $method;
			}
		}

		if ( isset( $_POST['payment_method'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return (string) wc_clean( wp_unslash( $_POST['payment_method'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}

		return '';
	}
}
