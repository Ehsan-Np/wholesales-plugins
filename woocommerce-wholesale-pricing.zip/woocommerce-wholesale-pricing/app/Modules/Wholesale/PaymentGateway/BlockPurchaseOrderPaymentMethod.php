<?php
/**
 * Block checkout registration for Purchase Order.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\PaymentGateway
 */

namespace WooCommerceWholesalePricing\App\Modules\Wholesale\PaymentGateway;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;
use WooCommerceWholesalePricing\App\Services\PurchaseOrderGatewayService;

/**
 * Registers wwp_purchase_order with WooCommerce Blocks.
 *
 * @extends AbstractPaymentMethodType
 */
class BlockPurchaseOrderPaymentMethod extends AbstractPaymentMethodType {

	/**
	 * Payment method name/id.
	 *
	 * @var string
	 */
	protected $name = PurchaseOrderGatewayService::GATEWAY_ID;

	/**
	 * Gateway settings.
	 *
	 * @var array
	 */
	protected $settings = array();

	/**
	 * Initialize settings from the classic gateway.
	 *
	 * @return void
	 */
	public function initialize() {
		$payment_gateways = WC()->payment_gateways()->payment_gateways();
		$title            = '';
		$description      = '';

		if ( isset( $payment_gateways[ $this->name ] ) ) {
			$title       = isset( $payment_gateways[ $this->name ]->settings['title'] ) ? $payment_gateways[ $this->name ]->settings['title'] : '';
			$description = isset( $payment_gateways[ $this->name ]->settings['description'] ) ? $payment_gateways[ $this->name ]->settings['description'] : '';
		}

		$this->settings = get_option(
			'woocommerce_' . $this->name . '_settings',
			array(
				'title'       => $title,
				'description' => $description,
			)
		);
	}

	/**
	 * Whether the payment method is available.
	 *
	 * @return bool
	 */
	public function is_active() {
		$payment_gateways = WC()->payment_gateways()->payment_gateways();

		if ( ! isset( $payment_gateways[ $this->name ] ) ) {
			return false;
		}

		return $payment_gateways[ $this->name ]->is_available();
	}

	/**
	 * Register and return frontend script handles.
	 *
	 * @return string[]
	 */
	public function get_payment_method_script_handles() {
		$asset_path   = WWP_PLUGIN_PATH . 'build/purchase-order-gateway/index.asset.php';
		$version      = WWP_VERSION;
		$dependencies = array();

		if ( file_exists( $asset_path ) ) {
			$asset        = include $asset_path;
			$version      = is_array( $asset ) && isset( $asset['version'] ) ? $asset['version'] : $version;
			$dependencies = is_array( $asset ) && isset( $asset['dependencies'] ) ? $asset['dependencies'] : $dependencies;
		}

		wp_register_style(
			'wwp-po-checkout',
			WWP_PLUGIN_URL . 'public/css/purchase-order-checkout.css',
			array(),
			WWP_VERSION
		);
		wp_enqueue_style( 'wwp-po-checkout' );

		wp_register_script(
			'wwp-purchase-order-payment',
			WWP_PLUGIN_URL . 'build/purchase-order-gateway/index.js',
			$dependencies,
			$version,
			true
		);

		return array( 'wwp-purchase-order-payment' );
	}

	/**
	 * Data passed to the payment method frontend script.
	 *
	 * @return array
	 */
	public function get_payment_method_data() {
		$po               = PurchaseOrderGatewayService::get_po_settings_for_user();
		$payment_gateways = WC()->payment_gateways()->payment_gateways();
		$supports         = array( 'products' );

		if ( isset( $payment_gateways[ $this->name ] ) && ! empty( $payment_gateways[ $this->name ]->supports ) ) {
			$supports = $payment_gateways[ $this->name ]->supports;
		}

		$file_types = isset( $po['file_types'] ) && is_array( $po['file_types'] ) ? $po['file_types'] : array();

		return array(
			'title'              => isset( $this->settings['title'] ) ? $this->settings['title'] : __( 'Purchase Order', 'woocommerce-wholesale-pricing' ),
			'description'        => isset( $this->settings['description'] ) ? $this->settings['description'] : '',
			'requireNumber'      => ! empty( $po['require_number'] ),
			'allowUpload'        => ! empty( $po['allow_upload'] ),
			'requireUpload'      => ! empty( $po['require_upload'] ),
			'fileTypes'          => $file_types,
			'maxFileSize'        => isset( $po['max_file_size'] ) ? absint( $po['max_file_size'] ) : 5,
			'uploadUrl'          => esc_url_raw( rest_url( 'wwp/v1/po-document' ) ),
			'uploadNonce'        => wp_create_nonce( 'wp_rest' ),
			'supports'           => $supports,
			'labelNumber'        => __( 'PO number', 'woocommerce-wholesale-pricing' ),
			'labelDocument'      => __( 'PO document', 'woocommerce-wholesale-pricing' ),
			'labelRequired'      => __( 'required', 'woocommerce-wholesale-pricing' ),
			'helpFileTypes'      => sprintf(
				/* translators: 1: allowed extensions, 2: max size in MB */
				__( 'Allowed types: %1$s. Max size: %2$d MB per file.', 'woocommerce-wholesale-pricing' ),
				'.' . implode( ', .', $file_types ),
				isset( $po['max_file_size'] ) ? absint( $po['max_file_size'] ) : 5
			),
			'errorNumber'        => __( 'Please enter a purchase order number.', 'woocommerce-wholesale-pricing' ),
			'errorDocument'     => __( 'Please attach a purchase order document.', 'woocommerce-wholesale-pricing' ),
			'errorFileType'     => __( 'This file type is not allowed.', 'woocommerce-wholesale-pricing' ),
			'errorFileSize'     => __( 'The document is too large.', 'woocommerce-wholesale-pricing' ),
			'errorUpload'        => __( 'The document could not be uploaded. Please try again.', 'woocommerce-wholesale-pricing' ),
		);
	}
}
