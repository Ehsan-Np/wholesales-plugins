<?php
/**
 * Compatibility Class for WooCommerce Product Add-ons.
 *
 * This class applies wholesale pricing rules to products that utilize the
 * WooCommerce Product Add-ons extension, handling price modifications for
 * both the base product and the add-on options themselves.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Compatibility
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Compatibility;

use WooCommerceWholesalePricing\App\Strategies\Hookable;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\IsWholesale;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\ModifyPrice;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\VariableWholesalePrice;

/**
 * ProductAddons Class.
 *
 * Implements compatibility fixes and logic for Product Add-ons.
 */
class ProductAddons implements Hookable {


	/**
	 * Trait for checking if a product has wholesale pricing applied
	 * 
	 *Trait For Applying the core wholesale discount logic (percentage/fixed).
	 * 
	 * Trait for retrieving wholesale prices for variable products
	 */
	use IsWholesale;
	use ModifyPrice;
	use VariableWholesalePrice;

	/**
	 * Register the necessary WordPress hooks/filters.
	 *
	 * @return void
	 */
	public function hooks() {
		// Filter the final cart item price to include wholesale product base price and addon prices.
		add_filter('wwp_override_product_price_cart_price', array( $this, 'wwp_override_product_price_cart_price' ), 10, 2); 
		
		// Filter quantity input arguments to enforce minimum wholesale quantity if applicable.
		add_filter('woocommerce_quantity_input_args', array( $this, 'wwp_quantity_input_args' ), 10, 2);

		// Add product's regular price to cart item session data before wholesale calc.
		add_filter('woocommerce_get_cart_item_from_session', array( $this, 'get_cart_item_from_session' ), 20, 2);

		// Check if the setting to apply discounts on add-on costs is enabled.
		/**
		 * Filter 
		 * 
		 * @var bool value
		 * 
		 * @since 1.8.0
		 */
		if (apply_filters('wpp_apply_discount_on_product_addon', false) ) {
			// Apply discount to the add-on option price displayed on the product page.
			add_filter('woocommerce_product_addons_option_price_raw', array( $this, 'wwp_woo_product_addons' ), 50, 2);
			// Apply discount to the add-on price when adding to cart.
			add_filter('woocommerce_add_cart_item_data', array( $this, 'wwp_product_add_cart_item_data' ), 50, 2);
		}
	}

	/**
	 * Override the final product price in the cart item to correctly include
	 * the product add-on prices after wholesale price is applied to the base product.
	 *
	 * @param  float $price The product price after base wholesale discount.
	 * @param  array $item  The cart item array.
	 * @return float The adjusted price including add-ons.
	 */
	public function wwp_override_product_price_cart_price( $price, $item ) {
			
		if (class_exists('WC_Product_Addons_Cart') && ! empty($item['addons']) ) {
			$quantity = $item['quantity'];

			foreach ( $item['addons'] as $addon ) {
				$price_type  = $addon['price_type'];
				$addon_price = $addon['price'];
				
				switch ( $price_type ) {
					case 'percentage_based':
						$price += (float) ( $price * ( $addon_price / 100 ) );
						break;
					case 'flat_fee':
						$price += (float) ( $addon_price / $quantity );
						break;
					default:
						$price += (float) $addon_price;
						break;
				}
			}
		}
			
		return $price;
	}

	/**
	 * Modifies the quantity input field arguments to enforce wholesale minimum quantity.
	 *
	 * Only applies if the current user is a wholesaler, the product is wholesale enabled,
	 * and the function is run on a non-cart/non-checkout page (i.e., product page).
	 *
	 * @param  array       $args    The quantity input field arguments.
	 * @param  \WC_Product $product The product object.
	 * @return array The filtered quantity input arguments.
	 */
	public function wwp_quantity_input_args( $args, $product ) {
		if (class_exists('WC_Product_Addons') ) {
			if (! ( is_cart() || is_product() ) ) {
				return $args;
			}
			if (is_cart() || is_checkout() ) {
				return $args;
			}
			if (! is_wholesaler_user(wp_get_current_user()->ID) ) {
				return $args;
			}
			$product_id = $product->is_type('variation') ? $product->get_parent_id() : $product->get_id();
			if (! $this->is_wholesale($product_id) ) {
				return $args;
			}
			$args['input_value'] = is_wholesale_product_quantity($product_id);
		}
		return $args;
	}

	/**
	 * Hook into cart session loading to store the product's regular price.
	 *
	 * This ensures that the original price is available for later add-on
	 * price calculations, particularly for percentage-based add-ons.
	 *
	 * @param  array $cart_item The cart item array.
	 * @param  array $values    The cart item session values.
	 * @return array The filtered cart item array.
	 */
	public function get_cart_item_from_session( $cart_item, $values ) {
		if (! empty($values['addons']) ) {
			$variation_id =  $cart_item['variation_id'];
			if (0 != $variation_id ) {
				$product = wc_get_product($cart_item['variation_id']);
			} else {
				$product = wc_get_product($cart_item['product_id']);
			}
			$cart_item['addons_price_before_calc'] = $product->get_regular_price();
		}
		return $cart_item;
	}

	/**
	 * Applies the wholesale discount to the raw price of a Product Add-on option.
	 *
	 * This runs only if the `wpp_apply_discount_on_product_addon` filter is enabled.
	 * It checks for both simple and variable product wholesale data.
	 *
	 * @param  float $price The original raw price of the add-on option.
	 * @param  array $addon The add-on option data.
	 * @return float The discounted add-on price, or the original price if no discount applies.
	 */
	public function wwp_woo_product_addons( $price, $addon ) {

		global $product;
		if (! $product ) {
			return $price;
		}
		$role              = get_current_user_role_id();
		$product_id = $product->get_id();
		$pr = (int) $addon['price'];
		if (empty($pr) ) {
			return $price;
		}
		$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
		if (isset($data[ $role ]) && 'product' == get_post_type($product_id) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {

			$my = $data[ $role ];
			if (isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
				$wholesale_qty = $my['min_quatity'];
			}


			/**
			 * Filter the raw price of a product add-on option before the discount is applied.
			 * Currently using a Mix and Match filter name, which might be a code structure issue,
			 * but is maintained here per original code.
			 *
			 * @since 3.0
			 * @param float $pr      The raw price of the add-on option.
			 * @param \WC_Product $product The product object.
			 */
			$price = apply_filters('wwp_mnm_get_price', $pr, $product);

			return $this->change_price($price, $my['discount_type'], $my['wholesale_price'], $product_id);
		} elseif ('product_variation' == get_post_type($product_id) ) {

			$variation_id = $product_id;
			$product_id   = wp_get_post_parent_id($product_id);

			$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
			if (isset($data[ $role ]) ) {
				if (isset($data[ $role ][ $variation_id ]['wholesaleprice']) && !empty($data[ $role ][ $variation_id ]['wholesaleprice']) ) {
					$my = $data[ $role ][ $variation_id ];
					if (isset($my['qty']) && ! empty($my['qty']) ) {
						$wholesale_qty = $my['qty'];
					}
					$price = $this->get_variable_wholesale_price($data[ $role ][ $variation_id ], $variation_id);
					return $price;
				} else {
					return $price;
				}
			} else {
				$wc_get_product               = wc_get_product($variation_id);
				$wwp_variation_explode_eneble = get_post_meta($wc_get_product->get_parent_id(), 'wwp_variation_explode_eneble', true);
				if ('yes' == $wwp_variation_explode_eneble ) {
					$price = wwp_get_price_including_tax($wc_get_product, array( 'price' => $price ));
				}
			}
		}
		return $price;
	}

	/**
	 * Applies the wholesale discount to the add-on price when the product is added to the cart.
	 *
	 * This runs only if the `wpp_apply_discount_on_product_addon` filter is enabled.
	 *
	 * @param  array $cart_item_data The cart item data array.
	 * @param  int   $product_id     The ID of the product being added.
	 * @return array The filtered cart item data with discounted add-on prices.
	 */
	public function wwp_product_add_cart_item_data( $cart_item_data, $product_id ) {
		if (! class_exists('WC_Product_Addons_Helper') ) {
			return $cart_item_data;
		}
		$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
		$role              = get_current_user_role_id();
		if (isset($data[ $role ]) ) {
			$my = $data[$role];
			if (isset($my['discount_type']) && isset($my['wholesale_price'])) {
				foreach ($cart_item_data['addons'] as $key => $value) {
					$price = $this->change_price($cart_item_data['addons'][$key]['price'], $my['discount_type'], $my['wholesale_price'], $product_id);
					$cart_item_data['addons'][$key]['price'] = $price;
				}
			}
		}

		return $cart_item_data;
	}
}
