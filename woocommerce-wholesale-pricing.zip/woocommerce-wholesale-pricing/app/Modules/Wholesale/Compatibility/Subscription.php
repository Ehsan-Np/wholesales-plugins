<?php
/**
 * Trait Subscription.
 *
 * Provides logic for calculating and displaying wholesale prices for
 * WooCommerce Subscriptions products (simple and variable) by checking
 * discounts at the product, category, and global levels.
 *
 * This trait is intended to be used in a class that handles compatibility
 * with the WooCommerce Subscriptions extension.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Compatibility
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Compatibility;

trait Subscription {


	/**
	 * Filters the subscription price string to display the wholesale price.
	 *
	 * This method applies the wholesale discount based on a hierarchy:
	 * 1. Product Group (Tiered)
	 * 2. Product Level (Tiered)
	 * 3. Product Level (General)
	 * 4. Category Level (Tiered)
	 * 5. Category Level (General)
	 * 6. Global Level (Tiered)
	 * 7. Global Level (General)
	 *
	 * It handles array-based and object-based product inputs, and accounts for
	 * guest wholesale pricing settings.
	 *
	 * @param  string            $subscription_string The original subscription price HTML string.
	 * @param  array|\WC_Product $product             The product or product array data.
	 * @param  bool              $include             Whether to include the recurring amount (unused in this logic).
	 * @return string The modified subscription price HTML string, or the original if no discount is applied.
	 */
	public function woocommerce_subscriptions_product( $subscription_string, $product, $include ) {
		if (is_array($product) ) {
			$post_id = $product['product_id'];
			$product = wc_get_product($post_id);
		}

		if ($product->is_type('variable-subscription') ) {
			return $subscription_string;
		}
		$post_id = $product->get_id();
		$role = get_current_user_role_id();
		if (wwp_guest_wholesale_pricing_enabled() ) {
			if (( is_shop() && ! wwp_guest_wholesale_pricing_enabled('display_on_shop') ) || ( is_product() && ! wwp_guest_wholesale_pricing_enabled('display_on_single') ) ) {
				return $subscription_string;
			}
			$role = wwp_guest_wholesale_pricing_enabled('role');
		}

		if (wwp_get_group_post_by_proid($product->get_id(), get_current_user_id()) ) {
			$this->tier_table = true;
			return tire_simple_subsc_wholesale_product_price_html($product->get_id(), $product, 'group');
		}

		$data = get_post_meta($post_id, 'wholesale_multi_user_pricing', true);
		if (isset($data[ $role ]) ) {
			if (tire_simple_subsc_wholesale_product_price_html($product->get_id(), $product, 'product') ) {
				$this->tier_table = true;
				return tire_simple_subsc_wholesale_product_price_html($product->get_id(), $product, 'product');
			}
		}

		if (isset($data[ $role ]) ) {
			$my = $data[ $role ];
			if (isset($my['discount_type']) && ! empty($my['discount_type']) && isset($my['wholesale_price']) && ! empty($my['wholesale_price']) && isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
				
				return simple_subsc_wholesale_product_price_html($my['discount_type'], $my['wholesale_price'], $my['min_quatity'], $product);
			} else {
				return $subscription_string;
			}
		}
		
		if (tire_simple_subsc_wholesale_product_price_html($product->get_id(), $product, 'category') ) {
			$this->tier_table = true;
			return tire_simple_subsc_wholesale_product_price_html($product->get_id(), $product, 'category');
		}

		$terms = get_the_terms($post_id, 'product_cat');
		if (! is_wp_error($terms) && ! empty($terms) ) {
			foreach ( $terms as $term ) {
				$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
				if (isset($data[ $role ]) ) {
					$my = $data[ $role ];
					if (isset($my['discount_type']) && ! empty($my['discount_type']) && isset($my['wholesale_price']) && ! empty($my['wholesale_price']) && isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
						return simple_subsc_wholesale_product_price_html($my['discount_type'], $my['wholesale_price'], $my['min_quatity'], $product);
					} else {
						return $subscription_string;
					}
				}
			}
		}

		$data = get_option('wholesale_multi_user_pricing');

		if (isset($data[ $role ]) ) {
			if (tire_simple_subsc_wholesale_product_price_html($product->get_id(), $product, 'global') ) {
				$this->tier_table = true;
				return tire_simple_subsc_wholesale_product_price_html($product->get_id(), $product, 'global');
			}
		}
		if (isset($data[ $role ]) ) {
			$my = $data[ $role ];
			if (isset($my['discount_type']) && ! empty($my['discount_type']) && isset($my['wholesale_price']) && ! empty($my['wholesale_price']) && isset($my['min_quatity']) && ! empty($my['min_quatity']) ) {
				return simple_subsc_wholesale_product_price_html($my['discount_type'], $my['wholesale_price'], $my['min_quatity'], $product);
			} else {
				return $subscription_string;
			}
		}

		return $subscription_string;
	}
}
