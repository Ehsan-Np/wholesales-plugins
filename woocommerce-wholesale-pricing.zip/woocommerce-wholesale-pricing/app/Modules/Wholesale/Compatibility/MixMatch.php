<?php
/**
 * Compatibility Class for WooCommerce Mix and Match Products.
 *
 * This class ensures that wholesale pricing logic correctly interacts with
 * Mix and Match product types by modifying price retrieval filters.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Wholesale\Compatibility
 */
namespace WooCommerceWholesalePricing\App\Modules\Wholesale\Compatibility;

use WooCommerceWholesalePricing\App\Strategies\Hookable;
use WooCommerceWholesalePricing\App\Modules\Wholesale\Traits\RegularPriceChange;

/**
 * MixMatch Class.
 *
 * Implements compatibility fixes for Mix and Match products (mnm).
 */
class MixMatch implements Hookable {


	/**
	 * Includes the trait containing logic for modifying regular prices to wholesale prices.
	 */
	use RegularPriceChange;

	/**
	 * Register the necessary WordPress hooks/filters.
	 *
	 * @return void
	 */
	public function hooks() {
		add_filter('mnm_get_price', array( $this, 'mnm_get_price' ), 10, 2);
		add_filter('wwp_mnm_get_price', array( $this, 'wwp_mnm_get_price' ), 10, 2);
		add_filter('wwp_mnm_get_price_qty', array( $this, 'wwp_mnm_get_price_qty' ), 10, 2);
	}

	/**
	 * Filters the raw Mix and Match product price before it is calculated.
	 *
	 * This uses the trait method to apply wholesale price modification logic.
	 *
	 * @param  float|\string $value    The raw product price.
	 * @param  \WC_Product   $instance The product instance.
	 * @return float|\string The modified price after wholesale rules are applied.
	 */
	public function mnm_get_price( $value, $instance ) {
		return $this->wwp_regular_price_change($value, $instance);
	}

	/**
	 * Filter to disable quantity price calculation logic for Mix and Match products.
	 *
	 * Returns false if the product is of type 'mix-and-match', otherwise returns the value.
	 *
	 * @param  bool        $value   The original boolean value (usually true).
	 * @param  \WC_Product $product The product object.
	 * @return bool False if it's a Mix and Match product, otherwise original value.
	 */
	public function wwp_mnm_get_price_qty( $value, $product ) {
		return ( 'mix-and-match' == $product->get_type() ) ? false : $value;
	}

	/**
	 * Get the original, uncalculated price for a Mix and Match product.
	 *
	 * This ensures wholesale calculations start from the correct base price,
	 * often stored as '_min_raw_regular_price' post meta for MNM bundles.
	 *
	 * @param  float|\string $price   The current price being filtered.
	 * @param  \WC_Product   $product The product object.
	 * @return float|\string The raw regular price from post meta if it's a Mix and Match product, otherwise original price.
	 */
	public function wwp_mnm_get_price( $price, $product ) {
		return ( 'mix-and-match' == $product->get_type() ) ? get_post_meta($product->get_id(), '_min_raw_regular_price', true) : $price;
	}
}
