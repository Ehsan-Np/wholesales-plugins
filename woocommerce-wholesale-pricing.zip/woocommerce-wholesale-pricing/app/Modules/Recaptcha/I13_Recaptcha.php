<?php

use WooCommerceWholesalePricing\App\Strategies\Recaptcha;
/**
 * I13 reCaptcha Class
 * 
 * This class integrates reCaptcha (v2 and v3) into the WooCommerce Wholesale Pricing plugin
 * for verifying user actions on the wholesale registration and login forms.
 *
 * @package    WooCommerceWholesalePricing\App\Modules\Recaptcha
 * @since      2.4.0
 */
class I13_Recaptcha extends Recaptcha {


	/**
	 * Recaptcha settings.
	 *
	 * This array holds the settings for the reCaptcha integration, including keys, version, and error messages.
	 *
	 * @var array
	 */
	private $settings = array();
	 
	/**
	 * Constructor Method
	 *
	 * Initializes the reCaptcha settings and hooks necessary actions and filters.
	 *
	 * @param array $settings The reCaptcha settings array passed from the plugin configuration.
	 * 
	 * @return void
	 */
	public function __construct( $settings ) {

		$this->settings = $settings;
		 
		if ('yes' == $this->settings['enable'] ) {
			add_action('wwp_wholesaler_registration_form_fields_end', array( $this, 'add_recaptcha' ));
			add_filter('wwp_process_registration_form', array( $this, 'verify_recaptcha' ), 10, 2);
		}

		add_filter('pre_option_i13_recapcha_enable_on_login', array( $this, 'i13_woo_recaptcha_tweaks' ), 999, 2);

		add_filter('woocommerce_get_sections_i13_woo_recaptcha', array( $this, 'wwp_register_tab_i13_woo' ));
		add_filter('woocommerce_get_settings_i13_woo_recaptcha', array( $this, 'wwp_recaptcha_setting_i13_woo' ), 10, 2);
	}
	 
	/**
	 * Add reCaptcha to the wholesale registration form
	 *
	 * Displays the reCaptcha widget on the registration form.
	 *
	 * @return void
	 */
	public function add_recaptcha() {

		$i13_recaptcha = new \I13_Woo_Recpatcha();
		echo $i13_recaptcha->add_woo_recaptcha_to_custom_form('', array()); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Verify reCaptcha response on form submission
	 *
	 * Handles the verification of the reCaptcha response on the registration and login forms.
	 *
	 * @param array $errors  The array of errors to be passed back if any validation fails.
	 * @param array $request The form submission data, including the reCaptcha response.
	 * 
	 * @return array The modified errors array after reCaptcha verification.
	 */
	public function verify_recaptcha( array $errors, array $request ) {
		if ('v2' == $this->settings['version'] ) {
			$grecaptcha_v2_site_key   = esc_attr($this->settings['v2_site_key']);
			$grecaptcha_v2_secret_key = esc_attr($this->settings['v2_secret_key']);

			if (empty($grecaptcha_v2_site_key) || empty($grecaptcha_v2_secret_key) ) {
				$errors['invalid_keys'] = esc_html__('Google reCaptcha keys not found.', 'woocommerce-wholesale-pricing');
			}

			if (isset($request['g-recaptcha-response']) && ! empty($request['g-recaptcha-response']) ) {
				$response = wp_remote_post(
					'https://www.google.com/recaptcha/api/siteverify',
					array(
					'body' => array(
					'secret'   => $grecaptcha_v2_secret_key,
					'response' => sanitize_text_field($request['g-recaptcha-response']),
					),
					)
				);

				$data = wp_remote_retrieve_body($response);
				$data = ( array ) json_decode($data);

				if (isset($data['error-codes']) && is_array($data['error-codes']) && count($data['error-codes']) ) {
					foreach ( $data['error-codes'] as $index => $error_code ) {
						$errors[$index] = $error_code;
					}
				}

				if (isset($data['success']) && true === $data['success'] ) {
					return $errors;
				}
			} else {
				$errors['invalid_captcha'] = empty($this->settings['error_message']) ? wp_kses(__('<strong>ERROR:</strong> Please confirm that you are not a robot.', 'woocommerce-wholesale-pricing'), array( 'strong' => array() )) : $this->settings['error_message'];
			}


		} else if ('v3' == $this->settings['version'] ) {
			$grecaptcha_v3_site_key   = esc_attr($this->settings['v3_site_key']);
			$grecaptcha_v3_secret_key = esc_attr($this->settings['v3_secret_key']);
			$grecaptcha_v3_score      = '0.3';

			if (empty($grecaptcha_v3_site_key) || empty($grecaptcha_v3_secret_key) ) {
				$errors['invalid_keys'] = esc_html__('Google reCaptcha keys not found.', 'woocommerce-wholesale-pricing');
			}

			if (isset($request['i13_recaptcha_login_token']) && ! empty($request['i13_recaptcha_login_token']) ) {
				$response = wp_remote_post(
					'https://www.google.com/recaptcha/api/siteverify',
					array(
					'body' => array(
					'secret'   => $grecaptcha_v3_secret_key,
					'response' => sanitize_text_field($request['i13_recaptcha_login_token']),
					'remoteip' => $this->get_ip_address(),
					),
					)
				);

				$data = wp_remote_retrieve_body($response);
				$data = ( array ) json_decode($data);

				if (isset($data['error-codes']) && is_array($data['error-codes']) && count($data['error-codes']) ) {
					foreach ( $data['error-codes'] as $index => $error_code ) {
						$errors[$index] = $error_code;
					}
				}

				if (isset($data['success']) && true === $data['success'] ) {
					$grecaptcha_v3_score = (float) $grecaptcha_v3_score;
					if (isset($data['action']) && ( 'login' === $data['action'] ) && isset($data['score']) && $data['score'] >= $grecaptcha_v3_score ) {
						return $errors;
					} else {
						$errors[] = wp_kses(__('<strong>ERROR:</strong> Low Score ', 'woocommerce-wholesale-pricing') . ':' . esc_html($data->score), array( 'strong' => array() ));
					}
				}
			} else {
				$errors['invalid_captcha'] = empty($this->settings['error_message']) ? wp_kses(__('<strong>ERROR:</strong> Please confirm that you are not a robot.', 'woocommerce-wholesale-pricing'), array( 'strong' => array() )) : $this->settings['error_message'];
			}
		}
		return $errors;
	}

	/**
	 * Apply reCaptcha tweaks for the login option
	 *
	 * This method modifies the value of the `i13_recapcha_enable_on_login` option.
	 *
	 * @param string $value       The current value of the option.
	 * @param string $option_name The name of the option.
	 * 
	 * @return string The modified option value.
	 */
	public function i13_woo_recaptcha_tweaks( $value, $option_name ) {
		if ('i13_recapcha_enable_on_login' === $option_name ) {
			return 'yes';
		}

		return $value;
	}

	/**
	 * Register a custom tab for reCaptcha settings in the WooCommerce settings
	 *
	 * Adds a new tab for configuring the reCaptcha settings on the Wholesale Registration form.
	 *
	 * @param array $sections The existing WooCommerce settings sections.
	 * 
	 * @return array The modified settings sections.
	 */
	public function wwp_register_tab_i13_woo( $sections ) {
		$sections['wwp_wholesale_recaptcha_woo'] = __('Wholesale Registration Form', 'woocommerce-wholesale-pricing');
		return $sections;
	}

	/**
	 * Add reCaptcha settings to WooCommerce settings
	 *
	 * This method adds the reCaptcha configuration options for the wholesale registration form.
	 *
	 * @param array  $settings        The current WooCommerce settings.
	 * @param string $current_section The current section in the WooCommerce settings.
	 * 
	 * @return array The updated settings array.
	 */
	public function wwp_recaptcha_setting_i13_woo( $settings, $current_section ) {
		if ('wwp_wholesale_recaptcha_woo' == $current_section && class_exists('I13_Woo_Recpatcha') ) {
			/**
			*  Filter: filter recaptcha settings 
			*          
			*  @since 2.4.0 
			*/
			$settings = apply_filters(
				'i13_woo_wholesale_recaptcha_settings', array(
				'section_title_recpacha_on_woo_wholesale' => array(
				'name' => __('Recaptcha on Wholesale Registration Form', 'woocommerce-wholesale-pricing'),
				'type' => 'title',
				'desc' => '',
				'id' => 'wwp_settings_tab_recapcha_woo_wholesale',
				),
				'wwp_recapcha_enable_on_woo_wholesale' => array(
				'name' => __('Enable Recaptcha on Wholesale Registration Form', 'woocommerce-wholesale-pricing'),
				'type' => 'checkbox',
				'id' => 'wwp_recapcha_enable_on_woo_wholesale',
				), 
				array(
				'type' => 'sectionend',
				'id' => 'wwp_settings_tab_recapcha_woo_wholesale',
				),
				)
			);
		}
		return $settings;
	}
}
