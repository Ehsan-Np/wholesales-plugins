<?php
/**
 * C4WP reCAPTCHA Integration for Wholesale Registration
 *
 * This file defines the C4WP_Recaptcha class, which extends the base Recaptcha strategy.
 * It adds Google reCAPTCHA functionality to the Wholesale Registration form within 
 * WooCommerce Wholesale Pricing plugin.
 *
 * @package    WooCommerceWholesalePricing\App\Modules\Recaptcha
 * @since      2.4.0
 */
use WooCommerceWholesalePricing\App\Strategies\Recaptcha;


if (! defined('ABSPATH') ) {
	exit; // Exit if accessed directly
}

/**
 * Class C4WP_Recaptcha
 *
 * Extends the base Recaptcha strategy to integrate reCAPTCHA (v2 Checkbox)
 * into the Wholesale Registration form. Handles rendering the reCAPTCHA field,
 * validating user input, and registering relevant settings.
 *
 * @since 2.4.0
 */
class C4WP_Recaptcha extends Recaptcha {

	 
	/**
	 * Plugin settings array.
	 *
	 * @var array
	 */
	private $settings = array();
	 
	/**
	 * Constructor
	 *
	 * Initializes reCAPTCHA integration by hooking into relevant
	 * actions and filters if enabled in settings.
	 *
	 * @param array $settings Plugin settings array.
	 */
	public function __construct( $settings ) {

		$this->settings = $settings;
		if (isset($this->settings['enabled_forms']) && in_array('wwp_wholesale_recaptcha', $this->settings['enabled_forms']) ) {
			add_action('wwp_wholesaler_registration_form_fields_end', array( $this, 'add_recaptcha' ));
			add_filter('wwp_process_registration_form', array( $this, 'verify_recaptcha' ), 10, 2);
		}

		add_filter('c4wp_settings_fields', array( $this, 'wwp_wholesale_recaptcha' ));
	}
	 
	/**
	 * Outputs the reCAPTCHA field on the registration form.
	 *
	 * Only renders the field if CAPTCHA version is v2 checkbox.
	 *
	 * @return void
	 */
	public function add_recaptcha() {
		if (isset($this->settings['captcha_version']) && 'v2_checkbox' == $this->settings['captcha_version'] ) {
			$this->display_recaptcha_v2();
		}
	}
	 
	/**
	 * Renders the reCAPTCHA v2 checkbox field.
	 *
	 * Validates presence of site and secret keys before rendering.
	 *
	 * @return void
	 */
	public function display_recaptcha_v2() {
		if (isset($this->settings['site_key'], $this->settings['secret_key']) && ! empty($this->settings['site_key']) && ! empty($this->settings['secret_key']) ) {

			if (defined('C4WP_PLUGIN_DIR') && class_exists('C4WP\C4WP_Functions') ) {
				include_once C4WP_PLUGIN_DIR . 'includes/class-c4wp-functions.php';
				\C4WP\C4WP_Functions::c4wp_captcha_form_field(true); 
			}
		}
	}
	 
	/**
	 * Verifies the submitted reCAPTCHA response.
	 *
	 * If verification fails, appends error messages to the errors array.
	 *
	 * @param  array $errors  Current form errors.
	 * @param  array $request Submitted form data.
	 * @return array Modified errors array.
	 */
	public function verify_recaptcha( array $errors, array $request ) {
	 
		if (isset($this->settings['captcha_version']) && 'v2_checkbox' == $this->settings['captcha_version'] ) {

			if (empty($this->settings['site_key']) || empty($this->settings['secret_key']) ) {
				$errors['invalid_keys'] = esc_html__('Google reCaptcha keys not found.', 'woocommerce-wholesale-pricing');
			}
			/**
			 * Hooks: filter recaptcha error message
			 * 
			 * @since 2.4.0
			 */
			$notice_recaptcha = apply_filters('wwp_recaptcha_error_msg', isset($this->settings['error_message']) ? $this->settings['error_message'] : esc_html__('Robot verification failed, please try again.', 'woocommerce-wholesale-pricing'));   

			if (isset($request['g-recaptcha-response']) ) {              
				if (function_exists('anr_verify_captcha') ) {
					if (! anr_verify_captcha() ) {
						$errors['invalid_captcha'] = $notice_recaptcha;
					}
				}
			}

		}

		return $errors;
	}

	/**
	 * Adds the wholesale registration form to enabled reCAPTCHA settings.
	 *
	 * @param  array $fields Settings fields array.
	 * @return array Modified settings fields array.
	 */
	public function wwp_wholesale_recaptcha( $fields ) {
		$fields['enabled_forms']['options'] = array_merge( 
			$fields['enabled_forms']['options'], 
			array( 'wwp_wholesale_recaptcha' => 'Wholesale Registration Form' ) 
		);

		return $fields;
	}
}
