<?php
/**
 * Gutenberg Payment Gateway Integration
 *
 * This class handles the registration and configuration of custom payment methods
 * for WooCommerce Blocks when used with the WooCommerce Wholesale Pricing plugin.
 * It dynamically checks the availability and settings of the selected payment gateway
 * and registers the necessary frontend scripts.
 *
 * @package WooCommerceWholesalePricing\App\Modules\GutenbergBlock
 * @version 2.3.0
 */
namespace WooCommerceWholesalePricing\App\Modules\GutenbergBlock;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * Class PaymentGateway
 *
 * Integrates custom wholesale-specific payment gateways with WooCommerce Blocks.
 * Loads settings from the corresponding gateway, checks availability, and
 * registers necessary JavaScript for block-based checkout.
 */
class PaymentGateway extends AbstractPaymentMethodType {

	/**
	 * Name of the payment method (slug).
	 *
	 * @var string
	 */
	protected $name = '';
	 
	/**
	 * Array of settings.
	 *
	 * @var array
	 */
	protected $settings = array();

	/**
	 * Constructor
	 *
	 * @param string $payment_method_name Human-readable name of the payment method.
	 */
	public function __construct( $payment_method_name ) {
		$this->name = strtolower(str_replace(' ', '_', $payment_method_name));
	}

	/**
	 * Initializes the payment method type.
	 *
	 * Loads gateway settings from WooCommerce options.
	 *
	 * @return void
	 */
	public function initialize() {
		$payment_gateways_class = WC()->payment_gateways();
		$payment_gateways       = $payment_gateways_class->payment_gateways();
		$this->settings                = get_option(
			'woocommerce_' . $this->name . '_settings', array(
			'title'         => isset($payment_gateways[$this->name]) ? $payment_gateways[$this->name]->settings['title'] : '',
			'description'   => isset($payment_gateways[$this->name]) ? $payment_gateways[$this->name]->settings['description'] : '',
			) 
		);
	}

	/**
	 * Returns if this payment method should be active. If false, the scripts will not be enqueued.
	 *
	 * @return boolean
	 */
	public function is_active() {
		$payment_gateways_class = WC()->payment_gateways();
		$payment_gateways       = $payment_gateways_class->payment_gateways();
		if (isset($payment_gateways[$this->name]) ) {
			return $payment_gateways[$this->name]->is_available();
		}
		return false;
	}

	/**
	 * Registers payment method JavaScript and returns script handles.
	 *
	 * @return string[] Array of script handles to enqueue.
	 */
	public function get_payment_method_script_handles() {
		$asset_path   = WWP_PLUGIN_PATH . '/build/payment-gateway/wwp-payment-gateway.asset.php';
		$version      = '2.3.0';
		$dependencies = array();

		if (file_exists($asset_path) ) {
			$asset        = include $asset_path;
			$version      = is_array($asset) && isset($asset['version']) ? $asset['version'] : $version;
			$dependencies = is_array($asset) && isset($asset['dependencies']) ? $asset['dependencies'] : $dependencies;
		}

		wp_register_script(
			'wwp-payment',
			WWP_PLUGIN_URL . '/build/payment-gateway/wwp-payment-gateway.js',
			$dependencies,
			$version,
			true
		);

		return array( 'wwp-payment' );
	}

	/**
	 * Provides data to the frontend payment method JavaScript.
	 *
	 * @since  2.3.0
	 * @return array Array of gateway settings.
	 */
	public function get_payment_method_data() {
		return $this->settings;
	}
}
