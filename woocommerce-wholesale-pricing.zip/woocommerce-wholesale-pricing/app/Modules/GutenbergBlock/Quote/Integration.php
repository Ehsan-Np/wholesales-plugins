<?php
/**
 * Gutenberg Block Integration
 *
 * This file initializes the integration between WooCommerce Wholesale Pricing
 * and WooCommerce Blocks. It conditionally registers custom Gutenberg cart blocks
 * (e.g., requisition list) and wholesale-specific payment gateways based on plugin settings
 * and user roles.
 *
 * @package WooCommerceWholesalePricing\App\Modules\GutenbergBlock
 */
namespace WooCommerceWholesalePricing\App\Modules\GutenbergBlock\Quote;

use WooCommerceWholesalePricing\App\Modules\GutenbergBlock\Quote\Handler;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;


/**
 * Class Integration
 *
 * Handles the integration of custom Gutenberg blocks and payment gateways
 * for the WooCommerce Wholesale Pricing plugin.
 * Registers custom cart blocks and payment methods conditionally based on
 * plugin settings and user role.
 */
class Integration {

	use WholesaleSettings;

	/**
	 * Initialize the integration for Gutenberg blocks and payment methods.
	 *
	 * This method:
	 * - Ensures WooCommerce Blocks is loaded.
	 * - Conditionally registers a custom cart block (requisition list).
	 * - Conditionally registers custom payment methods for wholesale users.
	 *
	 * @return void
	 */
	public static function init() {

		$settings = self::get_pricing_settings();

		if (! did_action('woocommerce_blocks_loaded') ) {
			return;
		}

		$quote_general       = get_option('wc_quote_general', array());
		$enable_build_quote  = isset($quote_general['enable_build_quote']) ? $quote_general['enable_build_quote'] : '0';
		$quote_feature_ready = isset($settings['enable_quote']) && 'yes' === $settings['enable_quote'] && '1' === $enable_build_quote;

		if ($quote_feature_ready) {
			add_action(
				'woocommerce_blocks_cart_block_registration',
				function ( $registry ) {
					$registry->register(Handler::instance());
				}
			);
		}
	}
}

Integration::init();
