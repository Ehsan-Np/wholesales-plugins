<?php

namespace WooCommerceWholesalePricing\App\Modules\GutenbergBlock\Quote;

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;



class Handler implements IntegrationInterface {



	/**

	 * The single instance of the class.
	 *
	 * @var Handler|null

	 */

	protected static $_instance = null;



	/**

	 * Whether the integration has been initialized.
	 *
	 * @var bool

	 */

	protected $is_initialized = false;



	/**

	 * Main Handler instance. Ensures only one instance of Handler is loaded or can be loaded.
	 *
	 * @static

	 * @return Handler

	 */

	public static function instance() {

		if (is_null(self::$_instance) ) {

			self::$_instance = new self();

		}

		return self::$_instance;
	}



	public function get_name() {

		return 'wc-quote-cart-block';
	}



	public function initialize() {

		if ($this->is_initialized) {

			return;

		}



		$block_json = WWP_PLUGIN_PATH . 'build/quote/cart-block/block.json';

		if (file_exists($block_json)) {

			register_block_type($block_json);

		}



		add_filter(

			'__experimental_woocommerce_blocks_add_data_attributes_to_block',

			function ( $blocks ) {

				$blocks[] = 'cart-block/build-quote';

				return $blocks;
			}

		);



		$this->register_block_front_scripts();

		$this->register_block_editor_scripts();

		$this->is_initialized = true;
	}



	public function get_script_handles() {

		return array( 'wc-quote-cart-frontend' );
	}



	public function get_editor_script_handles() {

		return array( 'wc-quote-cart-editor' );
	}



	public function get_script_data() {

		$general       = get_option('wc_quote_general', array());

		$customization = get_option('wc_quote_customization', array());



		$build_quote_text   = ! empty($customization['build_quote_text']) ? $customization['build_quote_text'] : 'Build Quote';

		$quote_page         = isset($general['quote_page']) ? esc_url(get_page_link($general['quote_page'])) : '';

		$enable_build_quote = isset($general['enable_build_quote']) ? $general['enable_build_quote'] : '0';



		return array(

			'quote_page'         => $quote_page,

			'enable_build_quote' => $enable_build_quote,

			'build_quote_text'   => $build_quote_text,

			'ajax_url'           => admin_url('admin-ajax.php'),

			'nonce'              => wp_create_nonce('wc-quote-ajax-nonce'),

		);
	}



	public function register_block_front_scripts() {

		$script_asset_path = WWP_PLUGIN_PATH . 'build/quote/cart-blocks/cart-block-frontend.asset.php';

		$script_path       = WWP_PLUGIN_URL . 'build/quote/cart-blocks/cart-block-frontend.js';

		$script_asset      = file_exists($script_asset_path) ? include $script_asset_path : array(

			'dependencies' => array(),

			'version'      => WWP_VERSION,

		);



		wp_register_script(

			'wc-quote-cart-frontend',

			$script_path,

			$script_asset['dependencies'],

			$script_asset['version'],

			true

		);
	}



	public function register_block_editor_scripts() {

		$script_asset_path = WWP_PLUGIN_PATH . 'build/quote/cart-blocks/index.asset.php';

		$script_path       = WWP_PLUGIN_URL . 'build/quote/cart-blocks/index.js';

		$script_asset      = file_exists($script_asset_path) ? include $script_asset_path : array(

			'dependencies' => array(),

			'version'      => WWP_VERSION,

		);



		wp_register_script(

			'wc-quote-cart-editor',

			$script_path,

			$script_asset['dependencies'],

			$script_asset['version'],

			true

		);
	}
}
