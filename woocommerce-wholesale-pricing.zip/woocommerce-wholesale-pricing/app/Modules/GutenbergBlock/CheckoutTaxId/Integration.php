<?php
/**
 * Checkout Tax ID block integration.
 *
 * @package WooCommerceWholesalePricing\App\Modules\GutenbergBlock\CheckoutTaxId
 */

namespace WooCommerceWholesalePricing\App\Modules\GutenbergBlock\CheckoutTaxId;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Services\FormBuilderService;

/**
 * Registers the checkout Tax ID block when enabled.
 */
class Integration {

	use WholesaleSettings;

	/**
	 * Bootstrap block registration and Store API hooks.
	 *
	 * @return void
	 */
	public static function init() {
		if ( did_action( 'woocommerce_blocks_loaded' ) ) {
			self::register();
			return;
		}

		add_action( 'woocommerce_blocks_loaded', array( __CLASS__, 'register' ) );
	}

	/**
	 * Register checkout block + Store API handlers when Tax ID checkout is enabled.
	 *
	 * @return void
	 */
	public static function register() {
		$registrations = self::get_registration_settings();
		if ( ! FormBuilderService::is_tax_id_checkout_enabled( $registrations ) ) {
			return;
		}

		add_action(
			'woocommerce_blocks_checkout_block_registration',
			static function ( $registry ) {
				$registry->register( Handler::instance() );
			}
		);

		self::register_store_api_extension();
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( __CLASS__, 'validate_and_save_from_request' ), 10, 2 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( __CLASS__, 'persist_tax_id_after_block_checkout' ), 10, 1 );
	}

	/**
	 * Register checkout extension schema so setExtensionData is accepted.
	 *
	 * @return void
	 */
	private static function register_store_api_extension() {
		if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
			return;
		}

		static $registered = false;
		if ( $registered ) {
			return;
		}
		$registered = true;

		woocommerce_store_api_register_endpoint_data(
			array(
				'endpoint'        => 'checkout',
				'namespace'       => 'woocommerce-wholesale-pricing',
				'schema_callback' => static function () {
					return array(
						'wwp_wholesaler_tax_id' => array(
							'description' => __( 'Tax ID', 'woocommerce-wholesale-pricing' ),
							'type'        => array( 'string', 'null' ),
							'context'     => array( 'view', 'edit' ),
							'readonly'    => false,
						),
					);
				},
				'schema_type'     => ARRAY_A,
			)
		);
	}

	/**
	 * Validate and persist Tax ID from block checkout request.
	 *
	 * @param \WC_Order        $order   Order being updated.
	 * @param \WP_REST_Request $request Request object.
	 * @return void
	 * @throws \Automattic\WooCommerce\StoreApi\Exceptions\RouteException On validation failure.
	 */
	public static function validate_and_save_from_request( $order, $request ) {
		$registrations = self::get_registration_settings();

		if ( ! FormBuilderService::is_tax_id_checkout_enabled( $registrations ) ) {
			return;
		}

		$country = $order->get_billing_country();

		// Billing country must match vat_countries (when configured); otherwise skip.
		if ( ! FormBuilderService::should_show_tax_id_for_country( $country, $registrations ) ) {
			return;
		}

		$extensions = $request->get_param( 'extensions' );
		$tax_id     = '';

		if ( is_array( $extensions ) && isset( $extensions['woocommerce-wholesale-pricing']['wwp_wholesaler_tax_id'] ) ) {
			$tax_id = sanitize_text_field( (string) $extensions['woocommerce-wholesale-pricing']['wwp_wholesaler_tax_id'] );
		}

		$result = FormBuilderService::validate_tax_id_value( $tax_id, $country, $registrations );

		if ( is_wp_error( $result ) ) {
			if ( class_exists( '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException' ) ) {
				throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException(
					esc_html( $result->get_error_code() ),
					esc_html( $result->get_error_message() ),
					400
				);
			}

			throw new \Exception( esc_html( $result->get_error_message() ) );
		}

		// Persist on the order now; also write user meta for the logged-in shopper
		// (order may not have a customer ID attached yet at this stage).
		$user_id = absint( $order->get_user_id() );
		if ( ! $user_id && is_user_logged_in() ) {
			$user_id = get_current_user_id();
		}

		FormBuilderService::save_tax_id_to_order( $order, $tax_id, $user_id );

		// Keep value available for the processed hook if customer ID is attached later.
		$order->update_meta_data( '_wwp_checkout_tax_id_pending', $tax_id );
		if ( method_exists( $order, 'save_meta_data' ) ) {
			$order->save_meta_data();
		}
	}

	/**
	 * Re-assert Tax ID on order + logged-in user after block checkout completes.
	 *
	 * @param \WC_Order $order Processed order.
	 * @return void
	 */
	public static function persist_tax_id_after_block_checkout( $order ) {
		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		$registrations = self::get_registration_settings();
		$country       = $order->get_billing_country();

		$pending = $order->get_meta( '_wwp_checkout_tax_id_pending', true );
		$tax_id  = $order->get_meta( 'wwp_wholesaler_tax_id', true );

		if ( '' === (string) $tax_id && '' !== (string) $pending ) {
			$tax_id = $pending;
		}

		$order->delete_meta_data( '_wwp_checkout_tax_id_pending' );

		if ( ! FormBuilderService::should_show_tax_id_for_country( $country, $registrations ) ) {
			if ( method_exists( $order, 'save_meta_data' ) ) {
				$order->save_meta_data();
			}
			return;
		}

		// Field was displayed for this country — persist to order and logged-in user.
		if ( '' !== (string) $tax_id || '' !== (string) $pending || $order->meta_exists( 'wwp_wholesaler_tax_id' ) ) {
			FormBuilderService::save_tax_id_to_order( $order, (string) $tax_id );
		} elseif ( method_exists( $order, 'save_meta_data' ) ) {
			$order->save_meta_data();
		}
	}
}

Integration::init();
