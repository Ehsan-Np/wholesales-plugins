<?php
/**
 * Checkout Tax ID Gutenberg block handler.
 *
 * @package WooCommerceWholesalePricing\App\Modules\GutenbergBlock\CheckoutTaxId
 */

namespace WooCommerceWholesalePricing\App\Modules\GutenbergBlock\CheckoutTaxId;

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Services\FormBuilderService;

/**
 * Integrates the Tax ID field with WooCommerce Checkout Blocks.
 */
class Handler implements IntegrationInterface {

	use WholesaleSettings;

	/**
	 * Whether the integration has been initialized.
	 *
	 * @var bool
	 */
	protected $is_initialized = false;

	/**
	 * Singleton instance.
	 *
	 * @var Handler|null
	 */
	protected static $_instance = null;

	/**
	 * Main Handler instance.
	 *
	 * @return Handler
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Integration name (also used for getSetting key: {name}_data).
	 *
	 * @return string
	 */
	public function get_name() {
		return 'wwp-checkout-tax-id';
	}

	/**
	 * Register scripts and block type.
	 *
	 * @return void
	 */
	public function initialize() {
		if ( $this->is_initialized ) {
			return;
		}

		$built_block_json = WWP_PLUGIN_PATH . 'build/checkout-tax-id/block.json';
		$block_json       = file_exists( $built_block_json )
			? $built_block_json
			: WWP_PLUGIN_PATH . 'src/js/checkout-tax-id/block.json';

		if ( file_exists( $block_json ) ) {
			register_block_type( $block_json );
		}

		add_filter(
			'__experimental_woocommerce_blocks_add_data_attributes_to_block',
			static function ( $blocks ) {
				$blocks[] = 'woocommerce-wholesale-pricing/checkout-tax-id';
				return $blocks;
			}
		);

		$this->register_scripts();
		$this->is_initialized = true;
	}

	/**
	 * Register editor and frontend scripts.
	 *
	 * @return void
	 */
	protected function register_scripts() {
		$editor_asset_path = WWP_PLUGIN_PATH . 'build/checkout-tax-id/index.asset.php';
		$editor_asset      = file_exists( $editor_asset_path )
			? include $editor_asset_path
			: array(
				'dependencies' => array(),
				'version'      => WWP_VERSION,
			);

		wp_register_script(
			'wwp-checkout-tax-id-editor',
			WWP_PLUGIN_URL . 'build/checkout-tax-id/index.js',
			$editor_asset['dependencies'],
			$editor_asset['version'],
			true
		);

		$frontend_asset_path = WWP_PLUGIN_PATH . 'build/checkout-tax-id/frontend.asset.php';
		$frontend_asset      = file_exists( $frontend_asset_path )
			? include $frontend_asset_path
			: array(
				'dependencies' => array(),
				'version'      => WWP_VERSION,
			);

		wp_register_script(
			'wwp-checkout-tax-id-frontend',
			WWP_PLUGIN_URL . 'build/checkout-tax-id/frontend.js',
			$frontend_asset['dependencies'],
			$frontend_asset['version'],
			true
		);
	}

	/**
	 * Frontend script handles.
	 *
	 * @return string[]
	 */
	public function get_script_handles() {
		return array( 'wwp-checkout-tax-id-frontend' );
	}

	/**
	 * Editor script handles.
	 *
	 * @return string[]
	 */
	public function get_editor_script_handles() {
		return array( 'wwp-checkout-tax-id-editor' );
	}

	/**
	 * Data exposed to the block via getSetting( 'wwp-checkout-tax-id_data' ).
	 *
	 * @return array<string, mixed>
	 */
	public function get_script_data() {
		$registrations = self::get_registration_settings();
		$initial       = '';

		if ( is_user_logged_in() ) {
			$initial = (string) get_user_meta( get_current_user_id(), 'wwp_wholesaler_tax_id', true );
		}

		return array(
			'enabled'         => FormBuilderService::is_tax_id_checkout_enabled( $registrations ),
			'label'           => FormBuilderService::get_tax_id_label( $registrations ),
			'required'        => FormBuilderService::is_tax_id_required( $registrations ),
			'vat_validation'  => FormBuilderService::is_vat_validation_enabled( $registrations ),
			'vat_countries'   => FormBuilderService::get_vat_countries( $registrations ),
			'initial_value'   => $initial,
		);
	}
}
