<?php
/**
 * Gutenberg Block Integration
 *
 * This file initializes the integration between WooCommerce Wholesale Pricing
 * and WooCommerce Blocks. It conditionally registers custom Gutenberg cart blocks
 * (e.g., requisition list) and wholesale-specific payment gateways based on plugin settings
 * and user roles.
 *
 * @package WooCommerceWholesalePricing\App\Modules\GutenbergBlock
 */
namespace WooCommerceWholesalePricing\App\Modules\GutenbergBlock;

use WooCommerceWholesalePricing\App\Modules\GutenbergBlock\Handler;
use WooCommerceWholesalePricing\App\Modules\GutenbergBlock\PaymentGateway;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Class Integration
 *
 * Handles the integration of custom Gutenberg blocks and payment gateways
 * for the WooCommerce Wholesale Pricing plugin.
 * Registers custom cart blocks and payment methods conditionally based on
 * plugin settings and user role.
 */
class Integration {

	use WholesaleSettings;
	
	/**
	 * Initialize the integration for Gutenberg blocks and payment methods.
	 *
	 * This method:
	 * - Ensures WooCommerce Blocks is loaded.
	 * - Conditionally registers a custom cart block (requisition list).
	 * - Conditionally registers custom payment methods for wholesale users.
	 *
	 * @return void
	 */
	public static function init() {

		$settings = self::get_pricing_settings();

		if (! did_action('woocommerce_blocks_loaded') ) {
			return;
		}

		if (isset($settings['requisition_list_cart_page']) && 'yes' == $settings['requisition_list_cart_page'] ) {
			add_action(
				'woocommerce_blocks_cart_block_registration',
				function ( $registry ) {
					$registry->register(Handler::instance());
				}
			);
		}

		add_action(
			'woocommerce_blocks_payment_method_type_registration', function ( $payment_method_registry ) {

				$settings = self::get_pricing_settings();
				if (!isset($settings['enable_custom_payment_method']) || 'yes' != $settings['enable_custom_payment_method'] ) {
					return ;
				}
				if (! is_wholesaler_user(get_current_user_id()) && !is_admin()  ) {
					return ;
				}
				$role = get_current_user_role_id();
				if ($role) {  
					$payment_method_name = get_term_meta($role, 'wwp_wholesale_payment_method_name', true);
				} else {
					 $payment_method_name =  $settings['payment_method_name'];
				}

				foreach ( (array) $payment_method_name as  $key => $wholesale_custom_gateway ) {
					if (array_key_exists($key, $settings['payment_method_name']) ) {
						$class = 'WooCommerceWholesalePricing\App\Modules\PaymentGateway\PaymentMethod';
						if (class_exists($class) ) { 
							if (is_wholesaler_user(get_current_user_id()) ) {
								if ('yes' == $wholesale_custom_gateway ) {
									$payment_method_registry->register(new PaymentGateway($key));
								}
							} else {
								$payment_method_registry->register(new PaymentGateway($key));
							} 
						}
					}
				}
			} 
		);
	}
}

Integration::init();
