<?php
namespace WooCommerceWholesalePricing\App\Modules\SalesAgent;

use WooCommerceWholesalePricing\App\Models\SalesAgent\AgentCommission;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Actions {
	/**
	 * General function to check current user login agent
	 */
	public static function is_agent( $user_obj = false ) {

		$agent = false;
		$user  = get_current_user_id();

		if ( $user_obj ) {
			$user = isset( $user_obj->ID ) ? $user_obj->ID : $user;
		}

		$args = array(
			'post_type'      => 'agent',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'meta_query'     => array(
				array(
					'key'     => 'assign_user',
					'value'   => $user,
					'compare' => '=',
				),
			),
		);

		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		$args   = apply_filters( 'args_check_current_user_agent', $args );
		$result = get_posts( $args );
		if ( ! empty( $result ) ) {
			$agent = $result[0]->ID;
		}

		if ( PHP_SESSION_ACTIVE === session_status() ) {
			$_SESSION['is_agent'] = $agent;
		}

		return $agent;
	}

	/**
	 * Stop AJAX handlers when the current user is not a logged-in sales agent.
	 */
	public function require_logged_in_agent() {
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( __( 'Unauthorized.', 'woocommerce-wholesale-pricing' ) );
		}

		if ( ! self::is_agent() ) {
			wp_send_json_error( __( 'Forbidden.', 'woocommerce-wholesale-pricing' ) );
		}
	}

	/**
	 * Whether the current user authored the given shop coupon.
	 *
	 * @param int $coupon_id Coupon post ID.
	 * @return bool
	 */
	public static function current_user_owns_shop_coupon( $coupon_id ) {
		$coupon_id = absint( $coupon_id );

		if ( ! $coupon_id || 'shop_coupon' !== get_post_type( $coupon_id ) ) {
			return false;
		}

		return (int) get_post_field( 'post_author', $coupon_id ) === get_current_user_id();
	}

	/**
	 * Base64url-encode a shared-cart identifier.
	 *
	 * @param string|int $value Value to encode.
	 * @return string
	 */
	public static function encode_shared_cart_id( $value ) {
		return rtrim( strtr( base64_encode( (string) $value ), '+/', '-_' ), '=' );
	}

	/**
	 * Base64url-decode a shared-cart identifier.
	 *
	 * @param string $encoded Encoded value.
	 * @return string
	 */
	public static function decode_shared_cart_id( $encoded ) {
		if ( '' === $encoded ) {
			return '';
		}

		$decoded = base64_decode(
			str_pad(
				strtr( $encoded, '-_', '+/' ),
				strlen( $encoded ) % 4,
				'=',
				STR_PAD_RIGHT
			)
		);

		return is_string( $decoded ) ? $decoded : '';
	}

	/**
	 * HMAC signature for a shared cart link.
	 *
	 * @param int    $user_id User ID.
	 * @param string $cart_id Cart key.
	 * @return string
	 */
	public static function get_shared_cart_signature( $user_id, $cart_id ) {
		return self::encode_shared_cart_id(
			hash_hmac(
				'sha256',
				(int) $user_id . '|' . $cart_id,
				wp_salt( 'safw_shared_cart' ),
				true
			)
		);
	}

	/**
	 * Build a signed shared-cart URL.
	 *
	 * @param int    $user_id  Agent user ID.
	 * @param string $cart_id  Saved cart key.
	 * @param int    $agent_id Optional agent post ID.
	 * @return string
	 */
	public static function build_shared_cart_link( $user_id, $cart_id, $agent_id = 0 ) {
		$token = self::encode_shared_cart_id( $user_id ) . '.'
			. self::encode_shared_cart_id( $cart_id ) . '.'
			. self::get_shared_cart_signature( $user_id, $cart_id );

		$url = wc_get_cart_url() . '?mycart=' . rawurlencode( $token );

		if ( $agent_id ) {
			$url .= '&id=' . absint( $agent_id );
		}

		return $url;
	}

	/**
	 * Parse and verify a signed shared-cart token.
	 *
	 * @param string $mycart Raw mycart query value.
	 * @return array{user_id:int,cart_id:string}|null
	 */
	public static function parse_shared_cart_token( $mycart ) {
		$parts = explode( '.', (string) $mycart );

		if ( 3 !== count( $parts ) ) {
			return null;
		}

		$user_id = self::decode_shared_cart_id( $parts[0] );
		$cart_id = self::decode_shared_cart_id( $parts[1] );
		$sig     = $parts[2];

		if ( '' === $user_id || '' === $cart_id || '' === $sig ) {
			return null;
		}

		if ( ! hash_equals( self::get_shared_cart_signature( $user_id, $cart_id ), $sig ) ) {
			return null;
		}

		return array(
			'user_id' => (int) $user_id,
			'cart_id' => $cart_id,
		);
	}

	/**
	 * Sanitize a comma-separated order-status IN-list for SQL interpolation.
	 *
	 * @param string $statuses Filtered status list.
	 * @return string
	 */
	public static function sanitize_order_status_sql_in_list( $statuses ) {
		$defaults = array(
			'wc-processing',
			'wc-completed',
			'wc-cancelled',
			'wc-refunded',
			'wc-on-hold',
			'wc-pending',
		);

		$parsed = array();

		if ( is_string( $statuses ) && preg_match_all( '/"([^"]+)"/', $statuses, $matches ) ) {
			$parsed = $matches[1];
		} elseif ( is_array( $statuses ) ) {
			$parsed = $statuses;
		}

		if ( empty( $parsed ) ) {
			$parsed = $defaults;
		}

		$safe = array();

		foreach ( $parsed as $status ) {
			$status = sanitize_key( $status );
			if ( preg_match( '/^wc-[a-z0-9_-]+$/', $status ) ) {
				$safe[] = '"' . $status . '"';
			}
		}

		if ( empty( $safe ) ) {
			$safe = array_map(
				static function ( $status ) {
					return '"' . $status . '"';
				},
				$defaults
			);
		}

	return implode( ', ', $safe );
	}

/**
 * Same as sanitize_order_status_sql_in_list() but strips the 'wc-' prefix
 * for use in HPOS queries (wp_wc_orders.status stores 'completed', not 'wc-completed').
 *
 * @param string $statuses Filtered status list (same format as sanitize_order_status_sql_in_list).
 * @return string
 */
	public static function sanitize_hpos_order_status_sql_in_list( $statuses ) {
		$with_prefix = self::sanitize_order_status_sql_in_list( $statuses );
		return preg_replace( '/"wc-([a-z0-9_-]+)"/', '"$1"', $with_prefix );
	}

	public static function get_agent_user_id( $agent_id ) {

		return get_post_meta( $agent_id, 'assign_user', true );
	}

	public static function get_customer_agent( $customer_id ) {

		return get_user_meta( $customer_id, 'sales_agent', true );
	}

	/**
	 * Whether HPOS is the authoritative order datastore.
	 *
	 * @return bool
	 */
	public static function is_hpos_enabled() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) ) {
			return \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
		}

		return 'yes' === get_option( 'woocommerce_custom_orders_table_enabled', 'no' );
	}

	public static function wc_agent_get_template( $template ) {

		$template_path = SALES_AGENT_TEMPLATES_PATH . $template;
		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		do_action( 'wc_agent_before_include_template' );
		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		include_once apply_filters( 'wc_agent_template', $template_path ); // nosemgrep: audit.php.lang.security.file.inclusion-arg
		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		do_action( 'wc_agent_after_include_template' );
	}

	public static function get_agent_commission( $agent_id ) {
		$commission_category_id = get_post_meta( $agent_id, 'commission_category', true );
		$commission_type        = 0;
		$commission             = '';
		if ( $commission_category_id ) {
			$commission = get_option( 'taxonomy_term_' . $commission_category_id );
			$commission = ( isset( $commission ) && $commission ) ? $commission : 0;
		}
		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		return apply_filters( 'wc_agent_get_agent_commission', $commission, $agent_id );
	}

	/**
	 * Get agent by order id
	 *
	 * @param  type $order_id
	 * @return type
	 */
	public static function get_order_agent( $order_id ) {

		// $agent = get_post_meta( $order_id, 'sales_agent', true );
		$order = wc_get_order( $order_id );
		$agent = $order->get_meta( 'sales_agent', true );
		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		return apply_filters( 'wc_sales_agent_order_agent', $agent, $order_id );
	}

	public static function agent_ids_equal( $first_agent_meta, $second_agent_meta ) {
		$first_ids  = filter_valid_agent_ids( $first_agent_meta );
		$second_ids = filter_valid_agent_ids( $second_agent_meta );

		sort( $first_ids );
		sort( $second_ids );

		return $first_ids === $second_ids;
	}

	public static function should_sync_customer_agent_on_admin_order_save( $post_id = 0, $order = null, $user_id = 0, $sales_agent = '' ) {
		$default = 'enabled' === get_option( 'bind_customer_to_agent_on_order', 'enabled' );

		/**
		 * Filter whether admin order saves should sync customer sales_agent meta.
		 *
		 * @since 2.0.0
		 *
		 * @param bool     $sync        Whether to sync customer meta.
		 * @param int      $post_id     Order ID.
		 * @param WC_Order $order       Order object.
		 * @param int      $user_id     Customer user ID.
		 * @param mixed    $sales_agent Submitted agent value.
		 */
		return (bool) apply_filters( 'safw_sync_customer_agent_on_admin_order_save', $default, $post_id, $order, $user_id, $sales_agent );
	}

	public static function prepare_query_sortable() {
		$sort      = '';
		$sort_type = '';
		if ( isset( $_REQUEST['order'] ) && ! empty( $_REQUEST['order'] ) ) {
			$sort_type = strtoupper( sanitize_text_field( wp_unslash( $_REQUEST['order'] ) ) );
		}
		if ( isset( $_REQUEST['orderby'] ) && ! empty( $_REQUEST['orderby'] ) ) {
			switch ( $_REQUEST['orderby'] ) {
				case 'agent_address':
					$sort = array(
						'meta_key' => 'billing_address_1',
						'orderby'  => 'meta_value',
						'order'    => $sort_type,
					);
					break;
				case 'agent_country':
					$sort = array(
						'meta_key' => 'billing_country',
						'orderby'  => 'meta_value',
						'order'    => $sort_type,
					);
					break;
				case 'agent_name':
					$sort = array(
						'orderby' => 'display_name',
						'order'   => $sort_type,
					);
					break;
				case 'agent_email':
					$sort = array(
						'meta_key' => 'billing_email',
						'orderby'  => 'meta_value',
						'order'    => $sort_type,
					);
					break;
			}
		}
		return $sort;
	}
}
