<?php

namespace WooCommerceWholesalePricing\App\Modules\SalesAgent\ListTable;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	include_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

use WooCommerceWholesalePricing\App\Models\SalesAgent\Commission;

class PayoutListTable extends \WP_List_Table {

	public function __construct() {

		parent::__construct(
			array(
				'singular' => 'commission_list', // Singular label
				'plural'   => 'commission_list', // plural label, also this well be one of the table css class
				'ajax'     => false, // We won't support Ajax for this table
			)
		);
	}

	public function get_all_agents() {

		// args of query
		$args = array(
			'post_type'      => 'agent',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
		);

		$result = get_posts( $args );

		return $result;
	}


	public function column_default( $item, $column_name ) {

		$agent_id = $item->ID;

		$commission_db      = new Commission();
		$select_commissions = $commission_db->get_pending_commission_by_agent_id( $agent_id, 'pending' );
		$pending_commission = 0.0;

		if ( is_array( $select_commissions ) && count( $select_commissions ) > 0 ) {
			foreach ( $select_commissions as $commission ) {
				$pending_commission += (float) $commission->commission_value;
			}
		}

		$commission_info          = $commission_db->get_agent_commission_info( $agent_id );
		$commission_category_name = $commission_info['commission_category'];

		$url = admin_url() . "admin.php?post_type=agent&page=agent-payout-view&agent_id=$item->ID";

		switch ( $column_name ) {
			case 'agent_name':
				return '<a href="' . $url . '">' . $item->post_title . '</a>';

			case 'commission_type':
				return __('Commission Category Based', 'woocommerce-wholesale-pricing');

			case 'commission_catagory':
				return esc_attr( $commission_category_name );

			case 'last_payment':
				return ! empty( get_option( 'last_payment_' . $item->ID ) ) ? get_option( 'last_payment_' . $item->ID ) : '-';

			case 'outstanding_balance':
				return wc_price( $pending_commission );

			case 'actions':
				return '<a class="payout-data" href="' . admin_url("admin.php?page=agent-payout-view&agent_id=$item->ID") . '">' . __( 'View Payout', 'woocommerce-wholesale-pricing' ) . '</a>';

			default:
				return print_r( $item, true ); // Show the whole array for troubleshooting purposes
		}
	}

	public function get_columns() {
		$columns = array(
			'agent_name'          => __( 'Agent Name', 'woocommerce-wholesale-pricing' ),
			'commission_type'     => __( 'Commission Type', 'woocommerce-wholesale-pricing' ),
			'commission_catagory' => __( 'Commission Category', 'woocommerce-wholesale-pricing' ),
			'last_payment'        => __( 'Last Payment', 'woocommerce-wholesale-pricing' ),
			'outstanding_balance' => __( 'Outstanding Balance', 'woocommerce-wholesale-pricing' ),
			'actions'             => __( 'Actions', 'woocommerce-wholesale-pricing' ),
		);
		return $columns;
	}

	public function get_sortable_columns() {
		$sortable_columns = array(
			'agent_name'          => array( 'agent_name', true ),
			'commission_catagory' => array( 'commission_catagory', true ), // true means it's already sorted
			'last_payment'        => array( 'last_payment', true ),
			'outstanding_balance' => array( 'outstanding_balance', true ),
		);
		return $sortable_columns;
	}

	public function prepare_items() {

		$per_page              = ( get_option( 'list_no_rows' ) ) ? get_option( 'list_no_rows' ) : 10;
		$hidden                = array();
		$columns               = $this->get_columns();
		$sortable              = $this->get_sortable_columns();
		$this->_column_headers = array( $columns, $hidden, $sortable );

		global $wpdb;

		$this->items = $this->get_all_agents();
		$total_items = $wpdb->get_var(
			$wpdb->prepare(
				"
            SELECT count(ID) FROM {$wpdb->prefix}posts WHERE post_status = %s AND post_type =  %s
            ",
				'publish',
				'agent'
			)
		);

		$this->set_pagination_args(
			array(
				'total_items' => $total_items, // WE have to calculate the total number of items
				'per_page'    => $per_page, // WE have to determine how many items to show on a page
				'total_pages' => ceil( $total_items / $per_page ),   // WE have to calculate the total number of pages
			)
		);
	}
}
