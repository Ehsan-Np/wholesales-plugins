<?php
namespace WooCommerceWholesalePricing\App\Modules\SalesAgent\ListTable;

use WooCommerceWholesalePricing\App\Modules\SalesAgent\Actions;
use WooCommerceWholesalePricing\App\Modules\SalesAgent\Request;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	include_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class CommissionListTable extends \WP_List_Table {

	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'commission_list', // Singular label
				'plural'   => 'commission_list', // plural label, also this well be one of the table css class
				'ajax'     => false, // We won't support Ajax for this table
			)
		);

		add_action( 'wc_agent_payout_admin_order_details', array( $this, 'wc_agent_after_payout_list_table' ) );
	}


	public function wc_agent_after_payout_list_table() {
		if ( isset( $_REQUEST['agent_id'] ) && ! empty( sanitize_text_field( $_REQUEST['agent_id'] ) ) ) {
			echo '<h1 class="agent_name">' . esc_html( get_the_title( sanitize_text_field( $_REQUEST['agent_id'] ) ) ) . '</h1>';
		}
	}


	public function column_default( $item, $column_name ) {

		switch ( $column_name ) {
			case 'sales_agent':
				$order = wc_get_order( $item->order_id );
				if ( $order ) {
					$customer = new \WC_Customer( $order->get_customer_id() );
					if ( ! empty( $customer->get_display_name() ) ) {
						return $customer->get_display_name();
					} else {
						$first_name = $customer->get_first_name();

						$last_name = $customer->get_last_name();

						return $first_name . ' ' . $last_name;
					}
				} else {
					return '-';
				}

			case 'order_no':
				$order = wc_get_order( $item->order_id );
				if ( $order ) {
					return "<a href='" . esc_url( $order->get_edit_order_url() ) . "'>" . esc_html( $order->get_order_number() ) . '</a>';
				} else {
					return '-';
				}

			case 'oder_date':
				/**
				 * Filter.
				 *
				 * @since 1.2
				 *
				 * Custom Task - CT-220
				 */
				return apply_filters( 'safw_admin_order_comm_list_date', $item->create_date, $item );

			case 'commission':
				return wc_price( (float) $item->commission_value );

			case 'status':
				return esc_html__( ucfirst( $item->commission_status ), 'woocommerce-wholesale-pricing' );

			case 'actions':
				$url = admin_url( "admin.php?page=agent-commission-edit&commission_id=$item->id" );
				return sprintf( '<a class="edit-data" href="' . esc_url( $url ) . '"><i class="dashicons dashicons-edit"></i>%s</a>', esc_html__( 'Edit', 'woocommerce-wholesale-pricing' ) ) . ' ' .
						sprintf( '<a style="color: red;" class="delete-commission" href="#" data-commss="' . esc_attr( $item->id ) . '" data-order="' . esc_attr( $item->order_id ) . '"><i class="dashicons dashicons-trash" ></i>%s</a>', esc_html__( 'Delete', 'woocommerce-wholesale-pricing' ) );
			default:
				return print_r( $item, true ); // Show the whole array for troubleshooting purposes
		}
	}

	public function column_cb( $item ) {
		return sprintf(
			'<input type="checkbox" name="commission_ids[]" value="%s" />',
			$item->id
		);
	}

	public function get_columns() {
		$columns = array(
			'cb'          => '<input type="checkbox" />', // Add this line
			'sales_agent' => __( 'Customer Name', 'woocommerce-wholesale-pricing' ),
			'order_no'    => __( 'Order No#', 'woocommerce-wholesale-pricing' ),
			/**
			 * Filter.
			 *
			 * @since 1.2
			 *
			 * Custom Task: CT-220
			 */
			'oder_date'   => __( apply_filters( 'safw_admin_comm_list_order_date_heading', 'Order Date' ), 'woocommerce-wholesale-pricing' ),
			'commission'  => __( 'Commission', 'woocommerce-wholesale-pricing' ),
			'status'      => __( 'Commission Status', 'woocommerce-wholesale-pricing' ),
			'actions'     => __( 'Actions', 'woocommerce-wholesale-pricing' ),
		);
		return $columns;
	}

	public function get_sortable_columns() {
		$sortable_columns = array(
			'order_no'    => array( 'order_no', true ),
			'sales_agent' => array( 'sales_agent', true ), // true means it's already sorted
			'oder_date'   => array( 'oder_date', true ),
			'commission'  => array( 'commission', true ),
			'status'      => array( 'status', true ),
		);
		return $sortable_columns;
	}

	public function extra_tablenav( $which ) {
		// Filters are rendered outside the list table in payout-view.php to avoid nested forms.
	}

	public function prepare_items() {
		$per_page              = ( get_option( 'list_no_rows' ) ) ? get_option( 'list_no_rows' ) : 10;
		$hidden                = array();
		$columns               = $this->get_columns();
		$sortable              = $this->get_sortable_columns();
		$this->_column_headers = array( $columns, $hidden, $sortable );
		$general_action        = new Request();
		$currentPage           = $this->get_pagenum();

		global $wpdb;
		$prepare     = 'prepare';
		$get_var     = 'get_var';
		$get_results = 'get_results';
		$where       = 'WHERE agent_id = %d';

		$agent_id           = isset( $_REQUEST['agent_id'] ) ? sanitize_text_field( $_REQUEST['agent_id'] ) : 0;
		$customer_date_flag = false;
		$only_date_flag     = false;
		$is_hpos            = Actions::is_hpos_enabled();

		if ( $agent_id ) {
			$total_items_query = "
                SELECT count(agent_id) 
                FROM {$wpdb->prefix}wc_agents_commissions 
                LEFT JOIN {$wpdb->prefix}posts ON {$wpdb->prefix}posts.ID = {$wpdb->prefix}wc_agents_commissions.agent_id 
                WHERE agent_id = %d
            ";

			if ( isset( $_REQUEST['customer_id'] ) && ! empty( sanitize_text_field( $_REQUEST['customer_id'] ) ) && isset( $_REQUEST['date_from'] ) && ! empty( sanitize_text_field( $_REQUEST['date_from'] ) ) && isset( $_REQUEST['date_to'] ) && ! empty( sanitize_text_field( $_REQUEST['date_to'] ) ) ) {
				$customer_date_flag = true;
				$customer_id        = sanitize_text_field( $_REQUEST['customer_id'] );
				$from               = gmdate( 'Y-m-d 00:00:01', strtotime( sanitize_text_field( $_REQUEST['date_from'] ) ) );
				$to                 = gmdate( 'Y-m-d 23:59:59', strtotime( sanitize_text_field( $_REQUEST['date_to'] ) ) );

				$total_items_query = $is_hpos
					? "
                    SELECT count(com.agent_id)
                    FROM {$wpdb->prefix}wc_agents_commissions com
                    INNER JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
                    WHERE com.agent_id = %d
                    AND o.customer_id = %d
                    AND ( com.create_date >= %s AND com.create_date <= %s)
                "
					: "
                    SELECT count(agent_id) 
                    FROM {$wpdb->prefix}wc_agents_commissions
                    LEFT JOIN {$wpdb->prefix}postmeta ON {$wpdb->prefix}wc_agents_commissions.order_id = {$wpdb->prefix}postmeta.post_id
                    WHERE agent_id = %d 
                    AND meta_key = '_customer_user' 
                    AND meta_value = %d 
                    AND ( create_date >= %s AND create_date <= %s)
                ";

				$total_items = $wpdb->$get_var( $wpdb->$prepare( $total_items_query, $agent_id, $customer_id, $from, $to ) ); // phpcs:ignore QITStandard.DB.DynamicWpdbMethodCall.DynamicMethod

			} elseif ( isset( $_REQUEST['date_from'] ) && ! empty( sanitize_text_field( $_REQUEST['date_from'] ) ) && isset( $_REQUEST['date_to'] ) && ! empty( sanitize_text_field( $_REQUEST['date_to'] ) ) ) {
				$only_date_flag = true;
				$from           = gmdate( 'Y-m-d 00:00:01', strtotime( sanitize_text_field( $_REQUEST['date_from'] ) ) );
				$to             = gmdate( 'Y-m-d 23:59:59', strtotime( sanitize_text_field( $_REQUEST['date_to'] ) ) );

				$total_items_query = "
                    SELECT count(DISTINCT id) 
                    FROM {$wpdb->prefix}wc_agents_commissions
                    LEFT JOIN {$wpdb->prefix}postmeta ON {$wpdb->prefix}wc_agents_commissions.order_id = {$wpdb->prefix}postmeta.post_id
                    WHERE agent_id = %d 
                    AND ( create_date >= %s AND create_date <= %s)
                ";

				$total_items = $wpdb->$get_var( $wpdb->$prepare( $total_items_query, $agent_id, $from, $to ) ); // phpcs:ignore QITStandard.DB.DynamicWpdbMethodCall.DynamicMethod

			} elseif ( isset( $_REQUEST['customer_id'] ) && ! empty( sanitize_text_field( $_REQUEST['customer_id'] ) ) ) {
				$customer_id = sanitize_text_field( $_REQUEST['customer_id'] );

				$total_items_query = $is_hpos
					? "
                    SELECT count(com.agent_id)
                    FROM {$wpdb->prefix}wc_agents_commissions com
                    INNER JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
                    WHERE com.agent_id = %d
                    AND o.customer_id = %d
                "
					: "
                    SELECT count(agent_id) 
                    FROM {$wpdb->prefix}wc_agents_commissions
                    LEFT JOIN {$wpdb->prefix}postmeta ON {$wpdb->prefix}wc_agents_commissions.order_id = {$wpdb->prefix}postmeta.post_id
                    WHERE agent_id = %d 
                    AND meta_key = '_customer_user' 
                    AND meta_value = %d
                ";

				$total_items = $wpdb->$get_var( $wpdb->$prepare( $total_items_query, $agent_id, $customer_id ) ); // phpcs:ignore QITStandard.DB.DynamicWpdbMethodCall.DynamicMethod

			} else {
				$total_items_query = "
                    SELECT count(*) 
                    FROM {$wpdb->prefix}wc_agents_commissions 
                    WHERE agent_id = %d
                ";

				$total_items = $wpdb->$get_var( $wpdb->$prepare( $total_items_query, $agent_id ) ); // phpcs:ignore QITStandard.DB.DynamicWpdbMethodCall.DynamicMethod
			}

			$items       = $general_action->query( $per_page, $currentPage );
			$this->items = is_array( $items ) ? $items : array();

		} else {
			$total_items = 0;
			$this->items = array();
		}

		$this->set_pagination_args(
			array(
				'total_items' => $total_items,
				'per_page'    => $per_page,
				'total_pages' => ceil( $total_items / $per_page ),
			)
		);
	}
}
