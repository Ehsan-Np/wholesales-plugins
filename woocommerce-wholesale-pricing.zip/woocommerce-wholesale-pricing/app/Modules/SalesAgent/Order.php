<?php

namespace WooCommerceWholesalePricing\App\Modules\SalesAgent;

use WooCommerceWholesalePricing\App\Models\SalesAgent\Commission;
use WooCommerceWholesalePricing\App\Models\SalesAgent\AgentCommission;
use WooCommerceWholesalePricing\App\Modules\SalesAgent\Traits\CalculateCommission;

class Order {

	use CalculateCommission;

	private $commission;

	private $agentCommission;

	public function __construct() {
		
		$this->commission       = new Commission();
		$this->agentCommission  = new AgentCommission();

		// add columns head to order items in backend
		add_action( 'woocommerce_admin_order_item_headers', array( $this, 'add_order_items_header_columns' ), 10, 1 );

		// add columns to order items in backend
		add_action( 'woocommerce_admin_order_item_values', array( $this, 'add_order_item_values' ), 10, 3 );

		add_action( 'woocommerce_admin_order_totals_after_total', array( $this, 'add_commission_order_subtotal' ), 10, 1 );

		add_action( 'woocommerce_order_status_changed', array( $this, 'safw_calc_comm_on_order_status_changed' ), 10, 4 );

		// add agent & commission meta to order in checkout for frontend orders
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'add_meta_to_order_callback' ), 20, 3 );
		// add agent & commission meta to order in checkout for frontend orders with API/Chekout blocks.
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'store_api_meta_to_order_callback' ), 20, 1 );
		// add agent & commission meta to orders created via the WooCommerce REST API.
		add_action( 'woocommerce_rest_insert_shop_order_object', array( $this, 'rest_api_meta_to_order_callback' ), 20, 3 );

		// add agent dropdown to order page backend
		add_action( 'woocommerce_admin_order_data_after_order_details', array( $this, 'add_agent_dropdown_to_order_callback' ), 10, 1 );

		// save order meta (agent/commission) for admin create orders
		add_action( 'woocommerce_process_shop_order_meta', array( $this, 'wc_agent_add_order_meta_callback' ), 10, 2 );

		// add order list filter
		add_action( 'restrict_manage_posts', array( $this, 'add_order_list_filter_callback' ), 20 );

		// add filter query
		add_filter( 'request', array( $this, 'request_query' ), 99 );

		add_filter( 'woocommerce_email_recipient_new_order', array( $this, 'send_new_order_email_to_agent' ), 99, 2 );

		add_action( 'admin_init', array( $this, 'wc_agent_add_columns' ) );
	}

	public function add_order_items_header_columns( $order ) {

		$order_items_columns = sprintf(
			'<th class="item_commission sortable" data-sort="float">%1$s</th>
        <th class="item_commission_amount sortable" data-sort="float">%2$s</th>',
			__( 'Commission Type', 'woocommerce-wholesale-pricing' ),
			__( 'Commission Amount', 'woocommerce-wholesale-pricing' )
		);

		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		echo wp_kses_post( apply_filters( 'wc_sales_agent_admin_order_item_headers', $order_items_columns, $order ) );
	}

	/**
	 * Add values columns to order items
	 *
	 * @param type $product
	 * @param type $item
	 * @param type $item_id
	 */
	public function add_order_item_values( $product, $item, $item_id ) {
		if ( $item instanceof \WC_Order_Item_Product ) {
			$order    = $item->get_order(); // get order from item
			$agent_id_meta    = $order->get_meta( 'sales_agent', true );
			$agent_ids        = normalize_agent_ids( $agent_id_meta );
			$primary_agent_id = ! empty( $agent_ids ) ? (int) reset( $agent_ids ) : 0;

			$commission_data = $this->resolve_commission_data_for_order( $order, $primary_agent_id, false, $item );
			$commission_text = '__';
			if ( $commission_data['commission_type'] && 'percentage' === $commission_data['commission_type'] ) {
				$commission_text = $commission_data['commission_value'] . ' ' . esc_html__( '(Percentage)', 'woocommerce-wholesale-pricing' );// commission text
			} elseif ( $commission_data['commission_type'] && 'fixed' === $commission_data['commission_type'] ) {
				$commission_text = $commission_data['commission_value'] . '-' . esc_html__( '(Fixed)', 'woocommerce-wholesale-pricing' ); // commission text
			}

			$order_items_values = sprintf(
				'<th class="item_commission sortable" data-sort="float">%1$s</th>
                <th class="item_commission_amount sortable" data-sort="float">%2$s',
				$commission_text,
				wc_price( $commission_data['product_commission'] )
			);

			$order_items_values .= '</th>';
			/**
			* Filter.
			*
			* @since 1.0.4
			*/
			echo wp_kses_post( apply_filters( 'wc_sales_agent_admin_order_item_values', $order_items_values, $product, $item, $item_id ) );
		}
	}

	/**
	 * Resolve commission data using priority: multi-agent > level > customer > category.
	 *
	 * @param WC_Order                   $order            Order object.
	 * @param int                        $primary_agent_id Primary agent post ID.
	 * @param mixed                      $new_status       Order status for category calc, or false.
	 * @param WC_Order_Item_Product|null $order_item       Optional single line item for per-item display.
	 * @return array
	 */
	public function resolve_commission_data_for_order( $order, $primary_agent_id, $new_status = false, $order_item = null ) {
		$commission = Actions::get_agent_commission( $primary_agent_id );
		return $this->calculate_commission( $commission, $primary_agent_id, $order, false, ! $order_item, $order_item, $new_status );
	}

	public function add_commission_order_subtotal( $order_id ) {

		$order       = new \WC_Order( $order_id );
		$order_id    = $order->get_id();
		$order_total = $order->get_total();

		$agent_id_meta    = $order->get_meta( 'sales_agent', true );
		$agent_ids        = normalize_agent_ids( $agent_id_meta );
		$primary_agent_id = ! empty( $agent_ids ) ? (int) reset( $agent_ids ) : 0;

		$subtotal_commission = $primary_agent_id
			? $this->resolve_commission_data_for_order( $order, $primary_agent_id )
			: array();
		// Ensure the key exists before accessing
		$product_commission = isset( $subtotal_commission['product_commission'] ) ? $subtotal_commission['product_commission'] : 0;

		$subtotal_commission_html = sprintf(
			'<tr>
            <td class="label">%1$s</td>
            <td class="total amount">%2$s',
			esc_html__( 'Total Commission:', 'woocommerce-wholesale-pricing' ),
			wc_price( $product_commission )
		);

		// Add Multi-Agent Breakdown if applicable
		if ( count( $agent_ids ) > 1 ) {
			$split_type = $order->get_meta( '_safw_multi_agent_split_type', true );
			$rule_id    = $order->get_meta( '_safw_multi_agent_rule_id', true );
			$breakdown  = array();

			if ( 'custom' === $split_type && $rule_id ) {
				$custom_splits = get_post_meta( $rule_id, '_safw_agents', true );
				foreach ( $agent_ids as $aid ) {
					$portion_percent    = isset( $custom_splits[ $aid ] ) ? (float) $custom_splits[ $aid ] : 0;
					$total_rule_percent = (float) get_post_meta( $rule_id, '_safw_commission_percentage', true );

					if ( $total_rule_percent > 0 ) {
						$agent_share = ( $portion_percent / $total_rule_percent ) * $product_commission;
						$breakdown[] = '<div><small>' . get_the_title( $aid ) . ': ' . wc_price( $agent_share ) . '</small></div>';
					}
				}
			} else {
				// Equal split
				$share = $product_commission / count( $agent_ids );
				foreach ( $agent_ids as $aid ) {
					$breakdown[] = '<div><small>' . get_the_title( $aid ) . ': ' . wc_price( $share ) . '</small></div>';
				}
			}

			if ( ! empty( $breakdown ) ) {
				$subtotal_commission_html .= '<div class="agent-commission-breakdown" style="margin-top:5px; border-top:1px solid #eee; padding-top:3px; font-weight:normal; text-align:right;">' . implode( '', $breakdown ) . '</div>';
			}
		}

		$subtotal_commission_html .= '</td></tr>';

		echo wp_kses_post( $subtotal_commission_html );
	}

	/**
	 * Commission Calculation depends on order status.
	 *
	 * @param type $order_id
	 * @param type $old_status
	 * @param type $new_status
	 * @param type $order
	 * @return void
	 */
	public function safw_calc_comm_on_order_status_changed( $order_id, $old_status, $new_status, $order ) {

		$customer_id = $order->get_customer_id();

		/**
		 * Filter: Allow overriding the credit check flag.
		 *
		 * @since 1.8.0
		 */
		$check_credit_flag = apply_filters( 'safw_check_credit_product_flag', true );

		// Handle multiple agents
		$agent_id_meta = $order->get_meta( 'sales_agent', true );
		if ( empty( $agent_id_meta ) ) {
			$agent_id_meta = get_user_meta( $customer_id, 'sales_agent', true );
		}

		$agent_ids = normalize_agent_ids( $agent_id_meta );

		if ( empty( $agent_ids ) ) {
			return;
		}

		$primary_agent_id = (int) reset( $agent_ids );

		if ( $check_credit_flag ) {
			$order_has_credit_product = false;
			$credit_product_id        = get_option( '_wc_cs_get_selected_product_for_repayment', true );

			if ( $credit_product_id ) {
				foreach ( $order->get_items() as $item ) {
					$product_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();

					if ( intval( $product_id ) === intval( $credit_product_id ) ) {
						$order_has_credit_product = true;
						break;
					}
				}
			}

			if ( $order_has_credit_product ) {
				$order->update_meta_data( 'sales_agent', $agent_id_meta );
				$order->save();
				return;
			}
		}


		/**
		 * Filter whether to check for wallet topup products.
		 *
		 * @since 1.0.0
		 * @param bool $flag Whether to check.
		 */
		$check_topup_flag = apply_filters( 'safw_check_wal_topup_product_flag', true );
		if ( true === $check_topup_flag ) {
			$order_has_topup_product = false;

			foreach ( $order->get_items() as $item ) {
				$product_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();
				$topup_flag = get_post_meta( $product_id, 'wal_topup_product', true );
				if ( ! empty( $topup_flag ) ) {
					$order_has_topup_product = true;
					break;
				}
			}
			if ( $order_has_topup_product ) {
				$order->update_meta_data( 'sales_agent', $agent_id_meta );
				$order->save();
				return;
			}
		}

		$commission_data = $this->resolve_commission_data_for_order( $order, $primary_agent_id, $new_status );
		
		$WC_Agent_Commission_Data_Store = new AgentCommission();
		$total_commission_to_distribute = (float) $commission_data['product_commission'];
		$share_factor = 1.0;
		$agent_id     = (int) $primary_agent_id;

		$agent_commission_amount     = $total_commission_to_distribute * $share_factor;
		$agent_commission_percentage = (float) $commission_data['commission_value'] * $share_factor;
		
		// Create/Update commission entry
		$commission_row = $WC_Agent_Commission_Data_Store->get_commission_by_order_agent( $order_id, $agent_id );
		$cid            = isset( $commission_row->id ) ? $commission_row->id : 0;

		if ( $cid ) {
			$WC_Agent_Commission_Data_Store->update_commission(
				array(
					'agent_id'              => $agent_id,
					'order_id'              => $order_id,
					'commission_type'       => $commission_data['commission_type'],
					'commission_percentage' => $agent_commission_percentage,
					'commission_value'      => $agent_commission_amount,
				),
				array( 'id' => $cid )
			);
		} elseif ( 0 != $agent_commission_amount ) {
			$WC_Agent_Commission_Data_Store->add_commission(
				array(
					'agent_id'              => $agent_id,
					'order_id'              => $order_id,
					'commission_percentage' => $agent_commission_percentage,
					'commission_value'      => $agent_commission_amount,
					'commission_type'       => $commission_data['commission_type'],
				)
			);
		}

		/**
		 * Action: Email on order.
		 *
		 * @since 1.0.0
		 * @param int $order_id The order ID.
		 * @param int $primary_agent_id The primary agent ID.
		 * @param WC_Order $order The order object.
		 */
		do_action( 'safw_email_on_order', $order_id, $primary_agent_id, $order );

		if ( in_array( $new_status, array( 'cancelled', 'failed', 'refunded' ) ) ) {
			global $wpdb;
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}wc_agents_commissions WHERE order_id = %d", $order_id ) );
		}
	}

	/**
	 * Add agent and commissions to order as meta
	 *
	 * @param type $order_id
	 * @param type $posted_data
	 * @param type $order
	 */
	public function add_meta_to_order_callback( $order_id, $posted_data, $order ) {

		if ( ! is_a( $order, 'WC_Order' ) ) {
			return;
		}

		$customer_id  = $order->get_customer_id();
		$order_status = $order->get_status();

		if ( 'failed' === $order_status ) {
			return;
		}

		// check if customer has an agent
		$agent_id = get_user_meta( $customer_id, 'sales_agent', true );

		/**
		 * Filter: Allow select agent on checkout.
		 *
		 * @since 1.8.0
		 */
		$agent_id = apply_filters( 'safw_custom_agent_data', $agent_id, $customer_id, $order );

		/**
		 * Filter: Allow overriding the credit check flag.
		 *
		 * @since 1.8.0
		 */
		$check_credit_flag = apply_filters( 'safw_check_credit_product_flag', true );

		if ( $check_credit_flag ) {
			$order_has_credit_product = false;

			// Get the credit product ID from the option
			$credit_product_id = get_option( '_wc_cs_get_selected_product_for_repayment', true );

			if ( $credit_product_id ) {
				foreach ( $order->get_items() as $item ) {
					$product_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();

					if ( intval( $product_id ) === intval( $credit_product_id ) ) {
						$order_has_credit_product = true;
						break; // Stop loop once credit product is found
					}
				}
			}

			if ( $order_has_credit_product && $agent_id ) {
				$order->update_meta_data( 'sales_agent', $agent_id );
				$order->save();
				return;
			}
		}
		/**
		* Filter.
		*
		* @since 1.8.0
		*/

		/**
		 * Filter whether to check for wallet topup products.
		 *
		 * @since 1.0.0
		 * @param bool $flag Whether to check.
		 */
		$check_topup_flag = apply_filters( 'safw_check_wal_topup_product_flag', true );
		if ( true === $check_topup_flag ) {
			$order_has_topup_product = false;

			foreach ( $order->get_items() as $item ) {
				$product_id = $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id();

				// Check if this product has the 'wal_topup_product' meta
				$topup_flag = get_post_meta( $product_id, 'wal_topup_product', true );

				if ( ! empty( $topup_flag ) ) {
					$order_has_topup_product = true;
					break; // stop loop as soon as we find one
				}
			}
			if ( $order_has_topup_product ) {
				$order->update_meta_data( 'sales_agent', $agent_id );
				$order->save();
				return;
			}
		}
		// Ensure agent store is initialized and handle cookie referrals
		if ( empty( $agent_id ) && isset( $_COOKIE['ref_id'] ) && ! empty( sanitize_text_field( $_COOKIE['ref_id'] ) ) ) {
			$agent_id = sanitize_text_field( $_COOKIE['ref_id'] );
			if ( ! empty( $customer_id ) ) {
				update_user_meta( $customer_id, 'sales_agent', $agent_id );
			}
			// deleting cookie once work done.
			setcookie( 'ref_id', '', time() - 36000, '/' );
		}

		// --- Fallback: Standard Agent & Commission Saving ---
		if ( ! empty( $agent_id ) ) {
			$commission = Actions::get_agent_commission( $agent_id );
			$order->update_meta_data( 'sales_agent', $agent_id );
			$order->update_meta_data( 'sales_agent_commision', $commission );
			$order->save();
	
			$order->add_order_note(
				sprintf(
					'Order sales agent has been updated to %1$s',
					get_the_title( $agent_id )
				)
			);
		}
	}

	public function store_api_meta_to_order_callback( $order ) {
		$order_id = $order->get_id();
		$this->add_meta_to_order_callback( $order_id, array(), $order );
	}

	/**
	 * Assign agent meta to orders created via the WooCommerce REST API.
	 *
	 * The checkout hooks (woocommerce_checkout_order_processed and
	 * woocommerce_store_api_checkout_order_processed) are never fired for
	 * programmatic REST API orders, so sales_agent meta would be missing.
	 * This hook runs after the REST controller persists the order, but only
	 * for new orders (not updates) and only when sales_agent is not already set.
	 *
	 * @param WC_Order        $order   The newly created order.
	 * @param WP_REST_Request $request The REST request object.
	 * @param bool            $creating True when creating, false when updating.
	 */
	public function rest_api_meta_to_order_callback( $order, $request, $creating ) {
		if ( ! $creating ) {
			return;
		}

		// Skip if agent meta was already set (e.g. explicitly passed in the request).
		if ( ! empty( $order->get_meta( 'sales_agent', true ) ) ) {
			return;
		}

		$order_id = $order->get_id();
		$this->add_meta_to_order_callback( $order_id, array(), $order );
	}

	/**
	 * Add agent dropdown to order page backend
	 *
	 * @param type $order
	 */
	public function add_agent_dropdown_to_order_callback( $order ) {
		?>
		<p class="form-field form-field-wide wc-woocommerce-wholesale-pricing-user">
			<label for="sales_agent">
			<?php
			esc_html_e( 'Sales Agent:', 'woocommerce-wholesale-pricing' );
			?>
			</label>
			<?php
			$multi_agent_enabled = 'enabled' === get_option( 'multi_agent_commission_toggle', 'disabled' );
			$multiple_attr       = $multi_agent_enabled ? 'multiple="multiple"' : '';
			$name_attr           = $multi_agent_enabled ? 'sales_agent[]' : 'sales_agent';
			?>
			<select class="wc-agent-search wc-enhanced-select" id="sales_agent" name="<?php echo esc_attr( $name_attr ); ?>" <?php echo esc_attr( $multiple_attr ); ?> data-placeholder="<?php esc_attr_e( 'Sales Agent(s)', 'woocommerce-wholesale-pricing' ); ?>" data-allow_clear="true" style="width:100%;">
			<?php
			$agents          = get_posts(
				array(
					'post_type'      => 'agent',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
				)
			);
			$selected_agents = filter_valid_agent_ids( $order->get_meta( 'sales_agent', true ) );
			?>
			<option value="" <?php echo empty( $selected_agents ) ? 'selected' : ''; ?>></option>
			<?php

			if ( is_array( $agents ) && count( $agents ) > 0 ) {
				foreach ( $agents as $key => $value ) {
					?>
					<option <?php echo in_array( $value->ID, $selected_agents ) ? 'selected ' : ''; ?>value="<?php echo esc_attr( $value->ID ); ?>" ><?php echo esc_html( get_the_title( $value ) ); ?></option>
					<?php
				}
			}
			?>
			</select>
			<input type="hidden" name="order_nonce" value="<?php echo esc_attr( wp_create_nonce( __FILE__ ) ); ?>">
		</p>
		<?php

		/**
		 * Filter.
		 *
		 * @since 1.2
		 *
		 * Custom Task - CT-297.
		 */
		$flag = apply_filters( 'sales_agent_add_custom_commission_field', false );

		if ( $flag ) {
			$cc = ! empty( $order->get_meta( 'custom_commission' ) ) ? $order->get_meta( 'custom_commission' ) : '';
			?>
			<style>
				.wc-sales-custom-commision-field-wrapper {
					margin: 20px 0;
					float:left;
					width: 100%
				}
				.wc-sales-custom-commision-field-wrapper label {
					display:block;
					margin-bottom: 10px;
				}
			</style>
			<p class="wc-sales-custom-commision-field-wrapper">
				<label for="is_custom_commission">
					<input type="checkbox" id="is_custom_commission" name="is_custom_commission" value="1" <?php checked( $order->get_meta( 'is_custom_commission' ), '1', true ); ?> />    <?php echo esc_html__( 'Custom Commission', 'woocommerce-wholesale-pricing' ); ?>
				</label>
				<input type="number" min=".01" step=".01" name="custom_commission" value="<?php echo esc_attr( $cc ); ?>">
			</p>
			<?php
		}
	}
	
	/**
	 * Add order meta (agent,commission)
	 *
	 * @param type $post_id
	 * @param type $post
	 */
	public function wc_agent_add_order_meta_callback( $post_id, $post ) {

		if ( ! isset( $_POST['order_nonce'] ) || ( isset( $_POST['order_nonce'] ) && ! wp_verify_nonce( sanitize_text_field( $_POST['order_nonce'] ), __FILE__ ) ) ) {
			exit( 'Not Authorized' );
		}

		$sales_agent = isset( $_POST['sales_agent'] ) ? map_deep( wp_unslash( $_POST['sales_agent'] ), 'sanitize_text_field' ) : '';
		if ( is_array( $sales_agent ) ) {
			$sales_agent = array_filter( $sales_agent, 'strlen' );
		}

		$new_agent_ids = filter_valid_agent_ids( $sales_agent );
		$sales_agent   = 1 === count( $new_agent_ids ) ? (string) reset( $new_agent_ids ) : $new_agent_ids;

		$commission_value      = '';
		$commission_percentage = '';

		// get order by id
		$order   = wc_get_order( $post_id );
		$user_id = $order->get_user_id();

		// get old agent
		$old_agent     = Actions::get_order_agent( $post_id );
		$old_agent_ids = filter_valid_agent_ids( $old_agent );

		if ( Actions::agent_ids_equal( $old_agent, $new_agent_ids ) ) {
			return;
		}

		$sync_customer_agent            = Actions::should_sync_customer_agent_on_admin_order_save( $post_id, $order, $user_id, $sales_agent );

		if ( empty( $new_agent_ids ) ) {
			// remove agent from the customer.
			if ( $sync_customer_agent && ! empty( $user_id ) ) {
				update_user_meta( $user_id, 'sales_agent', '' );
			}

			$order->update_meta_data( 'sales_agent', '' );
			$order->update_meta_data( 'sales_agent_commision', '' );
			$order->save();

			// get commission id and delete it from the commission table.
			$commission = $this->agentCommission->get_commission_by_order_id( $post_id );
			if ( isset( $commission->id ) ) {
				$this->agentCommission->delete_commission( $commission->id );
			}

			if ( ! empty( $old_agent_ids ) ) {
				$order->add_order_note( __( 'Order sales agent has been removed', 'woocommerce-wholesale-pricing' ) );
			}

			return; // return from here.
		}

		/**
		 * Action.
		 *
		 * @since 1.2
		 *
		 * Custom Task - CT-297.
		 */
		do_action( 'sales_agent_add_order_meta', $post_id, $order, $user_id, $sales_agent, $old_agent, $this->agentCommission );

		if ( ! has_action( 'sales_agent_add_order_meta' ) ) {

			if ( $sync_customer_agent && ! empty( $user_id ) ) {
				update_user_meta( $user_id, 'sales_agent', $sales_agent );
			}

			if ( ! empty( $sales_agent ) ) {
				// get commission category for agent
				// Note: For multiple agents, we'll need to handle this differently in calculating commission
				$single_agent          = is_array( $sales_agent ) ? reset( $sales_agent ) : $sales_agent;
				$commission_percentage = Actions::get_agent_commission( $single_agent );
			}

			$commission_id = 0;
			$commission    = $this->agentCommission->get_commission_by_order_id( $post_id );
			if ( isset( $commission->id ) ) {
				$commission_id = $commission->id;
			}

			$agent_names = array();
			if ( is_string( $sales_agent ) && strpos( $sales_agent, ',' ) !== false ) {
				$sales_agent = array_map( 'trim', explode( ',', $sales_agent ) );
			}
			if ( is_array( $sales_agent ) ) {
				foreach ( $sales_agent as $sid ) {
					$agent_names[] = get_the_title( $sid );
				}
			} else {
				$agent_names[] = get_the_title( $sales_agent );
			}
			$agent_names_str = implode( ', ', $agent_names );

			if ( ! empty( $old_agent ) ) {
				$old_agent_names = array();
				if ( is_array( $old_agent ) ) {
					foreach ( $old_agent as $sid ) {
						$old_agent_names[] = get_the_title( $sid ); }
				} else {
					$old_agent_names[] = get_the_title( $old_agent );
				}
				$old_agent_names_str = implode( ', ', $old_agent_names );

				if ( $agent_names_str !== $old_agent_names_str ) {
					$order->add_order_note(
						sprintf(
							'Order sales agent has been updated from %1$s to %2$s',
							$old_agent_names_str,
							$agent_names_str
						)
					);
				}
			} else {
				$order->add_order_note(
					sprintf(
						'Order sales agent has been updated to %1$s',
						$agent_names_str
					)
				);
			}

			$order->update_meta_data( 'sales_agent', implode( ',', (array) $sales_agent ) );
			$order->update_meta_data( 'sales_agent_commision', $commission_percentage );
			$order->save();
		}
	}

	/**
	 * Add admin order list filter
	 *
	 * @global type $typenow
	 */
	public function add_order_list_filter_callback() {
		global $typenow;

		if ( in_array( $typenow, wc_get_order_types( 'order-meta-boxes' ), true ) ) {
			$this->render_filters();
		}
	}

	/**
	 * Render filter
	 */
	public function render_filters() {
		?>

		<select class="wc-agent-search" id="salas_agent" name="sales_agent" data-placeholder="<?php esc_attr_e( 'Sales Agent', 'woocommerce-wholesale-pricing' ); ?>" data-allow_clear="true">
		<?php
		$sales_agent = ( isset( $_GET['sales_agent'] ) && sanitize_text_field( $_GET['sales_agent'] ) ) ? sanitize_text_field( $_GET['sales_agent'] ) : '';

		if ( $sales_agent ) {
			?>
				<option value="<?php echo esc_attr( $sales_agent ); ?>" selected="selected"><?php echo esc_html( get_the_title( $sales_agent ) ); ?></option>
		<?php } ?>
		</select>

		<input type="hidden" name="order_nonce" value="<?php echo esc_attr( wp_create_nonce( __FILE__ ) ); ?>">
		<?php
	}

	/**
	 * Handle any filters.
	 *
	 * @param  array $query_vars Query vars.
	 * @return array
	 */
	public function request_query( $query_vars ) {
		global $typenow;

		if ( in_array( $typenow, wc_get_order_types( 'order-meta-boxes' ), true ) ) {
			if ( ! empty( $_GET['sales_agent'] ) ) { // WPCS: input var ok.
				// @codingStandardsIgnoreStart.
				$agent_id = (int) $_GET['sales_agent'];
				$agent_meta_query = array(
					'relation' => 'OR',
					array(
						'key'     => 'sales_agent',
						'value'   => $agent_id,
						'compare' => '=',
					),
					array(
						'key'     => 'sales_agent',
						'value'   => $agent_id . ',%',
						'compare' => 'LIKE',
					),
					array(
						'key'     => 'sales_agent',
						'value'   => '%,' . $agent_id,
						'compare' => 'LIKE',
					),
					array(
						'key'     => 'sales_agent',
						'value'   => '%,' . $agent_id . ',%',
						'compare' => 'LIKE',
					),
					array(
						'key'     => 'sales_agent',
						'value'   => 'i:' . $agent_id . ';',
						'compare' => 'LIKE',
					),
					array(
						'key'     => 'sales_agent',
						'value'   => ':"' . $agent_id . '";',
						'compare' => 'LIKE',
					),
				);

				if ( ! empty( $query_vars['meta_query'] ) ) {
					$query_vars['meta_query'][] = $agent_meta_query;
				} else {
					$query_vars['meta_query'] = array(
						$agent_meta_query,
					);
				}
				// @codingStandardsIgnoreEnd
			}
		}

		return $query_vars;
	}

	public function send_new_order_email_to_agent( $recipient, $order ) {

		if ( ! empty( $order ) && 'enabled' === get_option( 'agent_email_notification' ) ) {

			$order_id      = $order->get_id();
			$agent_id_meta = $order->get_meta( 'sales_agent', true );
			if ( is_string( $agent_id_meta ) && strpos( $agent_id_meta, ',' ) !== false ) {
				$agent_id_meta = array_map( 'trim', explode( ',', $agent_id_meta ) );
			}
			$agent_ids = is_array( $agent_id_meta ) ? $agent_id_meta : ( ! empty( $agent_id_meta ) ? array( $agent_id_meta ) : array() );

			foreach ( $agent_ids as $agent_id ) {
				$user_id = get_post_meta( $agent_id, 'assign_user', true );
				if ( $user_id ) {
					$user_info = get_userdata( $user_id );
					if ( $user_info ) {
						$recipient = $recipient . ', ' . $user_info->user_email;
					}
				}
			}
		}

		return $recipient;
	}

	public function wc_agent_add_columns( $columns ) {

		if ( function_exists( 'wc_get_page_screen_id' ) ) {
			// add columns for legacy shop order
			$screen_id = wc_get_page_screen_id( 'shop-order' );
			add_filter( 'manage_edit-shop_order_columns', array( $this, 'wc_agent_columns_function' ) );
			add_action( 'manage_shop_order_posts_custom_column', array( $this, 'wc_agent_column_data' ), 10, 2 );

			// add columns for HPOS shop order
			add_action( 'woocommerce_shop_order_list_table_columns', array( $this, 'wc_agent_columns_function' ) );
			add_action( 'woocommerce_shop_order_list_table_custom_column', array( $this, 'wc_agent_column_data' ), 10, 2 );

		}
	}

	public function wc_agent_columns_function( $columns ) {

		unset( $columns['order_total'] );

		$columns['wc_agent']            = esc_html__( 'Sales Agent', 'woocommerce-wholesale-pricing' );
		$columns['wc_agent_commission'] = esc_html__( 'Commission Amount', 'woocommerce-wholesale-pricing' );

		if ( ! isset( $columns['order_total'] ) ) {
			$columns['order_total'] = esc_html__( 'Total', 'woocommerce' );
		}

		return $columns;
	}

	public function wc_agent_column_data( $column, $post_id ) {

		$order            = wc_get_order( $post_id );
		$agent_id_meta    = $order->get_meta( 'sales_agent', true );
		$agent_ids        = normalize_agent_ids( $agent_id_meta );
		$primary_agent_id = ! empty( $agent_ids ) ? (int) reset( $agent_ids ) : 0;

		switch ( $column ) {

			case 'wc_agent':
				if ( empty( $agent_ids ) ) {
					echo esc_html__( 'No Agent', 'woocommerce-wholesale-pricing' );
				} else {
					$names = array();
					foreach ( $agent_ids as $aid ) {
						$title = get_the_title( $aid );
						if ( $title ) {
							$names[] = $title;
						}
					}
					echo ! empty( $names ) ? esc_html( implode( ', ', $names ) ) : esc_html__( 'No Agent', 'woocommerce-wholesale-pricing' );
				}
				break;

			case 'wc_agent_commission':
				if ( ! $primary_agent_id ) {
					echo '-';
					break;
				}
				$subtotal_commission = $this->resolve_commission_data_for_order( $order, $primary_agent_id );
				$product_commission  = isset( $subtotal_commission['product_commission'] ) ? (float) $subtotal_commission['product_commission'] : 0;
				echo $product_commission > 0 ? wp_kses_post( wc_price( $product_commission ) ) : '-';
				break;
		}
	}
}