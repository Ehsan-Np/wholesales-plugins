<?php

namespace WooCommerceWholesalePricing\App\Modules\SalesAgent\Emails;

use WooCommerceWholesalePricing\App\Modules\SalesAgent\Traits\CalculateCommission;

class OrderEmail extends \WC_Email {

	use CalculateCommission;

	public function __construct() {
		$this->id             = 'safw_on_order';
		$this->title          = __( 'SAFW Order Email', 'woocommerce-wholesale-pricing' );
		$this->description    = __( 'SAFW order email are sent to Sales Agent & Admin when a new order is received.', 'woocommerce-wholesale-pricing' );
		$this->template_base  = WWP_PLUGIN_PATH . 'resources/views/admin/sales-agent/';
		$this->template_html  = 'emails/safw-order-temp.php';
		$this->template_plain = 'emails/plain/safw-order-plain-temp.php';
		$this->customer_email = true;

		$this->placeholders = array(
			'{user_name}'           => '',
			'{customer_name}'       => '',
			'{order_dateTIme}'      => '',
			'{agent_name}'          => '',
			'{order_id}'            => '',
			'{order_price}'         => '',
			'{commission_category}' => '',
			'{commission_amount}'   => '',

		);

		add_action( 'safw_email_on_order', array( $this, 'trigger' ), 10, 3 );

		parent::__construct();

		add_filter( 'woocommerce_settings_api_form_fields_safw_on_order', array( $this, 'safw_on_order_custom_field' ) );
	}

	public function trigger( $order_id, $agent_id, $order ) {
		$this->setup_locale();
		$safw_order_email_settings = get_option( 'woocommerce_' . $this->id . '_settings', true );

		if ( $order_id && ! is_a( $order, 'WC_Order' ) ) {
			$order = wc_get_order( $order_id );
		}
		$safw_order_status = isset( $safw_order_email_settings['safw_order_status'] ) ? $safw_order_email_settings['safw_order_status'] : '';


		if ( 'wc-' . $order->get_status() != $safw_order_status ) {
			return;
		}

		$category_id = get_post_meta( $agent_id, 'commission_category', true );
		$terms       = get_term( $category_id, 'commission_cat' );

		$agent_user_id = get_post_meta( $agent_id, 'assign_user', true );
		$user_data     = get_userdata( $agent_user_id );

		if ( ! $user_data ) {
			return;
		}

		$this->recipient = $user_data->user_email . ',' . get_option( 'admin_email' );

		$commission      = $order->get_meta( 'sales_agent_commision', true );
		$commission_data = $this->calculate_commission( $commission, $agent_id, $order, true );

		if ( isset( $commission_data['commission_set_flag'] ) && ! $commission_data['commission_set_flag'] ) {
			return;
		}

		if ( is_a( $order, 'WC_Order' ) ) {
			$this->object                                = $order;
			$this->placeholders['{user_name}']           = $this->object->get_user()->display_name;
			$this->placeholders['{customer_name}']       = $this->object->get_billing_first_name() . ' ' . $this->object->get_billing_last_name();
			$this->placeholders['{order_dateTIme}']      = wc_format_datetime( $this->object->get_date_created() );
			$this->placeholders['{agent_name}']          = get_the_title( $agent_id );
			$this->placeholders['{order_id}']            = $this->object->get_order_number();
			$this->placeholders['{order_price}']         = get_woocommerce_currency_symbol() . ' ' . $this->object->get_total();
			$this->placeholders['{commission_category}'] = ( ! is_wp_error( $terms ) && ! empty( $terms ) ) ? $terms->name : '';
			$this->placeholders['{commission_amount}']   = get_woocommerce_currency_symbol() . ' ' . $commission_data['product_commission'];
		}

		if ( $this->is_enabled() && $this->get_recipient() ) {
			$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		}

		$this->restore_locale();
	}

	public function get_content_html() {
		$args = array(
			'order'               => $this->object,
			'email_heading'       => $this->get_heading(),
			'additional_content'  => $this->get_additional_content(),
			'email'               => $this,
			'site_title'          => $this->placeholders['{site_title}'],
			'site_address'        => $this->placeholders['{site_address}'],
			'site_url'            => $this->placeholders['{site_url}'],
			'user_name'           => $this->placeholders['{user_name}'],
			'customer_name'       => $this->placeholders['{customer_name}'],
			'order_dateTIme'      => $this->placeholders['{order_dateTIme}'],
			'agent_name'          => $this->placeholders['{agent_name}'],
			'order_id'            => $this->placeholders['{order_id}'],
			'order_price'         => $this->placeholders['{order_price}'],
			'commission_category' => $this->placeholders['{commission_category}'],
			'commission_amount'   => $this->placeholders['{commission_amount}'],
		);

		extract( $args );
		ob_start();
		include WWP_PLUGIN_PATH . 'resources/views/admin/sales-agent/' . $this->template_html;
		return ob_get_clean();
	}

	public function get_content_plain() {
		$args = array(
			'order'               => $this->object,
			'email_heading'       => $this->get_heading(),
			'additional_content'  => $this->get_additional_content(),
			'email'               => $this,
			'site_title'          => $this->placeholders['{site_title}'],
			'site_address'        => $this->placeholders['{site_address}'],
			'site_url'            => $this->placeholders['{site_url}'],
			'user_name'           => $this->placeholders['{user_name}'],
			'customer_name'       => $this->placeholders['{customer_name}'],
			'order_dateTIme'      => $this->placeholders['{order_dateTIme}'],
			'agent_name'          => $this->placeholders['{agent_name}'],
			'order_id'            => $this->placeholders['{order_id}'],
			'order_price'         => $this->placeholders['{order_price}'],
			'commission_category' => $this->placeholders['{commission_category}'],
			'commission_amount'   => $this->placeholders['{commission_amount}'],
		);

		extract( $args );

		ob_start();
		include WWP_PLUGIN_PATH . 'resources/views/admin/sales-agent/' . $this->template_plain;
		return ob_get_clean();
	}

	public function safw_on_order_custom_field( $form_field ) {

		$form_field['safw_order_status'] = array(
			'title'       => __( 'Order Status', 'woocommerce-wholesale-pricing' ),
			'type'        => 'select',
			'description' => __( 'Choose order status on which email will sent.', 'woocommerce-wholesale-pricing' ),
			'default'     => 'wc-processing',
			'options'     => wc_get_order_statuses(),
			'desc_tip'    => true,
		);

		return $form_field;
	}

	public function get_default_subject() {
		return __( '[{site_title}]: SAFW On Order #{order_id}', 'woocommerce-wholesale-pricing' );
	}

	public function get_default_heading() {
		return __( 'SAFW On Order: #{order_id}', 'woocommerce-wholesale-pricing' );
	}
}
