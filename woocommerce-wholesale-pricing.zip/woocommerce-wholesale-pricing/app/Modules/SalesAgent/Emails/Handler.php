<?php

namespace WooCommerceWholesalePricing\App\Modules\SalesAgent\Emails;

class Handler {
	public function __construct() {

		add_filter( 'woocommerce_email_actions', array( $this, 'email_actions' ) );
		add_filter( 'woocommerce_email_classes', array( $this, 'email_notifications' ), 10, 1 );
		add_filter( 'woocommerce_template_directory', array( $this, 'template_directory' ), 10, 2 );
	}

	public function email_actions( $email_actions ) {
		array_push(
			$email_actions,
			'safw_email_on_order',
			'safw_email_assign_agent',
			'safw_email_assign_comm_cat',
			'safw_payout_status'
		);

		return $email_actions;
	}

	public function template_directory( $str, $template ) {
		return 'woocommerce-wholesale-pricing';
	}

	public function email_notifications( $emails ) {

		$emails['OrderEmail']   = new OrderEmail();
		$emails['AssigningAgent']   = new AssigningAgent();
		$emails['AssigningCommissionCategory'] = new AssigningCommissionCategory();
		$emails['PayoutStatus'] = new PayoutStatus();

		return $emails;
	}
}
