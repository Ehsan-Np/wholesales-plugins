<?php
namespace WooCommerceWholesalePricing\App\Modules\SalesAgent\Emails;

class PayoutStatus extends \WC_Email {

	public function __construct() {

		$this->id             = 'safw_payout_status';
		$this->title          = __( 'SAFW Payout Status', 'woocommerce-wholesale-pricing' );
		$this->description    = __( 'SAFW Payout Status emails are sent to Sales Agent when a payout status will change to paid.', 'woocommerce-wholesale-pricing' );
		$this->template_base  = WWP_PLUGIN_PATH . 'resources/views/admin/sales-agent/';
		$this->template_html  = 'emails/safw-payout-status-temp.php';
		$this->template_plain = 'emails/plain/safw-payout-status-plain-temp.php';
		$this->customer_email = true;
		$this->placeholders   = array(
			'{agent_name}'          => '',
			'{payout_amount}'       => '',
			'{commission_category}' => '',
		);

		add_action( 'safw_payout_status_notification', array( $this, 'trigger' ), 10, 2 );

		parent::__construct();
	}

	public function trigger( $agent_id, $payout_amount ) {

		$this->setup_locale();

		$category_id = get_post_meta( $agent_id, 'commission_category', true );
		$terms       = get_term( $category_id, 'commission_cat' );

		$agent_user_id = get_post_meta( $agent_id, 'assign_user', true );
		$user_data     = get_userdata( $agent_user_id );

		if ( $user_data ) {
			$this->recipient = $user_data->user_email;
		}

		$this->placeholders['{agent_name}']          = get_the_title( $agent_id );
		$this->placeholders['{payout_amount}']       = $payout_amount;
		$this->placeholders['{commission_category}'] = ( ! is_wp_error( $terms ) && ! empty( $terms ) ) ? $terms->name : '';

		if ( $this->is_enabled() && $this->get_recipient() ) {
			$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		}

		$this->restore_locale();
	}

	public function get_content_html() {
		$args = array(
			'email_heading'       => $this->get_heading(),
			'additional_content'  => $this->get_additional_content(),
			'email'               => $this,
			'site_title'          => $this->placeholders['{site_title}'],
			'site_address'        => $this->placeholders['{site_address}'],
			'site_url'            => $this->placeholders['{site_url}'],
			'agent_name'          => $this->placeholders['{agent_name}'],
			'payout_amount'       => $this->placeholders['{payout_amount}'],
			'commission_category' => $this->placeholders['{commission_category}'],
		);

		extract( $args );

		ob_start();
		include WWP_PLUGIN_PATH . 'resources/views/admin/sales-agent/' . $this->template_html;
		return ob_get_clean();
	}

	public function get_content_plain() {
		$args = array(
			'email_heading'       => $this->get_heading(),
			'additional_content'  => $this->get_additional_content(),
			'email'               => $this,
			'site_title'          => $this->placeholders['{site_title}'],
			'site_address'        => $this->placeholders['{site_address}'],
			'site_url'            => $this->placeholders['{site_url}'],
			'agent_name'          => $this->placeholders['{agent_name}'],
			'payout_amount'       => $this->placeholders['{payout_amount}'],
			'commission_category' => $this->placeholders['{commission_category}'],
		);

		extract( $args );

		ob_start();
		include WWP_PLUGIN_PATH . 'resources/views/admin/sales-agent/' . $this->template_plain;
		return ob_get_clean();
	}

	public function get_default_subject() {
		return __( '[{site_title}]: Payout Status Has Been Paid.', 'woocommerce-wholesale-pricing' );
	}

	public function get_default_heading() {
		return __( 'Payout Status Has Been Paid.', 'woocommerce-wholesale-pricing' );
	}
}
