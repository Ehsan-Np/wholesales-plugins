<?php

namespace WooCommerceWholesalePricing\App\Modules\SalesAgent\Traits;

trait CalculateCommission {

	public function calculate_commission( $commission, $agent_id, $order, $is_admin = false, $subtotal_cal_comm = false, $order_item = false, $new_status = false ) {
		// Support for Multi-Agent numeric percentage inputs
		if ( is_numeric( $commission ) ) {
			$percentage = (float) $commission;
			$comm_type  = 'percentage';
			$comm_value = $percentage;

			if ( $order_item ) {
				$product_subtotal = (float) $order_item->get_subtotal();
				$amount           = $product_subtotal * $percentage / 100;
			} else {
				// total commission for the whole order
				$amount = $order->get_total() * $percentage / 100;
			}

			return array(
				'product_commission' => $amount,
				'commission_type'    => $comm_type,
				'commission_value'   => $comm_value,
			);
		}

		// Normalize agent ID for legacy logic
		$agent_ids = is_array( $agent_id ) ? $agent_id : ( ! empty( $agent_id ) ? array( $agent_id ) : array() );
		$agent_id  = ! empty( $agent_ids ) ? reset( $agent_ids ) : 0;

		$commission_prod_cat  = isset( $commission['commission_prod_cat'] ) ? $commission['commission_prod_cat'] : '';
		$commission_product   = isset( $commission['commission_products'] ) ? (array) $commission['commission_products'] : array();
		$commission_category  = isset( $commission['commission_category'] ) ? (array) $commission['commission_category'] : array();
		$ind_prod_comm        = isset( $commission['indi_prod_comm'] ) ? $commission['indi_prod_comm'] : '';
		$per_quantity         = isset( $commission['per_quantity'] ) ? $commission['per_quantity'] : '';
		$commission_system    = isset( $commission['commission_system'] ) ? $commission['commission_system'] : '';
		$lvl_prod_comm        = isset( $commission['lvl_prod_comm'] ) ? $commission['lvl_prod_comm'] : '';

		if ( empty( $commission_prod_cat ) ) {
			$commission_prod_cat = 'commission_on_prod';
		}

		$product_commission  = 0.00;
		$coupon_amount       = $order->get_total_discount();
		$items               = $order->get_items();
		$commission_type     = '';
		$commission_value    = '';
		
		if ( 'commission_on_cat' == $commission_prod_cat ) {
			if ( $order_item && ! empty( $order_item ) ) {
				// Always get the parent product ID for category checking
				$variation_id      = $order_item->get_variation_id();
				$prod_id           = $order_item->get_product_id(); // parent product
				$actual_product_id = ! empty( $variation_id ) ? $variation_id : $prod_id;

				// Individual product commission meta
				$per_prod_data = get_post_meta( $actual_product_id, 'individual_prod_data', true );

				// Fallback to parent product commission if variation commission is not set
				if ( ! empty( $variation_id ) && ( empty( $per_prod_data ) || ( isset( $per_prod_data['per_prod_commission'] ) && 'no' === $per_prod_data['per_prod_commission'] ) ) ) {
					$per_prod_data = get_post_meta( $prod_id, 'individual_prod_data', true );
				}

				$commission_type   = isset( $commission['commission_type'] ) ? $commission['commission_type'] : '';
				$commission_value  = isset( $commission['commission_value'] ) ? $commission['commission_value'] : '';
				$commission_system = isset( $commission['commission_system'] ) ? $commission['commission_system'] : '';
				$ind_prod_comm     = isset( $commission['indi_prod_comm'] ) ? $commission['indi_prod_comm'] : '';

				// Override commission if individual product commission is set
				if ( ! empty( $ind_prod_comm ) ) {
					if ( isset( $per_prod_data['per_prod_commission'] ) && 'yes' === $per_prod_data['per_prod_commission'] && ! empty( $per_prod_data['commission_value'] ) ) {
						$commission_type  = isset( $per_prod_data['commission_type'] ) ? $per_prod_data['commission_type'] : '';
						$commission_value = isset( $per_prod_data['commission_value'] ) ? $per_prod_data['commission_value'] : '';
					}
				}

				$is_eligible = $this->commission_category_is_eligible( $prod_id, $commission_category );

				if ( $is_eligible ) {
					if ( 'percentage' === $commission_type ) {
						if ( isset( $per_quantity ) && ! empty( $per_quantity ) ) {
							$item_price = $order_item->get_total();
						} elseif ( $order_item && 'earning-basis' === $commission_system ) {
							$item_price = $order_item->get_total();
						} else {
							$item_price = $order->get_item_total( $order_item, false, true );
						}
						$product_commission  = $item_price * $commission_value / 100;
						$commission_set_flag = true;
					} elseif ( 'fixed' === $commission_type ) {
						$product_commission  = $commission_value;
						$commission_set_flag = true;
					}
				} else {
					$commission_type  = '__';
					$commission_value = '__';
				}
			} else {
				foreach ( $items as $item ) {
					$order_product_id = $item->get_product_id(); // Simple or parent product
					$variation_id     = $item->get_variation_id();
					$product          = $item->get_product();

					// In case of variation, get the parent as well
					$product_id_to_check = $product->is_type( 'variation' ) ? $product->get_parent_id() : $order_product_id;

					// For matching: include variation ID, product ID, and parent (if different)
					$product_ids_for_matching = array_filter(
						array(
							$order_product_id,
							$variation_id,
							$product_id_to_check,
						)
					);

					// Use variation ID if available (for fetching per product meta)
					$order_products_id = ! empty( $variation_id ) ? $variation_id : $order_product_id;

					$is_eligible = $this->commission_category_is_eligible( $product_id_to_check, $commission_category );

					if ( $is_eligible ) {
						$per_prod_data = get_post_meta( $order_products_id, 'individual_prod_data', true );

						// Fallback to parent product commission if variation commission is not set
						if ( ! empty( $variation_id ) && ( empty( $per_prod_data ) || ( isset( $per_prod_data['per_prod_commission'] ) && 'no' === $per_prod_data['per_prod_commission'] ) ) ) {
							$per_prod_data = get_post_meta( $order_product_id, 'individual_prod_data', true );
						}

						$commission_type  = isset( $commission['commission_type'] ) ? $commission['commission_type'] : '';
						$commission_value = isset( $commission['commission_value'] ) ? $commission['commission_value'] : '';

						if ( isset( $ind_prod_comm ) && ! empty( $ind_prod_comm ) ) {
							if ( ( isset( $per_prod_data['per_prod_commission'] ) && 'yes' === $per_prod_data['per_prod_commission'] ) && ( isset( $per_prod_data['commission_value'] ) && ! empty( $per_prod_data['commission_value'] ) ) ) {
								$commission_type  = isset( $per_prod_data['commission_type'] ) ? $per_prod_data['commission_type'] : '';
								$commission_value = isset( $per_prod_data['commission_value'] ) ? $per_prod_data['commission_value'] : '';
							}
						}

						if ( 'percentage' == $commission_type ) {
							if ( isset( $per_quantity ) && ! empty( $per_quantity ) ) {
								$item_price = (float) $item->get_total();
							} else {
								$item_price = $order->get_item_total( $item, false, true );
							}
							$product_commission += ( $item_price * $commission_value / 100 );
							$commission_set_flag = true;
						} elseif ( 'fixed' == $commission_type ) {
							$product_commission += $commission_value;
							$commission_set_flag = true;
						}
					}
				}
			}
		} elseif ( 'commission_on_prod' === $commission_prod_cat ) {
			if ( $order_item && ! empty( $order_item ) ) {
				$variation_products_id = $order_item->get_variation_id();
				if ( ! empty( $variation_products_id ) ) {
					$prod_id = $variation_products_id;
				} else {
					$prod_id = $order_item->get_product_id();
				}
				$per_prod_data = get_post_meta( $prod_id, 'individual_prod_data', true );

				// Fallback to parent product commission if variation commission is not set
				if ( ! empty( $variation_products_id ) && ( empty( $per_prod_data ) || ( isset( $per_prod_data['per_prod_commission'] ) && 'no' === $per_prod_data['per_prod_commission'] ) ) ) {
					$parent_id     = $order_item->get_product_id();
					$per_prod_data = get_post_meta( $parent_id, 'individual_prod_data', true );
				}

				// Initial defaults from category
				$commission_type  = isset( $commission['commission_type'] ) ? $commission['commission_type'] : '';
				$commission_value = isset( $commission['commission_value'] ) ? $commission['commission_value'] : '';
				
				// Check for Individual Product Override
				if ( isset( $ind_prod_comm ) && ! empty( $ind_prod_comm ) ) {
					if ( isset( $per_prod_data['per_prod_commission'] ) && 'yes' === $per_prod_data['per_prod_commission'] && ! empty( $per_prod_data['commission_value'] ) ) {
						$commission_type  = isset( $per_prod_data['commission_type'] ) ? $per_prod_data['commission_type'] : '';
						$commission_value = isset( $per_prod_data['commission_value'] ) ? $per_prod_data['commission_value'] : '';
					}
				}

				$parent_id     = $order_item->get_product_id();
				$is_eligible   = $this->commission_product_is_eligible( $parent_id, $variation_products_id, $commission_product );

				if ( $is_eligible ) {
					if ( 'percentage' == $commission_type ) {
						if ( isset( $per_quantity ) && ! empty( $per_quantity ) ) {
							$item_price = $order_item->get_subtotal();
						} elseif ( $order_item && isset( $commission_system ) && 'earning-basis' === $commission_system ) {
							$item_price = $order_item->get_subtotal();
						} else {
							$item_price = $order->get_item_total( $order_item, false, true );
						}
						$product_commission  = $item_price * $commission_value / 100;
						$commission_set_flag = true;
					} elseif ( 'fixed' == $commission_type ) {
						$product_commission  = $commission_value;
						$commission_set_flag = true;
					}
				} else {
					$commission_type  = '__';
					$commission_value = '__';
				}
			} else {
				foreach ( $items as $item ) {

					$variation_products_id = $item->get_variation_id();
					if ( ! empty( $variation_products_id ) ) {
						$order_products_id = $variation_products_id;
					} else {
						$order_products_id = $item->get_product_id();
					}

					$parent_id   = $item->get_product_id();
					$is_eligible = $this->commission_product_is_eligible( $parent_id, $variation_products_id, $commission_product );

					if ( $is_eligible ) {
						
						$per_prod_data = get_post_meta( $order_products_id, 'individual_prod_data', true );

						// Fallback to parent product commission if variation commission is not set
						if ( ! empty( $variation_products_id ) && ( empty( $per_prod_data ) || ( isset( $per_prod_data['per_prod_commission'] ) && 'no' === $per_prod_data['per_prod_commission'] ) ) ) {
							$per_prod_data = get_post_meta( $parent_id, 'individual_prod_data', true );
						}

						// Initial defaults from category for this item
						$commission_type  = isset( $commission['commission_type'] ) ? $commission['commission_type'] : '';
						$commission_value = isset( $commission['commission_value'] ) ? $commission['commission_value'] : '';

						// Check for Individual Product Override
						if ( isset( $ind_prod_comm ) && ! empty( $ind_prod_comm ) ) {
							if ( isset( $per_prod_data['per_prod_commission'] ) && 'yes' === $per_prod_data['per_prod_commission'] && ! empty( $per_prod_data['commission_value'] ) ) {
								$commission_type  = isset( $per_prod_data['commission_type'] ) ? $per_prod_data['commission_type'] : '';
								$commission_value = isset( $per_prod_data['commission_value'] ) ? $per_prod_data['commission_value'] : '';
							}
						}

						if ( 'percentage' == $commission_type ) {
							if ( isset( $per_quantity ) && ! empty( $per_quantity ) ) {
								$item_price = (float) $item->get_total();
							} else {
								$item_price = $order->get_item_total( $item, false, true );
							}
							$product_commission += ( $item_price * $commission_value / 100 );
							$commission_set_flag = true;
						} elseif ( 'fixed' == $commission_type ) {
							$product_commission += $commission_value;
							$commission_set_flag = true;
						}
					}
				}
			}
		} elseif ( $order_item && ! empty( $order_item ) ) {
			$order_product_id = $order_item->get_product_id();
			$variation_id     = $order_item->get_variation_id();
			$product          = $order_item->get_product();

			$product_id_to_check = $product->is_type( 'variation' ) ? $product->get_parent_id() : $order_product_id;

			$product_ids_for_matching = array_filter(
				array(
					$order_product_id,
					$variation_id,
					$product_id_to_check,
				)
			);

			// Use variation ID if available for individual product data
			$order_products_id = ! empty( $variation_id ) ? $variation_id : $order_product_id;
			
			if ( ! $this->commission_product_is_eligible( $order_product_id, $variation_id, $commission_product ) ) {
				return array(
					'product_commission' => '__',
					'commission_type'    => '__',
					'commission_value'   => '__',
				);
			}

			$per_prod_data    = get_post_meta( $order_products_id, 'individual_prod_data', true );
			$commission_type  = isset( $commission['commission_type'] ) ? $commission['commission_type'] : '';
			$commission_value = isset( $commission['commission_value'] ) ? $commission['commission_value'] : '';

			if ( isset( $ind_prod_comm ) && ! empty( $ind_prod_comm ) ) {
				if (
					isset( $per_prod_data['per_prod_commission'] ) && 'yes' === $per_prod_data['per_prod_commission']
					&& isset( $per_prod_data['commission_value'] ) && ! empty( $per_prod_data['commission_value'] )
				) {
					$commission_type  = isset( $per_prod_data['commission_type'] ) ? $per_prod_data['commission_type'] : '';
					$commission_value = isset( $per_prod_data['commission_value'] ) ? $per_prod_data['commission_value'] : '';

				}
			}

			if ( 'percentage' === $commission_type ) {
				if ( isset( $per_quantity ) && ! empty( $per_quantity ) ) {
					$item_price = $order_item->get_subtotal();
				} elseif ( $order_item && isset( $commission_system ) && 'earning-basis' === $commission_system ) {
					$item_price = $order_item->get_subtotal();
				} else {
					$item_price = $order->get_item_total( $order_item, false, true );
				}
				$product_commission  = $item_price * $commission_value / 100;
				$commission_set_flag = true;
			} elseif ( 'fixed' === $commission_type ) {
				$product_commission  = $commission_value;
				$commission_set_flag = true;
			}
		} else {
			foreach ( $items as $item ) {
				$order_product_id = $item->get_product_id(); // Simple or parent product
				$variation_id     = $item->get_variation_id();
				$product          = $item->get_product();

				// In case of variation, get the parent as well
				if ( $product && is_a( $product, 'WC_Product' ) ) {
					// In case of variation, get the parent as well
					$product_id_to_check = $product->is_type( 'variation' ) ? $product->get_parent_id() : $order_product_id;
				} else {
					// Fallback or skip logic (if needed)
					$product_id_to_check = $order_product_id;
				}

				// For matching: include variation ID, product ID, and parent (if different)
				$product_ids_for_matching = array_filter(
					array(
						$order_product_id,
						$variation_id,
						$product_id_to_check,
					)
				);
				// Use variation ID if available (for fetching per product meta)
				$order_products_id = ! empty( $variation_id ) ? $variation_id : $order_product_id;

				$per_prod_data    = get_post_meta( $order_products_id, 'individual_prod_data', true );
				$commission_type  = isset( $commission['commission_type'] ) ? $commission['commission_type'] : '';
				$commission_value = isset( $commission['commission_value'] ) ? $commission['commission_value'] : '';
				if ( isset( $lvl_prod_comm ) && ! empty( $lvl_prod_comm ) ) {
					if ( isset( $commission['lvl_based_comm'] ) ) {
						$level_based_commission = $commission['lvl_based_comm'];

						if ( ! empty( $level_based_commission ) ) {
							$total_commission = 0;

							foreach ( $order->get_items() as $item ) {
								$order_product_id = $item->get_product_id();   // For variations, this is variation ID
								$product_subtotal = $item->get_subtotal();
								$product          = $item->get_product();
								$matching_id      = $product->is_type( 'variation' ) ? $product->get_id() : $order_product_id; // treat each variation separately
								$product_cats     = wp_get_post_terms( $matching_id, 'product_cat', array( 'fields' => 'ids' ) );

								$commission_applied = false;
								$commission_type    = '';
								$commission_value   = 0;
								$product_commission = 0;

								// Check rules with priority: ALL > PRODUCT > CATEGORY
								foreach ( $level_based_commission as $commission_rule ) {

									// 1️⃣ "All" checkbox
									if ( isset( $commission_rule['all'] ) && 'yes' === $commission_rule['all'] ) {
										$commission_type    = $commission_rule['commission_value_type'];
										$commission_value   = (float) $commission_rule['commission_value'];
										$commission_applied = true;
									} elseif ( ! $commission_applied && 'product' === $commission_rule['type'] && in_array( $matching_id, $commission_rule['category_ids'] ) ) {
										$commission_type    = $commission_rule['commission_value_type'];
										$commission_value   = (float) $commission_rule['commission_value'];
										$commission_applied = true;
									} elseif ( ! $commission_applied && 'category' === $commission_rule['type'] && array_intersect( $product_cats, $commission_rule['category_ids'] ) ) {
										$commission_type    = $commission_rule['commission_value_type'];
										$commission_value   = (float) $commission_rule['commission_value'];
										$commission_applied = true;
									}

									// Stop loop once a commission is applied
									if ( $commission_applied ) {
										if ( 'percentage' === $commission_type ) {
											$product_commission = $product_subtotal * $commission_value / 100;
										} elseif ( 'fixed' === $commission_type ) {
											$product_commission = $commission_value;
										} else {
											$product_commission = 0;
										}
										break; // ✅ Only one commission per product/variation
									}
								}

								// Add to total
								$total_commission += $product_commission;
							}

							return array(
								'product_commission' => $total_commission,
								'commission_type'    => $commission_type,
								'commission_value'   => $commission_value,
							);
						}
					}
				}

				if ( isset( $ind_prod_comm ) && ! empty( $ind_prod_comm ) && empty( $lvl_prod_comm ) ) {
					if ( ( isset( $per_prod_data['per_prod_commission'] ) && 'yes' === $per_prod_data['per_prod_commission'] ) && ( isset( $per_prod_data['commission_value'] ) && ! empty( $per_prod_data['commission_value'] ) ) ) {
						$commission_type  = isset( $per_prod_data['commission_type'] ) ? $per_prod_data['commission_type'] : '';
						$commission_value = isset( $per_prod_data['commission_value'] ) ? $per_prod_data['commission_value'] : '';
					}
				}
				/**
				 * Filter.
				 *
				 * @since 1.4.5
				 *
				 * To exclude certain products
				 */
				$exclude = apply_filters( 'exclude_products_ids_form_commission', true, $order_products_id, $item );

				$is_eligible = $this->commission_product_is_eligible( $order_product_id, $variation_id, $commission_product );

				if ( $exclude && $is_eligible ) {
					if ( 'percentage' == $commission_type ) {
						if ( isset( $per_quantity ) && ! empty( $per_quantity ) ) {
							$item_price = (float) $item->get_total();
						} elseif ( $is_admin && 'earning-basis' === $commission_system ) {
							$item_price = (float) $item->get_total();
						} else {
							$item_price = $order->get_item_total( $item, false, true );
						}
						$product_commission += ( $item_price * (float) $commission_value / 100 );
						$commission_set_flag = true;
					} elseif ( 'fixed' == $commission_type ) {
						$product_commission += $commission_value;
						$commission_set_flag = true;
					}
				} elseif ( ! $is_eligible ) {
					$commission_type  = '__';
					$commission_value = '__';
				}
			}
		}
		return array(
			'product_commission' => $product_commission,
			'commission_type'    => $commission_type,
			'commission_value'   => $commission_value,
		);
	}

	/**
	 * Whether a line item qualifies under commission-on-product rules.
	 * Empty product list means all products are eligible.
	 *
	 * @param int   $parent_product_id Parent/simple product ID.
	 * @param int   $variation_id      Variation ID, or 0 for simple products.
	 * @param array $commission_products Selected product IDs.
	 * @return bool
	 */
	protected function commission_product_is_eligible( $parent_product_id, $variation_id, $commission_products ) {
		$commission_products = array_filter( array_map( 'absint', (array) $commission_products ) );

		if ( empty( $commission_products ) ) {
			return true;
		}

		$ids_to_check = array( (int) $parent_product_id );
		if ( ! empty( $variation_id ) ) {
			$ids_to_check[] = (int) $variation_id;
		}

		return (bool) array_intersect( $ids_to_check, $commission_products );
	}

	/**
	 * Whether a product qualifies under commission-on-category rules.
	 * Empty category list means all categories are eligible.
	 *
	 * @param int   $product_id            Product ID used for category lookup (parent for variations).
	 * @param array $commission_categories Selected category slugs.
	 * @return bool
	 */
	protected function commission_category_is_eligible( $product_id, $commission_categories ) {
		$commission_categories = array_filter( (array) $commission_categories );
		
		if ( empty( $commission_categories ) ) {
			return true;
		}
		
		$product_cats = wp_get_post_terms( (int) $product_id, 'product_cat', array( 'fields' => 'slugs' ) );

		if ( is_wp_error( $product_cats ) || empty( $product_cats ) ) {
			return false;
		}

		return (bool) array_intersect( $product_cats, $commission_categories );
	}
}
