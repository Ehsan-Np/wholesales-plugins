<?php

namespace WooCommerceWholesalePricing\App\Modules\SalesAgent;

class UserEdit {
	public function __construct() {

		// add agent fileld
		add_action( 'show_user_profile', array( $this, 'wc_user_agent_field' ) );
		add_action( 'edit_user_profile', array( $this, 'wc_user_agent_field' ) );
		add_action( 'user_new_form', array( $this, 'wc_user_agent_field' ) );

		// Saving Updated fields data
		add_action( 'personal_options_update', array( $this, 'wc_save_user_agent_field' ) );
		add_action( 'edit_user_profile_update', array( $this, 'wc_save_user_agent_field' ) );

		add_action( 'user_register', array( $this, 'wc_save_user_agent_field' ) );
		add_action( 'woocommerce_register_form', array( $this, 'custom_nonce_field' ) );

		add_action( 'admin_init', array( $this, 'user_profile_nonce_callback' ) );
	}

	public function wc_user_agent_field( $user ) {
		$is_agent       = Actions::is_agent( $user );

		if ( $is_agent ) {
			return;
		}
		?>
		<h3><?php esc_html_e( 'Assign Agent:', 'woocommerce-wholesale-pricing' ); ?></h3>
		<table class="form-table">
			<tr class="user-job-title-wrap">
			<?php
				$args       = array(
					'post_type'      => 'agent',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'fields'         => 'ids',
				);
				$all_agents = get_posts( $args );

				$agent_filter = '';
				if ( isset( $user->ID ) ) {
					$agent_filter = get_user_meta( $user->ID, 'sales_agent', true );
				}
				?>
				<th>
					<label for="agent-filter"><?php esc_html_e( 'Agent', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<select style="padding: 0 8px" name="agent-filter" class="customer-agent-form regular-text" data-placeholder="<?php esc_attr_e( 'search by agent name', 'woocommerce-wholesale-pricing' ); ?>" >
						<option value="0"><?php echo esc_html__( 'No Agent', 'woocommerce-wholesale-pricing' ); ?></option>
						<?php
						foreach ( $all_agents as $agent_id ) {
							?>
								<option value="<?php echo esc_attr( $agent_id ); ?>" <?php selected( $agent_id, @$agent_filter, true ); ?>><?php echo esc_attr( get_the_title( $agent_id ) ); ?></option>
							<?php
						}
						?>
					</select>
				</td>
			</tr>
			<input type="hidden" name="sales_agent_nonce" value="<?php echo esc_attr( wp_create_nonce( 'sales_agent_nonce' ) ); ?>">
		</table>
		<?php
	}

	/**
	 * Save user commission amount and type
	 *
	 * @param type $user_id
	 */
	public function wc_save_user_agent_field( $user_id ) {

		/**
		 * Filter.
		 *
		 * @since 1.2
		 *
		 * Support Ticket - WOOC-1178.
		 */
		$flag = apply_filters( 'safw_user_registration', false );

		if ( isset( $_POST['action'] ) && 'save_customer_details' !== $_POST['action'] && ! is_admin() ) {
			return;
		}

		if ( $flag ) {
			return;
		}

		if ( ! isset( $_POST['sales_agent_nonce'] ) || ( isset( $_POST['sales_agent_nonce'] ) && ! wp_verify_nonce( sanitize_text_field( $_POST['sales_agent_nonce'] ), 'sales_agent_nonce' ) ) ) {
			return;
		}

		$sales_agent = '';
		if ( isset( $user_id ) ) {
			$sales_agent = get_user_meta( $user_id, 'sales_agent', true );
		}

		if ( isset( $_POST['agent-filter'] ) && ! empty( $_POST['agent-filter'] ) ) {

			update_user_meta( $user_id, 'sales_agent', sanitize_text_field( $_POST['agent-filter'] ) );
			$current_sales_agent = get_user_meta( $user_id, 'sales_agent', true );

			if ( empty( $sales_agent ) || ! ( empty( $sales_agent ) && $sales_agent != $current_sales_agent ) ) {

				update_user_meta( $user_id, 'safw_assign_user_email_sent', true );

			}
		} elseif ( ! isset( $_POST['agent-filter'] ) || empty( $_POST['agent-filter'] ) ) {
			$settings = \WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper::get_pricing_settings();

			
			$default_agent = isset( $settings['sales_agent_default_agent'] ) ? $settings['sales_agent_default_agent'] : '';
			if ( '' == get_user_meta( $user_id, 'default_agent_set', true ) ) {
				update_user_meta( $user_id, 'sales_agent', $default_agent );
				update_user_meta( $user_id, 'default_agent_set', true );

			} else {
				update_user_meta( $user_id, 'sales_agent', '' );
			}
		}
	}

	public function user_profile_nonce_callback() {
		if ( is_admin() ) {
			add_action( 'profile_update', array( $this, 'custom_nonce_field' ) );
			add_action( 'edit_user_profile', array( $this, 'custom_nonce_field' ) );
		}
	}

	public function custom_nonce_field() {
		?>
			<input type="hidden" name="sales_agent_nonce" value="<?php echo esc_attr( wp_create_nonce( 'sales_agent_nonce' ) ); ?>">
		<?php
	}
}