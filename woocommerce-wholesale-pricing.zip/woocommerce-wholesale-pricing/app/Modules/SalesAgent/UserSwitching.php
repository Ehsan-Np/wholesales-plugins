<?php
namespace WooCommerceWholesalePricing\App\Modules\SalesAgent;

class UserSwitching {



	/**
	 * The name used to identify the application during a WordPress redirect.
	 *
	 * @var string
	 */
	public static $application = 'WordPress/User Switching';
	private $endpoint          = 'customer-messages';
	/**
	 * Sets up all the filters and actions.
	 */
	public function init_hooks() {

		add_action( 'woocommerce_account_' . $this->endpoint . '_endpoint', array( $this, 'wc_agent_customer_to_admin_end_point_handle' ) );

		// update name of  my account in agent orders endpoint
		add_filter( 'woocommerce_endpoint_' . $this->endpoint . '_title', array( $this, 'change_my_account_customer_message_title' ), 10, 2 );

		add_filter( 'wc_agent_customer_messages_menu_item', array( $this, 'add_notification_label_to_msg_title' ) );

		add_action( 'wp_ajax_compose_customer_message', array( $this, 'compose_customer_to_agent_message' ) );

		add_action( 'wp_ajax_cust_to_agent_conversation', array( $this, 'cust_to_agent_conversation' ) );

		add_action( 'wp_ajax_customer_mark_read_message_agent', array( $this, 'customer_mark_read_message_agent' ) );
		add_action( 'wp_ajax_customer_mark_as_read_message_view', array( $this, 'customer_mark_as_read_message_view' ) );

		add_action( 'wp_ajax_customer_mark_unread_message_agent', array( $this, 'customer_mark_unread_message_agent' ) );

		add_action( 'wp_ajax_customer_mark_active_thread_agent', array( $this, 'customer_mark_active_thread_agent' ) );

		add_action( 'wp_ajax_customer_mark_inactive_thread_agent', array( $this, 'customer_mark_inactive_thread_agent' ) );

		add_action( 'wp_ajax_fetch_customer_latest_messages', array( $this, 'fetch_customer_latest_messages' ) );

		// Required functionality:
		add_action( 'plugins_loaded', array( $this, 'action_plugins_loaded' ), 999 );
		add_action( 'init', array( $this, 'action_init' ) );
		add_action( 'wp_logout', 'wc_agent_user_switching_clear_olduser_cookie' );
		add_action( 'wp_login', 'wc_agent_user_switching_clear_olduser_cookie' );

		// Nice-to-haves:
		add_filter( 'removable_query_args', array( $this, 'filter_removable_query_args' ) );
		add_action( 'wp_meta', array( $this, 'action_wp_meta' ) );
		add_action( 'wp_body_open', array( $this, 'action_wp_header' ) );
		add_action( 'wp_footer', array( $this, 'action_wp_footer' ) );
		add_action( 'switch_to_user', array( $this, 'forget_woocommerce_session' ) );
		add_action( 'switch_back_user', array( $this, 'forget_woocommerce_session' ) );
	}

	public function add_notification_label_to_msg_title( $title ) {

		$current_user_id        = get_current_user_id();
		$agent_post_id          = get_user_meta( $current_user_id, 'sales_agent', true );
		$old_user               = get_post_meta( $agent_post_id, 'assign_user', true );
		$messages_post_customer = get_user_meta( $old_user, 'customer_messages', true );
		$unread_count           = 0;

		if ( ! empty( $messages_post_customer ) ) {
			foreach ( $messages_post_customer as $unique_id => $agent_message ) {
				$status_cust = isset( $agent_message['status_cust'] ) ? $agent_message['status_cust'] : 'read';
				if ( 'read' === $status_cust && $current_user_id === $agent_message['Cust_id'] ) {
					++$unread_count;
				}
			}
		}
		// Add 'New' tag if there are unread messages
		if ( $unread_count > 0 ) {
			return $title . ' (New)';
		} else {
			return $title;
		}
	}

	/**
	 * Change title in customer endpoint
	 *
	 * @param  type $title
	 * @param  type $endpoint
	 * @return type
	 */
	public function change_my_account_customer_message_title( $title, $endpoint ) {
		return __( 'Customer Messages', 'woocommerce-wholesale-pricing' );
	}

	public function fetch_customer_latest_messages() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'message_nonce' );
		// Check if the current user is logged in
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( 'User not logged in' );
			wp_die();
		}

		// Get user ID and other necessary data
		$user_id                = get_current_user_id();
		$agent_post_id          = get_user_meta( $user_id, 'sales_agent', true );
		$old_user               = get_post_meta( $agent_post_id, 'assign_user', true );
		$messages_post_customer = get_user_meta( $old_user, 'customer_messages', true );

		// Initialize the response variables
		$latest_messages = array();
		$customer_info   = get_userdata( $user_id );
		$customer_name   = $customer_info->display_name;

		$agent_info = get_userdata( $old_user );
		$agent_name = $agent_info->display_name;

		// Track the number of old containers
		$old_container_count = 0;
		foreach ( $messages_post_customer as $unique_id => $agent_message ) {
			if ( 'old' === $agent_message['status_msg'] && $user_id === $agent_message['Cust_id'] ) {
				++$old_container_count;
			}
		}
		$has_new_message = false;
		// Collect latest messages and update status to 'old'
		if ( ! empty( $messages_post_customer ) ) {
			foreach ( $messages_post_customer as $unique_id => $agent_message ) {
				if ( $has_new_message ) {
					break;
				}

				// Start by setting the unique_msg_id to the existing container ID
				$unique_msg_id = $unique_id;

				// Update unique_msg_id if the container itself is new
				if ( 'new' === $agent_message['status_msg'] && $user_id === $agent_message['Cust_id'] ) {
					$unique_msg_id   = 'msg_' . ( $old_container_count + 1 );
					$has_new_message = true;
				}

				// Loop through each agent message to check for new msg_status
				foreach ( $agent_message['messages_agent'] as $key => $agent_sub_message ) {
					if ( is_array( $agent_sub_message ) && isset( $agent_sub_message['msg_status'] ) && 'new' === $agent_sub_message['msg_status'] ) {
						// If there is a new agent message, retain the current unique_id
						$unique_msg_id   = $unique_id;
						$has_new_message = true;

						// Mark this specific message as old
						$messages_post_customer[ $unique_id ]['messages_agent'][ $key ]['msg_status'] = 'old';
					}
				}

				// If there is a new message in the container, add it to latest_messages and update the main status
				if ( $has_new_message ) {
					$latest_messages[]                                  = $agent_message;
					$messages_post_customer[ $unique_id ]['status_msg'] = 'old';

					// Save the updated messages to avoid fetching them as new again
					update_user_meta( $old_user, 'customer_messages', $messages_post_customer );
				}
			}
		}

		// Send response with customer name, unique subject ID, and latest messages
		wp_send_json_success(
			array(
				'agent_name'        => $agent_name,
				'customer_name'     => $customer_name,
				'unique_subject_id' => $unique_msg_id,
				'latest_messages'   => $latest_messages,
			)
		);
	}
	public function customer_mark_as_read_message_view() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'message_nonce' );
		if ( isset( $_POST['message_id'] ) ) {
			$message_id    = sanitize_text_field( $_POST['message_id'] );
			$agent_post_id = get_user_meta( get_current_user_id(), 'sales_agent', true );
			$old_user      = get_post_meta( $agent_post_id, 'assign_user', true );
			$user_meta     = get_user_meta( $old_user, 'customer_messages', true );

			// Ensure $user_meta is an array
			if ( ! is_array( $user_meta ) ) {
				$user_meta = array();
			}

			if ( isset( $user_meta[ $message_id ] ) ) {
				$user_meta[ $message_id ]['status_cust'] = 'unread';
				update_user_meta( $old_user, 'customer_messages', $user_meta );
				wp_send_json_success( array( 'message' => 'Message marked as read.' ) );
			} else {
				wp_send_json_error( array( 'message' => 'Message not found.' ) );
			}
		}
	}

	public function customer_mark_read_message_agent() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'message_nonce' );
		if ( isset( $_POST['message_id'] ) ) {
			$message_id    = sanitize_text_field( $_POST['message_id'] );
			$agent_post_id = get_user_meta( get_current_user_id(), 'sales_agent', true );
			$old_user      = get_post_meta( $agent_post_id, 'assign_user', true );
			$user_meta     = get_user_meta( $old_user, 'customer_messages', true );

			// Ensure $user_meta is an array
			if ( ! is_array( $user_meta ) ) {
				$user_meta = array();
			}

			if ( isset( $user_meta[ $message_id ] ) ) {
				$user_meta[ $message_id ]['status_cust'] = 'read';
				update_user_meta( $old_user, 'customer_messages', $user_meta );
				wp_send_json_success( array( 'message' => 'Message marked as read.' ) );
			} else {
				wp_send_json_error( array( 'message' => 'Message not found.' ) );
			}
		}
	}

	public function customer_mark_unread_message_agent() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'message_nonce' );
		if ( isset( $_POST['message_id'] ) ) {
			$message_id    = sanitize_text_field( $_POST['message_id'] );
			$agent_post_id = get_user_meta( get_current_user_id(), 'sales_agent', true );
			$old_user      = get_post_meta( $agent_post_id, 'assign_user', true );
			$user_meta     = get_user_meta( $old_user, 'customer_messages', true );

			if ( ! is_array( $user_meta ) ) {
				$user_meta = array();
			}

			if ( isset( $user_meta[ $message_id ] ) ) {
				$user_meta[ $message_id ]['status_cust'] = 'unread';
				update_user_meta( $old_user, 'customer_messages', $user_meta );
				wp_send_json_success( array( 'message' => 'Message marked as unread.' ) );
			} else {
				wp_send_json_error( array( 'message' => 'Message not found.' ) );
			}
		}
	}

	public function customer_mark_active_thread_agent() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'message_nonce' );
		if ( isset( $_POST['message_id'] ) ) {
			$message_id    = sanitize_text_field( $_POST['message_id'] );
			$agent_post_id = get_user_meta( get_current_user_id(), 'sales_agent', true );
			$old_user      = get_post_meta( $agent_post_id, 'assign_user', true );
			$user_meta     = get_user_meta( $old_user, 'customer_messages', true );

			if ( ! is_array( $user_meta ) ) {
				$user_meta = array();
			}

			if ( isset( $user_meta[ $message_id ] ) ) {
				$user_meta[ $message_id ]['thread_status_cust'] = 'active';
				update_user_meta( $old_user, 'customer_messages', $user_meta );
				wp_send_json_success( array( 'message' => 'Thread marked as active.' ) );
			} else {
				wp_send_json_error( array( 'message' => 'Thread not found.' ) );
			}
		}
	}

	public function customer_mark_inactive_thread_agent() {
		check_ajax_referer( 'wc_sales_agent_nonce', 'message_nonce' );
		if ( isset( $_POST['message_id'] ) ) {
			$message_id    = sanitize_text_field( $_POST['message_id'] );
			$agent_post_id = get_user_meta( get_current_user_id(), 'sales_agent', true );
			$old_user      = get_post_meta( $agent_post_id, 'assign_user', true );
			$user_meta     = get_user_meta( $old_user, 'customer_messages', true );

			if ( ! is_array( $user_meta ) ) {
				$user_meta = array();
			}

			if ( isset( $user_meta[ $message_id ] ) ) {
				$user_meta[ $message_id ]['thread_status_cust'] = 'inactive';
				update_user_meta( $old_user, 'customer_messages', $user_meta );
				wp_send_json_success( array( 'message' => 'Thread marked as inactive.' ) );
			} else {
				wp_send_json_error( array( 'message' => 'Thread not found.' ) );
			}
		}
	}

	/**
	 * Adds a 'Switch back to {user}' link to the WordPress Header.
	 */
	public function action_wp_header() {

		$old_user     = self::get_old_user();
		$current_user = wp_get_current_user();

		if ( $old_user instanceof \WP_User ) {
			$link = sprintf(
				/* Translators: 1: user display name; 2: username; */
				__( 'Switch back to %1$s (%2$s)', 'woocommerce-wholesale-pricing' ),
				$old_user->display_name,
				$old_user->user_login
			);

			/**
			 * Filter.
			 *
			 * @since 1.4.5
			 *
			 * For agents to change url
			 */
			$switch_back_agent = apply_filters( 'switch_back_to_agent_footer_url', urlencode( self::current_url() ) );

			$url = add_query_arg(
				array(
					'redirect_to' => $switch_back_agent,
				),
				self::switch_back_url( $old_user )
			);

			// Create the black bar with flexbox for alignment
			echo '<div style="background-color: black; color: white; padding: 30px; display: flex; justify-content: space-between; align-items: center;">';
			// Left side: Display the logged-in username
			printf(
				'<span>Agent Logged-In as : %s</span>',
				esc_html( $current_user->display_name )
			);
			// Right side: Display the switch back link as a button
			printf(
				'<a href="%s" style="background-color: #007bff; padding: 10px 20px; color: white; text-decoration: none; font-size: 14px; border-radius: 5px;">%s</a>',
				esc_url( $url ),
				esc_html( 'Switch back to Agent' )
			);
			echo '</div>';
		}
	}

	/**
	 * Defines the names of the cookies used by User Switching.
	 */
	public function action_plugins_loaded() {
		// User Switching's auth_cookie
		if ( ! defined( 'USER_SWITCHING_COOKIE' ) ) {
			define( 'USER_SWITCHING_COOKIE', 'wordpress_user_sw_' . COOKIEHASH );
		}

		// User Switching's secure_auth_cookie
		if ( ! defined( 'USER_SWITCHING_SECURE_COOKIE' ) ) {
			define( 'USER_SWITCHING_SECURE_COOKIE', 'wordpress_user_sw_secure_' . COOKIEHASH );
		}

		// User Switching's logged_in_cookie
		if ( ! defined( 'USER_SWITCHING_OLDUSER_COOKIE' ) ) {
			define( 'USER_SWITCHING_OLDUSER_COOKIE', 'wordpress_user_sw_olduser_' . COOKIEHASH );
		}
	}

	/**
	 * Outputs the 'Switch To' link on the user editing screen if the current user has permission to switch to them.
	 *
	 * @param WP_User $user User object for this screen.
	 */
	public function action_personal_options( \WP_User $user ) {
		$link = self::maybe_switch_url( $user );

		if ( ! $link ) {
			return;
		}
		?>
		<tr class="user-switching-wrap">
			<th scope="row">
				<?php echo esc_html_x( 'User Switching', 'User Switching title on user profile screen', 'woocommerce-wholesale-pricing' ); ?>
			</th>
			<td><a id="wc_agent_user_switching_switcher"
					href="<?php echo esc_url( $link ); ?>"><?php esc_html_e( 'Switch&nbsp;To', 'woocommerce-wholesale-pricing' ); ?></a></td>
		</tr>
		<?php
	}

	/**
	 * Returns whether the current logged in user is being remembered in the form of a persistent browser cookie
	 * (ie. they checked the 'Remember Me' check box when they logged in). This is used to persist the 'remember me'
	 * value when the user switches to another user.
	 *
	 * @return bool Whether the current user is being 'remembered'.
	 */
	public static function remember() {
		/**
		 * This filter is documented in wp-includes/pluggable.php
		 */
		/**
		 * Filter.
		 *
		 * @since 1.0.4
		 */
		$cookie_life = apply_filters( 'auth_cookie_expiration', 172800, get_current_user_id(), false );
		$current     = wp_parse_auth_cookie( '', 'logged_in' );

		// Here we calculate the expiration length of the current auth cookie and compare it to the default expiration.
		// If it's greater than this, then we know the user checked 'Remember Me' when they logged in.
		return ( ( $current['expiration'] - time() ) > $cookie_life );
	}

	/**
	 * Loads localisation files and routes actions depending on the 'action' query var.
	 */
	public function action_init() {
		load_plugin_textdomain( 'user-switching', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

		if ( ! isset( $_REQUEST['action'] ) ) {
			return;
		}

		$current_user = ( is_user_logged_in() ) ? wp_get_current_user() : null;

		switch ( $_REQUEST['action'] ) {

			// We're attempting to switch to another user:
			case 'switch_to_user':
				if ( isset( $_REQUEST['user_id'] ) ) {
					$user_id = absint( $_REQUEST['user_id'] );
				} else {
					$user_id = 0;
				}

				// Check authentication:
				// if (!current_user_can('switch_to_user', $user_id)) {
				// wp_die(esc_html__('Could not switch users.', 'woocommerce-wholesale-pricing'), 403);
				// }
				// Check intent:
				check_admin_referer( "switch_to_user_{$user_id}" );

				// Switch user:
				$user = switch_to_user( $user_id, self::remember() );
				if ( $user ) {
					$redirect_to = self::get_redirect( $user, $current_user );

					// Redirect to the dashboard or the home URL depending on capabilities:
					$args = array(
						'user_switched' => 'true',
					);

					if ( $redirect_to ) {
						wp_safe_redirect( add_query_arg( $args, $redirect_to ), 302, self::$application );
					} elseif ( ! current_user_can( 'read' ) ) {
						wp_safe_redirect( add_query_arg( $args, home_url() ), 302, self::$application );
					} else {
						wp_safe_redirect( add_query_arg( $args, admin_url() ), 302, self::$application );
					}
					exit;
				} else {
					wp_die( esc_html__( 'Could not switch users.', 'woocommerce-wholesale-pricing' ), 404 );
				}
				break;

			// We're attempting to switch back to the originating user:
			case 'switch_to_olduser':
				// Fetch the originating user data:
				$old_user = self::get_old_user();
				if ( ! $old_user ) {
					wp_die( esc_html__( 'Could not switch users.', 'woocommerce-wholesale-pricing' ), 400 );
				}

				// Check authentication:
				if ( ! self::authenticate_old_user( $old_user ) ) {
					wp_die( esc_html__( 'Could not switch users.', 'woocommerce-wholesale-pricing' ), 403 );
				}

				// Check intent:
				check_admin_referer( "switch_to_olduser_{$old_user->ID}" );

				// Switch user:
				if ( switch_to_user( $old_user->ID, self::remember(), false ) ) {

					if ( ! empty( $_REQUEST['interim-login'] ) ) {
						// $GLOBALS['interim_login'] = 'success'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
						login_header( '', '' );
						exit;
					}

					$redirect_to = self::get_redirect( $old_user, $current_user );
					$args        = array(
						'user_switched' => 'true',
						'switched_back' => 'true',
					);

					if ( $redirect_to ) {
						wp_safe_redirect( add_query_arg( $args, $redirect_to ), 302, self::$application );
					} else {
						wp_safe_redirect( add_query_arg( $args, admin_url( 'users.php' ) ), 302, self::$application );
					}
					exit;
				} else {
					wp_die( esc_html__( 'Could not switch users.', 'woocommerce-wholesale-pricing' ), 404 );
				}
				break;

			// We're attempting to switch off the current user:
			case 'switch_off':
				// Check authentication:
				// if (!current_user_can('switch_off')) {
				// * Translators: "switch off" means to temporarily log out */
				// wp_die(esc_html__('Could not switch off.', 'woocommerce-wholesale-pricing'));
				// }
				// Check intent:
				check_admin_referer( "switch_off_{$current_user->ID}" );

				// Switch off:
				if ( switch_off_user() ) {
					$redirect_to = self::get_redirect( null, $current_user );
					$args        = array(
						'switched_off' => 'true',
					);

					if ( $redirect_to ) {
						wp_safe_redirect( add_query_arg( $args, $redirect_to ), 302, self::$application );
					} else {
						wp_safe_redirect( add_query_arg( $args, home_url() ), 302, self::$application );
					}
					exit;
				} else {
					/* Translators: "switch off" means to temporarily log out */
					wp_die( esc_html__( 'Could not switch off.', 'woocommerce-wholesale-pricing' ) );
				}
				break;
		}
	}

	/**
	 * Fetches the URL to redirect to for a given user (used after switching).
	 *
	 * @param  WP_User $new_user Optional. The new user's WP_User object.
	 * @param  WP_User $old_user Optional. The old user's WP_User object.
	 * @return string The URL to redirect to.
	 */
	protected static function get_redirect( \WP_User $new_user, \WP_User $old_user ) {
		if ( ! empty( $_REQUEST['redirect_to'] ) ) {
			$redirect_to           = self::remove_query_args( wp_unslash( filter_var( $_REQUEST['redirect_to'], FILTER_SANITIZE_URL ) ) );
			$requested_redirect_to = wp_unslash( filter_var( $_REQUEST['redirect_to'], FILTER_SANITIZE_URL ) );
		} else {
			$redirect_to           = '';
			$requested_redirect_to = '';
		}

		if ( ! $new_user ) {
			/**
			 * This filter is documented in wp-login.php
			 */
			/**
			 * Filter.
			 *
			 * @since 1.0.4
			 */
			$redirect_to = apply_filters( 'logout_redirect', $redirect_to, $requested_redirect_to, $old_user );
		} else {
			/**
			 * This filter is documented in wp-login.php
			 */
			/**
			 * Filter.
			 *
			 * @since 1.0.4
			 */
			$redirect_to = apply_filters( 'login_redirect', $redirect_to, $requested_redirect_to, $new_user );
		}

		return $redirect_to;
	}

	/**
	 * Validates the old user cookie and returns its user data.
	 *
	 * @return false|WP_User False if there's no old user cookie or it's invalid, WP_User object if it's present and valid.
	 */
	public static function get_old_user() {
		$cookie = wc_agent_user_switching_get_olduser_cookie();
		if ( ! empty( $cookie ) ) {
			$old_user_id = wp_validate_auth_cookie( $cookie, 'logged_in' );

			if ( $old_user_id ) {
				return get_userdata( $old_user_id );
			}
		}
		return false;
	}

	/**
	 * Authenticates an old user by verifying the latest entry in the auth cookie.
	 *
	 * @param  WP_User $user A WP_User object (usually from the logged_in cookie).
	 * @return bool Whether verification with the auth cookie passed.
	 */
	public static function authenticate_old_user( \WP_User $user ) {
		$cookie = wc_agent_user_switching_get_auth_cookie();
		if ( ! empty( $cookie ) ) {
			if ( self::secure_auth_cookie() ) {
				$scheme = 'secure_auth';
			} else {
				$scheme = 'auth';
			}

			$old_user_id = wp_validate_auth_cookie( end( $cookie ), $scheme );

			if ( $old_user_id ) {
				return ( $user->ID === $old_user_id );
			}
		}
		return false;
	}

	/**
	 * Adds a 'Switch back to {user}' link to the Meta sidebar widget.
	 */
	public function action_wp_meta() {
		$old_user = self::get_old_user();

		if ( $old_user instanceof \WP_User ) {
			$link = sprintf(
				/* Translators: 1: user display name; 2: username; */
				__( 'Switch back to %1$s (%2$s)', 'woocommerce-wholesale-pricing' ),
				$old_user->display_name,
				$old_user->user_login
			);

			/**
			 * Filter.
			 *
			 * @since 1.4.5
			 *
			 * For agents to change url
			 */
			$switch_back_agent = apply_filters( 'switch_back_to_agent_url', urlencode( self::current_url() ) );

			$url = add_query_arg(
				array(
					'redirect_to' => $switch_back_agent,
				),
				self::switch_back_url( $old_user )
			);
			printf(
				'<li id="wc_agent_user_switching_switch_on"><a href="%s">%s</a></li>',
				esc_url( $url ),
				esc_html( $link )
			);
		}
	}


	/**
	 * Adds a 'Switch back to {user}' link to the WordPress footer if the admin toolbar isn't showing.
	 */
	public function action_wp_footer() {

		$old_user = self::get_old_user();

		if ( $old_user instanceof \WP_User ) {
			$link = sprintf(
				/* Translators: 1: user display name; 2: username; */
				__( 'Switch back to %1$s (%2$s)', 'woocommerce-wholesale-pricing' ),
				$old_user->display_name,
				$old_user->user_login
			);

			/**
			 * Filter.
			 *
			 * @since 1.4.5
			 *
			 * For agents to change url
			 */
			$switch_back_agent = apply_filters( 'switch_back_to_agent_footer_url', urlencode( self::current_url() ) );

			$url = add_query_arg(
				array(
					'redirect_to' => $switch_back_agent,
				),
				self::switch_back_url( $old_user )
			);
			printf(
				'<p id="user_switching_switch_on"><a href="%s">%s</a></p>',
				esc_url( $url ),
				esc_html( $link )
			);
		}
	}

	/**
	 * Filters the list of query arguments which get removed from admin area URLs in WordPress.
	 *
	 * @link https://core.trac.wordpress.org/ticket/23367
	 *
	 * @param  string[] $args Array of removable query arguments.
	 * @return string[] Updated array of removable query arguments.
	 */
	public function filter_removable_query_args( array $args ) {
		return array_merge(
			$args,
			array(
				'user_switched',
				'switched_off',
				'switched_back',
			)
		);
	}

	/**
	 * Returns the switch to or switch back URL for a given user.
	 *
	 * @param  WP_User $user The user to be switched to.
	 * @return string|false The required URL, or false if there's no old user or the user doesn't have the required capability.
	 */
	public static function maybe_switch_url( \WP_User $user ) {
		$old_user = self::get_old_user();

		if ( $old_user && ( $old_user->ID === $user->ID ) ) {
			return self::switch_back_url( $old_user );
		} elseif ( current_user_can( 'switch_to_user', $user->ID ) ) {
			return self::switch_to_url( $user );
		} else {
			return false;
		}
	}

	/**
	 * Returns the nonce-secured URL needed to switch to a given user ID.
	 *
	 * @param  WP_User $user The user to be switched to.
	 * @return string The required URL.
	 */
	public static function switch_to_url( \WP_User $user ) {
		return wp_nonce_url(
			add_query_arg(
				array(
					'action'  => 'switch_to_user',
					'user_id' => $user->ID,
					'nr'      => 1,
				),
				wp_login_url()
			),
			"switch_to_user_{$user->ID}"
		);
	}

	/**
	 * Returns the nonce-secured URL needed to switch back to the originating user.
	 *
	 * @param  WP_User $user The old user.
	 * @return string        The required URL.
	 */
	public static function switch_back_url( \WP_User $user ) {
		return wp_nonce_url(
			add_query_arg(
				array(
					'action' => 'switch_to_olduser',
					'nr'     => 1,
				),
				wp_login_url()
			),
			"switch_to_olduser_{$user->ID}"
		);
	}

	/**
	 * Returns the nonce-secured URL needed to switch off the current user.
	 *
	 * @param  WP_User $user The user to be switched off.
	 * @return string        The required URL.
	 */
	public static function switch_off_url( \WP_User $user ) {
		return wp_nonce_url(
			add_query_arg(
				array(
					'action' => 'switch_off',
					'nr'     => 1,
				),
				wp_login_url()
			),
			"switch_off_{$user->ID}"
		);
	}

	/**
	 * Returns the current URL.
	 *
	 * @return string The current URL.
	 */
	public static function current_url() {
		$http = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( $_SERVER['HTTP_HOST'] ) : '';
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( $_SERVER['REQUEST_URI'] ) : '';
		return ( is_ssl() ? 'https://' : 'http://' ) . $http . $uri;
	}

	/**
	 * Removes a list of common confirmation-style query args from a URL.
	 *
	 * @param  string $url A URL.
	 * @return string The URL with query args removed.
	 */
	public static function remove_query_args( $url ) {
		if ( function_exists( 'wp_removable_query_args' ) ) {
			$url = remove_query_arg( wp_removable_query_args(), $url );
		}

		return $url;
	}

	/**
	 * Returns whether User Switching's equivalent of the 'logged_in' cookie should be secure.
	 *
	 * This is used to set the 'secure' flag on the old user cookie, for enhanced security.
	 *
	 * @link https://core.trac.wordpress.org/ticket/15330
	 *
	 * @return bool Should the old user cookie be secure?
	 */
	public static function secure_olduser_cookie() {
		return ( is_ssl() && ( 'https' === parse_url( home_url(), PHP_URL_SCHEME ) ) );
	}

	/**
	 * Returns whether User Switching's equivalent of the 'auth' cookie should be secure.
	 *
	 * This is used to determine whether to set a secure auth cookie.
	 *
	 * @return bool Whether the auth cookie should be secure.
	 */
	public static function secure_auth_cookie() {
		return ( is_ssl() && ( 'https' === parse_url( wp_login_url(), PHP_URL_SCHEME ) ) );
	}

	/**
	 * Instructs WooCommerce to forget the session for the current user, without deleting it.
	 */
	public function forget_woocommerce_session() {
		if ( ! function_exists( 'WC' ) ) {
			return;
		}

		$wc = WC();

		if ( ! property_exists( $wc, 'session' ) ) {
			return;
		}

		if ( ! method_exists( $wc->session, 'forget_session' ) ) {
			return;
		}

		$wc->session->forget_session();
	}

	/**
	 * Singleton instantiator.
	 *
	 * @return WC_Agent_User_Switching User Switching instance.
	 */
	public static function get_instance() {
		static $instance;

		if ( ! isset( $instance ) ) {
			$instance = new UserSwitching();
		}

		return $instance;
	}
}

$GLOBALS['wc_agent_user_switching'] = UserSwitching::get_instance();
$GLOBALS['wc_agent_user_switching']->init_hooks();
