<?php

namespace WooCommerceWholesalePricing\App\Modules\SalesAgent;

use WooCommerceWholesalePricing\App\Models\SalesAgent\Agent;
use WooCommerceWholesalePricing\App\Models\SalesAgent\AgentCommission;
use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
class MyAccount extends Init {

	use WholesaleSettings;

	public function __construct() {
		parent::__construct();

		add_filter( 'woocommerce_get_query_vars', array( $this, 'myaccount_custom_endpoints_query_vars' ) );
		add_filter( 'woocommerce_account_menu_items', array( $this, 'wc_agent_menus_end_point_items' ), 99 );

		add_action( 'woocommerce_account_agent-customers_endpoint', array( $this, 'wc_agent_customer_endpoint_handle' ) );

		// update name of  my account in agent customers endpoint
		add_filter( 'woocommerce_endpoint_agent-customers_title', array( $this, 'change_my_account_agent_customer_title' ), 10, 2 );

		add_filter( 'woocommerce_get_endpoint_url', array( $this, 'get_url_back_agent' ), 10, 4 );

		add_action( 'woocommerce_account_agent-orders_endpoint', array( $this, 'wc_agent_orders_endpoint_handle' ) );

		// update name of  my account in agent orders endpoint
		add_filter( 'woocommerce_endpoint_agent-orders_title', array( $this, 'change_my_account_agent_orders_title' ), 10, 2 );

		// add capability so admin can visit order page
		add_filter( 'user_has_cap', array( $this, 'wc_customer_has_capability' ), 10, 3 );

		add_filter( 'wc_agent_myaccount_pagination_previous', array( $this, 'add_pagination_query' ), 10, 2 );
		add_filter( 'wc_agent_myaccount_pagination_next', array( $this, 'add_pagination_query' ), 10, 2 );

		add_action( 'woocommerce_account_commissions_endpoint', array( $this, 'wc_agent_view_commissions_point_handle' ) );

		// Change title in agent commission end point
		add_filter( 'woocommerce_endpoint_commissions_title', array( $this, 'change_my_account_agent_commission_title' ), 10, 2 );

		// modified pagenatations of commissions
		add_filter( 'wc_agent_myaccount_pagination_previous', array( $this, 'add_pagination_query_commissions' ), 10, 2 );
		add_filter( 'wc_agent_myaccount_pagination_next', array( $this, 'add_pagination_query_commissions' ), 10, 2 );

		add_action( 'woocommerce_account_agent-payout_endpoint', array( $this, 'wc_agent_customer_end_point_handle' ) );

		// update name of  my account in agent orders endpoint
		add_filter( 'woocommerce_endpoint_agent-payout_title', array( $this, 'change_my_account_payout_title' ), 10, 2 );

		add_action( 'woocommerce_account_agent-customer_endpoint', array( $this, 'wc_agent_edit_customer_point_handle' ) );
		// Change title in agent customer account end point
		add_filter( 'woocommerce_endpoint_agent-customer_title', array( $this, 'change_my_account_agent_customer_data_title' ), 10, 2 );

		// save customer details in create and edit
		add_action( 'template_redirect', array( $this, 'save_customer_details' ) );

		add_action( 'woocommerce_account_view-customer_endpoint', array( $this, 'wc_agent_view_customer_point_handle' ) );

		add_filter( 'query_vars', array( $this, 'commission_filter_query_vars' ) );
	}

	/**
	 * Allow commission filter params to persist on My Account endpoint URLs.
	 *
	 * @param array $vars Public query vars.
	 * @return array
	 */
	public function commission_filter_query_vars( $vars ) {
		$vars[] = 'user-filter';
		$vars[] = 'date_from';
		$vars[] = 'date_to';
		$vars[] = 'agent_id';

		return $vars;
	}

	public function register() {
		$settings = self::get_pricing_settings();

		// check if is agent
		$agent_id       = Actions::is_agent();
		if ( ( $agent_id ) ) {
			// end point commissions
			add_rewrite_endpoint( 'commissions', EP_ROOT | EP_PAGES );
			// end point of view customer
			add_rewrite_endpoint( 'view-customer', EP_ROOT | EP_PAGES );
			// end point of agent customers list
			add_rewrite_endpoint( 'agent-customers', EP_ROOT | EP_PAGES );
			// end point of agent orders list
			add_rewrite_endpoint( 'agent-orders', EP_ROOT | EP_PAGES );
			// end point dashboard

			// end point payout
			add_rewrite_endpoint( 'agent-payout', EP_ROOT | EP_PAGES );

			if ( get_post_meta( $agent_id, 'customer_registration', true ) == 'yes' ) {
				// end point of create and update customer
				add_rewrite_endpoint( 'agent-customer', EP_ROOT | EP_PAGES );
			}
		}
		$customer_id        = get_current_user_id();
		$customer_has_agent = get_user_meta( $customer_id, 'sales_agent', true );

		// end point of back to agent
		$old_user = UserSwitching::get_old_user();
		if ( isset( $old_user ) ) {
			add_rewrite_endpoint( 'back-agent', EP_ROOT | EP_PAGES );
		}

		if ( ! empty( $customer_has_agent ) ) {
			add_rewrite_endpoint( 'view-agent-details', EP_ROOT | EP_PAGES );
		}

		if ( $agent_id || isset( $old_user ) || ! empty( $customer_has_agent ) ) {
			flush_rewrite_rules();
		}
	}

	/**
	 * Add endpoints to query vars
	 *
	 * @param  array $query_vars
	 * @return string
	 */
	public function myaccount_custom_endpoints_query_vars( $query_vars ) {
		$settings = self::get_pricing_settings();

		$agent_id       = Actions::is_agent();
		if ( ( $agent_id ) ) {
			$query_vars['agent-customers']      = 'agent-customers';
			$query_vars['agent-orders']         = 'agent-orders';
			$query_vars['view-customer']        = 'view-customer';
			$query_vars['commissions']          = 'commissions';


			if ( ( isset( $settings['sales_agent_paypal_payout'] ) && 'yes' == $settings['sales_agent_paypal_payout'] ) || ( isset( $settings['sales_agent_bacs_payout'] ) && 'yes' == $settings['sales_agent_bacs_payout'] ) ) {
				$query_vars['agent-payout'] = 'agent-payout';
			}

			if ( get_post_meta( $agent_id, 'customer_registration', true ) == 'yes' ) {
				$query_vars['agent-customer'] = 'agent-customer';
			}

			$customer_has_agent = get_user_meta( get_current_user_id(), 'sales_agent', true );
			if ( 'enabled' === get_option( 'messages_agent_customer_toggle' ) && isset( $customer_has_agent ) && ! empty( $customer_has_agent ) ) {
				// end point messages
				$query_vars['customer-messages'] = 'customer-messages';
			}

			if ( ! empty( $customer_has_agent ) ) {
				$query_vars['view-agent-details'] = 'view-agent-details';
			}
		}

		return $query_vars;
	}

	public function wc_agent_menus_end_point_items( $items ) {
		$settings = self::get_pricing_settings();

		// remove logout endpoint from menu to reorder them
		$logout = $items['customer-logout'];
		unset( $items['customer-logout'] );

		// check agent and not have old user to add customer
		$agent_id = Actions::is_agent();

		$old_user = UserSwitching::get_old_user();
		

		if ( ( $agent_id ) && ! $old_user ) {
			
			/**
			 * Filter.
			 * 
			 * @since 1.0.4
			*/
			$items['agent-customers']      = apply_filters( 'wc_agent_customers_menu_item', __( 'Agent Customers', 'woocommerce-wholesale-pricing' ) );
			/**
			* Filter.
			* 
			* @since 1.0.4
			*/
			$items['agent-orders']         = apply_filters( 'wc_agent_orders_menu_item', __( 'Agent Orders', 'woocommerce-wholesale-pricing' ) );
			/**
			* Filter.
			* 
			* @since 1.0.4
			*/
			$items['commissions']          = apply_filters( 'wc_agent_commissions_menu_item', __( 'Agent Commissions', 'woocommerce-wholesale-pricing' ) );

			if ( ( isset( $settings['sales_agent_paypal_payout'] ) && 'yes' == $settings['sales_agent_paypal_payout'] ) || ( isset( $settings['sales_agent_bacs_payout'] ) && 'yes' == $settings['sales_agent_bacs_payout'] ) ) {
				/**
				* Filter.
				* 
				* @since 1.0.4
				*/
				$items['agent-payout'] = apply_filters( 'wc_agent_payout_menu_item', __( 'Payout', 'woocommerce-wholesale-pricing' ) );
			}
		}
		
		// if old user add to menu back to agent
		if ( $old_user ) {
			/**
			* Filter.
			* 
			* @since 1.0.4
			*/
			$items['back-agent'] = apply_filters( 'wc_agent_switch_back_menu_item', __( 'Back To Agent', 'woocommerce-wholesale-pricing' ) );
		}

		// return add logout last item in list
		$items['customer-logout'] = $logout;
		return $items;
	}

	public function wc_agent_customer_endpoint_handle( $current_page ) {
		// get agent id
		$agent_id       = Actions::is_agent();

		// prepare data of customers of current agent
		$per_page              = ( get_option( 'list_no_rows' ) ) ? get_option( 'list_no_rows' ) : 10;
		$agent = new Agent();
		$current_page          = ( ! empty( $current_page ) ) ? $current_page : 1;
		$data                  = $agent->query( $per_page, $current_page, true, $agent_id );
		$num_pages             = $data['num_pages'];
		$users                 = $data['users'];
		$end_point             = 'agent-customers';
		
		wwp_view('sales-agent.my-account.wc-agent-customers-list-view', compact('agent_id', 'users', 'per_page', 'end_point', 'current_page', 'num_pages'));
	}

	public function change_my_account_agent_customer_title( $title, $endpoint ) {
		$title = __( 'Customers', 'woocommerce-wholesale-pricing' );
		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		return apply_filters( 'wc_agent_agent_customers_endpoint_title', $title );
	}

	public function get_url_back_agent( $url, $endpoint, $value, $permalink ) {
		if ( 'back-agent' === $endpoint ) {
			$old_user = UserSwitching::get_old_user();
			if ( $old_user ) {
				// ok, here is the place for your custom URL, it could be external
				$url = add_query_arg(
					array(
						'redirect_to' => urlencode( UserSwitching::current_url() ),
					),
					UserSwitching::switch_back_url( $old_user )
				);
			}
		}
		return $url;
	}

	/**
	 * Customer end point data
	 *
	 * @global type $paged
	 * @param  type $current_page
	 */
	public function wc_agent_orders_endpoint_handle( $current_page ) {

		// Get agent id
		$agent_id       = Actions::is_agent();

		// Define default value for orders per page
		$default_per_page = ( get_option( 'list_no_rows' ) ) ? get_option( 'list_no_rows' ) : 10;

		// Apply filter to get the final value of orders per page
		/**
		 * Filter.
		 *
		 * @since 1.6
		*/
		$per_page = apply_filters( 'wc_agent_orders_per_page', $default_per_page );

		// Ensure current page is valid
		$current_page = ( ! empty( $current_page ) ) ? $current_page : 1;
		$end_point    = 'agent-orders';
		$action       = esc_url( wc_get_endpoint_url( $end_point ) );

		// Get orders
		$agent = new Agent();
		$orders_result  =(array) $agent->get_orders( array( 'agent_id' => $agent_id ), $per_page, $current_page );

		extract( $orders_result );
		$num_pages = $max_num_pages;
		wwp_view('sales-agent.my-account.wc-agent-orders-list-view', compact('action', 'orders', 'per_page', 'end_point', 'current_page', 'num_pages'));
	}

	/**
	 * Change title in agent orders endpoint
	 *
	 * @param  type $title
	 * @param  type $endpoint
	 * @return type
	 */
	public function change_my_account_agent_orders_title( $title, $endpoint ) {
		return __( 'Orders', 'woocommerce-wholesale-pricing' );
	}

	public function wc_customer_has_capability( $allcaps, $caps, $args ) {
		if ( isset( $caps[0] ) ) {
			if ( 'view_order' == $caps[0] ) {
				$user_id = intval( $args[1] );
				$order   = wc_get_order( $args[2] );

				if ( $order ) {
					$order_owner = $order->get_user_id();
					// get customer agent
					$owner_agent = Actions::get_customer_agent( $order_owner );
					// get order agent
					$order_agent = Actions::get_order_agent( $order->get_id() );
					// get customer agent user id
					$owner_agent_user = Actions::get_agent_user_id( $owner_agent );
					// get order agent user id
					$order_agent_user = Actions::get_agent_user_id( $order_agent );

					if ( intval( $order_agent_user ) === $user_id || intval( $owner_agent_user ) === $user_id ) {
						$allcaps['view_order'] = true;
					}
				}
			}
		}
		return $allcaps;
	}

	public function add_pagination_query( $url, $end_point ) {

		if ( ( 'agent-orders' == $end_point || strpos( $end_point, 'view-customer' ) !== false ) && isset( $_GET['serch'] ) ) {
			$url = add_query_arg(
				array(
					'serch' => sanitize_text_field( $_GET['serch'] ),
				),
				$url
			);
		}

		return $url;
	}

	/**
	 * Change title in agent commission end point
	 *
	 * @param  type $title
	 * @param  type $endpoint
	 * @return type
	 */
	public function change_my_account_agent_commission_title( $title, $endpoint ) {
		return __( 'Commissions', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Handle view commission
	 *
	 * @param type $parmter
	 */
	public function wc_agent_view_commissions_point_handle( $current_page ) {
		// get currnt agent id
		$agent_id       = Actions::is_agent();
		$commission_action = new Agent();
		$per_page          = ( get_option( 'list_no_rows' ) ) ? get_option( 'list_no_rows' ) : 10;
		$current_page      = ( ! empty( $current_page ) ) ? $current_page : 1;
		$data              = $commission_action->query_by_agent( $per_page, $current_page, $agent_id );
		$commissions       = $data['data'];
		$num_pages         = ! empty( $data['data'] ) ? ceil( count( $data['data'] ) / $per_page ) : '';
		$offset            = ( $current_page - 1 ) * $per_page;
		$end_point         = 'commissions';

		wwp_view('sales-agent.my-account.wc-agent-commission-list-view', compact('agent_id', 'commissions', 'per_page', 'end_point', 'current_page', 'num_pages', 'offset'));
	}

	/**
	 * Pagentation query
	 *
	 * @param  type $url
	 * @param  type $end_point
	 * @return type
	 */
	public function add_pagination_query_commissions( $url, $end_point ) {

		if ( 'commissions' == $end_point && ( isset( $_REQUEST['user-filter'] ) || isset( $_REQUEST['date_from'] ) || isset( $_REQUEST['date_to'] ) ) ) {
			$url = add_query_arg(
				array(
					'user-filter' => ( isset( $_REQUEST['user-filter'] ) ) ? sanitize_text_field( $_REQUEST['user-filter'] ) : '',
					'date_from'   => ( isset( $_REQUEST['date_from'] ) ) ? sanitize_text_field( $_REQUEST['date_from'] ) : '',
					'date_to'     => ( isset( $_REQUEST['date_to'] ) ) ? sanitize_text_field( $_REQUEST['date_to'] ) : '',
				),
				$url
			);
		}

		return $url;
	}

	/**
	 * Change title in agent orders endpoint
	 *
	 * @param  type $title
	 * @param  type $endpoint
	 * @return type
	 */
	public function change_my_account_payout_title( $title, $endpoint ) {
		return __( 'Agent Payout', 'woocommerce-wholesale-pricing' );
	}

	public function wc_agent_customer_end_point_handle( $current_page ) {
		$agent_id       = Actions::is_agent();

		wwp_view('sales-agent.my-account.wc-agent-payout-list-view', compact('agent_id'));
	}

	/**
	 * Change title in agent commission end point
	 *
	 * @param  type $title
	 * @param  type $endpoint
	 * @return type
	 */
	public function change_my_account_agent_customer_data_title( $title, $endpoint ) {
		return __( 'Customer Account', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Handle view customer details
	 *
	 * @param type $parmter
	 */
	public function wc_agent_edit_customer_point_handle( $user_id ) {
		$user = null;
		if ( $user_id ) {
			$user = get_userdata( $user_id );
		}
		wwp_view('sales-agent.my-account.wc-agent-from-create-update-customer', compact('user', 'user_id'));
	}

	/**
	 * Save and update customer details
	 *
	 * @return type
	 */
	public function save_customer_details() {

		if ( empty( $_POST['action'] ) || 'save_customer_details' !== $_POST['action'] ) {
			return;
		}

		if ( ! isset( $_POST['sales_agent_nonce'] ) || ( isset( $_POST['sales_agent_nonce'] ) && ! wp_verify_nonce( sanitize_text_field( $_POST['sales_agent_nonce'] ), 'sales_agent_nonce' ) ) ) {
			exit( 'Not Authorized' );
		}

		if ( ! current_user_can( 'sales_agent' ) && ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage customers.', 'woocommerce-wholesale-pricing' ) );
		}

		// form data
		$save_pass             = true;
		$customer_ws_role      = ! empty( $_POST['customer_ws_role'] ) ? wc_clean( wp_unslash( $_POST['customer_ws_role'] ) ) : '';
		$customer_display_name = ! empty( $_POST['customer_display_name'] ) ? wc_clean( wp_unslash( $_POST['customer_display_name'] ) ) : '';
		$customer_email        = ! empty( $_POST['customer_email'] ) ? wc_clean( wp_unslash( $_POST['customer_email'] ) ) : '';
		$customer_first_name   = ! empty( $_POST['customer_first_name'] ) ? wc_clean( wp_unslash( $_POST['customer_first_name'] ) ) : '';
		$customer_last_name    = ! empty( $_POST['customer_last_name'] ) ? wc_clean( wp_unslash( $_POST['customer_last_name'] ) ) : '';
		$customer_company      = ! empty( $_POST['customer_company'] ) ? wc_clean( wp_unslash( $_POST['customer_company'] ) ) : '';
		$customer_country      = ! empty( $_POST['customer_country'] ) ? wc_clean( wp_unslash( $_POST['customer_country'] ) ) : '';
		$customer_address      = ! empty( $_POST['customer_address'] ) ? wc_clean( wp_unslash( $_POST['customer_address'] ) ) : '';
		$customer_city         = ! empty( $_POST['customer_city'] ) ? wc_clean( wp_unslash( $_POST['customer_city'] ) ) : '';
		$customer_state        = ! empty( $_POST['customer_state'] ) ? wc_clean( wp_unslash( $_POST['customer_state'] ) ) : '';
		$customer_zip          = ! empty( $_POST['customer_zip'] ) ? wc_clean( wp_unslash( $_POST['customer_zip'] ) ) : '';
		$customer_phone        = ! empty( $_POST['customer_phone'] ) ? wc_clean( wp_unslash( $_POST['customer_phone'] ) ) : '';
		$customer_password     = ! empty( $_POST['customer_password'] ) ? sanitize_text_field( $_POST['customer_password'] ) : '';
		$customer_id           = ( isset( $_REQUEST['customer_id'] ) && ! empty( $_REQUEST['customer_id'] ) ) ? ( sanitize_text_field( $_REQUEST['customer_id'] ) ) : 0;

		$vlidation = array(
			'customer_display_name' => __( 'UserName', 'woocommerce-wholesale-pricing' ),
			'customer_email'        => __( 'Email address', 'woocommerce-wholesale-pricing' ),
			'customer_password'     => __( 'Password', 'woocommerce-wholesale-pricing' ),
		);

		// remove password from required validation
		if ( $customer_id ) {
			unset( $vlidation['customer_password'] );
		}
		// Handle required fields.
		/**
		* Filter.
		*
		* @since 1.0.4
		*/
		$required_fields = apply_filters(
			'woocommerce_save_account_details_required_fields',
			$vlidation
		);

		foreach ( $required_fields as $field_key => $field_name ) {
			if ( empty( $_POST[ $field_key ] ) ) {
				/* translators: %s: Field name. */
				wc_add_notice( sprintf( __( '%s is a required field.', 'woocommerce-wholesale-pricing' ), '<strong>' . esc_html( $field_name ) . '</strong>' ), 'error', array( 'id' => $field_key ) );

				$save_pass = false;
			}
		}

		if ( $customer_id ) {// update
			// Current user data.
			$current_user = get_user_by( 'id', $customer_id );
			if ( $current_user ) {
				$current_first_name = $current_user->first_name;
				$current_last_name  = $current_user->last_name;
				$current_email      = $current_user->user_email;
			}

			// New user data.
			$user             = new \stdClass();
			$user->ID         = $customer_id;
			$user->first_name = $customer_first_name;
			$user->last_name  = $customer_last_name;

			$customer_email = sanitize_email( $customer_email );
			if ( ! is_email( $customer_email ) ) {
				wc_add_notice( __( 'Please provide a valid email address.', 'woocommerce-wholesale-pricing' ), 'error' );
				$save_pass = false;
			} elseif ( email_exists( $customer_email ) && isset( $current_user->user_email ) && $current_email != $customer_email ) {
				wc_add_notice( __( 'This email address is already registered.', 'woocommerce-wholesale-pricing' ), 'error' );
				$save_pass = false;
			} elseif ( email_exists( $customer_email ) && ! $current_user ) {
				wc_add_notice( __( 'This email address is already registered.', 'woocommerce-wholesale-pricing' ), 'error' );
				$save_pass = false;
			}

			$user->user_email = $customer_email;
			if ( $save_pass && $customer_password ) {
				$user->user_pass = $customer_password;
			}

			if ( wc_notice_count( 'error' ) === 0 ) {
				wp_update_user( $user );
				$customer = new \WC_Customer( $customer_id );
				wc_add_notice( __( 'Customer details updated successfully.', 'woocommerce-wholesale-pricing' ) );
			}
		} elseif ( wc_notice_count( 'error' ) === 0 ) { // create customer
			// no required issue
				$new_customer = wc_create_new_customer(
					sanitize_email( $customer_email ),
					wc_clean( $customer_display_name ),
					$customer_password,
					array(
						'first_name' => $customer_first_name,
						'last_name'  => $customer_last_name,
					)
				);
			if ( is_wp_error( $new_customer ) ) {// couldn't add user
				wc_add_notice( $new_customer->get_error_message(), 'error' );
			} else { // added successfully
				$customer = new \WC_Customer( $new_customer );
				wc_add_notice( __( 'Customer details added successfully.', 'woocommerce-wholesale-pricing' ) );
			}
		}

		if ( isset( $customer ) && wc_notice_count( 'error' ) === 0 ) {
			$agent_id       = Actions::is_agent();
			update_user_meta( $customer->get_id(), 'sales_agent', $agent_id );
			$customer->set_billing_email( $customer_email );
			$customer->set_billing_first_name( $customer_first_name );
			$customer->set_billing_last_name( $customer_last_name );
			$customer->set_billing_company( $customer_company );
			$customer->set_billing_address( $customer_address );
			$customer->set_billing_country( $customer_country );
			$customer->set_billing_city( $customer_city );
			$customer->set_billing_state( $customer_state );
			$customer->set_billing_postcode( $customer_zip );
			$customer->set_billing_phone( $customer_phone );

			$user = '';
			if ( ! empty( $customer_ws_role ) ) {
				$user = new \WP_User( $customer->get_id() );
				$user->set_role( $customer_ws_role );
			}

			$customer->save();
			/**
			* Filter.
			*
			* @since 1.0.4
			*/
			do_action( 'woocommerce_save_account_details', $customer->get_id() );
			wp_safe_redirect( wc_get_endpoint_url( 'agent-customer', $customer->get_id() ) );
			exit;
		}
	}

	/**
	 * Handle view customer details
	 *
	 * @param type $parmter
	 */
	public function wc_agent_view_customer_point_handle( $customer_parameters ) {
		$customer            = '';
		$customer_parameters = explode( '/', $customer_parameters );
		$customer_id         = $customer_parameters[0];
		$customer            = new \WC_Customer( $customer_id );

		if ( ! $customer_id || ! $customer->get_id() ) {
			return printf( '<div class="woocommerce-notices-wrapper"><div class="woocommerce-info">%s</div></div>', esc_html__( 'Customer Not Found! ', 'woocommerce-wholesale-pricing' ) );
		}

		$agent_id      = Actions::get_customer_agent( $customer_id );
		$agent_user_id = Actions::get_agent_user_id( $agent_id );
		if ( get_current_user_id() != $agent_user_id ) {
			return printf( '<div class="woocommerce-notices-wrapper"><div class="woocommerce-info">%s</div></div>', esc_html__( 'Customer not found. ', 'woocommerce-wholesale-pricing' ) );
		}

		$per_page     = ( get_option( 'list_no_rows' ) ) ? get_option( 'list_no_rows' ) : 10;
		$current_page = ( isset( $customer_parameters[1] ) && $customer_parameters[1] ) ? $customer_parameters[1] : 1;
		$end_point    = 'view-customer/' . $customer_id;
		$action       = esc_url( wc_get_endpoint_url( $end_point ) );

		// get orders
		$general_action = new Agent();
		$orders_result  = (array) $general_action->get_orders(
			array(
				'customer_id' => $customer_id,
				'agent_id'    => $agent_id,
			),
			$per_page,
			$current_page
		);
		extract( $orders_result );

		if ( file_exists( get_stylesheet_directory() . '/woocommerce-wholesale-pricing/templates/endpoint/customer/customer-details.php' ) ) {
			include_once get_stylesheet_directory() . '/woocommerce-wholesale-pricing/templates/endpoint/customer/customer-details.php';
		} else {

			$num_pages = $max_num_pages;
			wwp_view('sales-agent.my-account.wc-agent-view-customer-details', compact('customer', 'agent_id', 'agent_user_id', 'per_page', 'current_page', 'end_point', 'action', 'orders', 'num_pages'));
		}
	}
}
