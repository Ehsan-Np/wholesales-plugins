<?php
namespace WooCommerceWholesalePricing\App\Modules\Quote;

use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;
use WooCommerceWholesalePricing\App\Modules\Quote\Admin\PDF\BronzePDF;
use WooCommerceWholesalePricing\App\Modules\Quote\Admin\PDF\DarkBluePDF;
use WooCommerceWholesalePricing\App\Modules\Quote\Admin\PDF\LightBluePDF;
use WooCommerceWholesalePricing\App\Modules\Quote\Admin\PDF\CustomPDF;

class Handler implements ServiceInterface {

	public function __construct() {
		$this->include_pdf_module();
	}

	public function include_pdf_module() {
		// PDF
		new BronzePDF();
		new DarkBluePDF();
		new LightBluePDF();
		new CustomPDF();
	}

	public static function resolveDependency() {
		return is_quote_enabled();
	}
}
