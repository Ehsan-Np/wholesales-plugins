<?php
namespace WooCommerceWholesalePricing\App\Modules\Quote;

class CheckoutService {

	public function __construct() {
		add_action('woocommerce_store_api_checkout_order_processed', array( $this, 'woocommerce_store_api_checkout_order_processed_action' ));
		add_action('woocommerce_checkout_order_processed', array( $this, 'woocommerce_store_api_checkout_order_processed_action' ));
	}

		
	/**
	 * Change Status of quote after the processed to checkout 
	 *
	 * @param  mixed $order
	 * @return void
	 */
	public function woocommerce_store_api_checkout_order_processed_action( $order ) {
		global $wpdb;
		$quote_id = WC()->session->get('quote_id');

		if (isset($quote_id) && null != $quote_id ) {
			$wpdb->update($wpdb->prefix . 'posts', array( 'post_status' => 'quote_converted' ), array( 'ID' => $quote_id ));
			update_post_meta($quote_id, 'converted_by_user', get_current_user());
			update_post_meta($quote_id, 'converted_by', __('Customer', 'wc_quote'));
			// Save quote_id to order meta
			$order->update_meta_data('quote_id', $quote_id);
			$order->save(); 
		}

		WC()->session->set('quote_id', null);
	}
}
