<?php
namespace WooCommerceWholesalePricing\App\Modules\Quote\Admin\PDF;

use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;


class BronzePDF extends Init {

	public $defaultImageUrl;
	public $quote_id;

	public function __construct() {

		parent::__construct();
		$this->defaultImageUrl = WWP_PUBLIC_URL . 'images/quote/products/defaultImage.jpg';
		$this->quote_id = isset($_REQUEST['quote_id']) ? sanitize_text_field($_REQUEST['quote_id']) : 0;
		add_action('current_screen', array( $this, 'wc_quote_register_bronze_block_pattern' ));
	}

	public function register() {
		$registry = \WP_Block_Type_Registry::get_instance();

		if ( ! $registry->is_registered( 'wc-quote/bronze-image' ) ) {
			register_block_type(
				'wc-quote/bronze-image', array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'bronze_image_block_render_html' ),
				'attributes'      => array(
					'imageUrl' => array( 'type' => 'string', 'default' => $this->defaultImageUrl ),
					'altText' => array( 'type' => 'string', 'default' => 'Default Image' ),
					'caption' => array( 'type' => 'string', 'default' => '' ),
					'alignment' => array( 'type' => 'string', 'default' => 'center' ),
					'size' => array( 'type' => 'string', 'default' => 'medium' ),
				),
				
				)
			);
		}

		if ( ! $registry->is_registered( 'wc-quote/bronze-tagline' ) ) {
			register_block_type(
				'wc-quote/bronze-tagline', array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'bronze_tagline_block_render_html' ),
			
				'attributes' => array(
					'content' => array(
						'type' => 'string',
						'default' => 'Your Tagline Here',
					),
					'fontSize' => array(
						'type' => 'string',
						'default' => 'M',
					),
					'customFontSize' => array(
						'type' => 'number',
						'default' => 18,
					),
					'isBold' => array(
						'type' => 'boolean',
						'default' => false,
					),
					'textColor' => array(
						'type' => 'string',
						'default' => '#000000',
					),
					'backgroundColor' => array(
					'type' => 'string',
					'default' => '#ffffff',
					),
					'textTransform' => array(
						'type' => 'string',
						'default' => 'none',
					),
				),
				)
			);
		}

		if ( ! $registry->is_registered( 'wc-quote/bronze-quotation-number' ) ) {
			register_block_type(
				'wc-quote/bronze-quotation-number', array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'bronze_quotationNo_block_render_html' ),
				'attributes' => array(
				'textColor' => array(
				'type' => 'string',
				'default' => '#000',
				),
				'backgroundColor' => array(
				'type' => 'string',
				'default' => '',
				),
				'fontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'textAlign' => array(
				'type' => 'string',
				'default' => 'left',
				),
				'quotationNoHeading' => array(
				'type' => 'string',
				'default' => __('Quotation Number :', 'woocommerce-wholesale-pricing'),
				),
				),
				)
			);
		}
			
		if ( ! $registry->is_registered( 'wc-quote/bronze-quotation-date' ) ) {
			register_block_type(
				'wc-quote/bronze-quotation-date', array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'bronze_quotationDate_block_render_html' ),
				'attributes' => array(
				'textColor' => array(
				'type' => 'string',
				'default' => '#000',
				),
				'backgroundColor' => array(
				'type' => 'string',
				'default' => '',
				),
				'fontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'textAlign' => array(
				'type' => 'string',
				'default' => 'left',
				),
				'quotationDate' => array(
				'type' => 'string',
				'default' => __('Quotation Date :', 'woocommerce-wholesale-pricing'),
				),
				),
				)
			);
		}

		if ( ! $registry->is_registered( 'wc-quote/bronze-product-details' ) ) {
			register_block_type(
				'wc-quote/bronze-product-details', array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'bronze_product_details_render_html' ),
				'attributes'      => array(
				'productHeader' => array(
				'type' => 'string',
				'default' => 'Product',
				),
				'quantityHeader' => array(
				'type' => 'string',
				'default' => 'Quantity',
				),
				'imageHeader' => array(
				'type' => 'string',
				'default' => 'Image',
				),
				'priceHeader' => array(
				'type' => 'string',
				'default' => 'Price',
				),
				'offeredPriceHeader' => array(
				'type' => 'string',
				'default' => 'Offered Price',
				),
				'subtotalHeader' => array(
				'type' => 'string',
				'default' => 'Subtotal',
				),
				'showQuantityColumn' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'showImageColumn' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'showPriceColumn' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'offeredPriceColumn' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'tableStyle' => array(
				'type' => 'object',
				'default' => array(
				'textTransform' => 'none',
				),
				),
				'backgroundColor' => array(
				'type' => 'string',
				'default' => '#D3A475',
				),
				'borderWidth' => array(
				'type' => 'string',
				'default'=> '0px 0px 1px 0px',
				),
				'borderColor' => array(
				'type' => 'string',
				'default' => '#ECECEC',
				),
				'padding' => array(
				'type' => 'string',
				'default' => '8px 15px',
				),
				// items style setting
				'titleColor' => array(
				'type' => 'string',
				'default' => '#000',
				),
				'titleFontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'titleTextTransform' => array(
				'type' => 'string',
				'default' => 'none',
				),
				'itemColor' => array(
				'type' => 'string',
				'default' => '#000',
				),
				'itemFontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'itemTextTransform' => array(
				'type' => 'string',
				'default' => 'none',
				),
				),
				)
			);
		}

		if ( ! $registry->is_registered( 'wc-quote/bronze-total' ) ) {
			register_block_type(
				'wc-quote/bronze-total', array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'bronze_total_render_html' ),
				'attributes'      => array(
				'subtotal' => array(
				'type' => 'string',
				'default' => __('Subtotal(standard):', 'woocommerce-wholesale-pricing'),
				),
				'subtotalOffered' => array(
				'type' => 'string',
				'default' => __('Subtotal(offered):', 'woocommerce-wholesale-pricing'),
				),
				'shipping' => array(
				'type' => 'string',
				'default' => __('Shipping :', 'woocommerce-wholesale-pricing'),
				),
				'tax' => array(
				'type' => 'string',
				'default' => __('Tax(standard):', 'woocommerce-wholesale-pricing'),
				),
				'taxOffered' => array(
				'type' => 'string',
				'default' => __('Tax(offered):', 'woocommerce-wholesale-pricing'),
				),
				'total' => array(
				'type' => 'string',
				'default' => __('Total(standard):', 'woocommerce-wholesale-pricing'),
				),
				'totalOffered' => array(
				'type' => 'string',
				'default' => __('Total(offered):', 'woocommerce-wholesale-pricing'),
				),
				'showShipping' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'showTax' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'showTaxOffered' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'showsubtotalOffered' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'tableHeadingBgColor' => array(
				'type' => 'string',
				'default' => '#D3A475',
				), 'tableItemBgColor' => array(
				'type' => 'string',
				'default' => '#000000',
				),
				'showTotal' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'showTotalOffered' => array(
				'type' => 'boolean',
				'default' => true,
				),
				'tableStyle' => array(
				'type' => 'object',
				'default' => array(
				'textTransform' => 'none',
				),
				),
				'backgroundColor' => array(
				'type' => 'string',
				'default' => '#fff',
				),
				'titleColor' => array(
				'type' => 'string',
				'default' => '#000',
				),
				'titleFontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'titleTextTransform' => array(
				'type' => 'string',
				'default' => 'none',
				),
				'itemColor' => array(
				'type' => 'string',
				'default' => '#fff',
				),
				'itemFontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'align' => array(
				'type' => 'string',
				'default' => 'left',
				),
				'borderWidth' => array(
				'type' => 'string',
				'default'=> '0px 0px 1px 0px',
				),
				'borderColor' => array(
				'type' => 'string',
				'default' => '#fff',
				),
				'padding' => array(
				'type' => 'string',
				'default' => '8px 15px',
				),
				),
				)
			);
		}

		if ( ! $registry->is_registered( 'wc-quote/bronze-customer-info' ) ) {
			register_block_type(
				'wc-quote/bronze-customer-info', array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'bronze_customer_info_render_html' ),
				)
			);
		}

		if ( ! $registry->is_registered( 'wc-quote/bronze-footer-block' ) ) {
			register_block_type(
				'wc-quote/bronze-footer-block', array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'bronze_footer_render_html' ),
				)
			);
		}

		if ( ! $registry->is_registered( 'wc-quote/bronze-shipping-method' ) ) {
			register_block_type(
				'wc-quote/bronze-shipping-method', array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'bronze_shipping_method_render_html' ),
				'attributes' => array(
				'textColor' => array(
				'type' => 'string',
				'default' => '#000',
				),
				'backgroundColor' => array(
				'type' => 'string',
				'default' => '',
				),
				'fontSize' => array(
				'type' => 'number',
				'default' => 16,
				),
				'textAlign' => array(
				'type' => 'string',
				'default' => 'left',
				),
				'shippingMethod' => array(
				'type' => 'string',
				'default' => __('Shipping Method', 'woocommerce-wholesale-pricing'),
				),
				),
				)
			);
		}

		if ( ! $registry->is_registered( 'wc-quote/bronze-terms-condition-block' ) ) {
			register_block_type(
				'wc-quote/bronze-terms-condition-block', array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'bronze_terms_condition_render_html' ),
				)
			);
		}

		if ( ! $registry->is_registered( 'wc-quote/bronze-author-info' ) ) {
			register_block_type(
				'wc-quote/bronze-author-info', array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'bronze_author_info_render_html' ),

				'attributes' => array(
				'headingBgColor' => array( 'type' => 'string', 'default' => '#ffffff' ),
				'headingTextColor' => array( 'type' => 'string', 'default' => '#333' ),
				'itemBgColor' => array( 'type' => 'string', 'default' => '#ffffff' ),
				'itemTextColor' => array( 'type' => 'string', 'default' => '#333' ),
				'headingFontSize' => array( 'type' => 'number', 'default' => 14 ),
				'itemFontSize' => array( 'type' => 'number', 'default' => 12 ),
				'columnSpacing' => array( 'type' => 'number', 'default' => 0 ),
				'borderColor' => array( 'type' => 'string', 'default' => '#ECECEC' ),
				'fields' => array(
				'type' => 'object',
				'default' => array(
				'countryName' => true,
				// 'yourBusiness' => true,
				'address' => true,
				'city' => true,
				'zipCode' => true,
				'state' => true,
				'email' => true,
				'phoneNumber' => true,
				),
				),
				),
				)
			);
		}

		if ( ! $registry->is_registered( 'wc-quote/bronze-signature' ) ) {
			register_block_type(
				'wc-quote/bronze-signature', array(
				'editor_script' => 'wc_quote_pdf_block_type',
				'render_callback' => array( $this, 'bronze_signature_render_html' ),
				'signature' => array(
				'signatureData' => array(
				'type' => 'string',
				'default' => '',
				),
				),
				)
			);
		}
	}

	public function bronze_image_block_render_html( $attributes ) {
		// Extract attributes
		$imageUrl = isset($attributes['imageUrl']) ? esc_url($attributes['imageUrl']) : $this->defaultImageUrl;
		$altText = isset($attributes['altText']) ? esc_attr($attributes['altText']) : 'Default Image';
		$alignment = isset($attributes['alignment']) ? esc_attr($attributes['alignment']) : 'center';
		$size = isset($attributes['size']) ? esc_attr($attributes['size']) : 'medium';

		$sizeStyle = 'small' === $size ? '150px' : ( 'medium' === $size ? '300px' : '600px' );

		ob_start();
		?>
		<div class="wp-block-custom-image-block align<?php echo esc_attr($alignment); ?>" style="text-align: <?php echo esc_attr($alignment); ?>;">
			<?php if ($imageUrl) : ?>
				<img src="<?php echo esc_attr($imageUrl); ?>" alt="<?php echo esc_attr($altText); ?>" style="width: <?php echo esc_attr($sizeStyle); ?>; max-width: 100%;" />
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	public function bronze_tagline_block_render_html( $attributes ) {
	
		$content = isset($attributes['content']) ? $attributes['content'] : 'Your Tagline Here';
		// die();
		$fontSizeMap = array(
		'S' => '14px',
		'M' => '18px',
		'L' => '24px',
		'XL' => '32px',
		'XXXL' => '48px',
		'Custom' => isset($attributes['customFontSize']) ? esc_attr($attributes['customFontSize']) . 'px' : '18px',
		);

		$fontSize = isset($attributes['fontSize']) ? esc_attr($fontSizeMap[ $attributes['fontSize'] ]) : '18px';
		$textColor = isset($attributes['textColor']) ? esc_attr($attributes['textColor']) : '#000000';
		$backgroundColor = isset($attributes['backgroundColor']) ? esc_attr($attributes['backgroundColor']) : '#ffffff';
		$isBold = isset($attributes['isBold']) && $attributes['isBold'] ? 'bold' : 'normal';
		$textTransform = isset($attributes['textTransform']) ? esc_attr($attributes['textTransform']) : 'none';

		ob_start();
		?>
		<p style="
			color: <?php echo esc_attr($textColor); ?>;
			background-color: <?php echo esc_attr($backgroundColor); ?>;
			font-size: <?php echo esc_attr($fontSize); ?>;
			font-weight: <?php echo esc_attr($isBold); ?>;
			text-transform: <?php echo esc_attr($textTransform); ?>;
			padding: 0px;

		">
			<?php echo esc_html($content); ?>
		</p>
		<?php
		return ob_get_clean();
	}

	// Dynamic Done  ===> 
	public function bronze_quotationNo_block_render_html( $attributes ) {

		$styles = '';
		$quotationNoHeading = $attributes['quotationNoHeading'];
		if (!empty($attributes['textColor'])) {
			$styles .= 'color:' . esc_attr($attributes['textColor']) . ';';
		}
		if (!empty($attributes['backgroundColor'])) {
			$styles .= 'background-color:' . esc_attr($attributes['backgroundColor']) . ';';
		}
		if (!empty($attributes['fontSize'])) {
			$styles .= 'font-size:' . esc_attr($attributes['fontSize']) . 'px;';
		}
		if (!empty($attributes['textAlign'])) {
			$styles .= 'text-align:' . esc_attr($attributes['textAlign']) . ';';
		}
		ob_start();
		?>
		<div class="invoice-number" style="<?php echo esc_attr($styles); ?>">
			<p><strong><?php echo esc_html($quotationNoHeading); ?></strong> &nbsp; <span><?php echo isset($this->quote_id) ?  esc_html($this->quote_id) : esc_html('[quotation_number]'); ?></span></p>
		</div>
		<?php
		return ob_get_clean();
	}

	// Dynamic Done ===> 
	public function bronze_quotationDate_block_render_html( $attributes ) {

		// Get the creation date for the quote ID
		$date = get_the_date('F j, Y', $this->quote_id);

		// If no creation date is found, set a default or fallback
		if (empty($date)) {
			$date = '[quotation_date]';
		}
	 
		$styles = '';
		$quotationDate = $attributes['quotationDate'];
		if (!empty($attributes['textColor'])) {
			$styles .= 'color:' . esc_attr($attributes['textColor']) . ';';
		}
		if (!empty($attributes['backgroundColor'])) {
			$styles .= 'background-color:' . esc_attr($attributes['backgroundColor']) . ';';
		}
		if (!empty($attributes['fontSize'])) {
			$styles .= 'font-size:' . esc_attr($attributes['fontSize']) . 'px;';
		}
		if (!empty($attributes['textAlign'])) {
			$styles .= 'text-align:' . esc_attr($attributes['textAlign']) . ';';
		}
		ob_start();
		?>
		<div class="invoice-number" style="<?php echo esc_attr($styles); ?>">
			<p><strong><?php echo esc_html($quotationDate); ?></strong> &nbsp; <span><?php echo esc_html( ! empty($date) ? $date : '[quotation_date]' ); ?></span></p>
		</div>
		<?php
		return ob_get_clean();
	}

	// Dynamic Done ===> 
	public function bronze_product_details_render_html( $attributes ) {

		$quote_contents = get_post_meta($this->quote_id, 'quote_contents', true);
		$productHeader = $attributes['productHeader'];
		$quantityHeader = $attributes['quantityHeader'];
		$priceHeader = $attributes['priceHeader'];
		$imageHeader = $attributes['imageHeader'];
		// $subtotalHeader = $attributes['subtotalHeader'];
		$offeredPriceHeader = $attributes['offeredPriceHeader'];
		$showQuantityColumn = $attributes['showQuantityColumn'];
		$showPriceColumn = $attributes['showPriceColumn'];
		$showImageColumn = $attributes['showImageColumn'];
		$offeredPriceColumn = $attributes['offeredPriceColumn'];
		$textTransform = $attributes['tableStyle']['textTransform'];
		$backgroundColor = $attributes['backgroundColor'];
		$borderColor = $attributes['borderColor'];
		$borderWidth = $attributes['borderWidth'];
		$padding = $attributes['padding'];
		$titleColor = $attributes['titleColor'];
		$titleFontSize = $attributes['titleFontSize'];
		$titleTextTransform = $attributes['titleTextTransform'];
		$itemColor = $attributes['itemColor'];
		$itemFontSize = $attributes['itemFontSize'];
		$itemTextTransform = $attributes['itemTextTransform'];        
		$columnSpacing = isset($attributes['columnSpacing']) ? $attributes['columnSpacing'] : 0;
		ob_start();
		?>

		<table class="invoice-product-table" style="background-color: white; width: 100%;  border-spacing: <?php echo esc_attr($columnSpacing); ?>px;"   >
			<thead>
			<tr style="background-color: <?php echo esc_attr($backgroundColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>">
		
				<th style=" background-color: <?php echo esc_attr($backgroundColor); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>" ><?php echo esc_attr($productHeader); ?></th>
			<?php 
			if ($showPriceColumn) :
				?>
					<th style=" background-color: <?php echo esc_attr($backgroundColor); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>" ><?php echo esc_attr($priceHeader); ?></th>
					<?php 
			endif;
			?>
			<?php 
			if ($showQuantityColumn) :
				?>
					<th style=" background-color: <?php echo esc_attr($backgroundColor); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>" ><?php echo esc_attr($quantityHeader); ?></th>
					 <?php 
			endif;
			?>
			<?php 
			if ($offeredPriceColumn) :
				?>
					<th style=" background-color: <?php echo esc_attr($backgroundColor); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>" ><?php echo esc_attr($offeredPriceHeader); ?></th>
					<?php 
			endif;
			?>

			</tr>
			</thead>
			<tbody style="background-color: white;">

			<?php
			if (isset($quote_contents) && !empty($quote_contents)) {
				
				foreach ( $quote_contents as $key => $content ) {
					if ( 0 == $key ) {
						continue;
					}

					$image_id = $content['data']->get_image_id(); // Image ID
					$image_url = wp_get_attachment_url($image_id); // Image URL
					if ( empty( $image_url ) ) {
						$image_url = wc_placeholder_img_src('woocommerce_thumbnail');
					}
					$product_name = $content['data'] ? $content['data']->get_name() : 'N/A';
					$sku = $content['data']->get_sku() ?  $content['data']->get_sku() : 'N/A'; // Get SKU
					$product_price = $content['data'] ? $content['data']->get_price()  : 0; // Standard price
					$quantity = $content['quantity']; // Quantity
					// $subtotal = $content['data'] ?  $quantity * $product_price : 0;
					$offeredPrice = $content['data'] ?  $content['offered_price']:0; // Offered price

					?>

						<tr style="background-color: white; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($itemTextTransform); ?>">

							<td style="padding: <?php echo esc_attr($padding); ?>; border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>; -webkit-padding: <?php echo esc_attr($padding); ?>; -webkit-border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>">
					<?php //echo esc_html($product_name); ?>
								<div style= "display:flex;">
					<?php
					if ($showImageColumn) :
						?>
										<div style="padding: <?php echo esc_attr($padding); ?>; border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>; -webkit-padding: <?php echo esc_attr($padding); ?>; -webkit-border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>">
											<img src=<?php echo esc_url($image_url); ?> alt="<?php echo esc_attr( $product_name ); ?>" style="margin-right: 8px; width: 70px; height: 70px;">    
										</div>
					<?php endif; ?>
										<div>
											<div><?php echo wp_kses_post($product_name); ?></div>
											<div><strong>SKU:</strong> <?php echo wp_kses_post($sku); ?></div>
										</div>
									</div>
							</td>
					<?php 
					if ($showPriceColumn) :
						?>
								<td style="padding: <?php echo esc_attr($padding); ?>; border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>; -webkit-padding: <?php echo esc_attr($padding); ?>; -webkit-border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>"><?php echo wp_kses_post(wc_price($product_price)); ?></td>
								<?php 
					endif;
					?>
					<?php 
					if ($showQuantityColumn) :
						?>
								<td style="padding: <?php echo esc_attr($padding); ?>; border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>; -webkit-padding: <?php echo esc_attr($padding); ?>; -webkit-border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>"><?php echo esc_html($quantity); ?></td>
								<?php 
					endif;
					?>
					<?php 
					if ($offeredPriceColumn) :
						?>
								<td style="padding: <?php echo esc_attr($padding); ?>; border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>; -webkit-padding: <?php echo esc_attr($padding); ?>; -webkit-border-bottom: <?php echo esc_attr('1px solid ' . $borderColor); ?>"><?php echo wp_kses_post(wc_price($offeredPrice)); ?></td>
								 <?php 
					endif;
					?>
						</tr>

					<?php 
				}
			} else {
					echo '<tr style="background-color: white; color:' . esc_attr($itemColor) . '; font-size: ' . esc_attr($itemFontSize) . 'px; text-transform: ' . esc_attr($itemTextTransform) . ';">';
				echo '<td colspan="5" style="padding: 8px 15px; border-bottom: 1px solid ' . esc_attr($borderColor) . ';">No Products Found</td>';
					echo '</tr>';
			}
			?>

			</tbody>
		</table>
		<?php
		return ob_get_clean();
	}

	// Dynamic Done ===> 
	public function bronze_total_render_html( $attributes ) {

		$quote_contents = get_post_meta($this->quote_id, 'quote_contents', true);
		$getCalTotal = new QuoteProcess();
		$calculatedTotal = $getCalTotal->get_calculated_totals($quote_contents, $this->quote_id);

		$subtotal = $attributes['subtotal'];
		$subtotalOffered = $attributes['subtotalOffered'];
		$tax = $attributes['tax'];
		$taxOffered = $attributes['taxOffered'];
		$shipping = $attributes['shipping'];
		$showShipping = $attributes['showShipping'];
		$total = $attributes['total'];
		$totalOffered = $attributes['totalOffered'];

		// heading & item bg color 
		$tableHeadingBgColor = $attributes['tableHeadingBgColor'];
		$tableItemBgColor = $attributes['tableItemBgColor'];

		$backgroundColor = $attributes['backgroundColor'];
		$titleColor = $attributes['titleColor'];
		$titleFontSize = $attributes['titleFontSize'];
		$titleTextTransform = $attributes['titleTextTransform'];
		$itemColor = $attributes['itemColor'];
		$itemFontSize = $attributes['itemFontSize'];
		$align = $attributes['align'];
		$borderColor = $attributes['borderColor'];
		$borderWidth = $attributes['borderWidth'];
		$padding = $attributes['padding'];
		ob_start();
		 
		if (! empty($quote_contents)) {

			$sub_total_amount = $calculatedTotal['_subtotal'];
			$sub_total_offered_amount = $calculatedTotal['_offered_total'];
			$tax_total = $calculatedTotal['_tax_total'];
			$tax_offered = $calculatedTotal['_tax_total_offered'];
			$shipping_total = $calculatedTotal['_shipping'];
			$total_standard = $calculatedTotal['_total'];
			$total_offered_amount = $calculatedTotal['cal_offered_total'];
		} else {
			$sub_total_amount = 0;
			$sub_total_offered_amount = 0;
			$tax_total = 0;
			$tax_offered = 0;
			$shipping_total = 0;
			$total_standard = 0;
			$total_offered_amount = 0;
		}
		?>
		 
		<table class="invoice-product-table total-table-invoice" style="border-collapse: collapse; width: 100%; margin-bottom: 20px;">
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html($subtotal); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($sub_total_amount)); ?></td>
			</tr>
		<?php if ($attributes['showsubtotalOffered']) : ?>
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html($subtotalOffered); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($sub_total_offered_amount)); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ($attributes['showTax']) : ?>
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html(isset($calculatedTotal['_tax_label']) ? $calculatedTotal['_tax_label'] : $tax); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($tax_total)); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ($attributes['showTaxOffered']) : ?>
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html($taxOffered); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($tax_offered)); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ($attributes['showShipping']) : ?>
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html($shipping); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($shipping_total)); ?></td>
			</tr>
		<?php endif; ?>

		<?php if ($attributes['showTotal']) : ?>
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html($total); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($total_standard)); ?></td>
			</tr>
		<?php endif; ?>
		 
		<?php if ($attributes['showTotalOffered']) : ?>
			<tr>
				<th style="vertical-align: middle; background-color: <?php echo esc_attr($tableHeadingBgColor); ?>; color: <?php echo esc_attr($titleColor); ?>; font-size: <?php echo esc_attr($titleFontSize . 'px'); ?>; text-transform: <?php echo esc_attr($titleTextTransform); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo esc_html($totalOffered); ?></th>
				<td style="background-color: <?php echo esc_attr($tableItemBgColor); ?>; color: <?php echo esc_attr($itemColor); ?>; font-size: <?php echo esc_attr($itemFontSize . 'px'); ?>; border-width: <?php echo esc_attr($borderWidth); ?>; border-color: <?php echo esc_attr($borderColor); ?>; padding: <?php echo esc_attr($padding); ?>; "><?php echo wp_kses_post(wc_price($total_offered_amount)); ?></td>
			</tr>
		<?php endif; ?>    

		</table>
		<?php
		return ob_get_clean();
	}

	// Dynamic Done ===> 
	public function bronze_customer_info_render_html( $attributes ) {

		$quote_fields = ( get_post_meta($this->quote_id, 'quote_fields', true) );
		$form_config = json_decode(str_replace('"false"', 'false', wp_unslash(get_option('wc_quote_form_builder'))), true);

		if (isset($quote_fields)) {
			$date = get_the_date('F j, Y', $this->quote_id);

		} else {
			$date = '[quote_date]';
		}    

		$topHeadingText = esc_html($attributes['topHeadingText'] ? $attributes['topHeadingText'] : 'Customer Information');
		$headingFontSize = isset( $attributes['headingFontSize'] ) ? intval($attributes['headingFontSize']) : 14;
		$itemFontSize = isset( $attributes['itemFontSize'] ) ? intval($attributes['itemFontSize']) : 12;
		$columnSpacing = isset( $attributes['columnSpacing'] ) ? intval($attributes['columnSpacing']) : 0;

		// Updated ================

		$rows = array();
		// Check for visibility of each field before adding it to the rows
		if (!array_key_exists('quoteNumberVisible', $attributes)) {
			$rows[] = array( 'label' => esc_html(isset( $attributes['quoteNumber'] ) ? $attributes['quoteNumber'] : 'Quote Number'), 'value' =>  $this->quote_id || 0 !== $this->quote_id   ? $this->quote_id : '[quote_number]' );
		}
	 
		if (!array_key_exists('quoteDateVisible', $attributes)) {
			$rows[] = array( 'label' => esc_html(isset( $attributes['quoteDate'] ) ? $attributes['quoteDate'] : 'Quote Date'), 'value' =>  $date ? $date : '[quote_date]' );
		}


		// Add dynamic fields
		if (!empty($form_config['components']) && is_array($form_config['components'])) {
			foreach ($form_config['components'] as $component) {
				$key = $component['key'] ? $component['key'] : '';
				$label = $component['label'] ? $component['label'] : ucfirst($key);


				$value = !empty($quote_fields[$key]) ? sanitize_text_field($quote_fields[$key]) : '';

				if ( empty($value) ) {
					continue;
				}

				$rows[] = array(
					'label' => esc_html($label),
					'value' => $value,
				);
			}
		}

		ob_start();
		?>

		<div class="customer-info-block-preview">
			<table style="width: 100%; border-spacing: <?php echo esc_attr($columnSpacing); ?>px;">
				<thead>
					<tr>
						<th colspan="2" style="
							background-color: <?php echo esc_attr(isset($attributes['topHeadingBgColor'] ) ? $attributes['topHeadingBgColor'] : '#D3A475'); ?>;
							color: <?php echo esc_attr(isset($attributes['topHeadingFontColor'] ) ? $attributes['topHeadingFontColor'] : '#000'); ?>;
							font-size: <?php echo esc_attr(isset($attributes['topHeadingFontSize'] ) ? $attributes['topHeadingFontSize'] : '16'); ?>px;
							border: 1px solid <?php echo esc_attr(isset($attributes['borderColor'] ) ? $attributes['borderColor'] : '#ECECEC'); ?>;
						">
							<?php echo esc_html($topHeadingText); ?>
						</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($rows as $row) : ?>
						<tr>
							<th style="
								background-color: <?php echo esc_attr(isset( $attributes['headingBgColor'] ) ? $attributes['headingBgColor'] : '#ffffff'); ?>;
								color: <?php echo esc_attr(isset( $attributes['headingTextColor'] ) ? $attributes['headingTextColor'] : '#333'); ?>;
								font-size: <?php echo esc_attr($headingFontSize); ?>px;
								border: 1px solid <?php echo esc_attr(isset( $attributes['borderColor'] ) ? $attributes['borderColor'] : '#ECECEC'); ?>;
							">
								<?php echo esc_html($row['label']); ?>
							</th>
							<td style="
								background-color: <?php echo esc_attr(isset( $attributes['itemBgColor'] ) ? $attributes['itemBgColor'] : '#ffffff'); ?>;
								color: <?php echo esc_attr(isset( $attributes['itemTextColor'] ) ? $attributes['itemTextColor'] : '#333'); ?>;
								font-size: <?php echo esc_attr($itemFontSize); ?>px;
								border: 1px solid <?php echo esc_attr(isset( $attributes['borderColor'] ) ? $attributes['borderColor'] : '#ECECEC'); ?>;
							">
								<!-- Old One   -->
								<!-- add php tag echo esc_html($row['value']);  -->
								<p style="max-width: 300px; "><?php echo esc_html($row['value']); ?></p>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php
		return ob_get_clean();
	}

	public function bronze_footer_render_html( $attributes ) {
		// Extract block attributes
		$footerText = isset($attributes['footerText']) ? $attributes['footerText'] : 'Footer content goes here';
		$fontSize = isset($attributes['fontSize']) ? $attributes['fontSize'] : 16;
		$fontColor = isset($attributes['fontColor']) ? $attributes['fontColor'] : '#000000';
		$backgroundColor = isset($attributes['backgroundColor']) ? $attributes['backgroundColor'] : '#D3A475';
		$textAlignment = isset($attributes['textAlignment']) ? $attributes['textAlignment'] : 'center';
		$isBold = isset($attributes['isBold']) ? $attributes['isBold'] : false;
		$padding = isset($attributes['padding']) ? $attributes['padding'] : 10;
		$borderRadius = isset($attributes['borderRadius']) ? $attributes['borderRadius'] : 5;

		// Output the block's HTML with dynamic styles
		ob_start();
		?>
		<div style="
			font-size: <?php echo esc_attr($fontSize); ?>px;
			color: <?php echo esc_attr($fontColor); ?>;
			background-color: <?php echo esc_attr($backgroundColor); ?>;
			padding: <?php echo esc_attr($padding); ?>px;
			text-align: <?php echo esc_attr($textAlignment); ?>;
			font-weight: <?php echo $isBold ? 'bold' : 'normal'; ?>;
			border-radius: <?php echo esc_attr($borderRadius); ?>px;
		">
				<?php echo esc_html($footerText); ?>
		</div>
		<?php
		return ob_get_clean();
	}

	public function bronze_terms_condition_render_html( $attributes ) { 

		// Extract block attributes
		$termsConditionText = isset($attributes['termsConditionText']) ? $attributes['termsConditionText'] : 'Terms Conditions';
		$fontSize = isset($attributes['fontSize']) ? $attributes['fontSize'] : 16;
		$fontColor = isset($attributes['fontColor']) ? $attributes['fontColor'] : '#000000';
		$backgroundColor = isset($attributes['backgroundColor']) ? $attributes['backgroundColor'] : '#D3A475';
		$textAlignment = isset($attributes['textAlignment']) ? $attributes['textAlignment'] : 'center';
		$isBold = isset($attributes['isBold']) ? $attributes['isBold'] : false;
		$padding = isset($attributes['padding']) ? $attributes['padding'] : 10;
		$borderRadius = isset($attributes['borderRadius']) ? $attributes['borderRadius'] : 5;

		// Output the block's HTML with dynamic styles
		ob_start();
		?>
		<div style="
			font-size: <?php echo esc_attr($fontSize); ?>px;
			color: <?php echo esc_attr($fontColor); ?>;
			background-color: <?php echo esc_attr($backgroundColor); ?>;
			padding: <?php echo esc_attr($padding); ?>px;
			text-align: <?php echo esc_attr($textAlignment); ?>;
			font-weight: <?php echo $isBold ? 'bold' : 'normal'; ?>;
			border-radius: <?php echo esc_attr($borderRadius); ?>px;
			margin-top:10px;
		">

			<style>
				li.custom-bullet-list {
					list-style: none!important;
				}
				li.custom-bullet-list:before {
					content: '\2022';
					font-size: 24px;
					display: inline-block;
					line-height: 1;
					margin-right: 10px;
				}
			</style>
		
			<!-- Old   -->
			<?php //echo nl2br(esc_html($termsConditionText)); ?>
			<?php echo wp_kses_post($termsConditionText); // nosemgrep ?>
			
		</div>
		<?php
		return ob_get_clean();
	}

	public function bronze_shipping_method_render_html( $attributes ) {

		$quote_contents = get_post_meta($this->quote_id, 'quote_contents', true);
		$getCalTotal = new QuoteProcess();
		$calculatedTotal = $getCalTotal->get_calculated_totals($quote_contents, $this->quote_id);

		// $shippint_method = '';
		if (isset($quote_contents)) {
			// Retrieve and format the shipping method in one step if not formatted. 
			$shipping_method = isset($calculatedTotal['shipping_method'])
			? ucwords(str_replace('_', ' ', explode(':', $calculatedTotal['shipping_method'])[0]))
			: '';
		}


		$styles = '';
		$shippingMethod = $attributes['shippingMethod'];
		if (!empty($attributes['textColor'])) {
			$styles .= 'color:' . esc_attr($attributes['textColor']) . ';';
		}
		if (!empty($attributes['backgroundColor'])) {
			$styles .= 'background-color:' . esc_attr($attributes['backgroundColor']) . ';';
		}
		if (!empty($attributes['fontSize'])) {
			$styles .= 'font-size:' . esc_attr($attributes['fontSize']) . 'px;';
		}
		if (!empty($attributes['textAlign'])) {
			$styles .= 'text-align:' . esc_attr($attributes['textAlign']) . ';';
		}
		ob_start();
		?>
		<div class="invoice-number" style="<?php echo esc_attr($styles); ?>">
			<p><strong><?php echo esc_html($shippingMethod); ?></strong> <span> &nbsp; <?php echo $shipping_method ? esc_html($shipping_method) : esc_html('[shipping_method]'); ?></span></p>
		</div>
		<?php
		return ob_get_clean();
	}

	public function bronze_author_info_render_html( $attributes ) {

		$topHeadingText = esc_html($attributes['topHeadingText'] ? $attributes['topHeadingText'] : 'Author Information');
		$headingFontSize = intval($attributes['headingFontSize'] ? $attributes['headingFontSize'] : 14);
		$itemFontSize = intval($attributes['itemFontSize'] ? $attributes['itemFontSize'] : 12);
		$columnSpacing = intval($attributes['columnSpacing'] ? $attributes['columnSpacing'] : 0);

		$fields = array(
			'countryName'  => array( 
				'label' => esc_html($attributes['fieldLabels']['countryName'] ? $attributes['fieldLabels']['countryName'] : __('Country Name', 'woocommerce-wholesale-pricing')), 
				'value' => '[country_name]', 
			),
			'address'      => array( 
				'label' => esc_html($attributes['fieldLabels']['address'] ? $attributes['fieldLabels']['address'] : __('Address', 'woocommerce-wholesale-pricing')), 
				'value' => '[address]', 
			),
			'city'         => array( 
				'label' => esc_html($attributes['fieldLabels']['city'] ? $attributes['fieldLabels']['city'] : __('City', 'woocommerce-wholesale-pricing')), 
				'value' => '[city]', 
			),
			'zipCode'      => array( 
				'label' => esc_html($attributes['fieldLabels']['zipCode'] ? $attributes['fieldLabels']['zipCode'] : __('ZIP Code', 'woocommerce-wholesale-pricing')), 
				'value' => '[zip_code]', 
			),
			'state'        => array( 
				'label' => esc_html($attributes['fieldLabels']['state'] ? $attributes['fieldLabels']['state'] : __('State', 'woocommerce-wholesale-pricing')), 
				'value' => '[state]', 
			),
			'email'        => array( 
				'label' => esc_html($attributes['fieldLabels']['email'] ? $attributes['fieldLabels']['email'] : __('Email', 'woocommerce-wholesale-pricing')), 
				'value' => '[email]', 
			),
			'phoneNumber'  => array( 
				'label' => esc_html($attributes['fieldLabels']['phoneNumber'] ? $attributes['fieldLabels']['phoneNumber'] : __('Phone Number', 'woocommerce-wholesale-pricing')), 
				'value' => '[phone_number]', 
			),
		);
		

		ob_start();
		?>
		<div class="author-info-block-preview">
			<table style="width: 100%; border-spacing: <?php echo esc_attr($columnSpacing); ?>px;">
				<thead>
					<tr>
						<th colspan="2" style="
							background-color: <?php echo esc_attr($attributes['topHeadingBgColor'] ? $attributes['topHeadingBgColor'] : '#D3A475'); ?>;
							color: <?php echo esc_attr($attributes['topHeadingFontColor'] ? $attributes['topHeadingFontColor'] : '#000'); ?>;
							font-size: <?php echo esc_attr($attributes['topHeadingFontSize'] ? $attributes['topHeadingFontSize'] : '16'); ?>px;
							border: 1px solid <?php echo esc_attr($attributes['borderColor'] ? $attributes['borderColor'] : '#000'); ?>;
						">
							<?php echo esc_html($topHeadingText); ?>
						</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($fields as $key => $field) : ?>
						<?php if (!empty($attributes['fields'][$key]) && 1 == $attributes['fields'][$key] ) : // Check if the field is set to 1 ?>
							<tr>
								<th style="
									background-color: <?php echo esc_attr($attributes['headingBgColor'] ? $attributes['headingBgColor'] : '#f0f0f0'); ?>;
									color: <?php echo esc_attr($attributes['headingTextColor'] ? $attributes['headingTextColor'] : '#333'); ?>;
									font-size: <?php echo esc_attr($headingFontSize); ?>px;
									border: 1px solid <?php echo esc_attr($attributes['borderColor'] ? $attributes['borderColor'] : '#000'); ?>;
								">
									<?php echo esc_html($field['label']); ?>
								</th>
								<td style="
									background-color: <?php echo esc_attr($attributes['itemBgColor'] ? $attributes['itemBgColor'] : '#ffffff'); ?>;
									color: <?php echo esc_attr($attributes['itemTextColor'] ? $attributes['itemTextColor'] : '#333'); ?>;
									font-size: <?php echo esc_attr($itemFontSize); ?>px;
									border: 1px solid <?php echo esc_attr($attributes['borderColor'] ? $attributes['borderColor'] : '#000'); ?>;
								">
									<!-- Old One -->
									<!-- echo esc_html($field['value']); -->
									<p style="max-width: 300px; "><?php echo esc_html($field['value']); ?></p>
								</td>
							</tr>
						<?php endif; ?>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
		return ob_get_clean();
	}

	public function bronze_signature_render_html( $attributes ) {
		ob_start();
		?>
		<div class="bronze-signature">
			<?php if (!empty($attributes['signature'])) : ?>
				<img 
					src="<?php echo esc_attr($attributes['signature']); ?>" 
					alt="Signature" 
					style="width:100%; max-width: 400px; border: 0px solid #ccc; padding: 10px;"
				/>
			<?php else : ?>
				<p style="font-style: italic; color: #666;"><?php echo esc_html__('No signature available.', 'woocommerce-wholesale-pricing'); ?></p>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	// TEMPLATE
	public function wc_quote_register_bronze_block_pattern() {
		$screen = get_current_screen();
		$screen_id = $screen ? $screen->id : '';

		if (in_array($screen_id, array( 'custom_pdf' ))) {
		 
			register_block_pattern_category(
				'Wc quote Custom PDF',
				array( 'label' => __('B2B Request a Quote', 'woocommerce-wholesale-pricing') )
			);

			// Register Bronze block pattern
			register_block_pattern(
				'wc-quote-custom-pdf/bronze',
				array(
				'categories'    => array( 'Wc quote Custom PDF' ),
				'title'         => 'Bronze PDF',
				'description'   => 'Create PDF template for Bronze',
				'content' => '
					
				<!-- wp:columns -->
				<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center"} -->
				<div class="wp-block-column is-vertically-aligned-center"><!-- wp:wc-quote/bronze-image {"imageUrl":"http://local-projects.local/wp-content/uploads/2024/11/images.jpg","altText":"Selected Image"} /--></div>
				<!-- /wp:column -->

				<!-- wp:column {"verticalAlignment":"center","width":""} -->
				<div class="wp-block-column is-vertically-aligned-center"><!-- wp:heading -->
				<h2 class="wp-block-heading"><strong>Dev</strong></h2>
				<!-- /wp:heading -->

				<!-- wp:wc-quote/bronze-tagline {"fontSize":"S"} /--></div>
				<!-- /wp:column -->

				<!-- wp:column {"verticalAlignment":"top","width":"","fontSize":"normal"} -->
				<div class="wp-block-column is-vertically-aligned-top has-normal-font-size"><!-- wp:heading {"style":{"spacing":{"margin":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"0","right":"0"}},"elements":{"link":{"color":{"text":"#d3a475"}}},"color":{"text":"#d3a475"}}} -->
				<h2 class="wp-block-heading has-text-color has-link-color" style="color:#d3a475;margin-top:var(--wp--preset--spacing--40);margin-right:0;margin-bottom:var(--wp--preset--spacing--40);margin-left:0"><strong>QUOTATION</strong></h2>
				<!-- /wp:heading -->

				<!-- wp:wc-quote/bronze-quotation-number {"textColor":"#000000","backgroundColor":"#ffffff","fontSize":12} /-->

				<!-- wp:wc-quote/bronze-quotation-date {"fontSize":12} /-->

				<!-- wp:wc-quote/bronze-shipping-method {"fontSize":12} /--></div>
				<!-- /wp:column --></div>
				<!-- /wp:columns -->

				<!-- wp:columns -->
				<div class="wp-block-columns"><!-- wp:column {"width":"50%"} -->
				<div class="wp-block-column" style="flex-basis:50%"><!-- wp:wc-quote/bronze-customer-info {"headingBgColor":"#ffffff","headingTextColor":"#000000","itemTextColor":"#000000","borderColor":"#ededed","topHeadingText":"Customer Informations","topHeadingFontColor":"#000000","topHeadingBgColor":"#d3a475","email":"Emails"} /--></div>
				<!-- /wp:column -->

				<!-- wp:column {"width":"50%"} -->
				<div class="wp-block-column" style="flex-basis:50%"><!-- wp:wc-quote/bronze-author-info {"headingBgColor":"#ffffff","headingTextColor":"#000000","borderColor":"#ececec","topHeadingText":"Author Informations","topHeadingBgColor":"#d3a475","fields":{"countryName":true,"address":true,"city":true,"zipCode":true,"state":true,"email":true,"phoneNumber":false}} /--></div>
				<!-- /wp:column --></div>
				<!-- /wp:columns -->

				<!-- wp:wc-quote/bronze-product-details /-->

				<!-- wp:columns -->
				<div class="wp-block-columns"><!-- wp:column {"verticalAlignment":"center","width":"50%","style":{"spacing":{"blockGap":"0"},"border":{"width":"0px","style":"none","radius":"0px"}}} -->
				<div class="wp-block-column is-vertically-aligned-center" style="border-style:none;border-width:0px;border-radius:0px;flex-basis:50%"><!-- wp:wc-quote/bronze-terms-condition-block {"termsConditionText":"Terms \u0026 Conditions "} /-->

				<!-- wp:wc-quote/bronze-signature {"signature":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWYAAADICAYAAADbR0s8AAAAAXNSR0IArs4c6QAAIABJREFUeF7tnQn8pVMZx8+UqUgUolKMJcZuwow2QohsNZPIMoYQEVFpUkYaWxnSZAvZojImFTONyZItW5R1CmWPDCHt2/T5nnp1587d7z33nv+93+fz8aH+73ve837Pe3/v8z7nOc8ZNm/evHlBk4AEJCCBbAgMU5izGQs7IgEJSCASUJh9ECQgAQlkRkBhzmxA7I4EJCABhdlnQAISkEBmBBTmzAbE7khAAhJQmH0GJCABCWRGQGHObEDsjgQkIAGF2WdAAhKQQGYEFObMBsTuSEACElCYfQYkIAEJZEZAYc5sQOyOBCQgAYXZZ0ACEpBAZgQU5swGxO5IQAISUJh9BiQgAQlkRkBhzmxA7I4EJCABhdlnQAISkEBmBBTmzAbE7khAAhJQmH0GJCABCWRGQGHObEDsjgQkIAGF2WdAAhKQQGYEFObMBsTuSEACElCYfQYkIAEJZEZAYc5sQOyOBCQgAYXZZ0ACEpBAZgQU5swGxO5IQAISUJh9BiQgAQlkRkBhzmxA7I4EJCABhdlnQAISkEBmBBTmzAbE7khAAhJQmH0GJCABCWRGQGHObEDsjgQkIAGF2WdAAhKQQGYEFObMBsTuSEACElCYfQYkIAEJZEZAYc5sQOyOBCQgAYXZZ0ACEpBAZgQU5swGxO5IQAISUJh9BiQgAQlkRkBhzmxA7I4EJCABhdlnQAISkEBmBBTmzAbE7khAAhJQmH0GJCABCWRGQGHObEDsjgQkIAGF2WdAAhKQQGYEFObMBsTuSEACElCYfQYkIAEJZEZAYc5sQOyOBCQgAYXZZ0ACEpBAZgQU5swGxO5IQAISUJh9BiQgAQlkRkBhzmxA7I4EJCABhdlnQAISkEBmBBTmzAbE7khAAhJQmH0GJCABCWRGQGHObEDsjgQkIAGF2WdAAhKQQGYEFObMBsTuSEACElCYfQYkIAEJZEZAYc5sQOyOBCQgAYXZZ0ACEpBAZgQU5swGxO5IQAISUJh9BiQgAQlkRkBhzmxA7I4EJCABhdlnQAISkEBmBBTmzAbE7khAAhJQmH0GJCABCWRGQGHObEDsjgQkIAGF2WdAAhKQQGYEFObMBsTuSEACElCYfQYkIAEJZEZAYc5sQOyOBCQgAYXZZ0ACEpBAZgQU5swGxO5IQAISUJh9BiQgAQlkRkBhzmxA7I4EJCABhdlnQAISkEBmBBTmzAbE7khAAhJQmH0GJCABCWRGQGHObEDsjgQkIAGF2WdAAi0QeOaZZ8IvfvGL8N73vreFsz1FArUJKMw+IRJogcCECRPCjTfeGO6///4WzvYUCSjMPgMS6CiBf//732GppZYKw4YNC88++2xH27YxCUBAj9nnQAJNEkCMEeZNNtkkXH311U2e7eESqE9AYa7PyCMkMB+BM888M+yzzz5h3rx5kpFAEgIKcxKsNtrPBEaNGhUn/hTmfh7l3t6bwtxb/l59CBIgtvz+978/XH755UOw93Z5KBBQmIfCKNnHrAggzOeee24YP358Vv2yM/1DQGEeYmP517/+Nfb4Va961RDreX9097bbbgujR48Ot956a9hggw3646a8i+wIKMzZDcmCHZozZ06YNm1azJv9wx/+8JIw77jjjmG//fYbAnfQP1086qijwqRJk2Ka3BJLLNE/N+adZEVAYc5qOP7fGX74CPEJJ5wQrr/++viHV7ziFTFNi3/jOf/ud78La621Vpg5c2ZYdtllM72T/urW2LFjw6xZs8Kf/vSn/rox7yYrAgpzVsPx384QvzzxxBPDvffeG1jMsNpqq4UDDjggrLvuuvMJ83333Rf22muv8MY3vjHw31p6ArwIeSE+/fTT6S/mFQaWgMKc0dA/8MAD4XOf+1y45JJLwqtf/eooxMccc0zYaKONqvbykUceCauuumq44oorwsYbb5zR3fRfV0iPY1xWXnnlcNddd/XfDXpH2RBQmDMZCsT44IMPDk888UQYM2ZMmDp1ahTm4cOH1+3hnnvuGV544YUwffr0usd6QOsECB8tvPDC4dRTTzW23zpGz2yAgMLcAKSUhxCrPPbYY8PRRx8dlllmmRia4L+bMSqdrbfeegHvWUtH4LnnnosTfoQxXv/616e7kC0PPAGFuYePABkWlI0kBWullVYKl112WYwnt2KLL7549Jq1dATuvvvusPbaaze94u+pp54KSy65ZENfP+l6b8tDiYDC3KPRevDBB8O2224bfvWrX0Vxnj17dls9UZhbw3f66aeH73//+2Hy5Mlh0UUXjY0QsvjnP/853z+IK1kyX//618NJJ50Uj+P/K6z8v/nf/MNEIYaH7YRha2M0iGcpzD0Y9V/+8pdhyy23DI8++miMVU6ZMiXGLtsxwiCFCLTTzqCdSwwfEWZS7zWvec0CwvyPf/wj/Otf/6qLBf60hWf8hje8Yb5/ll9++bDKKquENdZYo247HiABCCjMXX4OfvOb34QNN9wwEBceN25cuPjii9vuAR4f6XXXXXdd220NWgPbbbddmDt37ny3zapKvGfEuhBZDpg4cWJc7cccAB4wf8OKfw8aO+83HQGFOR3bBVp+8cUXw5prrhk95X333TecfPLJ4ZWvfGXbPRg5cmTYbbfdwuGHH952W4PYQLHMvbj3asvdqZHxhS98IbD6T5NASgIKc0q6JW3/5S9/iWlwTCBts802caKvE3bNNdeETTfdNJAx8NrXvrYTTdpGFQII83nnnRd23313GUkgKQGFOSne/ze+/fbbhx/+8IfhzW9+c1zRt9hii7V9ZSYOWXxCHjMpd1paAgjzVVddFV+EmgRSElCYU9L9X9tXXnll2HzzzePkEqv7mChq15iUIhODRSjElhdaaKF2m/T8GgT44llkkUXCQw89FEaMGCErCSQloDAnxfvfxpkoYrKPib4PfehDHbkiwnzKKaeEj3zkI2HppZfuSJs2Up3A7bffHtZff/2YwfHyl79cVBJISkBhToo3hDPOOCN87GMfC6uvvnoMYWhDk8A555wT9/njhahJIDUBhTkxYT5/+Qx+8sknTatKzDpl81/60pfC8ccfH/74xz+mvIxtSyASUJgTPgjkF3/gAx8IH/7wh8N3vvOdhFey6dQEdt111zBjxoyY/aJJIDUBhTkhYdLj2IKICT9KRWpDlwArNdkZ29WVQ3cMh1LPFeaEo0V6FbnFelkJIXepaar3sWz+hhtu6NIVvcwgE1CYE40+nhVLddninq3utaFNgHoXW221VaDokSaB1AQU5kSESWVjOygK4LzsZS9LdBWb7RYB6mYcd9xx4cADD+zWJb3OABNQmBMN/tvf/vZw8803N127N1F3bLYNAuy7SO7y1VdfHTbZZJM2WvJUCTRGQGFujFPTR5Emxyapv/71r5s+1xPyIkDuMjuTE57q5WIeUi7ZMZ3l/Z0ofpUXZXtTSkBhTvQ8MFHEcumbbrop0RVstlsEir3+2Iy1V1bsln7//ffHODfVCbX+JaAwJxpbSkeyMwmTf9rQJsC+jNRn7qUws3MKO6jfc8894eMf/3jHqhMO7ZHp394rzInGFo+ZgviU5eyF/fnPfw68HJx4bJ8+ezNSMKqXwszzdNhhh4VPf/rT4Ytf/GL48pe/3P6N2UK2BBTmREPDLD4pVvfdd1+iK9Ru9vOf/3z4+9//7g+4A/SL1MdeCjM58ex+w7iyk7qlRzswsBk3oTAnGpwddtghzJo1K27s2QtjfzkmHnt1/V7cc6prFmVbeynMfPnMmTMnrLPOOoHQSrsV7ljFyG46lotN9dS0167C3B6/qmf/+Mc/DltssUVg0gZvp9vG3nQsiHAbpPbJn3rqqZFj6U7Y7bfaXAsIM6L8la98Jc5dtGqIOh43O+i85S1vCWwM3Khx/3vssUc499xzLcjVKLQWj1OYWwTXyGkI8uOPPx6WXXbZRg7v6DEsHSbGrUfUPtYjjzwyXHjhhbHmSa+MZ4ktrdjaqh3baaedwo9+9KOA48AWZ08//XRDzbEl2o477hh22WWXGE7R0hJQmBPyXW655cJqq60WrrjiioRXsenUBNiM4LHHHos5xNXs5z//eRg1atQCfyb3mHmGzTbbrKVuEopCDJ999tlw7bXXhqlTp8atxMiTb9buvPPOMHr06BirxllgmzMch1rGxgCXXnpp+OQnPxm/Gri2lp6AwpyQ8ZQpU8KnPvWpns7mJ7y9gWma0MFSSy0V1l577ShQZEiUGkWqVlhhhfD8888vwISvFhaDIKqtGHMV7Kp+4403xh26TzzxxDjxR9y7GaOO9EorrRSFmTDG3/72t7jvJP+uZXvvvXc4++yzY//f/e53N3NJj22DgMLcBrx6pxLPY5+/iy66KPAJOZSM1W7kzJJ2t+qqq0Zhyt34LJ82bVoUHuLCK664Yke6TLx+7ty5cSVnpQVDCCZ5xuVVBPlSet/73he++c1vhgkTJjTdlyOOOCKceeaZsdxosU/k9773vTB27NimXvaI8rhx4+KX24MPPhgFmo2BDz744Og9V7Lf/va3Yb/99ovHz549uyfhuKaB9dEJCnPiwaSyHLtZ84APJSOeyA8SYSbD4yc/+UnM5W3XSD3rxGa05f3AW914443DXXfdFfdBZIXcbbfd1m534/nkgxOSqsYAj5gXAZNqpYaQM2GGMJI+2YwxyceCEmK7I0eOfOlUPOd3vetdTQnzdtttF59BmBSZJYwBi5946ZQbW6B98IMfjKEONnhgz0qtuwQU5i7w5tOXgkbMqg8FYxslwjDEM/nh4rnxYiFFi+2Vmsmh5VMZUeAHjtCzqSmCc/TRR3cMBTFcigshgGQMsOEtXiUTdohqq0Z8mJ1LKF502mmnxb0byw1PGgHDWy99cbF7DYtB4NZsmh2Tc7zQYcYLstQIqyy55JLhu9/9bt3bIo+dxSh8RfDVtvPOO8exgD9eOOmc5ca1qcWBh/2tb33LBUp1Kac5QGFOw3W+VvlB8+NgAid34wdP2IVwALP2eKJ4zHzabrTRRlFYG933DjFA0PDAyA7B05s5c2YULMS/E3byySeHY445JoYR6DM7jWCs1sNLbTXfF+8ST/Otb31r9CwZP8Sq3MhQYHUnnmypMbmGANI/2mrU8JDf+c53xpch8xPlRnZGtb6UH8uWZrwM77jjjsDkJB4/LxFeXvx3eUGmj370o+Hb3/52+NrXvhYzQIYPH95otz2uwwQU5g4DrdQcQsbnIJ+n1GhOZXinzLwjoM0uLMHjo94wP0omrEi3o5Y0Hho/akIEZJmQm82O31/96lcr3gZ94Fx2lH7mmWfiZzg/eD7zycWl5gTCUCpyeG/jx4+PIoqINGII7+TJkyNT7IQTTgiHHnroS6fi+fGS4VrNGnHkzTffPBahIi5LnxHf97znPQs09Y53vCPGkEvDDT/4wQ9ivwh/wIoJw0bsoYceiu1su+224ZJLLlngFDb15WXD81QrK4OX6Wc+85nYd9LiVllllRhqIdWO5+Kqq66ab86AhUgTJ06Mx/OSoxaH1lsCCnOX+DNpQ3I+gpLCEA68LBYMIIjNfD6zLyGTU0xW8pnMJy4vEj5ld9ttt+h1IVQYMWLCG2QKlBvijreNMJNN8NnPfjYKTamIEFr42c9+FledYYgB57B8nZcK/5D9UMsefvjhGKpAxBE+2i+NJ1PM/owzzghMYDbDgWviARPGYULvkEMOiaEQvFQ82aLPRd9IJWNyF8EsNRjSH0JXt9xyS+xjIzZixIjY3k9/+tP473LjZcPmvrVeuog2L1NWCXLt4oWBh0yGBWP9ute97qWmeXHx3HAeXzO8lLXeE1CYuzgG/EDZlJUZ8U4ZgkEckXABgkRsEw+0kYUDfP7jIXM+sUximmRgEIckvvqmN70pel7ElUsNoUL0isUr/Pf5558fPWPEC2+RbIRywwPn85jVkBjn4CnzwsLrxKM+66yzFphEK20HD5C+kiWCB0gKFzFm+v373/8+ZhqQSoZ3j6dfLx2saJswEyEWcnb5GqBfhXG/hCMIa5Qa1yPDoTQbAy8eYUXk+AIoQiq1xvvFF1+MvGDOdaotCpo0aVK8t/KwCW3DlpccIQjGjRc1L4jCCEWx0o+xhR152XjRlBBlP0O86E5M7nbquR70dhTmLj4BhAP4POZTl8/VdowfPBNTCDKfocSD2WOQTAC8vf33379m86xiY5KMdCnyVJmFR0joH/+b0AOihriVT6AhVHjM/NAx7gVvjrgxXlm11DquhZDhxbJo4uKLL47iTD8QI9r9xCc+EeOylUSd8AgTekz0kUbGS4n7JASAx0eYBWHDO8RbxONvpLof4wJL2mMRCbHw8hcRIlzqafJ3Jva452I1HhkYpOgVizZ4WTA5WM/4uuCZ4EuAL4dqxtcLO+OUjy1jAU/uGUYsBFliiSXma4aXISGuRx555CVh5mVExbrDDz+8ooder9/+PR0BhTkd24otE2NGjPBYWvFQ8IT5EePdIWh4p+zEXerdPfHEE9FrqmR8BuNV490iHMQyWRxRGF4ZP2w8ezy/SqlSiMf06dPjAgVm8F944YV4T/VqOBR5vbxEEEAWS5SuJEOYERbCEIUh4ggnGQWICgJa/B3vkHABE3584iPueJOI0rHHHhuPr7V5Ki8e7h/B42sGb5wXW7nRr0ohETxOjufaZECstdZaMT7Ly4V28Z75eqlmnEO4hK8FPGHi1bWMfnJvhFsIoyDkxNF5kfHCQ2Dr5UvzEuXFQbocx7topMsC0ODlFOYGQXXqMDwXfkTM2hOLbcb4sRMPZDIHAUWUyustIyJ4QuUeE9chPoywIQKEDIjTloo6xxCWQNwQZmbwKxkCvP7664cLLrggxnfJWkDk6xkZHZyH2BPHftvb3jbfKUyyEcsmnIDxVUCcmhALLxT+/yLrgr/jIfOJzn3RFp4rXw1YPWEuvEzSGAl/ELKplq8L4yL8UtphXhaIMF4snidpdbzMCNfw5cBYfOMb36iKhXN4sZJlwVjUM8ac4/HKGSeEmRAGk4v0o/iCqdUOgs7XRfm417u2f+8uAYW5u7zj1ZgYYmks4lQqNJW6giAQF0SgWInHv/nRVzPEgJglIlcYHi2Tj4QnEDBEmZBFq0YaFmEIPDwmBptZPIFXygRTpcktJhW5R44hM4LiQRihi3POOWcB4SQuyhcI7fH3UoMtLyEmQksNQSatjvOIQ5OJgsDWMkI8CGC54W3ydcHkH6EEQhtFXJfxJaRUKWRFW4SLCEmQUtdoBUBeQjDH0yesQmyY54F0Rq2/CCjMPRpPvDQ8wXqlJAk5ICSsZsMzQkxqGcKMd1ls1knYgx8+n69MaiEUpaLd7O3j9ZI2RioY4lfJM2+2zeJ4UrX4vC6EkJAH4oYAVctHhh/5uOVfDoSKYHXQQQfFyUUm6PDsCeMQ6+blhqg1smybjVgJO5QbYZfrrrsuhqXw5vHgC8N7JQ2Nc8uNe8KjJz6N19zMLjN4yYwvwpxiBWWrY+d5nSWgMHeWZ8Ot4TXx2Y03iPdZboQTimWxZEXUi98W5yMEeJx4ivz48eIQDDy0Sl5qwx0OIZa9JBSBh4w3mmJ7I4SUZeD8uzw9rZm+ciz3DYtSowIcIQFi440aL7lK2R28mIjp4n3zQik1RJMQS6kRfiDfGmHm66U0lt5oXzxuMAgozD0cZ37YLL1FhIv8UWKAiB7pVvyAmRwrTXuq1108MCa8iM9SapKYJGGLThTrZ5IQ7w5PE5FOIcz17q+ZvxPSYYKRsAh9Z1ELL5ZmJl1pA4+8PFeZfhBmIgukdHFJ0T9eXuSFlxpfAIw5Xy6EMZrxlJu5b48d+gQU5h6PIbuMMGGEd8XiCj678aaJmbI0txXDS2Ryp1KBmlba42VBfQzSyRAiPt9JoyProN+NLBiyUCoJc6175+sEXmTHsNiD3Gvi29QIIRNDk0AtAgpzj58PJuaIc5JpgTDzacyEUC92PamGgs9v0vPI5sALJ4cYT3IQBIY4MSsRy73feo8NE3KEZAphxjsmxj1mzJiOfL3Uu75/H9oEFOYejx+pbXij5OpS6wERzMmYbCIMQIiEDAbspJNOihNPTEj2u7HEncnHZoWZAk5M1rI4h7RGJnpb2XWk3/l6f5UJKMw9fDKIA7PKjIUQeMh4WAhhTsZkGRkd9LEQFgqoU3mNMEy/G6mNvDj5QmjWWCqOMDeS+dFs2x7f3wQU5h6NLx4YE39kTRR1DVhFRlGZenm13eoyOcrkWRMjLZ3gIo+ZUqZklPS7tSPM/c7G+0tHQGFOx7ZmyyxAYOEIldaK4jikxzGxhofaToH3Tt0S2QvkLJMLXWrFkmwyHPrdWM1Hal0rHnO/s/H+0hFQmNOxrdgy4QrKXPKDR4RLlyUzEUg2BRXfqBTXS2P3Eib3yCQorx9B6l25F93Lvqa8NvU9SLNTmFNStu1yAgpzl58JVt4xO09d3ErpbGRkIMyN7hKSovsshKBuBHFkihMt8NAMGxa9+pwyR1JwoE2EmVQ3XpqaBLpFQGHuFukQYg4rRYhYFlyt7CcCgCiy2q/RnS86fQvkUO+7774VlyFzLTxmJi7bXUnY6X6naG/GjBkx+0RhTkHXNqsRUJi79Gyw2wY5rKRRUa6zliHarFYrL8DTpa7G+Da1PIr0uPLrVqsd0a3+dfM6pLnxklKYu0ndaynMXXgGEFi8YDwvCr3XsyJ3mNxmavx20xAi6v6yErFSgSIKAFHhrF7xpW72OeW1DGWkpGvbesw9fAbYoYKYMvUlGi2RyS4gbDfELhzdMmo/kHFBbWVW+VUy6guzwITJv0EwJ/8GYZTzu0c95sRjQkocRYTY/qgo4t7IJak8Rq5ws5uJNtJ2tWNY5UY5T+pDVCsaT4412ywhWINg5DGTr93LydhB4Ow9zk9AYU78RFArgbq9RdH3Ri/H9lDsINJNYSafGkGmqFI1I3d56623bri4e6P3m+txrS7JzvV+7NfQIKAwJxwnwgFM5DVbmYwuUdGNJdDs6EGBo9RGlgULSsitrrUPHF4/9aPZ2HMQjPxlXlYUp9ck0C0CCnNC0lQYY3POejtWV+sCewNyfjequJE/TeyYT/Zqu4WwOIYUOV40lXbmSIiyp01XK5Tf00558b4moDAnGl48LESMnS9aLYhO2ICSk+yinNIIl4wYMSJuKkpWRjWjBCabtHYzvJLyvhttm/Fj0U21F1aj7XicBBoloDA3SqrJ49jwlF2br7/++ibP/P/h1D5mr7l22mjk4njAhE2ef/75mrt7INp4/0z+DZKxoObJJ59savJ2kPh4r50noDB3nmlskbQ4aitTIrNVYwcT0ubKiwi12l618yZOnBhIg6M2dC0jf5kJyUp7FHa6Tzm1x9J5lsnzRaFJoBsEFOZElIlLsv3S6quv3vIVuhXKYKUfOzazS0ktw3PkJUENjUEyttPiRTsItUEGaVxzvleFOdHoEI9k7752jCwJvFk2P01lZB0stthigaLu5DBXM+pHL7roorFg/nLLLZeqO7YrAQlQj2beoM3kdGnYmTBiJV2r9txzz8Ul0Wzoueaaa7baTN3zWCLOTtxMUtayCy64INaMIGuj1cnMup3xAAlIIBJQmBM9CAsttFB47LHHFqhl3OjlTjvttDjRlvq9SZ41iyhYLl7LyG1mIvKWW25p9BY8TgISaJGAwtwiuHqnLbzwwnHCaO+99653aMW/E15gJd7tt9/e0vmNnkR4guyRsWPHVj2FxS6k/vGy2GOPPRpt2uMkIIEWCSjMLYKrdxoFiCgVSfnOZozwB2JO7vKll14aKICUyoiB49nX88oJp5BPXe+4VP20XQkMGgGFOdGIUzaT5ct4vKXbR9W7HKvvyI5YZpll4o7Zw4cPr3dKy38nrkxGRj3BZSdvandQiEmTgATSE1CYEzImD5mCQAgaK+tqGVkP7JB9wAEHxNQsBJ3ymymNUqQU7SfTopqx4o3l16ecckrLS8tT3oNtS6AfCSjMCUcVwVthhRVijWOqy40fP77i1Sh2RK0KdjkhvMACjnq7nHSi25MnT4651tOnT6/aHCsYCa3MnTs3LnbRJCCB9AQU5sSMqVvMhBk7fowaNSpsueWWYZ111on/mw1NZ82aFe69997YC8IXkyZNamu1YDO3M3r06FiM/6ijjqp4GvFuamPgwRNn1iQgge4QUJi7wJl0tIMOOijMnj276tXwStl8tdYij053lcyR008/vaonf+edd8Yi/9TqIM6sSUAC3SGgMHeHc7wKYQM85BtuuOGlHaaZGCRsQcij28YS62nTpoVx48ZVvDTLydmvkB1NNAlIoHsEFObusc7uSgjzzJkzw1ZbbbVA32bMmBG22WabwIq/XXfdNbu+2yEJ9DMBhbmfR7fOvZH1ccQRR4RddtllviOpnzFy5MhYf/jRRx8dYELeugR6Q0Bh7g33LK564IEHxm2TEOdSw4Mm5HLttdcOzBZSWQyInZDA/wgozAP8KOANb7HFFrFWBkbB/KlTp4bDDjssTJgwIfnOKQOM3luXQE0CCvMAPyCs+GN1IjHkMWPGhClTpsSFLSuuuGLMqaaOhiYBCXSfgMLcfeZZXfGaa64JO++8c2AJOelz7H5NGEOTgAR6R0Bh7h37bK48Z86cWPaTBS4sghmkHbCzGQQ7IoESAgqzj4MEJCCBzAgozJkNiN2RgAQkoDD7DEhAAhLIjIDCnNmA2B0JSEACCrPPgAQkIIHMCCjMmQ2I3ZGABCSgMPsMSEACEsiMgMKc2YDYHQlIQAIKs8+ABCQggcwIKMyZDYjdkYAEJKAw+wxIQAISyIyAwpzZgNgdCUhAAgqzz4AEJCCBzAgozJkNiN2RgAQkoDD7DEhAAhLIjIDCnNmA2B0JSEACCrPPgAQkIIHMCCjMmQ2I3ZGABCSgMPsMSEACEsiMgMKc2YDYHQlIQAIKs8+ABCQggcwIKMyZDYjdkYBExkksAAAAMUlEQVQEJKAw+wxIQAISyIyAwpzZgNgdCUhAAgqzz4AEJCCBzAgozJkNiN2RgAQk8B/8j0iKM7jHWQAAAABJRU5ErkJggg=="} /--></div>
				<!-- /wp:column -->

				<!-- wp:column {"verticalAlignment":"top","width":"50%","style":{"spacing":{"blockGap":"0"},"border":{"width":"0px","style":"none"}},"fontSize":"normal"} -->
				<div class="wp-block-column is-vertically-aligned-top has-normal-font-size" style="border-style:none;border-width:0px;flex-basis:50%"><!-- wp:wc-quote/bronze-total {"titleColor":"#000000","itemColor":"#ffffff","align":"wide","borderColor":"#ffffff"} /--></div>
				<!-- /wp:column --></div>
				<!-- /wp:columns -->
				

				<!-- wp:wc-quote/bronze-footer-block {"backgroundColor":"#d3a475","footerText":"washington , dc copyrightalliance.org © 2024 Copyright Alliance","padding":12,"borderRadius":4} /-->

				<!-- wp:paragraph -->
				<p></p>
				<!-- /wp:paragraph -->',

				)
			);
		}
	}
}