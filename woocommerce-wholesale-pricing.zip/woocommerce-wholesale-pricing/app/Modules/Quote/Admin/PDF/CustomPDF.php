<?php
namespace WooCommerceWholesalePricing\App\Modules\Quote\Admin\PDF;

use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Services\Quote\PDFService;
use WP_Block_Type_Registry;


class CustomPDF extends Init {

	public function __construct() {
		parent::__construct();
		add_action('add_meta_boxes', array( $this, 'wc_quote_user_role_meta_box' ));
		add_action('save_post_custom_pdf', array( $this, 'wc_quote_save_custom_pdf_post' ));
		add_filter('allowed_block_types_all', array( $this, 'restrict_blocks_to_post_type' ), 10, 2);
		add_action('query_vars', array( $this, 'wcquote_query_vars' ));
		add_action('template_redirect', array( $this, 'wcquote_template_redirect' ));
	}

	public function register() {
		$builder_config = str_replace('"false"', 'false', wp_unslash(get_option('wc_quote_form_builder')));
		wp_register_script('wc_quote_pdf_block_type', WWP_PLUGIN_URL . 'build/quote/pdf-blocks/index.js', array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-plugins', 'wp-edit-post', 'wc-settings' ), WWP_VERSION);
		wp_localize_script(
			'wc_quote_pdf_block_type', 'apips', 
			array(
			'cap_image_path' => WWP_PUBLIC_URL . '/images/quote/products/cap.jpg',
			'belt_image_path' => WWP_PUBLIC_URL . '/images/quote/products/belt.jpg',
			'album_image_path' => WWP_PUBLIC_URL . '/images/quote/products/album.jpg',
			'builder_config' => $builder_config ? json_decode($builder_config) : array(
				array(
					'input' =>  true,
					'key' =>  'email',
					'label' =>  'Email',
					'tableView' =>  true,
					'type' =>  'email',
				),
				array(
					'input' =>  true,
					'key' =>  'name',
					'label' =>  'Name',
					'tableView' =>  true,
					'type' =>  'textfield',
				),
				array(
					'input' =>  true,
					'key' =>  'message',
					'label' =>  'Message',
					'tableView' =>  true,
					'type' =>  'textarea',
				),
			),
			)
		);

		// Creating Email PDF download url
		add_rewrite_rule('^download-pdf/?$', 'index.php?download_pdf=1', 'top');
	}

	// Restricted Blocks
	public function restrict_blocks_to_post_type( $allowed_blocks, $block_editor_context ) {
		// Check if we are editing a specific post type
		if (!empty($block_editor_context->post) && 'custom_pdf' === $block_editor_context->post->post_type) {
			// Get the meta value of the post
			$pdf_template_name = get_post_meta($block_editor_context->post->ID, 'pdf_template_name', true);

			// Define additional blocks based on the meta value
			$additional_blocks = array();
			if ('lightblue' === $pdf_template_name) {
				$additional_blocks = array(
				'wc-quote/lightblue-image',
				'wc-quote/lightblue-tagline',
				'wc-quote/lightblue-quotation-number',
				'wc-quote/lightblue-quotation-date',
				'wc-quote/lightblue-product-details',
				'wc-quote/lightblue-total',
				'wc-quote/lightblue-customer-info',
				'wc-quote/lightblue-footer-block',
				'wc-quote/lightblue-shipping-method',
				'wc-quote/lightblue-terms-condition-block',
				'wc-quote/lightblue-author-info',
				'wc-quote/lightblue-signature',
				// Add other lightblue blocks here
				);
			} elseif ('darkblue' === $pdf_template_name) {
				$additional_blocks = array(
				'wc-quote/darkblue-image',
				'wc-quote/darkblue-tagline',
				'wc-quote/darkblue-quotation-number',
				'wc-quote/darkblue-quotation-date',
				'wc-quote/darkblue-product-details',
				'wc-quote/darkblue-total',
				'wc-quote/darkblue-customer-info',
				'wc-quote/darkblue-footer-block',
				'wc-quote/darkblue-shipping-method',
				'wc-quote/darkblue-terms-condition-block',
				'wc-quote/darkblue-author-info',
				'wc-quote/darkblue-signature',
				// Add other darkblue blocks here
				);
			} elseif ('bronze' === $pdf_template_name) {
				$additional_blocks = array(
				'wc-quote/bronze-image',
				'wc-quote/bronze-tagline',
				'wc-quote/bronze-quotation-number',
				'wc-quote/bronze-quotation-date',
				'wc-quote/bronze-product-details',
				'wc-quote/bronze-total',
				'wc-quote/bronze-customer-info',
				'wc-quote/bronze-footer-block',
				'wc-quote/bronze-shipping-method',
				'wc-quote/bronze-terms-condition-block',
				'wc-quote/bronze-author-info',
				'wc-quote/bronze-signature',
				// Add other bronze blocks here
				);
			}

			// Get all registered blocks
			$all_registered_blocks = WP_Block_Type_Registry::get_instance()->get_all_registered();

			// Filter only core blocks
			$core_blocks = array_filter(
				array_keys($all_registered_blocks),
				function ( $block_name ) {
					return strpos($block_name, 'core/') === 0; // Include only blocks that start with "core/"
				}
			);

			// Combine core blocks with additional custom blocks
			$allowed_blocks = array_merge($core_blocks, $additional_blocks);

			// Return filtered blocks for 'custom_pdf' only
			return $allowed_blocks;
		}

		// For all other post types, return the default allowed blocks
		return $allowed_blocks;
	}

	/**
	 * Register metabox for wc-quote.
	 */
	public function wc_quote_user_role_meta_box() {

		add_meta_box( 
			'wc_quote_pdf_admin_detail_user',
			__('Select Admin', 'woocommerce-wholesale-pricing'),
			array( $this, 'wc_quote_pdf_admin_detail' ),
			'custom_pdf',
			'side',
			'high'
		);
	}

	public function wc_quote_pdf_admin_detail( $post ) {
		$users = get_admin_user_ids();
		$selected_user = get_post_meta($post->ID, 'wc_quote_pdf_admin_detail_user', true);
		wwp_view('admin.quote.custom-pdf.metabox.pdf-details', compact( 'users', 'selected_user' ));
	}

	public function wc_quote_save_custom_pdf_post( $post_id ) {

		if ( !isset( $_POST['wc_quote_pdf_user_action_nonce'] ) || ( isset( $_POST['wc_quote_pdf_user_action_nonce'] ) && !wp_verify_nonce( sanitize_text_field( $_POST['wc_quote_pdf_user_action_nonce'] ), 'wc_quote_pdf_user_action_nonce' ) ) ) {
			return;
		}

		if (isset($_POST['wc_quote_pdf_admin_detail_user']) ) {
			update_post_meta($post_id, 'wc_quote_pdf_admin_detail_user', sanitize_text_field($_POST['wc_quote_pdf_admin_detail_user']));
		}
	}

	// Creating Email PDF download url
	public function wcquote_query_vars( $vars ) {
		$vars[] = 'download_pdf';
		return $vars;
	}

	public function wcquote_template_redirect() {
		
		if (get_query_var('download_pdf') ) {
			if (isset($_REQUEST['quote_id']) && isset($_REQUEST['pdf_type'])) {
				$pdf_type_raw = filter_input( INPUT_GET, 'pdf_type', FILTER_SANITIZE_SPECIAL_CHARS );
				$pdf_type = quote_get_pdf_template_for_email($pdf_type_raw);
				if ( 'default' == $pdf_type_raw ) {
					$quote_id = filter_input( INPUT_GET, 'quote_id', FILTER_SANITIZE_SPECIAL_CHARS );
					$pdf_controller = new PDFService();
					wp_safe_redirect($pdf_controller->process_pdf_print(intval($quote_id)));
					exit();
				} elseif ( !empty( quote_generate_pdf( $pdf_type['id'], true ) ) ) {
						include quote_generate_pdf( $pdf_type['id'], true );
				}
			}
			exit;
		}
	}
}
