<?php
namespace WooCommerceWholesalePricing\App\Modules\Quote;

use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;

class ProductService {

	private $quote_settings;
	public static $rule_applied;

	private static $rendered_single_buttons = array();

	public function __construct() {

		self::$rule_applied = array();
		$this->quote_settings['customization'] = get_option('wc_quote_customization', false);

		add_action('woocommerce_after_add_to_cart_button', array( $this, 'wc_quote_button_show_single' ), 30);
		add_action('woocommerce_single_product_summary', array( $this, 'wc_quote_button_show_single' ), 30);
	}

	public function wc_quote_button_show_single() {
		global $product;

		if ( ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
			return;
		}

		$product_id = (int) $product->get_id();
		if ( isset( self::$rendered_single_buttons[ $product_id ] ) ) {
			return;
		}

		$current_hook   = current_action();
		$stock_status   = $product->get_stock_status();
		$quote_general  = get_option('wc_quote_general', false);
		$show_on_stock  = isset($quote_general['show_on_stock']) ? $quote_general['show_on_stock'] : 'hide';
	
		if ( 'outofstock' === $stock_status ) {
			if ( 'show' !== $show_on_stock || 'woocommerce_after_add_to_cart_button' === $current_hook ) {
				return;
			}
		} elseif ( 'woocommerce_single_product_summary' === $current_hook ) {
				return;
		}
		
		$quote_button = false;
		$wc_quote     = new QuoteProcess();
		foreach ( get_quote_rules() as $rule ) {

			$quote_rules = get_post_meta($rule->ID, 'wc_quote_rules', true);
			$show_single = isset($quote_rules['show_single']) ? $quote_rules['show_single'] : '0' ;
			$hide_cart_single = isset($quote_rules['hide_cart_single']) ? $quote_rules['hide_cart_single'] : '0' ;
			$hide_cart_all = isset($quote_rules['hide_cart_all']) ? $quote_rules['hide_cart_all'] : '0' ;
			$add_quote_text = isset($this->quote_settings['customization']['add_quote_text']) && !empty($this->quote_settings['customization']['add_quote_text']) ? $this->quote_settings['customization']['add_quote_text'] : esc_html__('Add To Quote', 'woocommerce-wholesale-pricing');
			$quote_btn_color = isset($this->quote_settings['customization']['add_quote_btn_color']) ? $this->quote_settings['customization']['add_quote_btn_color'] : '';
			$quote_text_color = isset($this->quote_settings['customization']['add_quote_text_color']) ? $this->quote_settings['customization']['add_quote_text_color'] : '';
			$quote_button_position  = isset($this->quote_settings['customization']['quote_btn_positioning']) ? $this->quote_settings['customization']['quote_btn_positioning'] : 'inline';
			if (! is_object($product) || !quote_check_rule_for_product($product->get_id(), $rule->ID) ) {
				continue;
			}
			
			if (in_array($rule->ID, self::$rule_applied) ) {
				break;
			}

			if ($quote_button && '1' !== $show_single ) {
				continue;
			}

			if ('variable' === $product->get_type() || 'variable-subscription' === $product->get_type() ) {

				$disable_class = 'disabled wc-variation-selection-needed';
			} else {
				$disable_class = '';
			}

			if ('1' === $show_single && ( '1' === $hide_cart_single || '1' === $hide_cart_all ) ) {
				$quote_button = true;
				array_push(self::$rule_applied, $rule->ID);
				self::$rendered_single_buttons[ $product_id ] = true;

				if ( in_array( $product->get_type(), array( 'simple', 'subscription' ), true ) ) {
					wwp_view( 'quote.quote-simple', compact( 'product', 'add_quote_text', 'quote_btn_color', 'quote_text_color' ) );
				} else {
					wwp_view( 'quote.quote-variable', compact( 'product', 'add_quote_text', 'quote_btn_color', 'quote_text_color' ), true );
				}

				if ($wc_quote->find_product_id_quote($product->get_id())) {
					/**
					 * Filter wcquote_product_already_added
					 * 
					 * @since 1.0
					**/
					echo '<p class="hide_on_quote browse_list">' . esc_html( apply_filters( 'wcquote_product_already_added', __( 'Product already added in the List', 'woocommerce-wholesale-pricing' ) ) ) . '</p>';
				}
				
				return;
			}
				
			if ('1' === $show_single) {
				$quote_button = true;
				self::$rendered_single_buttons[ $product_id ] = true;
				$class = ( 'underneath' == $quote_button_position ) ? 'underneath_add_to_cart' : '';
				echo '<a href="javascript:void(0)" rel="nofollow" data-product_id="' . intval($product->get_ID()) . '" data-product_sku="' . esc_attr($product->get_sku()) . '" class="wp-element-button wc_quote_single_page single_add_to_cart_button button alt ' . esc_attr($disable_class) . ' product_type_' . esc_attr($product->get_type()) . ' ' . esc_attr($class) . '" style="background-color:' . esc_attr($quote_btn_color) . ';color:' . esc_attr($quote_text_color) . ';">' . esc_attr($add_quote_text) . '</a>';
				if ($wc_quote->find_product_id_quote($product->get_id())) {
					/**
					 * Filter wcquote_product_already_added
					 * 
					 * @since 1.0
					**/
					echo '<p class="hide_on_quote browse_list">' . esc_html( apply_filters( 'wcquote_product_already_added', __( 'Product already added in the List', 'woocommerce-wholesale-pricing' ) ) ) . '</p>';
				}
			}
		}
	}
}
