<?php
/**
 * Handles native WooCommerce registration and login customization for wholesale users.
 *
 * This module integrates with WooCommerce registration and login hooks to manage
 * wholesale-specific restrictions such as pending approval, rejected status, or restricted store access.
 *
 * @package    WooCommerceWholesalePricing\App\Modules\Registration
 */
namespace WooCommerceWholesalePricing\App\Modules\Registration;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Class Native
 *
 * Provides hooks and logic for handling wholesale user registration and authentication.
 * Controls user access based on their wholesale registration request status
 * and integrates custom registration and login form modifications.
 */
class Native {

	use WholesaleSettings;
	
	/**
	 * Constructor.
	 *
	 * Registers WordPress and WooCommerce hooks for authentication,
	 * registration forms, and user registration logic.
	 */
	public function __construct() {
		add_filter('authenticate', array( $this, 'authenticate_login_request' ), 100, 2);

		add_action('woocommerce_register_form_end', array( $this, 'after_registration_form' ));
		add_action('woocommerce_login_form_end', array( $this, 'after_login_form' ), 10);
		add_filter('login_errors', array( $this, 'handle_errors' ), 100, 1);
		add_action('user_register', array( $this, 'register' ));
	}

	/**
	 * Validates wholesale user login requests.
	 *
	 * Checks if the logged-in user has a wholesale role and whether their account
	 * has been approved, rejected, or is pending. Restricts login access accordingly.
	 *
	 * @param  WP_User|WP_Error $user     The authenticated user object or WP_Error.
	 * @param  string           $username The username used for login.
	 * @return WP_User|WP_Error The authenticated user or an error if access is restricted.
	 */
	public function authenticate_login_request( $user, $username ) {
		if (! is_wp_error($user) ) {
			$settings  = self::get_pricing_settings();
			$auth_user = get_user_by('id', $user->data->ID);
			$user_role = $auth_user->roles;
			if (! empty($settings['wholesaler_login_restriction']) && 'yes' == $settings['wholesaler_login_restriction'] ) {
				if (! empty($user_role) ) {
					foreach ( $user_role as $key => $role ) {
						$args    = array(
							'post_type'  => array( 'wwp_requests' ),
							'order'      => 'ASC',
							'orderby'    => 'id',
							'fields'     => 'ids',
							'meta_query' => array(
								array(
									'key'   => '_user_id',
									'value' => $user->data->ID,
								),
							),
						);
						
						$post_id = get_posts($args);
						if (isset($post_id[0]) ) {
							$user_status = get_post_meta($post_id[0], '_user_status', true);
							if ('waiting' == $user_status ) {
								if (empty($settings['login_message_waiting_user']) ) {
									$settings['login_message_waiting_user'] = __('You can not access this store, Your request status is in Pending', 'woocommerce-wholesale-pricing');
								}
								return new \WP_Error('authentication_failed', __($settings['login_message_waiting_user'], 'woocommerce-wholesale-pricing'));
							} elseif ('rejected' == $user_status ) {
								if (empty($settings['login_message_rejected_user']) ) {
									$settings['login_message_rejected_user'] = __('You can not access this store, Your request is Rejected by admin', 'woocommerce-wholesale-pricing');
								}
								return new \WP_Error('authentication_failed', __($settings['login_message_rejected_user'], 'woocommerce-wholesale-pricing'));
							}
						}
					}
				}
			}
		}
		return $user;
	}

	/**
	 * Displays a link to the wholesale registration page on the registration form.
	 *
	 * @return string Rendered HTML output.
	 */
	public function after_registration_form() {
		$settings = self::get_pricing_settings();
		if (isset($settings['enable_registration_page']) && 'yes' == $settings['enable_registration_page'] ) {
			$page_id   = $settings['registration_page'];
			$page_link = get_permalink($page_id);
			
			/**
			* Hooks
			*
			* @since 2.0
			*/
			echo '<a href="' . esc_url($page_link) . '">' . esc_html(apply_filters('wwp_wholesale_registration_text', esc_html__('Or Want to Register as a Wholesaler?', 'woocommerce-wholesale-pricing'))) . '</a>';
		}
	}

	/**
	 * Displays the access password field on the WooCommerce login form when store access is restricted.
	 *
	 * @return string Rendered HTML output.
	 */
	public function after_login_form() {
		$settings = self::get_pricing_settings();
		$post     = wwp_get_post_data('');
		if (isset($settings['restrict_store_access']) && 'yes' == $settings['restrict_store_access'] && ! isset($_COOKIE['access_store_id']) ) {
			?>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
			<label for="access_store"><?php esc_html_e('Enter the password to access wholesale store', 'woocommerce-wholesale-pricing'); ?><span class="required">*</span></label>
			<input type="password" class="woocommerce-Input--text input-text" name="access_store_pass" id="access_store_pass" > 
			<button type="submit" class="woocommerce-button button woocommerce-form-access_store" name="access_store" value="Log in">Enter</button>
			</p>
			<?php
			if ('yes' == $settings['enable_registration_page'] ) {
				$page_id   = $settings['registration_page'];
				$page_link = get_permalink($page_id);
				
				/**
				* Hooks
				*
				* @since 3.0
				*/
				echo '<a href="' . esc_url($page_link) . '">' . esc_html(apply_filters('wwp_wholesale_registration_text', esc_html__('Or Want to Register as a Wholesaler?', 'woocommerce-wholesale-pricing'))) . '</a>';
			}
		}
	}

	/**
	 * Handles login error display for restricted access scenarios.
	 *
	 * Prevents login errors from showing when store access is restricted and
	 * the user is attempting access using the access store password.
	 *
	 * @param  string $error The existing login error message.
	 * @return string|void Modified error message or void if suppressed.
	 */
	public function handle_errors( $error ) {
		$settings = self::get_pricing_settings();
		if (isset($settings['restrict_store_access']) && 'yes' == $settings['restrict_store_access'] ) {
			$post = wwp_get_post_data('');
			if (isset($post['access_store_pass']) && ! empty($post['access_store_pass']) ) {
				return;
			}
		}

		return $error;
	}

	/**
	 * Assigns a wholesale role to a newly registered user when store access is restricted.
	 *
	 * Uses the `access_store_id` cookie and stored option to determine which wholesale
	 * role should be applied to the new user.
	 *
	 * @param  int $user_id The newly registered user's ID.
	 * @return void
	 */
	public function register( $user_id ) {
		$settings = self::get_pricing_settings();
		if (isset( $settings['restrict_store_access'] ) && 'yes' == $settings['restrict_store_access'] ) {
			if (isset($_COOKIE['access_store_id']) && ! empty($_COOKIE['access_store_id']) ) {
				$wholesale_user_roles = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
				$u = new \WP_User($user_id);
				if (! $u ) {
					return;
				}
				$email = $u->user_email;
				$access_store_id = get_option($email);
				foreach ( $wholesale_user_roles as  $value ) {
					if ($value->term_id == $access_store_id ) {
						$user_role_set = $value->slug;
					}
				}
				$wp_roles = new \WP_Roles();
				$names    = $wp_roles->get_names();
				foreach ( $names as $key => $value ) {
					$u->remove_role($key);
				}
				if ( isset( $user_role_set ) ) {
					$u->add_role($user_role_set);
				}
				delete_option($email); 
				unset($_COOKIE['access_store_id']);
				setcookie('access_store_id', null, 0, '/');
			}
		}
	}
}
