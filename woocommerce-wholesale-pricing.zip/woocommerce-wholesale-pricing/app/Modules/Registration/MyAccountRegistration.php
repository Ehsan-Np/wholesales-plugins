<?php
/**
 * MyAccountRegistration class
 * 
 * Handles the integration of the wholesale registration form with the WooCommerce "My Account" login page.
 * Specifically manages loading a wholesale registration form via AJAX, 
 * injecting custom scripts, rendering registration errors, and integrating Google reCAPTCHA.
 *
 * This functionality is conditionally activated based on the "over_right_wholesale_form" setting.
 *
 * @package WooCommerceWholesalePricing\App\Modules\Registration
 */
namespace WooCommerceWholesalePricing\App\Modules\Registration;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Class MyAccountRegistration
 * 
 * Responsible for adding wholesale registration form functionality on the WooCommerce My Account page.
 * Loads the wholesale registration form asynchronously via AJAX to replace the default registration form.
 * Adds necessary JavaScript and styles, handles displaying validation errors, and enqueues reCAPTCHA scripts.
 */
class MyAccountRegistration {

	use WholesaleSettings;

	/**
	 * Constructor.
	 * 
	 * Adds WordPress hooks if the "over_right_wholesale_form" setting is enabled.
	 */
	public function __construct() {
		$settings = self::get_pricing_settings();
		if (isset($settings['over_right_wholesale_form']) && 'yes' == $settings['over_right_wholesale_form'] ) {

			add_action('wp_ajax_over_right_wholesale_form', array( $this, 'form' ));
			add_action('wp_ajax_nopriv_over_right_wholesale_form', array( $this, 'form' ));
			add_action('woocommerce_after_customer_login_form', array( $this, 'scripts' ), 10, 1);
			
			add_action('wwp_wholesaler_registration_fields_start', array( $this, 'registration_fields_start' ), 10, 2);
			add_filter('wwp_wholesale_registration_form_errors', array( $this, 'registration_form_errors' ), 10, 1);

			add_action('template_redirect', array( $this, 'recpatcha_scripts' ), 5);
		}
	}

		
	/**
	 * AJAX callback to render the wholesale registration form shortcode.
	 * Outputs the registration form HTML and terminates the script.
	 *
	 * @return string Rendered HTML output.
	 */
	public function form() {
		echo do_shortcode('[' . wwp_env()->get('registration_shortcode') . ']');
		die;
	}

	/**
	 * Outputs JavaScript and CSS that replace the default WooCommerce registration form
	 * with the wholesale registration form loaded via AJAX.
	 * Also initializes Google reCAPTCHA for the form if enabled.
	 *
	 * @param string $customer_login_form The original WooCommerce customer login form HTML.
	 * 
	 * @return string Rendered HTML output.
	 */
	public function scripts( $customer_login_form ) {

		$settings   = recaptcha_initialize();

		$lang       = get_bloginfo('language');
		?>
		<script type="text/javascript">
		jQuery(document).ready( function() {     
			jQuery.ajax({
				url : "<?php echo esc_html__(admin_url('admin-ajax.php')); ?>",
				type : 'POST',
				data : {
					action : 'over_right_wholesale_form'
				},
				success : function( response ) {
					jQuery('form.woocommerce-form.woocommerce-form-register.register').replaceWith(response);
					
					if( jQuery("#wwp-recaptcha").length ) {
						grecaptcha.render('wwp-recaptcha', {
							'sitekey'     : '<?php echo esc_attr($settings['site_key']); ?>',
							'theme'     : '<?php echo esc_attr($settings['theme']); ?>',
							'hl'        : '<?php echo esc_attr($lang); ?>'
						});
					}

					if( jQuery("#c4wp_captcha_field_1").length ) {
						grecaptcha.render('c4wp_captcha_field_1', {
							'sitekey'     : '<?php echo esc_attr($settings['site_key']); ?>',
							'theme'     : '<?php echo esc_attr($settings['theme']); ?>',
							'hl'        : '<?php echo esc_attr($lang); ?>'
						});
					}
					
					jQuery('h2.wholesaler-registration').remove(); 
					jQuery('.wwp_wholesaler_registration_form').append('<input type="hidden" name="wwp_wholesale_registration_form_over_right">');
					jQuery('#wwp_wholesaler_copy_billing_address').change(
					function() { 
					if (!this.checked) {
						jQuery('#wholesaler_shipping_address').fadeIn('slow');
					} else {
						jQuery('#wholesaler_shipping_address').fadeOut('slow');
					}
					}
					);
				}
			});
		});
		</script>
		<style>
			form.woocommerce-form.woocommerce-form-register.register {
				display:none;
			}
		</style>
		<?php
	}

	/**
	 * Displays any wholesale registration errors stored in cookies.
	 * Outputs errors in a WooCommerce error list.
	 *
	 * @param array $registrations The registration fields data (unused).
	 * @param array $settings      The current plugin settings (unused).
	 */
	public function registration_fields_start( $registrations, $settings ) {
		
		if (isset($_COOKIE['wwp_registration_error']) && ! empty($_COOKIE['wwp_registration_error']) ) {
			$cookie = $_COOKIE;
			$errors = $cookie['wwp_registration_error'];
			$errors = explode(',,', $errors);
			if (! empty($errors) ) {
				echo '<ul class="woocommerce-error" role="alert">';
				foreach ( $errors as $key => $error ) { 
					echo '<li>' . wp_kses_post($error) . '</li>';
				}
				echo '</ul>';
				unset($_COOKIE['wwp_registration_error']);
				setcookie('wwp_registration_error', null, 0, '/');
			}
		}
	}

	/**
	 * Sets registration errors in a cookie if the wholesale registration form over the right is submitted.
	 *
	 * @param  array $errors Array of error messages.
	 * @return array The original errors, unchanged.
	 */
	public function registration_form_errors( $errors ) {
		$post = wwp_get_post_data();
		$errors = implode(',,', $errors);
		if (!empty($errors) && isset($post['wwp_wholesale_registration_form_over_right']) ) { 
			setcookie('wwp_registration_error', $errors, time() + 86400, '/', '', 0);
		}
		return $errors;
	}
		
	/**
	 * Enqueues the Google reCAPTCHA script on the WooCommerce My Account page
	 * if the "over_right_wholesale_form" setting is enabled.
	 *
	 * @return void
	 */
	public function recpatcha_scripts() {
		recaptcha_initialize();

		if (get_option('woocommerce_myaccount_page_id') != get_the_ID() ) {
			return;
		}

		$settings = self::get_pricing_settings();
		if (isset($settings['over_right_wholesale_form']) && 'yes' == $settings['over_right_wholesale_form'] ) {
			wp_enqueue_script('wwp_google_recaptcha', '//www.google.com/recaptcha/api.js', array(), '2.4.0', true);
		}
	}
}
