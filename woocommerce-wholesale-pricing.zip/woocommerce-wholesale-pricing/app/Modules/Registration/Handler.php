<?php
/**
 * Handler Class for WooCommerce Wholesale Registration
 * 
 * This class is responsible for handling the wholesale registration logic in the WooCommerce Wholesale Pricing plugin. 
 * It manages the registration process, renders the registration form, and handles redirection after registration.
 *
 * @package    WooCommerceWholesalePricing\App\Modules\Registration
 */
namespace WooCommerceWholesalePricing\App\Modules\Registration;

use WooCommerceWholesalePricing\App\Migrations\RegistrationFieldsMigration;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\Init;

/**
 * Class Handler
 * 
 * This class handles the entire registration flow for wholesale users. It includes rendering the registration form,
 * managing the registration process, handling errors, and managing redirects after registration.
 */
class Handler extends Init {

	use WholesaleSettings;
	
	/**
	 * Holds error messages during the registration process.
	 *
	 * @var array
	 */
	public $errors = array();

	/**
	 * Constructor Method
	 * 
	 * Initializes the Handler class, creates instances of necessary classes for registration,
	 * and sets up actions and shortcodes for handling registration.
	 *
	 * @return void
	 */
	public function __construct() {
		parent::__construct();
	
		// Initialize the necessary components for registration
		new Native();
		new MyAccountRegistration();
		new MultipleUploads();
		recaptcha_initialize();

		// Register shortcodes and actions
		add_shortcode(wwp_env()->get('registration_shortcode'), array( $this, 'render' ));
		add_action('wwp_registration_end', array( $this, 'registration_end' ));

		add_action('wp_ajax_register_redirect', array( $this, 'register_redirect' ));
		add_action('wp_ajax_nopriv_register_redirect', array( $this, 'register_redirect' ));
	}

	/**
	 * Render the registration form
	 * 
	 * This method is responsible for rendering the HTML output of the registration form. 
	 * It is hooked to the 'registration_shortcode' shortcode.
	 *
	 * @return string Rendered HTML output.
	 */
	public function render() {
		$settings = self::get_pricing_settings();

		if ( RegistrationFieldsMigration::is_in_progress() ) {
			return $this->render_registration_fields_migration_notice();
		}

		if (class_exists('WC_USER_REGISTRATION') && isset($settings['advance_registration_form']) && 'yes' == $settings['advance_registration_form'] ) {
			
			echo do_shortcode('[wc-user-registration-page]');
			return;
		}
		
		if (! is_admin() && is_user_logged_in() ) {
		
			/**
			* Hooks
			*
			* @since 3.0
			*/
			do_action('user_already_registered', $this);

			/**
			 * Filter Hooks
			 * CT-478 custom work
			 * Hide default message
			 *
			 * @since 2.6
			 */
			$show_msg = apply_filters('wwp_user_is_register', true);

			if ($show_msg ) {
				return esc_html__('You are already registered!', 'woocommerce-wholesale-pricing');
			} else {
				/**
				 * Filter Hooks
				 * CT-478 custom work
				 * show any custom message
				 *
				 * @since 2.6
				 */
				return apply_filters('wwp_user_is_already_register', '');
			}
		}
		global $woocommerce;
		$countries_obj         = new \WC_Countries();
		$countries             = $countries_obj->__get('countries');
		$default_country       = $countries_obj->get_base_country();
		$default_county_states = $countries_obj->get_states($default_country);
		$errors                = array();
		ob_start();
		if (isset($_POST['wwp_register']) ) {
			if (isset($_POST['wwp_wholesale_registrattion_nonce']) && wp_verify_nonce(wc_clean($_POST['wwp_wholesale_registrattion_nonce']), 'wwp_wholesale_registrattion_nonce') ) {
				$errors = $this->errors;
			} else {
				wp_die(esc_html__('Security check', 'wholesale-for-woocommerce'));
			}
		}
		$username = '';
		$email    = '';
		$fname    = '';
		$lname    = '';
		$company  = '';
		$addr1    = '';

		if (! empty($errors) ) {
			echo '<ul class="woocommerce-error" role="alert">';
			foreach ( (array) $errors as $key => $error ) {
				echo '<li>' . wp_kses_post($error) . '</li>';
			}
			echo '</ul>';
		}
		$username                               = isset($_POST['wwp_wholesaler_username']) ? wc_clean($_POST['wwp_wholesaler_username']) : '';
		$email                                  = isset($_POST['wwp_wholesaler_email']) ? wc_clean($_POST['wwp_wholesaler_email']) : '';
		$fname                                  = isset($_POST['wwp_wholesaler_fname']) ? wc_clean($_POST['wwp_wholesaler_fname']) : '';
		$lname                                  = isset($_POST['wwp_wholesaler_lname']) ? wc_clean($_POST['wwp_wholesaler_lname']) : '';
		$company                                = isset($_POST['wwp_wholesaler_company']) ? wc_clean($_POST['wwp_wholesaler_company']) : '';
		$addr1                                  = isset($_POST['wwp_wholesaler_address_line_1']) ? wc_clean($_POST['wwp_wholesaler_address_line_1']) : '';
		$wwp_wholesaler_address_line_2          = isset($_POST['wwp_wholesaler_address_line_2']) ? wc_clean($_POST['wwp_wholesaler_address_line_2']) : '';
		$wwp_wholesaler_city                    = isset($_POST['wwp_wholesaler_city']) ? wc_clean($_POST['wwp_wholesaler_city']) : '';
		$wwp_wholesaler_post_code               = isset($_POST['wwp_wholesaler_post_code']) ? wc_clean($_POST['wwp_wholesaler_post_code']) : '';
		$billing_country                        = isset($_POST['billing_country']) ? wc_clean($_POST['billing_country']) : $default_country;
		$billing_state                          = isset($_POST['billing_state']) ? wc_clean($_POST['billing_state']) : '';
		$shipping_country                       = isset($_POST['shipping_country']) ? wc_clean($_POST['shipping_country']) : $billing_country;
		$shipping_state                         = isset($_POST['shipping_state']) ? wc_clean($_POST['shipping_state']) : '';
		$default_county_states                  = $countries_obj->get_states($billing_country);
		$shipping_county_states                 = $countries_obj->get_states($shipping_country);
		$wwp_wholesaler_phone                   = isset($_POST['wwp_wholesaler_phone']) ? wc_clean($_POST['wwp_wholesaler_phone']) : '';
		$wwp_wholesaler_shipping_fname          = isset($_POST['wwp_wholesaler_shipping_fname']) ? wc_clean($_POST['wwp_wholesaler_shipping_fname']) : '';
		$wwp_wholesaler_shipping_lname          = isset($_POST['wwp_wholesaler_shipping_lname']) ? wc_clean($_POST['wwp_wholesaler_shipping_lname']) : '';
		$wwp_wholesaler_shipping_company        = isset($_POST['wwp_wholesaler_shipping_company']) ? wc_clean($_POST['wwp_wholesaler_shipping_company']) : '';
		$wwp_wholesaler_shipping_address_line_1 = isset($_POST['wwp_wholesaler_shipping_address_line_1']) ? wc_clean($_POST['wwp_wholesaler_shipping_address_line_1']) : '';
		$wwp_wholesaler_shipping_address_line_2 = isset($_POST['wwp_wholesaler_shipping_address_line_2']) ? wc_clean($_POST['wwp_wholesaler_shipping_address_line_2']) : '';
		$wwp_wholesaler_shipping_city           = isset($_POST['wwp_wholesaler_shipping_city']) ? wc_clean($_POST['wwp_wholesaler_shipping_city']) : '';
		$wwp_wholesaler_shipping_post_code      = isset($_POST['wwp_wholesaler_shipping_post_code']) ? wc_clean($_POST['wwp_wholesaler_shipping_post_code']) : '';
		$wwp_wholesaler_shipping_post_code      = isset($_POST['wwp_wholesaler_shipping_post_code']) ? wc_clean($_POST['wwp_wholesaler_shipping_post_code']) : '';

		$wwp_wholesaler_tax_id = isset($_POST['wwp_wholesaler_tax_id']) ? wc_clean($_POST['wwp_wholesaler_tax_id']) : '';
		$default_country                        = $billing_country;

		$registrations = self::get_registration_settings();
		
		/**
		* Hooks
		*
		* @since 3.0
		*/
		apply_filters('wwp_wholesale_custom_filters_css', wwp_wholesale_css($settings));
		$registeration = esc_html__('Registration', 'woocommerce-wholesale-pricing');
		?>
		<div class="wwp_wholesaler_registration">
			<h2 class="wholesaler-registration">
				<?php 
					/**
					 * Hooks
					 *
					 * @since 2.6
					 */
					echo esc_html(apply_filters('change_wwp_register_text', $registeration)); 
				?>
			</h2>
				<?php if (function_exists('wc_print_notices') ) : ?>
					<?php wc_print_notices(); ?>
				<?php endif; ?>
			<form method="post" class="wwp_wholesaler_registration_form" action="" enctype="multipart/form-data">
				<?php
					/*
					* custom work CT-478
					* Tim
					* */
				if (file_exists(WP_PLUGIN_DIR . '/wwp-custom-plugin/wholesale-for-woocommerce/registration-fields.php') ) {
					include WP_PLUGIN_DIR . '/wwp-custom-plugin/wholesale-for-woocommerce/registration-fields.php';
				} else if (file_exists(get_stylesheet_directory() . '/wholesale-for-woocommerce/registration-fields.php') ) {
					include get_stylesheet_directory() . '/wholesale-for-woocommerce/registration-fields.php';
				} else {
					include WWP_PLUGIN_PATH . 'resources/views/registration-form/fields.php';
				}
				?>
			</form>
		</div>
		<?php
		
		/**
		 * Hooks
		 *
		 * @since 3.0
		 */
		do_action('wwp_registration_end', $this);
		return ob_get_clean();
	}

	private function render_registration_fields_migration_notice() {
		ob_start();
		?>
		<style>
			.wwp-registration-migration-maintenance {
				position: relative;
				min-height: 280px;
				border-radius: 6px;
				overflow: hidden;
				background: rgba(255, 255, 255, 0.75);
			}

			.wwp-registration-migration-maintenance__overlay {
				position: absolute;
				top: 0;
				right: 0;
				bottom: 0;
				left: 0;
				display: flex;
				align-items: center;
				justify-content: center;
				padding: 24px;
				background: rgba(255, 255, 255, 0.92);
				text-align: center;
				z-index: 2;
			}

			.wwp-registration-migration-maintenance__message {
				max-width: 520px;
				padding: 28px;
				border: 1px solid #dcdcde;
				border-radius: 8px;
				background: #fff;
				box-shadow: 0 12px 30px rgba(0, 0, 0, 0.08);
			}

			.wwp-registration-migration-maintenance__message h2 {
				margin: 0 0 12px;
			}

			.wwp-registration-migration-maintenance__message p {
				margin: 0;
			}
		</style>
		<div class="wwp-registration-migration-maintenance" aria-live="polite">
			<div class="wwp-registration-migration-maintenance__overlay" role="status">
				<div class="wwp-registration-migration-maintenance__message">
					<h2><?php esc_html_e( 'Registration Fields Maintenance', 'woocommerce-wholesale-pricing' ); ?></h2>
					<p><?php esc_html_e( 'The registration fields are currently in maintenance. This can take up to 5 minutes. Please check again later.', 'woocommerce-wholesale-pricing' ); ?></p>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Handle the registration form submission
	 *
	 * This method handles the registration process when the registration form is submitted.
	 * It verifies the nonce and triggers the wholesaler registration process.
	 *
	 * @return void
	 */
	public function register() {
		
		if (isset($_POST['wwp_register']) ) {
			if (isset($_POST['wwp_wholesale_registrattion_nonce']) && wp_verify_nonce(wc_clean($_POST['wwp_wholesale_registrattion_nonce']), 'wwp_wholesale_registrattion_nonce') ) {
				$this->errors = $this->register_wholesaler();
			}
		}
	}

	 /**
	  * Handle wholesaler registration
	  * 
	  * This method is responsible for registering a wholesaler when the form is submitted.
	  * It creates the user, saves their data, and stores relevant metadata.
	  *
	  * @return array Array of error messages if the registration fails, or an empty array if successful.
	  */
	public function register_wholesaler() {
		
		$posted_data = array();
		/**
		* Hooks
		*
		* @since 3.0
		*/
		if (apply_filters('wwp_register_fields_validation', false, $this) ) {
			/**
			* Hooks
			*
			* @since 3.0
			*/
			wc_print_notice(esc_html__(apply_filters('wwp_fields_validation_error_msg', 'Filed Must be required.'), 'woocommerce-wholesale-pricing'), 'error');
			return;
		}
		
		if (! isset($_POST['wwp_wholesale_registrattion_nonce']) || ( isset($_POST['wwp_wholesale_registrattion_nonce']) && ! wp_verify_nonce(wc_clean($_POST['wwp_wholesale_registrattion_nonce']), 'wwp_wholesale_registrattion_nonce') ) ) {
			wp_die(esc_html__('Security check', 'wholesale-for-woocommerce'));
		}

		$post           = $_POST;
		
		$errors         = array();
		/***
		 * Hooks Filter hook process registration form
		 * 
		 * @since 2.4.0
		 * 
		 * $args array $post
		 */
		$errors         = ( array ) apply_filters('wwp_process_registration_form', $errors, $post);
		if (is_array($errors) && count($errors) > 0 ) {
			foreach ( $errors as $error ) {
				wc_add_notice($error, 'error');
			}
			return false;
		}

		$settings       = self::get_pricing_settings();
		$registrations  = self::get_registration_settings();

		if (isset($registrations['extra_pass_field']) && 'yes' == $registrations['extra_pass_field'] ) {
			if (isset($post['wwp_wholesaler_password']) && isset($post['password2']) ) {
				if (strcmp($post['wwp_wholesaler_password'], $post['password2']) !== 0 ) {
					wc_add_notice(esc_html__('Passwords do not match.', 'woocommerce-wholesale-pricing'), 'error');
					return false;
				}
			}
		}
		/**
		 * Filter hook to hide email field in registration form
		 * 
		 * @since 3.0.1
		 */
		if ( ! apply_filters('wwp_hide_email_field_registration', false) && empty($post['wwp_wholesaler_email']) ) {
			wc_print_notice(esc_html__('Email Required', 'woocommerce-wholesale-pricing'), 'error');
			return false;
		}

		if ( isset( $registrations['enable_tex_id'], $registrations['vat_validation'], $post['wwp_wholesaler_tax_id'] ) && 'yes' == $registrations['enable_tex_id'] && 'yes' == $registrations['vat_validation'] ) {
			$validated = validate_vat( $post['wwp_wholesaler_tax_id'] );
			if ( $validated ) {
				wc_print_notice($validated, 'error');
				return false;
			}
		}
		
		// first name if required
		if (isset($registrations['enable_billing_first_name'], $post['wwp_wholesaler_fname'], $registrations['required_billing_first_name']) && 'yes' == $registrations['enable_billing_first_name'] && empty($post['wwp_wholesaler_fname']) && 'yes' == $registrations['required_billing_first_name'] ) {
			/* translators: %s is a field label (e.g., First Name, Last Name) */
			wc_print_notice(sprintf(esc_html__('%s is a required field.', 'woocommerce-wholesale-pricing'), $registrations['billing_first_name']), 'error');
			return false;
		}

		// last name if required
		if (isset($registrations['enable_billing_last_name'], $post['wwp_wholesaler_lname'], $registrations['required_billing_last_name']) && 'yes' == $registrations['enable_billing_last_name'] && empty($post['wwp_wholesaler_lname']) && 'yes' == $registrations['required_billing_last_name'] ) {
			/* translators: %s is a field label (e.g., First Name, Last Name) */
			wc_print_notice(sprintf(esc_html__('%s is a required field.', 'woocommerce-wholesale-pricing'), $registrations['billing_last_name']), 'error');
			return false;
		}

		// company if required
		if (isset($registrations['enable_billing_company'], $post['wwp_wholesaler_company'], $registrations['required_billing_company']) && 'yes' == $registrations['enable_billing_company'] && empty($post['wwp_wholesaler_company']) && 'yes' == $registrations['required_billing_company'] ) {
			/* translators: %s is a field label (e.g., First Name, Last Name) */
			wc_print_notice(sprintf(esc_html__('%s is a required field.', 'woocommerce-wholesale-pricing'), $registrations['billing_company']), 'error');
			return false;
		}

		// address_1 if required
		if (isset($registrations['enable_billing_address_1'], $post['wwp_wholesaler_address_line_1'], $registrations['required_billing_address_1']) && 'yes' == $registrations['enable_billing_address_1'] && empty($post['wwp_wholesaler_address_line_1']) && 'yes' == $registrations['required_billing_address_1'] ) {
			/* translators: %s is a field label (e.g., First Name, Last Name) */
			wc_print_notice(sprintf(esc_html__('%s is a required field.', 'woocommerce-wholesale-pricing'), $registrations['billing_address_1']), 'error');
			return false;
		}

		// address_2 if required
		if (isset($registrations['enable_billing_address_2'], $post['wwp_wholesaler_address_line_2'], $registrations['required_billing_address_2']) && 'yes' == $registrations['enable_billing_address_2'] && empty($post['wwp_wholesaler_address_line_2']) && 'yes' == $registrations['required_billing_address_2'] ) {
			/* translators: %s is a field label (e.g., First Name, Last Name) */
			wc_print_notice(sprintf(esc_html__('%s is a required field.', 'woocommerce-wholesale-pricing'), $registrations['billing_address_2']), 'error');
			return false;
		}

		// City if required
		if (isset($registrations['enable_billing_city'], $post['wwp_wholesaler_city'], $registrations['required_billing_city']) && 'yes' == $registrations['enable_billing_city'] && empty($post['wwp_wholesaler_city']) && 'yes' == $registrations['required_billing_city'] ) {
			/* translators: %s is a field label (e.g., First Name, Last Name) */
			wc_print_notice(sprintf(esc_html__('%s is a required field.', 'woocommerce-wholesale-pricing'), $registrations['billing_city']), 'error');
			return false;
		}

		// postal code if required
		if (isset($registrations['enable_billing_post_code'], $post['wwp_wholesaler_post_code'], $registrations['required_billing_post_code']) && 'yes' == $registrations['enable_billing_post_code'] && empty($post['wwp_wholesaler_post_code']) && 'yes' == $registrations['required_billing_post_code'] ) {
			/* translators: %s is a field label (e.g., First Name, Last Name) */
			wc_print_notice(sprintf(esc_html__('%s is a required field.', 'woocommerce-wholesale-pricing'), $registrations['billing_post_code']), 'error');
			return false;
		}

		// Billing UK postcode validation when enabled and a value was submitted.
		if (
			isset( $registrations['enable_billing_post_code'], $registrations['billing_validate_uk_postcode'] )
			&& 'yes' === $registrations['enable_billing_post_code']
			&& 'yes' === $registrations['billing_validate_uk_postcode']
			&& ! empty( $post['wwp_wholesaler_post_code'] )
			&& false === validate_uk_postcode( $post['wwp_wholesaler_post_code'] )
		) {
			$billing_post_code_label = ! empty( $registrations['billing_post_code'] ) ? $registrations['billing_post_code'] : __( 'Postcode / ZIP', 'woocommerce-wholesale-pricing' );
			/* translators: %s is a field label (e.g., Postcode / ZIP) */
			wc_print_notice( sprintf( esc_html__( '%s is invalid.', 'woocommerce-wholesale-pricing' ), $billing_post_code_label ), 'error' );
			return false;
		}

		// Phone if required
		if (isset($registrations['enable_billing_phone'], $post['wwp_wholesaler_phone'], $registrations['required_billing_phone']) && 'yes' == $registrations['enable_billing_phone'] && empty($post['wwp_wholesaler_phone']) && 'yes' == $registrations['required_billing_phone'] ) {
			/* translators: %s is a field label (e.g., First Name, Last Name) */
			wc_print_notice(sprintf(esc_html__('%s is a required field.', 'woocommerce-wholesale-pricing'), $registrations['billing_phone']), 'error');
			return false;
		}
		
		$role = get_option('default_role');
		if (! isset($settings['disable_auto_role']) || ( isset($settings['disable_auto_role']) && 'no' == $settings['disable_auto_role'] ) ) {

			if (isset($settings['wholesale_role']) && 'single' == $settings['wholesale_role'] ) {

				$role = 'default_wholesaler';

			} elseif (isset($settings['default_multipe_wholesale_roles']) ) {
				$role = $settings['default_multipe_wholesale_roles'];
				if (isset($_POST['wwp_wholesale_role_request']) ) {
					$wwp_wholesaler_role = wc_clean($_POST['wwp_wholesale_role_request']);
					$role = $wwp_wholesaler_role;
				}
			}
		}
		
		if (isset($registrations['required_billing_country'], $registrations['enable_billing_country']) &&  $registrations['enable_billing_country'] && empty($post['billing_country']) ) {
			wc_add_notice(sprintf('<strong>%s </strong> is a required field.', $registrations['billing_countries']), 'error');
			return false;
		}

		if (isset($registrations['required_billing_state'], $registrations['enable_billing_state']) && 'yes' ==  $registrations['required_billing_state'] && empty($post['billing_state']) && ! empty($post['wwp_state_type']) ) {
			$valid_states = '';
			if ('select' == $post['wwp_state_type'] ) {
				$countries_state = new \WC_Countries();
				$valid_states = $countries_state->get_states($post['billing_country']);
			}
			
			if (! empty($valid_states) && in_array($post['billing_state'], $valid_states) ) {
				wc_add_notice(sprintf('<strong>%s </strong> is a required field.', $registrations['billing_state']), 'error');
			} else {
				wc_add_notice(sprintf('<strong>%s </strong> is a required field.', $registrations['billing_state']), 'error');
			}
			return false;
		}

		// Unchecked checkboxes are not submitted, so shipping applies unless copy-billing was explicitly checked.
		if ( ! isset( $_POST['wwp_wholesaler_copy_billing_address'] ) || 'yes' !== wc_clean( $_POST['wwp_wholesaler_copy_billing_address'] ) ) {
			if (isset($registrations['required_shipping_country'], $registrations['enable_shipping_country']) && 'yes' ==  $registrations['required_shipping_country'] && empty($post['shipping_country']) ) {
				wc_add_notice(sprintf('<strong>%s </strong> is a required field.', $registrations['shipping_countries']), 'error');
				return false;
			}

			if (isset($registrations['required_shipping_state'], $registrations['enable_shipping_state']) && 'yes' ==  $registrations['required_shipping_state'] && empty($post['shipping_state']) ) {
				wc_add_notice(sprintf('<strong>%s </strong> is a required field.', $registrations['shipping_state']), 'error');
				return false;
			}

			// Shipping postal code if required.
			if (
				isset( $registrations['enable_shipping_post_code'], $registrations['required_shipping_post_code'] )
				&& 'yes' === $registrations['enable_shipping_post_code']
				&& 'yes' === $registrations['required_shipping_post_code']
				&& empty( $post['wwp_wholesaler_shipping_post_code'] )
			) {
				$shipping_post_code_label = ! empty( $registrations['shipping_post_code'] ) ? $registrations['shipping_post_code'] : __( 'Postcode / ZIP', 'woocommerce-wholesale-pricing' );
				/* translators: %s is a field label (e.g., Postcode / ZIP) */
				wc_print_notice( sprintf( esc_html__( '%s is a required field.', 'woocommerce-wholesale-pricing' ), $shipping_post_code_label ), 'error' );
				return false;
			}

			// Shipping UK postcode validation when enabled and a value was submitted.
			if (
				isset( $registrations['enable_shipping_post_code'], $registrations['shipping_validate_uk_postcode'] )
				&& 'yes' === $registrations['enable_shipping_post_code']
				&& 'yes' === $registrations['shipping_validate_uk_postcode']
				&& ! empty( $post['wwp_wholesaler_shipping_post_code'] )
				&& false === validate_uk_postcode( $post['wwp_wholesaler_shipping_post_code'] )
			) {
				$shipping_post_code_label = ! empty( $registrations['shipping_post_code'] ) ? $registrations['shipping_post_code'] : __( 'Postcode / ZIP', 'woocommerce-wholesale-pricing' );
				/* translators: %s is a field label (e.g., Postcode / ZIP) */
				wc_print_notice( sprintf( esc_html__( '%s is invalid.', 'woocommerce-wholesale-pricing' ), $shipping_post_code_label ), 'error' );
				return false;
			}
		}
		
		$user_login     = isset($_POST['wwp_wholesaler_username']) ? wc_clean($_POST['wwp_wholesaler_username']) : '';
		$user_email     = isset($_POST['wwp_wholesaler_email']) ? wc_clean($_POST['wwp_wholesaler_email']) : '';

		if ( empty( $user_login ) ) {
			$user_login = $user_email;
		}
		$userdata = array(
			'first_name' => isset($_POST['wwp_wholesaler_fname']) ? wc_clean($_POST['wwp_wholesaler_fname']) : '',
			'last_name'  => isset($_POST['wwp_wholesaler_lname']) ? wc_clean($_POST['wwp_wholesaler_lname']) : '',
			'user_login' => $user_login,
			'user_email' => $user_email,
			'user_pass'  => isset($_POST['wwp_wholesaler_password']) ? wc_clean($_POST['wwp_wholesaler_password']) : '',
			'role'       => $role,
		);
		$user_id  = wp_insert_user($userdata);
		if (! is_wp_error($user_id) ) {

			/**
			 * Action
			 * 
			 * Added for custom work CT-478
			 *
			 * @since 2.5
			 */
			do_action('wwp_insert_user_data', $user_id, $post);
		
			$customer = new \WC_Customer($user_id);
			
			// Form builder fields udate in user meta
			form_builder_update_user_meta($user_id, $post);

			if (isset($_POST['wwp_wholesaler_fname']) ) {
				$billing_first_name = wc_clean($_POST['wwp_wholesaler_fname']);
				$customer->set_billing_first_name($billing_first_name);
			}
			if (isset($_POST['wwp_wholesaler_lname']) ) {
				$billing_last_name = wc_clean($_POST['wwp_wholesaler_lname']);
				$customer->set_billing_last_name($billing_last_name);
			}
			if (isset($_POST['wwp_wholesaler_company']) ) {
				$billing_company = wc_clean($_POST['wwp_wholesaler_company']);
				$customer->set_billing_company($billing_company);
			}
			if (isset($_POST['wwp_wholesaler_address_line_1']) ) {
				$billing_address_1 = wc_clean($_POST['wwp_wholesaler_address_line_1']);
				$customer->set_billing_address_1($billing_address_1);
			}
			if (isset($_POST['wwp_wholesaler_address_line_2']) ) {
				$billing_address_2 = wc_clean($_POST['wwp_wholesaler_address_line_2']);
				$customer->set_billing_address_2($billing_address_2);
			}
			if (isset($_POST['wwp_wholesaler_city']) ) {
				$billing_city = wc_clean($_POST['wwp_wholesaler_city']);
				$customer->set_billing_city($billing_city);
			}
			if (isset($_POST['billing_state']) ) {
				$billing_state = wc_clean($_POST['billing_state']);
				$customer->set_billing_state($billing_state);
			}
			if (isset($_POST['wwp_wholesaler_post_code']) ) {
				$billing_postcode = wc_clean($_POST['wwp_wholesaler_post_code']);
				$customer->set_billing_postcode($billing_postcode);
			}
			if (isset($_POST['billing_country']) ) {
				$billing_country = wc_clean($_POST['billing_country']);
				$customer->set_billing_country($billing_country);
			}
			if (isset($_POST['wwp_wholesaler_phone']) ) {
				$billing_phone = wc_clean($_POST['wwp_wholesaler_phone']);
				$customer->set_billing_phone($billing_phone);
			}
			if (isset($_POST['wwp_wholesaler_tax_id']) ) {
				$wwp_wholesaler_tax_id = wc_clean($_POST['wwp_wholesaler_tax_id']);
				$customer->update_meta_data('wwp_wholesaler_tax_id', $wwp_wholesaler_tax_id);
			}
			if (isset($_POST['wwp_wholesale_role_request']) ) {
				$wwp_wholesale_role_request = wc_clean($_POST['wwp_wholesale_role_request']);
				$customer->update_meta_data('wwp_wholesale_role_request', $wwp_wholesale_role_request);
			}
			if (isset($_POST['wwp_custom_field_1']) ) {
				$wwp_custom_field_1 = wc_clean($_POST['wwp_custom_field_1']);
				$customer->update_meta_data('wwp_custom_field_1', $wwp_custom_field_1);
			}
			if (isset($_POST['wwp_custom_field_2']) ) {
				$wwp_custom_field_2 = wc_clean($_POST['wwp_custom_field_2']);
				$customer->update_meta_data('wwp_custom_field_2', $wwp_custom_field_2);
			}
			if (isset($_POST['wwp_custom_field_3']) ) {
				$wwp_custom_field_3 = wc_clean($_POST['wwp_custom_field_3']);
				$customer->update_meta_data('wwp_custom_field_3', $wwp_custom_field_3);
			}
			if (isset($_POST['wwp_custom_field_4']) ) {
				$wwp_custom_field_4 = wc_clean($_POST['wwp_custom_field_4']);
				$customer->update_meta_data('wwp_custom_field_4', $wwp_custom_field_4);
			}
			if (isset($_POST['wwp_custom_field_5']) ) {
				$wwp_custom_field_5 = wc_clean($_POST['wwp_custom_field_5']);
				$customer->update_meta_data('wwp_custom_field_5', $wwp_custom_field_5);
			}

			if (! empty($_FILES['wwp_wholesaler_file_upload']) ) {
				if (isset($registrations['multiple_file_upload']) && 'yes' == $registrations['multiple_file_upload'] ) {
					/**
					* Hooks
					*
					* @since 3.0
					*/
					do_action('wwp_wholesaler_file_upload_multiple_handle', $_FILES, $user_id);
				} else {
					include_once ABSPATH . 'wp-admin/includes/file.php';
					include_once ABSPATH . 'wp-admin/includes/image.php';
					include_once ABSPATH . 'wp-admin/includes/media.php';
					$attach_id = media_handle_upload('wwp_wholesaler_file_upload', $user_id);
					$customer->update_meta_data('wwp_wholesaler_file_upload', $attach_id);
					
				}
			}

			if (isset($_POST['wwp_wholesaler_copy_billing_address']) ) {
				$wwp_wholesaler_copy_billing_address = wc_clean($_POST['wwp_wholesaler_copy_billing_address']);
			}
			if (isset($wwp_wholesaler_copy_billing_address) ) {
				if (isset($_POST['wwp_wholesaler_fname']) ) {
					$billing_first_name = wc_clean($_POST['wwp_wholesaler_fname']);
					//update_user_meta( $user_id, 'shipping_first_name', $billing_first_name );
					$customer->set_shipping_first_name($billing_first_name);
				}
				if (isset($_POST['wwp_wholesaler_lname']) ) {
					$billing_last_name = wc_clean($_POST['wwp_wholesaler_lname']);
					//update_user_meta( $user_id, 'shipping_last_name', $billing_last_name );
					$customer->set_shipping_last_name($billing_last_name);
				}
				if (isset($_POST['wwp_wholesaler_company']) ) {
					$billing_company = wc_clean($_POST['wwp_wholesaler_company']);
					//update_user_meta( $user_id, 'shipping_company', $billing_company );
					$customer->set_shipping_company($billing_company);
				}
				if (isset($_POST['wwp_wholesaler_address_line_1']) ) {
					$shipping_address_1 = wc_clean($_POST['wwp_wholesaler_address_line_1']);
					//update_user_meta( $user_id, 'shipping_address_1', $shipping_address_1 );
					$customer->set_shipping_address_1($shipping_address_1);
				}
				if (isset($_POST['wwp_wholesaler_address_line_2']) ) {
					$shipping_address_2 = wc_clean($_POST['wwp_wholesaler_address_line_2']);
					//update_user_meta( $user_id, 'shipping_address_2', $shipping_address_2 );
					$customer->set_shipping_address_2($shipping_address_2);
				}
				if (isset($_POST['wwp_wholesaler_city']) ) {
					$shipping_city = wc_clean($_POST['wwp_wholesaler_city']);
					//update_user_meta( $user_id, 'shipping_city', $shipping_city );
					$customer->set_shipping_city($shipping_city);
				}
				if (isset($_POST['billing_state']) ) {
					$billing_state = wc_clean($_POST['billing_state']);
					//update_user_meta( $user_id, 'shipping_state', $billing_state );
					$customer->set_shipping_state($billing_state);
				}
				if (isset($_POST['wwp_wholesaler_post_code']) ) {
					$shipping_postcode = wc_clean($_POST['wwp_wholesaler_post_code']);
					//update_user_meta( $user_id, 'shipping_postcode', $shipping_postcode );
					$customer->set_shipping_postcode($shipping_postcode);
				}
				if (isset($_POST['billing_country']) ) {
					$billing_country = wc_clean($_POST['billing_country']);
					//update_user_meta( $user_id, 'shipping_country', $billing_country );
					$customer->set_shipping_country($billing_country);
				}
				if (isset($_POST['billing_phone']) ) {
					$billing_phone = wc_clean($_POST['billing_phone']);
					//update_user_meta( $user_id, 'shipping_country', $billing_country );
					$customer->set_shipping_phone($billing_phone);
				}
			} else {
				if (isset($_POST['wwp_wholesaler_shipping_fname']) ) {
					$shipping_first_name = wc_clean($_POST['wwp_wholesaler_shipping_fname']);
					//update_user_meta( $user_id, 'shipping_first_name', $shipping_first_name );
					$customer->set_shipping_first_name($shipping_first_name);
				}
				if (isset($_POST['wwp_wholesaler_shipping_lname']) ) {
					$shipping_last_name = wc_clean($_POST['wwp_wholesaler_shipping_lname']);
					//update_user_meta( $user_id, 'shipping_last_name', $shipping_last_name );
					$customer->set_shipping_last_name($shipping_last_name);
				}
				if (isset($_POST['wwp_wholesaler_shipping_company']) ) {
					$shipping_company = wc_clean($_POST['wwp_wholesaler_shipping_company']);
					//update_user_meta( $user_id, 'shipping_company', $shipping_company );
					$customer->set_shipping_company($shipping_company);
				}
				if (isset($_POST['wwp_wholesaler_shipping_address_line_1']) ) {
					$shipping_address_1 = wc_clean($_POST['wwp_wholesaler_shipping_address_line_1']);
					//update_user_meta( $user_id, 'shipping_address_1', $shipping_address_1 );
					$customer->set_shipping_address_1($shipping_address_1);
				}
				if (isset($_POST['wwp_wholesaler_shipping_address_line_2']) ) {
					$shipping_address_2 = wc_clean($_POST['wwp_wholesaler_shipping_address_line_2']);
					//update_user_meta( $user_id, 'shipping_address_2', $shipping_address_2 );
					$customer->set_shipping_address_2($shipping_address_2);
				}
				if (isset($_POST['wwp_wholesaler_shipping_city']) ) {
					$shipping_city = wc_clean($_POST['wwp_wholesaler_shipping_city']);
					//update_user_meta( $user_id, 'shipping_city', $shipping_city );
					$customer->set_shipping_city($shipping_city);
				}
				if (isset($_POST['shipping_state']) ) {
					$shipping_state = wc_clean($_POST['shipping_state']);
					//update_user_meta( $user_id, 'shipping_state', $shipping_state );
					$customer->set_shipping_state($shipping_state);
				}
				if (isset($_POST['wwp_wholesaler_shipping_post_code']) ) {
					$shipping_postcode = wc_clean($_POST['wwp_wholesaler_shipping_post_code']);
					//update_user_meta( $user_id, 'shipping_postcode', $shipping_postcode );
					$customer->set_shipping_postcode($shipping_postcode);
				}
				if (isset($_POST['shipping_country']) ) {
					$shipping_country = wc_clean($_POST['shipping_country']);
					//update_user_meta( $user_id, 'shipping_country', $shipping_country );
					$customer->set_shipping_country($shipping_country);
				}
			}
			$id = wp_insert_post(
				array(
					'post_type'   => 'wwp_requests',
					'post_title'  => $user_login . ' - ' . esc_attr($user_id),
					'post_status' => 'publish',
				)
			);
			if (! is_wp_error($id) ) {

				update_post_meta($id, '_user_id', $user_id);
				
				if (! isset($settings['disable_auto_role']) || ( isset($settings['disable_auto_role']) && 'no' == $settings['disable_auto_role'] ) ) {
					update_post_meta($id, '_user_status', 'active');
					$customer->update_meta_data('_user_status', 'active');

					if (isset($settings['wholesale_role']) && 'single' == $settings['wholesale_role'] ) {

						wp_set_object_terms($id, 'default_wholesaler', 'wholesale_user_roles', true);

					} elseif (isset($settings['default_multipe_wholesale_roles']) ) {
						if (isset($_POST['wwp_wholesale_role_request']) ) {
							$wwp_wholesaler_role = wc_clean($_POST['wwp_wholesale_role_request']);
							wp_set_object_terms($id, $wwp_wholesaler_role, 'wholesale_user_roles', true);
						} else {
							wp_set_object_terms($id, $settings['default_multipe_wholesale_roles'], 'wholesale_user_roles', true);
						}
					} else {
						wp_set_object_terms($id, 'default_wholesaler', 'wholesale_user_roles', true);
					}

					if (! empty($role) ) {
					
						/**
						* Hooks
						*
						* @since 3.0
						*/
						do_action('wwp_wholesale_user_request_approved', $user_id);
						update_post_meta($id, '_approval_notification', 'sent');
					}
				} else {
					update_post_meta($id, '_user_status', 'waiting');
					if (isset($_POST['wwp_wholesale_role_request']) ) {
						$wwp_wholesaler_role = wc_clean($_POST['wwp_wholesale_role_request']);
						update_post_meta($id, 'user_role_set', $wwp_wholesaler_role);
					} 
					$customer->update_meta_data('_user_status', 'waiting');
				}

				$role_slug = '';
				if ( isset( $_POST['wwp_wholesale_role_request'] ) ) {
					$role_slug = wc_clean( wp_unslash( $_POST['wwp_wholesale_role_request'] ) );
				} elseif ( isset( $wwp_wholesaler_role ) && ! empty( $wwp_wholesaler_role ) ) {
					$role_slug = $wwp_wholesaler_role;
				} elseif ( isset( $settings['default_multipe_wholesale_roles'] ) ) {
					$role_slug = $settings['default_multipe_wholesale_roles'];
				} else {
					$role_slug = 'default_wholesaler';
				}

				$role_term = $role_slug ? get_term_by( 'slug', $role_slug, 'wholesale_user_roles' ) : false;
				if ( $role_term && ! is_wp_error( $role_term ) ) {
					$role_approval = get_term_meta( $role_term->term_id, 'wwp_user_request_approval', true );
					if ( 'auto' === $role_approval ) {
						update_post_meta( $id, '_user_status', 'active' );
						$customer->update_meta_data( '_user_status', 'active' );

						wp_set_object_terms($id, $role_slug, 'wholesale_user_roles', true);
						/**
						* Hooks
						*
						* @since 3.0
						*/
						do_action('wwp_wholesale_user_request_approved', $user_id);
						update_post_meta($id, '_approval_notification', 'sent');
					}
				}

				$customer->save();
				/**
				* Hooks
				*
				* @since 3.0
				*/
				do_action('wwp_wholesale_new_request_submitted', $user_id);
				/**
				* Hooks
				*
				* @since 3.0
				*/
				do_action('wwp_wholesale_new_registered_request', $user_id);

			}
			// On success
			if (! is_wp_error($user_id) ) {
				/**
				* Hooks
				*
				* @since 3.0
				*/
				$notice = apply_filters('wwp_success_msg', esc_html__('You are Registered Successfully', 'woocommerce-wholesale-pricing'));
				wc_add_notice(esc_html__($notice, 'woocommerce-wholesale-pricing'), 'success');
				$_POST = array();
			} else {
				/**
				* Hooks
				*
				* @since 3.0
				*/
				$notice = apply_filters('wwp_error_msg', esc_html__($user_id->get_error_message(), 'woocommerce-wholesale-pricing'));
				wc_add_notice(esc_html__($notice, 'woocommerce-wholesale-pricing'), 'error');
			}

			if (isset($settings['register_redirect']) && ! empty(get_permalink($settings['register_redirect'])) && ! is_wp_error($user_id) ) {
				$location = get_permalink($settings['register_redirect']);
				header("Location: $location", true);
				exit;
			}
		} else {
			$errors[] = $user_id->get_error_message();
		}
		
		/**
		* Hooks
		*
		* @since 3.0
		*/
		return apply_filters('wwp_wholesale_registration_form_errors', $errors);
	}

	/**
	 * Perform actions at the end of the registration process
	 * 
	 * This method is hooked to the 'wwp_registration_end' action and runs a JavaScript snippet
	 * to trigger a change event on the billing country dropdown.
	 *
	 * @return string Rendered HTML output.
	 */
	public function registration_end() {
		?>
					<script>
				jQuery('#billing_country').trigger('change');
			</script>
		<?php 
	} 

	/**
	 * Handle registration redirect via AJAX
	 * 
	 * This method handles the redirection process after registration via AJAX. It checks the GET data
	 * for specific parameters (e.g., 'sample_product') and builds a response containing a list of posts
	 * (pages or products) based on the search query.
	 *
	 * @return void
	 */
	public function register_redirect() {
	
		$wwp_get_get_data = wwp_get_get_data();
		if (isset($wwp_get_get_data['sample_product']) ) {
			$post_type = array( 'product' );
		} else {
			$post_type = array( 'page', 'product' );
		}

		$args     = array(
			'posts_per_page' => -1,
			'post_type'      => $post_type,
			'post_status'    => 'publish',
			's'              => wwp_get_get_data('name'),
		);
		$query    = get_posts($args);
		$response = array();
		foreach ( $query as $r ) {
			if ( isset($wwp_get_get_data['sample_product']) ) {
				$product = wc_get_product($r->ID);
				if ( ! $product || $product->is_type('variable') ) {
					continue;
				}
			}
			$post_title = $r->post_title . ' - (' . $r->ID . ')';
			$response[] = array(
				'value' => $r->ID,
				'label' => $post_title,
			);
		}
		echo wp_kses_post(wwp_get_get_data('callback') . '(' . json_encode($response) . ')');
		die();
	}
}
