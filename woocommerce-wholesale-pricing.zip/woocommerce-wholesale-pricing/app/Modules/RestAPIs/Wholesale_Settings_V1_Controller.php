<?php
/**
 * REST API Controller for managing General Wholesale Discount Settings (V1).
 *
 * This controller handles the CRUD operations for general wholesale pricing
 * settings (like percentage/fixed discount) associated with specific roles.
 *
 * @package WooCommerceWholesalePricing\App\Modules\RestAPIs
 */
namespace WooCommerceWholesalePricing\App\Modules\RestAPIs;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Wholesale_Settings_V1_Controller Class.
 *
 * Registers the /wholesale/v1/general-discount API endpoint and related functionality.
 *
 * @extends \WC_REST_Controller
 */
class Wholesale_Settings_V1_Controller extends \WC_REST_Controller {

	
	/**
	 * Include the WholesaleSettings trait for utility functions like
	 * get_multiuser_pricing_settings().
	 */
	use WholesaleSettings;

	/**
	 * The namespace for the REST API routes.
	 *
	 * @var string
	 */
	protected $namespace = 'wholesale/v1';

	/**
	 * The REST base for this controller (e.g., 'general-discount').
	 *
	 * @var string
	 */
	protected $rest_base = 'general-discount';

	/**
	 * Main plugin instance object.
	 *
	 * @var \WC_Wholesale_Prices|null
	 */
	protected $wc_wholesale_prices;

	/**
	 * Constructor.
	 *
	 * Initializes the controller, sets the main plugin object, and registers hooks.
	 */
	public function __construct() {
		global $wc_wholesale_prices;
		$this->wc_wholesale_prices = $wc_wholesale_prices;

		add_action('rest_api_init', array( $this, 'register_routes' ));
		add_filter('w\wp_rest_response_product_object', array( $this, 'filter_product_object' ), 10, 3);
	}

	/**
	 * Filter the product object response data based on the 'fields' request parameter.
	 *
	 * Note: This method seems duplicated from the role controller and may not be necessary
	 * for a general settings endpoint, but is maintained for code structure consistency.
	 *
	 * @param  \WP_REST_Response $response The response object.
	 * @param  \WC_Product       $object   The product object.
	 * @param  \WP_REST_Request  $request  The request object.
	 * @return \WP_REST_Response Filtered response object.
	 */
	public function filter_product_object( $response, $object, $request ) {
		if (isset($request['fields']) && !empty($request['fields'])) {
			$data    = $response->get_data();
			$newdata = array();
			foreach (explode(',', $request['fields']) as $field) {
				$newdata[$field] = $data[$field];
			}
			$response->set_data($newdata);
		}
		return $response;
	}

	/**
	 * Register the routes for the Wholesale Settings REST API endpoint.
	 *
	 * Defines routes for collection (`/general-discount`) and single item (`/general-discount/<role_key>`).
	 *
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create_item' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
			)
		);

		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/(?P<role_key>[a-z0-9_-]*)?',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'update_item' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
				array(
					'methods'             => \WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete_item' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
			)
		);
	}

	/**
	 * Check if a given request has permission to access or modify wholesale settings.
	 *
	 * Requires the user to have the 'manage_woocommerce' capability (admin/shop manager).
	 *
	 * @param  \WP_REST_Request $request Full details about the request.
	 * @return bool|\WP_Error True if the request has permission, WP_Error otherwise.
	 */
	public function permissions_check( $request ) {
		if (current_user_can('manage_woocommerce')) {
			return true;
		}
		return new \WP_Error('wholesale_rest_role_permission_failed', __('You don\'t have permission.', 'woocommerce-wholesale-pricing'), array( 'status' => rest_authorization_required_code() ));
	}

	/**
	 * Get a collection of all registered general wholesale discount settings.
	 *
	 * Retrieves all role-specific general discount settings and transforms them
	 * to include the role ID.
	 *
	 * @param  \WP_REST_Request $request Full details about the request.
	 * @return \WP_REST_Response Response object containing the array of wholesale settings.
	 */
	public function get_items( $request ) {
		$settings = self::get_multiuser_pricing_settings();
		
		if (!empty($settings)) {
			$pre = array_map(
				function ( $key, $value ) {
					$value['role-id'] = $key;
					return $value;
				}, array_keys($settings), $settings
			);
		}
		
		/**
		 * Filter the general wholesale settings fetched via the API.
		 *
		 * @since 2.4.0
		 * @param array $pre Array of general discount settings, keyed by role term ID.
		 * @param \WP_REST_Request $request Full details about the request.
		 */
		$wholesale_settings = apply_filters('wwp_api_fetch_wholesale_settings_filter', $pre, $request);
	
		return new \WP_REST_Response($wholesale_settings, 200);
	}
	
	/**
	 * Get a single wholesale role's general discount settings by its key/slug.
	 *
	 * @param  \WP_REST_Request $request Full details about the request. Must contain 'role_key'.
	 * @return \WP_REST_Response Response object on success.
	 */
	public function get_item( $request ) {
		$role_key = $request->get_param('role_key');
		$settings = self::get_multiuser_pricing_settings();
		$wholesale_role = term_exists($role_key, 'wholesale_user_roles');

		if (!empty($settings)) {
			if ( is_array($settings) && ! empty( $wholesale_role ) && isset($settings[ $wholesale_role['term_id'] ]) ) {
				$settings            = $settings[ $wholesale_role['term_id'] ];
				$settings['role-id'] = $wholesale_role['term_id'];
			}
		}
		/**
		 * Filter the single general wholesale setting fetched via the API.
		 *
		 * @since 2.4.0
		 * @param array            $settings_for_role The settings array for the requested role.
		 * @param \WP_REST_Request $request           Full details about the request.
		 */
		$wholesale_settings = apply_filters('wwp_api_fetch_wholesale_settings_filter', $settings, $request);
		return new \WP_REST_Response($wholesale_settings, 200);
	}

	/**
	 * Create a new general discount setting for a wholesale role.
	 *
	 * @param  \WP_REST_Request $request Full details about the request. Should include 'slug', 'discount_type',
	 *                                   'wholesale_price', and 'min_quantity'.
	 * @return \WP_REST_Response Response object indicating success or failure.
	 */
	public function create_item( $request ) {
		$params   = $request->get_params();
		$settings = self::get_multiuser_pricing_settings();
	
		$wholesale_role = term_exists($params['slug'], 'wholesale_user_roles');
		if (!empty($wholesale_role)) {
			$settings[$wholesale_role['term_id']] = array(
				'slug' => $params['slug'],
				'discount_type' => $params['discount_type'],
				'wholesale_price' => $params['wholesale_price'],
				'min_quatity' => $params['min_quantity'],
				'min_subtotal' => $params['min_subtotal'],
			);
			update_option('wholesale_multi_user_pricing', $settings);
	
			$response_message = __('Successfully created discount.', 'woocommerce-wholesale-pricing');
			$response_status  = 200;
		} else {
			$response_message = __('Role not exist', 'woocommerce-wholesale-pricing');
			$response_status  = 400;
		}
	
		$response = array(
			'message' => $response_message,
		);
		return new \WP_REST_Response($response, $response_status);
	}

	/**
	 * Update an existing general discount setting for a wholesale role.
	 *
	 * @param  \WP_REST_Request $request Full details about the request. Must contain 'role_key' and update fields.
	 * @return \WP_REST_Response Response object indicating success or failure.
	 */
	public function update_item( $request ) {
		$role_key = $request->get_param('role_key');
		$params   = $request->get_params();
		$settings = self::get_multiuser_pricing_settings();
	
		$wholesale_role = term_exists($role_key, 'wholesale_user_roles');
		if (!empty($wholesale_role)) {
			$settings[$wholesale_role['term_id']] = array(
				'slug' => $role_key,
				'discount_type' => $params['discount_type'],
				'wholesale_price' => $params['wholesale_price'],
				'min_quatity' => $params['min_quantity'],
				'min_subtotal' => $params['min_subtotal'],
			);
			update_option('wholesale_multi_user_pricing', $settings);
	
			$response_message = __('Successfully updated discount.', 'woocommerce-wholesale-pricing');
			$response_status  = 200;
		} else {
			$response_message = __('Role not exist', 'woocommerce-wholesale-pricing');
			$response_status  = 400;
		}
	
		$response = array(
			'message' => $response_message,
		);
		return new \WP_REST_Response($response, $response_status);
	}

	/**
	 * Delete the general discount setting for a specific wholesale role.
	 *
	 * Deletes the entry from the 'wholesale_multi_user_pricing' option.
	 *
	 * @param  \WP_REST_Request $request Full details about the request. Must contain 'role_key'.
	 * @return \WP_REST_Response Response object indicating success or failure.
	 */
	public function delete_item( $request ) {
		$role_key       = $request->get_param('role_key');
		$settings       = self::get_multiuser_pricing_settings();
		$wholesale_role = term_exists($role_key, 'wholesale_user_roles');
		if (!empty($wholesale_role)) {
			unset($settings[$wholesale_role['term_id']]);
			update_option('wholesale_multi_user_pricing', $settings);
			$response_message = __('Successfully deleted discount.', 'woocommerce-wholesale-pricing');
			$response_status  = 200;
		} else {
			$response_message = __('Role not exist', 'woocommerce-wholesale-pricing');
			$response_status  = 400;
		}
		$response = array(
			'message' => $response_message,
		);
		return new \WP_REST_Response($response, $response_status);
	}
}
