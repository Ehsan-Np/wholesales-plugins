<?php

namespace WooCommerceWholesalePricing\App\Modules\RestAPIs;

use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\RecentRequests;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\UserInformation;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\OrdersCount;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\TopSoldProducts;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\ScoreCards;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\TopCustomers;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\WholesaleChart;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\RecentOrders;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\OrderReceipt;

/**
 * Dashboard_V1_Controller
 *
 * REST API controller for the wholesale dashboard.
 * Handles dashboard data retrieval, chart data, and order invoice generation.
 *
 * @package WooCommerceWholesalePricing\App\Modules\RestAPIs
 * @since   1.0.0
 */
class Dashboard_V1_Controller {

	use RecentRequests;
	use UserInformation;
	use OrdersCount;
	use TopSoldProducts;
	use TopCustomers;
	use RecentOrders;
	use ScoreCards;
	use WholesaleChart;
	use OrderReceipt;

	/**
	 * REST API namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'wholesale/v1';

	/**
	 * REST API base route.
	 *
	 * @var string
	 */
	protected $rest_base = 'wholesale-requests';

	/**
	 * Constructor.
	 *
	 * Registers REST API routes on initialization.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action('rest_api_init', array( $this, 'register_routes' ));
	}

	/**
	 * Register REST API routes.
	 *
	 * Registers all endpoints for the dashboard API:
	 * - GET /wholesale/v1/wholesale-requests - Main dashboard data
	 * - GET /wholesale/v1/wholesale-requests/orders - Chart data
	 * - GET /wholesale/v1/wholesale-requests/order-invoice - Order invoice PDF
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register_routes() {
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
			)
		);
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/orders',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_order_chart_data' ),
					'permission_callback' => array( $this, 'permissions_check' ),
				),
			)
		);
		register_rest_route(
			$this->namespace,
			'/' . $this->rest_base . '/order-invoice',
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => array( $this, 'download_order_invoice' ),
					'permission_callback' => array( $this, 'permissions_check' ),
					'args'                => array(
						'order_id' => array(
							'required'          => true,
							'validate_callback' => function ( $param ) {
								return is_numeric( $param ) && absint( $param ) > 0;
							},
						),
					),
				),
			)
		);
	}

	/**
	 * Get dashboard items.
	 *
	 * Retrieves all dashboard data including user information, score cards,
	 * chart data, order counts, top products, top customers, recent requests,
	 * recent orders, redirect URLs, and accounting settings.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return \WP_REST_Response Response object containing dashboard data.
	 */
	public function get_items( $request ) {
		$response['requests']   = $this->get_user_information($request);
		$response['scoreCards'] = $this->get_score_cards($request);

		$chart_filter = $request->get_param('chart_filter');
		if ( empty( $chart_filter ) ) {
			$chart_filter = 'group-users';
		}
		$response['chart']          = $this->get_chart_data( $request, $chart_filter );
		$response['ordersCount']    = $this->get_wholesale_orders_count_by_status($request);
		$response['topProducts']    = $this->get_top_products( $request );
		$response['topCustomers']   = $this->get_top_customers( $request );
		$response['recentRequests'] = $this->get_recent_requests();
		$response['recentOrders']   = $this->get_recent_orders_data( $request );
		
		$response['redirects']      = array(
			'orders'    => admin_url('admin.php?page=wc-orders&_user_role=Wholesaler'),
			'requests'  => admin_url('edit.php?post_type=wwp_requests'), 
		);
		
		$accounting = array(
			'currency_format_num_decimals'                    => wc_get_price_decimals(),
			'currency_format_symbol'                          => get_woocommerce_currency_symbol(),
			'currency_format_decimal_sep'                     => esc_attr( wc_get_price_decimal_separator() ),
			'currency_format_thousand_sep'                    => esc_attr( wc_get_price_thousand_separator() ),
			'currency_pos'                                    => get_option( 'woocommerce_currency_pos' ),
		);
		
		$response['accounting'] = $accounting;
		
		return new \WP_REST_Response($response, 200);
	}

	/**
	 * Download order invoice as PDF.
	 *
	 * Generates or retrieves a cached PDF invoice for a wholesale order.
	 * Validates that the order belongs to a wholesale customer before processing.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 *                                   Must contain 'order_id' parameter.
	 * @return \WP_REST_Response|\WP_Error Response object with PDF URL and filename on success,
	 *                                     or WP_Error on failure.
	 */
	public function download_order_invoice( $request ) {
		$order_id = absint( $request->get_param( 'order_id' ) );

		if ( ! $order_id ) {
			return new \WP_Error( 'wwp_invalid_order', __( 'Invalid order ID.', 'woocommerce-wholesale-pricing' ), array( 'status' => 400 ) );
		}

		$order = wc_get_order( $order_id );

		if ( ! $order ) {
			return new \WP_Error( 'wwp_order_not_found', __( 'Order not found.', 'woocommerce-wholesale-pricing' ), array( 'status' => 404 ) );
		}

		$wholesale_user_ids = $this->get_wholesale_user_ids();
		
		if ( empty( $wholesale_user_ids ) || ! in_array( $order->get_user_id(), $wholesale_user_ids ) ) {
			return new \WP_Error( 'wwp_non_wholesale_order', __( 'This order is not associated with a wholesale customer.', 'woocommerce-wholesale-pricing' ), array( 'status' => 403 ) );
		}

		$result = $this->get_order_invoice_pdf( $order );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return new \WP_REST_Response( $result, 200 );
	}

	/**
	 * Get order chart data.
	 *
	 * Retrieves chart data based on the specified filter type (revenue, orders, refunds, customers).
	 * Supports different time period filters (today, last_7_days, last_30_days, etc.).
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 *                                   Should contain 'filter' parameter (group-users, orders, refund, customers).
	 * @return \WP_REST_Response Response object containing chart data with 'data' and 'series' arrays.
	 */
	public function get_order_chart_data( $request ) {
		$filter = $request->get_param('filter');
		if ( empty( $filter ) ) {
			$filter = 'group-users';
		}

		$chart_data = $this->get_chart_data( $request, $filter );
		
		return new \WP_REST_Response($chart_data, 200);
	}

	/**
	 * Check if the current user has permission to access the API.
	 *
	 * Verifies that the current user has the 'manage_woocommerce' capability,
	 * which is required to access wholesale dashboard data.
	 *
	 * @since 1.0.0
	 *
	 * @param \WP_REST_Request $request Full details about the request.
	 * @return bool|\WP_Error True if user has permission, WP_Error otherwise.
	 */
	public function permissions_check( $request ) {
		if (current_user_can('manage_woocommerce')) {
			return true;
		}
		return new \WP_Error('wholesale_rest_role_permission_failed', __('You don\'t have permission.', 'woocommerce-wholesale-pricing'), array( 'status' => rest_authorization_required_code() ));
	}
}
