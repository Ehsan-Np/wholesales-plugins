<?php 
namespace WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits;

use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\DateRangeFilter;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\WholesaleOrders;

trait OrdersCount {

	use DateRangeFilter;
	use WholesaleOrders {
		get_wholesale_orders_by_date_range as protected get_orders_count_orders_by_range;
	}

	/**
	 * Get wholesale order counts grouped by order status for the selected period.
	 *
	 * @param \WP_REST_Request|null $request Request carrying filters.
	 * @return array Array with 'labels' (order status names) and 'data' (counts per status).
	 */
	public function get_wholesale_orders_count_by_status( $request = null ) {
		$ranges = $this->get_date_ranges_from_request( $request );
		$orders = $this->get_orders_count_orders_by_range( $ranges['current'], array_keys(wc_get_order_statuses()) );

		$order_statuses = wc_get_order_statuses();
		$labels         = array_values( $order_statuses );
		$status_keys    = array_keys( $order_statuses );

		$counts = array_fill_keys( $status_keys, 0 );

		if (empty($orders)) {
			return array(
				'labels' => $labels,
				'data'   => array_values( $counts ),
			);
		}

		foreach ( $orders as $order ) {
			$status_key = 'wc-' . $order->get_status();

			if ( isset( $counts[ $status_key ] ) ) {
				$counts[ $status_key ]++;
			}
		}

		return array(
			'labels' => $labels,
			'data'   => array_values( $counts ),
		);
	}
}
