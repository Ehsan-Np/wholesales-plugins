<?php
namespace WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits;

use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\DateRangeFilter;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\WholesaleUserIDs;

trait UserInformation {

	use DateRangeFilter;

	use WholesaleUserIDs;

	public function get_user_information( $request = null ) {
		$ranges = $this->get_date_ranges_from_request( $request );
		$bounds = $this->get_date_bounds_from_range_user( $ranges['current'] );

		return array(
			$this->get_total_wholesale_users_count( $bounds ),
			$this->get_total_pending_wholesalers_count( $bounds ),
			$this->get_total_rejected_wholesalers_count( $bounds ),
			$this->get_total_grouped_users_count( $bounds ),
		);
	}

	/**
	 * Get total count of wholesale users created within the selected period.
	 *
	 * @param array|null $bounds Date bounds with 'start' and 'end'.
	 * @return int
	 */
	private function get_total_wholesale_users_count( $bounds ) {
		$wholesale_role_slugs = $this->get_wholesale_role_slugs();

		if (empty($wholesale_role_slugs)) {
			return 0;
		}

		$args = array(
			'role__in'     => $wholesale_role_slugs,
			'fields'       => 'ID',
			'count_total'  => true,
			'number'       => 1,
		);

		if ($bounds) {
			$args['date_query'] = array(
				array(
					'after'     => $bounds['start'],
					'before'    => $bounds['end'],
					'inclusive' => true,
					'column'    => 'user_registered',
				),
			);
		}

		$query = new \WP_User_Query($args);

		return (int) $query->get_total();
	}

	/**
	 * Get total count of pending wholesalers within the selected period.
	 *
	 * @param array|null $bounds Date bounds with 'start' and 'end'.
	 * @return int
	 */
	private function get_total_pending_wholesalers_count( $bounds ) {
		$args = array(
			'post_type'      => 'wwp_requests',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array(
					'key'   => '_user_status',
					'value' => 'waiting',
				),
			),
		);

		$date_query = $this->build_date_query_clause( $bounds );
		if ( $date_query ) {
			$args['date_query'] = array( $date_query );
		}

		$query = new \WP_Query($args);
		return $query->found_posts;
	}

	/**
	 * Get total count of rejected wholesalers within the selected period.
	 *
	 * @param array|null $bounds Date bounds with 'start' and 'end'.
	 * @return int
	 */
	private function get_total_rejected_wholesalers_count( $bounds ) {
		$args = array(
			'post_type'      => 'wwp_requests',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_query'     => array(
				array(
					'key'   => '_user_status',
					'value' => 'rejected',
				),
			),
		);

		$date_query = $this->build_date_query_clause( $bounds );
		if ( $date_query ) {
			$args['date_query'] = array( $date_query );
		}

		$query = new \WP_Query($args);
		return $query->found_posts;
	}

	/**
	 * Get total count of grouped users (unique) based on groups created within the period.
	 *
	 * @param array|null $bounds Date bounds with 'start' and 'end'.
	 * @return int
	 */
	private function get_total_grouped_users_count( $bounds ) {
		$args = array(
			'post_type'      => 'wwp_groups',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		);

		$date_query = $this->build_date_query_clause( $bounds );
		if ( $date_query ) {
			$args['date_query'] = array( $date_query );
		}

		$query = new \WP_Query($args);
		$group_posts = $query->posts;

		if (empty($group_posts)) {
			return 0;
		}

		$all_user_ids = array();

		foreach ($group_posts as $post_id) {
			$add_users = get_post_meta($post_id, '_add_users', true);

			if (!empty($add_users) && is_array($add_users)) {
				$all_user_ids = array_merge($all_user_ids, $add_users);
			}
		}

		$unique_user_ids = array_unique($all_user_ids);
		return count($unique_user_ids);
	}

	/**
	 * Convert date range string (YYYY-MM-DD...YYYY-MM-DD) into start/end bounds.
	 *
	 * @param string $date_range
	 * @return array|null
	 */
	private function get_date_bounds_from_range_user( $date_range ) {
		if ( empty( $date_range ) || false === strpos( $date_range, '...' ) ) {
			return null;
		}

		list( $start, $end ) = explode( '...', $date_range );

		try {
			$timezone = wp_timezone();
			$start_dt = new \DateTime( $start . ' 00:00:00', $timezone );
			$end_dt   = new \DateTime( $end . ' 23:59:59', $timezone );
		} catch ( \Exception $e ) {
			return null;
		}

		return array(
			'start' => $start_dt->format( 'Y-m-d H:i:s' ),
			'end'   => $end_dt->format( 'Y-m-d H:i:s' ),
		);
	}

	/**
	 * Build a WP_Query compatible date_query clause.
	 *
	 * @param array|null $bounds
	 * @param string     $column
	 * @return array|null
	 */
	private function build_date_query_clause( $bounds, $column = 'post_date' ) {
		if ( ! $bounds ) {
			return null;
		}

		return array(
			'after'     => $bounds['start'],
			'before'    => $bounds['end'],
			'inclusive' => true,
			'column'    => $column,
		);
	}
}
