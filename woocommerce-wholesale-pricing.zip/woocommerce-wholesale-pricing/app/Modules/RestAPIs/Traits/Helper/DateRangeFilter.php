<?php

namespace WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper;

trait DateRangeFilter {
	/**
	 * Build date range strings for current and previous period based on filter.
	 *
	 * @param \WP_REST_Request $request
	 * @return array {
	 *  @type string current  YYYY-MM-DD...YYYY-MM-DD
	 *  @type string previous YYYY-MM-DD...YYYY-MM-DD
	 *  @type string label    Human-readable comparison label
	 *  @type string filter   Normalized filter key
	 * }
	 */
	private function get_date_ranges_from_request( $request ) {
		$timezone = wp_timezone();
		$today    = new \DateTime('today', $timezone);

		$filter_key = $this->normalize_filter_key($request);

		$build_range = function ( \DateTime $start, \DateTime $end ) {
			return $start->format('Y-m-d') . '...' . $end->format('Y-m-d');
		};
		switch ( $filter_key ) {
			case 'today':
				$current_start = ( clone $today );
				$current_end   = ( clone $today );

				$prev_start = ( clone $today )->modify('-1 day'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$prev_end   = ( clone $today )->modify('-1 day'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$label      = __('vs Yesterday', 'woocommerce-wholesale-pricing');
				break;

			case 'last_7_days':
				$current_start = ( clone $today )->modify('-6 days'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$current_end   = ( clone $today );

				$prev_start = ( clone $today )->modify('-13 days'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$prev_end   = ( clone $today )->modify('-7 days'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$label      = __('vs Previous 7 Days', 'woocommerce-wholesale-pricing');
				break;

			case 'last_6_months':
				// Last 6 months rolling window (by day)
				$current_start = ( clone $today )->modify('-6 months')->modify('+1 day'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$current_end   = ( clone $today );

				$prev_start = ( clone $current_start )->modify('-6 months'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$prev_end   = ( clone $current_start )->modify('-1 day'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$label      = __('vs Previous 6 Months', 'woocommerce-wholesale-pricing');
				break;

			case 'last_12_months':
				// Last 12 months rolling window (by day)
				$current_start = ( clone $today )->modify('-12 months')->modify('+1 day'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$current_end   = ( clone $today );

				$prev_start = ( clone $current_start )->modify('-12 months'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$prev_end   = ( clone $current_start )->modify('-1 day'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$label      = __('vs Previous Year', 'woocommerce-wholesale-pricing');
				break;

			case 'custom':
				$start_param = (string) $request->get_param('start_date');
				$end_param   = (string) $request->get_param('end_date');

				try {
					$current_start = new \DateTime($start_param, $timezone);
					$current_end   = new \DateTime($end_param, $timezone);
				} catch ( \Exception $e ) {
					// Fallback to last 30 days when custom params invalid
					$current_start = ( clone $today )->modify('-29 days'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
					$current_end   = ( clone $today );
				}

				// Previous period equal length
				$interval_days = (int) $current_start->diff($current_end)->format('%a') + 1;
				$prev_end      = ( clone $current_start )->modify('-1 day'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$prev_start    = ( clone $prev_end )->modify('-' . ( $interval_days - 1 ) . ' days'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$label         = __('vs Previous Period', 'woocommerce-wholesale-pricing');
				break;

			case 'last_30_days':
			default:
				$current_start = ( clone $today )->modify('-29 days'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$current_end   = ( clone $today );

				$prev_start = ( clone $today )->modify('-59 days'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$prev_end   = ( clone $today )->modify('-30 days'); //phpcs:ignore PHPCompatibility.Syntax.NewClassMemberAccess.OnCloneFound
				$label      = __('vs Previous 30 Days', 'woocommerce-wholesale-pricing');
				break;
		}

		$ranges = array(
			'current'  => $build_range($current_start, $current_end),
			'previous' => $build_range($prev_start, $prev_end),
			'label'    => $label,
			'filter'   => $filter_key,
		);

		/**
		 * Filter the computed dashboard date ranges.
		 *
		 * @param array             $ranges {
		 *   @type string current
		 *   @type string previous
		 *   @type string label
		 *   @type string filter
		 * }
		 * @param \WP_REST_Request  $request
		 * 
		 * @since 3.0.0
		 */
		return apply_filters('wwp_dashboard_date_ranges', $ranges, $request);
	}

	/**
	 * Normalize filter key from request.
	 *
	 * @param \WP_REST_Request $request
	 * @return string
	 */
	private function normalize_filter_key( $request ) {
		$filter = $request instanceof \WP_REST_Request ? (string) $request->get_param('period') : 'last_30_days';
		$filter = strtolower(trim($filter));
		$filter = str_replace(array( ' ', '-' ), '_', $filter);

		/**
		 * Filter the dashboard filter key.
		 *
		 * @param string             $filter  Normalized filter key.
		 * @param \WP_REST_Request   $request Request.
		 * 
		 * @since 3.0.0
		 */
		return apply_filters('wwp_dashboard_filter_key', $filter, $request);
	}
}
