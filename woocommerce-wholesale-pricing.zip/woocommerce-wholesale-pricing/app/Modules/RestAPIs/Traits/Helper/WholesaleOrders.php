<?php

namespace WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper;

use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\WholesaleUserIDs;

trait WholesaleOrders {

	use WholesaleUserIDs;

	/**
	 * Get wholesale orders within a date range.
	 *
	 * @param string $date_range Date range in YYYY-MM-DD...YYYY-MM-DD format (WooCommerce standard format).
	 * @return array Array of WC_Order objects.
	 */
	private function get_wholesale_orders_by_date_range( $date_range, $order_statuses = array() ) {
		$wholesale_user_ids = $this->get_wholesale_user_ids();

		if (empty($wholesale_user_ids)) {
			return array();
		}

		if ( empty( $order_statuses ) ) {
			// Get all order statuses except cancelled and failed for financial calculations.
			$all_order_statuses = array_keys(wc_get_order_statuses());
			$excluded_statuses = array( 'wc-cancelled', 'wc-failed' );
			$order_statuses = array_diff($all_order_statuses, $excluded_statuses);
			
			// If no valid statuses, return empty array.
			if (empty($order_statuses)) {
				$order_statuses = array( 'completed', 'processing', 'on-hold', 'pending' ); // Fallback to common statuses.
			}
			/**
			 * Filter the order statuses included in dashboard queries.
			 *
			 * @param array $order_statuses Status keys.
			 * 
			 * @since 3.0.0
			 */
			$order_statuses = apply_filters('wwp_dashboard_order_statuses', $order_statuses);
		}
		
		$query_args = array(
			'customer_id' => $wholesale_user_ids,
			'status'      => $order_statuses,
			'date_created' => $date_range,
			'limit'       => -1,
			'orderby'     => 'date',
			'order'       => 'ASC',
		);
		/**
		 * Filter the order query args used for dashboard score cards.
		 *
		 * @param array  $query_args
		 * @param strin
		 * 
		 * g $date_range
		 * 
		 * @since 3.0.0
		 */
		$query_args = apply_filters('wwp_dashboard_orders_query_args', $query_args, $date_range);
		$orders = wc_get_orders($query_args);

		return $orders;
	}
}
