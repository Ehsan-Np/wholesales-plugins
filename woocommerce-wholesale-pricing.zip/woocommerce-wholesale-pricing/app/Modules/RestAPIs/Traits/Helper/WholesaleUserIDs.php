<?php

namespace WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper;

trait WholesaleUserIDs {
	/**
	 * Get wholesale role slugs from taxonomy.
	 *
	 * @return array Array of wholesale role slugs.
	 */
	private function get_wholesale_role_slugs() {
		$all_terms = get_terms(array(
			'taxonomy'   => 'wholesale_user_roles',
			'hide_empty' => false,
		));

		if (empty($all_terms) || is_wp_error($all_terms)) {
			return array();
		}

		$role_slugs = array();
		foreach ($all_terms as $term) {
			$role_slugs[] = $term->slug;
		}

		return $role_slugs;
	}

	/**
	 * Get all user IDs with wholesale roles.
	 *
	 * @return array Array of user IDs.
	 */
	public function get_wholesale_user_ids() {
		$wholesale_role_slugs = $this->get_wholesale_role_slugs();

		if (empty($wholesale_role_slugs)) {
			return array();
		}

		$wholesale_user_ids = get_users(array(
			'role__in' => $wholesale_role_slugs,
			'fields'   => 'ID',
		));
		return $wholesale_user_ids;
	}
}
