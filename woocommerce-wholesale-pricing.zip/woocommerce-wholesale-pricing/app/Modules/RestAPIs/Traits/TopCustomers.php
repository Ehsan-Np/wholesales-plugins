<?php

namespace WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits;

use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\DateRangeFilter;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\WholesaleOrders;

trait TopCustomers {

	use DateRangeFilter;
	use WholesaleOrders {
		get_wholesale_orders_by_date_range as protected get_top_customer_orders_by_range;
	}

	/**
	 * Build the top wholesale customers collection ranked by total spend.
	 *
	 * @param \WP_REST_Request $request Incoming REST request (used for filters).
	 * @param int              $limit   Optional number of customers to return.
	 *
	 * @return array {
	 *   @type array items {
	 *     @type string thumb Avatar URL.
	 *     @type string name  Customer display name.
	 *     @type string email Customer email.
	 *     @type float  value Total spend within the selected period.
	 *   }
	 * }
	 */
	public function get_top_customers( $request, $limit = 5 ) {
		/**
		 * Filter
		 * 
		 * @since 3.0.0
		 */
		$limit = (int) apply_filters( 'wwp_dashboard_top_customers_limit', $limit, $request );

		if ( $limit <= 0 ) {
			$limit = 5;
		}

		$ranges = $this->get_date_ranges_from_request( $request );
		$orders = $this->get_top_customer_orders_by_range( $ranges['current'] );

		if ( empty( $orders ) ) {
			return array( 'items' => array() );
		}

		$customer_stats = array();

		foreach ( $orders as $order ) {
			$customer_id = (int) $order->get_user_id();

			if ( $customer_id <= 0 ) {
				continue;
			}

			if ( ! isset( $customer_stats[ $customer_id ] ) ) {
				$customer_stats[ $customer_id ] = array(
					'spent'      => 0,
					'last_order' => $order,
				);
			}

			$customer_stats[ $customer_id ]['spent']      += (float) $order->get_total();
			$customer_stats[ $customer_id ]['last_order'] = $order;
		}

		if ( empty( $customer_stats ) ) {
			return array( 'items' => array() );
		}

		uasort(
			$customer_stats,
			function ( $a, $b ) {
				if ( $a['spent'] == $b['spent'] ) {
					return 0;
				}
				return ( $a['spent'] < $b['spent'] ) ? 1 : -1;
			}
		);

		$items = array();

		foreach ( $customer_stats as $customer_id => $stats ) {
			$customer = get_user_by( 'id', $customer_id );
			$order    = $stats['last_order'];

			$name = $this->resolve_customer_name( $customer, $order );
			$email = $this->resolve_customer_email( $customer, $order );
			$thumb = $this->resolve_customer_avatar( $customer, $email );

			$items[] = array(
				'thumb' => $thumb,
				'name'  => $name,
				'email' => $email,
				'value' => round( (float) $stats['spent'], 2 ),
			);

			if ( count( $items ) >= $limit ) {
				break;
			}
		}

		return array( 'items' => $items );
	}

	/**
	 * Resolve a customer's display name using user or order data.
	 *
	 * @param \WP_User|null $customer User object.
	 * @param \WC_Order     $order    Order reference.
	 *
	 * @return string
	 */
	private function resolve_customer_name( $customer, $order ) {
		if ( $customer instanceof \WP_User ) {
			$name = $customer->display_name;

			if ( empty( $name ) ) {
				$name = trim( $customer->first_name . ' ' . $customer->last_name );
			}

			if ( ! empty( $name ) ) {
				return $name;
			}
		}

		$name = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );

		return ! empty( $name ) ? $name : __( 'Wholesale Customer', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Resolve a customer's email address.
	 *
	 * @param \WP_User|null $customer User object.
	 * @param \WC_Order     $order    Order reference.
	 *
	 * @return string
	 */
	private function resolve_customer_email( $customer, $order ) {
		if ( $customer instanceof \WP_User && ! empty( $customer->user_email ) ) {
			return $customer->user_email;
		}

		$email = $order->get_billing_email();

		return ! empty( $email ) ? $email : __( 'not.provided@example.com', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Resolve a customer's avatar URL with graceful fallback.
	 *
	 * @param \WP_User|null $customer User object.
	 * @param string        $email    Email fallback.
	 *
	 * @return string
	 */
	private function resolve_customer_avatar( $customer, $email ) {
		$args = array( 'size' => 96 );

		if ( $customer instanceof \WP_User ) {
			$avatar = get_avatar_url( $customer->ID, $args );

			if ( $avatar ) {
				return $avatar;
			}
		}

		if ( ! empty( $email ) ) {
			$avatar = get_avatar_url( $email, $args );

			if ( $avatar ) {
				return $avatar;
			}
		}

		return wc_placeholder_img_src();
	}
}
