<?php

namespace WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits;

use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\DateRangeFilter;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\WholesaleUserIDs;

trait RecentOrders {

	use DateRangeFilter;
	use WholesaleUserIDs;

	/**
	 * Build the recent wholesale orders collection for the dashboard.
	 *
	 * @param \WP_REST_Request|null $request Incoming request with filters.
	 * @param int                   $limit   Optional number of orders to return.
	 *
	 * @return array
	 */
	public function get_recent_orders_data( $request = null, $limit = 5 ) {
		/**
		 * Filter
		 * 
		 * @since 3.0.0
		 */
		$limit = (int) apply_filters( 'wwp_dashboard_recent_orders_limit', $limit, $request );

		if ( $limit <= 0 ) {
			$limit = 5;
		}

		$wholesale_user_ids = $this->get_wholesale_user_ids();

		if ( empty( $wholesale_user_ids ) ) {
			return array( 'items' => array() );
		}

		$query_args = array(
			'customer_id'  => $wholesale_user_ids,
			'status'       => array_keys( wc_get_order_statuses() ),
			'limit'        => $limit,
			'orderby'      => 'date',
			'order'        => 'DESC',
			'return'       => 'objects',
		);

		/**
		 * Filter the recent orders query arguments.
		 *
		 * @param array               $query_args Query args.
		 * @param string              $date_range Current date range string.
		 * @param \WP_REST_Request    $request    Current request.
		 * 
		 * @since 3.0.0
		 */
		$query_args = apply_filters( 'wwp_dashboard_recent_orders_query_args', $query_args, $request );

		$orders = wc_get_orders( $query_args );

		if ( empty( $orders ) ) {
			return array( 'items' => array() );
		}

		$items = array();

		foreach ( $orders as $order ) {
			$items[] = array(
				'id'    => $order->get_id(),
				'order' => $this->format_order_display( $order ),
				'role'  => $this->resolve_customer_role_label( $order ),
				'status'=> $this->build_status_badge( $order ),
				'total' => (float) $order->get_total(),
				'date'  => $this->format_order_date( $order ),
			);
		}

		return array(
			'items' => $items,
		);
	}

	/**
	 * Format the order display string (#number Name).
	 *
	 * @param \WC_Order $order Order instance.
	 * @return string
	 */
	private function format_order_display( $order ) {
		$number = $order->get_order_number();
		$name   = trim( $order->get_formatted_billing_full_name() );

		if ( empty( $name ) ) {
			$name = __( 'Wholesale Customer', 'woocommerce-wholesale-pricing' );
		}

		return sprintf( '#%s %s', $number, $name );
	}

	/**
	 * Resolve a readable wholesale role label for the order's customer.
	 *
	 * @param \WC_Order $order Order instance.
	 * @return string
	 */
	private function resolve_customer_role_label( $order ) {
		$user_id = (int) $order->get_user_id();

		if ( $user_id <= 0 ) {
			return __( 'Wholesaler', 'woocommerce-wholesale-pricing' );
		}

		$user = get_user_by( 'id', $user_id );

		if ( ! $user ) {
			return __( 'Wholesaler', 'woocommerce-wholesale-pricing' );
		}

		$wholesale_roles = $this->get_wholesale_role_slugs();

		foreach ( (array) $user->roles as $role_slug ) {
			if ( in_array( $role_slug, $wholesale_roles, true ) ) {
				$term = get_term_by( 'slug', $role_slug, 'wholesale_user_roles' );

				if ( $term && ! is_wp_error( $term ) ) {
					return $term->name;
				}

				return $this->format_role_label( $role_slug );
			}
		}

		return __( 'Wholesaler', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Format role slug into readable label.
	 *
	 * @param string $slug Role slug.
	 * @return string
	 */
	private function format_role_label( $slug ) {
		return ucwords( str_replace( array( '-', '_' ), ' ', $slug ) );
	}

	/**
	 * Build the HTML badge used for order status display.
	 *
	 * @param \WC_Order $order Order instance.
	 * @return string
	 */
	private function build_status_badge( $order ) {
		$status       = $order->get_status();
		$status_key   = 'wc-' . $status;
		$status_label = wc_get_order_status_name( $status_key );

		$map = array(
			'pending'    => 'status-pending',
			'processing' => 'status-processing',
			'on-hold'    => 'status-on-hold',
			'completed'  => 'status-completed',
			'cancelled'  => 'status-cancelled',
			'refunded'   => 'status-refunded',
			'failed'     => 'status-failed',
		);

		$class = isset( $map[ $status ] ) ? $map[ $status ] : 'status-processing';

		return sprintf(
			'<mark class="flex items-center bg-blue-100 text-blue-800 text-xs me-2 px-2.5 py-2 rounded-sm order-status %1$s tips"><div class="h-2 w-2 rounded-full dot %1$s"></div><span>%2$s</span></mark>',
			esc_attr( $class ),
			esc_html( $status_label )
		);
	}

	/**
	 * Format order date using site settings.
	 *
	 * @param \WC_Order $order Order instance.
	 * @return string
	 */
	private function format_order_date( $order ) {
		$date = $order->get_date_created();

		if ( ! $date ) {
			return '';
		}

		return date_i18n( get_option( 'date_format', 'M j, Y' ), $date->getTimestamp() );
	}
}
