<?php

namespace WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits;

use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\DateRangeFilter;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\WholesaleUserIDs;
use WooCommerceWholesalePricing\App\Modules\RestAPIs\Traits\Helper\WholesaleOrders;

trait TopSoldProducts {

	use DateRangeFilter;
	use WholesaleUserIDs;
	use WholesaleOrders;

	/**
	 * Build the top sold products collection for the dashboard.
	 *
	 * @param \WP_REST_Request $request Incoming REST request (used for filters).
	 * @param int              $limit   Optional number of products to return.
	 *
	 * @return array {
	 *   @type array items {
	 *     @type string thumb
	 *     @type string title
	 *     @type string category
	 *     @type int    value   Percentage share of total wholesale units sold.
	 *   }
	 * }
	 */
	public function get_top_products( $request, $limit = 5 ) {
		/**
		 * Filter
		 * 
		 * @since 3.0.0
		 */
		$limit = (int) apply_filters( 'wwp_dashboard_top_products_limit', $limit, $request );

		if ( $limit <= 0 ) {
			$limit = 5;
		}

		$ranges = $this->get_date_ranges_from_request( $request );
		$orders = $this->get_wholesale_orders_by_date_range( $ranges['current'] );

		if ( empty( $orders ) ) {
			return array( 'items' => array() );
		}

		$product_stats  = array();
		$total_quantity = 0;

		foreach ( $orders as $order ) {
			foreach ( $order->get_items( 'line_item' ) as $item ) {
				$product_id = (int) $item->get_product_id();

				if ( 0 === $product_id ) {
					$product_id = (int) $item->get_variation_id();
				}

				if ( 0 === $product_id ) {
					$product = $item->get_product();
					if ( $product ) {
						$product_id = (int) $product->get_id();
					}
				}

				if ( 0 === $product_id ) {
					continue;
				}

				if ( ! isset( $product_stats[ $product_id ] ) ) {
					$product_stats[ $product_id ] = array(
						'quantity' => 0,
						'revenue'  => 0.0,
					);
				}

				$line_quantity = (int) $item->get_quantity();

				$product_stats[ $product_id ]['quantity'] += $line_quantity;
				$product_stats[ $product_id ]['revenue']  += (float) $item->get_total();
				$total_quantity                           += $line_quantity;
			}
		}

		if ( empty( $product_stats ) ) {
			return array( 'items' => array() );
		}

		uasort(
			$product_stats,
			function ( $a, $b ) {
		
				// 1️⃣ Compare quantity (DESC)
				if ( $a['quantity'] == $b['quantity'] ) {
		
					// 2️⃣ If quantity same, compare revenue (DESC)
					if ( $a['revenue'] == $b['revenue'] ) {
						return 0;
					}
		
					return ( $a['revenue'] < $b['revenue'] ) ? 1 : -1;
				}
		
				return ( $a['quantity'] < $b['quantity'] ) ? 1 : -1;
			}
		);

		$items = array();

		foreach ( $product_stats as $product_id => $stats ) {
			$product = wc_get_product( $product_id );

			if ( ! $product ) {
				continue;
			}

			$percentage = $total_quantity > 0
				? round( ( (int) $stats['quantity'] / $total_quantity ) * 100 )
				: 0;

			$items[] = array(
				'thumb'    => $this->get_product_thumbnail_url( $product ),
				'title'    => $product->get_name(),
				'category' => $this->get_product_primary_category( $product ),
				'value'    => (int) $percentage,
			);

			if ( count( $items ) >= $limit ) {
				break;
			}
		}

		return array( 'items' => $items );
	}

	/**
	 * Resolve the primary category name for a product.
	 *
	 * @param \WC_Product $product Product instance.
	 *
	 * @return string
	 */
	private function get_product_primary_category( $product ) {
		$category_name = __( 'Uncategorized', 'woocommerce-wholesale-pricing' );

		$product_id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();

		if ( ! $product_id ) {
			return $category_name;
		}

		$terms = get_the_terms( $product_id, 'product_cat' );

		if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
			$category_name = $terms[0]->name;
		}

		return $category_name;
	}

	/**
	 * Get the thumbnail URL for a product, with a placeholder fallback.
	 *
	 * @param \WC_Product $product Product instance.
	 *
	 * @return string
	 */
	private function get_product_thumbnail_url( $product ) {
		$image_id = $product->get_image_id();

		if ( $image_id ) {
			$thumbnail = wp_get_attachment_image_url( $image_id, 'thumbnail' );
			if ( $thumbnail ) {
				return $thumbnail;
			}
		}

		return wc_placeholder_img_src();
	}
}
