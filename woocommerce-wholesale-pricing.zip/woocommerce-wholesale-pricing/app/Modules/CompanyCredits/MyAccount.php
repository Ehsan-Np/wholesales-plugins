<?php

namespace WooCommerceWholesalePricing\App\Modules\CompanyCredits;

use WooCommerceWholesalePricing\App\Strategies\Init;

/**
 * Company portal My Account endpoint for Owner / Manager / Member.
 */
class MyAccount extends Init {

	/**
	 * Endpoint slug.
	 *
	 * @var string
	 */
	public $company_slug;

	/**
	 * Endpoint menu label.
	 *
	 * @var string
	 */
	public $company_name;

	/**
	 * MyAccount constructor.
	 */
	public function __construct() {
		/**
		 * Filter the company my account slug.
		 *
		 * @since 3.4.0
		 *
		 * @param string $slug The company my account slug.
		 */
		$this->company_slug = apply_filters( 'ccp_company_my_account_slug', 'company' );
		$this->company_name = 'Company';

		add_action( 'init', array( $this, 'set_translated_labels' ), 1 );
		add_filter( 'woocommerce_get_query_vars', array( $this, 'add_query_vars' ) );
		add_filter( 'woocommerce_account_menu_items', array( $this, 'add_menu_items' ), 40 );
		add_action( 'woocommerce_account_' . $this->company_slug . '_endpoint', array( $this, 'render_endpoint' ) );
		add_filter( 'woocommerce_endpoint_' . $this->company_slug . '_title', array( $this, 'endpoint_title' ), 10, 2 );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );

		parent::__construct();
	}

	/**
	 * Set translated labels after the text domain is available (WP 6.7+).
	 *
	 * @return void
	 */
	public function set_translated_labels() {
		/**
		 * Filter the company my account name.
		 *
		 * @since 3.4.0
		 *
		 * @param string $name The company my account name.
		 */
		$this->company_name = apply_filters( 'ccp_company_my_account_name', __( 'Company', 'woocommerce-wholesale-pricing' ) );
	}

	/**
	 * Register rewrite endpoint once when company credits are enabled.
	 *
	 * @return void
	 */
	public function register() {
		add_rewrite_endpoint( $this->company_slug, EP_ROOT | EP_PAGES );

		$flush_key = 'wwp_ccp_company_endpoint_flushed';
		if ( '1.0.0' !== get_option( $flush_key ) ) {
			flush_rewrite_rules( false );
			update_option( $flush_key, '1.0.0' );
		}
	}

	/**
	 * Register endpoint query var.
	 *
	 * @param array $query_vars Query vars.
	 * @return array
	 */
	public function add_query_vars( $query_vars ) {
		$query_vars[ $this->company_slug ] = $this->company_slug;
		return $query_vars;
	}

	/**
	 * Add Company menu item for company-linked users.
	 *
	 * @param array $items Menu items.
	 * @return array
	 */
	public function add_menu_items( $items ) {
		$company_id = get_user_meta( get_current_user_id(), 'ccp_company_id', true );
		if ( empty( $company_id ) ) {
			return $items;
		}

		$logout = null;
		if ( isset( $items['customer-logout'] ) ) {
			$logout = $items['customer-logout'];
			unset( $items['customer-logout'] );
		}

		$items[ $this->company_slug ] = $this->company_name;

		if ( null !== $logout ) {
			$items['customer-logout'] = $logout;
		}

		return $items;
	}

	/**
	 * Endpoint page title.
	 *
	 * @param string $title Current title.
	 * @param string $endpoint Endpoint slug.
	 * @return string
	 */
	public function endpoint_title( $title, $endpoint ) {
		unset( $endpoint );
		return $this->company_name;
	}

	/**
	 * Enqueue assets on the company endpoint.
	 *
	 * @return void
	 */
	public function enqueue_assets() {
		if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
			return;
		}

		if ( function_exists( 'is_wc_endpoint_url' ) && ! is_wc_endpoint_url( $this->company_slug ) ) {
			return;
		}

		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style( 'wwp-ccp-frontend' );
		wp_enqueue_style( 'wwp_dataTables' );
		wp_enqueue_script( 'wwp_dataTables' );
		wp_enqueue_script( 'wwp-ccp-frontend' );

		wp_localize_script(
			'wwp-ccp-frontend',
			'wwp_ccp_frontend',
			array(
				'ajax_url'   => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'ccp_user_security' ),
				'company_id' => absint( get_user_meta( get_current_user_id(), 'ccp_company_id', true ) ),
				'i18n'       => array(
					'confirmDeleteShared' => __( 'Are you sure you want to delete this shared cart?', 'woocommerce-wholesale-pricing' ),
					'selectUser'          => __( 'Please select user', 'woocommerce-wholesale-pricing' ),
					'requiredTitle'       => __( 'Required Title', 'woocommerce-wholesale-pricing' ),
					'itemsAdded'          => __( 'Items added to the cart successfully', 'woocommerce-wholesale-pricing' ),
					'orderDetails'        => __( 'Order details', 'woocommerce-wholesale-pricing' ),
					'sharedCartDetails'   => __( 'Shared Carts Detail', 'woocommerce-wholesale-pricing' ),
					'requestSubmitted'    => __( 'Credit request submitted successfully.', 'woocommerce-wholesale-pricing' ),
					'requestFailed'       => __( 'Request failed.', 'woocommerce-wholesale-pricing' ),
					'confirmDeclineRequest' => __( 'Decline this credit request?', 'woocommerce-wholesale-pricing' ),
					'confirmRejectOrder'  => __( 'Reject this order? Credits will be restored to the buyer.', 'woocommerce-wholesale-pricing' ),
					'view'                => __( 'View', 'woocommerce-wholesale-pricing' ),
					'approve'             => __( 'Approve', 'woocommerce-wholesale-pricing' ),
					'reject'              => __( 'Reject', 'woocommerce-wholesale-pricing' ),
					'addNewUser'          => __( 'Add New User', 'woocommerce-wholesale-pricing' ),
					'editUser'            => __( 'Edit User', 'woocommerce-wholesale-pricing' ),
					'edit'                => __( 'Edit', 'woocommerce-wholesale-pricing' ),
					'remove'              => __( 'Remove', 'woocommerce-wholesale-pricing' ),
					'confirmRemoveMember' => __( 'Remove this member from the company?', 'woocommerce-wholesale-pricing' ),
					'firstNameRequired'   => __( 'First name is required.', 'woocommerce-wholesale-pricing' ),
					'lastNameRequired'    => __( 'Last name is required.', 'woocommerce-wholesale-pricing' ),
					'usernameRequired'    => __( 'Username is required.', 'woocommerce-wholesale-pricing' ),
					'emailRequired'       => __( 'Email address is required.', 'woocommerce-wholesale-pricing' ),
					'userAdded'           => __( 'User added successfully.', 'woocommerce-wholesale-pricing' ),
					'userUpdated'         => __( 'User updated successfully.', 'woocommerce-wholesale-pricing' ),
				),
			)
		);

		wp_add_inline_script(
			'wwp-ccp-frontend',
			'window.admin_ccp_script = window.wwp_ccp_frontend;',
			'before'
		);
	}

	/**
	 * Render company portal content.
	 *
	 * @return void
	 */
	public function render_endpoint() {
		$user_id    = get_current_user_id();
		$company_id = get_user_meta( $user_id, 'ccp_company_id', true );

		if ( empty( $company_id ) ) {
			printf(
				'<p>%s</p>',
				esc_html__( 'You are not associated with any company.', 'woocommerce-wholesale-pricing' )
			);
			return;
		}

		$tab              = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : 'orders';
		$ccp_company_role = get_user_meta( $user_id, 'ccp_company_role', true );
		$endpoint_url     = wc_get_account_endpoint_url( $this->company_slug );

		$allowed_tabs = array( 'orders', 'users', 'credit', 'credit-requests', 'my-shared-carts', 'user-shared-carts' );
		if ( ! in_array( $tab, $allowed_tabs, true ) ) {
			$tab = 'orders';
		}

		if ( ! authentication_role( $tab ) ) {
			$tab = 'orders';
		}

		if ( 'users' === $tab && 'yes' !== ccp_get_option_yes_default( 'ccp_manage_users' ) ) {
			$tab = 'orders';
		}

		$user             = wp_get_current_user();
		$company_post     = get_post( $company_id );
		$company_email    = get_post_meta( $company_id, 'ccp_company_email', true );
		$consumed         = ccp_company_credits( $company_id );
		$user_id          = get_current_user_id();
		$user_credit_limit = ccp_get_effective_user_credit_limit( $company_id, $user_id );
		$user_wallet      = ccp_get_user_wallet_balance( $company_id, $user_id );
		$company_available = isset( $consumed['remaining'] ) ? $consumed['remaining'] : 0;
		$wallet_consumed  = function_exists( 'ccp_get_user_wallet_consumed_amount' ) ? ccp_get_user_wallet_consumed_amount( $company_id, $user_id ) : 0.0;

		$role_labels = array(
			'ccp_owner'   => __( 'Owner', 'woocommerce-wholesale-pricing' ),
			'ccp_manager' => __( 'Manager', 'woocommerce-wholesale-pricing' ),
			'ccp_member'  => __( 'Member', 'woocommerce-wholesale-pricing' ),
		);
		$role_label = isset( $role_labels[ $ccp_company_role ] ) ? $role_labels[ $ccp_company_role ] : $ccp_company_role;

		$initials = '';
		$name     = $user->display_name;
		$parts    = preg_split( '/\s+/', trim( $name ) );
		if ( ! empty( $parts[0] ) ) {
			$initials .= strtoupper( substr( $parts[0], 0, 1 ) );
		}
		if ( ! empty( $parts[1] ) ) {
			$initials .= strtoupper( substr( $parts[1], 0, 1 ) );
		}
		if ( '' === $initials ) {
			$initials = 'U';
		}

		/**
		 * Action to start the company frontend section.
		 *
		 * @since 3.4.0
		 */
		do_action( 'ccp_frontend_start_section' );

		wwp_view(
			'frontend.company-credits.my-account.portal',
			array(
				'company_id'       => $company_id,
				'tab'              => $tab,
				'ccp_company_role' => $ccp_company_role,
				'company_slug'     => $this->company_slug,
				'endpoint_url'     => $endpoint_url,
				'user'             => $user,
				'user_initials'    => $initials,
				'role_label'       => $role_label,
				'company_name'     => $company_post ? $company_post->post_title : '',
				'company_email'    => $company_email,
				'credit_limit'       => $user_credit_limit,
				'total_credit'       => isset( $consumed['credit'] ) ? $consumed['credit'] : 0,
				'available_credit'   => $user_wallet,
				'company_available'  => $company_available,
				'consumed_credit'    => $wallet_consumed,
			)
		);
	}
}
