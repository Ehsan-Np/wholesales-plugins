<?php
/**
 * Shared cart AJAX endpoints (B2B CCP parity).
 *
 * @package WooCommerceWholesalePricing
 */

namespace WooCommerceWholesalePricing\App\Modules\CompanyCredits;

/**
 * Handles share-cart save / list / delete / add-to-cart AJAX.
 */
class SharedCartAjax {

	/**
	 * SharedCartAjax constructor.
	 */
	public function __construct() {
		$actions = array(
			'ccp_sahre_cart_save'         => 'save_shared_cart',
			'ccp_shared_cart_datatable'   => 'my_shared_carts_datatable',
			'ccp_user_shared_cart'        => 'user_shared_carts_datatable',
			'ccp_my_shared_cart_delete'   => 'delete_my_shared_cart',
			'ccp_user_shared_cart_delete' => 'delete_user_shared_cart',
			'ccp_shared_cart_template'    => 'shared_cart_template',
			'ccp_add_to_cart_shared'      => 'add_to_cart_shared',
		);

		foreach ( $actions as $hook => $method ) {
			add_action( 'wp_ajax_' . $hook, array( $this, $method ) );
		}
	}

	/**
	 * Verify current user can share carts.
	 *
	 * @return bool
	 */
	private function can_share() {
		return is_user_logged_in()
			&& function_exists( 'authentication_role' )
			&& authentication_role( 'user-shared-carts' );
	}

	/**
	 * Whether a target user belongs to the current user's company.
	 *
	 * @param int $user_id Target user ID.
	 * @return bool
	 */
	private function is_same_company_user( $user_id ) {
		$company_id = get_user_meta( get_current_user_id(), 'ccp_company_id', true );
		if ( empty( $company_id ) ) {
			return false;
		}

		return get_user_meta( $user_id, 'ccp_company_id', true ) === $company_id;
	}

	/**
	 * Save current cart as a shared cart for another company user.
	 *
	 * @return void
	 */
	public function save_shared_cart() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		if ( ! $this->can_share() ) {
			wp_send_json(
				array(
					'message' => __( 'You are not allowed to share carts.', 'woocommerce-wholesale-pricing' ),
					'status'  => 'failed',
				)
			);
		}

		$post          = ccp_post_data();
		$title         = isset( $post['ccp_share_title'] ) ? sanitize_text_field( $post['ccp_share_title'] ) : '';
		$share_user_id = isset( $post['ccp_share_user'] ) ? absint( $post['ccp_share_user'] ) : 0;

		if ( '' === $title ) {
			wp_send_json(
				array(
					'message' => __( 'Required Title', 'woocommerce-wholesale-pricing' ),
					'status'  => 'failed',
				)
			);
		}

		if ( $share_user_id <= 0 || ! $this->is_same_company_user( $share_user_id ) ) {
			wp_send_json(
				array(
					'message' => __( 'Please select a valid company user.', 'woocommerce-wholesale-pricing' ),
					'status'  => 'failed',
				)
			);
		}

		if ( ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() ) {
			wp_send_json(
				array(
					'message' => __( 'Cart empty', 'woocommerce-wholesale-pricing' ),
					'status'  => 'failed',
				)
			);
		}

		$arraydata = array();

		foreach ( WC()->cart->get_cart() as $key => $cart ) {
			unset( $key );
			$rand = wp_rand( 120, 11100333 );

			$line_subtotal = isset( $cart['line_subtotal'] ) ? (float) $cart['line_subtotal'] : 0;
			$line_total    = isset( $cart['line_total'] ) ? (float) $cart['line_total'] : $line_subtotal;

			if ( 0.0 === $line_subtotal && isset( $cart['data'] ) && is_a( $cart['data'], 'WC_Product' ) ) {
				$line_subtotal = (float) $cart['data']->get_price() * (float) $cart['quantity'];
			}

			if ( 0.0 === $line_total ) {
				$line_total = $line_subtotal;
			}

			$arraydata[ $rand ]['ccp_product_id']    = isset( $cart['product_id'] ) ? (int) $cart['product_id'] : 0;
			$arraydata[ $rand ]['ccp_variation_id']  = isset( $cart['variation_id'] ) ? (int) $cart['variation_id'] : 0;
			$arraydata[ $rand ]['ccp_product_qty']   = isset( $cart['quantity'] ) ? (float) $cart['quantity'] : 1;
			$arraydata[ $rand ]['ccp_line_subtotal'] = $line_subtotal;
			$arraydata[ $rand ]['ccp_line_total']    = $line_total;

			if ( ! empty( $cart['variation'] ) && is_array( $cart['variation'] ) ) {
				$arraydata[ $rand ]['ccp_variation'] = wc_clean( $cart['variation'] );
			}

			if ( ! empty( $cart['booking'] ) && is_array( $cart['booking'] ) ) {
				$arraydata[ $rand ]['ccp_booking'] = wc_clean( $cart['booking'] );
			}

			if ( ! empty( $cart['addons'] ) && is_array( $cart['addons'] ) ) {
				$arraydata[ $rand ]['ccp_addons'] = wc_clean( $cart['addons'] );
			}
		}

		$post_args = array(
			'post_title'  => $title,
			'post_type'   => 'ccp_sahre_cart',
			'post_status' => 'publish',
			'post_author' => get_current_user_id(),
			'meta_input'  => array(
				'ccp_sahre_cart'  => $arraydata,
				'ccp_from_shared' => get_current_user_id(),
				'ccp_to_shared'   => $share_user_id,
				'ccp_deleted'     => 0,
			),
		);

		/**
		 * Filter the shared cart insert arguments.
		 *
		 * @since 3.4.0
		 *
		 * @param array $post_args The shared cart insert arguments.
		 */
		$id = wp_insert_post( apply_filters( 'ccp_sahre_cart_args', $post_args ), true );

		if ( is_wp_error( $id ) ) {
			wp_send_json(
				array(
					'message' => $id->get_error_message(),
					'status'  => 'failed',
				)
			);
		}

		wp_send_json(
			/**
			 * Filter the shared cart message.
			 *
			 * @since 3.4.0
			 *
			 * @param array $message The message array.
			 */
			apply_filters(
				'ccp_sahre_cart_message',
				array(
					'message' => __( 'Cart shared successfully.', 'woocommerce-wholesale-pricing' ),
					'status'  => 'success',
				)
			)
		);
	}

	/**
	 * DataTables payload: carts shared by the current user.
	 *
	 * @return void
	 */
	public function my_shared_carts_datatable() {
		if ( ! is_user_logged_in() || ! authentication_role( 'my-shared-carts' ) ) {
			wp_send_json( array( 'data' => array() ) );
		}

		$query = new \WP_Query(
			array(
				'post_type'      => 'ccp_sahre_cart',
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'meta_query'     => array(
					array(
						'key'   => 'ccp_from_shared',
						'value' => get_current_user_id(),
					),
				),
			)
		);

		$rows = array();

		while ( $query->have_posts() ) {
			$query->the_post();
			$post_id     = get_the_ID();
			$user_email  = '';
			$to_user_id  = get_post_meta( $post_id, 'ccp_to_shared', true );
			$share_items = get_post_meta( $post_id, 'ccp_sahre_cart', true );

			if ( ! empty( $to_user_id ) ) {
				$user_info = get_userdata( $to_user_id );
				if ( $user_info ) {
					$user_email = $user_info->user_email;
				}
			}

			$rows[] = array(
				'title'       => get_the_title(),
				'shared_with' => $user_email,
				'count_list'  => ( is_array( $share_items ) ? count( $share_items ) : 0 ) . ' items',
				'id'          => $post_id,
			);
		}

		wp_reset_postdata();
		wp_send_json( array( 'data' => $rows ) );
	}

	/**
	 * DataTables payload: carts shared with the current user.
	 *
	 * @return void
	 */
	public function user_shared_carts_datatable() {
		if ( ! is_user_logged_in() || ! authentication_role( 'user-shared-carts' ) ) {
			wp_send_json( array( 'data' => array() ) );
		}

		$query = new \WP_Query(
			array(
				'post_type'      => 'ccp_sahre_cart',
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'   => 'ccp_to_shared',
						'value' => get_current_user_id(),
					),
					array(
						'key'   => 'ccp_deleted',
						'value' => 0,
					),
				),
			)
		);

		$rows = array();

		while ( $query->have_posts() ) {
			$query->the_post();
			$post_id     = get_the_ID();
			$user_email  = '';
			$from_user   = get_post_meta( $post_id, 'ccp_from_shared', true );
			$share_items = get_post_meta( $post_id, 'ccp_sahre_cart', true );

			if ( ! empty( $from_user ) ) {
				$user_info = get_userdata( $from_user );
				if ( $user_info ) {
					$user_email = $user_info->user_email;
				}
			}

			$rows[] = array(
				'title'       => get_the_title(),
				'shared_with' => $user_email,
				'count_list'  => ( is_array( $share_items ) ? count( $share_items ) : 0 ) . ' items',
				'id'          => $post_id,
			);
		}

		wp_reset_postdata();
		wp_send_json( array( 'data' => $rows ) );
	}

	/**
	 * Permanently delete a cart shared by the current user.
	 *
	 * @return void
	 */
	public function delete_my_shared_cart() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$post_id = absint( ccp_post_data( 'post_id' ) );
		if ( $post_id <= 0 || 'ccp_sahre_cart' !== get_post_type( $post_id ) ) {
			wp_die( 'invalid' );
		}

		if ( (int) get_post_meta( $post_id, 'ccp_from_shared', true ) !== get_current_user_id() ) {
			wp_die( 'forbidden' );
		}

		wp_delete_post( $post_id, true );
		wp_die( 'deleted' );
	}

	/**
	 * Soft-delete a cart shared with the current user.
	 *
	 * @return void
	 */
	public function delete_user_shared_cart() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$post_id = absint( ccp_post_data( 'post_id' ) );
		if ( $post_id <= 0 || 'ccp_sahre_cart' !== get_post_type( $post_id ) ) {
			wp_die( 'invalid' );
		}

		if ( (int) get_post_meta( $post_id, 'ccp_to_shared', true ) !== get_current_user_id() ) {
			wp_die( 'forbidden' );
		}

		update_post_meta( $post_id, 'ccp_deleted', 1 );
		wp_die( 'deleted' );
	}

	/**
	 * Render shared cart detail modal markup.
	 *
	 * @return void
	 */
	public function shared_cart_template() {
		if ( ! is_user_logged_in() ) {
			wp_die();
		}

		$post_id = absint( ccp_post_data( 'post_id' ) );
		if ( $post_id <= 0 || 'ccp_sahre_cart' !== get_post_type( $post_id ) ) {
			wp_die();
		}

		$from = (int) get_post_meta( $post_id, 'ccp_from_shared', true );
		$to   = (int) get_post_meta( $post_id, 'ccp_to_shared', true );
		$user = get_current_user_id();

		if ( $from !== $user && $to !== $user ) {
			wp_die();
		}

		wwp_view(
			'frontend.company-credits.shared-cart-detail',
			array(
				'post_id' => $post_id,
			),
			true
		);
		wp_die();
	}

	/**
	 * Add all items from a shared cart into the current cart.
	 *
	 * @return void
	 */
	public function add_to_cart_shared() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			wp_die( 'failed' );
		}

		$post_id = absint( ccp_post_data( 'post_id' ) );
		if ( $post_id <= 0 || 'ccp_sahre_cart' !== get_post_type( $post_id ) ) {
			wp_die( 'failed' );
		}

		$from = (int) get_post_meta( $post_id, 'ccp_from_shared', true );
		$to   = (int) get_post_meta( $post_id, 'ccp_to_shared', true );
		$user = get_current_user_id();

		if ( $from !== $user && $to !== $user ) {
			wp_die( 'failed' );
		}

		$share_cart = get_post_meta( $post_id, 'ccp_sahre_cart', true );
		$has_error  = false;

		if ( ! empty( $share_cart ) && is_array( $share_cart ) ) {
			foreach ( $share_cart as $list ) {
				if ( empty( $list['ccp_product_id'] ) ) {
					continue;
				}

				$product_id   = (int) $list['ccp_product_id'];
				$quantity     = isset( $list['ccp_product_qty'] ) ? max( 1, absint( $list['ccp_product_qty'] ) ) : 1;
				$variation_id = isset( $list['ccp_variation_id'] ) ? absint( $list['ccp_variation_id'] ) : 0;
				$variation    = array();
				$cart_data    = array();

				if ( ! empty( $list['ccp_variation'] ) && is_array( $list['ccp_variation'] ) ) {
					$variation = wc_clean( $list['ccp_variation'] );
				}

				if ( ! empty( $list['ccp_booking'] ) && is_array( $list['ccp_booking'] ) ) {
					$booking_data   = wc_clean( $list['ccp_booking'] );
					$protected_keys = array( '_booking_id', '_booking_parent_id', '_booking_order_item_id' );
					foreach ( $protected_keys as $protected_key ) {
						unset( $booking_data[ $protected_key ] );
					}
					$cart_data['booking'] = $booking_data;
				}

				if ( ! empty( $list['ccp_addons'] ) && is_array( $list['ccp_addons'] ) ) {
					$cart_data['addons'] = wc_clean( $list['ccp_addons'] );
				}

				$added = WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation, $cart_data );
				if ( ! $added ) {
					$has_error = true;
				}
			}
		}

		wp_die( $has_error ? 'failed' : 'done' );
	}
}
