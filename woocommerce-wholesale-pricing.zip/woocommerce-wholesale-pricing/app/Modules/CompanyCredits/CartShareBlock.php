<?php
/**
 * WooCommerce Blocks integration for Share Cart.
 *
 * Loaded only after woocommerce_blocks_loaded so IntegrationInterface exists.
 *
 * @package WooCommerceWholesalePricing
 */

namespace WooCommerceWholesalePricing\App\Modules\CompanyCredits;

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;

/**
 * Registers the Share Cart block script with WooCommerce Cart / Checkout Blocks.
 */
class CartShareBlock implements IntegrationInterface {

	/**
	 * Singleton instance.
	 *
	 * @var CartShareBlock|null
	 */
	protected static $instance = null;

	/**
	 * Whether block scripts were registered.
	 *
	 * @var bool
	 */
	protected $is_initialized = false;

	/**
	 * Get singleton instance.
	 *
	 * @return CartShareBlock
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Integration name.
	 *
	 * @return string
	 */
	public function get_name() {
		return 'wwp-ccp-cart-share';
	}

	/**
	 * Bootstrap block scripts.
	 *
	 * @return void
	 */
	public function initialize() {
		if ( $this->is_initialized ) {
			return;
		}

		$asset_path = WWP_PLUGIN_PATH . 'build/company-credits/cart-share/index.asset.php';
		$asset      = file_exists( $asset_path )
			? include $asset_path
			: array(
				'dependencies' => array(),
				'version'      => WWP_VERSION,
			);

		wp_register_script(
			'wwp-ccp-cart-share-blocks',
			WWP_PLUGIN_URL . 'build/company-credits/cart-share/index.js',
			isset( $asset['dependencies'] ) ? $asset['dependencies'] : array(),
			isset( $asset['version'] ) ? $asset['version'] : WWP_VERSION,
			true
		);

		add_filter(
			'__experimental_woocommerce_blocks_add_data_attributes_to_block',
			function ( $blocks ) {
				$blocks[] = 'wwp-ccp/cart-share';
				return $blocks;
			}
		);

		$this->is_initialized = true;
	}

	/**
	 * Frontend script handles.
	 *
	 * @return string[]
	 */
	public function get_script_handles() {
		return array( 'wwp-ccp-cart-share-blocks' );
	}

	/**
	 * Editor script handles.
	 *
	 * @return string[]
	 */
	public function get_editor_script_handles() {
		return array( 'wwp-ccp-cart-share-blocks' );
	}

	/**
	 * Data exposed to the block script.
	 *
	 * @return array
	 */
	public function get_script_data() {
		$can_share = function_exists( 'authentication_role' ) && authentication_role( 'user-shared-carts' );

		return array(
			'canShare'        => $can_share,
			'users'           => $can_share ? ccp_get_company_share_users() : array(),
			'ajax_url'        => admin_url( 'admin-ajax.php' ),
			'nonce'           => wp_create_nonce( 'ccp_user_security' ),
			'shareLabel'      => __( 'Share cart', 'woocommerce-wholesale-pricing' ),
			'titleLabel'      => __( 'Title', 'woocommerce-wholesale-pricing' ),
			'usersLabel'      => __( 'User(s)', 'woocommerce-wholesale-pricing' ),
			'selectUserLabel' => __( 'Select User', 'woocommerce-wholesale-pricing' ),
			'modalTitle'      => __( 'Share cart', 'woocommerce-wholesale-pricing' ),
		);
	}
}
