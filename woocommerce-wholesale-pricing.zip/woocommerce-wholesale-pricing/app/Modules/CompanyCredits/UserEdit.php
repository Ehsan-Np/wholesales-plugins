<?php



namespace WooCommerceWholesalePricing\App\Modules\CompanyCredits;

/**

 * Company assignment fields on user profile screens.

 */

class UserEdit {



	/**

	 * UserEdit constructor.

	 */

	public function __construct() {

		add_action( 'user_new_form', array( $this, 'render_new_user_fields' ) );

		add_action( 'edit_user_profile', array( $this, 'render_fields' ) );

		add_action( 'show_user_profile', array( $this, 'render_fields' ) );

		add_action( 'user_register', array( $this, 'save_fields' ) );

		add_action( 'personal_options_update', array( $this, 'save_fields' ) );

		add_action( 'edit_user_profile_update', array( $this, 'save_fields' ) );

		add_action( 'user_profile_update_errors', array( $this, 'validate_fields' ), 10, 3 );

		add_action( 'admin_init', array( $this, 'validate_new_user_fields' ) );
	}



	/**

	 * Render company fields on the Add New User screen.
	 *
	 * @param string $operation Current operation.

	 * @return void

	 */

	public function render_new_user_fields( $operation ) {

		unset( $operation );



		$this->render_fields( new \WP_User( 0 ) );
	}



	/**

	 * Render company and role fields on user profile.
	 *
	 * @param \WP_User $user User object.

	 * @return void

	 */

	public function render_fields( $user ) {

		$user_id          = isset( $user->ID ) ? absint( $user->ID ) : 0;

		$ccp_company_id   = $user_id ? get_user_meta( $user_id, 'ccp_company_id', true ) : '';

		$ccp_company_role = $user_id ? get_user_meta( $user_id, 'ccp_company_role', true ) : '';

		$company_slug     = wwp_env()->get( 'company_credits_slug' );



		$companies = get_posts(

			array(

				'post_type'      => $company_slug,

				'post_status'    => 'publish',

				'posts_per_page' => -1,

				'orderby'        => 'title',

				'order'          => 'ASC',

			)

		);

		?>

		<h3 class="heading"><?php esc_html_e( 'Company', 'woocommerce-wholesale-pricing' ); ?></h3>

		<table class="form-table" role="presentation">

			<tr>

				<th><label for="ccp_company_id"><?php esc_html_e( 'Company', 'woocommerce-wholesale-pricing' ); ?></label></th>

				<td>

					<select id="ccp_company_id" name="ccp_company_id" class="regular-text">

						<option value=""><?php esc_html_e( 'Select Company', 'woocommerce-wholesale-pricing' ); ?></option>

						<?php if ( is_array( $companies ) && ! empty( $companies ) ) : ?>

							<?php foreach ( $companies as $company ) : ?>

								<option value="<?php echo esc_attr( $company->ID ); ?>" <?php selected( $ccp_company_id, $company->ID ); ?>><?php echo esc_html( $company->post_title ); ?></option>

							<?php endforeach; ?>

						<?php endif; ?>

					</select>

				</td>

			</tr>

			<tr>

				<th><label for="ccp_company_role"><?php esc_html_e( 'Company User Role', 'woocommerce-wholesale-pricing' ); ?></label></th>

				<td>

					<select id="ccp_company_role" name="ccp_company_role" class="regular-text">

						<option value=""><?php esc_html_e( 'Select User Role', 'woocommerce-wholesale-pricing' ); ?></option>

						<option value="ccp_owner" <?php selected( $ccp_company_role, 'ccp_owner' ); ?>><?php esc_html_e( 'Owner', 'woocommerce-wholesale-pricing' ); ?></option>

						<option value="ccp_manager" <?php selected( $ccp_company_role, 'ccp_manager' ); ?>><?php esc_html_e( 'Manager', 'woocommerce-wholesale-pricing' ); ?></option>

						<option value="ccp_member" <?php selected( $ccp_company_role, 'ccp_member' ); ?>><?php esc_html_e( 'Member', 'woocommerce-wholesale-pricing' ); ?></option>

					</select>

				</td>

			</tr>

		</table>

		<?php
	}



	/**

	 * Save company assignment user meta and sync company post meta.
	 *
	 * @param int $user_id User ID.

	 * @return bool|false

	 */

	public function save_fields( $user_id ) {

		$user_id = absint( $user_id );

		if ( empty( $user_id ) || ! current_user_can( 'edit_user', $user_id ) ) {

			return false;

		}



		$post = ccp_post_data();

		if ( ! isset( $post['ccp_company_id'] ) && ! isset( $post['ccp_company_role'] ) ) {

			return false;

		}



		$ccp_company_role = isset( $post['ccp_company_role'] ) ? sanitize_text_field( $post['ccp_company_role'] ) : '';

		$ccp_company_id   = isset( $post['ccp_company_id'] ) ? absint( $post['ccp_company_id'] ) : 0;



		if ( empty( $ccp_company_role ) || empty( $ccp_company_id ) ) {

			$ccp_company_role = '';

			$ccp_company_id   = 0;

		}



		ccp_sync_user_company_assignment( $user_id, $ccp_company_id, $ccp_company_role );



		return true;
	}



	/**

	 * Validate company profile fields.
	 *
	 * @param \WP_Error $errors Error object.

	 * @param bool      $update Whether this is an existing user being updated.

	 * @param \WP_User  $user User object.

	 * @return void

	 */

	public function validate_fields( $errors, $update, $user ) {

		unset( $update, $user );



		$this->add_validation_errors( $errors, ccp_post_data() );
	}



	/**

	 * Validate company fields when creating a user in admin.
	 *
	 * @return void

	 */

	public function validate_new_user_fields() {

		global $pagenow;

		$createUser = filter_input( INPUT_POST, 'createuser', FILTER_SANITIZE_SPECIAL_CHARS );

		if ( 'user-new.php' !== $pagenow || empty( $createUser ) ) {

			return;

		}



		if ( ! current_user_can( 'create_users' ) ) {

			return;

		}



		$errors = new \WP_Error();

		$this->add_validation_errors( $errors, ccp_post_data() );



		if ( $errors->has_errors() ) {

			wp_die(

				esc_html( $errors->get_error_message() ),

				esc_html__( 'Company assignment error', 'woocommerce-wholesale-pricing' ),

				array( 'back_link' => true )

			);

		}
	}



	/**

	 * Add validation errors for company assignment fields.
	 *
	 * @param \WP_Error $errors Error object.

	 * @param array     $post Posted data.

	 * @return void

	 */

	private function add_validation_errors( $errors, $post ) {

		$company_id   = isset( $post['ccp_company_id'] ) ? sanitize_text_field( $post['ccp_company_id'] ) : '';

		$company_role = isset( $post['ccp_company_role'] ) ? sanitize_text_field( $post['ccp_company_role'] ) : '';



		if ( ! empty( $company_id ) && empty( $company_role ) ) {

			$errors->add( 'ccp_user_error', __( 'You must choose a company user role.', 'woocommerce-wholesale-pricing' ) );

		}



		if ( empty( $company_id ) && ! empty( $company_role ) ) {

			$errors->add( 'ccp_user_error', __( 'You must choose a company.', 'woocommerce-wholesale-pricing' ) );

		}
	}
}


