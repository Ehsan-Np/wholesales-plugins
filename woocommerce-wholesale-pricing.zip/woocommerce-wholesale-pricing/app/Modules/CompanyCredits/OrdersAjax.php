<?php
/**
 * Company orders AJAX endpoints.
 *
 * @package WooCommerceWholesalePricing
 */

namespace WooCommerceWholesalePricing\App\Modules\CompanyCredits;

/**
 * List / view / approve / reject company credit orders from My Account.
 */
class OrdersAjax {

	/**
	 * OrdersAjax constructor.
	 */
	public function __construct() {
		add_action( 'wp_ajax_ccp_get_company_orders', array( $this, 'get_company_orders' ) );
		add_action( 'wp_ajax_ccp_get_order_view', array( $this, 'get_order_view' ) );
		add_action( 'wp_ajax_ccp_approve_company_order', array( $this, 'approve_order' ) );
		add_action( 'wp_ajax_ccp_reject_company_order', array( $this, 'reject_order' ) );
		add_action( 'wp_ajax_ccp_get_company_credits', array( $this, 'get_company_credits' ) );
	}

	/**
	 * Current user's company context.
	 *
	 * @return array{company_id:int,role:string}|null
	 */
	protected function get_company_context() {
		if ( ! is_user_logged_in() ) {
			return null;
		}

		$user_id    = get_current_user_id();
		$company_id = absint( get_user_meta( $user_id, 'ccp_company_id', true ) );
		if ( empty( $company_id ) ) {
			return null;
		}

		return array(
			'company_id' => $company_id,
			'role'       => (string) get_user_meta( $user_id, 'ccp_company_role', true ),
		);
	}

	/**
	 * DataTables payload for company orders.
	 *
	 * @return void
	 */
	public function get_company_orders() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$ctx = $this->get_company_context();
		if ( ! $ctx ) {
			wp_send_json( array( 'data' => array() ) );
		}

		$post = function_exists( 'ccp_post_data' ) ? ccp_post_data() : array();

		// Scope by company users; works on both HPOS and legacy order storage.
		$company_user_ids = get_users(
			array(
				'meta_key'   => 'ccp_company_id',
				'meta_value' => $ctx['company_id'],
				'fields'     => 'ID',
			)
		);
		$company_user_ids = array_map( 'absint', (array) $company_user_ids );

		if ( empty( $company_user_ids ) ) {
			wp_send_json( array( 'data' => array() ) );
		}

		$args = array(
			'limit'          => -1,
			'orderby'        => 'date',
			'order'          => 'DESC',
			'customer'       => $company_user_ids,
			'payment_method' => 'company_credit_payment',
		);

		$date_query = array();
		if ( ! empty( $post['start_date'] ) ) {
			$date_query['after'] = sanitize_text_field( $post['start_date'] );
		}
		if ( ! empty( $post['end_date'] ) ) {
			$date_query['before']    = sanitize_text_field( $post['end_date'] );
			$date_query['inclusive'] = true;
		}
		if ( ! empty( $date_query ) ) {
			$args['date_query'] = $date_query;
		}

		if ( 'ccp_member' === $ctx['role'] ) {
			$args['customer'] = array( get_current_user_id() );
		} elseif ( ! empty( $post['ccp_select_user'] ) ) {
			$selected = absint( $post['ccp_select_user'] );
			if ( in_array( $selected, $company_user_ids, true ) ) {
				$args['customer'] = array( $selected );
			}
		}

		
		/**
		 * Filter the company orders arguments.
		 *
		 * @since 3.4.0
		 *
		 * @param array $args The arguments.
		 */
		$orders = wc_get_orders( apply_filters( 'ccp_get_company_orders_args', $args ) );
		$rows   = array();

		foreach ( $orders as $order ) {
			if ( ! $order instanceof \WC_Order ) {
				continue;
			}

			$user       = $order->get_user();
			$user_email = $user ? $user->user_email : $order->get_billing_email();
			$status     = $order->get_status();
			$status_label = wc_get_order_status_name( $status );
			$can_approve  = ccp_user_can_approve_order( $order );

			$rows[] = array(
				'user_id'     => $order->get_id(),
				'post_date'   => $order->get_date_created() ? $order->get_date_created()->date_i18n( 'F j, Y' ) : '',
				'user_email'  => $user_email,
				'user_status' => $status_label,
				'status_slug' => $status,
				'can_approve' => $can_approve,
			);
		}

		wp_send_json( array( 'data' => $rows ) );
	}

	/**
	 * Render order details HTML for the modal.
	 *
	 * @return void
	 */
	public function get_order_view() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$ctx = $this->get_company_context();
		if ( ! $ctx ) {
			wp_die( esc_html__( 'Unauthorized.', 'woocommerce-wholesale-pricing' ), 403 );
		}

		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$order    = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_die( esc_html__( 'Order not found.', 'woocommerce-wholesale-pricing' ), 404 );
		}

		$order_company = absint( $order->get_meta( '_ccp_company_id' ) );
		if ( empty( $order_company ) ) {
			$order_company = absint( $order->get_meta( 'company_id' ) );
		}
		if ( empty( $order_company ) ) {
			$order_company = absint( get_user_meta( $order->get_user_id(), 'ccp_company_id', true ) );
		}
		if ( (int) $order_company !== (int) $ctx['company_id'] ) {
			wp_die( esc_html__( 'Unauthorized.', 'woocommerce-wholesale-pricing' ), 403 );
		}

		if ( 'ccp_member' === $ctx['role'] && (int) $order->get_user_id() !== get_current_user_id() ) {
			wp_die( esc_html__( 'Unauthorized.', 'woocommerce-wholesale-pricing' ), 403 );
		}

		woocommerce_order_details_table( $order_id );
		wp_die();
	}

	/**
	 * Approve a pending company credit order.
	 *
	 * @return void
	 */
	public function approve_order() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$result   = ccp_approve_company_credit_order( $order_id, get_current_user_id() );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
		}

		wp_send_json_success(
			array(
				'message' => __( 'Order approved.', 'woocommerce-wholesale-pricing' ),
				'status'  => wc_get_order_status_name( 'processing' ),
			)
		);
	}

	/**
	 * Reject a pending company credit order.
	 *
	 * @return void
	 */
	public function reject_order() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$result   = ccp_reject_company_credit_order( $order_id, get_current_user_id() );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 );
		}

		wp_send_json_success(
			array(
				'message' => __( 'Order rejected. Credits restored.', 'woocommerce-wholesale-pricing' ),
				'status'  => wc_get_order_status_name( 'cancelled' ),
			)
		);
	}

	/**
	 * DataTables payload for company credit logs.
	 *
	 * @return void
	 */
	public function get_company_credits() {
		check_ajax_referer( 'ccp_user_security', 'nonce' );

		$ctx = $this->get_company_context();
		if ( ! $ctx ) {
			wp_send_json( array( 'data' => array() ) );
		}

		$post = function_exists( 'ccp_post_data' ) ? ccp_post_data() : array();

		$args = array(
			'post_type'      => 'ccp_credit_logs',
			'posts_per_page' => -1,
			'orderby'        => 'ID',
			'order'          => 'DESC',
			'meta_query'     => array(
				array(
					'key'   => 'company_id',
					'value' => $ctx['company_id'],
				),
			),
		);

		if ( ! empty( $post['start_date'] ) || ! empty( $post['end_date'] ) ) {
			$args['date_query'] = array();
			if ( ! empty( $post['start_date'] ) ) {
				$args['date_query']['after'] = sanitize_text_field( $post['start_date'] );
			}
			if ( ! empty( $post['end_date'] ) ) {
				$args['date_query']['before']    = sanitize_text_field( $post['end_date'] );
				$args['date_query']['inclusive'] = true;
			}
		}

		if ( 'ccp_member' === $ctx['role'] ) {
			$args['meta_query'][] = array(
				'key'   => 'user_id',
				'value' => get_current_user_id(),
			);
		} elseif ( ! empty( $post['ccp_select_user'] ) ) {
			$args['meta_query'][] = array(
				'key'   => 'user_id',
				'value' => absint( $post['ccp_select_user'] ),
			);
		}

		$logs = get_posts( $args );
		$rows = array();

		foreach ( $logs as $log ) {
			$user_id    = absint( get_post_meta( $log->ID, 'user_id', true ) );
			$user_email = get_post_meta( $log->ID, 'user_email', true );
			if ( empty( $user_email ) && $user_id ) {
				$user = get_user_by( 'id', $user_id );
				$user_email = $user ? $user->user_email : '';
			}

			$rows[] = array(
				'ID'         => $log->ID,
				'user_email' => $user_email,
				'amount'     => get_post_meta( $log->ID, 'amount', true ),
				'event'      => get_post_meta( $log->ID, 'event', true ),
				'post_date'  => get_post_meta( $log->ID, 'ccp_date', true ),
			);
		}

		wp_send_json( array( 'data' => $rows ) );
	}
}
