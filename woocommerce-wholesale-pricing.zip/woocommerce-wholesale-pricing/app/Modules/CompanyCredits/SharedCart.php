<?php
/**
 * Classic cart sharing UI and Blocks registration bootstrap.
 *
 * @package WooCommerceWholesalePricing
 */

namespace WooCommerceWholesalePricing\App\Modules\CompanyCredits;

/**
 * Renders Share Cart on classic carts and registers the Blocks integration after WC Blocks loads.
 */
class SharedCart {

	/**
	 * SharedCart constructor.
	 */
	public function __construct() {
		add_action( 'woocommerce_cart_actions', array( $this, 'render_classic_share_button' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'woocommerce_blocks_loaded', array( $this, 'register_blocks_hooks' ) );
	}

	/**
	 * Hook Blocks cart/checkout registration once WooCommerce Blocks is available.
	 *
	 * @return void
	 */
	public function register_blocks_hooks() {
		if ( ! interface_exists( '\Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface' ) ) {
			return;
		}

		add_action( 'woocommerce_blocks_checkout_block_registration', array( $this, 'register_with_blocks' ) );
		add_action( 'woocommerce_blocks_cart_block_registration', array( $this, 'register_with_blocks' ) );
	}

	/**
	 * Register cart-share integration with WooCommerce Blocks.
	 *
	 * @param mixed $registry Integration registry.
	 * @return void
	 */
	public function register_with_blocks( $registry ) {
		if ( ! is_object( $registry ) || ! method_exists( $registry, 'register' ) ) {
			return;
		}

		$registry->register( CartShareBlock::instance() );
	}

	/**
	 * Classic cart "Share cart" button + modal.
	 *
	 * @return void
	 */
	public function render_classic_share_button() {
		if ( ! authentication_role( 'user-shared-carts' ) ) {
			return;
		}

		$users = ccp_get_company_share_users();
		wwp_view(
			'frontend.company-credits.share-cart-button',
			array(
				'users' => $users,
			),
			true
		);
	}

	/**
	 * Enqueue shared-cart frontend assets on cart and company My Account.
	 *
	 * @return void
	 */
	public function enqueue_assets() {
		$on_cart    = function_exists( 'is_cart' ) && is_cart();
		$on_company = function_exists( 'is_account_page' ) && is_account_page()
			&& function_exists( 'is_wc_endpoint_url' )
			&& is_wc_endpoint_url( 
				/**
				 * Filter the company my account slug.
				 *
				 * @since 3.4.0
				 *
				 * @param string $slug The company my account slug.
				 */
				apply_filters( 'ccp_company_my_account_slug', 'company' ) 
			);

		if ( ! $on_cart && ! $on_company ) {
			return;
		}

		if ( $on_cart && ! authentication_role( 'user-shared-carts' ) ) {
			return;
		}

		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style( 'wwp-ccp-frontend' );
		wp_enqueue_script( 'wwp-ccp-frontend' );

		wp_localize_script(
			'wwp-ccp-frontend',
			'wwp_ccp_frontend',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'ccp_user_security' ),
				'users'    => ccp_get_company_share_users(),
				'my_id'    => get_current_user_id(),
				'i18n'     => array(
					'confirmDeleteShared'   => __( 'Are you sure you want to delete this shared cart?', 'woocommerce-wholesale-pricing' ),
					'selectUser'            => __( 'Please select user', 'woocommerce-wholesale-pricing' ),
					'requiredTitle'         => __( 'Required Title', 'woocommerce-wholesale-pricing' ),
					'itemsAdded'            => __( 'Items added to the cart successfully', 'woocommerce-wholesale-pricing' ),
					'orderDetails'          => __( 'Order details', 'woocommerce-wholesale-pricing' ),
					'sharedCartDetails'     => __( 'Shared Carts Detail', 'woocommerce-wholesale-pricing' ),
					'requestSubmitted'      => __( 'Credit request submitted successfully.', 'woocommerce-wholesale-pricing' ),
					'requestFailed'         => __( 'Request failed.', 'woocommerce-wholesale-pricing' ),
					'confirmDeclineRequest' => __( 'Decline this credit request?', 'woocommerce-wholesale-pricing' ),
					'confirmRejectOrder'    => __( 'Reject this order? Credits will be restored to the buyer.', 'woocommerce-wholesale-pricing' ),
					'view'                  => __( 'View', 'woocommerce-wholesale-pricing' ),
					'approve'               => __( 'Approve', 'woocommerce-wholesale-pricing' ),
					'reject'                => __( 'Reject', 'woocommerce-wholesale-pricing' ),
					'addNewUser'            => __( 'Add New User', 'woocommerce-wholesale-pricing' ),
					'editUser'              => __( 'Edit User', 'woocommerce-wholesale-pricing' ),
					'edit'                  => __( 'Edit', 'woocommerce-wholesale-pricing' ),
					'remove'                => __( 'Remove', 'woocommerce-wholesale-pricing' ),
					'confirmRemoveMember'   => __( 'Remove this member from the company?', 'woocommerce-wholesale-pricing' ),
					'firstNameRequired'     => __( 'First name is required.', 'woocommerce-wholesale-pricing' ),
					'lastNameRequired'      => __( 'Last name is required.', 'woocommerce-wholesale-pricing' ),
					'usernameRequired'      => __( 'Username is required.', 'woocommerce-wholesale-pricing' ),
					'emailRequired'         => __( 'Email address is required.', 'woocommerce-wholesale-pricing' ),
					'userAdded'             => __( 'User added successfully.', 'woocommerce-wholesale-pricing' ),
					'userUpdated'           => __( 'User updated successfully.', 'woocommerce-wholesale-pricing' ),
				),
				'company_id' => absint( get_user_meta( get_current_user_id(), 'ccp_company_id', true ) ),
			)
		);

		wp_add_inline_script(
			'wwp-ccp-frontend',
			'window.admin_ccp_script = window.wwp_ccp_frontend;',
			'before'
		);
	}
}
