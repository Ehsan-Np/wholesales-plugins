<?php
/**
 * Product Table Admin Screen Class
 *
 * This file defines the Product Table class, rendering of the "Product Table" admin screen in the WooCommerce Wholesale Pricing plugin.
 * It extends the WholesaleMenu base class and integrates with plugin settings.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Product Table
 *
 * Represents the admin screen for managing Product Table.
 * This class registers the menu item, adds settings, and renders
 * the associated view.
 */
class ProductTable extends WholesaleMenu {

	use WholesaleSettings;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability  = wwp_env()->get('capability') . '_product_table';

		$this->menu_slug  = 'edit.php?post_type=' . wwp_env()->get('product_table_slug');

		$this->needs_callback = false;

		parent::__construct();

		add_filter( 'parent_file', array( $this, 'set_wholesale_parent_menu' ), 11 );
		add_filter( 'submenu_file', array( $this, 'set_product_table_submenu' ), 11 );
		add_action( 'admin_footer', array( $this, 'wholesale_menu_active' ) );

		add_action('admin_menu', array( $this, 'conditonal_menu' ), 999);

		add_filter( 'display_post_states', array( $this, 'product_table_page_identifier' ), 10, 2);

		add_action('views_edit-' . wwp_env()->get('product_table_slug'), array( $this, 'import_button' ) );
	}


	/**
	 * Retrieves the page title for the Product Table admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Product Table', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Product Table admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('Product Table', 'woocommerce-wholesale-pricing');
	}

	public function conditonal_menu() {
		$settings = self::get_pricing_settings();
		if (! isset($settings['product_table']) || 'no' == $settings['product_table'] ) {
			global $submenu;

			if (isset($submenu['wwp_wholesale']) ) {
				foreach ( $submenu['wwp_wholesale'] as $index => &$item ) {
					if ('manage_wholesale_product_table' === $item[1] ) {
						unset($submenu['wwp_wholesale'][$index]);
					}
				}
			}
		}
	}

	/**
	 * Whether the current admin screen belongs to the product table post type.
	 *
	 * @param \WP_Screen|null $screen Current admin screen.
	 * @return bool
	 */
	private function is_product_table_admin_screen( $screen ) {
		if ( ! $screen ) {
			return false;
		}

		$post_type = wwp_env()->get( 'product_table_slug' );

		return $post_type === $screen->post_type
			|| in_array( $screen->id, array( 'edit-' . $post_type, $post_type ), true );
	}

	/**
	 * Keep the Wholesale top-level menu highlighted on product table screens.
	 *
	 * @param string $parent_file Parent menu file slug.
	 * @return string
	 */
	public function set_wholesale_parent_menu( $parent_file ) {
		if ( $this->is_product_table_admin_screen( get_current_screen() ) ) {
			return wwp_env()->get( 'menu_slug' );
		}

		return $parent_file;
	}

	/**
	 * Keep the Product Table submenu item highlighted on product table screens.
	 *
	 * @param string $submenu_file Submenu file slug.
	 * @return string
	 */
	public function set_product_table_submenu( $submenu_file ) {
		if ( $this->is_product_table_admin_screen( get_current_screen() ) ) {
			return $this->menu_slug;
		}

		return $submenu_file;
	}

	/**
	 * Ensure the Wholesale menu stays expanded and active in the sidebar.
	 *
	 * @return void
	 */
	public function wholesale_menu_active() {
		if ( ! $this->is_product_table_admin_screen( get_current_screen() ) ) {
			return;
		}

		$menu_slug  = wwp_env()->get( 'menu_slug' );
		$post_type  = wwp_env()->get( 'product_table_slug' );
		$menu_id    = 'toplevel_page_' . $menu_slug;
		?>
		<style>
			#<?php echo esc_attr( $menu_id ); ?>.wp-has-current-submenu > a {
				background-color: #2271b1 !important;
				color: #fff !important;
			}
			#<?php echo esc_attr( $menu_id ); ?>.wp-menu-open .wp-submenu {
				display: block !important;
			}
		</style>

		<script type="text/javascript">
			(function($) {
				$(function() {
					var $wholesaleMenu = $('#<?php echo esc_js( $menu_id ); ?>');

					if (!$wholesaleMenu.length) {
						return;
					}

					$('.wp-has-current-submenu, .wp-menu-open')
						.not($wholesaleMenu)
						.removeClass('wp-has-current-submenu wp-menu-open')
						.addClass('wp-not-current-submenu');

					$wholesaleMenu
						.removeClass('wp-not-current-submenu')
						.addClass('wp-has-current-submenu wp-menu-open opensub');

					$wholesaleMenu.find('a[href*="post_type=<?php echo esc_js( $post_type ); ?>"]')
						.addClass('current')
						.parent('li').addClass('current');
				});
			})(jQuery);
		</script>
		<?php
	}
	 
	/**
	 * Render
	 *
	 * @return string Rendered HTML output.
	 */
	public function render() {}

	public function product_table_page_identifier( $post_states, $post ) {
		if (( has_shortcode( $post->post_content, 'wc_products_table' ) || has_block( 'product-table/wcpt-product-table' ) ) && 'page' == $post->post_type ) {
			$post_states['wwp_product_table_page'] = __('Product Table', 'woocommerce-wholesale-pricing');
		}

		return $post_states;
	}

	/**
	 * Output the import button on the list table screen.
	 *
	 * @param string[] $views Status view links for the list table.
	 * @return string[]
	 */
	public function import_button( $views ) {
		wwp_view('admin.product-table.import');

		return $views;
	}
}
