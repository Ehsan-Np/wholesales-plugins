<?php
/**
 * Dynamic Rules Admin Screen Class
 *
 * Registers the Dynamic Rules submenu under Wholesale and keeps the
 * Wholesale menu highlighted on dynamic_rules screens.
 *
 * @package WooCommerceWholesalePricing\App\Admin\Screens
 */

namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class DynamicRules
 *
 * Link-only submenu pointing at edit.php?post_type=dynamic_rules.
 */
class DynamicRules extends WholesaleMenu {

	/**
	 * Constructor.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->capability     = wwp_env()->get( 'capability' );
		$this->menu_slug      = 'edit.php?post_type=' . wwp_env()->get( 'dynamic_rules_slug' );
		$this->needs_callback = false;

		parent::__construct();

		add_filter( 'parent_file', array( $this, 'set_wholesale_parent_menu' ), 11 );
		add_filter( 'submenu_file', array( $this, 'set_dynamic_rules_submenu' ), 11 );
		add_action( 'admin_footer', array( $this, 'wholesale_menu_active' ) );
	}

	/**
	 * Page title.
	 *
	 * @return string
	 */
	public function get_page_title() {
		/**
		 * Filter Dynamic Rules page title.
		 *
		 * @since 3.2.0
		 * @param string $title Page title.
		 */
		return apply_filters( 'wwp_wholsale_dynamic_rules_title', __( 'Dynamic Rules', 'woocommerce-wholesale-pricing' ) );
	}

	/**
	 * Menu title.
	 *
	 * @return string
	 */
	public function get_menu_title() {
		/**
		 * Filter Dynamic Rules menu title.
		 *
		 * @since 3.2.0
		 * @param string $title Menu title.
		 */
		return apply_filters( 'wwp_wholsale_dynamic_rules_title', __( 'Dynamic Rules', 'woocommerce-wholesale-pricing' ) );
	}

	/**
	 * Whether the current screen belongs to dynamic_rules.
	 *
	 * @param \WP_Screen|null $screen Current screen.
	 * @return bool
	 */
	private function is_dynamic_rules_admin_screen( $screen ) {
		if ( ! $screen ) {
			return false;
		}

		$post_type = wwp_env()->get( 'dynamic_rules_slug' );

		return $post_type === $screen->post_type
			|| in_array( $screen->id, array( 'edit-' . $post_type, $post_type ), true );
	}

	/**
	 * Keep Wholesale top-level menu highlighted.
	 *
	 * @param string $parent_file Parent menu file.
	 * @return string
	 */
	public function set_wholesale_parent_menu( $parent_file ) {
		if ( $this->is_dynamic_rules_admin_screen( get_current_screen() ) ) {
			return wwp_env()->get( 'menu_slug' );
		}

		return $parent_file;
	}

	/**
	 * Keep Dynamic Rules submenu highlighted.
	 *
	 * @param string $submenu_file Submenu file.
	 * @return string
	 */
	public function set_dynamic_rules_submenu( $submenu_file ) {
		if ( $this->is_dynamic_rules_admin_screen( get_current_screen() ) ) {
			return $this->menu_slug;
		}

		return $submenu_file;
	}

	/**
	 * Ensure Wholesale menu stays expanded on dynamic_rules screens.
	 *
	 * @return void
	 */
	public function wholesale_menu_active() {
		if ( ! $this->is_dynamic_rules_admin_screen( get_current_screen() ) ) {
			return;
		}

		$menu_slug = wwp_env()->get( 'menu_slug' );
		$post_type = wwp_env()->get( 'dynamic_rules_slug' );
		$menu_id   = 'toplevel_page_' . $menu_slug;
		?>
		<style>
			#<?php echo esc_attr( $menu_id ); ?>.wp-has-current-submenu > a {
				background-color: #2271b1 !important;
				color: #fff !important;
			}
			#<?php echo esc_attr( $menu_id ); ?>.wp-menu-open .wp-submenu {
				display: block !important;
			}
		</style>
		<script type="text/javascript">
			(function($) {
				$(function() {
					var $wholesaleMenu = $('#<?php echo esc_js( $menu_id ); ?>');

					if (!$wholesaleMenu.length) {
						return;
					}

					$('.wp-has-current-submenu, .wp-menu-open')
						.not($wholesaleMenu)
						.removeClass('wp-has-current-submenu wp-menu-open')
						.addClass('wp-not-current-submenu');

					$wholesaleMenu
						.removeClass('wp-not-current-submenu')
						.addClass('wp-has-current-submenu wp-menu-open opensub');

					$wholesaleMenu.find('a[href*="post_type=<?php echo esc_js( $post_type ); ?>"]')
						.addClass('current')
						.parent('li').addClass('current');
				});
			})(jQuery);
		</script>
		<?php
	}

	/**
	 * Render (unused for link-only submenu).
	 *
	 * @return void
	 */
	public function render() {}
}
