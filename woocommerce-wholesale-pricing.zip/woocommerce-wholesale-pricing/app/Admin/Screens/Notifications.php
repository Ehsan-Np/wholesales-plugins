<?php
/**
 * Notifications Admin Screen Class
 *
 * This file defines the Notifications class, which handles the registration
 * and rendering of the "Notifications" admin screen in the WooCommerce Wholesale Pricing plugin.
 * It extends the WholesaleMenu base class and integrates with plugin settings.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Notifications
 *
 * Represents the admin screen for managing wholesale-related notifications.
 * This class registers the menu item, adds settings registration, and renders
 * the associated view.
 */
class Notifications extends WholesaleMenu {

	use WholesaleSettings;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->menu_slug   = wwp_env()->get('menu_slug') . '_notifcations';
		$this->capability  = wwp_env()->get('capability') . '_notifications';

		parent::__construct();

		add_action('admin_init', array( $this, 'register_setting_fields' ));
	}

	/**
	 * Retrieves the page title for the Notifications admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Notifications', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Notifications admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('Notifications', 'woocommerce-wholesale-pricing');
	}
	 
	/**
	 * Render
	 *
	 * @return string Rendered HTML output.
	 */
	public function render() {
		return wwp_view('admin.menus.notifications');
	}
	
	/**
	 * Register_setting_fields
	 *
	 * @return void
	 */
	public function register_setting_fields() {
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_admin_request_notification');
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_stop_admin_notification');
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_send_notification_email_other');
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_admin_request_subject');
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_admin_request_recipient');
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_admin_request_body');
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_request_approve_notification');
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_email_request_subject');
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_email_request_body');

		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_user_registration_notification');
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_registration_notification_subject');
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_registration_notification_body');

		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_user_rejection_notification');
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_rejection_notification_subject');
		register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_rejection_notification_body');
		register_setting('wwp_wholesale_request_notifications', 'wc_quote_email');

		/**
		* Version 1.3.0 For Subscriptions User Role Update Notification
		*
		* @since 1.3.0
		*/
		if (wwp_is_subscription_active() ) {
			register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_subscription_role_notification');
			register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_subscription_role_subject');
			register_setting('wwp_wholesale_request_notifications', 'wwp_wholesale_subscription_role_body');
		}
		// ends version 1.3.0
		$settings = self::get_pricing_settings();

		if (isset($settings['upgrade_btn_label']) && ! empty($settings['upgrade_btn_label']) ) {

			$settings['upgrade_tab_text']  = $settings['upgrade_btn_label'];
			$settings['upgrade_btn_label'] = '';

			self::update_pricing_settings($settings);
		}
	}
}
