<?php
/**
 * Dashboard Admin Screen Class
 *
 * This file defines the Dashboard class, which manages the "Dashboard" screen
 * in the WooCommerce Wholesale Pricing plugin's admin interface. It sets up the
 * menu item, permissions, and dashboard-specific hooks for reporting, user requests,
 * recent orders, and AJAX functionality.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Dashboard
 *
 * Handles the admin dashboard screen for the Wholesale for WooCommerce plugin.
 * This class registers the menu page and attaches action hooks for displaying various
 * dashboard widgets and processing AJAX requests.
 */
class Dashboard extends WholesaleMenu {

		
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->menu_slug   = wwp_env()->get('menu_slug');
		$this->capability  = wwp_env()->get('capability') . '_reports';

		parent::__construct();
	}

	/**
	 * Retrieves the page title for the Dashboard admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Wholesale For WooCommerce', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Dashboard admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('Dashboard', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Render
	 *
	 * @return string Rendered HTML output.
	 */
	public function render() {
		return wwp_view('admin.menus.dashboard');
	}
}
