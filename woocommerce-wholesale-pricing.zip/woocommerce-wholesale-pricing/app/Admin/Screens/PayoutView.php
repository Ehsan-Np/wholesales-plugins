<?php
/**
 * Sales Agent Payout View Admin Screen Class
 *
 * This file defines the Sales Agent Payout View class, rendering of the "Sales Agent Payout View" admin screen in the WooCommerce Wholesale Pricing plugin.
 * It extends the WholesaleMenu base class and integrates with plugin settings.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Sales Agent Payout View
 *
 * Represents the admin screen for managing Sales Agent Payout View.
 * This class registers the menu item, adds settings, and renders
 * the associated view.
 */
class PayoutView extends WholesaleMenu {

	use WholesaleSettings;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability  = wwp_env()->get('capability') . '_sales_agent';

		$this->menu_slug  = wwp_env()->get('payout_view_page_slug');
		parent::__construct();

		add_action('admin_menu', array( $this, 'conditonal_menu' ), 999);
		add_filter('submenu_file', array( $this, 'submenuMenu' ), 11);
		add_action('admin_footer', array( $this, 'wholesale_menu_active' ));
	}


	/**
	 * Retrieves the page title for the Sales Agent admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return '';
	}

	/**
	 * Retrieves the menu title for the Sales Agent admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return '';
	}

	public function conditonal_menu() {
		$settings = self::get_pricing_settings();
		if (! isset($settings['sales_agent']) || 'no' == $settings['sales_agent'] ) {
			global $submenu;

			if (isset($submenu['wwp_wholesale']) ) {
				foreach ( $submenu['wwp_wholesale'] as $index => &$item ) {
					if ('manage_wholesale_sales_agent' === $item[1] ) {
						unset($submenu['wwp_wholesale'][$index]);
					}
				}
			}
		}
	}

	/**
	 * Keep the Wholesale parent menu active on the payout view screen.
	 *
	 * @param string $parent_file Parent menu slug.
	 * @return string
	 */
	public function parentMenu( $parent_file ) {
		if ( $this->is_payout_view_screen() ) {
			return wwp_env()->get( 'menu_slug' );
		}

		return $parent_file;
	}

	/**
	 * Highlight the Payout submenu while viewing a single agent payout.
	 *
	 * @param string $submenu_file Active submenu slug.
	 * @return string
	 */
	public function submenuMenu( $submenu_file ) {
		if ( $this->is_payout_view_screen() ) {
			return wwp_env()->get( 'payout_page_slug' );
		}

		return $submenu_file;
	}

	/**
	 * Ensure the Wholesale menu stays expanded with Payout highlighted.
	 *
	 * @return void
	 */
	public function wholesale_menu_active() {
		if ( ! $this->is_payout_view_screen() ) {
			return;
		}

		$menu_slug       = wwp_env()->get( 'menu_slug' );
		$payout_page     = wwp_env()->get( 'payout_page_slug' );
		$payout_view_page = wwp_env()->get( 'payout_view_page_slug' );
		?>
		<style>
			#toplevel_page_<?php echo esc_attr( $menu_slug ); ?>.wp-has-current-submenu > a {
				background-color: #2271b1 !important;
				color: #fff !important;
			}
			#toplevel_page_<?php echo esc_attr( $menu_slug ); ?>.wp-menu-open .wp-submenu {
				display: block !important;
			}
		</style>

		<script type="text/javascript">
			(function($) {
				$(function() {
					var $wholesaleMenu = $('#toplevel_page_<?php echo esc_js( $menu_slug ); ?>');

					if (!$wholesaleMenu.length) {
						return;
					}

					$('.wp-has-current-submenu, .wp-menu-open')
						.not($wholesaleMenu)
						.removeClass('wp-has-current-submenu wp-menu-open')
						.addClass('wp-not-current-submenu');

					$wholesaleMenu
						.removeClass('wp-not-current-submenu')
						.addClass('wp-has-current-submenu wp-menu-open opensub');

					$wholesaleMenu.find('.wp-submenu a')
						.removeClass('current')
						.parent('li')
						.removeClass('current');

					var payoutPage = <?php echo wp_json_encode( $payout_page ); ?>;
					var payoutViewPage = <?php echo wp_json_encode( $payout_view_page ); ?>;
					var $activeLink = $wholesaleMenu.find('.wp-submenu a').filter(function() {
						var href = $(this).attr('href') || '';

						return href.indexOf('page=' + payoutPage) !== -1
							&& href.indexOf('page=' + payoutViewPage) === -1;
					}).first();

					$activeLink
						.addClass('current')
						.parent('li')
						.addClass('current');
				});
			})(jQuery);
		</script>
		<?php
	}

	/**
	 * Whether the current admin screen is the payout view page.
	 *
	 * @return bool
	 */
	private function is_payout_view_screen() {
		if ( isset( $_GET['page'] ) && wwp_env()->get( 'payout_view_page_slug' ) === sanitize_text_field( wp_unslash( $_GET['page'] ) ) ) {
			return true;
		}

		$screen = get_current_screen();

		if ( ! $screen ) {
			return false;
		}

		return 'wholesale_page_' . wwp_env()->get( 'payout_view_page_slug' ) === $screen->id;
	}
	 
	/**
	 * Render
	 *
	 * @return string Rendered HTML output.
	 */
	public function render() {
		if ( isset( $_REQUEST['agent_id'] ) && ! empty( $_REQUEST['agent_id'] ) ) {

			/**
			* Filter.
			*
			* @since 1.0.4
			*/
			do_action( 'before_edit_form_of_payout' );
			wwp_view( 'admin.menus.payout-view' );

			/**
			* Filter.
			*
			* @since 1.0.4
			*/
			do_action( 'after_edit_form_of_payout' );
		}
	}
}
