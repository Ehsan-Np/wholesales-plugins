<?php
/**
 * UserRoles Admin Screen Class
 *
 * This file defines the UserRoles class, which manages the admin interface
 * for handling wholesale user roles taxonomy in the WooCommerce Wholesale Pricing plugin.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class UserRoles
 *
 * Registers the admin screen for managing wholesale user roles taxonomy.
 * The screen appears as a taxonomy management page within the admin.
 */
class UserRoles extends WholesaleMenu {


	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability   = wwp_env()->get('capability') . '_user_role';
		$this->menu_slug  = 'edit-tags.php?taxonomy=wholesale_user_roles';

		$this->needs_callback = false;

		parent::__construct();
	}

	/**
	 * Retrieves the page title for the UserRoles admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('User Roles', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the UserRoles admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('User Roles', 'woocommerce-wholesale-pricing');
	}
	
	/**
	 * Render
	 *
	 * @return void
	 */
	public function render() {
	}
}
