<?php
/**
 * BulkPricing Admin Screen Class
 *
 * This file defines the BulkPricing class, which handles the registration and rendering
 * of the "Bulk Wholesale Pricing" admin screen in the WooCommerce Wholesale Pricing plugin.
 * It extends the WholesaleMenu base class to integrate with the plugin's admin menu system.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;
use WooCommerceWholesalePricing\App\Modules\BulkWholesalePricing\Handler as BulkWholesalePricing;

/**
 * Class BulkPricing
 *
 * Represents the admin screen for managing bulk wholesale pricing.
 * This class sets up the admin page under the WooCommerce Wholesale Pricing menu
 * and delegates rendering to the BulkWholesalePricing handler.
 */
class BulkPricing extends WholesaleMenu {


	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability   = wwp_env()->get('capability') . '_bulk_ricing';
		$this->menu_slug  = 'wwp-bulk-wholesale-pricing';

		parent::__construct();
	}

	/**
	 * Retrieves the page title for the Bulk Wholesale Pricing admin page.
	 *
	 * This title is displayed at the top of the admin screen and
	 * can be modified using the 'wwp_wholsale_Bulk_title' filter.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		/**
		 * Filter bulk pricing
		 * 
		 * @since 2.0.0
		 */
		return apply_filters('wwp_wholsale_Bulk_title', __('Bulk Wholesale Pricing', 'woocommerce-wholesale-pricing'));
	}

	/**
	 * Retrieves the menu title for the Bulk Wholesale Pricing admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu and
	 * can be modified using the 'wwp_wholsale_Bulk_title' filter.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		/**
		 * Filter bulk pricing
		 * 
		 * @since 2.0.0
		 */
		return apply_filters('wwp_wholsale_Bulk_title', __('Bulk Wholesale Pricing', 'woocommerce-wholesale-pricing'));
	}
	
	/**
	 * Render the Bulk Wholesale Pricing admin page.
	 *
	 * @return void
	 */
	public function render() {
		BulkWholesalePricing::render();
	}
}
