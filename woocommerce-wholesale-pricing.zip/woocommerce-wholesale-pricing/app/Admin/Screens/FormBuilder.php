<?php
/**
 * Form Builder Admin Screen Class
 *
 * This file defines the Form Builder class, which registers the "Form Builder" screen
 * in the WooCommerce Wholesale Pricing plugin. It integrates with the admin
 * menu and is intended to provide functionality for building custom forms.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Form Builder
 *
 * Represents the admin screen for building custom forms.
 * This class adds the "Form Builder" submenu under the Wholesale Menu.
 */
class FormBuilder extends WholesaleMenu {


	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability   = 'manage_options';
		$this->menu_slug  = 'wwp-registration-setting&tab=quote-form-builder';

		parent::__construct();
	}

	/**
	 * Retrieves the page title for the Export admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Form Builder', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Export admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('Form Builder', 'woocommerce-wholesale-pricing');
	}
	
	/**
	 * Render
	 *
	 * @return void
	 */
	public function render() {
	}
}
