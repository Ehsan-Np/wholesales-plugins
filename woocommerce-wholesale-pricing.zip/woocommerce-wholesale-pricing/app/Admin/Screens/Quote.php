<?php
/**
 * Quote Admin Screen Class
 *
 * This file defines the Quote class, which handles the registration
 * and rendering of the "Quote" admin screen in the WooCommerce Wholesale Pricing plugin.
 * It extends the WholesaleMenu base class and integrates with plugin settings.
 *
 * @package    WooCommerceWholesalePricing\Screens
 */
namespace WooCommerceWholesalePricing\App\Admin\Screens;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\WholesaleMenu;

/**
 * Class Quote
 *
 * Represents the admin screen for managing Quote rules and lists.
 * This class registers the menu item, adds settings, and renders
 * the associated view.
 */
class Quote extends WholesaleMenu {

	use WholesaleSettings;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$this->capability  = wwp_env()->get('capability') . '_quotes';

		$this->menu_slug  = 'edit.php?post_type=wc-quote-rules';

		$this->needs_callback = false;

		parent::__construct();

		add_action('admin_menu', array( $this, 'conditonal_menu' ), 999);

		add_action('admin_footer', array( $this, 'wholesale_menu_active' ));

		add_action( 'all_admin_notices', array( $this, 'wwp_add_custom_buttons_to_views' ) );

		add_filter('display_post_states', array( $this, 'quote_page_identifier' ), 10, 2);
		add_action( 'delete_post', array( $this, 'delete_quote_page_option' ), 10 );
	}

	public function wwp_add_custom_buttons_to_views() {
		global $current_screen;

		if ( ! $current_screen || ! in_array( $current_screen->id, array( 'edit-wc-quote-rules', 'wc-quote-rules', 'wc-quote', 'edit-wc-quote' ) ) ) {
			return;
		}

		wwp_view('admin.quote.rules.meta-buttons', compact('current_screen'));
	}

	/**
	 * Retrieves the page title for the Quote admin page.
	 *
	 * This title is displayed at the top of the admin screen.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered page title.
	 */
	public function get_page_title() {
		return __('Quote', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Retrieves the menu title for the Quote admin menu item.
	 *
	 * This title is displayed in the WordPress admin sidebar menu.
	 *
	 * @since 3.0.0
	 *
	 * @return string The localized and filtered menu title.
	 */
	public function get_menu_title() {
		return __('Quote', 'woocommerce-wholesale-pricing');
	}

	public function conditonal_menu() {
		$settings = self::get_pricing_settings();
		if (! isset($settings['enable_quote']) || 'no' == $settings['enable_quote'] ) {
			global $submenu;

			if (isset($submenu['wwp_wholesale']) ) {
				foreach ( $submenu['wwp_wholesale'] as $index => &$item ) {
					if ('manage_wholesale_quotes' === $item[1] ) {
						unset($submenu['wwp_wholesale'][$index]);
					}
				}
			}
		}
	}

	public function wholesale_menu_active( $submenu_file ) {
		$screen = get_current_screen();

		if ( ! $screen || ! in_array( $screen->id, array( 'edit-wc-quote-rules', 'wc-quote-rules', 'wc-quote', 'edit-wc-quote' ) ) ) {
			return;
		}
		?>
		<style>
			#toplevel_page_wwp_wholesale.wp-has-current-submenu > a {
				background-color: #2271b1 !important;
				color: #fff !important;
			}
			#toplevel_page_wwp_wholesale.wp-menu-open .wp-submenu {
				display: block !important;
			}
		</style>

		<script type="text/javascript">
			(function($) {
				$(function() {
					var $wholesaleMenu = $('#toplevel_page_wwp_wholesale');

					if ($wholesaleMenu.length) {
						$('.wp-has-current-submenu, .wp-menu-open')
							.not($wholesaleMenu)
							.removeClass('wp-has-current-submenu wp-menu-open')
							.addClass('wp-not-current-submenu');

						$wholesaleMenu
							.removeClass('wp-not-current-submenu')
							.addClass('wp-has-current-submenu wp-menu-open opensub');
						
						$wholesaleMenu.find('a[href*="post_type=wc-quote-rules"]')
							.addClass('current')
							.parent('li').addClass('current');
					}
				});
			})(jQuery);
		</script>
		<?php
	}
	 
	/**
	 * Render
	 *
	 * @return string Rendered HTML output.
	 */
	public function render() {}

	public function quote_page_identifier( $post_states, $post ) {

		$quote_general  = self::get_quote_general_settings();
		$page_id = isset( $quote_general['quote_page'] ) ? $quote_general['quote_page'] : '';

		if ($page_id == $post->ID && 'page' == $post->post_type ) {
			$post_states['wwp_quote_page'] = __('Request a Quote Page', 'woocommerce-wholesale-pricing');
		}

		return $post_states;
	}

	public function delete_quote_page_option( $post_id ) {
		$quote_general  = self::get_quote_general_settings();

		if (isset( $quote_general['quote_page'] ) && $quote_general['quote_page'] == $post_id) {
			$quote_general['quote_page'] = '';
			self::update_quote_general_settings($quote_general);
		}
	}
}
