<?php
/**
 * Creates the AI Assistant change history table.
 *
 * @package WooCommerceWholesalePricing\App\Migrations
 */

namespace WooCommerceWholesalePricing\App\Migrations;

use WooCommerceWholesalePricing\App\Providers\WholesaleOption;

/**
 * Ensures the wwp_ai_change_history table exists on plugin update or activation.
 */
class AIAssistantHistoryTableMigration {

	const MIGRATED_OPTION = 'wwp_ai_history_table_migrated';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'migrate' ), 250 );
	}

	/**
	 * Run migration once.
	 *
	 * @return void
	 */
	public function migrate() {
		if ( 'yes' === get_option( self::MIGRATED_OPTION ) ) {
			return;
		}

		self::create_table();
		update_option( self::MIGRATED_OPTION, 'yes' );
	}

	/**
	 * Create or update the change history table via dbDelta.
	 *
	 * @return void
	 */
	public static function create_table() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table_name      = $wpdb->prefix . WholesaleOption::AI_CHANGE_HISTORY_TABLE;
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table_name} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			tool varchar(100) NOT NULL DEFAULT '',
			change_description text NOT NULL,
			status tinyint(1) NOT NULL DEFAULT 1,
			action_type varchar(20) NOT NULL DEFAULT '',
			resource_type varchar(50) NOT NULL DEFAULT '',
			resource longtext NOT NULL,
			before_state longtext NULL,
			prompt text NULL,
			ability varchar(50) NULL,
			model varchar(100) NULL,
			undone_at datetime NULL,
			undone_by bigint(20) unsigned NULL,
			PRIMARY KEY  (id),
			KEY user_id (user_id),
			KEY status (status),
			KEY created_at (created_at)
		) {$charset_collate};";

		dbDelta( $sql );
	}
}
