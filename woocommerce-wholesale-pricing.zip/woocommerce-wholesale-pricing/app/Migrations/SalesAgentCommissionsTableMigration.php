<?php
/**
 * Creates the sales agent commissions table.
 *
 * @package WooCommerceWholesalePricing\App\Migrations
 */

namespace WooCommerceWholesalePricing\App\Migrations;

use WooCommerceWholesalePricing\App\Providers\WholesaleOption;

/**
 * Ensures the wc_agents_commissions table exists on plugin update or activation.
 */
class SalesAgentCommissionsTableMigration {

	const MIGRATED_OPTION = 'wwp_sales_agent_commissions_table_migrated';

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'init', array( $this, 'migrate' ), 250 );
	}

	/**
	 * Run migration once.
	 *
	 * @return void
	 */
	public function migrate() {
		if ( 'yes' === get_option( self::MIGRATED_OPTION ) ) {
			return;
		}

		self::create_table();
		update_option( self::MIGRATED_OPTION, 'yes' );
	}

	/**
	 * Create or update the commissions table via dbDelta.
	 *
	 * @return void
	 */
	public static function create_table() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table_name      = $wpdb->prefix . WholesaleOption::AGENTS_COMMISSIONS_TABLE;
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table_name} (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			agent_id varchar(255) NOT NULL,
			order_id varchar(255) NOT NULL,
			commission_type varchar(255) NOT NULL DEFAULT 'percentage',
			commission_percentage varchar(255) NOT NULL,
			commission_value varchar(255) NOT NULL,
			commission_status varchar(255) NOT NULL DEFAULT 'pending',
			create_date datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
			PRIMARY KEY  (id)
		) {$charset_collate};";

		dbDelta( $sql );
	}
}
