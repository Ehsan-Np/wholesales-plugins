<?php

namespace WooCommerceWholesalePricing\App\Migrations;

class RegistrationUserDataMigration {

	public function __construct() {
		add_action( 'wwp_migrate_user_data_batch', array( $this, 'migrate_data_batch' ) );
		add_action( 'init', array( $this, 'maybe_schedule_migration' ), 250 );
	}

	/**
	 * Maybe schedule the migration.
	 * 
	 * @return void
	 */
	public function maybe_schedule_migration() {
		$db_version = get_option( 'wwp_wholesale_version', '1.0.0' );

		if ( version_compare( $db_version, WWP_VERSION, '<' ) ) {
			if ( function_exists( 'as_next_scheduled_action' ) && ! as_next_scheduled_action( 'wwp_migrate_user_data_batch' ) ) {
				as_enqueue_async_action( 'wwp_migrate_user_data_batch' );
			}
		}
	}

	public function migrate_data_batch() {
		// Ensure fields are migrated first
		RegistrationFieldsMigration::migrate();

		$processed_anything = false;

		$users = get_users(
			array(
				'meta_key' => 'wwp_form_data_json',
				'number'   => 100,
				'fields'   => 'ID',
			)
		);

		if ( ! empty( $users ) ) {
			$count = 0;
			foreach ( $users as $user_id ) {
				if ( get_user_meta( $user_id, '_wwp_migration_v2_done', true ) === 'yes' ) {
					continue;
				}
				$this->migrate_entity_meta( $user_id, 'user' );
				$processed_anything = true;
				$count++;

				if ( $count >= 50 ) {
					break;
				}
			}
		}

		$orders = wc_get_orders(
			array(
				'limit'    => 100,
				'meta_key' => 'wwp_form_data_json',
			)
		);

		if ( ! empty( $orders ) ) {
			$order_count = 0;
			foreach ( $orders as $order ) {

				if ( $order->get_meta( '_wwp_migration_v2_done' ) === 'yes' ) {
					continue;
				}

				$this->migrate_entity_meta( $order, 'order' );
				$processed_anything = true;
				$order_count++;

				if ( $order_count >= 50 ) {
					break;
				}
			}
		}

		if ( ! $processed_anything ) {
			wc_get_logger()->info( 'Migration Complete: No more records to process.', array( 'source' => 'wwp-migration' ) );
			return;
		}

		// RESCHEDULE: Run the next batch
		as_enqueue_async_action( 'wwp_migrate_user_data_batch' );
	}

	/**
	 * Helper to migrate meta for either User or Order
	 */
	private function migrate_entity_meta( $entity, $type ) {
		$old_json = ( 'user' === $type )
			? get_user_meta( $entity, 'wwp_form_data_json', true )
			: $entity->get_meta( 'wwp_form_data_json' );

		if ( 'user' === $type ) {
			update_user_meta( $entity, 'wwp_form_data_json_legacy', $old_json );
		} else {
			$entity->update_meta_data( 'wwp_form_data_json_legacy', $old_json );
		}

		// If the data is already an array, it might be partially migrated or formatted incorrectly
		if ( empty( $old_json ) || is_array( $old_json ) ) {
			$this->mark_as_done( $entity, $type );
			// Persist the done flag for orders; without save() the meta only
			// changes in memory and the same order is re-processed forever.
			if ( 'user' !== $type ) {
				$entity->save();
			}
			return;
		}

		$flat_data = $this->transform_to_flat( $old_json );

		if ( ! empty( $flat_data ) ) {
			// CRITICAL: Overwrite the key that the frontend renderer uses
			if ( 'user' === $type ) {
				update_user_meta( $entity, 'wwp_form_data_json', $flat_data );
			} else {
				$entity->update_meta_data( 'wwp_form_data_json', wp_json_encode( $flat_data ) );
			}
		}

		$this->mark_as_done( $entity, $type );
		if ( 'user' !== $type ) {
			$entity->save();
		}
	}

	private function mark_as_done( &$entity, $type ) {
		if ( 'user' === $type ) {
			update_user_meta( $entity, '_wwp_migration_v2_done', 'yes' );
		} else {
			$entity->update_meta_data( '_wwp_migration_v2_done', 'yes' );
		}
	}

	private function transform_to_flat( $json ) {
		$data = json_decode( stripslashes( $json ), true );
		if ( ! is_array( $data ) ) {
			return array();
		}

		$flattened = array();
		foreach ( $data as $field ) {
			if ( isset( $field['name'], $field['userData'] ) ) {
				$val = $field['userData'];
				// Normalize: if it's an array with 1 item, extract it.
				$flattened[ $field['name'] ] = ( is_array( $val ) && count( $val ) === 1 ) ? $val[0] : $val;
			}
		}
		return $flattened;
	}
}
