<?php

namespace WooCommerceWholesalePricing\App\Migrations;

use WooCommerceWholesalePricing\App\Providers\WholesaleOption;

/**
 * Migrates legacy quote reCAPTCHA settings into wholesale registration options.
 */
class RecaptchaQuoteMigration {

	const MIGRATED_OPTION       = 'wwp_recaptcha_quote_migrated';
	const LEGACY_QUOTE_OPTION   = 'wc_quote_recaptcha';

	public function __construct() {
		add_action( 'init', array( $this, 'migrate' ), 250 );
	}

	/**
	 * Migrate reCAPTCHA settings from legacy quote options to wholesale registration options.
	 * 
	 * @return void
	 */
	public function migrate() {
		if ( 'yes' === get_option( self::MIGRATED_OPTION ) ) {
			return;
		}

		$settings = get_option( WholesaleOption::REGISTRATION_OPTION, array() );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		$updated = false;

		if ( $this->wholesale_recaptcha_is_configured( $settings ) ) {
			if ( ! isset( $settings['enable_recaptcha_quote'] ) || 'yes' !== $settings['enable_recaptcha_quote'] ) {
				$settings['enable_recaptcha_quote'] = 'yes';
				$updated                            = true;
			}
		} else {
			$updated = $this->migrate_from_legacy_quote_recaptcha( $settings ) || $updated;
		}

		if ( $updated ) {
			update_option( WholesaleOption::REGISTRATION_OPTION, $settings );
		}

		update_option( self::MIGRATED_OPTION, 'yes' );
	}

	/**
	 * Wholesale registration captcha is enabled with valid keys for the active version.
	 *
	 * @param array $settings Registration settings.
	 * @return bool
	 */
	private function wholesale_recaptcha_is_configured( array $settings ) {
		return $this->has_recaptcha_keys( $settings );
	}

	/**
	 * Check if reCAPTCHA keys are configured for the active version.
	 * 
	 * @param array $settings Registration settings.
	 * @return bool
	 */
	private function has_recaptcha_keys( array $settings ) {
		$version = isset( $settings['recaptcha_version'] ) ? $settings['recaptcha_version'] : 'v2';

		if ( 'v3' === $version ) {
			return ! empty( $settings['recaptcha_v3_site_key'] ) && ! empty( $settings['recaptcha_v3_secret_key'] );
		}

		return ! empty( $settings['recaptcha_v2_site_key'] ) && ! empty( $settings['recaptcha_v2_secret_key'] );
	}

	/**
	 * Process quote pdf for print.
	 *
	 * @param array $settings Registration settings (passed by reference).
	 * @return bool Whether settings were changed.
	 */
	private function migrate_from_legacy_quote_recaptcha( array &$settings ) {
		$legacy = get_option( self::LEGACY_QUOTE_OPTION, array() );

		if ( ! is_array( $legacy ) ) {
			return false;
		}

		$updated        = false;
		$site_key       = isset( $legacy['captcha_site_key'] ) ? (string) $legacy['captcha_site_key'] : '';
		$secret_key     = isset( $legacy['captcha_secret_key'] ) ? (string) $legacy['captcha_secret_key'] : '';
		$enable_captcha = isset( $legacy['enable_captcha'] ) ? (string) $legacy['enable_captcha'] : '';

		if ( '' !== $site_key && empty( $settings['recaptcha_v2_site_key'] ) ) {
			$settings['recaptcha_v2_site_key'] = $site_key;
			$updated                           = true;
		}

		if ( '' !== $secret_key && empty( $settings['recaptcha_v2_secret_key'] ) ) {
			$settings['recaptcha_v2_secret_key'] = $secret_key;
			$updated                             = true;
		}

		if ( '1' === $enable_captcha ) {
			if ( empty( $settings['recaptcha_version'] ) ) {
				$settings['recaptcha_version'] = 'v2';
				$updated                       = true;
			}

			if ( ! isset( $settings['enable_recaptcha_quote'] ) || 'yes' !== $settings['enable_recaptcha_quote'] ) {
				$settings['enable_recaptcha_quote'] = 'yes';
				$updated                            = true;
			}
		}

		return $updated;
	}
}
