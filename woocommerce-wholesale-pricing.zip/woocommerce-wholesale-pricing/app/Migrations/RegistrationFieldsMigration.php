<?php
namespace WooCommerceWholesalePricing\App\Migrations;

// Migration for version 3.1.0

class RegistrationFieldsMigration {

	const STATUS_OPTION = 'wwp_registration_fields_migration_status';

	/**
	 * Executes the necessary data migrations.
	 *
	 * This migration focuses on converting the old hardcoded custom registration
	 * fields (custom_field_1 through custom_field_5) into a new structured,
	 * JSON-encoded array format suitable for a modern form builder.
	 *
	 * @return void
	 */
	public static function migrate() {
		$db_version = get_option( 'wwp_wholesale_version' );

		if ( version_compare( $db_version, WWP_VERSION, '<' ) ) {
			update_option( self::STATUS_OPTION, 'in_progress' );
			
			// Execute the schema change
			self::run_form_builder_migration();

			// FINALLY: Update the version to current once logic is done
			update_option( 'wwp_wholesale_version', WWP_VERSION );
			update_option( self::STATUS_OPTION, 'completed' );
		}
	}

	public static function is_in_progress() {
		$db_version = get_option( 'wwp_wholesale_version', '1.0.0' );

		return version_compare( $db_version, WWP_VERSION, '<' );
	}

	private static function run_form_builder_migration() {
		$updated_settings  = array( 'components' => array() );
		$existing_settings = ! empty( get_option( 'wwp_save_form' ) ) ? json_decode( (string) get_option( 'wwp_save_form' ), true ) : array();
		update_option( 'wwp_save_form_legacy', $existing_settings );

		foreach ( $existing_settings as $field ) {
			if ( empty( $field['type'] ) ) {
				continue;
			}

			$component = self::map_legacy_field_to_formio_component( $field );
			if ( ! empty( $component ) && is_array( $component ) ) {
				$updated_settings['components'][] = $component;
			}
		}

		if ( ! empty( $updated_settings['components'] ) ) {
			update_option( 'wwp_save_form', wp_json_encode( $updated_settings ) );

		}
	}

	private static function map_legacy_field_to_formio_component( $field ) {

		$field_type    = isset( $field['type'] ) ? $field['type'] : '';
		$field_subtype = isset( $field['subtype'] ) ? $field['subtype'] : '';
		$required      = ! empty( $field['required'] );

		$component = array(
			'key'                => isset( $field['name'] ) ? $field['name'] : 'field_' . uniqid(),
			'validate'           => array( 'required' => $required ),
			'label'              => isset( $field['label'] ) ? $field['label'] : '',
			'tooltip'            => isset( $field['description'] ) ? $field['description'] : '',
			'placeholder'        => isset( $field['placeholder'] ) ? $field['placeholder'] : '',
			'customClass'        => isset( $field['className'] ) ? $field['className'] : '',
			'validateWhenHidden' => false,
			'input'              => true,
			'tableView'          => true,
		);

		switch ( $field_type ) {
			case 'text':
				switch ( $field_subtype ) {
					case 'password':
						$component['type'] = 'password';
						break;
					case 'email':
						$component['type'] = 'email';
						break;
					case 'tel':
						$component['type'] = 'phoneNumber';
						break;
					case 'url':
						$component['type'] = 'url';
						break;

					case 'color':
						$component['type']      = 'color';
						break;
					default:
						$component['type'] = 'textfield';
						$component['onChange'] = 'change';
						break;
				}
				if ( isset( $field['value'] ) ) {
					$component['defaultValue'] = $field['value'];
				}
				return $component;

			case 'textarea':
				$component['type'] = 'textarea';
				if ( isset( $field['value'] ) ) {
					$component['defaultValue'] = $field['value'];
				}
				if ( isset( $field['rows'] ) ) {
					$component['rows'] = $field['rows'];
				}
				if ( isset( $field['maxlength'] ) ) {
					$component['validate']['maxWords'] = $field['maxlength'];
				}
				return $component;

			case 'select':
				$component['type'] = 'select';
				$component['widget'] = 'choicesjs';
				$component['data'] = array( 'values' => self::normalize_legacy_values( $field ) );
				$component['multiple'] = ( isset($field['multiple']) && $field['multiple'] );
				return $component;

			case 'checkbox-group':
				$component['type']   = 'selectboxes';
				$component['values'] = self::normalize_legacy_values( $field );
				$component['inputType'] = 'checkbox';
				return $component;

			case 'radio-group':
				$component['type']   = 'radio';
				$component['values'] = self::normalize_legacy_values( $field );
				$component['optionsLabelPosition'] = 'right';
				$component['defaultValue'] = self::normalize_selected_value( $field['values'] );
				$component['inline'] = false;
				return $component;

			case 'number':
				$component['type'] = 'number';
				if ( isset( $field['value'] ) ) {
					$component['defaultValue'] = $field['value'];
				}
				if ( isset( $field['min'] ) ) {
					$component['validate']['min'] = $field['min'];
				}
				if ( isset( $field['max'] ) ) {
					$component['validate']['max'] = $field['max'];
				}
				return $component;

			case 'date':
				$component['type']   = 'datetime';
				$component['format'] = 'yyyy-MM-dd';
				return $component;

			case 'autocomplete':
				$component['type'] = 'select';
				$component['widget'] = 'choicesjs';
				$component['data'] = array( 'values' => self::normalize_legacy_values( $field ) );
				return $component;

			case 'header':
				return array(
					'type'      => 'content',
					'key'       => 'content',
					'label'     => isset( $field['label'] ) ? $field['label'] : '',
					'html'      => '<' . $field['subtype'] . '>' . esc_html( isset( $field['label'] ) ? $field['label'] : '' ) . '</' . $field['subtype'] . '>',
					'input'     => false,
					'tableView' => false,
				);

			case 'paragraph':
				return array(
					'type'      => 'content',
					'key'       => 'content',
					'label'     => isset( $field['label'] ) ? $field['label'] : '',
					'html'      => '<' . $field['subtype'] . '>' . esc_html( isset( $field['label'] ) ? $field['label'] : '' ) . '</' . $field['subtype'] . '>',
					'input'     => false,
					'tableView' => false,
				);
		}

		return array();
	}

	private static function normalize_legacy_values( $field ) {
		$normalized_values = array();
		$legacy_values     = isset( $field['values'] ) && is_array( $field['values'] ) ? $field['values'] : array();

		foreach ( $legacy_values as $value ) {
			if ( is_array( $value ) ) {
				$value_label = isset( $value['label'] ) ? $value['label'] : '';
				$value_value = isset( $value['value'] ) && '' !== $value['value'] ? $value['value'] : sanitize_title( $value_label );

				$normalized_values[] = array(
					'label' => $value_label,
					'value' => $value_value,
				);
			} elseif ( is_string( $value ) ) {
				$normalized_values[] = array(
					'label' => $value,
					'value' => sanitize_title( $value ),
				);
			}
		}

		return $normalized_values;
	}

	public static function normalize_selected_value( $values ) {
		if ( empty( $values ) || ! is_iterable($values) ) {
			return null;
		}

		foreach ( $values as $value ) {
			if ( isset( $value['value'], $value['selected'] ) && '1' == $value['selected'] ) {
				return $value['value'];
			}
		}

		return null;
	}
}
