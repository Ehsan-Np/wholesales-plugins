<?php
/**
 * Hookable
 *
 * Defines the contract for any class that registers WordPress actions or filters.
 * This interface promotes a standardized way of defining where all hook registrations
 * occur within a service or module.
 *
 * @package    WooCommerceWholesalePricing\Strategies
 */
namespace WooCommerceWholesalePricing\App\Strategies;

/**
 * Hookable
 *
 * Interface for classes that manage WordPress hooks (actions and filters).
 * Any class implementing this interface must define a `hooks()` method
 * where all WordPress hook registration functions (`add_action`, `add_filter`)
 * are called.
 */
interface Hookable {

	/**
	 * Registers all WordPress hooks (actions and filters) for the implementing class.
	 *
	 * This method serves as the centralized location for registering event listeners
	 * that connect the class's methods to the WordPress execution cycle.
	 *
	 * @return void
	 */
	public function hooks();
}
