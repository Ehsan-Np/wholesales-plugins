<?php
/**
 * Recaptcha
 *
 * Defines the abstract contract for implementing reCAPTCHA validation services.
 * This class provides a common method for safely retrieving the client's IP address,
 * ensuring consistency across different reCAPTCHA versions or providers that may
 * extend this class.
 *
 * @package    WooCommerceWholesalePricing\Strategies
 *
 * @since 2.4.0
 */
namespace WooCommerceWholesalePricing\App\Strategies;

/**
 * Recaptcha
 *
 * Abstract base class for reCAPTCHA integration strategies. Concrete
 * implementations must define how the reCAPTCHA field is added to the form
 * and how the submission is verified.
 *
 * @since 2.4.0
 */
abstract class Recaptcha {

	 
	/**
	 * Abstract method to render the reCAPTCHA field on the necessary form.
	 *
	 * This method should be hooked into the relevant action (e.g., login,
	 * registration, contact form) to output the necessary HTML and/or JavaScript
	 * for the reCAPTCHA widget.
	 *
	 * @since 2.4.0
	 *
	 * @return void
	 */
	abstract public function add_recaptcha();
	 
	/**
	 * Abstract method to verify the reCAPTCHA response upon form submission.
	 *
	 * This method is typically hooked into a validation filter (e.g., form submission
	 * validation) and should communicate with the reCAPTCHA API to check the
	 * user's response or score.
	 *
	 * @since 2.4.0
	 *
	 * @param array $errors  Array of WP_Error objects or similar error structure.
	 * @param array $request The request data (e.g., $_POST) passed during submission.
	 *
	 * @return void
	 */
	abstract public function verify_recaptcha( array $errors, array $request );
	 
	/**
	 * Retrieves the client's IP address by checking common server variables.
	 *
	 * It attempts to securely determine the client IP address, accounting for
	 * proxy and forwarded headers, and sanitizes the result using WordPress's
	 * `sanitize_text_field`.
	 *
	 * @since 2.4.0
	 *
	 * @return string The determined IP address, or '127.0.0.1' as a fallback.
	 */
	public function get_ip_address() {

		if (isset($_SERVER['HTTP_CLIENT_IP']) ) {
			$ipaddress = sanitize_text_field($_SERVER['HTTP_CLIENT_IP']);
		} else if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) ) {
			$ipaddress = sanitize_text_field($_SERVER['HTTP_X_FORWARDED_FOR']);
		} else if (isset($_SERVER['HTTP_X_FORWARDED']) ) {
			$ipaddress = sanitize_text_field($_SERVER['HTTP_X_FORWARDED']);
		} else if (isset($_SERVER['HTTP_FORWARDED_FOR']) ) {
			$ipaddress = sanitize_text_field($_SERVER['HTTP_FORWARDED_FOR']);
		} else if (isset($_SERVER['HTTP_FORWARDED']) ) {
			$ipaddress = sanitize_text_field($_SERVER['HTTP_FORWARDED']);
		} else if (isset($_SERVER['REMOTE_ADDR']) ) {
			$ipaddress = sanitize_text_field($_SERVER['REMOTE_ADDR']);
		} else {
			$ipaddress = '127.0.0.1';
		}

		return $ipaddress;
	}
}
