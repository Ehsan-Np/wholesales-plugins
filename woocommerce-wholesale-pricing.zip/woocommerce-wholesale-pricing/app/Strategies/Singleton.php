<?php
/**
 * Singleton
 *
 * Defines the base class for the Singleton design pattern, allowing only one
 * instance of a class (or one instance per subclass) to be created.
 *
 * It uses Late Static Binding to support inheritance, enabling subclasses to
 * retrieve their own unique instance.
 *
 * @package    WooCommerceWholesalePricing\Strategies
 */
namespace WooCommerceWholesalePricing\App\Strategies;

/**
 * Singleton
 *
 * Implements the core logic of the Singleton pattern. Subclasses should inherit
 * from this class to gain Singleton capabilities.
 *
 * This implementation prevents external instantiation, cloning, and unserialization.
 */
class Singleton {

	/**
	 * Instances
	 * 
	 * @var array Holds the instances of all Singleton subclasses.
	 * The key is the fully qualified class name.
	 */
	private static $instances = array();

	/**
	 * Protected constructor to prevent direct instantiation of the class.
	 *
	 * By making the constructor protected, we allow subclasses to be constructed
	 * internally by the `instance()` method, but prevent direct use of `new ClassName()`.
	 */
	protected function __construct() {
	}

	/**
	 * Prevents the instance from being cloned (copied).
	 */
	protected function __clone() {
	}

	/**
	 * Prevents the instance from being restored from a serialized string.
	 *
	 * @throws \Exception If an attempt is made to unserialize the singleton.
	 */
	public function __wakeup() {
		throw new \Exception('Cannot unserialize singleton');
	}

	/**
	 * The static method used to get the Singleton's instance.
	 *
	 * This uses Late Static Binding (`static::class` and `new static()`) to ensure
	 * that when called from a subclass, an instance of that specific subclass is
	 * created and stored uniquely.
	 *
	 * @return static Returns the single instance of the class or subclass.
	 */
	public static function instance() {
		$subclass = static::class;
		if (! isset(self::$instances[$subclass]) ) {
			// Note that here we use the "static" keyword instead of the actual
			// class name. In this context, the "static" keyword means "the name
			// of the current class". That detail is important because when the
			// method is called on the subclass, we want an instance of that
			// subclass to be created here.
			self::$instances[$subclass] = new static();
		}
		return self::$instances[$subclass];
	}
}
