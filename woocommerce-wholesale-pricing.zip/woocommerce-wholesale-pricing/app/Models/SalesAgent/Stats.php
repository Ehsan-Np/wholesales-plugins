<?php

namespace WooCommerceWholesalePricing\App\Models\SalesAgent;

class Stats {
	
	public static function total_count_order_by_agent( $agent_id = false ) {
		$data = 0;
		if ( $agent_id ) {
			$orders = wc_get_orders(
				array(
					'limit'      => -1,
					'return'     => 'ids',
					'meta_key'   => 'sales_agent',
					'meta_value' => (string) $agent_id,
					'status'     => array_keys( wc_get_order_statuses() ),
				)
			);
			$data = is_array( $orders ) ? count( $orders ) : 0;
		}
		/**
		 * Filter.
		 *
		 * @since 1.0.4
		 */
		return apply_filters( 'data_total_count_order_by_agent', $data );
	}

	public static function total_order_sales_by_agent( $agent_id = false ) {
		$data = 0;
		if ( $agent_id ) {
			$orders = wc_get_orders(
				array(
					'limit'      => -1,
					'meta_key'   => 'sales_agent',
					'meta_value' => (string) $agent_id,
					'status'     => array_keys( wc_get_order_statuses() ),
				)
			);
			if ( ! empty( $orders ) ) {
				foreach ( $orders as $order ) {
					$data += $order->get_total();
				}
			}
		}
		/**
		 * Filter.
		 *
		 * @since 1.0.4
		 */
		return apply_filters( 'total_order_sales_by_agent', wc_price($data) );
	}
}
