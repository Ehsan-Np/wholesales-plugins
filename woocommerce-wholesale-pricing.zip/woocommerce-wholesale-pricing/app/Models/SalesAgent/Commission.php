<?php

namespace WooCommerceWholesalePricing\App\Models\SalesAgent;

class Commission {

	private $table_name          = 'wc_agents_commissions';
	private $columns_placeholder = array(
		'agent_id'              => '%d',
		'order_id'              => '%d',
		'commission_type'       => '%s',
		'commission_percentage' => '%s',
		'commission_value'      => '%s',
		'create_date'           => '%s',
	);

	public function get_pending_commission_by_agent_id( $agent_id = '', $status = '' ) {
		global $wpdb;
		$wc_agents_commissions = $wpdb->prefix . $this->table_name;
		$result                = $wpdb->get_results(
			$wpdb->prepare(
				"
            SELECT * FROM {$wpdb->prefix}wc_agents_commissions WHERE agent_id = %d AND commission_status = %s
            ",
				$agent_id,
				$status
			)
		);

		return $result;
	}

	public function get_agent_commission_info( $agent_id ) {
		$commission_type          = '';
		$commission_category_name = '-';

		if ( '' === $commission_type ) {
			$args_group    = array(
				'post_type'  => 'agent_groups',
				'meta_query' => array(
					array(
						'key'     => 'agents_in_group',
						'value'   => $agent_id,
						'compare' => 'LIKE',
					),
				),
			);
			$group_post    = get_posts( $args_group );
			$group_post_id = isset( $group_post[0]->ID ) ? $group_post[0]->ID : false;

			$customer_based_commission = $group_post_id ? get_post_meta( $group_post_id, 'customer_based_commission', true ) : '';
			$agent_commission_type     = get_post_meta( $agent_id, 'commission_type', true );

			$agent_level_post_id = class_exists( 'WC_Agent_Order' ) ? \WC_Agent_Order::get_agent_level_id( $agent_id ) : (int) get_post_meta( $agent_id, 'agent_current_level', true );

			$default_commission_category_id = get_post_meta( $agent_id, 'commission_category', true );
			$terms                          = $default_commission_category_id ? get_term( $default_commission_category_id, 'commission_cat' ) : '';

			if ( ! $agent_level_post_id ) {
				if (
					( ! $group_post_id && 'customer' === $agent_commission_type ) ||
					( $group_post_id && 'on' === $customer_based_commission && 'customer' === $agent_commission_type )
				) {
					$commission_type          = 'Customer Based';
					$commission_category_name = '-';
				} elseif ( ! $group_post_id ) {
					$commission_type = 'Commission Category Based';
					if ( $terms && ! is_wp_error( $terms ) ) {
						$commission_category_name = $terms->name;
					}
				} else {
					$commission_type        = 'Group Commission Category';
					$commission_category_id = get_post_meta( $group_post_id, 'group_commission_category', true );
					$group_terms            = $commission_category_id ? get_term( $commission_category_id, 'commission_cat' ) : '';
					if ( $group_terms && ! is_wp_error( $group_terms ) ) {
						$commission_category_name = $group_terms->name;
					}
				}
			} else {
				$commission_type          = 'Level Based';
				$commission_category_name = '-';
			}
		}

		// =========== Commission =============

		// Total Paid Commission
		$paid_commissions      = $this->get_pending_commission_by_agent_id( $agent_id, 'paid' );
		$total_paid_commission = 0;
		if ( is_array( $paid_commissions ) ) {
			foreach ( $paid_commissions as $commission ) {
				$total_paid_commission += $commission->commission_value;
			}
		}

		// Total Pending Commission
		$pending_commissions      = $this->get_pending_commission_by_agent_id( $agent_id, 'pending' );
		$total_pending_commission = 0;
		if ( is_array( $pending_commissions ) ) {
			foreach ( $pending_commissions as $commission ) {
				$total_pending_commission += $commission->commission_value;
			}
		}

		$sub_commissions_by_agent_id = $this->get_sub_commissions_by_agent_id( $agent_id );
		$total_sub_commission        = array_sum( array_column( $sub_commissions_by_agent_id, 'sub_commission_amount' ) );


		return array(
			'commission_type'          => $commission_type,
			'commission_category'      => $commission_category_name,
			'total_paid_commission'    => $total_paid_commission,
			'total_pending_commission' => $total_pending_commission,
			'total_sub_commission'     => $total_sub_commission,
		);
	}

	public function get_sub_commissions_by_agent_id( $agent_id = 0 ) {
		global $wpdb;

		$user_id = get_current_user_id();

		$agent_post = get_posts(
			array(
				'post_type'        => 'agent',
				'numberposts'      => 1,
				'meta_key'         => 'assign_user',
				'meta_value'       => $user_id,
				'suppress_filters' => true,
			)
		);

		if ( isset( $agent_post[0]->ID ) ) {
			$agent_id = $agent_post[0]->ID;
	
			$commissions = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$wpdb->prefix}wc_agents_sub_commissions WHERE agent_id = %d",
					$agent_id
				)
			);
	
			return $commissions;
		}

		return array();
	}

	public function get_commission_by_id( $commission_id ) {
		$commission_db = new AgentCommission();
		$rows          = $commission_db->query_get_commission_by_id( $commission_id );
		return $rows;
	}

	public function get_commission_percentage( $tax_id ) {
		$term_meta  = get_option( "taxonomy_term_$tax_id" );
		$percentage = '';
		if ( ! empty( $term_meta ) && $term_meta['percentage'] ) {
			$percentage = $term_meta['percentage'];
			return $percentage;
		}
		return $percentage;
	}

	public function save_commission_edit() {

		$saved = false;
		if ( isset( $_REQUEST['submit-commission'] ) ) {
			check_admin_referer( 'save_commission_edit_nonce' );

			if ( ! current_user_can( 'manage_woocommerce' ) ) {
				wp_die( esc_html__( 'You do not have permission to edit commissions.', 'woocommerce-wholesale-pricing' ) );
			}

			$commission_id = isset( $_REQUEST['commission_id'] ) ? sanitize_text_field( $_REQUEST['commission_id'] ) : '';
			global $wpdb;
			// prepare data commission
			$agent_id          = isset( $_REQUEST['agent-filter'] ) ? stripslashes_deep( sanitize_text_field( $_REQUEST['agent-filter'] ) ) : '';
			$commission_status = isset( $_REQUEST['commission_status'] ) ? stripslashes_deep( sanitize_text_field( $_REQUEST['commission_status'] ) ) : 'pending';
			$commission_amount = isset( $_REQUEST['commission_amount'] ) ? stripslashes_deep( sanitize_text_field( $_REQUEST['commission_amount'] ) ) : '';
			$order_id          = isset( $_REQUEST['order_id'] ) ? stripslashes_deep( sanitize_text_field( $_REQUEST['order_id'] ) ) : '';

			$wpdb->update(
				"{$wpdb->prefix}wc_agents_commissions",
				array(
					'agent_id'          => $agent_id,
					'commission_status' => $commission_status,
				),
				array( 'id' => $commission_id )
			);
			// update sales agent for order
			$order = wc_get_order( $order_id );
			if ( $order ) {
				$order->update_meta_data( 'sales_agent', $agent_id );
				$order->save();
			}

			if ( isset( $_REQUEST['commission_status'] ) && 'paid' == sanitize_text_field( $_REQUEST['commission_status'] ) ) {
				update_option( 'last_payment_' . $agent_id, current_time( 'Y-m-d H:i:s' ) );

				if ( ! metadata_exists( 'post', $order_id, 'safw_payout_email_sent' ) ) {
					/**
					 * Action Hook.
					 *
					 * @since 1.3
					 */
					do_action( 'safw_payout_status', $agent_id, $commission_amount );
					if ( $order ) {
						$order->update_meta_data( 'safw_payout_email_sent', true );
						$order->save();
					}
				}
			} elseif ( isset( $_REQUEST['commission_status'] ) && 'paid' != sanitize_text_field( $_REQUEST['commission_status'] ) ) {
				if ( $order ) {
					$order->delete_meta_data( 'safw_payout_email_sent' );
					$order->save();
				}
			}
			/**
			* Update commission for order.
			*
			* @since 1.0.4
			*/
			do_action( 'save_update_commission', $commission_id, $agent_id );

			$saved = true;
		}
		return $saved;
	}
}
