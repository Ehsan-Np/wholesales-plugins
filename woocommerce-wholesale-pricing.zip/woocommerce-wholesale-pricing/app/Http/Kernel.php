<?php
/**
 * Kernel Class
 *
 * Acts as the core service container manager for the WooCommerce Wholesale Pricing plugin.
 * Responsible for registering and initializing service classes, including those implementing
 * the ServiceInterface, and bootstrapping the WooCommerce extension.
 *
 * @package WooCommerceWholesalePricing\Kernel
 */
namespace WooCommerceWholesalePricing\App\Http;

use WooCommerceWholesalePricing\Bootstrap\WooCommerceExtension;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

class Kernel {



	/**
	 * Register and instantiate service classes.
	 *
	 * Iterates over an autoload array of service class names,
	 * instantiates them conditionally based on whether they implement
	 * the ServiceInterface and their static resolveDependency() method.
	 *
	 * @param array $autoload Nested array of service class names keyed by namespace or group.
	 *
	 * @return Kernel Returns an instance of the Kernel after registration.
	 */
	public static function register( $autoload ) {
		$serviceContainers = array_merge(...array_values($autoload));
		foreach ( $serviceContainers as $entity ) { 
			if (class_exists($entity) && in_array(ServiceInterface::class, class_implements($entity), true) ) {
				/**
				 * Call resolveDependency statically before instantiation
				 */
				if ($entity::resolveDependency() ) {
					new $entity();
				}
			} else {
				new $entity();
			}
		}
		return new self();
	}
	 
	/**
	 * Load core plugin extension.
	 *
	 * Instantiates the WooCommerceExtension class to bootstrap plugin features.
	 *
	 * @return void
	 */
	public function load() {
		new WooCommerceExtension();
	}
}
