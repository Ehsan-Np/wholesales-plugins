<?php

namespace WooCommerceWholesalePricing\App\Services\SalesAgent;

use WooCommerceWholesalePricing\App\Modules\SalesAgent\Emails\Handler as Emails;
use WooCommerceWholesalePricing\App\Modules\SalesAgent\Registration;
use WooCommerceWholesalePricing\App\Modules\SalesAgent\Order;
use WooCommerceWholesalePricing\App\Modules\SalesAgent\ProductPanel;
use WooCommerceWholesalePricing\App\Modules\SalesAgent\MyAccount;
use WooCommerceWholesalePricing\App\Modules\SalesAgent\UserEdit;
use WooCommerceWholesalePricing\App\Modules\SalesAgent\UserSwitching;
use WooCommerceWholesalePricing\App\Modules\SalesAgent\Request;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

class SalesAgentService implements ServiceInterface {

	public function __construct() {
		new Registration();
		new Emails();
		new ProductPanel();
		new Order();
		new UserEdit();
		new MyAccount();
		new UserSwitching();
		new Request();
	}

	public static function resolveDependency() {
		return is_sales_agent_enabled();
	}
}
