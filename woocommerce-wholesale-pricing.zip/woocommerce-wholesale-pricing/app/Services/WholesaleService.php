<?php
/**
 * WholesaleService
 *
 * This class is the primary registration point for all wholesale-related
 * functionality on the frontend and administrative sides of the store. It determines
 * if the current user (logged in or guest) is eligible for wholesale features
 * and, if so, loads the necessary wholesale modules (e.g., pricing, cart, shipping).
 *
 * @package    WooCommerceWholesalePricing\Services
 * @extends    Init
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;
use WooCommerceWholesalePricing\App\Modules\Wholesale\CartService;
use WooCommerceWholesalePricing\App\Modules\Wholesale\PaymentGatewayService;
use WooCommerceWholesalePricing\App\Modules\Wholesale\ProductService;
use WooCommerceWholesalePricing\App\Modules\Wholesale\ProductVisibility;
use WooCommerceWholesalePricing\App\Modules\Wholesale\ShippingService;
use WooCommerceWholesalePricing\App\Modules\Wholesale\PriceService;
use WooCommerceWholesalePricing\App\Strategies\Init;

/**
 * WholesaleService
 *
 * Initializes and manages all core wholesale application modules based on
 * user status and global wholesale settings.
 *
 * @extends    Init
 * @implements ServiceInterface
 */
class WholesaleService extends Init implements ServiceInterface {


	/**
	 * Trait that provides static access to wholesale pricing settings.
	 */
	use WholesaleSettings;

	/**
	 * WholesaleService constructor.
	 *
	 * Initializes the service by calling the parent constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Registers and activates wholesale functionality based on user eligibility
	 * or global store restrictions.
	 *
	 * 1. If the user is logged in: Checks if the user has a registered wholesale role,
	 * is a shop admin, or belongs to a wholesale group. If any condition is met,
	 * it includes all wholesale functionality.
	 * 2. If the user is a guest: Checks if store access restriction is enabled or
	 * if guest wholesale pricing is enabled. If either is true, it includes
	 * wholesale functionality (and potentially restricts store access).
	 *
	 * @return bool Always returns false after execution (standard Init strategy).
	 */
	public function register() {
		$settings = self::get_pricing_settings();
	
		if (is_user_logged_in() ) { 
			$user_info      = get_userdata(get_current_user_id());
			$user_role      = implode(', ', $user_info->roles);
			$ws_group       = wwp_get_group_post_by_proid(0, $user_info->ID);
			$wholesale_role = term_exists($user_role, wwp_env()->get('role_taxonomy'));
			if (( 0 !== $wholesale_role && null !== $wholesale_role ) || is_admin() || $ws_group || is_company_member() ) { 
				self::includeWholesaleFunctionality();
			}

		} elseif (( isset($settings['restrict_store_access']) && 'yes' == $settings['restrict_store_access'] ) || ( wwp_guest_wholesale_pricing_enabled() ) ) {
			PrivateStoreService::restrict_store_access();
			self::includeWholesaleFunctionality();
		}

		return false;
	}

	/**
	 * Initializes all necessary wholesale modules.
	 *
	 * This method is only called if the current user is confirmed to be a wholesaler
	 * (or is a guest with active wholesale pricing/restrictions). It instantiates
	 * the core modules required for wholesale operations.
	 *
	 * @return void
	 */
	public static function includeWholesaleFunctionality() {
		$settings = self::get_pricing_settings();
		if (isset($settings['restrict_store_access']) && 'yes' != $settings['restrict_store_access'] ) {
			$ws_group = wwp_get_group_post_by_proid(0, get_current_user_id());
			if (! is_wholesaler_user(get_current_user_id()) && ( ! wwp_guest_wholesale_pricing_enabled() ) && ! $ws_group && ! is_company_member() ) {
				return;
			}
		}

		// Initialize core modules.
		new CartService();
		new PaymentGatewayService();
		new ShippingService();
		new ProductVisibility();
		new PriceService();

		// Initialize ProductService globally for pricing logic.
		$GLOBALS['productService'] = new ProductService();
	}

	/**
	 * Determines whether this service should be initialized.
	 *
	 * This service is essential for both frontend and backend operations, so it
	 * is always resolved to true.
	 *
	 * @return bool Always true.
	 */
	public static function resolveDependency() {
		return true;
	}
}
