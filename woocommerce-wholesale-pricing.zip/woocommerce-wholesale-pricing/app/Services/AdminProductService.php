<?php
/**
 * AdminProductService Class
 *
 * This class handles all administrative aspects related to product management
 * for the WooCommerce Wholesale Pricing plugin, including custom columns,
 * product data tabs, metaboxes, and saving product metadata.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Handles admin product UI and data saving for wholesale pricing.
 * 
 * @implements ServiceInterface
 */
class AdminProductService implements ServiceInterface {


	/**
	 * Includes methods for retrieving general wholesale settings.
	 */
	use WholesaleSettings;

	/**
	 * Constructor. Registers all necessary WordPress and WooCommerce hooks.
	 */
	public function __construct() {
		// Product list table columns
		add_filter('manage_edit-product_columns', array( $this, 'change_columns_filter' ), 10, 1);
		add_action('manage_product_posts_custom_column', array( $this, 'manage_product_posts_custom_column' ), 10, 2);
		
		// Product data tabs and panels
		add_filter('woocommerce_product_data_tabs', array( $this, 'wwp_add_wholesale_product_data_tab' ), 99, 1);

		// Product save actions (legacy settings save)
		add_action('woocommerce_product_data_panels', array( $this, 'wwp_add_wholesale_product_data_fields_multi' ));
		add_action('woocommerce_process_product_meta', array( $this, 'wwp_woo_wholesale_fields_save_multi' ), 99);

		// Wholesale User Pricing Metabox
		add_action('add_meta_boxes', array( $this, 'callback' ));
		add_action('wp_ajax_retrieve_wholesale_multiuser_pricing', array( $this, 'metabox_content' ));

		// Product save action (Wholesale User Pricing save)
		add_action('save_post_product', array( $this, 'update_product' ), 10, 1);
	}

	/**
	 * Adds the 'Wholesale Pricing' column to the WooCommerce Products list table.
	 *
	 * @param  array $columns Existing columns in the product list table.
	 * @return array Modified array of columns.
	 */
	public function change_columns_filter( $columns ) {
		$columns['wholesale'] = esc_html__('Wholesale Pricing', 'woocommerce-wholesale-pricing');
		return $columns; 
	}

	/**
	 * Renders content for the custom 'Wholesale Pricing' column.
	 * Displays buttons indicating where wholesale pricing is applied (Product, Category, Global).
	 *
	 * @param  string $column     The column key being rendered.
	 * @param  int    $product_id The ID of the current product post.
	 * @return void
	 */
	public function manage_product_posts_custom_column( $column, $product_id ) {
		if ('wholesale' == $column ) {
			$has_discount   = false;
			$discounts      = array();
			$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
			foreach ( $allterms as $allterm ) { 
				$role = $allterm->term_id;
				$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
				if (isset($data[ $role ]) ) { 
					$has_discount = true;
					$discounts['product_' . $role] = sprintf('%s: Product', $allterm->name);
				}
				$terms = get_the_terms($product_id, 'product_cat');
				if (! is_wp_error($terms) && ! empty($terms) ) {
					foreach ( $terms as $term ) {
						$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
						if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
							$has_discount = true;
							$discounts['category_' . $term->term_id . '_' . $role] = sprintf('%s: Category', $allterm->name);
						}
					}
				}
				$data = self::get_multiuser_pricing_settings();
				if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
					$has_discount = true;
					$discounts['global_' . $role] = sprintf('%s: Global', $allterm->name);
				}
			}

			if ($has_discount && ! empty($discounts) ) {
				?>
				<div class="wwp-tooltip-wrapper">
					<button type="button" class="trigger-btn products-list wwp-button-primary"><?php esc_html_e('Applied Discounts', 'woocommerce-wholesale-pricing'); ?></button>
					<div class="wwp-tooltip-content">
						<?php
						foreach ( get_sorted_admin_discounts_view($discounts) as $key => $discount ) : 
							$keys = explode('_', $key);
							$type = reset($keys);
							?>
							<a href="<?php echo esc_url(get_admin_discount_type_link($type, $product_id, $keys)); ?>#accordion" target="_blank"><?php esc_attr_e($discount); ?></a>
						<?php endforeach; ?>
					</div>
				</div>
				<?php
			} else {
				?>
				<span class="dashicons dashicons-minus"></span>
				<?php
			}
		}
	}

	/**
	 * Adds the 'Wholesale' product data tab to the WooCommerce product edit screen.
	 *
	 * @param  array $product_data_tabs Existing product data tabs.
	 * @return array Modified array of product data tabs.
	 */
	public function wwp_add_wholesale_product_data_tab( $product_data_tabs ) {
		$product_data_tabs['wwp-wholesale-tab'] = array(
			'label'  => esc_html__('Wholesale', 'woocommerce-wholesale-pricing'),
			'target' => 'wwp_wholesale_product_data',
		);
		return $product_data_tabs;
	}

	/**
	 * Displays the fields within the 'Wholesale' product data tab panel.
	 *
	 * * @return string Rendered HTML output.
	 */
	public function wwp_add_wholesale_product_data_fields_multi() {
		// version 1.3.0
		global $post;
		
		// This assumes a global helper function 'view' exists to render a template.
		// The panel template contains fields for visibility, icons, and sample products.
		// phpcs:ignore WordPress.NamingConventions.PrefixUnderscores.NonPrivatePrefix
		return wwp_view('admin.product.panel', compact('post'));
	}

	/**
	 * Saves wholesale-related meta fields from the Wholesale Product Data tab.
	 * This handles fields like visibility settings, icon/image URLs, and sample product settings.
	 *
	 * @param  int $post_id The ID of the post being saved.
	 * @return void
	 */
	public function wwp_woo_wholesale_fields_save_multi( $post_id ) {

		if (! isset($_POST['wwp_product_wholesale_nonce']) || ( isset($_POST['wwp_product_wholesale_nonce']) && ! wp_verify_nonce(wc_clean($_POST['wwp_product_wholesale_nonce']), 'wwp_product_wholesale_nonce') ) ) {
			return;
		}

		$product = wc_get_product($post_id); 

		// hide product for customer
		$_wwp_hide_for_customer = isset($_POST['_wwp_hide_for_customer']) ? wc_clean($_POST['_wwp_hide_for_customer']) : '';
		$product->update_meta_data('_wwp_hide_for_customer', esc_attr($_wwp_hide_for_customer));
		// hide product for visitor
		$_wwp_hide_for_visitor = isset($_POST['_wwp_hide_for_visitor']) ? wc_clean($_POST['_wwp_hide_for_visitor']) : '';
		$product->update_meta_data('_wwp_hide_for_visitor', esc_attr($_wwp_hide_for_visitor));
		
		$wwp_icon_url = isset($_POST['wwp_icon_url']) ? wc_clean($_POST['wwp_icon_url']) : '';
		$product->update_meta_data('wwp_icon_url', esc_attr($wwp_icon_url));
		
		$wwp_image_url = isset($_POST['wwp_image_url']) ? wc_clean($_POST['wwp_image_url']) : '';
		$product->update_meta_data('wwp_image_url', esc_attr($wwp_image_url));
		
		$wwp_attachment_title = isset($_POST['wwp_attachment_title']) ? wc_clean($_POST['wwp_attachment_title']) : '';
		$product->update_meta_data('wwp_attachment_title', esc_attr($wwp_attachment_title));
		
		$wwp_attachment_text_link = isset($_POST['wwp_attachment_text_link']) ? wc_clean($_POST['wwp_attachment_text_link']) : '';
		$product->update_meta_data('wwp_attachment_text_link', esc_attr($wwp_attachment_text_link));
		
		$wwp_variation_explode_eneble = isset($_POST['wwp_variation_explode_eneble']) ? wc_clean($_POST['wwp_variation_explode_eneble']) : '';
		$product->update_meta_data('wwp_variation_explode_eneble', esc_attr($wwp_variation_explode_eneble));
		
		$wwp_variation_attribute_with_qty = isset($_POST['wwp_variation_attribute_with_qty']) ? wc_clean($_POST['wwp_variation_attribute_with_qty']) : '';
		$product->update_meta_data('wwp_variation_attribute_with_qty', esc_attr($wwp_variation_attribute_with_qty));
		
		$sample_product_id_hidden = isset($_POST['sample_product_id_hidden']) ? wc_clean($_POST['sample_product_id_hidden']) : '';
		$product->update_meta_data('sample_product_id_hidden', esc_attr($sample_product_id_hidden));
		
		$sample_product_id = isset($_POST['sample_product_id']) ? wc_clean($_POST['sample_product_id']) : '';
		$product->update_meta_data('sample_product_id', esc_attr($sample_product_id));
		
		$request_for_sample_enable = isset($_POST['request_for_sample_enable']) ? wc_clean($_POST['request_for_sample_enable']) : '';
		$product->update_meta_data('request_for_sample_enable', esc_attr($request_for_sample_enable));
		
		$product->save();
	}

	/**
	 * Registers the 'Wholesale User Pricing' meta box on the product edit screen.
	 *
	 * @return void
	 */
	public function callback() {
		add_meta_box(
			'wholesale-pricing-pro-multiuser',
			esc_html__('Wholesale User Pricing', 'woocommerce-wholesale-pricing'),
			array( $this, 'metabox_callback' ),
			'product',
			'normal',
			'high'
		);
	}

	/**
	 * Renders the structure for the 'Wholesale User Pricing' meta box.
	 * The actual content is loaded via an AJAX call to `metabox_content`.
	 *
	 * @param  \WP_Post $post The current post object.
	 * @return void
	 */
	public function metabox_callback( \WP_Post $post ) {
		wp_nonce_field('wwp_wholesale_multi_user', 'wwp_wholesale_multi_user');
		?>
			<div class="" id="wholesale-multiuser-pricing">
				<input type="hidden" value="<?php esc_attr_e($post->ID); ?>" name="product_id">
				<div class="wholesale_loader"></div>
				<div class="wholesale_container"></div>
			</div>
		<?php
	}

	/**
	 * AJAX handler to retrieve and render the meta box content based on product type.
	 *
	 * @return void
	 */
	public function metabox_content() {

		check_ajax_referer('wwp_wholesale_pricing', 'security');

		if (! isset($_POST['product_id']) && ! is_numeric($_POST['product_id']) && ! isset($_POST['ptype']) && empty($_POST['ptype']) ) {
			die();
		}
		$settings        = self::get_pricing_settings();
		$product_id      = wc_clean($_POST['product_id']);
		$ptype           = wc_clean($_POST['ptype']);
		$data            = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
		$wholesale_type  = get_post_meta($product_id, '_wwp_wholesale_type', true);
		$wholesale_price = get_post_meta($product_id, '_wwp_wholesale_amount', true);
		$roles           = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
		$rolehtml        = '';

		if ('variable' == $ptype || 'variable-subscription' == $ptype ) {
			$rolehtml     = $this->get_variable_product_wholesale($product_id, $roles, $ptype);
		} elseif (! empty($roles) ) { 
			$product_tier_pricing = get_post_meta($product_id, 'product_tier_pricing', true);
			if ('variable' === \WC_Product_Factory::get_product_type($product_id) || 'variable-subscription' === \WC_Product_Factory::get_product_type($product_id) ) {
				$product_tier_pricing = array();
			}

			wwp_view('admin.product.simple', compact('roles', 'data', 'wholesale_type', 'wholesale_price', 'settings', 'product_tier_pricing', 'product_id'));
		} else {
			esc_html_e('Please add Wholesale user roles first', 'woocommerce-wholesale-pricing');
		}
		die();
	}

	/**
	 * Retrieves and renders the wholesale pricing fields for variable products.
	 *
	 * @param  int    $product_id The product ID.
	 * @param  array  $roles      Array of wholesale user role term objects.
	 * @param  string $ptype      The product type slug.
	 * @return void
	 */
	public function get_variable_product_wholesale( $product_id, $roles, $ptype ) {
		if (! empty($product_id) && ! empty($roles) ) {
		
			$wholesale_type       = get_post_meta($product_id, '_wwp_wholesale_type', true);
			$data                 = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
			$product_tier_pricing = get_post_meta($product_id, 'product_tier_pricing', true);
			$tickets              = new \WC_Product_Variable($product_id);
			$variables            = $tickets->get_children();
			$settings             = self::get_pricing_settings();

			if (! empty($variables) ) {
				wwp_view('admin.product.variable', compact('roles', 'data', 'settings', 'product_tier_pricing', 'wholesale_type', 'variables', 'product_id', 'product_tier_pricing', 'ptype'));
			} else {
				esc_html_e('No variations found. Add variations before.', 'woocommerce-wholesale-pricing');
			}
		} else {
			esc_html_e('Wholesale Roles not found', 'woocommerce-wholesale-pricing');
		}
	}

	/**
	 * Handles saving all wholesale user pricing and visibility meta when a product post is saved.
	 *
	 * @param  int $post_id The ID of the post being saved.
	 * @return void
	 */
	public function update_product( $post_id ) {
		// Autosave
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
			return;
		}
		// AJAX
		if (defined('DOING_AJAX') && DOING_AJAX ) {
			return;
		}
		if (! isset($_POST['wwp_wholesale_multi_user']) || ! wp_verify_nonce(wc_clean($_POST['wwp_wholesale_multi_user']), 'wwp_wholesale_multi_user') ) {
			return;
		}
		$roles = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
		
		$product_tier_pricing = array();

		if (isset($_POST['product_tier_pricing']) && !empty($_POST['product_tier_pricing']['tier_pricing']) ) {
			$product_tier_pricing = wwp_sanitize_tier_prices( wc_clean($_POST['product_tier_pricing']['tier_pricing']) );
		}
		$product = wc_get_product($post_id); 
		
		$data = array();
		if (! empty($roles) ) {
			if (isset($_POST['product-type']) && isset($_POST['wholesale_product_type']) && ( 'variable' == wc_clean($_POST['wholesale_product_type']) || 'variable-subscription' == wc_clean($_POST['wholesale_product_type']) ) ) {
				
				$wholesale_product_type = wc_clean($_POST['wholesale_product_type']);
				if ('variable-subscription' == $wholesale_product_type ) {
					$tickets = new \WC_Product_Variable_Subscription($post_id);
				} else {
					$tickets   = new \WC_Product_Variable($post_id);
				}

				$variables = $tickets->get_available_variations();
				if (! empty($variables) ) {
					foreach ( $variables as $variable ) {
						$variation_id = $variable['variation_id'];
						if ('variable-subscription' == $wholesale_product_type ) {
							$variation_obj = new \WC_Product_Subscription_Variation($variation_id);
						} else {
							$variation_obj = new \WC_Product_Variation($variation_id);
						}
						$vary         = array();
						foreach ( $roles as $key => $role ) {
							if (! isset($_POST[ 'role_' . $role->term_id ]) ) {
								continue;
							}
							if (isset($_POST[ 'role_' . $role->term_id ]) ) {
								$data[ $role->term_id ]['slug'] = $role->slug;
								$vary[ $role->term_id ]['slug'] = $role->slug;
							}
							if (isset($_POST[ 'discount_type_' . $role->term_id ]) ) {
								$data[ $role->term_id ]['discount_type'] = wc_clean($_POST[ 'discount_type_' . $role->term_id ]);
								$vary[ $role->term_id ]['discount_type'] = wc_clean($_POST[ 'discount_type_' . $role->term_id ]);
							}
							if (isset($_POST[ 'wholesaleprice_' . $role->term_id . '_' . $variation_id ]) ) {
								$variation_wholesale_price = sanitize_text_field( wp_unslash( $_POST[ 'wholesaleprice_' . $role->term_id . '_' . $variation_id ] ) );
								$data[ $role->term_id ][ $variation_id ]['wholesaleprice'] = wwp_sanitize_price( $variation_wholesale_price );
								$vary[ $role->term_id ][ $variation_id ]['wholesaleprice'] = wwp_sanitize_price( $variation_wholesale_price );
							}
							if (isset($_POST[ 'qty_' . $role->term_id . '_' . $variation_id ]) ) {
								$data[ $role->term_id ][ $variation_id ]['qty'] = is_numeric(wc_clean($_POST[ 'qty_' . $role->term_id . '_' . $variation_id ])) ? wc_clean($_POST[ 'qty_' . $role->term_id . '_' . $variation_id ]) : 1;
								$vary[ $role->term_id ][ $variation_id ]['qty'] = is_numeric(wc_clean($_POST[ 'qty_' . $role->term_id . '_' . $variation_id ])) ? wc_clean($_POST[ 'qty_' . $role->term_id . '_' . $variation_id ]) : 1;
							}
							if (isset($_POST[ 'step_' . $role->term_id . '_' . $variation_id ]) ) {
								$data[ $role->term_id ][ $variation_id ]['step'] = is_numeric(wc_clean($_POST[ 'step_' . $role->term_id . '_' . $variation_id ])) ? wc_clean($_POST[ 'step_' . $role->term_id . '_' . $variation_id ]) : '';
								$vary[ $role->term_id ][ $variation_id ]['step'] = is_numeric(wc_clean($_POST[ 'step_' . $role->term_id . '_' . $variation_id ])) ? wc_clean($_POST[ 'step_' . $role->term_id . '_' . $variation_id ]) : '';
							}
						}
						
						$variation_obj->update_meta_data('wholesale_multi_user_pricing', $vary);
						$variation_obj->update_meta_data('product_tier_pricing', $product_tier_pricing);
						$variation_obj->save();
					}
					
					$product->update_meta_data('wholesale_multi_user_pricing', $data);
					$product->update_meta_data('product_tier_pricing', $product_tier_pricing);
				}
			} else {
				foreach ( $roles as $key => $role ) {
					if (! isset($_POST[ 'role_' . $role->term_id ]) ) {
						continue;
					}
					if (isset($_POST[ 'role_' . $role->term_id ]) ) {
						$data[ $role->term_id ]['slug'] = $role->slug;
					}
					if (isset($_POST[ 'discount_type_' . $role->term_id ]) ) {
						$data[ $role->term_id ]['discount_type'] = wc_clean($_POST[ 'discount_type_' . $role->term_id ]);
					}
					if (isset($_POST[ 'wholesale_price_' . $role->term_id ]) ) {
						$simple_wholesale_price = sanitize_text_field( wp_unslash( $_POST[ 'wholesale_price_' . $role->term_id ] ) );
						$data[ $role->term_id ]['wholesale_price'] = wwp_sanitize_price( $simple_wholesale_price );
					}
					if (isset($_POST[ 'min_quatity_' . $role->term_id ]) ) {
						$data[ $role->term_id ]['min_quatity'] = is_numeric(wc_clean($_POST[ 'min_quatity_' . $role->term_id ])) ? wc_clean($_POST[ 'min_quatity_' . $role->term_id ]) : 1;
					}
					if (isset($_POST[ 'step_quantity_' . $role->term_id ]) ) {
						$data[ $role->term_id ]['step_quantity'] = is_numeric(wc_clean($_POST[ 'step_quantity_' . $role->term_id ])) ? wc_clean($_POST[ 'step_quantity_' . $role->term_id ]) : '';
					}
				}
				
				$product->update_meta_data('wholesale_multi_user_pricing', $data);
				$product->update_meta_data('product_tier_pricing', $product_tier_pricing);
				
			}
		}
		if (isset($_POST['wholesale_product_visibility_multi']) ) {
			$product->update_meta_data('wholesale_product_visibility_multi', (array) wc_clean($_POST['wholesale_product_visibility_multi']));
		} else {
			$product->update_meta_data('wholesale_product_visibility_multi', '');
		}
		// $product->update_meta_data('wholesale_multi_user_pricing', $data);
		$product->save();
	}

	/**
	 * Determines if the dependency for this service is met.
	 * This service should only run in the WordPress administration area.
	 *
	 * @return bool True if the service should be registered, false otherwise.
	 */
	public static function resolveDependency() {
		return is_admin();
	}
}
