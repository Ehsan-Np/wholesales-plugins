<?php
/**
 * Programmatic CRUD for wholesale user roles (taxonomy + meta + WP roles).
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

/**
 * Shared service for wholesale_user_roles taxonomy operations.
 */
class WholesaleUserRoleService {

	/**
	 * Protected default role slug.
	 *
	 * @var string
	 */
	const DEFAULT_ROLE_SLUG = 'default_wholesaler';

	/**
	 * Term meta keys managed by this service.
	 *
	 * @var list<string>
	 */
	const META_KEYS = array(
		'wwp_tax_exmept_wholesaler',
		'wwp_wholesaler_tax_classes',
		'wwp_wholesale_disable_coupons',
		'wwp_wholesaler_subscription',
		'wwp_restricted_pmethods_wholesaler',
		'wwp_restricted_smethods_wholesaler',
		'password',
		'wwp_wholesale_payment_method_name',
		'wwp_user_request_approval',
		'wwp_conditions_enabled',
		'wwp_condition_location',
		'wwp_condition_countries',
		'wwp_condition_states',
		'wwp_condition_min_order',
		'wwp_condition_max_order',
		'wwp_po_enabled',
		'wwp_po_require_number',
		'wwp_po_allow_upload',
		'wwp_po_require_upload',
		'wwp_po_file_types',
		'wwp_po_max_file_size',
	);

	/**
	 * Get taxonomy slug.
	 *
	 * @return string
	 */
	public function get_taxonomy() {
		if ( function_exists( 'wwp_env' ) ) {
			$slug = (string) wwp_env()->get( 'role_taxonomy' );
			if ( '' !== $slug ) {
				return $slug;
			}
		}

		return 'wholesale_user_roles';
	}

	/**
	 * List all wholesale roles with meta.
	 *
	 * @return list<array<string, mixed>>
	 */
	public function list_roles() {
		$terms = get_terms(
			array(
				'taxonomy'   => $this->get_taxonomy(),
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
			return array();
		}

		return array_map( array( $this, 'format_role' ), $terms );
	}

	/**
	 * Get a single role by slug or term id.
	 *
	 * @param string|int $identifier Role slug or term id.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function get_role( $identifier ) {
		$term = $this->resolve_term( $identifier );
		if ( is_wp_error( $term ) ) {
			return $term;
		}

		return $this->format_role( $term );
	}

	/**
	 * Create a wholesale role.
	 *
	 * @param array<string, mixed> $data Role data.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function create_role( array $data ) {
		$name = isset( $data['name'] ) ? sanitize_text_field( (string) $data['name'] ) : '';
		if ( '' === $name ) {
			return new \WP_Error(
				'wwp_role_missing_name',
				__( 'Role name is required.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$slug = isset( $data['slug'] ) ? sanitize_title( (string) $data['slug'] ) : '';
		if ( '' === $slug ) {
			$slug = sanitize_title( $name );
		}

		$args = array( 'slug' => $slug );
		if ( isset( $data['description'] ) ) {
			$args['description'] = sanitize_textarea_field( (string) $data['description'] );
		}

		$result = wp_insert_term( $name, $this->get_taxonomy(), $args );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$term_id = (int) $result['term_id'];
		$term    = get_term( $term_id, $this->get_taxonomy() );
		if ( ! $term || is_wp_error( $term ) ) {
			return new \WP_Error(
				'wwp_role_create_failed',
				__( 'Failed to load created role.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		if ( ! wp_roles()->is_role( $term->slug ) ) {
			add_role(
				$term->slug,
				$term->name . esc_html__( ' - Wholesaler role', 'woocommerce-wholesale-pricing' ),
				array(
					'read'    => true,
					'level_0' => true,
				)
			);
		}

		$this->save_role_meta( $term_id, $data );

		return $this->format_role( get_term( $term_id, $this->get_taxonomy() ) );
	}

	/**
	 * Update a wholesale role.
	 *
	 * @param string|int           $identifier Role slug or term id.
	 * @param array<string, mixed> $data       Partial role data.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_role( $identifier, array $data ) {
		$term = $this->resolve_term( $identifier );
		if ( is_wp_error( $term ) ) {
			return $term;
		}

		if ( self::DEFAULT_ROLE_SLUG === $term->slug && isset( $data['slug'] ) ) {
			$new_slug = sanitize_title( (string) $data['slug'] );
			if ( '' !== $new_slug && self::DEFAULT_ROLE_SLUG !== $new_slug ) {
				return new \WP_Error(
					'wwp_role_protected',
					__( 'The default wholesaler role slug cannot be changed.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 403 )
				);
			}
		}

		$term_args = array();
		if ( isset( $data['name'] ) ) {
			$term_args['name'] = sanitize_text_field( (string) $data['name'] );
		}
		if ( isset( $data['slug'] ) ) {
			$term_args['slug'] = sanitize_title( (string) $data['slug'] );
		}
		if ( isset( $data['description'] ) ) {
			$term_args['description'] = sanitize_textarea_field( (string) $data['description'] );
		}

		$old_slug = $term->slug;
		$old_name = $term->name;

		if ( ! empty( $term_args ) ) {
			$result = wp_update_term( $term->term_id, $this->get_taxonomy(), $term_args );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		$term = get_term( $term->term_id, $this->get_taxonomy() );
		if ( ! $term || is_wp_error( $term ) ) {
			return new \WP_Error(
				'wwp_role_update_failed',
				__( 'Failed to load updated role.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		$new_slug = $term->slug;
		$new_name = $term->name;
		if ( $new_slug !== $old_slug || $new_name !== $old_name ) {
			$this->sync_wp_role( $old_slug, $new_slug, $new_name );
		} elseif ( ! wp_roles()->is_role( $new_slug ) ) {
			add_role(
				$new_slug,
				$new_name . esc_html__( ' - Wholesaler role', 'woocommerce-wholesale-pricing' ),
				array(
					'read'    => true,
					'level_0' => true,
				)
			);
		}

		$this->save_role_meta( $term->term_id, $data );

		return $this->format_role( get_term( $term->term_id, $this->get_taxonomy() ) );
	}

	/**
	 * Delete a wholesale role.
	 *
	 * @param string|int $identifier Role slug or term id.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function delete_role( $identifier ) {
		$term = $this->resolve_term( $identifier );
		if ( is_wp_error( $term ) ) {
			return $term;
		}

		if ( self::DEFAULT_ROLE_SLUG === $term->slug ) {
			return new \WP_Error(
				'wwp_role_protected',
				__( 'The default wholesaler role cannot be deleted.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		$slug = $term->slug;
		$result = wp_delete_term( $term->term_id, $this->get_taxonomy() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( wp_roles()->is_role( $slug ) ) {
			remove_role( $slug );
		}

		return array(
			'deleted' => true,
			'slug'    => $slug,
		);
	}

	/**
	 * Save role meta from normalized data.
	 *
	 * @param int                  $term_id Term id.
	 * @param array<string, mixed> $data    Role data (partial allowed).
	 * @return void
	 */
	public function save_role_meta( $term_id, $data ) {
		if ( array_key_exists( 'tax_exempt', $data ) ) {
			update_term_meta(
				$term_id,
				'wwp_tax_exmept_wholesaler',
				$this->bool_to_yes_no( $data['tax_exempt'] )
			);
		}

		if ( array_key_exists( 'role_tax_exempt', $data ) ) {
			$tax_class = sanitize_text_field( (string) $data['role_tax_exempt'] );
			if ( '' !== $tax_class && ! $this->is_valid_tax_class( $tax_class ) ) {
				$tax_class = '';
			}
			update_term_meta( $term_id, 'wwp_wholesaler_tax_classes', $tax_class );
		}

		if ( array_key_exists( 'disable_coupons', $data ) ) {
			update_term_meta(
				$term_id,
				'wwp_wholesale_disable_coupons',
				$this->bool_to_yes_no( $data['disable_coupons'] )
			);
		}

		if ( array_key_exists( 'subscription_variation_id', $data ) ) {
			update_term_meta(
				$term_id,
				'wwp_wholesaler_subscription',
				sanitize_text_field( (string) $data['subscription_variation_id'] )
			);
		}

		if ( array_key_exists( 'disabled_payment_methods', $data ) ) {
			$methods = $this->sanitize_string_list( $data['disabled_payment_methods'] );
			update_term_meta( $term_id, 'wwp_restricted_pmethods_wholesaler', $methods );
		}

		if ( array_key_exists( 'disabled_shipping_methods', $data ) ) {
			$methods = $this->sanitize_string_list( $data['disabled_shipping_methods'] );
			update_term_meta( $term_id, 'wwp_restricted_smethods_wholesaler', $methods );
		}

		if ( array_key_exists( 'password', $data ) ) {
			update_term_meta( $term_id, 'password', wc_clean( (string) $data['password'] ) );
		}

		if ( array_key_exists( 'payment_methods', $data ) ) {
			$payment_methods = $this->sanitize_payment_methods( $data['payment_methods'] );
			update_term_meta( $term_id, 'wwp_wholesale_payment_method_name', $payment_methods );
		}

		if ( array_key_exists( 'user_request_approval', $data ) ) {
			update_term_meta(
				$term_id,
				'wwp_user_request_approval',
				$this->sanitize_user_request_approval( $data['user_request_approval'] )
			);
		}

		if ( array_key_exists( 'conditions_enabled', $data ) ) {
			update_term_meta( $term_id, 'wwp_conditions_enabled', $this->bool_to_yes_no( $data['conditions_enabled'] ) );
		}

		if ( array_key_exists( 'condition_location', $data ) ) {
			update_term_meta( $term_id, 'wwp_condition_location', $this->sanitize_condition_location( $data['condition_location'] ) );
		}

		if ( array_key_exists( 'condition_countries', $data ) ) {
			update_term_meta( $term_id, 'wwp_condition_countries', $this->sanitize_string_list( $data['condition_countries'] ) );
		}

		if ( array_key_exists( 'condition_states', $data ) ) {
			update_term_meta( $term_id, 'wwp_condition_states', $this->sanitize_string_list( $data['condition_states'] ) );
		}

		if ( array_key_exists( 'condition_min_order', $data ) ) {
			update_term_meta( $term_id, 'wwp_condition_min_order', $this->sanitize_order_total( $data['condition_min_order'] ) );
		}

		if ( array_key_exists( 'condition_max_order', $data ) ) {
			update_term_meta( $term_id, 'wwp_condition_max_order', $this->sanitize_order_total( $data['condition_max_order'] ) );
		}

		if ( array_key_exists( 'po_enabled', $data ) ) {
			update_term_meta( $term_id, 'wwp_po_enabled', $this->bool_to_yes_no( $data['po_enabled'] ) );
		}

		if ( array_key_exists( 'po_require_number', $data ) ) {
			update_term_meta( $term_id, 'wwp_po_require_number', $this->bool_to_yes_no( $data['po_require_number'] ) );
		}

		if ( array_key_exists( 'po_allow_upload', $data ) ) {
			update_term_meta( $term_id, 'wwp_po_allow_upload', $this->bool_to_yes_no( $data['po_allow_upload'] ) );
		}

		if ( array_key_exists( 'po_require_upload', $data ) ) {
			$require_upload = filter_var( $data['po_require_upload'], FILTER_VALIDATE_BOOLEAN );
			if ( array_key_exists( 'po_allow_upload', $data ) && ! filter_var( $data['po_allow_upload'], FILTER_VALIDATE_BOOLEAN ) ) {
				$require_upload = false;
			}
			update_term_meta( $term_id, 'wwp_po_require_upload', $this->bool_to_yes_no( $require_upload ) );
		}

		if ( array_key_exists( 'po_file_types', $data ) ) {
			update_term_meta( $term_id, 'wwp_po_file_types', $this->sanitize_po_file_types( $data['po_file_types'] ) );
		}

		if ( array_key_exists( 'po_max_file_size', $data ) ) {
			update_term_meta( $term_id, 'wwp_po_max_file_size', $this->sanitize_po_max_file_size( $data['po_max_file_size'] ) );
		}
	}

	/**
	 * Restore meta from a stored snapshot.
	 *
	 * @param int                  $term_id Term id.
	 * @param array<string, mixed> $meta    Stored meta values keyed by normalized field names.
	 * @return void
	 */
	public function restore_role_meta( $term_id, $meta ) {
		$this->save_role_meta( $term_id, $meta );
	}

	/**
	 * Format a term for API/ability output.
	 *
	 * @param \WP_Term $term Term object.
	 * @return array<string, mixed>
	 */
	public function format_role( \WP_Term $term ) {
		$term_id = (int) $term->term_id;
		$meta    = $this->get_role_meta( $term_id );

		$formatted = array(
			'term_id'     => $term_id,
			'name'        => $term->name,
			'slug'        => $term->slug,
			'description' => $term->description,
			'user_count'  => $this->get_user_count( $term->slug ),
			'tax_exempt'  => 'yes' === ( isset( $meta['wwp_tax_exmept_wholesaler'] ) ? $meta['wwp_tax_exmept_wholesaler'] : 'no' ),
			'role_tax_exempt' => (string) ( isset( $meta['wwp_wholesaler_tax_classes'] ) ? $meta['wwp_wholesaler_tax_classes'] : '' ),
			'disable_coupons' => 'yes' === ( isset( $meta['wwp_wholesale_disable_coupons'] ) ? $meta['wwp_wholesale_disable_coupons'] : 'no' ),
			'payment_methods' => $this->format_payment_methods_for_output( isset( $meta['wwp_wholesale_payment_method_name'] ) ? $meta['wwp_wholesale_payment_method_name'] : array() ),
			'disabled_payment_methods' => $this->normalize_meta_array( isset( $meta['wwp_restricted_pmethods_wholesaler'] ) ? $meta['wwp_restricted_pmethods_wholesaler'] : array() ),
			'disabled_shipping_methods' => $this->normalize_meta_array( isset( $meta['wwp_restricted_smethods_wholesaler'] ) ? $meta['wwp_restricted_smethods_wholesaler'] : array() ),
			'password' => (string) ( isset( $meta['password'] ) ? $meta['password'] : '' ),
			'user_request_approval' => $this->sanitize_user_request_approval( isset( $meta['wwp_user_request_approval'] ) ? $meta['wwp_user_request_approval'] : 'manual' ),
			'conditions_enabled'    => 'yes' === ( isset( $meta['wwp_conditions_enabled'] ) ? $meta['wwp_conditions_enabled'] : 'no' ),
			'condition_location'    => $this->sanitize_condition_location( isset( $meta['wwp_condition_location'] ) ? $meta['wwp_condition_location'] : 'shipping' ),
			'condition_countries'   => $this->normalize_meta_array( isset( $meta['wwp_condition_countries'] ) ? $meta['wwp_condition_countries'] : array() ),
			'condition_states'      => $this->normalize_meta_array( isset( $meta['wwp_condition_states'] ) ? $meta['wwp_condition_states'] : array() ),
			'condition_min_order'   => (string) ( isset( $meta['wwp_condition_min_order'] ) ? $meta['wwp_condition_min_order'] : '' ),
			'condition_max_order'   => (string) ( isset( $meta['wwp_condition_max_order'] ) ? $meta['wwp_condition_max_order'] : '' ),
			'po_enabled'            => 'yes' === ( isset( $meta['wwp_po_enabled'] ) ? $meta['wwp_po_enabled'] : 'no' ),
			'po_require_number'      => 'yes' === ( isset( $meta['wwp_po_require_number'] ) ? $meta['wwp_po_require_number'] : 'no' ),
			'po_allow_upload'       => 'yes' === ( isset( $meta['wwp_po_allow_upload'] ) ? $meta['wwp_po_allow_upload'] : 'no' ),
			'po_require_upload'     => 'yes' === ( isset( $meta['wwp_po_require_upload'] ) ? $meta['wwp_po_require_upload'] : 'no' ),
			'po_file_types'         => $this->sanitize_po_file_types( isset( $meta['wwp_po_file_types'] ) ? $meta['wwp_po_file_types'] : array() ),
			'po_max_file_size'      => $this->sanitize_po_max_file_size( isset( $meta['wwp_po_max_file_size'] ) ? $meta['wwp_po_max_file_size'] : 5 ),
		);

		$subscription_id = (string) ( isset( $meta['wwp_wholesaler_subscription'] ) ? $meta['wwp_wholesaler_subscription'] : '' );
		if ( $this->subscription_field_available() ) {
			$formatted['subscription_variation_id'] = $subscription_id;
		}

		return $formatted;
	}

	/**
	 * Full snapshot for undo (term args + meta).
	 *
	 * @param string|int $identifier Role slug or term id.
	 * @return array<string, mixed>|null
	 */
	public function snapshot_role( $identifier ) {
		$term = $this->resolve_term( $identifier );
		if ( is_wp_error( $term ) ) {
			return null;
		}

		$meta = $this->get_role_meta( (int) $term->term_id );

		return array(
			'term_id' => (int) $term->term_id,
			'args'    => array(
				'name'        => $term->name,
				'slug'        => $term->slug,
				'description' => $term->description,
			),
			'meta'    => array(
				'tax_exempt'                  => 'yes' === ( isset( $meta['wwp_tax_exmept_wholesaler'] ) ? $meta['wwp_tax_exmept_wholesaler'] : 'no' ),
				'role_tax_exempt'             => (string) ( isset( $meta['wwp_wholesaler_tax_classes'] ) ? $meta['wwp_wholesaler_tax_classes'] : '' ),
				'disable_coupons'             => 'yes' === ( isset( $meta['wwp_wholesale_disable_coupons'] ) ? $meta['wwp_wholesale_disable_coupons'] : 'no' ),
				'payment_methods'             => $this->format_payment_methods_for_output( isset( $meta['wwp_wholesale_payment_method_name'] ) ? $meta['wwp_wholesale_payment_method_name'] : array() ),
				'disabled_payment_methods'    => $this->normalize_meta_array( isset( $meta['wwp_restricted_pmethods_wholesaler'] ) ? $meta['wwp_restricted_pmethods_wholesaler'] : array() ),
				'disabled_shipping_methods'   => $this->normalize_meta_array( isset( $meta['wwp_restricted_smethods_wholesaler'] ) ? $meta['wwp_restricted_smethods_wholesaler'] : array() ),
				'password'                    => (string) ( isset($meta['password']) ? $meta['password'] : '' ),
				'subscription_variation_id'   => (string) ( isset($meta['wwp_wholesaler_subscription']) ? $meta['wwp_wholesaler_subscription'] : '' ),
				'user_request_approval'        => $this->sanitize_user_request_approval( isset( $meta['wwp_user_request_approval'] ) ? $meta['wwp_user_request_approval'] : 'manual' ),
				'conditions_enabled'            => 'yes' === ( isset( $meta['wwp_conditions_enabled'] ) ? $meta['wwp_conditions_enabled'] : 'no' ),
				'condition_location'            => $this->sanitize_condition_location( isset( $meta['wwp_condition_location'] ) ? $meta['wwp_condition_location'] : 'shipping' ),
				'condition_countries'           => $this->normalize_meta_array( isset( $meta['wwp_condition_countries'] ) ? $meta['wwp_condition_countries'] : array() ),
				'condition_states'              => $this->normalize_meta_array( isset( $meta['wwp_condition_states'] ) ? $meta['wwp_condition_states'] : array() ),
				'condition_min_order'           => (string) ( isset( $meta['wwp_condition_min_order'] ) ? $meta['wwp_condition_min_order'] : '' ),
				'condition_max_order'           => (string) ( isset( $meta['wwp_condition_max_order'] ) ? $meta['wwp_condition_max_order'] : '' ),
				'po_enabled'                    => 'yes' === ( isset( $meta['wwp_po_enabled'] ) ? $meta['wwp_po_enabled'] : 'no' ),
				'po_require_number'            => 'yes' === ( isset( $meta['wwp_po_require_number'] ) ? $meta['wwp_po_require_number'] : 'no' ),
				'po_allow_upload'               => 'yes' === ( isset( $meta['wwp_po_allow_upload'] ) ? $meta['wwp_po_allow_upload'] : 'no' ),
				'po_require_upload'             => 'yes' === ( isset( $meta['wwp_po_require_upload'] ) ? $meta['wwp_po_require_upload'] : 'no' ),
				'po_file_types'                 => $this->sanitize_po_file_types( isset( $meta['wwp_po_file_types'] ) ? $meta['wwp_po_file_types'] : array() ),
				'po_max_file_size'              => $this->sanitize_po_max_file_size( isset( $meta['wwp_po_max_file_size'] ) ? $meta['wwp_po_max_file_size'] : 5 ),
			),
		);
	}

	/**
	 * Map admin $_POST to normalized role meta payload.
	 *
	 * @return array<string, mixed>
	 */
	public function map_post_to_role_meta() {
		$post = wwp_get_post_data();
		$tax_exempt = filter_input( INPUT_POST, 'wwp_tax_exmept_wholesaler', FILTER_SANITIZE_SPECIAL_CHARS );
		$disable_coupons = filter_input( INPUT_POST, 'wwp_wholesale_disable_coupons', FILTER_SANITIZE_SPECIAL_CHARS );
		$role_tax_exempt = filter_input( INPUT_POST, 'wwp_wholesaler_tax_classes', FILTER_SANITIZE_SPECIAL_CHARS );
		$password = filter_input( INPUT_POST, 'password', FILTER_SANITIZE_SPECIAL_CHARS );

		$wwp_wholesaler_subscription = filter_input( INPUT_POST, 'wwp_wholesaler_subscription', FILTER_SANITIZE_SPECIAL_CHARS );
		$wwp_user_request_approval  = filter_input( INPUT_POST, 'wwp_user_request_approval', FILTER_SANITIZE_SPECIAL_CHARS );

		// Array POST fields — filter_input() cannot read these.
		$wwp_restricted_pmethods_wholesaler = isset( $post['wwp_restricted_pmethods_wholesaler'] )
			? wc_clean( wp_unslash( $post['wwp_restricted_pmethods_wholesaler'] ) )
			: null;
		$wwp_restricted_smethods_wholesaler = isset( $post['wwp_restricted_smethods_wholesaler'] )
			? wc_clean( wp_unslash( $post['wwp_restricted_smethods_wholesaler'] ) )
			: null;
		$wwp_wholesale_payment_method_name = isset( $post['wwp_wholesale_payment_method_name'] )
			? wc_clean( wp_unslash( $post['wwp_wholesale_payment_method_name'] ) )
			: null;
		$wwp_condition_countries = isset( $post['wwp_condition_countries'] )
			? wc_clean( wp_unslash( $post['wwp_condition_countries'] ) )
			: array();
		$wwp_condition_states = isset( $post['wwp_condition_states'] )
			? wc_clean( wp_unslash( $post['wwp_condition_states'] ) )
			: array();


		$data = array(
			'tax_exempt'        => isset( $tax_exempt ),
			'disable_coupons'   => isset( $disable_coupons ),
			'role_tax_exempt'   => isset( $role_tax_exempt ) ? wc_clean( wp_unslash( $role_tax_exempt ) ) : '',
			'password'          => isset( $password ) ? wc_clean( wp_unslash( $password ) ) : '',
		);

		if ( isset( $wwp_wholesaler_subscription ) ) {
			$data['subscription_variation_id'] = wc_clean( wp_unslash( $wwp_wholesaler_subscription ) );
		}

		if ( isset( $wwp_user_request_approval ) ) {
			$data['user_request_approval'] = $this->sanitize_user_request_approval( $wwp_user_request_approval );
		}

		if ( isset( $wwp_restricted_pmethods_wholesaler ) ) {
			$data['disabled_payment_methods'] = is_array( $wwp_restricted_pmethods_wholesaler )
				? $wwp_restricted_pmethods_wholesaler
				: array();
		} else {
			$data['disabled_payment_methods'] = array();
		}

		if ( isset( $wwp_restricted_smethods_wholesaler ) ) {
			$data['disabled_shipping_methods'] = is_array( $wwp_restricted_smethods_wholesaler )
				? $wwp_restricted_smethods_wholesaler
				: array();
		} else {
			$data['disabled_shipping_methods'] = array();
		}

		if ( isset( $wwp_wholesale_payment_method_name ) ) {
			$data['payment_methods'] = is_array( $wwp_wholesale_payment_method_name )
				? $wwp_wholesale_payment_method_name
				: array();
		} else {
			$data['payment_methods'] = array();
		}

		$data['conditions_enabled']  = isset( $post['wwp_conditions_enabled'] ) && 'yes' === $post['wwp_conditions_enabled'];
		$data['condition_location']  = isset( $post['wwp_condition_location'] ) ? wc_clean( wp_unslash( $post['wwp_condition_location'] ) ) : 'shipping';
		$data['condition_countries'] = is_array( $wwp_condition_countries ) ? $wwp_condition_countries : array();
		$data['condition_states']    = is_array( $wwp_condition_states ) ? $wwp_condition_states : array();
		$data['condition_min_order'] = isset( $post['wwp_condition_min_order'] ) ? wc_clean( wp_unslash( $post['wwp_condition_min_order'] ) ) : '';
		$data['condition_max_order'] = isset( $post['wwp_condition_max_order'] ) ? wc_clean( wp_unslash( $post['wwp_condition_max_order'] ) ) : '';

		$wwp_po_file_types = isset( $post['wwp_po_file_types'] )
			? wc_clean( wp_unslash( $post['wwp_po_file_types'] ) )
			: array();

		$data['po_enabled']        = isset( $post['wwp_po_enabled'] ) && 'yes' === $post['wwp_po_enabled'];
		$data['po_require_number'] = isset( $post['wwp_po_require_number'] ) && 'yes' === $post['wwp_po_require_number'];
		$data['po_allow_upload']  = isset( $post['wwp_po_allow_upload'] ) && 'yes' === $post['wwp_po_allow_upload'];
		$data['po_require_upload'] = $data['po_allow_upload'] && isset( $post['wwp_po_require_upload'] ) && 'yes' === $post['wwp_po_require_upload'];
		$data['po_file_types']    = is_array( $wwp_po_file_types ) ? $wwp_po_file_types : array();
		$data['po_max_file_size'] = isset( $post['wwp_po_max_file_size'] ) ? wc_clean( wp_unslash( $post['wwp_po_max_file_size'] ) ) : '5';

		return $data;
	}

	/**
	 * Sync WordPress role when taxonomy slug/name changes.
	 *
	 * @param string $old_slug Previous slug.
	 * @param string $new_slug New slug.
	 * @param string $new_name New display name.
	 * @return void
	 */
	public function sync_wp_role( $old_slug, $new_slug, $new_name ) {
		if ( wp_roles()->is_role( $old_slug ) ) {
			remove_role( $old_slug );
		}

		if ( ! wp_roles()->is_role( $new_slug ) ) {
			add_role(
				$new_slug,
				$new_name . esc_html__( ' - Wholesaler role', 'woocommerce-wholesale-pricing' ),
				array(
					'read'    => true,
					'level_0' => true,
				)
			);
		}

		$users = get_users( array( 'role' => $old_slug ) );
		if ( ! empty( $users ) ) {
			foreach ( $users as $user ) {
				$wp_user = new \WP_User( $user->ID );
				$wp_user->remove_role( $old_slug );
				$wp_user->remove_cap( $old_slug );
				$wp_user->add_role( $new_slug );
				$wp_user->add_cap( $new_slug );
				wp_cache_delete( $user->ID, 'users' );
			}
		}
	}

	/**
	 * Resolve a term by slug or id.
	 *
	 * @param string|int $identifier Identifier.
	 * @return \WP_Term|\WP_Error
	 */
	private function resolve_term( $identifier ) {
		$taxonomy = $this->get_taxonomy();

		if ( is_numeric( $identifier ) ) {
			$term = get_term( (int) $identifier, $taxonomy );
		} else {
			$term = get_term_by( 'slug', sanitize_title( (string) $identifier ), $taxonomy );
		}

		if ( ! $term || is_wp_error( $term ) ) {
			return new \WP_Error(
				'wwp_role_not_found',
				__( 'Wholesale role not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		return $term;
	}

	/**
	 * Read all managed meta for a term.
	 *
	 * @param int $term_id Term id.
	 * @return array<string, mixed>
	 */
	private function get_role_meta( $term_id ) {
		$meta = array();
		foreach ( self::META_KEYS as $key ) {
			$meta[ $key ] = get_term_meta( $term_id, $key, true );
		}
		return $meta;
	}

	/**
	 * Convert bool to yes/no storage format.
	 *
	 * @param mixed $value Input value.
	 * @return string
	 */
	private function bool_to_yes_no( $value ) {
		return filter_var( $value, FILTER_VALIDATE_BOOLEAN ) ? 'yes' : 'no';
	}

	/**
	 * Sanitize user request approval mode.
	 *
	 * @param mixed $value Input value.
	 * @return string auto|manual
	 */
	private function sanitize_user_request_approval( $value ) {
		$value = is_string( $value ) ? $value : 'manual';
		return in_array( $value, array( 'auto', 'manual' ), true ) ? $value : 'manual';
	}

	/**
	 * Sanitize optional order total.
	 *
	 * @param mixed $value Input value.
	 * @return string
	 */
	private function sanitize_condition_location( $value ) {
		$value = is_string( $value ) ? $value : 'shipping';
		return in_array( $value, array( 'billing', 'shipping' ), true ) ? $value : 'shipping';
	}

	private function sanitize_order_total( $value ) {
		if ( '' === $value || null === $value ) {
			return '';
		}
		$value = wc_format_decimal( $value );
		return ( is_numeric( $value ) && (float) $value > 0 ) ? (string) $value : '';
	}

	/**
	 * Allowed PO upload extensions (no leading dot).
	 *
	 * @return list<string>
	 */
	private function get_allowed_po_file_types() {
		return array( 'pdf', 'jpg', 'jpeg', 'png', 'csv', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'rtf', 'zip' );
	}

	/**
	 * Sanitize PO file type list.
	 *
	 * @param mixed $value Input value.
	 * @return list<string>
	 */
	private function sanitize_po_file_types( $value ) {
		$clean = array();
		foreach ( $this->sanitize_string_list( $value ) as $ext ) {
			$ext = ltrim( strtolower( $ext ), '.' );
			if ( in_array( $ext, $this->get_allowed_po_file_types(), true ) ) {
				$clean[] = $ext;
			}
		}

		return array_values( array_unique( $clean ) );
	}

	/**
	 * Sanitize max PO upload size in MB.
	 *
	 * @param mixed $value Input value.
	 * @return string
	 */
	private function sanitize_po_max_file_size( $value ) {
		$size = absint( $value );
		return (string) ( $size > 0 ? $size : 5 );
	}

	/**
	 * Sanitize list of strings.
	 *
	 * @param mixed $value Input value.
	 * @return list<string>
	 */
	private function sanitize_string_list( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		return array_values(
			array_filter(
				array_map(
					static function ( $item ) {
						return sanitize_text_field( (string) $item );
					},
					$value
				)
			)
		);
	}

	/**
	 * Sanitize payment method toggles.
	 *
	 * @param mixed $value Input value.
	 * @return array<string, string>
	 */
	private function sanitize_payment_methods( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$allowed = $this->get_allowed_payment_method_keys();
		$clean   = array();

		foreach ( $value as $key => $enabled ) {
			$key = sanitize_text_field( (string) $key );
			if ( ! in_array( $key, $allowed, true ) ) {
				continue;
			}
			if ( filter_var( $enabled, FILTER_VALIDATE_BOOLEAN ) || 'yes' === $enabled ) {
				$clean[ $key ] = 'yes';
			}
		}

		return $clean;
	}

	/**
	 * Format stored payment methods for output.
	 *
	 * @param mixed $stored Stored meta.
	 * @return array<string, bool>
	 */
	private function format_payment_methods_for_output( $stored ) {
		if ( ! is_array( $stored ) ) {
			return array();
		}

		$output = array();
		foreach ( $stored as $key => $value ) {
			$output[ (string) $key ] = ( 'yes' === $value );
		}

		return $output;
	}

	/**
	 * Normalize meta that may be stored as array or empty string.
	 *
	 * @param mixed $value Stored value.
	 * @return list<string>
	 */
	private function normalize_meta_array( $value ) {
		if ( is_array( $value ) ) {
			return $this->sanitize_string_list( $value );
		}

		if ( is_string( $value ) && '' !== $value ) {
			return array( sanitize_text_field( $value ) );
		}

		return array();
	}

	/**
	 * Allowed payment method keys from plugin settings.
	 *
	 * @return list<string>
	 */
	private function get_allowed_payment_method_keys() {
		$settings = WholesaleSettingsHelper::get_pricing_settings();
		$methods  = isset($settings['payment_method_name']) ? $settings['payment_method_name'] : array();

		if ( ! is_array( $methods ) ) {
			return array();
		}

		return array_map( 'strval', array_keys( $methods ) );
	}

	/**
	 * Whether tax class slug is valid.
	 *
	 * @param string $slug Tax class slug.
	 * @return bool
	 */
	private function is_valid_tax_class( $slug ) {
		if ( '' === $slug ) {
			return true;
		}

		if ( ! class_exists( '\WC_Tax' ) ) {
			return true;
		}

		foreach ( \WC_Tax::get_tax_rate_classes() as $tax_class ) {
			if ( $tax_class->slug === $slug ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether subscription variation field is configured.
	 *
	 * @return bool
	 */
	private function subscription_field_available() {
		$settings = WholesaleSettingsHelper::get_pricing_settings();
		$product_id = ! empty( $settings['wholesale_subscription'] ) ? (int) $settings['wholesale_subscription'] : 0;

		return $product_id > 0 && 'publish' === get_post_status( $product_id );
	}

	/**
	 * Count users assigned to a role slug.
	 *
	 * @param string $slug Role slug.
	 * @return int
	 */
	private function get_user_count( $slug ) {
		$users = get_users( array( 'role__in' => array( $slug ) ) );
		return is_array( $users ) ? count( $users ) : 0;
	}
}
