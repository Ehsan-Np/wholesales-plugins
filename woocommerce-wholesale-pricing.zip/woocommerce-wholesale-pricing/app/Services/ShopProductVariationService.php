<?php
/**
 * ShopProductVariationService
 *
 * This service manages the AJAX functionality required to dynamically load and display
 * the tiered wholesale discount table when a user selects a variation on a variable
 * product page in the WooCommerce shop.
 *
 * @package    WooCommerceWholesalePricing\Services
 */
namespace WooCommerceWholesalePricing\App\Services;

/**
 * Service class for handling variation-specific wholesale pricing features on the shop frontend.
 *
 * Primarily focuses on the AJAX endpoint for dynamic tier pricing display.
 */
class ShopProductVariationService {

	/**
	 * ShopProductVariationService constructor.
	 *
	 * Registers the AJAX hooks for both logged-in users and guests to fetch the
	 * tiered discount table for a product variation.
	 */
	public function __construct() {
		add_action('wp_ajax_wwp_show_discount_list_product_variation', array( $this, 'discounts_table' ));
		add_action('wp_ajax_nopriv_wwp_show_discount_list_product_variation', array( $this, 'discounts_table' ));
	}

	/**
	 * AJAX callback to generate and output the tiered discount table HTML for a selected variation.
	 *
	 * This function performs nonce verification, product retrieval, tier price calculation,
	 * and HTML generation, then sends a JSON response before terminating the script.
	 *
	 * @return void Outputs JSON and terminates the script via wp_die().
	 */
	public function discounts_table() {

		if (isset($_POST['wwp_tier_nonce']) && wp_verify_nonce(sanitize_text_field($_POST['wwp_tier_nonce']), 'wwp_tier_load') ) {

			if (isset($_POST['variation_id']) && ! empty($_POST['variation_id']) ) {

				$variation_id = sanitize_text_field($_POST['variation_id']);
				$variation = wc_get_product($variation_id);
				$product_id = $variation->get_parent_id();
				$product = new \WC_Product_Variable($product_id);
				$role = get_current_user_role_id();
				
				/**
				 * Filter
				 * 
				 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
				 * 
				 * @since 3.1.0
				 */
				$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

				if ($product->get_type() == 'simple' ) {
					return;
				}

				$product_tier_pricing = wholesale_tire_prices($product);
				$html = '';

				// check tier for variable product
				if (isset($product_tier_pricing[ $role ][ $variation_id ])  ) {
					$i = 1;
					foreach ( $product_tier_pricing[ $role ][ $variation_id ] as $variation_data ) {
						$variation_product = wc_get_product($variation_id);

						$max_original_variation_price = get_post_meta($variation_id, $price_key, true);
						$max_wholesale_price = tire_get_type($variation_id, $product, $variation_data['price'], $max_original_variation_price, $product_tier_pricing[ $role ]['discount_type']);
						$max_wholesale_price = $this->apply_dynamic_raise_to_tier_price( $max_wholesale_price, $variation_product );
						$max_saving_percent = ( $max_original_variation_price - $max_wholesale_price ) / $max_original_variation_price * 100;
						$max_saving_percent = round($max_saving_percent);
						$max_wholesale_price = wwp_get_price_including_tax($product, array( 'price' => $max_wholesale_price ));
						$max_wholesale_price = wc_price($max_wholesale_price); 

						$product = $variation_product;

						// Generate the row HTML if conditions are met
						if (! empty($variation_data['min']) || ! empty($variation_data['max']) || 0 != $max_saving_percent ) {
							if (1 === $i ) {
								$html .= '<tr>
                                    <th>Variations</th>
                                    <th>Quantity</th>
                                    <th>Save Discount</th>
                                    <th>Price per unit</th>
                                </tr>';
							}

							$html .= '<tr class="wrap_' . esc_attr($variation_id) . ' row_tire" data-id="' . esc_attr($variation_id) . '" data-min="' . esc_attr($variation_data['min']) . '" data-max="' . esc_attr($variation_data['max']) . '">';
							$html .= '<td>' . wp_kses_post(wc_get_formatted_variation($product->get_variation_attributes(), true)) . '</td>';
							$html .= '<td>' . wp_kses_post($variation_data['min'] . '-' . $variation_data['max']) . '</td>';
							$html .= '<td>' . esc_attr($max_saving_percent) . '%</td>';
							$html .= '<td>' . wp_kses_post($max_wholesale_price) . '</td>';
							$html .= '</tr>';
						}

						$i++;
					}
				}

				// check tier for global setting
				if (isset($product_tier_pricing[ $role ])  ) {
					$i = 1;
					foreach ( $product_tier_pricing[ $role ] as $key => $variation_data ) {
						$variation_product = wc_get_product($variation_id);

						$max_original_variation_price = (float) get_post_meta($variation_id, $price_key, true);
						$variation_data_price = isset($variation_data['price']) ? floatval($variation_data['price']) : 0;

						$max_wholesale_price =  tire_get_type($variation_id, $product, $variation_data_price, $max_original_variation_price, $product_tier_pricing[ $role ]['discount_type']);
						$max_wholesale_price = $this->apply_dynamic_raise_to_tier_price( $max_wholesale_price, $variation_product );

						$max_saving_percent = floatval($max_original_variation_price - $max_wholesale_price) / $max_original_variation_price * 100;
						$max_saving_percent = round($max_saving_percent);
						$max_wholesale_price = wwp_get_price_including_tax($product, array( 'price' => $max_wholesale_price ));
						$max_wholesale_price = wc_price($max_wholesale_price); 

						$product = $variation_product;

						// Generate the row HTML if conditions are met
						if (! empty($variation_data['min']) || ! empty($variation_data['max']) || 0 != $max_saving_percent ) {
							if (1 === $i ) {
								$html .= '<tr>
                                    <th>Variations</th>
                                    <th>Quantity</th>
                                    <th>Save Discount</th>
                                    <th>Price per unit</th>
                                </tr>';
							}

							$html .= '<tr class="wrap_' . esc_attr($variation_id) . ' row_tire" data-id="' . esc_attr($variation_id) . '" data-min="' . esc_attr($variation_data['min']) . '" data-max="' . esc_attr($variation_data['max']) . '">';
							$html .= '<td>' . wp_kses_post(wc_get_formatted_variation($product->get_variation_attributes(), true)) . '</td>';
							$html .= '<td>' . wp_kses_post($variation_data['min'] . '-' . $variation_data['max']) . '</td>';
							$html .= '<td>' . esc_attr($max_saving_percent) . '%</td>';
							$html .= '<td>' . wp_kses_post($max_wholesale_price) . '</td>';
							$html .= '</tr>';
						}

						$i++;
					}
				}

				$status = array();
				$status['html'] = $html;
				echo json_encode($status);
				wp_die();
			}
		} else {
			echo json_encode('Security Error'); 
			wp_die();
		}
	}

	/**
	 * Apply Raise Percentage dynamic rules to tier table unit price.
	 *
	 * @param float|int|string $price   Tier wholesale unit price before raise.
	 * @param \WC_Product      $product Product context for rule matching.
	 * @return float
	 */
	private function apply_dynamic_raise_to_tier_price( $price, $product ) {
		$price = (float) $price;

		if ( ! $product instanceof \WC_Product || $price <= 0 ) {
			return $price;
		}

		$matcher_class = '\WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMatcher';
		if ( ! class_exists( $matcher_class ) ) {
			return $price;
		}

		if ( ! $matcher_class::has_wholesale_discount( $price, $product ) ) {
			return $price;
		}

		$matched = $matcher_class::get_matching_rules( 'raise-percentage', $product );
		if ( empty( $matched ) ) {
			return $price;
		}

		$raised = $price;
		foreach ( $matched as $rule ) {
			$increase = isset( $rule['price_increase'] ) ? absint( $rule['price_increase'] ) : 0;
			if ( $increase > 0 ) {
				$raised = $raised * ( 1 + ( $increase / 100 ) );
			}
		}

		return (float) apply_filters( 'wwp_dynamic_rule_raise_percentage_price', $raised, $price, $product, $matched );
	}
}
