<?php
/**
 * ProductService class.
 *
 * Manages the integration of wholesale pricing and visibility settings directly
 * into the WooCommerce product edit screens and product list table.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service for handling product-specific wholesale administration features.
 * 
 * @implements ServiceInterface
 */
class ProductService implements ServiceInterface {

	/**
	 * Includes methods for retrieving general wholesale settings.
	 */
	use WholesaleSettings;

	/**
	 * Constructor.
	 *
	 * Hooks into WooCommerce actions and filters to customize the product admin UI.
	 *
	 * @return void
	 */
	public function __construct() {
		// Add a custom column to the product list table.
		add_filter('manage_edit-product_columns', array( $this, 'change_columns_filter' ), 10, 1);
		
		// Populate the content of the custom column.
		add_action('manage_product_posts_custom_column', array( $this, 'manage_product_posts_custom_column' ), 10, 2);

		// Add the custom 'Wholesale' tab to the product data metabox.
		add_filter('woocommerce_product_data_tabs', array( $this, 'wwp_add_wholesale_product_data_tab' ), 99, 1);

		// Output the fields for the custom 'Wholesale' product data tab.
		add_action('woocommerce_product_data_panels', array( $this, 'wwp_add_wholesale_product_data_fields_multi' ));

		// Save the custom wholesale fields when the product is saved.
		add_action('woocommerce_process_product_meta', array( $this, 'wwp_woo_wholesale_fields_save_multi' ), 99);
	}

	/**
	 * Adds the "Wholesale Pricing On" column to the product list table.
	 *
	 * @hooked manage_edit-product_columns
	 * @param  array $columns Existing column headers.
	 * @return array Modified column headers.
	 */
	public function change_columns_filter( $columns ) {
		$columns['wholesale'] = esc_html__('Wholesale Pricing On', 'woocommerce-wholesale-pricing');
		return $columns; 
	}

	/**
	 * Renders the content for the custom 'wholesale' column.
	 *
	 * Displays buttons indicating whether wholesale pricing is applied to the
	 * product via product-level, category-level, or global settings for each role.
	 *
	 * @hooked manage_product_posts_custom_column
	 * @param  string $column     The current column key being rendered.
	 * @param  int    $product_id The ID of the product post.
	 * @return void
	 */
	public function manage_product_posts_custom_column( $column, $product_id ) {
		if ('wholesale' == $column ) {
			$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
			foreach ( $allterms as $allterm ) { 
				$role = $allterm->term_id;
				$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
				if (isset($data[ $role ]) ) { 
					?>
					<button class="wholesale_on button">
						<div class="border_on"></div><?php echo esc_attr($allterm->name); ?> Product
					</button>
					<?php 
				}
				$terms = get_the_terms($product_id, 'product_cat');
				if (! is_wp_error($terms) && ! empty($terms) ) {
					foreach ( $terms as $term ) {
						$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
						if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
							?>
							<button class="wholesale_on button">
								<div class="border_on"></div><?php echo esc_attr($allterm->name); ?> Category
							</button>
							<?php  
						}
					}
				}
				$data = self::get_multiuser_pricing_settings();
				if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
					?>
						<button class="wholesale_on button">
							<div class="border_on"></div><?php echo esc_attr($allterm->name); ?> Global
						</button>                        
					<?php 
				}   

			}
		}
	}

	 /**
	  * Adds the "Wholesale" tab to the WooCommerce Product Data metabox.
	  *
	  * @hooked woocommerce_product_data_tabs
	  * @param  array $product_data_tabs Existing product data tabs.
	  * @return array Modified product data tabs.
	  */
	public function wwp_add_wholesale_product_data_tab( $product_data_tabs ) {
		$product_data_tabs['wwp-wholesale-tab'] = array(
			'label'  => esc_html__('Wholesale', 'woocommerce-wholesale-pricing'),
			'target' => 'wwp_wholesale_product_data',
		);
		return $product_data_tabs;
	}

	/**
	 * Outputs the HTML content (fields) for the custom Wholesale product data panel.
	 *
	 * Assumes a global helper function `wwp_view()` exists to render the corresponding view file.
	 *
	 * @hooked woocommerce_product_data_panels
	 * @global \WP_Post $post The global post object (the product being edited).
	 * @return string The rendered HTML content.
	 */
	public function wwp_add_wholesale_product_data_fields_multi() {
		// version 1.3.0
		global $post;
		
		return wwp_view('admin.product.panel', compact('post'));
	}

	/**
	 * Saves the wholesale-specific product meta fields when the product is updated.
	 *
	 * Note: Wholesale pricing rules (wholesale_multi_user_pricing) are typically handled
	 * elsewhere in the plugin via a dedicated meta box or on a more granular level.
	 * This method focuses on visibility and sample request settings.
	 *
	 * @hooked woocommerce_process_product_meta
	 * @param  int $post_id The ID of the product post being saved.
	 * @return void
	 */
	public function wwp_woo_wholesale_fields_save_multi( $post_id ) {

		if (! isset($_POST['wwp_product_wholesale_nonce']) || ( isset($_POST['wwp_product_wholesale_nonce']) && ! wp_verify_nonce(wc_clean($_POST['wwp_product_wholesale_nonce']), 'wwp_product_wholesale_nonce') ) ) {
			return;
		}

		$product = wc_get_product($post_id); 

		// hide product for customer
		$_wwp_hide_for_customer = isset($_POST['_wwp_hide_for_customer']) ? wc_clean($_POST['_wwp_hide_for_customer']) : '';
		$product->update_meta_data('_wwp_hide_for_customer', esc_attr($_wwp_hide_for_customer));
		// hide product for visitor
		$_wwp_hide_for_visitor = isset($_POST['_wwp_hide_for_visitor']) ? wc_clean($_POST['_wwp_hide_for_visitor']) : '';
		$product->update_meta_data('_wwp_hide_for_visitor', esc_attr($_wwp_hide_for_visitor));
		
		$wwp_icon_url = isset($_POST['wwp_icon_url']) ? wc_clean($_POST['wwp_icon_url']) : '';
		$product->update_meta_data('wwp_icon_url', esc_attr($wwp_icon_url));
		
		$wwp_image_url = isset($_POST['wwp_image_url']) ? wc_clean($_POST['wwp_image_url']) : '';
		$product->update_meta_data('wwp_image_url', esc_attr($wwp_image_url));
		
		$wwp_attachment_title = isset($_POST['wwp_attachment_title']) ? wc_clean($_POST['wwp_attachment_title']) : '';
		$product->update_meta_data('wwp_attachment_title', esc_attr($wwp_attachment_title));
		
		$wwp_attachment_text_link = isset($_POST['wwp_attachment_text_link']) ? wc_clean($_POST['wwp_attachment_text_link']) : '';
		$product->update_meta_data('wwp_attachment_text_link', esc_attr($wwp_attachment_text_link));
		
		$wwp_variation_explode_eneble = isset($_POST['wwp_variation_explode_eneble']) ? wc_clean($_POST['wwp_variation_explode_eneble']) : '';
		$product->update_meta_data('wwp_variation_explode_eneble', esc_attr($wwp_variation_explode_eneble));
		
		$wwp_variation_attribute_with_qty = isset($_POST['wwp_variation_attribute_with_qty']) ? wc_clean($_POST['wwp_variation_attribute_with_qty']) : '';
		$product->update_meta_data('wwp_variation_attribute_with_qty', esc_attr($wwp_variation_attribute_with_qty));
		
		$sample_product_id_hidden = isset($_POST['sample_product_id_hidden']) ? wc_clean($_POST['sample_product_id_hidden']) : '';
		$product->update_meta_data('sample_product_id_hidden', esc_attr($sample_product_id_hidden));
		
		$sample_product_id = isset($_POST['sample_product_id']) ? wc_clean($_POST['sample_product_id']) : '';
		$product->update_meta_data('sample_product_id', esc_attr($sample_product_id));
		
		$request_for_sample_enable = isset($_POST['request_for_sample_enable']) ? wc_clean($_POST['request_for_sample_enable']) : '';
		$product->update_meta_data('request_for_sample_enable', esc_attr($request_for_sample_enable));
		
		$product->save();
	}

	/**
	 * Determines if the service dependencies are met.
	 *
	 * This service is only needed in the WordPress Admin area.
	 *
	 * @return bool True if the service should be initialized (i.e., when in admin).
	 */
	public static function resolveDependency() {
		return is_admin();
	}
}
