<?php
/**
 * Preview helper: effective products for a Dynamic Rule (admin metabox).
 *
 * Mirrors RuleMatcher product scope (rule ∪ group include/exclude) and applies
 * wholesale-role excluded-category filtering only when specific roles are selected.
 *
 * @package WooCommerceWholesalePricing\App\Services\DynamicRules
 */

namespace WooCommerceWholesalePricing\App\Services\DynamicRules;

/**
 * Builds a bounded product list for the Effective Applicable Products metabox.
 */
class ApplicableProductsPreview {

	/**
	 * Default number of product rows returned to the admin UI.
	 *
	 * @var int
	 */
	const DEFAULT_LIMIT = 50;

	/**
	 * Hard cap when scanning the catalog (all_products / group include=all).
	 *
	 * @var int
	 */
	const SCAN_CAP = 500;

	/**
	 * Build preview payload from sanitized rule meta.
	 *
	 * @param array $rule  Sanitized rule meta.
	 * @param int   $limit Max product rows to return.
	 * @return array{
	 *   supported: bool,
	 *   total: int,
	 *   truncated: bool,
	 *   products: array<int, array{id:int,name:string,edit_url:string}>,
	 *   note: string
	 * }
	 */
	public static function build( array $rule, $limit = self::DEFAULT_LIMIT ) {
		$limit = max( 1, absint( $limit ) );

		$rule_type = isset( $rule['rule_type'] ) ? $rule['rule_type'] : '';
		if ( 'change-group' === $rule_type ) {
			return self::empty_result(
				false,
				__( 'Product applicability does not apply to Change Group rules.', 'woocommerce-wholesale-pricing' )
			);
		}

		if ( self::is_all_products_scope( $rule ) && ! self::may_reduce_by_role_exclusions( $rule ) ) {
			return array(
				'supported' => true,
				'is_all'    => true,
				'total'     => 0,
				'truncated' => false,
				'products'  => array(),
				'note'      => '',
			);
		}

		$pool = self::build_candidate_pool( $rule );
		$ids  = array();

		foreach ( $pool as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}
			if ( ! RuleMatcher::product_matches( $rule, $product ) ) {
				continue;
			}
			$ids[] = (int) $product_id;
		}

		$ids = self::filter_by_role_exclusions( $ids, $rule );

		if ( empty( $ids ) ) {
			return self::empty_result(
				true,
				__( 'No products match the current rule, group, and role settings.', 'woocommerce-wholesale-pricing' )
			);
		}

		$total     = count( $ids );
		$slice     = array_slice( $ids, 0, $limit );
		$products  = self::hydrate_products( $slice );
		$truncated = $total > $limit;

		$note = '';
		if ( $truncated ) {
			$note = sprintf(
				/* translators: 1: shown count, 2: total count */
				__( 'Showing %1$d of %2$d applicable products.', 'woocommerce-wholesale-pricing' ),
				count( $products ),
				$total
			);
		} elseif ( count( $pool ) >= self::SCAN_CAP && self::needs_catalog_scan( $rule ) ) {
			$note = sprintf(
				/* translators: %d: scan cap */
				__( 'Preview limited to the first %d catalog products for performance.', 'woocommerce-wholesale-pricing' ),
				self::SCAN_CAP
			);
		}

		return array(
			'supported' => true,
			'is_all'    => false,
			'total'     => $total,
			'truncated' => $truncated,
			'products'  => $products,
			'note'      => $note,
		);
	}

	/**
	 * Empty / unsupported payload.
	 *
	 * @param bool   $supported Whether rule type supports this metabox.
	 * @param string $note      Message.
	 * @return array
	 */
	private static function empty_result( $supported, $note ) {
		return array(
			'supported' => (bool) $supported,
			'is_all'    => false,
			'total'     => 0,
			'truncated' => false,
			'products'  => array(),
			'note'      => $note,
		);
	}

	/**
	 * Whether rule/group scope can cover all products.
	 *
	 * @param array $rule Rule meta.
	 * @return bool
	 */
	private static function is_all_products_scope( array $rule ) {
		$applies_to = isset( $rule['applies_to'] ) ? $rule['applies_to'] : 'all_products';
		if ( 'all_products' === $applies_to ) {
			return true;
		}

		foreach ( self::get_selected_group_ids( $rule ) as $group_id ) {
			if ( 'all' === get_post_meta( $group_id, '_include_products', true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * True when selected role exclusions may reduce the final product set.
	 *
	 * @param array $rule Rule meta.
	 * @return bool
	 */
	private static function may_reduce_by_role_exclusions( array $rule ) {
		$roles = self::get_target_role_slugs_for_exclusions( $rule );
		if ( empty( $roles ) ) {
			return false;
		}

		$excluded_by_role = self::get_excluded_category_ids_for_role_slugs( $roles );
		if ( empty( $excluded_by_role ) ) {
			return false;
		}

		// If any selected role has excluded categories, those products can be reduced.
		foreach ( $excluded_by_role as $excluded_cats ) {
			if ( ! empty( $excluded_cats ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Whether the rule/group config may require scanning the full catalog.
	 *
	 * @param array $rule Rule meta.
	 * @return bool
	 */
	private static function needs_catalog_scan( array $rule ) {
		$applies_to = isset( $rule['applies_to'] ) ? $rule['applies_to'] : 'all_products';
		if ( 'all_products' === $applies_to ) {
			return true;
		}

		foreach ( self::get_selected_group_ids( $rule ) as $group_id ) {
			if ( 'all' === get_post_meta( $group_id, '_include_products', true ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Candidate product IDs before RuleMatcher filtering.
	 *
	 * @param array $rule Rule meta.
	 * @return int[]
	 */
	private static function build_candidate_pool( array $rule ) {
		if ( self::needs_catalog_scan( $rule ) ) {
			return self::query_all_product_ids();
		}

		$ids = array();

		$applies_to = isset( $rule['applies_to'] ) ? $rule['applies_to'] : 'all_products';

		if ( 'specific_products' === $applies_to ) {
			$products = isset( $rule['products'] ) && is_array( $rule['products'] )
				? array_filter( array_map( 'absint', $rule['products'] ) )
				: array();
			$ids      = array_merge( $ids, $products );
		}

		if ( 'specific_categories' === $applies_to ) {
			$categories = isset( $rule['categories'] ) && is_array( $rule['categories'] )
				? array_values( array_filter( array_map( 'sanitize_title', $rule['categories'] ) ) )
				: array();
			if ( ! empty( $categories ) ) {
				$ids = array_merge( $ids, self::query_product_ids_by_category_slugs( $categories ) );
			}
		}

		foreach ( self::get_selected_group_ids( $rule ) as $group_id ) {
			$include_type = get_post_meta( $group_id, '_include_products', true );
			if ( 'specific' === $include_type ) {
				$include = self::normalize_id_list( get_post_meta( $group_id, '_include_specific_products', true ) );
				$ids     = array_merge( $ids, $include );
			}
		}

		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	/**
	 * Group IDs selected on the rule (same semantics as RuleMatcher).
	 *
	 * @param array $rule Rule meta.
	 * @return int[]
	 */
	private static function get_selected_group_ids( array $rule ) {
		if ( ! RuleMetaHelper::is_groups_enabled() ) {
			return array();
		}

		if ( isset( $rule['apply_all_groups'] ) && 'yes' === $rule['apply_all_groups'] ) {
			$slug = wwp_env()->get( 'group_slug' );
			if ( ! $slug ) {
				$slug = 'wwp_groups';
			}

			$ids = get_posts(
				array(
					'post_type'      => $slug,
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'fields'         => 'ids',
					'orderby'        => 'ID',
					'order'          => 'ASC',
				)
			);

			return array_map( 'absint', (array) $ids );
		}

		$groups = isset( $rule['groups'] ) && is_array( $rule['groups'] )
			? array_values( array_filter( array_map( 'absint', $rule['groups'] ) ) )
			: array();

		return $groups;
	}

	/**
	 * Drop products excluded by any explicitly selected wholesale role.
	 *
	 * Skipped when apply_all_roles is yes or no roles are selected.
	 *
	 * @param int[] $product_ids Product IDs.
	 * @param array $rule        Rule meta.
	 * @return int[]
	 */
	private static function filter_by_role_exclusions( array $product_ids, array $rule ) {
		if ( empty( $product_ids ) ) {
			return array();
		}

		$roles = self::get_target_role_slugs_for_exclusions( $rule );
		if ( empty( $roles ) ) {
			return $product_ids;
		}

		$excluded_by_role = self::get_excluded_category_ids_for_role_slugs( $roles );
		if ( empty( $excluded_by_role ) ) {
			return $product_ids;
		}

		$kept = array();
		foreach ( $product_ids as $product_id ) {
			if ( ! self::is_excluded_for_any_role( $product_id, $excluded_by_role ) ) {
				$kept[] = $product_id;
			}
		}

		return $kept;
	}

	/**
	 * Resolve which wholesale roles should contribute exclusion categories.
	 *
	 * @param array $rule Rule meta.
	 * @return string[] Role slugs.
	 */
	private static function get_target_role_slugs_for_exclusions( array $rule ) {
		$apply_all_roles = isset( $rule['apply_all_roles'] ) && 'yes' === $rule['apply_all_roles'];
		if ( $apply_all_roles ) {
			$taxonomy = wwp_env()->get( 'role_taxonomy' );
			if ( ! $taxonomy ) {
				$taxonomy = 'wholesale_user_roles';
			}

			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
					'fields'     => 'slugs',
				)
			);

			if ( is_wp_error( $terms ) || empty( $terms ) ) {
				return array();
			}

			return array_values(
				array_filter(
					array_map( 'sanitize_title', (array) $terms )
				)
			);
		}

		$roles = isset( $rule['roles'] ) && is_array( $rule['roles'] ) ? $rule['roles'] : array();
		return array_values(
			array_filter(
				array_map( 'sanitize_title', $roles )
			)
		);
	}

	/**
	 * Map role slugs to excluded category term IDs.
	 *
	 * @param string[] $role_slugs Role slugs.
	 * @return array<string, int[]> Role slug => excluded category IDs.
	 */
	private static function get_excluded_category_ids_for_role_slugs( array $role_slugs ) {
		if ( ! function_exists( 'get_excluded_categories_for_wholesale_roles' ) ) {
			return array();
		}

		$all_excluded = get_excluded_categories_for_wholesale_roles();
		if ( empty( $all_excluded ) || ! is_array( $all_excluded ) ) {
			return array();
		}

		$taxonomy = wwp_env()->get( 'role_taxonomy' );
		if ( ! $taxonomy ) {
			$taxonomy = 'wholesale_user_roles';
		}

		$by_slug = array();
		foreach ( $role_slugs as $slug ) {
			$slug = sanitize_title( $slug );
			if ( '' === $slug ) {
				continue;
			}
			$term = get_term_by( 'slug', $slug, $taxonomy );
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}
			$term_id          = (int) $term->term_id;
			$by_slug[ $slug ] = isset( $all_excluded[ $term_id ] ) && is_array( $all_excluded[ $term_id ] )
				? array_map( 'absint', $all_excluded[ $term_id ] )
				: array();
		}

		return $by_slug;
	}

	/**
	 * Whether the product is in an excluded category for any selected role.
	 *
	 * @param int                 $product_id       Product ID.
	 * @param array<string,int[]> $excluded_by_role Role slug => category IDs.
	 * @return bool
	 */
	private static function is_excluded_for_any_role( $product_id, array $excluded_by_role ) {
		if ( empty( $excluded_by_role ) ) {
			return false;
		}

		$product_cat_ids = self::get_product_category_ids_with_ancestors( $product_id );
		if ( empty( $product_cat_ids ) ) {
			return false;
		}

		foreach ( $excluded_by_role as $excluded_cats ) {
			if ( empty( $excluded_cats ) ) {
				continue;
			}
			foreach ( $product_cat_ids as $cat_id ) {
				if ( in_array( (int) $cat_id, $excluded_cats, true ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Product category IDs including ancestors.
	 *
	 * @param int $product_id Product ID.
	 * @return int[]
	 */
	private static function get_product_category_ids_with_ancestors( $product_id ) {
		$product = wc_get_product( $product_id );
		$lookup  = $product_id;
		if ( $product && $product->get_parent_id() ) {
			$lookup = $product->get_parent_id();
		}

		$category_ids     = (array) wp_get_post_terms( $lookup, 'product_cat', array( 'fields' => 'ids' ) );
		$all_category_ids = array();

		foreach ( $category_ids as $cat_id ) {
			$cat_id = (int) $cat_id;
			if ( ! $cat_id ) {
				continue;
			}
			$all_category_ids[] = $cat_id;
			$term               = get_term( $cat_id, 'product_cat' );
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}
			$parent_id = (int) $term->parent;
			while ( $parent_id > 0 && ! in_array( $parent_id, $all_category_ids, true ) ) {
				$all_category_ids[] = $parent_id;
				$parent             = get_term( $parent_id, 'product_cat' );
				if ( ! $parent || is_wp_error( $parent ) ) {
					break;
				}
				$parent_id = (int) $parent->parent;
			}
		}

		return $all_category_ids;
	}

	/**
	 * Query product IDs by category slugs.
	 *
	 * @param string[] $slugs Category slugs.
	 * @return int[]
	 */
	private static function query_product_ids_by_category_slugs( array $slugs ) {
		$query = new \WP_Query(
			array(
				'post_type'              => array( 'product' ),
				'post_status'            => 'publish',
				'posts_per_page'         => self::SCAN_CAP,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'tax_query'              => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					array(
						'taxonomy' => 'product_cat',
						'field'    => 'slug',
						'terms'    => $slugs,
					),
				),
			)
		);

		return array_map( 'absint', (array) $query->posts );
	}

	/**
	 * Query published product IDs (capped).
	 *
	 * @return int[]
	 */
	private static function query_all_product_ids() {
		$query = new \WP_Query(
			array(
				'post_type'              => 'product',
				'post_status'            => 'publish',
				'posts_per_page'         => self::SCAN_CAP,
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'orderby'                => 'title',
				'order'                  => 'ASC',
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		return array_map( 'absint', (array) $query->posts );
	}

	/**
	 * Hydrate product rows for the UI.
	 *
	 * @param int[] $ids Product IDs.
	 * @return array<int, array{id:int,name:string,edit_url:string}>
	 */
	private static function hydrate_products( array $ids ) {
		$rows = array();
		foreach ( $ids as $id ) {
			$product = wc_get_product( $id );
			if ( ! $product ) {
				continue;
			}
			$edit_url = get_edit_post_link( $id, 'raw' );
			$rows[]   = array(
				'id'       => (int) $id,
				'name'     => $product->get_formatted_name(),
				'edit_url' => $edit_url ? $edit_url : '',
			);
		}
		return $rows;
	}

	/**
	 * Normalize meta ID list.
	 *
	 * @param mixed $value Raw meta.
	 * @return int[]
	 */
	private static function normalize_id_list( $value ) {
		if ( empty( $value ) && '0' !== $value && 0 !== $value ) {
			return array();
		}
		if ( ! is_array( $value ) ) {
			$value = array( $value );
		}
		return array_values( array_filter( array_map( 'absint', $value ) ) );
	}
}
