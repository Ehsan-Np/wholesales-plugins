<?php
/**
 * Dynamic Rules post type service.
 *
 * Registers the dynamic_rules CPT and handles metaboxes, list columns,
 * row actions (duplicate / remove quick edit), and save logic.
 *
 * @package WooCommerceWholesalePricing\App\Services\DynamicRules
 */

namespace WooCommerceWholesalePricing\App\Services\DynamicRules;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\Init;

/**
 * Service for the Dynamic Rules custom post type.
 *
 * @extends Init
 */
class PostTypeService extends Init {

	use WholesaleSettings;

	/**
	 * Post type slug.
	 *
	 * @var string
	 */
	public $slug;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->slug = wwp_env()->get( 'dynamic_rules_slug' );

		add_action( 'add_meta_boxes', array( $this, 'meta_boxes' ) );
		add_action( 'save_post_' . $this->slug, array( $this, 'save_post' ), 10, 2 );

		add_filter( 'manage_' . $this->slug . '_posts_columns', array( $this, 'columns' ) );
		add_action( 'manage_' . $this->slug . '_posts_custom_column', array( $this, 'column_values' ), 10, 2 );
		add_filter( 'post_row_actions', array( $this, 'row_actions' ), 10, 2 );

		add_action( 'admin_action_wwp_duplicate_dynamic_rule', array( $this, 'duplicate_rule' ) );
		add_action( 'admin_notices', array( $this, 'duplicate_admin_notice' ) );
		add_filter( 'enter_title_here', array( $this, 'enter_title_here' ), 10, 2 );

		add_action( 'admin_notices', array( $this, 'title_required_notice' ) );

		add_action( 'wp_ajax_wwp_dynamic_rule_applicable_products', array( $this, 'ajax_applicable_products' ) );

		parent::__construct();
	}

	/**
	 * Register the dynamic_rules post type.
	 *
	 * @return void
	 */
	public function register() {
		$labels = array(
			'name'               => __( 'Dynamic Rules', 'woocommerce-wholesale-pricing' ),
			'singular_name'      => __( 'Dynamic Rule', 'woocommerce-wholesale-pricing' ),
			'menu_name'          => __( 'Dynamic Rules', 'woocommerce-wholesale-pricing' ),
			'name_admin_bar'     => __( 'Dynamic Rule', 'woocommerce-wholesale-pricing' ),
			'add_new'            => __( 'Add New', 'woocommerce-wholesale-pricing' ),
			'add_new_item'       => __( 'Add New Dynamic Rule', 'woocommerce-wholesale-pricing' ),
			'new_item'           => __( 'New Dynamic Rule', 'woocommerce-wholesale-pricing' ),
			'edit_item'          => __( 'Edit Dynamic Rule', 'woocommerce-wholesale-pricing' ),
			'view_item'          => __( 'View Dynamic Rule', 'woocommerce-wholesale-pricing' ),
			'all_items'          => __( 'Dynamic Rules', 'woocommerce-wholesale-pricing' ),
			'search_items'       => __( 'Search Dynamic Rules', 'woocommerce-wholesale-pricing' ),
			'parent_item_colon'  => __( 'Parent Dynamic Rule:', 'woocommerce-wholesale-pricing' ),
			'not_found'          => __( 'No dynamic rules found.', 'woocommerce-wholesale-pricing' ),
			'not_found_in_trash' => __( 'No dynamic rules found in Trash.', 'woocommerce-wholesale-pricing' ),
		);

		$args = array(
			'labels'              => $labels,
			'description'         => __( 'Wholesale Dynamic Rules.', 'woocommerce-wholesale-pricing' ),
			'public'              => false,
			'publicly_queryable'  => false,
			'show_ui'             => true,
			'show_in_menu'        => false,
			'exclude_from_search' => true,
			'query_var'           => false,
			'rewrite'             => false,
			'capability_type'     => 'post',
			'has_archive'         => false,
			'hierarchical'        => false,
			'supports'            => array( 'title' ),
		);

		/**
		 * Filter dynamic rules post type registration args.
		 *
		 * @since 3.2.0
		 * @param array $args Post type args.
		 */
		register_post_type( $this->slug, apply_filters( 'wwp_dynamic_rules_register_post_type', $args ) );
	}

	/**
	 * Register metaboxes.
	 *
	 * @return void
	 */
	public function meta_boxes() {
		$screen = $this->slug;

		add_meta_box(
			'wwp-dr-rule-settings',
			__( 'Rule Settings', 'woocommerce-wholesale-pricing' ),
			array( $this, 'callback' ),
			$screen,
			'advanced',
			'high',
			array( 'file' => 'rule-settings' )
		);

		add_meta_box(
			'wwp-dr-applicable-roles',
			__( 'Applicable Wholesale roles', 'woocommerce-wholesale-pricing' ),
			array( $this, 'callback' ),
			$screen,
			'advanced',
			'default',
			array( 'file' => 'applicable-roles' )
		);

		add_meta_box(
			'wwp-dr-applicable-groups',
			__( 'Applicable Groups', 'woocommerce-wholesale-pricing' ),
			array( $this, 'callback' ),
			$screen,
			'advanced',
			'default',
			array( 'file' => 'applicable-groups' )
		);

		add_meta_box(
			'wwp-dr-applicable-customers',
			__( 'Applicable Customers', 'woocommerce-wholesale-pricing' ),
			array( $this, 'callback' ),
			$screen,
			'advanced',
			'default',
			array( 'file' => 'applicable-customers' )
		);

		add_meta_box(
			'wwp-dr-applicable-products',
			__( 'Effective Applicable Products', 'woocommerce-wholesale-pricing' ),
			array( $this, 'callback' ),
			$screen,
			'advanced',
			'default',
			array( 'file' => 'applicable-products' )
		);

		add_meta_box(
			'wwp-dr-summary',
			__( 'Summary', 'woocommerce-wholesale-pricing' ),
			array( $this, 'callback' ),
			$screen,
			'side',
			'default',
			array( 'file' => 'summary' )
		);
	}

	/**
	 * AJAX: preview effective applicable products for the current (unsaved) form.
	 *
	 * @return void
	 */
	public function ajax_applicable_products() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to preview applicable products.', 'woocommerce-wholesale-pricing' ) ),
				403
			);
		}

		check_ajax_referer( 'wwp_dynamic_rule_applicable_products', 'nonce' );

		$raw = array();
		if ( isset( $_POST['wwp_dynamic_rule'] ) && is_array( $_POST['wwp_dynamic_rule'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$raw = wp_unslash( $_POST['wwp_dynamic_rule'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		}

		$rule    = RuleMetaHelper::sanitize( $raw );
		$preview = ApplicableProductsPreview::build( $rule );

		wp_send_json_success( $preview );
	}

	/**
	 * Metabox view callback.
	 *
	 * @param \WP_Post $post Post object.
	 * @param array    $args Metabox args.
	 * @return void
	 */
	public function callback( $post, $args ) {
		$post_id = $post->ID;
		$rule    = RuleMetaHelper::get_rule( $post_id );
		$file    = isset( $args['args']['file'] ) ? $args['args']['file'] : '';

		if ( ! $file ) {
			return;
		}

		wwp_view( 'admin.dynamic-rules.meta-box.' . $file, compact( 'post_id', 'post', 'rule' ) );
	}

	/**
	 * Custom list table columns.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public function columns( $columns ) {
		$date = isset( $columns['date'] ) ? $columns['date'] : __( 'Date', 'woocommerce-wholesale-pricing' );
		unset( $columns['date'] );

		$columns['wwp_dr_rule_type']  = __( 'Rule Type', 'woocommerce-wholesale-pricing' );
		$columns['wwp_dr_applies_to'] = __( 'Applies to', 'woocommerce-wholesale-pricing' );
		$columns['wwp_dr_roles']      = __( 'User roles', 'woocommerce-wholesale-pricing' );
		$columns['wwp_dr_groups']     = __( 'Groups', 'woocommerce-wholesale-pricing' );
		$columns['date']              = $date;

		/**
		 * Filter dynamic rules list columns.
		 *
		 * @since 3.2.0
		 * @param array $columns Column key => label.
		 */
		return apply_filters( 'wwp_dynamic_rules_columns', $columns );
	}

	/**
	 * Render custom column values.
	 *
	 * @param string $column  Column key.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	public function column_values( $column, $post_id ) {
		$rule = RuleMetaHelper::get_rule( $post_id );

		switch ( $column ) {
			case 'wwp_dr_rule_type':
				echo esc_html( RuleMetaHelper::format_rule_type( $rule ) );
				break;

			case 'wwp_dr_applies_to':
				echo esc_html( RuleMetaHelper::format_applies_to( $rule ) );
				break;

			case 'wwp_dr_roles':
				echo esc_html( RuleMetaHelper::format_roles( $rule ) );
				break;

			case 'wwp_dr_groups':
				echo esc_html( RuleMetaHelper::format_groups( $rule ) );
				break;
		}
	}

	/**
	 * Remove quick edit and add Duplicate row action.
	 *
	 * @param array    $actions Row actions.
	 * @param \WP_Post $post    Post object.
	 * @return array
	 */
	public function row_actions( $actions, $post ) {
		if ( ! isset( $post->post_type ) || $this->slug !== $post->post_type ) {
			return $actions;
		}

		unset( $actions['inline'] );
		unset( $actions['inline hide-if-no-js'] );

		$duplicate_url = wp_nonce_url(
			admin_url( 'admin.php?action=wwp_duplicate_dynamic_rule&post=' . absint( $post->ID ) ),
			'wwp_duplicate_dynamic_rule_' . $post->ID
		);

		$duplicate_action = sprintf(
			'<a href="%s">%s</a>',
			esc_url( $duplicate_url ),
			esc_html__( 'Duplicate', 'woocommerce-wholesale-pricing' )
		);

		$new_actions = array();
		foreach ( $actions as $key => $action ) {
			if ( 'trash' === $key ) {
				$new_actions['wwp_duplicate'] = $duplicate_action;
			}
			$new_actions[ $key ] = $action;
		}

		if ( ! isset( $new_actions['wwp_duplicate'] ) ) {
			$new_actions['wwp_duplicate'] = $duplicate_action;
		}

		return $new_actions;
	}

	/**
	 * Duplicate a dynamic rule post and its meta.
	 *
	 * @return void
	 */
	public function duplicate_rule() {
		$post_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( ! $post_id ) {
			wp_die( esc_html__( 'No rule to duplicate.', 'woocommerce-wholesale-pricing' ) );
		}

		check_admin_referer( 'wwp_duplicate_dynamic_rule_' . $post_id );

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_die( esc_html__( 'You are not allowed to duplicate this rule.', 'woocommerce-wholesale-pricing' ) );
		}

		$source = get_post( $post_id );
		if ( ! $source || $this->slug !== $source->post_type ) {
			wp_die( esc_html__( 'Invalid dynamic rule.', 'woocommerce-wholesale-pricing' ) );
		}

		$new_id = wp_insert_post(
			array(
				'post_title'  => $source->post_title . ' ' . __( '(Copy)', 'woocommerce-wholesale-pricing' ),
				'post_status' => $source->post_status,
				'post_type'   => $this->slug,
				'post_author' => get_current_user_id(),
			),
			true
		);

		if ( is_wp_error( $new_id ) || ! $new_id ) {
			wp_die( esc_html__( 'Could not duplicate the rule.', 'woocommerce-wholesale-pricing' ) );
		}

		$meta = get_post_meta( $post_id );
		if ( is_array( $meta ) ) {
			foreach ( $meta as $key => $values ) {
				foreach ( (array) $values as $value ) {
					add_post_meta( $new_id, $key, maybe_unserialize( $value ) );
				}
			}
		}

		/**
		 * Fires after a dynamic rule has been duplicated.
		 *
		 * @since 3.2.0
		 * @param int $new_id    New post ID.
		 * @param int $source_id Source post ID.
		 */
		do_action( 'wwp_dynamic_rule_duplicated', $new_id, $post_id );

		wp_safe_redirect(
			admin_url( 'edit.php?post_type=' . $this->slug . '&duplicated=1' )
		);
		exit;
	}

	/**
	 * Admin notice after successful duplicate.
	 *
	 * @return void
	 */
	public function duplicate_admin_notice() {
		if ( ! isset( $_GET['duplicated'] ) || '1' !== $_GET['duplicated'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$screen = get_current_screen();
		if ( ! $screen || 'edit-' . $this->slug !== $screen->id ) {
			return;
		}

		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Dynamic rule duplicated successfully.', 'woocommerce-wholesale-pricing' ) . '</p></div>';
	}

	/**
	 * Title placeholder text.
	 *
	 * @param string   $text Placeholder text.
	 * @param \WP_Post $post Post object.
	 * @return string
	 */
	public function enter_title_here( $text, $post ) {
		if ( isset( $post->post_type ) && $this->slug === $post->post_type ) {
			return __( 'Enter rule title', 'woocommerce-wholesale-pricing' );
		}
		return $text;
	}

	/**
	 * Show notice when title was required but empty.
	 *
	 * @return void
	 */
	public function title_required_notice() {
		if ( ! isset( $_GET['wwp_dr_title_required'] ) || '1' !== $_GET['wwp_dr_title_required'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__( 'Rule title is required.', 'woocommerce-wholesale-pricing' ) . '</p></div>';
	}

	/**
	 * Save dynamic rule meta.
	 *
	 * @param int      $post_id Post ID.
	 * @param \WP_Post $post    Post object.
	 * @return void
	 */
	public function save_post( $post_id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! isset( $post->post_type ) || $this->slug !== $post->post_type ) {
			return;
		}

		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'update-post_' . $post_id ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$title = isset( $_POST['post_title'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['post_title'] ) ) ) : '';
		if ( '' === $title ) {
			// Prevent publishing without a title; keep as draft and flag notice.
			remove_action( 'save_post_' . $this->slug, array( $this, 'save_post' ), 10 );
			wp_update_post(
				array(
					'ID'          => $post_id,
					'post_status' => 'draft',
					'post_title'  => '',
				)
			);
			add_action( 'save_post_' . $this->slug, array( $this, 'save_post' ), 10, 2 );

			add_filter(
				'redirect_post_location',
				function ( $location ) {
					return add_query_arg( 'wwp_dr_title_required', '1', $location );
				}
			);
			return;
		}

		$raw = isset( $_POST['wwp_dynamic_rule'] ) ? wp_unslash( $_POST['wwp_dynamic_rule'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$sanitized = RuleMetaHelper::sanitize( $raw );

		update_post_meta( $post_id, RuleMetaHelper::META_KEY, $sanitized );

		/**
		 * Fires after a dynamic rule has been saved.
		 *
		 * @since 3.2.0
		 * @param int   $post_id   Post ID.
		 * @param array $sanitized Sanitized rule meta.
		 */
		do_action( 'wwp_dynamic_rule_save', $post_id, $sanitized );
	}
}
