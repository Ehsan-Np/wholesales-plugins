<?php
/**
 * Buy X Get X Free dynamic rule runtime.
 *
 * When paid cart qty of an applicable product meets buy_quantity, the same
 * product is added as a free cart line (price 0) with free_items quantity.
 * Free lines are kept in sync when paid qty changes, and restored if removed
 * while still eligible.
 *
 * @package WooCommerceWholesalePricing\App\Services\DynamicRules\Rules
 */

namespace WooCommerceWholesalePricing\App\Services\DynamicRules\Rules;

use WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMatcher;

/**
 * Class BuyXGetXRule
 */
class BuyXGetXRule {

	const RULE_TYPE = 'buy-x-get-x';

	/**
	 * Cart item data key for free gift lines.
	 */
	const CART_KEY = 'wwp_dr_buy_x_get_x';

	/**
	 * Whether a cart sync is already running (prevents recursion).
	 *
	 * @var bool
	 */
	private static $syncing = false;

	/**
	 * Whether a free gift line is being added (bypasses stock/validation).
	 *
	 * @var bool
	 */
	private static $adding_free = false;

	/**
	 * Constructor — register hooks only.
	 */
	public function __construct() {
		add_action( 'woocommerce_add_to_cart', array( $this, 'sync_cart' ), 30 );
		add_action( 'woocommerce_cart_item_removed', array( $this, 'sync_cart' ), 30 );
		add_action( 'woocommerce_cart_item_restored', array( $this, 'sync_cart' ), 30 );
		add_action( 'woocommerce_after_cart_item_quantity_update', array( $this, 'sync_cart' ), 30 );
		add_action( 'woocommerce_cart_loaded_from_session', array( $this, 'sync_cart' ), 30 );
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'sync_cart' ), 1 );
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'apply_free_prices' ), 9999 );

		add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'filter_free_add_validation' ), 9999, 1 );
		add_filter( 'woocommerce_add_to_cart_sold_individually_found_in_cart', array( $this, 'filter_sold_individually_found' ), 9999, 1 );
		add_filter( 'woocommerce_product_has_enough_stock', array( $this, 'filter_has_enough_stock' ), 9999, 1 );
		add_filter( 'woocommerce_quantity_input_max', array( $this, 'filter_max_purchase_qty' ), 9999, 1 );
		add_filter( 'woocommerce_get_cart_item_from_session', array( $this, 'filter_cart_item_from_session' ), 20, 2 );

		add_filter( 'wwp_override_product_price_cart_price', array( $this, 'filter_cart_wholesale_price' ), 5, 2 );
		add_filter( 'woocommerce_cart_item_name', array( $this, 'filter_cart_item_name' ), 20, 3 );
		add_filter( 'woocommerce_cart_item_quantity', array( $this, 'filter_cart_item_quantity' ), 20, 3 );
		add_filter( 'woocommerce_cart_item_price', array( $this, 'filter_cart_item_price_html' ), 20, 3 );
		add_filter( 'woocommerce_cart_item_subtotal', array( $this, 'filter_cart_item_price_html' ), 20, 3 );
		add_filter( 'woocommerce_get_item_data', array( $this, 'filter_item_data' ), 20, 2 );

		add_action( 'wwp_dynamic_rule_save', array( RuleMatcher::class, 'clear_cache' ) );
	}

	/**
	 * Keep free gift lines in sync with paid qualifying quantities.
	 *
	 * @return void
	 */
	public function sync_cart() {
		if ( self::$syncing || self::$adding_free ) {
			return;
		}

		if ( is_admin() && ! wp_doing_ajax() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}

		// Guest carts are not persisted until a session cookie exists.
		if ( WC()->session && ! WC()->session->has_session() ) {
			WC()->session->set_customer_session_cookie( true );
		}

		self::$syncing = true;

		try {
			$this->do_sync();
		} finally {
			self::$syncing = false;
		}
	}

	/**
	 * Allow free gift add_to_cart to pass validation.
	 *
	 * @param bool $passed Current validation result.
	 * @return bool
	 */
	public function filter_free_add_validation( $passed ) {
		return self::$adding_free ? true : $passed;
	}

	/**
	 * Allow a free line of a sold-individually product already in the cart.
	 *
	 * @param bool $found Whether the product was found in cart.
	 * @return bool
	 */
	public function filter_sold_individually_found( $found ) {
		return self::$adding_free ? false : $found;
	}

	/**
	 * Skip stock checks while adding a free gift.
	 *
	 * @param bool $enough Whether stock is sufficient.
	 * @return bool
	 */
	public function filter_has_enough_stock( $enough ) {
		return self::$adding_free ? true : $enough;
	}

	/**
	 * Unlimited max qty while adding a free gift.
	 *
	 * @param mixed $max Max purchase quantity.
	 * @return mixed
	 */
	public function filter_max_purchase_qty( $max ) {
		return self::$adding_free ? -1 : $max;
	}

	/**
	 * Restore free-gift flag and zero price from the session cart.
	 *
	 * @param array $item   Cart item.
	 * @param array $values Session values.
	 * @return array
	 */
	public function filter_cart_item_from_session( $item, $values ) {
		if ( ! empty( $values[ self::CART_KEY ] ) ) {
			$item[ self::CART_KEY ] = $values[ self::CART_KEY ];
			if ( ! empty( $item[ self::CART_KEY ]['free'] ) && isset( $item['data'] ) && $item['data'] instanceof \WC_Product ) {
				$item['data']->set_price( 0 );
			}
		}

		return $item;
	}

	/**
	 * Force free gift cart lines to price 0 after other price overrides.
	 *
	 * @param \WC_Cart $cart Cart.
	 * @return void
	 */
	public function apply_free_prices( $cart ) {
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			return;
		}

		if ( ! $cart instanceof \WC_Cart ) {
			return;
		}

		foreach ( $cart->get_cart() as $item ) {
			if ( empty( $item[ self::CART_KEY ]['free'] ) ) {
				continue;
			}
			if ( isset( $item['data'] ) && $item['data'] instanceof \WC_Product ) {
				$item['data']->set_price( 0 );
			}
		}
	}

	/**
	 * Keep WWP cart wholesale override from repricing free gifts.
	 *
	 * @param float $price Cart item price.
	 * @param array $item  Cart item.
	 * @return float
	 */
	public function filter_cart_wholesale_price( $price, $item ) {
		if ( is_array( $item ) && ! empty( $item[ self::CART_KEY ]['free'] ) ) {
			return 0;
		}
		return $price;
	}

	/**
	 * Append Free label to cart item name.
	 *
	 * @param string $name           Item name HTML.
	 * @param array  $cart_item      Cart item.
	 * @param string $cart_item_key  Cart key.
	 * @return string
	 */
	public function filter_cart_item_name( $name, $cart_item, $cart_item_key ) {
		unset( $cart_item_key );
		if ( ! empty( $cart_item[ self::CART_KEY ]['free'] ) ) {
			$name .= ' <strong class="wwp-dr-buy-x-free-label">(' . esc_html__( 'Free', 'woocommerce-wholesale-pricing' ) . ')</strong>';
		}
		return $name;
	}

	/**
	 * Make free gift quantity read-only (sync restores correct qty).
	 *
	 * @param string $quantity_html Quantity input HTML.
	 * @param string $cart_item_key Cart key.
	 * @param array  $cart_item     Cart item.
	 * @return string
	 */
	public function filter_cart_item_quantity( $quantity_html, $cart_item_key, $cart_item ) {
		unset( $cart_item_key );
		if ( ! empty( $cart_item[ self::CART_KEY ]['free'] ) ) {
			return '<span class="wwp-dr-buy-x-free-qty">' . esc_html( (string) $cart_item['quantity'] ) . '</span>';
		}
		return $quantity_html;
	}

	/**
	 * Show free price HTML for free gift lines.
	 *
	 * @param string $price_html    Price HTML.
	 * @param array  $cart_item     Cart item.
	 * @param string $cart_item_key Cart key.
	 * @return string
	 */
	public function filter_cart_item_price_html( $price_html, $cart_item, $cart_item_key ) {
		unset( $cart_item_key );
		if ( ! empty( $cart_item[ self::CART_KEY ]['free'] ) ) {
			return '<span class="wwp-dr-buy-x-free-price">' . esc_html__( 'Free', 'woocommerce-wholesale-pricing' ) . '</span>';
		}
		return $price_html;
	}

	/**
	 * Expose free gift meta in cart item data.
	 *
	 * @param array $item_data Cart item data rows.
	 * @param array $cart_item Cart item.
	 * @return array
	 */
	public function filter_item_data( $item_data, $cart_item ) {
		if ( ! empty( $cart_item[ self::CART_KEY ]['free'] ) ) {
			$item_data[] = array(
				'key'   => __( 'Promotion', 'woocommerce-wholesale-pricing' ),
				'value' => __( 'Buy X Get X Free', 'woocommerce-wholesale-pricing' ),
			);
		}
		return $item_data;
	}

	/**
	 * Core sync: add / update / remove free lines per matching buy-x-get-x rules.
	 *
	 * @return void
	 */
	private function do_sync() {
		$cart = WC()->cart;
		if ( ! $cart ) {
			return;
		}

		$desired  = $this->collect_desired_free_lines( $cart->get_cart() );
		$existing = $this->index_existing_free_lines( $cart->get_cart() );
		$changed  = false;

		foreach ( $existing as $identity => $info ) {
			if ( ! isset( $desired[ $identity ] ) ) {
				$cart->remove_cart_item( $info['key'] );
				unset( $existing[ $identity ] );
				$changed = true;
			}
		}

		foreach ( $desired as $identity => $need ) {
			$qty = (int) $need['quantity'];
			if ( $qty < 1 ) {
				continue;
			}

			if ( isset( $existing[ $identity ] ) ) {
				$current_qty = (int) $existing[ $identity ]['quantity'];
				if ( $current_qty !== $qty ) {
					$cart->set_quantity( $existing[ $identity ]['key'], $qty, false );
					$changed = true;
				}
				continue;
			}

			$added = $this->add_free_line( $cart, $need );
			if ( $added ) {
				$changed = true;
			}
		}

		if ( $changed && ! doing_action( 'woocommerce_before_calculate_totals' ) && ! doing_action( 'woocommerce_add_to_cart' ) ) {
			$cart->calculate_totals();
		}
	}

	/**
	 * Build map of identity => desired free line data from paid cart items.
	 *
	 * @param array $cart_contents Cart contents.
	 * @return array<string, array>
	 */
	private function collect_desired_free_lines( array $cart_contents ) {
		$paid_qty_by_identity = array();
		$sample_item_by_identity = array();

		foreach ( $cart_contents as $item ) {
			if ( ! empty( $item[ self::CART_KEY ]['free'] ) ) {
				continue;
			}

			if ( empty( $item['data'] ) || ! $item['data'] instanceof \WC_Product ) {
				continue;
			}

			$identity = $this->item_identity( $item );
			if ( ! isset( $paid_qty_by_identity[ $identity ] ) ) {
				$paid_qty_by_identity[ $identity ] = 0;
				$sample_item_by_identity[ $identity ] = $item;
			}
			$paid_qty_by_identity[ $identity ] += (int) $item['quantity'];
		}

		$desired = array();

		foreach ( $paid_qty_by_identity as $identity => $paid_qty ) {
			$item    = $sample_item_by_identity[ $identity ];
			$product = $item['data'];
			$rules   = RuleMatcher::get_matching_rules( self::RULE_TYPE, $product );

			if ( empty( $rules ) ) {
				continue;
			}

			// One free-gift grant per product identity (first matching rule).
			$rule = $rules[0];
			$buy  = isset( $rule['buy_quantity'] ) ? max( 1, absint( $rule['buy_quantity'] ) ) : 1;
			$free = isset( $rule['free_items'] ) ? max( 1, absint( $rule['free_items'] ) ) : 1;

			$sets = (int) floor( $paid_qty / $buy );
			if ( $sets < 1 ) {
				continue;
			}

			$free_qty = $sets * $free;
			$rule_id  = isset( $rule['_post_id'] ) ? absint( $rule['_post_id'] ) : 0;
			$free_id  = $this->free_identity( $identity, $rule_id );

			$desired[ $free_id ] = array(
				'quantity'     => $free_qty,
				'product_id'   => isset( $item['product_id'] ) ? absint( $item['product_id'] ) : $product->get_id(),
				'variation_id' => isset( $item['variation_id'] ) ? absint( $item['variation_id'] ) : 0,
				'variation'    => isset( $item['variation'] ) && is_array( $item['variation'] ) ? $item['variation'] : array(),
				'rule_id'      => $rule_id,
				'paid_identity'=> $identity,
			);
		}

		return $desired;
	}

	/**
	 * Index existing free cart lines by free identity.
	 *
	 * @param array $cart_contents Cart contents.
	 * @return array<string, array{key:string,quantity:int}>
	 */
	private function index_existing_free_lines( array $cart_contents ) {
		$indexed = array();

		foreach ( $cart_contents as $key => $item ) {
			if ( empty( $item[ self::CART_KEY ]['free'] ) ) {
				continue;
			}

			$rule_id  = isset( $item[ self::CART_KEY ]['rule_id'] ) ? absint( $item[ self::CART_KEY ]['rule_id'] ) : 0;
			$identity = $this->free_identity( $this->item_identity( $item ), $rule_id );

			$indexed[ $identity ] = array(
				'key'      => $key,
				'quantity' => (int) $item['quantity'],
			);
		}

		return $indexed;
	}

	/**
	 * Add a free gift cart line.
	 *
	 * @param \WC_Cart $cart Cart.
	 * @param array    $need Desired free line data.
	 * @return bool Whether a line was added.
	 */
	private function add_free_line( $cart, array $need ) {
		$product_id   = absint( $need['product_id'] );
		$variation_id = absint( $need['variation_id'] );
		$quantity     = max( 1, absint( $need['quantity'] ) );
		$variation    = isset( $need['variation'] ) && is_array( $need['variation'] ) ? $need['variation'] : array();
		$rule_id      = absint( $need['rule_id'] );

		$cart_item_data = array(
			self::CART_KEY => array(
				'free'          => true,
				'rule_id'       => $rule_id,
				'paid_identity' => isset( $need['paid_identity'] ) ? $need['paid_identity'] : '',
			),
			// Keep free lines from merging with paid lines of the same product.
			'unique_key' => md5( 'wwp_dr_buy_x_free_' . $rule_id . '_' . $product_id . '_' . $variation_id ),
		);

		/**
		 * Filter cart item data before adding a Buy X Get X free line.
		 *
		 * @since 3.2.0
		 * @param array $cart_item_data Cart item data.
		 * @param array $need           Desired free line.
		 */
		$cart_item_data = apply_filters( 'wwp_dynamic_rule_buy_x_free_cart_item_data', $cart_item_data, $need );

		self::$adding_free = true;
		try {
			$key = $cart->add_to_cart( $product_id, $quantity, $variation_id, $variation, $cart_item_data );
		} finally {
			self::$adding_free = false;
		}

		return ! empty( $key );
	}

	/**
	 * Stable identity for a cart product line (product + variation).
	 *
	 * @param array $item Cart item.
	 * @return string
	 */
	private function item_identity( array $item ) {
		$product_id   = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
		$variation_id = isset( $item['variation_id'] ) ? absint( $item['variation_id'] ) : 0;

		if ( ! $product_id && isset( $item['data'] ) && $item['data'] instanceof \WC_Product ) {
			$product = $item['data'];
			if ( $product->is_type( 'variation' ) ) {
				$variation_id = $product->get_id();
				$product_id   = $product->get_parent_id();
			} else {
				$product_id = $product->get_id();
			}
		}

		return $product_id . ':' . $variation_id;
	}

	/**
	 * Identity for a free gift line (paid identity + rule).
	 *
	 * @param string $paid_identity Paid item identity.
	 * @param int    $rule_id       Rule post ID.
	 * @return string
	 */
	private function free_identity( $paid_identity, $rule_id ) {
		return $paid_identity . ':rule:' . absint( $rule_id );
	}
}
