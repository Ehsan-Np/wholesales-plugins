<?php
/**
 * Dynamic Rules meta helper.
 *
 * Centralizes defaults, sanitization, labels, and summary/column formatting
 * for the dynamic_rules custom post type.
 *
 * @package WooCommerceWholesalePricing\App\Services\DynamicRules
 */

namespace WooCommerceWholesalePricing\App\Services\DynamicRules;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

/**
 * Helper for reading and formatting Dynamic Rule post meta.
 */
class RuleMetaHelper {

	const META_KEY = '_wwp_dynamic_rule';

	/**
	 * Default rule meta structure.
	 *
	 * @return array
	 */
	public static function get_defaults() {
		return array(
			'rule_type'         => 'raise-percentage',
			'applies_to'        => 'all_products',
			'products'          => array(),
			'categories'        => array(),
			'price_increase'    => 1,
			'free_items'        => 1,
			'buy_quantity'      => 1,
			'tax_fee'           => 1,
			'tax_label'         => 'Additional Tax',
			'condition'         => 'total_spent',
			'threshold'         => 1,
			'applies_to_roles'  => array(),
			'applies_to_groups' => array(),
			'move_to_group'     => 0,
			'notify_customer'   => 'no',
			'apply_all_roles'   => 'yes',
			'roles'             => array(),
			'apply_all_groups'  => 'yes',
			'groups'            => array(),
			'b2c_customer'      => 'no',
			'guest_users'       => 'no',
			'specific_users'    => array(),
		);
	}

	/**
	 * Whether wholesale groups are enabled.
	 *
	 * @return bool
	 */
	public static function is_groups_enabled() {
		$settings = WholesaleSettingsHelper::get_pricing_settings();
		return isset( $settings['enable_groups'] ) && 'yes' === $settings['enable_groups'];
	}

	/**
	 * Rule type options for the admin select.
	 *
	 * @param bool|null $groups_enabled Whether groups feature is enabled.
	 * @return array<string, string>
	 */
	public static function get_rule_type_options( $groups_enabled = null ) {
		if ( null === $groups_enabled ) {
			$groups_enabled = self::is_groups_enabled();
		}

		$options = array(
			'raise-percentage'       => __( 'Raise Price (Percentage)', 'woocommerce-wholesale-pricing' ),
			'buy-x-get-x'            => __( 'Buy X Get X Free', 'woocommerce-wholesale-pricing' ),
			'change-group'           => __( 'Change Group', 'woocommerce-wholesale-pricing' ),
			'add-tax-fee-percentage' => __( 'Add Tax Fee (Percentage)', 'woocommerce-wholesale-pricing' ),
			'add-tax-fee-fixed'      => __( 'Add Tax Fee (Fixed)', 'woocommerce-wholesale-pricing' ),
		);

		/**
		 * Filter dynamic rule type options.
		 *
		 * @since 3.2.0
		 * @param array $options        Rule type slug => label.
		 * @param bool  $groups_enabled Whether groups are enabled.
		 */
		return apply_filters( 'wwp_dynamic_rule_type_options', $options, $groups_enabled );
	}

	/**
	 * Condition options for Change Group rules.
	 *
	 * @return array<string, string>
	 */
	public static function get_condition_options() {
		$options = array(
			'total_spent'             => __( 'Total Spent (All Time order value)', 'woocommerce-wholesale-pricing' ),
			'yearly_order_value'      => __( 'Yearly order value', 'woocommerce-wholesale-pricing' ),
			'monthly_order_value'     => __( 'Monthly order value', 'woocommerce-wholesale-pricing' ),
			'no_of_orders'            => __( 'No of orders', 'woocommerce-wholesale-pricing' ),
			'days_since_registration' => __( 'Day since registration', 'woocommerce-wholesale-pricing' ),
		);

		/**
		 * Filter change-group condition options.
		 *
		 * @since 3.2.0
		 * @param array $options Condition slug => label.
		 */
		return apply_filters( 'wwp_dynamic_rule_condition_options', $options );
	}

	/**
	 * Applies-to options for product-scoped rule types.
	 *
	 * @return array<string, string>
	 */
	public static function get_applies_to_options() {
		return array(
			'all_products'         => __( 'All Products', 'woocommerce-wholesale-pricing' ),
			'specific_products'    => __( 'Specific Products', 'woocommerce-wholesale-pricing' ),
			'specific_categories'  => __( 'Specific Categories', 'woocommerce-wholesale-pricing' ),
		);
	}

	/**
	 * Get saved rule meta for a post, merged with defaults.
	 *
	 * @param int $post_id Post ID.
	 * @return array
	 */
	public static function get_rule( $post_id ) {
		$stored = get_post_meta( absint( $post_id ), self::META_KEY, true );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		return wp_parse_args( $stored, self::get_defaults() );
	}

	/**
	 * Sanitize posted rule data.
	 *
	 * @param array $raw Raw posted data (typically $_POST['wwp_dynamic_rule']).
	 * @return array
	 */
	public static function sanitize( $raw ) {
		if ( ! is_array( $raw ) ) {
			$raw = array();
		}

		$defaults   = self::get_defaults();
		$rule_types = array_keys( self::get_rule_type_options( true ) );
		$rule_type  = isset( $raw['rule_type'] ) ? sanitize_text_field( wp_unslash( $raw['rule_type'] ) ) : $defaults['rule_type'];

		if ( ! in_array( $rule_type, $rule_types, true ) ) {
			$rule_type = $defaults['rule_type'];
		}

		// Change Group requires groups to be enabled.
		if ( 'change-group' === $rule_type && ! self::is_groups_enabled() ) {
			$rule_type = $defaults['rule_type'];
		}

		$applies_to_options = array_keys( self::get_applies_to_options() );
		$applies_to         = isset( $raw['applies_to'] ) ? sanitize_text_field( wp_unslash( $raw['applies_to'] ) ) : $defaults['applies_to'];
		if ( ! in_array( $applies_to, $applies_to_options, true ) ) {
			$applies_to = $defaults['applies_to'];
		}

		$products = array();
		if ( ! empty( $raw['products'] ) && is_array( $raw['products'] ) ) {
			$products = array_values( array_filter( array_map( 'absint', $raw['products'] ) ) );
		}

		$categories = array();
		if ( ! empty( $raw['categories'] ) && is_array( $raw['categories'] ) ) {
			$categories = array_values(
				array_filter(
					array_map(
						function ( $slug ) {
							return sanitize_title( wp_unslash( $slug ) );
						},
						$raw['categories']
					)
				)
			);
		}

		$condition_options = array_keys( self::get_condition_options() );
		$condition         = isset( $raw['condition'] ) ? sanitize_text_field( wp_unslash( $raw['condition'] ) ) : $defaults['condition'];
		if ( ! in_array( $condition, $condition_options, true ) ) {
			$condition = $defaults['condition'];
		}

		$applies_to_roles = array();
		if ( ! empty( $raw['applies_to_roles'] ) && is_array( $raw['applies_to_roles'] ) ) {
			$applies_to_roles = array_values(
				array_filter(
					array_map(
						function ( $slug ) {
							return sanitize_title( wp_unslash( $slug ) );
						},
						$raw['applies_to_roles']
					)
				)
			);
		}

		$applies_to_groups = array();
		if ( ! empty( $raw['applies_to_groups'] ) && is_array( $raw['applies_to_groups'] ) ) {
			$applies_to_groups = array_values( array_filter( array_map( 'absint', $raw['applies_to_groups'] ) ) );
		}

		$notify = isset( $raw['notify_customer'] ) ? sanitize_text_field( wp_unslash( $raw['notify_customer'] ) ) : 'no';
		if ( ! in_array( $notify, array( 'yes', 'no' ), true ) ) {
			$notify = 'no';
		}

		$roles = array();
		if ( ! empty( $raw['roles'] ) && is_array( $raw['roles'] ) ) {
			$roles = array_values(
				array_filter(
					array_map(
						function ( $slug ) {
							return sanitize_title( wp_unslash( $slug ) );
						},
						$raw['roles']
					)
				)
			);
		}

		$groups = array();
		if ( ! empty( $raw['groups'] ) && is_array( $raw['groups'] ) ) {
			$groups = array_values( array_filter( array_map( 'absint', $raw['groups'] ) ) );
		}

		$specific_users = array();
		if ( ! empty( $raw['specific_users'] ) && is_array( $raw['specific_users'] ) ) {
			$specific_users = array_values( array_filter( array_map( 'absint', $raw['specific_users'] ) ) );
		}

		$tax_fee_raw = isset( $raw['tax_fee'] ) ? $raw['tax_fee'] : $defaults['tax_fee'];
		$tax_label   = isset( $raw['tax_label'] ) ? sanitize_text_field( wp_unslash( $raw['tax_label'] ) ) : $defaults['tax_label'];
		if ( '' === trim( $tax_label ) ) {
			$tax_label = $defaults['tax_label'];
		}

		$sanitized = array(
			'rule_type'        => $rule_type,
			'applies_to'       => $applies_to,
			'products'         => $products,
			'categories'       => $categories,
			'price_increase'   => max( 1, absint( isset( $raw['price_increase'] ) ? $raw['price_increase'] : $defaults['price_increase'] ) ),
			'free_items'       => max( 1, absint( isset( $raw['free_items'] ) ? $raw['free_items'] : $defaults['free_items'] ) ),
			'buy_quantity'     => max( 1, absint( isset( $raw['buy_quantity'] ) ? $raw['buy_quantity'] : $defaults['buy_quantity'] ) ),
			'tax_fee'          => max( 1, floatval( $tax_fee_raw ) ),
			'tax_label'        => $tax_label,
			'condition'        => $condition,
			'threshold'        => max( 1, floatval( isset( $raw['threshold'] ) ? $raw['threshold'] : $defaults['threshold'] ) ),
			'applies_to_roles'  => $applies_to_roles,
			'applies_to_groups' => $applies_to_groups,
			'move_to_group'     => absint( isset( $raw['move_to_group'] ) ? $raw['move_to_group'] : 0 ),
			'notify_customer'  => $notify,
			'apply_all_roles'  => ( ! empty( $raw['apply_all_roles'] ) && 'yes' === $raw['apply_all_roles'] ) ? 'yes' : 'no',
			'roles'            => $roles,
			'apply_all_groups' => ( ! empty( $raw['apply_all_groups'] ) && 'yes' === $raw['apply_all_groups'] ) ? 'yes' : 'no',
			'groups'           => $groups,
			'b2c_customer'     => ( ! empty( $raw['b2c_customer'] ) && 'yes' === $raw['b2c_customer'] ) ? 'yes' : 'no',
			'guest_users'      => ( ! empty( $raw['guest_users'] ) && 'yes' === $raw['guest_users'] ) ? 'yes' : 'no',
			'specific_users'   => $specific_users,
		);

		// Change Group clears applicability fields (roles/groups/customers metaboxes are hidden).
		if ( 'change-group' === $sanitized['rule_type'] ) {
			$sanitized['apply_all_roles']  = 'yes';
			$sanitized['roles']            = array();
			$sanitized['apply_all_groups'] = 'yes';
			$sanitized['groups']           = array();
			$sanitized['b2c_customer']     = 'no';
			$sanitized['guest_users']      = 'no';
			$sanitized['specific_users']   = array();
			$sanitized['applies_to']       = 'all_products';
			$sanitized['products']         = array();
			$sanitized['categories']       = array();
		}

		/**
		 * Filter sanitized dynamic rule meta before save.
		 *
		 * @since 3.2.0
		 * @param array $sanitized Sanitized rule data.
		 * @param array $raw       Raw posted data.
		 */
		return apply_filters( 'wwp_dynamic_rule_sanitize', $sanitized, $raw );
	}

	/**
	 * Human-readable rule type label.
	 *
	 * @param array $rule Rule meta.
	 * @return string
	 */
	public static function format_rule_type( $rule ) {
		$types = self::get_rule_type_options( true );
		$type  = isset( $rule['rule_type'] ) ? $rule['rule_type'] : '';
		return isset( $types[ $type ] ) ? $types[ $type ] : '—';
	}

	/**
	 * Format Applies to column / summary value.
	 *
	 * @param array $rule Rule meta.
	 * @return string
	 */
	public static function format_applies_to( $rule ) {
		$type = isset( $rule['rule_type'] ) ? $rule['rule_type'] : '';

		if ( 'change-group' === $type ) {
			$conditions = self::get_condition_options();
			$condition  = isset( $rule['condition'] ) ? $rule['condition'] : '';
			return isset( $conditions[ $condition ] ) ? $conditions[ $condition ] : '—';
		}

		$options    = self::get_applies_to_options();
		$applies_to = isset( $rule['applies_to'] ) ? $rule['applies_to'] : '';

		if ( 'specific_products' === $applies_to && ! empty( $rule['products'] ) && is_array( $rule['products'] ) ) {
			$count = count( $rule['products'] );
			return sprintf(
				/* translators: %d: number of products */
				_n( '%d product', '%d products', $count, 'woocommerce-wholesale-pricing' ),
				$count
			);
		}

		if ( 'specific_categories' === $applies_to && ! empty( $rule['categories'] ) && is_array( $rule['categories'] ) ) {
			$count = count( $rule['categories'] );
			return sprintf(
				/* translators: %d: number of categories */
				_n( '%d category', '%d categories', $count, 'woocommerce-wholesale-pricing' ),
				$count
			);
		}

		return isset( $options[ $applies_to ] ) ? $options[ $applies_to ] : '—';
	}

	/**
	 * Format User roles column / summary value.
	 *
	 * @param array $rule Rule meta.
	 * @return string
	 */
	public static function format_roles( $rule ) {
		if ( isset( $rule['rule_type'] ) && 'change-group' === $rule['rule_type'] ) {
			return '—';
		}

		if ( isset( $rule['apply_all_roles'] ) && 'yes' === $rule['apply_all_roles'] ) {
			return __( 'All wholesale roles', 'woocommerce-wholesale-pricing' );
		}

		if ( empty( $rule['roles'] ) || ! is_array( $rule['roles'] ) ) {
			return '—';
		}

		return self::format_role_slugs( $rule['roles'] );
	}

	/**
	 * Format Groups column / summary value.
	 *
	 * @param array $rule Rule meta.
	 * @return string
	 */
	public static function format_groups( $rule ) {
		if ( ! self::is_groups_enabled() ) {
			return '—';
		}

		if ( isset( $rule['rule_type'] ) && 'change-group' === $rule['rule_type'] ) {
			$from = self::format_group_ids( isset( $rule['applies_to_groups'] ) ? $rule['applies_to_groups'] : array() );
			$to   = '';
			$to_id = isset( $rule['move_to_group'] ) ? absint( $rule['move_to_group'] ) : 0;
			if ( $to_id ) {
				$to_title = get_the_title( $to_id );
				$to       = $to_title ? $to_title : '';
			}

			if ( '—' === $from && '' === $to ) {
				return '—';
			}

			if ( '' === $to ) {
				return $from;
			}

			if ( '—' === $from ) {
				return $to;
			}

			return $from . ' → ' . $to;
		}

		if ( isset( $rule['apply_all_groups'] ) && 'yes' === $rule['apply_all_groups'] ) {
			return __( 'All groups', 'woocommerce-wholesale-pricing' );
		}

		if ( empty( $rule['groups'] ) || ! is_array( $rule['groups'] ) ) {
			return '—';
		}

		$names = array();
		foreach ( $rule['groups'] as $group_id ) {
			$title = get_the_title( absint( $group_id ) );
			if ( $title ) {
				$names[] = $title;
			}
		}

		return $names ? implode( ', ', $names ) : '—';
	}

	/**
	 * Format customers summary line.
	 *
	 * @param array $rule Rule meta.
	 * @return string
	 */
	public static function format_customers( $rule ) {
		if ( isset( $rule['rule_type'] ) && 'change-group' === $rule['rule_type'] ) {
			return '—';
		}

		$parts = array();
		if ( isset( $rule['b2c_customer'] ) && 'yes' === $rule['b2c_customer'] ) {
			$parts[] = __( 'B2C (retail)', 'woocommerce-wholesale-pricing' );
		}
		if ( isset( $rule['guest_users'] ) && 'yes' === $rule['guest_users'] ) {
			$parts[] = __( 'Guest users', 'woocommerce-wholesale-pricing' );
		}

		return $parts ? implode( ', ', $parts ) : '—';
	}

	/**
	 * Format specific users summary line.
	 *
	 * @param array $rule Rule meta.
	 * @return string
	 */
	public static function format_specific_users( $rule ) {
		if ( isset( $rule['rule_type'] ) && 'change-group' === $rule['rule_type'] ) {
			return __( 'All', 'woocommerce-wholesale-pricing' );
		}

		if ( empty( $rule['specific_users'] ) || ! is_array( $rule['specific_users'] ) ) {
			return __( 'All', 'woocommerce-wholesale-pricing' );
		}

		$labels = array();
		foreach ( $rule['specific_users'] as $user_id ) {
			$user = get_user_by( 'id', absint( $user_id ) );
			if ( $user ) {
				$labels[] = $user->display_name;
			}
		}

		return $labels ? implode( ', ', $labels ) : __( 'All', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Build summary rows for the Summary metabox.
	 *
	 * @param array $rule Rule meta.
	 * @return array<string, string> Label => value.
	 */
	public static function build_summary( $rule ) {
		$type_slug = isset( $rule['rule_type'] ) ? $rule['rule_type'] : '';

		$summary = array(
			'type'           => $type_slug ? $type_slug : '—',
			'applies_to'     => self::format_applies_to( $rule ),
			'roles'          => self::format_roles( $rule ),
			'groups'         => self::format_groups( $rule ),
			'customers'      => self::format_customers( $rule ),
			'specific_users' => self::format_specific_users( $rule ),
		);

		/**
		 * Filter dynamic rule summary rows.
		 *
		 * @since 3.2.0
		 * @param array $summary Summary key => display value.
		 * @param array $rule    Rule meta.
		 */
		return apply_filters( 'wwp_dynamic_rule_summary', $summary, $rule );
	}

	/**
	 * Resolve group post IDs to titles.
	 *
	 * @param int[] $ids Group post IDs.
	 * @return string
	 */
	private static function format_group_ids( $ids ) {
		if ( empty( $ids ) || ! is_array( $ids ) ) {
			return '—';
		}

		$names = array();
		foreach ( $ids as $group_id ) {
			$title = get_the_title( absint( $group_id ) );
			if ( $title ) {
				$names[] = $title;
			}
		}

		return $names ? implode( ', ', $names ) : '—';
	}

	/**
	 * Resolve role slugs to display names.
	 *
	 * @param string[] $slugs Role term slugs.
	 * @return string
	 */
	private static function format_role_slugs( array $slugs ) {
		$terms = get_terms(
			array(
				'taxonomy'   => 'wholesale_user_roles',
				'hide_empty' => false,
				'slug'       => $slugs,
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return implode( ', ', $slugs );
		}

		$names = array();
		foreach ( $terms as $term ) {
			$names[] = $term->name;
		}

		return $names ? implode( ', ', $names ) : '—';
	}
}
