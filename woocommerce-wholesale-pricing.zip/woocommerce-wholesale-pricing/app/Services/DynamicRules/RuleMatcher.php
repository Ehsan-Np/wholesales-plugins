<?php
/**
 * Dynamic Rules matcher.
 *
 * Loads published dynamic rules and evaluates product / audience applicability.
 * Selected groups contribute their members (_add_users) and product scope
 * (_include_products / _include_specific_products / _exclude_products) as a
 * union with the rule's own product and user selections.
 *
 * @package WooCommerceWholesalePricing\App\Services\DynamicRules
 */

namespace WooCommerceWholesalePricing\App\Services\DynamicRules;

/**
 * Shared matching helpers for all Dynamic Rule runtime types.
 */
class RuleMatcher {

	/**
	 * Cached published rules keyed by post ID (full meta arrays).
	 *
	 * @var array<int, array>|null
	 */
	private static $rules_cache = null;

	/**
	 * Clear the per-request rules cache.
	 *
	 * @return void
	 */
	public static function clear_cache() {
		self::$rules_cache = null;
	}

	/**
	 * Get matching rules of a given type for a product and user.
	 *
	 * @param string      $rule_type Rule type slug (e.g. raise-percentage).
	 * @param \WC_Product $product   Product object.
	 * @param int|null    $user_id   User ID (defaults to current user).
	 * @return array[] Matched rule meta arrays (includes _post_id).
	 */
	public static function get_matching_rules( $rule_type, $product, $user_id = null ) {
		if ( ! $product instanceof \WC_Product ) {
			return array();
		}

		if ( null === $user_id ) {
			$user_id = is_user_logged_in() ? get_current_user_id() : 0;
		}
		$user_id = absint( $user_id );

		$matched = array();

		foreach ( self::get_rules_by_type( $rule_type ) as $rule ) {
			if ( ! self::matches_product( $rule, $product ) ) {
				continue;
			}
			if ( ! self::matches_audience( $rule, $user_id, $product ) ) {
				continue;
			}
			$matched[] = $rule;
		}

		/**
		 * Filter matching dynamic rules for a product/user.
		 *
		 * @since 3.2.0
		 * @param array       $matched   Matched rules.
		 * @param string      $rule_type Rule type slug.
		 * @param \WC_Product $product   Product.
		 * @param int         $user_id   User ID.
		 */
		return apply_filters( 'wwp_dynamic_rule_matching_rules', $matched, $rule_type, $product, $user_id );
	}

	/**
	 * Whether the given price reflects a wholesale discount vs retail base.
	 *
	 * @param float       $price   Candidate (already discounted) price.
	 * @param \WC_Product $product Product.
	 * @return bool
	 */
	public static function has_wholesale_discount( $price, $product ) {
		if ( ! $product instanceof \WC_Product || ! is_numeric( $price ) ) {
			return false;
		}

		$retail_base = self::get_retail_base_price( $product );
		if ( ! is_numeric( $retail_base ) || (float) $retail_base <= 0 ) {
			return false;
		}

		return (float) $price < ( (float) $retail_base - 0.0001 );
	}

	/**
	 * Resolve retail base price for a product (respects wwp_wholesale_apply_on_sale_price).
	 *
	 * @param \WC_Product $product Product.
	 * @return float
	 */
	public static function get_retail_base_price( $product ) {
		/**
		 * Filter price meta key used as wholesale discount base.
		 *
		 * @since 3.1.0
		 * @param string $_regular_price Default meta key.
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

		$product_id = $product->get_id();
		$base       = get_post_meta( $product_id, $price_key, true );

		if ( '' === $base || false === $base ) {
			$parent_id = $product->get_parent_id();
			if ( $parent_id ) {
				$base = get_post_meta( $parent_id, $price_key, true );
			}
		}

		return (float) $base;
	}

	/**
	 * Get all published rules of a given type.
	 *
	 * @param string $rule_type Rule type slug.
	 * @return array[]
	 */
	public static function get_published_rules( $rule_type ) {
		return self::get_rules_by_type( $rule_type );
	}

	/**
	 * Load all published rules of a type from cache.
	 *
	 * @param string $rule_type Rule type slug.
	 * @return array[]
	 */
	private static function get_rules_by_type( $rule_type ) {
		$all = self::load_all_rules();
		$out = array();

		foreach ( $all as $rule ) {
			if ( isset( $rule['rule_type'] ) && $rule_type === $rule['rule_type'] ) {
				$out[] = $rule;
			}
		}

		return $out;
	}

	/**
	 * Load and cache all published dynamic rules.
	 *
	 * @return array<int, array>
	 */
	private static function load_all_rules() {
		if ( null !== self::$rules_cache ) {
			return self::$rules_cache;
		}

		self::$rules_cache = array();

		$slug = wwp_env()->get( 'dynamic_rules_slug' );
		if ( ! $slug ) {
			$slug = 'dynamic_rules';
		}

		$posts = get_posts(
			array(
				'post_type'      => $slug,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'date',
				'order'          => 'ASC',
				'fields'         => 'ids',
			)
		);

		foreach ( (array) $posts as $post_id ) {
			$rule             = RuleMetaHelper::get_rule( $post_id );
			$rule['_post_id'] = (int) $post_id;
			self::$rules_cache[ (int) $post_id ] = $rule;
		}

		return self::$rules_cache;
	}

	/**
	 * Group IDs whose users/products should contribute to this rule.
	 *
	 * - apply_all_groups = yes → every published wholesale group
	 * - apply_all_groups = no  → only checked groups (empty = no group contribution)
	 *
	 * @param array $rule Rule meta.
	 * @return int[]
	 */
	private static function get_selected_group_ids( array $rule ) {
		if ( ! RuleMetaHelper::is_groups_enabled() ) {
			return array();
		}

		if ( isset( $rule['apply_all_groups'] ) && 'yes' === $rule['apply_all_groups'] ) {
			return self::get_all_published_group_ids();
		}

		$groups = isset( $rule['groups'] ) && is_array( $rule['groups'] )
			? array_values( array_filter( array_map( 'absint', $rule['groups'] ) ) )
			: array();

		return $groups;
	}

	/**
	 * All published wholesale group post IDs.
	 *
	 * @return int[]
	 */
	private static function get_all_published_group_ids() {
		$slug = wwp_env()->get( 'group_slug' );
		if ( ! $slug ) {
			$slug = 'wwp_groups';
		}

		$ids = get_posts(
			array(
				'post_type'      => $slug,
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);

		return array_map( 'absint', (array) $ids );
	}

	/**
	 * Public product-scope check for admin previews.
	 *
	 * @param array       $rule    Rule meta.
	 * @param \WC_Product $product Product.
	 * @return bool
	 */
	public static function product_matches( array $rule, $product ) {
		return self::matches_product( $rule, $product );
	}

	/**
	 * Product scope match.
	 *
	 * Rule product/category selections are unioned with products from any
	 * specifically selected groups (include all/specific, minus excludes).
	 *
	 * @param array       $rule    Rule meta.
	 * @param \WC_Product $product Product.
	 * @return bool
	 */
	private static function matches_product( array $rule, $product ) {
		$group_ids = self::get_selected_group_ids( $rule );
		$applies   = isset( $rule['applies_to'] ) ? $rule['applies_to'] : 'all_products';

		// Specific products selected on the rule but list left empty → products come from groups only.
		if ( 'specific_products' === $applies ) {
			$products = isset( $rule['products'] ) && is_array( $rule['products'] )
				? array_filter( array_map( 'absint', $rule['products'] ) )
				: array();

			if ( empty( $products ) ) {
				return ! empty( $group_ids ) && self::matches_group_products( $group_ids, $product );
			}
		}

		$rule_match  = self::matches_rule_product_scope( $rule, $product );
		$group_match = ! empty( $group_ids ) && self::matches_group_products( $group_ids, $product );

		if ( ! empty( $group_ids ) ) {
			return $rule_match || $group_match;
		}

		return $rule_match;
	}

	/**
	 * Match against the rule's own applies_to / products / categories.
	 *
	 * @param array       $rule    Rule meta.
	 * @param \WC_Product $product Product.
	 * @return bool
	 */
	private static function matches_rule_product_scope( array $rule, $product ) {
		$applies_to = isset( $rule['applies_to'] ) ? $rule['applies_to'] : 'all_products';

		if ( 'all_products' === $applies_to ) {
			return true;
		}

		$product_id = (int) $product->get_id();
		$parent_id  = (int) $product->get_parent_id();

		if ( 'specific_products' === $applies_to ) {
			$products = isset( $rule['products'] ) && is_array( $rule['products'] )
				? array_map( 'absint', $rule['products'] )
				: array();

			if ( empty( $products ) ) {
				return false;
			}

			return in_array( $product_id, $products, true )
				|| ( $parent_id && in_array( $parent_id, $products, true ) );
		}

		if ( 'specific_categories' === $applies_to ) {
			$categories = isset( $rule['categories'] ) && is_array( $rule['categories'] )
				? $rule['categories']
				: array();

			if ( empty( $categories ) ) {
				return false;
			}

			$lookup_id = $parent_id ? $parent_id : $product_id;
			$terms     = get_the_terms( $lookup_id, 'product_cat' );

			if ( is_wp_error( $terms ) || empty( $terms ) ) {
				return false;
			}

			foreach ( $terms as $term ) {
				if ( in_array( $term->slug, $categories, true ) ) {
					return true;
				}
			}

			return false;
		}

		return false;
	}

	/**
	 * Whether product is included by any of the given groups' product settings.
	 *
	 * @param int[]       $group_ids Group post IDs.
	 * @param \WC_Product $product   Product.
	 * @return bool
	 */
	private static function matches_group_products( array $group_ids, $product ) {
		$product_id = (int) $product->get_id();
		$parent_id  = (int) $product->get_parent_id();

		foreach ( $group_ids as $group_id ) {
			if ( self::product_in_group_scope( $group_id, $product_id, $parent_id ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Check group include/exclude product meta for a product.
	 *
	 * Meta keys from group configuration:
	 * - _include_products: 'all' | 'specific'
	 * - _include_specific_products: product ID list when specific
	 * - _exclude_products: product IDs always excluded
	 *
	 * @param int $group_id   Group post ID.
	 * @param int $product_id Product or variation ID.
	 * @param int $parent_id  Parent product ID (0 if simple).
	 * @return bool
	 */
	private static function product_in_group_scope( $group_id, $product_id, $parent_id = 0 ) {
		$exclude = self::normalize_id_list( get_post_meta( $group_id, '_exclude_products', true ) );

		if ( in_array( $product_id, $exclude, true ) || ( $parent_id && in_array( $parent_id, $exclude, true ) ) ) {
			return false;
		}

		$include_type = get_post_meta( $group_id, '_include_products', true );

		// Match core wwp_get_group_post_by_proid(): only 'all' or 'specific' are valid.
		if ( 'specific' === $include_type ) {
			$include = self::normalize_id_list( get_post_meta( $group_id, '_include_specific_products', true ) );

			if ( empty( $include ) ) {
				return false;
			}

			return in_array( $product_id, $include, true )
				|| ( $parent_id && in_array( $parent_id, $include, true ) );
		}

		if ( 'all' === $include_type ) {
			return true;
		}

		return false;
	}

	/**
	 * Normalize meta that may be an array of string/int IDs into int[].
	 *
	 * @param mixed $value Raw meta.
	 * @return int[]
	 */
	private static function normalize_id_list( $value ) {
		if ( empty( $value ) && '0' !== $value && 0 !== $value ) {
			return array();
		}

		if ( ! is_array( $value ) ) {
			$value = array( $value );
		}

		return array_values( array_filter( array_map( 'absint', $value ) ) );
	}

	/**
	 * Audience match: guests, B2C, specific users, group members, and wholesale roles (OR).
	 *
	 * Guest users and B2C checkboxes are independent of roles/groups/specific users.
	 *
	 * @param array       $rule      Rule meta.
	 * @param int         $user_id   User ID (0 = guest).
	 * @param \WC_Product $product   Product.
	 * @return bool
	 */
	private static function matches_audience( array $rule, $user_id, $product ) {
		unset( $product );

		$user_id      = absint( $user_id );
		$is_logged_in = $user_id > 0;

		// Guest users (not logged in) — independent of roles / groups.
		if ( ! $is_logged_in ) {
			return self::is_yes( $rule, 'guest_users' );
		}

		// Named customers.
		$specific_users = self::normalize_id_list( isset( $rule['specific_users'] ) ? $rule['specific_users'] : array() );
		if ( in_array( $user_id, $specific_users, true ) ) {
			return true;
		}

		$is_wholesaler = self::user_is_wholesaler( $user_id );

		// B2C (logged in, no wholesale role) — independent of roles / groups.
		if ( ! $is_wholesaler ) {
			return self::is_yes( $rule, 'b2c_customer' );
		}

		$group_ids = self::get_selected_group_ids( $rule );
		if ( ! empty( $group_ids ) && self::user_in_selected_groups( $user_id, $group_ids ) ) {
			return true;
		}

		// When groups are selected, do not auto-match every wholesale role.
		$skip_apply_all = ! empty( $group_ids );

		return self::matches_customer_or_role( $rule, $user_id, $skip_apply_all );
	}

	/**
	 * Whether a yes/no rule flag is enabled.
	 *
	 * @param array  $rule Rule meta.
	 * @param string $key  Flag key.
	 * @return bool
	 */
	private static function is_yes( array $rule, $key ) {
		return isset( $rule[ $key ] ) && 'yes' === $rule[ $key ];
	}

	/**
	 * Whether the user has a wholesale role (not guest, not B2C).
	 *
	 * @param int $user_id User ID.
	 * @return bool
	 */
	private static function user_is_wholesaler( $user_id ) {
		$user_id = absint( $user_id );
		if ( ! $user_id ) {
			return false;
		}

		if ( (int) get_current_user_id() === $user_id && function_exists( 'get_current_user_role_id' ) ) {
			return ! empty( get_current_user_role_id() );
		}

		if ( function_exists( 'is_wholesaler_user' ) ) {
			return (bool) is_wholesaler_user( $user_id );
		}

		return false;
	}

	/**
	 * Whether user is a member of any selected group (_add_users).
	 *
	 * @param int   $user_id   User ID.
	 * @param int[] $group_ids Group post IDs.
	 * @return bool
	 */
	private static function user_in_selected_groups( $user_id, array $group_ids ) {
		$user_id = (int) $user_id;

		// Primary membership source used by group pricing (wwp_get_group_post_by_proid).
		foreach ( $group_ids as $group_id ) {
			$members = self::normalize_id_list( get_post_meta( $group_id, '_add_users', true ) );
			if ( in_array( $user_id, $members, true ) ) {
				return true;
			}
		}

		// Fallback: user meta set when the group is saved.
		$user_group = absint( get_user_meta( $user_id, 'user_wwp_groupname', true ) );
		if ( $user_group && in_array( $user_group, $group_ids, true ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Roles / guest / B2C audience.
	 *
	 * @param array $rule             Rule meta.
	 * @param int   $user_id          User ID.
	 * @param bool  $skip_apply_all   When true, ignore apply_all_roles blanket (used with group targeting).
	 * @return bool
	 */
	private static function matches_customer_or_role( array $rule, $user_id, $skip_apply_all = false ) {
		if ( absint( $user_id ) < 1 ) {
			return self::is_yes( $rule, 'guest_users' );
		}

		if ( ! self::user_is_wholesaler( $user_id ) ) {
			return self::is_yes( $rule, 'b2c_customer' );
		}

		$wholesale_id = function_exists( 'get_current_user_role_id' ) ? get_current_user_role_id() : false;

		// Wholesale roles.
		if ( ! $skip_apply_all && self::is_yes( $rule, 'apply_all_roles' ) ) {
			return true;
		}

		$roles = isset( $rule['roles'] ) && is_array( $rule['roles'] ) ? $rule['roles'] : array();
		if ( empty( $roles ) ) {
			return false;
		}

		$term = get_term( (int) $wholesale_id, 'wholesale_user_roles' );
		if ( ! $term || is_wp_error( $term ) ) {
			return false;
		}

		return in_array( $term->slug, $roles, true );
	}
}
