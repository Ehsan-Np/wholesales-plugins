<?php
/**
 * Read and update wholesale email notification settings.
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

/**
 * Manages the five fixed wholesale registration email notifications.
 */
class WholesaleEmailNotificationService {

	/**
	 * Notification definitions keyed by identifier.
	 *
	 * @var array<string, array{title: string, requires_subscription: bool, fields: array<string, array{option: string, type: string}>}>
	 */
	const NOTIFICATIONS = array(
		'admin_new_registration'       => array(
			'title'                  => 'Admin Notification (New Registration Request)',
			'requires_subscription'  => false,
			'fields'                 => array(
				'enabled'                      => array(
					'option' => 'wwp_wholesale_admin_request_notification',
					'type'   => 'yes_no',
				),
				'stop_site_admin_notification' => array(
					'option' => 'wwp_wholesale_stop_admin_notification',
					'type'   => 'yes_no',
				),
				'recipients'                   => array(
					'option' => 'wwp_wholesale_admin_request_recipient',
					'type'   => 'string',
				),
				'subject'                      => array(
					'option' => 'wwp_wholesale_admin_request_subject',
					'type'   => 'string',
				),
				'body'                         => array(
					'option' => 'wwp_wholesale_admin_request_body',
					'type'   => 'html',
				),
			),
		),
		'user_new_registration'        => array(
			'title'                  => 'User Notification (New Registration Request)',
			'requires_subscription'  => false,
			'fields'                 => array(
				'enabled' => array(
					'option' => 'wwp_wholesale_user_registration_notification',
					'type'   => 'yes_no',
				),
				'subject' => array(
					'option' => 'wwp_wholesale_registration_notification_subject',
					'type'   => 'string',
				),
				'body'    => array(
					'option' => 'wwp_wholesale_registration_notification_body',
					'type'   => 'html',
				),
			),
		),
		'user_registration_rejection'  => array(
			'title'                  => 'User Notification (Registration Request Rejection Notification)',
			'requires_subscription'  => false,
			'fields'                 => array(
				'enabled' => array(
					'option' => 'wwp_wholesale_user_rejection_notification',
					'type'   => 'yes_no',
				),
				'subject' => array(
					'option' => 'wwp_wholesale_rejection_notification_subject',
					'type'   => 'string',
				),
				'body'    => array(
					'option' => 'wwp_wholesale_rejection_notification_body',
					'type'   => 'html',
				),
			),
		),
		'user_registration_approval'   => array(
			'title'                  => 'User Notification (Registration Request Approval Notification)',
			'requires_subscription'  => false,
			'fields'                 => array(
				'enabled' => array(
					'option' => 'wwp_wholesale_request_approve_notification',
					'type'   => 'yes_no',
				),
				'subject' => array(
					'option' => 'wwp_wholesale_email_request_subject',
					'type'   => 'string',
				),
				'body'    => array(
					'option' => 'wwp_wholesale_email_request_body',
					'type'   => 'html',
				),
			),
		),
		'user_role_upgrade'            => array(
			'title'                  => 'User Role Upgrade Notification',
			'requires_subscription'  => true,
			'fields'                 => array(
				'enabled' => array(
					'option' => 'wwp_wholesale_subscription_role_notification',
					'type'   => 'yes_no',
				),
				'subject' => array(
					'option' => 'wwp_wholesale_subscription_role_subject',
					'type'   => 'string',
				),
				'body'    => array(
					'option' => 'wwp_wholesale_subscription_role_body',
					'type'   => 'html',
				),
			),
		),
	);

	/**
	 * List all notification identifiers.
	 *
	 * @return list<string>
	 */
	public function list_notification_ids() {
		return array_keys( self::NOTIFICATIONS );
	}

	/**
	 * List all notifications with settings.
	 *
	 * @return list<array<string, mixed>>
	 */
	public function list_notifications() {
		$notifications = array();

		foreach ( self::NOTIFICATIONS as $id => $definition ) {
			if ( ! empty( $definition['requires_subscription'] ) && ! $this->wwp_is_subscription_active() ) {
				$notifications[] = array(
					'id'        => $id,
					'title'     => $definition['title'],
					'available' => false,
					'settings'  => null,
				);
				continue;
			}

			$notifications[] = $this->format_notification( $id, $definition );
		}

		return $notifications;
	}

	/**
	 * Get a single notification by identifier.
	 *
	 * @param string $identifier Notification id.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function get_notification( $identifier ) {
		$definition = $this->get_definition( $identifier );
		if ( is_wp_error( $definition ) ) {
			return $definition;
		}

		return $this->format_notification( $identifier, $definition );
	}

	/**
	 * Update notification settings (partial merge).
	 *
	 * @param string               $identifier Notification id.
	 * @param array<string, mixed> $settings   Settings to update.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_notification( $identifier, array $settings ) {
		$definition = $this->get_definition( $identifier );
		if ( is_wp_error( $definition ) ) {
			return $definition;
		}

		if ( empty( $settings ) ) {
			return new \WP_Error(
				'wwp_notification_missing_settings',
				__( 'Notification settings are required for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$allowed_keys = array_keys( $definition['fields'] );
		$settings     = array_intersect_key( $settings, array_flip( $allowed_keys ) );

		if ( empty( $settings ) ) {
			return new \WP_Error(
				'wwp_notification_invalid_field',
				sprintf(
					/* translators: %s: comma-separated field names allowed for this notification */
					__( 'No valid notification fields for this template. Allowed field(s): %s', 'woocommerce-wholesale-pricing' ),
					implode( ', ', $allowed_keys )
				),
				array( 'status' => 400 )
			);
		}

		foreach ( $settings as $field_key => $value ) {
			$field     = $definition['fields'][ $field_key ];
			$sanitized = $this->sanitize_field_value( $field['type'], $value );
			if ( is_wp_error( $sanitized ) ) {
				return $sanitized;
			}

			$persisted = $this->persist_option( $field['option'], $sanitized );
			if ( is_wp_error( $persisted ) ) {
				return $persisted;
			}
		}

		return $this->format_notification( $identifier, $definition );
	}

	/**
	 * Persist a single WordPress option value.
	 *
	 * Update_option() returns false when the value is unchanged, so verify by re-reading.
	 *
	 * @param string $option Option name.
	 * @param mixed  $value  Value to store.
	 * @return true|\WP_Error
	 */
	private function persist_option( $option, $value ) {
		$previous = get_option( $option, null );

		if ( $this->option_values_match( $previous, $value ) ) {
			wp_cache_delete( $option, 'options' );
			return true;
		}

		update_option( $option, $value );

		$stored = get_option( $option, null );
		if ( $this->option_values_match( $stored, $value ) ) {
			wp_cache_delete( $option, 'options' );
			return true;
		}

		// Option may not exist yet (update_option can no-op in edge cases).
		if ( null === $previous || false === $previous ) {
			add_option( $option, $value, '', false );
			$stored = get_option( $option, null );
			if ( $this->option_values_match( $stored, $value ) ) {
				wp_cache_delete( $option, 'options' );
				return true;
			}
		}

		return new \WP_Error(
			'wwp_notification_update_failed',
			sprintf(
				/* translators: %s: WordPress option name */
				__( 'Failed to save notification option "%s".', 'woocommerce-wholesale-pricing' ),
				$option
			),
			array( 'status' => 500 )
		);
	}

	/**
	 * Compare stored and target option values.
	 *
	 * @param mixed $stored Stored value.
	 * @param mixed $target Target value.
	 * @return bool
	 */
	private function option_values_match( $stored, $target ) {
		if ( $stored === $target ) {
			return true;
		}

		return is_scalar( $stored ) && is_scalar( $target ) && (string) $stored === (string) $target;
	}

	/**
	 * Snapshot raw option values for undo.
	 *
	 * @param string $identifier Notification id.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function snapshot_notification( $identifier ) {
		$definition = $this->get_definition( $identifier );
		if ( is_wp_error( $definition ) ) {
			return $definition;
		}

		$options = array();
		foreach ( $definition['fields'] as $field ) {
			$options[ $field['option'] ] = get_option( $field['option'] );
		}

		return array(
			'notification_id' => $identifier,
			'options'         => $options,
		);
	}

	/**
	 * Restore notification options from a snapshot.
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_notification( array $snapshot ) {
		$identifier = (string) ( isset( $snapshot['notification_id'] ) ? $snapshot['notification_id'] : '' );
		$options    = is_array( isset( $snapshot['options'] ) ? $snapshot['options'] : null ) ? $snapshot['options'] : array();

		if ( '' === $identifier || empty( $options ) ) {
			return new \WP_Error(
				'wwp_notification_restore_invalid_snapshot',
				__( 'Cannot restore notification: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$definition = $this->get_definition( $identifier );
		if ( is_wp_error( $definition ) ) {
			return $definition;
		}

		$allowed_options = array_column( $definition['fields'], 'option', 'option' );

		foreach ( $options as $option_key => $value ) {
			if ( ! isset( $allowed_options[ $option_key ] ) ) {
				continue;
			}

			$persisted = $this->persist_option( $option_key, $value );
			if ( is_wp_error( $persisted ) ) {
				return $persisted;
			}
		}

		return true;
	}

	/**
	 * List allowed setting keys for a notification identifier.
	 *
	 * @param string $identifier Notification id.
	 * @return list<string>|\WP_Error
	 */
	public function get_allowed_field_keys( $identifier ) {
		$definition = $this->get_definition( $identifier );
		if ( is_wp_error( $definition ) ) {
			return $definition;
		}

		return array_keys( $definition['fields'] );
	}

	/**
	 * Resolve a notification definition.
	 *
	 * @param string $identifier Notification id.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function get_definition( $identifier ) {
		$identifier = sanitize_key( $identifier );

		if ( ! isset( self::NOTIFICATIONS[ $identifier ] ) ) {
			return new \WP_Error(
				'wwp_notification_not_found',
				__( 'Notification not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		$definition = self::NOTIFICATIONS[ $identifier ];

		if ( ! empty( $definition['requires_subscription'] ) && ! $this->wwp_is_subscription_active() ) {
			return new \WP_Error(
				'wwp_notification_unavailable',
				__( 'This notification requires WooCommerce Subscriptions.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return $definition;
	}

	/**
	 * Format a notification for API output.
	 *
	 * @param string               $identifier Notification id.
	 * @param array<string, mixed> $definition Notification definition.
	 * @return array<string, mixed>|\WP_Error
	 */
	private function format_notification( $identifier, array $definition ) {
		if ( ! empty( $definition['requires_subscription'] ) && ! $this->wwp_is_subscription_active() ) {
			return new \WP_Error(
				'wwp_notification_unavailable',
				__( 'This notification requires WooCommerce Subscriptions.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		$settings = array();
		foreach ( $definition['fields'] as $field_key => $field ) {
			$settings[ $field_key ] = $this->format_field_value( $field['type'], get_option( $field['option'] ) );
		}

		return array(
			'id'        => $identifier,
			'title'     => $definition['title'],
			'available' => true,
			'settings'  => $settings,
		);
	}

	/**
	 * Format a stored option value for API output.
	 *
	 * @param string $type  Field type.
	 * @param mixed  $value Stored value.
	 * @return mixed
	 */
	private function format_field_value( $type, $value ) {
		if ( 'yes_no' === $type ) {
			return 'yes' === $value;
		}

		if ( 'html' === $type ) {
			return is_string( $value ) ? html_entity_decode( $value, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401 ) : '';
		}

		return is_string( $value ) ? $value : (string) $value;
	}

	/**
	 * Sanitize an incoming field value before saving.
	 *
	 * @param string $type  Field type.
	 * @param mixed  $value Incoming value.
	 * @return mixed|\WP_Error
	 */
	private function sanitize_field_value( $type, $value ) {
		if ( 'yes_no' === $type ) {
			return $this->sanitize_yes_no_value( $value );
		}

		if ( 'html' === $type ) {
			return is_string( $value ) ? wp_kses_post( $value ) : '';
		}

		return is_string( $value ) ? sanitize_text_field( $value ) : sanitize_text_field( (string) $value );
	}

	/**
	 * Match admin checkbox storage: enabled = "yes", disabled = empty string.
	 *
	 * @param mixed $value Incoming value.
	 * @return string|\WP_Error
	 */
	private function sanitize_yes_no_value( $value ) {
		if ( is_bool( $value ) ) {
			return $value ? 'yes' : '';
		}

		if ( is_numeric( $value ) ) {
			return (int) 1 === $value ? 'yes' : '';
		}

		if ( is_string( $value ) ) {
			$normalized = strtolower( trim( $value ) );
			if ( in_array( $normalized, array( 'yes', '1', 'true', 'on' ), true ) ) {
				return 'yes';
			}
			if ( in_array( $normalized, array( 'no', '0', 'false', 'off', '' ), true ) ) {
				return '';
			}
		}

		if ( null === $value ) {
			return '';
		}

		return new \WP_Error(
			'wwp_notification_invalid_boolean',
			__( 'Boolean notification fields must be true or false.', 'woocommerce-wholesale-pricing' ),
			array( 'status' => 400 )
		);
	}

	/**
	 * Whether WooCommerce Subscriptions is active.
	 *
	 * @return bool
	 */
	private function wwp_is_subscription_active() {
		if ( function_exists( 'wwp_is_subscription_active' ) ) {
			return (bool) wwp_is_subscription_active();
		}

		return false;
	}
}
