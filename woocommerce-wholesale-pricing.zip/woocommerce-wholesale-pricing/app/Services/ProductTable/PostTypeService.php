<?php

namespace WooCommerceWholesalePricing\App\Services\ProductTable;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service for registering wholesale-related custom post types.
 * 
 * @extends Init
 */
class PostTypeService extends Init implements ServiceInterface {
	use WholesaleSettings;

	public $slug;

	public function __construct() {

		$this->slug = wwp_env()->get('product_table_slug');

		add_action('add_meta_boxes', array( $this, 'meta_boxes' ));
		add_action('save_post_' . $this->slug, array( $this, 'save_post' ), 10);

		add_filter('manage_' . $this->slug . '_posts_columns', array( $this, 'columns' ));
		add_action('manage_' . $this->slug . '_posts_custom_column', array( $this, 'column_values' ), 10, 2);
		add_filter('post_row_actions', array( $this, 'row_actions' ), 10, 2);
		add_filter('get_edit_post_link', array( $this, 'append_table_type_to_edit_link' ), 10, 3);
		add_filter('redirect_post_location', array( $this, 'preserve_table_type_on_redirect' ), 10, 2);

		parent::__construct();
	}

	public function register() {
		
		$settings = self::get_pricing_settings();

		if ( ! isset( $settings['product_table'] ) || 'no' === $settings['product_table'] ) {
			return;
		}

		/**
		 * Filter product table menu title
		 * 
		 * @since 1.1.5
		**/
		$product_table_title = apply_filters('wcpt_menu_title', __('Product Table', 'woocommerce-wholesale-pricing'));
		$button_labels = array(
			'name'               => $product_table_title,
			'singular_name'      => $product_table_title,
			'menu_name'          => $product_table_title,
			'name_admin_bar'     => $product_table_title,
			'add_new'            => __('Add New', 'woocommerce-wholesale-pricing'),
			'add_new_item'       => __('Add New Table', 'woocommerce-wholesale-pricing'),
			'new_item'           => __('New Table', 'woocommerce-wholesale-pricing'),
			'edit_item'          => __('Edit Table', 'woocommerce-wholesale-pricing'),
			'view_item'          => __('View Table', 'woocommerce-wholesale-pricing'),
			'all_items'          => __('Product Table', 'woocommerce-wholesale-pricing'),
			'search_items'       => __('Search Table', 'woocommerce-wholesale-pricing'),
			'parent_item_colon'  => __('Parent Table:', 'woocommerce-wholesale-pricing'),
			'not_found'          => __('No results found.', 'woocommerce-wholesale-pricing'),
			'not_found_in_trash' => __('No results found in Trash.', 'woocommerce-wholesale-pricing'),
		);

		$button_args = array(
			'labels'             => $button_labels,
			'description'        => __('Products Table.', 'woocommerce-wholesale-pricing'),
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			/**
			 * Filter product table show in menu
			 * 
			 * @since 1.1.5
			**/
			'show_in_menu'       => false,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'wcpt' ),
			'capability_type'    => 'post',
			/**
			 * Filter product table menu position
			 * 
			 * @since 1.1.5
			**/
			'menu_position'      => apply_filters('wcpt_menu_position', null),
			'menu_icon'          => 'dashicons-editor-table',
			'supports'           => array( 'title' ),
		);
		
		/**
		 * Filter product table register post type
		 * 
		 * @since 3.2.0
		**/
		register_post_type('wcpt', apply_filters('wcpt_register_post_type', $button_args));
	}

	public function meta_boxes() {
		global $post;

		$is_quick_order = TableTypeHelper::is_quick_order_form( $post );

		if ( $is_quick_order ) {
			add_meta_box('wcpt-settings', __('Product Table Settings', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'settings' ));
			add_meta_box('wcpt-products-display-settings', __('Choosing which products appear in the table', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'products-display-options' ));
			add_meta_box('wcpt-user-registration', __('User Role Restriction', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'user-restriction' ));
			add_meta_box('wcpt-shortcode-generates', __('Shortcode', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'side', 'default', array( 'file' => 'quick-order-shortcode' ));
			return;
		}

		add_meta_box('wcpt-settings', __('Product Table Settings', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'settings' ));
		add_meta_box('wcpt-header-footer-settings', __('Table Header & Footer Settings', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'header-footer-options' ));
		add_meta_box('wcpt-variation-product-settings', __('Variation Product Display Settings', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'variation-product-display-options' ));
		add_meta_box('wcpt-group-product-settings', __('Group Product Display Settings', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'group-product-display-options' ));
		add_meta_box('wcpt-table-contols-settings', __('Add controls above & below the table Settings', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'controls-table-options' ));
		add_meta_box('wcpt-table-size-settings', __('Control Table Size Settings', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'table-size-options' ));
		add_meta_box('wcpt-table-content-settings', __('Control Table Contents Settings', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'table-content-options' ));
		add_meta_box('wcpt-adv-search-settings', __('Advanced Search Settings', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'advanced-search-options' ));
		add_meta_box('wcpt-product-sorted-settings', __('Controls how products are sorted Settings', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'products-sort-options' ));
		add_meta_box('wcpt-products-display-settings', __('Choosing which products appear in the table', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'products-display-options' ));
		add_meta_box('wcpt-responsive-settings', __('Responsive', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'responsive-options' ));
		add_meta_box('wcpt-mini-cart-settings', __('Mini Cart', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'mini-cart-options' ));
		add_meta_box('wcpt-table-design-settings', __('Table Design', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'table-design-view' ));
		add_meta_box('wcpt-user-registration', __('User Role Restriction', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'advanced', 'default', array( 'file' => 'user-restriction' ));

		add_meta_box('wcpt-shortcode-generates', __('Shortcode', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'side', 'default', array( 'file' => 'shortcode' ));
		add_meta_box('wcpt-onepage-checkout', __('One-Page Checkout', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'side', 'default', array( 'file' => 'one-page-checkout' ));
		add_meta_box('wcpt-export-table', __('Export', 'woocommerce-wholesale-pricing'), array( $this, 'callback' ), $this->slug, 'side', 'default', array( 'file' => 'export-table' ));
	}

	public function callback( $post, $args ) {
		$post_id = $post->ID;
		return wwp_view('admin.product-table.meta-box.' . $args['args']['file'], compact('post_id', 'post'));
	}

	public function columns( $columns ) {
		$temp = $columns['date'];
		unset($columns['date']);
		$columns['wcpt_table_type']      = __('Type', 'woocommerce-wholesale-pricing');
		$columns['shortcode']            = __('Shortcode', 'woocommerce-wholesale-pricing');
		$columns['wcpt_columns']         = __('Columns', 'woocommerce-wholesale-pricing');
		$columns['wcpt_onepage_checkout'] = __('One Page Checkout', 'woocommerce-wholesale-pricing');
		$columns['wcpt_status']          = __('Status', 'woocommerce-wholesale-pricing');
		$columns['date'] = $temp;
		return $columns;
	}

	/**
	 * Default labels for product table column types.
	 *
	 * @return array<string, string>
	 */
	private function get_field_type_labels() {
		return array(
			'id'            => __('ID', 'woocommerce-wholesale-pricing'),
			'title'         => __('Title', 'woocommerce-wholesale-pricing'),
			'sku'           => __('SKU', 'woocommerce-wholesale-pricing'),
			'short_desc'    => __('Short Description', 'woocommerce-wholesale-pricing'),
			'descr'         => __('Description', 'woocommerce-wholesale-pricing'),
			'date'          => __('Date', 'woocommerce-wholesale-pricing'),
			'cat'           => __('Categories', 'woocommerce-wholesale-pricing'),
			'featured_img'  => __('Featured Image', 'woocommerce-wholesale-pricing'),
			'reviews'       => __('Reviews', 'woocommerce-wholesale-pricing'),
			'stock'         => __('Stock', 'woocommerce-wholesale-pricing'),
			'weight'        => __('Weight', 'woocommerce-wholesale-pricing'),
			'dimensions'    => __('Dimensions', 'woocommerce-wholesale-pricing'),
			'price'         => __('Price', 'woocommerce-wholesale-pricing'),
			'attributes'    => __('Attributes', 'woocommerce-wholesale-pricing'),
			'custom_fields' => __('Custom Fields', 'woocommerce-wholesale-pricing'),
			'tags'          => __('Tags', 'woocommerce-wholesale-pricing'),
			'quick_view'    => __('Quick View', 'woocommerce-wholesale-pricing'),
			'taxonomy'      => __('Taxonomy', 'woocommerce-wholesale-pricing'),
			'cart_button'   => __('Add To Cart Button', 'woocommerce-wholesale-pricing'),
		);
	}

	/**
	 * Get display labels for product table columns (pills).
	 *
	 * @param int $post_id Product table post ID.
	 * @return string[]
	 */
	private function get_column_pill_labels( $post_id ) {
		$table_fields = get_post_meta($post_id, 'product_table_fields', true);
		$labels       = array();

		if ( ! is_array($table_fields) || empty($table_fields) ) {
			return $labels;
		}

		$type_labels = $this->get_field_type_labels();

		foreach ( $table_fields as $field ) {
			if ( ! is_array($field) ) {
				continue;
			}

			$label = '';
			if ( ! empty($field['woo_label']) ) {
				$label = $field['woo_label'];
			} elseif ( ! empty($field['woo_ids']) && isset($type_labels[ $field['woo_ids'] ]) ) {
				$label = $type_labels[ $field['woo_ids'] ];
			} elseif ( ! empty($field['woo_ids']) ) {
				$label = $field['woo_ids'];
			}

			if ( '' !== $label ) {
				$labels[] = $label;
			}
		}

		return $labels;
	}

	/**
	 * Build tooltip HTML for column pills.
	 *
	 * @param string[] $labels Column labels.
	 * @return string
	 */
	private function build_column_pills_tooltip( array $labels ) {
		if ( empty($labels) ) {
			return esc_html__('No columns configured', 'woocommerce-wholesale-pricing');
		}

		$pills = '';
		foreach ( $labels as $index => $label ) {
			$variant = (int) $index % 5;
			$pills  .= '<span class="wcpt-column-pill wcpt-column-pill--' . esc_attr((string) $variant) . '">' . esc_html($label) . '</span>';
		}

		return '<div class="wcpt-column-pills">' . $pills . '</div>';
	}

	/**
	 * Product table shortcode for a post.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	private function get_product_table_shortcode( $post_id ) {
		if ( TableTypeHelper::is_quick_order_form( $post_id ) ) {
			return '[wc_quick_order id=' . (int) $post_id . ']';
		}

		return '[wc_products_table id=' . (int) $post_id . ']';
	}

	/**
	 * Human-readable label for a table type.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	private function get_table_type_label( $post_id ) {
		if ( TableTypeHelper::is_quick_order_form( $post_id ) ) {
			return __('Quick Order Form', 'woocommerce-wholesale-pricing');
		}

		return __('Product Table', 'woocommerce-wholesale-pricing');
	}

	/**
	 * Render list-table toggle switch.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $action  Toggle action key.
	 * @param bool   $checked Whether toggle is on.
	 * @return void
	 */
	private function render_list_toggle( $post_id, $action, $checked ) {
		?>
		<label class="switch wcpt-list-toggle-wrap">
			<input
				type="checkbox"
				class="wcpt-list-toggle"
				data-post-id="<?php echo esc_attr((string) $post_id); ?>"
				data-action="<?php echo esc_attr($action); ?>"
				<?php checked($checked); ?>
			>
			<span class="slider round"></span>
		</label>
		<?php
	}

	public function column_values( $column, $post_id ) {
		switch ( $column ) {
			case 'wcpt_table_type':
				echo esc_html( $this->get_table_type_label( $post_id ) );
				break;

			case 'shortcode':
				$shortcode = $this->get_product_table_shortcode($post_id);
				printf(
					'<button type="button" class="wcpt-shortcode-copy" data-shortcode="%1$s" aria-label="%2$s"><code class="wcpt-shortcode-copy__code">%3$s</code><span class="wcpt-shortcode-copy__feedback" aria-hidden="true">%4$s</span></button>',
					esc_attr($shortcode),
					esc_attr(
						sprintf(
							/* translators: %s: product table shortcode */
							__('Copy shortcode %s', 'woocommerce-wholesale-pricing'),
							$shortcode
						)
					),
					esc_html($shortcode),
					esc_html__('Click to copy', 'woocommerce-wholesale-pricing')
				);
				break;

			case 'wcpt_columns':
				$labels  = $this->get_column_pill_labels($post_id);
				$tooltip = $this->build_column_pills_tooltip($labels);

				if ( empty($labels) ) {
					echo '<span class="wcpt-columns-empty">&mdash;</span>';
					break;
				}

				$allowed_tooltip_tags = array(
					'div'  => array( 'class' => array() ),
					'span' => array( 'class' => array() ),
				);

				printf(
					'<span class="wcpt-columns-tooltip"><button type="button" class="button wcpt-columns-view" aria-describedby="wcpt-columns-tip-%1$d">%2$s</button><span id="wcpt-columns-tip-%1$d" class="wcpt-columns-tooltip-panel" role="tooltip">%3$s</span></span>',
					(int) $post_id,
					esc_html__('View', 'woocommerce-wholesale-pricing'),
					wp_kses($tooltip, $allowed_tooltip_tags)
				);
				break;

			case 'wcpt_onepage_checkout':
				if ( TableTypeHelper::is_quick_order_form( $post_id ) ) {
					echo '<span class="wcpt-status-na">&mdash;</span>';
					break;
				}
				$enabled = 'yes' === get_post_meta($post_id, 'display_onepage_checkout', true);
				$this->render_list_toggle($post_id, 'onepage_checkout', $enabled);
				break;

			case 'wcpt_status':
				$status = get_post_status($post_id);
				if ( ! in_array($status, array( 'publish', 'draft' ), true) ) {
					echo '<span class="wcpt-status-na">&mdash;</span>';
					break;
				}
				$this->render_list_toggle($post_id, 'post_status', 'publish' === $status);
				break;
		}
	}

	/**
	 * Add Export row action and ensure Quick Order edit links keep table= param.
	 *
	 * @param array   $actions Row actions.
	 * @param WP_Post $post    Post object.
	 * @return array
	 */
	public function row_actions( $actions, $post ) {
		if ( ! isset($post->post_type) || $this->slug !== $post->post_type ) {
			return $actions;
		}

		if ( TableTypeHelper::is_quick_order_form( $post->ID ) ) {
			$quick_order_edit_url = $this->get_quick_order_edit_url( $post->ID );

			if ( isset( $actions['edit'] ) ) {
				$actions['edit'] = sprintf(
					'<a href="%s" aria-label="%s">%s</a>',
					esc_url( $quick_order_edit_url ),
					/* translators: %s: post title */
					esc_attr( sprintf( __( 'Edit &#8220;%s&#8221;', 'woocommerce-wholesale-pricing' ), get_the_title( $post ) ) ),
					esc_html__( 'Edit', 'woocommerce-wholesale-pricing' )
				);
			}

			if ( isset( $actions['inline hide-if-no-js'] ) ) {
				unset( $actions['inline hide-if-no-js'] );
			}
		}

		$export_url = wp_nonce_url(
			admin_url('admin-ajax.php?action=wcpt_export_product_table&post=' . $post->ID),
			'wcpt_export_product_table'
		);

		$export_action = sprintf(
			'<a href="%s">%s</a>',
			esc_url($export_url),
			esc_html__('Export', 'woocommerce-wholesale-pricing')
		);

		$new_actions = array();
		foreach ( $actions as $key => $action ) {
			if ( 'trash' === $key ) {
				$new_actions['wcpt_export'] = $export_action;
			}
			$new_actions[ $key ] = $action;
		}

		if ( ! isset($new_actions['wcpt_export']) ) {
			$new_actions['wcpt_export'] = $export_action;
		}

		return $new_actions;
	}

	/**
	 * Append table=quick_order_form to edit links for quick order posts.
	 *
	 * @param string $link    Edit post link.
	 * @param int    $post_id Post ID.
	 * @param string $context Link context.
	 * @return string
	 */
	public function append_table_type_to_edit_link( $link, $post_id, $context ) {
		unset( $context );

		if ( ! $link ) {
			return $link;
		}

		$post = get_post( $post_id );
		if ( ! $post || $this->slug !== $post->post_type ) {
			return $link;
		}

		if ( ! TableTypeHelper::is_quick_order_form( $post_id ) ) {
			return $link;
		}

		return add_query_arg(
			TableTypeHelper::URL_PARAM_TABLE_TYPE,
			TableTypeHelper::TABLE_TYPE_QUICK_ORDER_FORM,
			$link
		);
	}

	/**
	 * Keep table=quick_order_form on the post-save redirect URL.
	 *
	 * @param string $location Redirect URL.
	 * @param int    $post_id  Post ID.
	 * @return string
	 */
	public function preserve_table_type_on_redirect( $location, $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post || $this->slug !== $post->post_type ) {
			return $location;
		}

		if ( ! TableTypeHelper::is_quick_order_form( $post_id ) && ! TableTypeHelper::is_quick_order_form_url_context() ) {
			return $location;
		}

		return add_query_arg(
			TableTypeHelper::URL_PARAM_TABLE_TYPE,
			TableTypeHelper::TABLE_TYPE_QUICK_ORDER_FORM,
			$location
		);
	}

	/**
	 * Build the edit URL for a Quick Order Form post.
	 *
	 * @param int $post_id Post ID.
	 * @return string
	 */
	private function get_quick_order_edit_url( $post_id ) {
		return add_query_arg(
			array(
				'post'   => (int) $post_id,
				'action' => 'edit',
				TableTypeHelper::URL_PARAM_TABLE_TYPE => TableTypeHelper::TABLE_TYPE_QUICK_ORDER_FORM,
			),
			admin_url( 'post.php' )
		);
	}

	/**
	 * Table Save
	 *
	 * @param int $product_table_id product table id.
	 * @param int $post             post id.
	 * @param int $update           update.
	 */
	public function save_post( $product_table_id ) {
		// Persist table type from request as early as possible (GET/POST),
		// so list-table edit links work even if a later save path skips the nonce block.
		if ( TableTypeHelper::is_quick_order_form_url_context() ) {
			TableTypeHelper::set_table_type( $product_table_id, TableTypeHelper::TABLE_TYPE_QUICK_ORDER_FORM );
		}

		$is_quick_order = TableTypeHelper::is_quick_order_form_url_context()
			|| TableTypeHelper::is_quick_order_form( $product_table_id );

		if ( $is_quick_order ) {
			TableTypeHelper::set_table_type( $product_table_id, TableTypeHelper::TABLE_TYPE_QUICK_ORDER_FORM );
			QuickOrderFormService::save_post( $product_table_id );
			return;
		}

		if (! isset($_POST['wcpt_settings_display_nonce']) ) {
			return;
		}

		// Verify that the nonce is valid.
		if (! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wcpt_settings_display_nonce'])), 'wcpt_settings_display_callback') ) {
			return;
		}

		TableTypeHelper::set_table_type( $product_table_id, TableTypeHelper::TABLE_TYPE_PRODUCT_TABLE );
		
		$fields = array();

		$link_key   = 0;
		$stock_key  = 0;
		$expand_key = 0;
		$descr_key  = 0;
		$date_key   = 0;
		$attr_key   = 0;
		$tax_key    = 0;
		$custom_key = 0;
		$cart_key   = 0;


		if (isset($_POST['woo_ids']) ) {
			$woo_ids = array_map('sanitize_text_field', wp_unslash($_POST['woo_ids']));

			foreach ( $woo_ids as $key => $id ) {
				$fields[ $key ]['woo_ids'] = $id;
				if (isset($_POST['woo_label'][ $key ]) ) {
					$fields[ $key ]['woo_label'] = sanitize_text_field(wp_unslash($_POST['woo_label'][ $key ]));
				}

				if (isset($_POST['woo_width_text']) ) {
					if (isset($_POST['woo_width_text'][ $key ]) ) {
						$width_text = sanitize_text_field(wp_unslash($_POST['woo_width_text'][ $key ]));
					}

					if ($width_text ) {
						if (isset($_POST['woo_width_type'][ $key ]) ) {
							$width_type = sanitize_text_field(wp_unslash($_POST['woo_width_type'][ $key ]));
						}
						if ('percent' === $width_type ) {
							$option = '%';
						} else {
							$option = 'px';
						}
						$fields[ $key ]['woo_width']      = $width_text . '' . $option;
						$fields[ $key ]['woo_width_text'] = $width_text;
						$fields[ $key ]['woo_width_type'] = $width_type;
					} else {
						$fields[ $key ]['woo_width']      = '';
						$fields[ $key ]['woo_width_text'] = '';
					}
				}


				if (isset($_POST['woo_linkable'][ $link_key ]) && ( 'title' === $id || 'featured_img' === $id ) ) {
					$fields[ $key ]['woo_expandable'] = !empty( sanitize_text_field(wp_unslash($_POST['woo_expandable'][ $expand_key ])) ) ?  sanitize_text_field(wp_unslash($_POST['woo_expandable'][ $expand_key ])) : '' ;
					$fields[ $key ]['woo_linkable'] = !empty( sanitize_text_field(wp_unslash($_POST['woo_linkable'][ $link_key ])) ) ? sanitize_text_field(wp_unslash($_POST['woo_linkable'][ $link_key ])) : '';
					$expand_key++;
					$link_key++;
				} elseif (isset($_POST['woo_show_stock'][ $stock_key ]) && 'stock' === $id) {
					$fields[ $key ]['woo_show_stock'] = sanitize_text_field(wp_unslash($_POST['woo_show_stock'][ $stock_key ]));
					$stock_key++;
				} elseif (isset($_POST['woo_show_stock'][ $stock_key ]) && 'stock' === $id) {
					$fields[ $key ]['woo_show_stock'] = sanitize_text_field(wp_unslash($_POST['woo_show_stock'][ $stock_key ]));
					$stock_key++;
				} elseif (isset($_POST['woo_descr'][ $descr_key ]) && 'descr' === $id ) {
					$fields[ $key ]['woo_descr'] = sanitize_text_field(wp_unslash($_POST['woo_descr'][ $descr_key ]));
					$descr_key++;
				} elseif (isset($_POST['woo_date_format'][ $date_key ]) && 'date' === $id ) {
					$fields[ $key ]['woo_date_format'] = sanitize_text_field(wp_unslash($_POST['woo_date_format'][ $date_key ]));
					$date_key++;
				} elseif (isset($_POST['woo_attrs'][ $attr_key ]) && 'attributes' === $id ) {
					$fields[ $key ]['woo_attrs'] = sanitize_text_field(wp_unslash($_POST['woo_attrs'][ $attr_key ]));
					$attr_key++;
				} elseif (isset($_POST['woo_custom_keys'][ $custom_key ]) && 'custom_fields' === $id ) {
					$fields[ $key ]['woo_custom_keys'] = sanitize_text_field(wp_unslash($_POST['woo_custom_keys'][ $custom_key ]));
					$custom_key++;
				} elseif (isset($_POST['woo_taxonomy'][ $tax_key ]) && 'taxonomy' === $id ) {
					$fields[ $key ]['woo_taxonomy'] = sanitize_text_field(wp_unslash($_POST['woo_taxonomy'][ $tax_key ]));
					$tax_key++;
				} elseif (( isset($_POST['woo_quantity'][ $cart_key ]) || isset($_POST['woo_add_types'][ $cart_key ]) || isset($_POST['woo_add_selected_cart'][ $cart_key ]) ) && 'cart_button' === $id ) {
					$fields[ $key ]['woo_quantity']          = sanitize_text_field(wp_unslash($_POST['woo_quantity'][ $cart_key ]));
					$fields[ $key ]['woo_add_types']         = sanitize_text_field(wp_unslash($_POST['woo_add_types'][ $cart_key ]));
					$fields[ $key ]['woo_add_selected_cart'] = sanitize_text_field(wp_unslash($_POST['woo_add_selected_cart'][ $cart_key ]));
					$cart_key++;
				} 
			}
		}
		update_post_meta($product_table_id, 'product_table_fields', $fields);

		$wcpt_meta_settings = array(
			'display_wholesale_only',
			'display_table_header',
			'display_table_footer',
			'display_reset',
			'display_page_length',
			'display_product_totals',
			'display_pagination',
			'variable_list_view',
			'group_list_view',
			'wcpt_custom_products_msg',
			'default_sorted_col',
			'default_sorted_dir',
			'wcpt_rows_page',
			'wcpt_product_limit',
			'enable_sort_cols',
			'show_search',
			'show_filter',
			'wcpt_inc_product_cats',
			'wcpt_wholesale_selected_roles',
			'wcpt_addon_display',
			'display_table_design',
			'external_bdcolor',
			'external_bdsize',
			'header_bdcolor',
			'header_bdsize',
			'footer_bdcolor',
			'table_footer_bg',
			'footer_bdsize',
			'border_cells_color',
			'border_cells_size',
			'table_header_bg',
			'table_cell_bg',
			'table_header_font_clr',
			'table_header_font_size',
			'table_footer_font_clr',
			'table_footer_font_size',
			'table_cell_font',
			'table_cell_size',
			'wcpt_inc_product_tags',
			'wcpt_product_status',
			'wcpt_ex_product_cats',
			'display_responsive',
			'columns_show',
			'wcpt_date_opt',
			'wcpt_date',
			'wcpt_filters_col',
			'wcpt_filters_obj',
			'filter_product_based_term',
			'shortocode_html_formatting',
			'guest_users',
			'wcpt_add_to_cart_label',
			'wcpt_price_text',
			'guest_users_redirection',
			'wcpt_wrap',
			'wcpt_scroll',
			'wcpt_checked',
			'sorted_cols',
			'mobile_icon_chck',
			'columns_mobile_show',
			'tablet_icon_chck',
			'columns_tablet_show',
			'pagingType',
			'display_onepage_checkout',
			'mini_cart_enable',
			'mini_cart_position',
			'mini_cart_placement',
			'mini_cart_icons',
		);



		foreach ( $wcpt_meta_settings as $wcpt_meta_setting ) {
			if (isset($_POST[ $wcpt_meta_setting ]) ) {
				if (is_array($_POST[ $wcpt_meta_setting ]) ) {
					$wcpt_meta = array_map('sanitize_text_field', wp_unslash($_POST[ $wcpt_meta_setting ]));
				} else {
					$wcpt_meta = sanitize_text_field(wp_unslash($_POST[ $wcpt_meta_setting ]));
				}
					
				
				if ('wcpt_rows_page' === $wcpt_meta_setting && intval($wcpt_meta) <= 0) {
					$wcpt_meta = '';
				}
				
				if ( 'wcpt_product_limit' === $wcpt_meta_setting && intval($wcpt_meta) <= 0) {
					$wcpt_meta = '';
				}

				update_post_meta($product_table_id, $wcpt_meta_setting, $wcpt_meta);
			} else {
				update_post_meta($product_table_id, $wcpt_meta_setting, '');
			}
		}



		if (isset($_POST['wcpt_table_restricted_users'])) {
			$selected_roles = array_map('sanitize_text_field', $_POST['wcpt_table_restricted_users']);
			update_post_meta($product_table_id, '_wcpt_table_user_restriction', $selected_roles);
		}

		if (isset($_POST['wcpt_table_restricted_user_roles'])) {
			$selected_roles = array_map('sanitize_text_field', $_POST['wcpt_table_restricted_user_roles']);
			update_post_meta($product_table_id, '_wcpt_table_user_role_restriction', $selected_roles);
		}
		
		if ( isset( $_POST['wcpt_inc_product_ids'] ) ) {
			$product_ids = sanitize_text_field(wp_unslash($_POST['wcpt_inc_product_ids'])) ? explode(',', sanitize_text_field(wp_unslash($_POST['wcpt_inc_product_ids']))) : '';
			update_post_meta($product_table_id, 'wcpt_inc_product_ids', $product_ids);
		}

		if ( isset( $_POST['wcpt_ex_product_ids'] ) ) {
			$product_ex_ids = sanitize_text_field(wp_unslash($_POST['wcpt_ex_product_ids'])) ? explode(',', sanitize_text_field(wp_unslash($_POST['wcpt_ex_product_ids']))) : '';
			update_post_meta($product_table_id, 'wcpt_ex_product_ids', $product_ex_ids);
		}
	}

	public static function resolveDependency() {
		return is_product_table_enabled();
	}
}
