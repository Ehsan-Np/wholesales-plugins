<?php

namespace WooCommerceWholesalePricing\App\Services\ProductTable;

use WooCommerceWholesalePricing\App\Modules\ProductTable\Traits\Fields;
use WooCommerceWholesalePricing\App\Modules\ProductTable\Traits\TableHeading;
use WooCommerceWholesalePricing\App\Modules\ProductTable\Traits\SelectedCart;
use WooCommerceWholesalePricing\App\Modules\ProductTable\Traits\ResponsiveOptions;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;
class ProductTableService implements ServiceInterface {

	use Fields;
	use TableHeading;
	use SelectedCart;
	use ResponsiveOptions;

	public function __construct() {
		add_shortcode('wc_products_table', array( self::class, 'wc_products_table' ));

		add_action(
			'pre_get_posts', function ( $q ) {
				$title = $q->get('_meta_or_title');
				if ($title ) {
					add_filter(
						'get_meta_sql', function ( $sql ) use ( $title ) {
							global $wpdb;

							// Only run once:
							static $nr = 0; 
							if (0 != $nr++ ) {
								return $sql;
							}

							// Modify WHERE part:
							$sql['where'] = sprintf(
								' AND ( %1s OR %2s ) ',
								$wpdb->prepare("{$wpdb->posts}.post_title like %s", '%' . $title . '%'),
								mb_substr($sql['where'], 5, mb_strlen($sql['where']))
							);
							return $sql;
						}
					);
				}
			}
		);
	}

	public static function wc_products_table( $atts ) {

		if ( defined('REST_REQUEST') && REST_REQUEST ) {
			return;
		}

		$post_id = isset( $atts['id'] ) ? $atts['id'] : '';
		$show_table = false;
		$selected_roles = get_post_meta( $post_id, '_wcpt_table_user_role_restriction', true );
		$selected_users = get_post_meta( $post_id, '_wcpt_table_user_restriction', true );
		$display_onepage_checkout = get_post_meta( $post_id, 'display_onepage_checkout', true );

		$post_status = get_post_status($post_id);

		if ( ! is_array( $selected_roles ) ) {
			$selected_roles = array();
		}
		
		if ( ! is_array( $selected_users ) ) {
			$selected_users = array();
		}
		
		if ( in_array( 'Guest', $selected_roles ) && ! is_user_logged_in() ) {
			$show_table = true;
		}

		if ( empty(array_filter($selected_roles)) && empty(array_filter($selected_users)) ) {
			$show_table = true;
		}
		
		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			$current_user_role = isset($current_user->roles[0]) ? $current_user->roles[0] : '';
			$current_user_id = $current_user->ID;
	
			if ( in_array( $current_user_role, $selected_roles ) || in_array( $current_user_id, $selected_users ) ) {
				$show_table = true;
			}
			
		}

		if ( false === $show_table || 'publish' !== $post_status || 'publish' !== get_post_status() ) {
			return;
		}
		$product_table_params = array(
			'ajax_url'      => admin_url('admin-ajax.php'),
			'error_message' => __('No product added to cart', 'woocommerce-wholesale-pricing'),
			'nonce'         => wp_create_nonce('ajax-nonce'),
			'display_onepage_checkout'    => $display_onepage_checkout,
			
		);

		wp_localize_script('product_table_script', 'product_table_params', $product_table_params); 

		ob_start();
		wp_enqueue_style('datatables_style');
		wp_enqueue_style('product_table_style');
		wp_enqueue_script('datatables_script');
		wp_enqueue_script('product_table_script');
		wp_enqueue_script('wc-add-to-cart');
		wp_enqueue_script('wc-add-to-cart-variation');
		wp_enqueue_style('responsive_datatables_style');
		wp_enqueue_script('responsive_datatables_script');
		wp_enqueue_script('button_datatables_script');
		wp_enqueue_script('colvis_button_datatables_script');
		// wp_enqueue_script('wtp-front-script');
		
	
	//Tier Pricing Compatibility
		if (class_exists('Wpexperts\TierPricingForWoocommerce\Frontend\WooTierPricingFrontend')) {
	
			?>
			<style>
				:root {
					--wtp-border-color: <?php echo esc_attr( get_option( 'wtp_tooltip_icon_color', '#000' ) ); ?>;
					--wtp-active-color: <?php echo esc_attr( get_option( 'wtp_active_price_bg_color', '#ddd' ) ); ?>;
				}

				.wtp-summary{
					display:none;
				}

				<?php
				if ( 'enabled' === get_option( 'wtp_tooltip_border', 'disabled' ) ) {
					?>
					.tippy-box {
						border:  1px solid var(--wtp-border-color)!important;
						border-radius:  4px;
					}
					<?php
				}
				?>
			</style>
				<?php

				wp_enqueue_style( 'wtp-front-style', WTP_ROOT_URL . 'assets/css/front/front-style.css', array(), '1.0.0' );
				wp_enqueue_script( 'wtp-tippy-popper', WTP_ROOT_URL . 'assets/js/front/popper.js', array( 'jquery' ), WTP_VERSION, true );
				wp_enqueue_script( 'wtp-tippy', WTP_ROOT_URL . 'assets/js/front/tippy.js', array( 'jquery', 'wtp-tippy-popper' ), WTP_VERSION, true );

				$params = array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wtp_front' ),
				'summary' => get_option( 'wtp_summary_display_type', 'none' ),
				);

				wp_register_script( 'wtp-front-script', WTP_ROOT_URL . 'assets/js/front/front-script.js', array( 'jquery', 'wtp-tippy' ), WTP_VERSION, true );
				wp_localize_script( 'wtp-front-script', 'wtp_front_script', $params );
				wp_enqueue_script('wtp-front-script');

		
			wp_register_script( 'wtp-front-block', WTP_ROOT_URL . 'assets/js/front/cart-block.js', array( 'jquery' ), WTP_VERSION, true );
			wp_enqueue_script( 'wtp-front-block' );
		
		} 

	
		$atts = shortcode_atts(
		array( 'id' => '' ), $atts);
	
		// get product table settings with id.
	
		if ($atts['id'] && !in_array(get_post_status($atts['id']), array( 'trash', false )) ) {
		
			$product_table_id       = $atts['id'];
			$get_external_bdcolor = get_post_meta($product_table_id, 'external_bdcolor', true);
			$get_external_bdsize = get_post_meta($product_table_id, 'external_bdsize', true);
			$header = get_post_meta($product_table_id, 'display_table_header', true);
			if ( ! $header ) {
				?>
				<style>
			#ptholder table.product-table thead {
				display:none;
			}
		</style>
			<?php
			}
		$get_header_bdcolor = get_post_meta($product_table_id, 'header_bdcolor', true);
		$get_header_bdsize = get_post_meta($product_table_id, 'header_bdsize', true);
		$get_footer_bdcolor = get_post_meta($product_table_id, 'footer_bdcolor', true);
		$get_footer_bdsize = get_post_meta($product_table_id, 'footer_bdsize', true);
		$get_table_header_bg = get_post_meta($product_table_id, 'table_header_bg', true);
		$table_header_font_clr = get_post_meta($product_table_id, 'table_header_font_clr', true);
		$table_header_font_size= get_post_meta($product_table_id, 'table_header_font_size', true);

		$get_table_footer_bg = get_post_meta($product_table_id, 'table_footer_bg', true);
		$table_footer_font_clr = get_post_meta($product_table_id, 'table_footer_font_clr', true);
		$table_footer_font_size= get_post_meta($product_table_id, 'table_footer_font_size', true);

		$get_border_cells_color = get_post_meta($product_table_id, 'border_cells_color', true);
		$get_border_cells_size = get_post_meta($product_table_id, 'border_cells_size', true);
		$get_table_cell_bg = get_post_meta($product_table_id, 'table_cell_bg', true);
		$table_cell_font = get_post_meta($product_table_id, 'table_cell_font', true);
		$table_cell_size = get_post_meta($product_table_id, 'table_cell_size', true);
		$display_table_design = get_post_meta($product_table_id, 'display_table_design', true);
		$display_onepage_checkout = get_post_meta($product_table_id, 'display_onepage_checkout', true);
		$mini_cart_enable = get_post_meta($product_table_id, 'mini_cart_enable', true);


			if ('default_design' === $display_table_design ) {
				?>
		<style>
			#ptholder table.product-table{
				border-collapse: separate;
			}
			#ptholder table.product-table thead{
				border: initial ;
				border-color: initial ;
			}
			#ptholder th{
				background-color:initial;
				color:initial;
				font-size:initial;
			}
			#ptholder table.product-table tr td{
				border: initial ;
				border-color: initial ;
			}
			#ptholder table.product-table tbody td{
				background-color:initial;
				color:initial;
				font-size:initial;
			}

		</style>
				<?php
			} else {
				?>
		<style>
			#ptholder .product-table-wrap .dataTables_wrapper .product-table{
				border-collapse: collapse;
				border: <?php echo absint($get_external_bdsize) . 'px solid!important'; ?> ;
				border-color: <?php echo esc_attr($get_external_bdcolor); ?>!important ;
			}

			#ptholder table.product-table thead th{
				border-collapse: collapse;
				border-right: 
				<?php 
				echo absint($get_header_bdsize) . 'px solid';
				echo esc_attr($get_header_bdcolor); 
				?>
				!important ;
			}
			#ptholder table.product-table tfoot th{
				border-collapse: collapse;
				border-right: 
				<?php 
				echo absint($get_footer_bdsize) . 'px solid';
				echo esc_attr($get_footer_bdcolor); 
				?>
				!important ;
			}
			#ptholder table.product-table thead th:last-child{
				border-right:unset!important;
			}

			#ptholder table.product-table tbody tr td:first-child{
				border-left: 0!important;
			} 
			#ptholder table.product-table tbody tr td:first-child{
				border-right: 0!important;
			}

			#ptholder thead th{
				background-color:<?php echo esc_attr($get_table_header_bg); ?>!important;
				color:<?php echo esc_attr($table_header_font_clr); ?>!important;
				font-size:<?php echo absint($table_header_font_size) . 'px'; ?>;
			}
			#ptholder tfoot th{
				background-color:<?php echo esc_attr($get_table_footer_bg); ?>!important;
				color:<?php echo esc_attr($table_footer_font_clr); ?>!important;
				font-size:<?php echo absint($table_footer_font_size) . 'px'; ?>;
			}
			#ptholder table.product-table tbody tr td{
				border: <?php echo absint($get_border_cells_size) . 'px solid'; ?> ;
				border-color: <?php echo esc_attr($get_border_cells_color); ?>;
				border-right: 0;
				vertical-align:middle;
			}


			#ptholder table.product-table thead {
				border-bottom: <?php echo absint($get_border_cells_size) . 'px solid ' . esc_attr($get_border_cells_color); ?>		
			}

			#ptholder table.product-table tbody td{
				background-color:<?php echo esc_attr($get_table_cell_bg); ?>!important;
				color:<?php echo esc_attr($table_cell_font); ?>!important;
				font-size:<?php echo absint($table_cell_size) . 'px'; ?>;
			}

		</style>
				<?php
			}
		$display_wholesale_only = !empty(get_post_meta($product_table_id, 'display_wholesale_only', true)) ? get_post_meta($product_table_id, 'display_wholesale_only', true) : 'no';
		$wcpt_addon_display = !empty(get_post_meta($product_table_id, 'wcpt_addon_display', true)) ? get_post_meta($product_table_id, 'wcpt_addon_display', true) : 'vertical';
			if ('horizontal' === $wcpt_addon_display ) {
				$horizontal_css = '#ptholder table.product-table.dataTable .product-cart-wrapper p.wc-pao-addon-wrap{display:inline-block;width:auto;margin-right:10px;}';
				wp_add_inline_style('product_table_style', $horizontal_css);
			}
		$wcpt_wholesale_selected_roles = !empty(get_post_meta($product_table_id, 'wcpt_wholesale_selected_roles', true)) ? get_post_meta($product_table_id, 'wcpt_wholesale_selected_roles', true) : array();
		$roles = is_user_logged_in() ? wp_get_current_user()->roles : array();

			if (function_exists('is_wholesaler_user')  && 'yes' === $display_wholesale_only && !empty($wcpt_wholesale_selected_roles) ) {

				if (is_wholesaler_user(get_current_user_id()) && array_intersect($roles, $wcpt_wholesale_selected_roles)) {
					ob_start();
				} else {
					?>

			<p class="woocommerce-info"><?php echo esc_html__('You don\'t have permissions', 'woocommerce-wholesale-pricing'); ?></p>
				<?php
				return ob_get_clean();
				}

			} 


		/**
		 * Filter product table footer
		 * 
		 * @since 1.1.6
		**/
		$product_table_footer           = apply_filters('wcpt_product_table_footer', get_post_meta($product_table_id, 'display_table_footer', true), $product_table_id);
		$selected_cart_position         = self::product_table_add_selected_cart($product_table_id);
		$product_table_fields            = self::get_product_table_fields($product_table_id);
		
		$args['id']                     = $product_table_id;
		$args['product_table_header']   = get_post_meta($product_table_id, 'display_table_header', true);
		$args['rows_per_page']          = get_post_meta($product_table_id, 'wcpt_rows_page', true);
		
		$args['product_table_headings'] = self::products_table_heading($product_table_id);
		// get sorted columns.

			if (get_post_meta($product_table_id, 'default_sorted_col', true) ) {
				$default_sorted_col = get_post_meta($product_table_id, 'default_sorted_col', true);
				$default_sorted_col         = explode('_', $default_sorted_col);
				$args['default_sorted_col'] = end($default_sorted_col);
			} else {
			$args['default_sorted_col'] = '';
			}
		$args['default_sorted_dir'] = get_post_meta($product_table_id, 'default_sorted_dir', true);
		$enable_sort_cols           = get_post_meta($product_table_id, 'enable_sort_cols', true);
			if ($enable_sort_cols ) {
				$args['sorted_cols'] = get_post_meta($product_table_id, 'sorted_cols', true);
			} else {
				$args['sorted_cols'] = array();
			}
		$args['table_id']               = $product_table_id;
		$args['responsive_options']     = self::get_responsive_options($args);
		$args['search']                 = get_post_meta($product_table_id, 'show_search', true);
		$args['search_term']            = get_post_meta($product_table_id, 'filter_product_based_term', true);
		$args['filters']                = get_post_meta($product_table_id, 'show_filter', true);
		$args['filter_terms']           = get_post_meta($product_table_id, 'wcpt_filters_obj', true);
		$args['col_filters']            = get_post_meta($product_table_id, 'wcpt_filters_col', true);
		$args['product_table_headings'] = self::products_table_heading($product_table_id);
		$args['wcpt_scroll']            = get_post_meta($product_table_id, 'wcpt_scroll', true);
		$args['reset_button']           = get_post_meta($product_table_id, 'display_reset', true);
			if (! $args['wcpt_scroll'] ) {
				$args['wcpt_scroll'] = 0;
			}

		$wcpt_wrap                   = get_post_meta($product_table_id, 'wcpt_wrap', true);
		$args['wcpt_wrap']           = ( 'yes' === $wcpt_wrap ? 'wrap' : 'nowrap' );
		$args['paging_type']         = get_post_meta($product_table_id, 'pagingType', true);
		$args['no_products_msg']     = get_post_meta($product_table_id, 'wcpt_custom_products_msg', true);
		$display_page_length         = get_post_meta($product_table_id, 'display_page_length', true);
		$args['display_page_length'] = ( $display_page_length ? 'yes' : 'no' );

		$display_product_totals         = get_post_meta($product_table_id, 'display_product_totals', true);
		$args['display_product_totals'] = ( $display_product_totals ? 'yes' : 'no' );
		
		$display_pagination         = get_post_meta($product_table_id, 'display_pagination', true);
		$args['display_pagination'] = ( $display_pagination ? 'yes' : 'no' );
		/**
		 * Filter product table heading args
		 * 
		 * @since 1.1.6
		**/
		$args = apply_filters('wcpt_product_table_heading_args', $args, $atts);
		
			if (function_exists('wc_print_notices')) {
				wc_print_notices();
			}
		
		$array = array(
			'key' => '<sv',

		);

		wwp_wc_product_table_get_template('product-table-wrap-start.php');

			if (( $selected_cart_position && 'below_add' !== $selected_cart_position ) || $args['filters'] ) {
				wwp_wc_product_table_get_template('product-table-filter-cart-start.php');
			}
		// add selected cart before table.
			if ($selected_cart_position && 'below_add' !== $selected_cart_position ) {
				wwp_wc_product_table_get_template('product-table-add-selected-cart.php');
			}
			if ($args['filters'] ) {
				wwp_wc_product_table_get_template('product-table-filters.php', $args);
			}
			if (( $selected_cart_position && 'below_add' !== $selected_cart_position ) || $args['filters'] ) {
				wwp_wc_product_table_get_template('product-table-filter-cart-end.php');
			}
		// woocommerce product table start tag.
		wwp_wc_product_table_get_template('product-table-start.php', $args);
		// woocommerce product table header.
		wwp_wc_product_table_get_template('product-table-header.php', $args);

		// // woocommerce product table footer.
			if ($product_table_footer ) {
				wwp_wc_product_table_get_template('product-table-footer.php', $args);
			}

		// woocommerce product table end tag.
		wwp_wc_product_table_get_template('product-table-end.php');

		// add selected cart below table.
			if ($selected_cart_position && 'above_add' !== $selected_cart_position ) {
				wwp_wc_product_table_get_template('product-table-add-selected-cart.php');
			
			}
		

		wwp_wc_product_table_get_template('product-table-wrap-end.php');
			foreach ($product_table_fields as $key => $value) {

				if (isset($value['woo_add_types']) && ( 'add_checkbox' === $value['woo_add_types'] || 'add_button_checkbox' === $value['woo_add_types'] || 'add_button' === $value['woo_add_types'] || 'add_quick_view_button' === $value['woo_add_types'] )  && $display_onepage_checkout && 'disable' == $mini_cart_enable ) {
					?>
				<input type="hidden" class="one_page_check" value="<?php echo esc_attr($display_onepage_checkout); ?>" >
				<div id="wcpt_one_page_checkout">
					<?php echo do_shortcode('[woocommerce_checkout]'); ?>
				</div>
				<?php
				}
			}

		// echo ob_get_clean();
		$mini_cart_position = get_post_meta($product_table_id, 'mini_cart_position', true);
		$mini_cart_placement = get_post_meta($product_table_id, 'mini_cart_placement', true);
		$mini_cart_icon = get_post_meta($product_table_id, 'mini_cart_icons', true);
		$icon_url = array(
			'mini_cart_1' => '<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 62 62"><title>cart</title><path d="M4,9.92H14L12.23,8.58l.87,2.67c.71,2.14,1.41,4.28,2.12,6.42.84,2.57,1.7,5.15,2.54,7.72Q18.87,28.75,20,32.1c.36,1.09.7,2.18,1.07,3.26,0,0,0,0,0,0a1.83,1.83,0,0,0,3.53-1c-.3-.89-.59-1.78-.88-2.68q-1.07-3.21-2.11-6.41l-2.55-7.74c-.74-2.23-1.48-4.47-2.21-6.7-.36-1.09-.69-2.18-1.07-3.26,0,0,0,0,0,0A1.87,1.87,0,0,0,14,6.27H4A1.83,1.83,0,1,0,4,9.92Z"/><path d="M21.24,34c-1,1.76-2,3.52-3,5.28-.15.25-.29.5-.43.76a1.85,1.85,0,0,0,1.58,2.75h27.9c1.28,0,2.58,0,3.87,0h0a1.83,1.83,0,0,0,0-3.66H23.35c-1.29,0-2.58,0-3.87,0h-.05L21,41.87l3-5.28c.14-.25.29-.5.43-.76A1.83,1.83,0,1,0,21.24,34Z"/><circle cx="45.58" cy="50.37" r="4.15"/><path d="M40.21,50.37a5.45,5.45,0,0,0,3.59,5.05,5.35,5.35,0,0,0,5.85-1.56,5.37,5.37,0,1,0-9.44-3.49,1.22,1.22,0,0,0,2.44,0c0-.1,0-.2,0-.3s0-.09,0-.13c0-.24,0,.08,0,.07a2.44,2.44,0,0,1,.15-.59c0-.05,0-.26.1-.27s-.11.22,0,.1,0-.1.07-.14a4.46,4.46,0,0,1,.31-.52c.12-.18-.16.19,0,0l.19-.21.2-.19.09-.08s.22-.12.06,0,0,0,0,0l.13-.1.21-.12.29-.14s.16-.08,0,0,.06,0,.08,0a3,3,0,0,1,.51-.15l.16,0c.14,0-.11,0-.11,0l.33,0c.2,0,.4,0,.6,0s-.23,0,0,0l.32.07.28.09.15,0s-.23-.12-.11,0,.36.18.53.29l.14.09s.13.06,0,0,0,0,0,0l.13.1a5.51,5.51,0,0,1,.41.43c.18.2-.09-.14,0,0l.15.24a1.88,1.88,0,0,1,.14.24l.06.11c.11.22,0,0,0,0s.15.46.18.54,0,.17.05.24c0,.24,0-.07,0-.07s0,.17,0,.2a5.23,5.23,0,0,1,0,.56.88.88,0,0,0,0,.17c0,.12-.07.1,0-.08a1.3,1.3,0,0,0-.07.33c0,.17-.11.33-.16.5s.11-.2,0-.06a.37.37,0,0,0-.05.11l-.15.28L48,52.1c-.17.25.11-.12,0,0a5.51,5.51,0,0,1-.41.43s-.17.18-.21.18.24-.17,0,0l-.1.07a5.29,5.29,0,0,1-.52.29c-.19.1.22-.07,0,0l-.27.09-.28.07-.12,0c-.27.06.19,0,0,0a3.88,3.88,0,0,1-.59,0h-.3s-.19,0,0,0,0,0-.08,0a4.57,4.57,0,0,1-.63-.19s-.16-.07,0,0,0,0-.07,0l-.28-.15-.27-.18c-.15-.09,0,.05.06.05s-.11-.09-.13-.11a4.78,4.78,0,0,1-.45-.45s-.1-.1-.1-.12.15.21.05.06l-.18-.27c-.06-.11-.11-.22-.17-.32-.13-.25.06.2,0-.08a4.5,4.5,0,0,1-.17-.63.42.42,0,0,0,0-.12c.09.2,0,.17,0,0s0-.26,0-.39a1.23,1.23,0,0,0-1.22-1.22,1.24,1.24,0,0,0-1.25,1.22Z"/><circle cx="24.58" cy="50.37" r="4.15"/><path d="M19.21,50.37a5.45,5.45,0,0,0,3.59,5.05,5.35,5.35,0,0,0,5.85-1.56,5.37,5.37,0,1,0-9.44-3.49,1.22,1.22,0,0,0,2.44,0c0-.1,0-.2,0-.3s0-.09,0-.13c0-.24,0,.08,0,.07a2.44,2.44,0,0,1,.15-.59c0-.05.05-.26.1-.27s-.11.22-.05.1.05-.1.07-.14a4.46,4.46,0,0,1,.31-.52c.12-.18-.16.19,0,0l.19-.21.2-.19.09-.08c.05,0,.22-.12.06,0s0,0,0,0l.13-.1.21-.12.29-.14s.16-.08,0,0,.06,0,.08,0a3,3,0,0,1,.51-.15l.16,0c.14,0-.11,0-.11,0l.33,0c.2,0,.4,0,.6,0s-.23,0,.05,0l.32.07.27.09.16,0s-.23-.12-.11,0,.36.18.53.29l.14.09s.13.06,0,0,0,0,0,0l.13.1a5.51,5.51,0,0,1,.41.43c.18.2-.09-.14,0,0l.15.24a1.88,1.88,0,0,1,.14.24l.06.11c.11.22,0,0,0,0s.15.46.18.54,0,.17.05.24c.05.24,0-.07,0-.07s0,.17,0,.2a5.23,5.23,0,0,1,0,.56.88.88,0,0,0,0,.17c0,.12-.07.1,0-.08a1.3,1.3,0,0,0-.07.33c0,.17-.11.33-.16.5s.11-.2,0-.06a.37.37,0,0,0-.05.11l-.15.28L27,52.1c-.17.25.11-.12,0,0a5.51,5.51,0,0,1-.41.43s-.17.18-.21.18.24-.17.05,0l-.1.07a5.29,5.29,0,0,1-.52.29c-.19.1.22-.07,0,0l-.27.09-.28.07-.12,0c-.27.06.19,0,0,0a3.88,3.88,0,0,1-.59,0h-.3s-.19,0,0,0,0,0-.08,0a4.19,4.19,0,0,1-.63-.19s-.16-.07,0,0,0,0-.07,0l-.28-.15-.27-.18c-.15-.09,0,.05.06.05s-.11-.09-.13-.11a3.82,3.82,0,0,1-.45-.45s-.1-.1-.1-.12.15.21.05.06l-.18-.27c-.06-.11-.11-.22-.17-.32-.13-.25.06.2,0-.08a4.5,4.5,0,0,1-.17-.63.42.42,0,0,0,0-.12c.09.2,0,.17,0,0s0-.26,0-.39a1.24,1.24,0,0,0-2.47,0ZM58.64,15.83,51.24,34.9H22.82L16.53,15.83Z"/><path d="M57.46,15.49Q56.22,18.73,55,22L51,32.23c-.3.79-.6,1.58-.91,2.36l1.18-.89H26.32c-1.14,0-2.3-.05-3.45,0h-.05l1.18.89c-.72-2.16-1.42-4.32-2.14-6.48-1.12-3.42-2.25-6.83-3.37-10.26l-.78-2.36L16.53,17H58.64a1.23,1.23,0,0,0,1.22-1.22,1.24,1.24,0,0,0-1.22-1.22H16.53a1.23,1.23,0,0,0-1.17,1.54l2.13,6.49q1.7,5.11,3.37,10.26c.27.78.52,1.57.78,2.36a1.27,1.27,0,0,0,1.18.9H47.74c1.15,0,2.31,0,3.46,0h0a1.25,1.25,0,0,0,1.17-.9q1.26-3.23,2.5-6.45,2-5.14,4-10.29c.3-.78.61-1.57.91-2.36a1.22,1.22,0,0,0-.85-1.5,1.26,1.26,0,0,0-1.5.85Z"/></svg>',
			'mini_cart_2' => '<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 62 62"><title>cart</title><path d="M55.89,38.66H21.21L17.58,7.8a1.91,1.91,0,0,0-1.9-1.69H6.11a1.92,1.92,0,1,0,0,3.83H14L17.61,40.8a1.91,1.91,0,0,0,1.9,1.69H55.89a1.92,1.92,0,1,0,0-3.83Z"/><circle cx="25.26" cy="50.15" r="5.74"/><circle cx="48.23" cy="50.15" r="5.74"/><path d="M34.83,19.51H23.17l.59,3.83H34.83Zm3.83,7.66H44.4v7.66H38.66Zm0-21.06H44.4v9.57H38.66Zm0,13.4H44.4v3.83H38.66ZM55.89,6.11H48.23v9.57h9.58V8A1.92,1.92,0,0,0,55.89,6.11ZM27.17,34.83h7.66V27.17H24.35l.93,6A1.91,1.91,0,0,0,27.17,34.83ZM48.23,19.51h9.58v3.83H48.23Zm0,15.32h7.66a1.92,1.92,0,0,0,1.92-1.92V27.17H48.23ZM34.83,15.68V6.11H23.34A1.91,1.91,0,0,0,21.43,8a1.37,1.37,0,0,0,0,.29l1.13,7.37Z"/></svg>',
			'mini_cart_3' => '<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 62 62"><title>cart</title><path d="M51.69,38.28,59.3,15.64a1.23,1.23,0,0,0-.17-1.07,1.14,1.14,0,0,0-1-.48H15.33L13.81,7.93A4.59,4.59,0,0,0,9.41,4.6H3.83A1.18,1.18,0,0,0,3.83,7H9.41a2.2,2.2,0,0,1,2.11,1.57l9.44,38a5.54,5.54,0,1,0,6.15,2.13H45.87a5.54,5.54,0,1,0,4.53-2.36H23.33L21.54,39.1h29A1.2,1.2,0,0,0,51.69,38.28Z"/></svg>',
			'mini_cart_4' => '<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 62 62"><defs><style>.cls-1{fill-rule:evenodd;}</style></defs><title>cart</title><path d="M36.18,5.81h-.12a1,1,0,0,0-.94,1.11,1.08,1.08,0,0,0,.07.31l5.82,15H21L26.81,7.23a1,1,0,0,0-.57-1.35,1.1,1.1,0,0,0-.44-.07,1,1,0,0,0-.93.67L17.67,25a.6.6,0,0,0-.06.19,1,1,0,0,1-.47-1.36l.65-1.67H4.19a2.06,2.06,0,0,0-2.06,2.06v1a2.06,2.06,0,0,0,2.06,2.06H57.81a2.06,2.06,0,0,0,2.06-2.06v-1a2.06,2.06,0,0,0-2.06-2.06H44.19l.65,1.67a1,1,0,0,1-.47,1.29.56.56,0,0,0,0-.12L37.13,6.48a1,1,0,0,0-1-.68Z"/><path class="cls-1" d="M7.28,29.4l5.08,22a6.19,6.19,0,0,0,6,4.8H43.6a6.19,6.19,0,0,0,6-4.8l5.08-22Zm9.79,5.65a1,1,0,0,1,1,.85l2.57,12.86a1,1,0,1,1-2,.51.52.52,0,0,1,0-.11L16.07,36.31a1,1,0,0,1,.78-1.23l.11,0h.11Zm8.73,0a1,1,0,0,1,1.07.93l1.55,12.86a1,1,0,1,1-2.05.31.2.2,0,0,0,0-.07L24.83,36.22a1,1,0,0,1,.88-1.16h.09Zm19.11,0a1,1,0,0,1,1,1,1.94,1.94,0,0,1,0,.24L43.35,49.16a1,1,0,1,1-2-.38v0L43.9,35.9a1,1,0,0,1,.9-.84h.11Zm-8.77,0a1,1,0,0,1,1,1,.53.53,0,0,1,0,.13L35.64,49.08a1,1,0,0,1-1.15.91,1,1,0,0,1-.91-1.15h0L35.13,36a1,1,0,0,1,.93-.91h.08Z"/></svg>',
			'mini_cart_5' => '<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 62 62"><defs><style>.cls-1{fill-rule:evenodd;}</style></defs><title>cart</title><path class="cls-1" d="M23.08,9.75a2.93,2.93,0,0,1,4.21,4.07l-.07.07-10,10H44.77l-10-10a2.93,2.93,0,0,1,4.14-4.14L51.33,22.17a2.87,2.87,0,0,1,.84,1.71h4.52a2.93,2.93,0,0,1,2.92,2.93,3.66,3.66,0,0,1,0,.57L52,50.79a2.93,2.93,0,0,1-2.87,2.35H12.92a2.93,2.93,0,0,1-2.87-2.35L2.44,27.38a2.93,2.93,0,0,1,2.3-3.44,2.76,2.76,0,0,1,.57-.06H9.83a2.87,2.87,0,0,1,.84-1.71ZM16.37,31.19a1.47,1.47,0,0,1,2.93,0V45.82a1.47,1.47,0,1,1-2.93,0Zm8.78,0a1.46,1.46,0,1,1,2.92,0V45.82a1.46,1.46,0,1,1-2.92,0Zm10.24-1.46a1.46,1.46,0,0,0-1.46,1.46V45.82a1.46,1.46,0,1,0,2.92,0V31.19A1.46,1.46,0,0,0,35.39,29.73Zm7.31,1.46a1.47,1.47,0,0,1,2.93,0V45.82a1.47,1.47,0,1,1-2.93,0Z"/></svg>',
			'mini_cart_6' => '<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 62 62"><title>cart</title><path d="M51.38,21.07,48.42,5H13.58l-3,16.06h-8v3.41H5L7.89,49.6A8.51,8.51,0,0,0,16.31,57H45.69a8.51,8.51,0,0,0,8.42-7.39L57,24.48h2.37V21.07ZM18.46,44.8,17.33,33.27h3.42L21.88,44.8Zm14.29,0H29.34V33.27h3.41Zm10.77,0H40.11l1.13-11.53h3.42ZM14.1,21.07,16.33,8.41H45.67L47.9,21.07Z"/></svg>',
		);
			if ( 'enable' == $mini_cart_enable ) {
				?>
	<div class="wcpt-minicart-icon wcpt-minicart-icon_<?php echo esc_attr( $mini_cart_placement ); ?> wcpt-minicart-icon_<?php echo esc_attr( $mini_cart_position ); ?>">
		<?php 
					echo ! empty( $icon_url[$mini_cart_icon] ) ?  wp_kses($icon_url[$mini_cart_icon], wwp_wc_allowed_html()) : wp_kses($icon_url['mini_cart_1'], wwp_wc_allowed_html());
					$cart_counts = '';
				if ( ! is_object( WC()->cart ) ) {
				return;
				}
			global $woocommerce;
			$cart_counts = $woocommerce->cart->cart_contents_count;

				?>
										<span class="mini_cart_contents_count" ><?php echo esc_attr( $cart_counts ); ?></span> 

	</div>

	<div class="cart-drawer cart-drawer_<?php echo esc_attr( $mini_cart_placement ); ?> ">
		<div class="wcpt-mini-cart-title">
			<!-- <a href="#" class="mini-cart-close">✕</a> -->
			<span class="dashicons dashicons-no-alt mini-cart-close"></span>
			<h4 class="wcpt-my-cart"><?php echo esc_html__( 'My Cart', 'woocommerce-wholesale-pricing' ); ?></h4>
		</div>
		<div class="widget_shopping_cart_content"><?php woocommerce_mini_cart(); ?>
	</div>
</div>
<div class="wcpt-global-loader">
  <div class="wcpt-spinner"></div>
</div>
	<?php 
			}


		}
	return ob_get_clean();
	}

	public static function resolveDependency() {
		return is_product_table_enabled();
	}
}