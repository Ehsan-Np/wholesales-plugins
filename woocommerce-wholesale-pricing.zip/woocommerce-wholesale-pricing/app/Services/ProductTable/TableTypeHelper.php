<?php

namespace WooCommerceWholesalePricing\App\Services\ProductTable;

/**
 * Helper for distinguishing Product Table vs Quick Order Form table types.
 */
class TableTypeHelper {

	public const TABLE_TYPE_PRODUCT_TABLE    = 'product_table';
	public const TABLE_TYPE_QUICK_ORDER_FORM = 'quick_order_form';
	public const META_KEY_TABLE_TYPE         = '_wcpt_table_type';
	public const POST_KEY_TABLE_TYPE         = 'wcpt_table_type';
	public const URL_PARAM_TABLE_TYPE        = 'table';

	/**
	 * Get the table type for a post.
	 *
	 * @param int|\WP_Post|null $post Post ID, post object, or null for current admin context.
	 * @return string
	 */
	public static function get_table_type( $post = null ) {
		$post_id = self::resolve_post_id( $post );

		if ( $post_id ) {
			$stored = get_post_meta( $post_id, self::META_KEY_TABLE_TYPE, true );
			if ( self::TABLE_TYPE_QUICK_ORDER_FORM === $stored ) {
				return self::TABLE_TYPE_QUICK_ORDER_FORM;
			}
		}

		if ( self::is_quick_order_form_url_context() ) {
			return self::TABLE_TYPE_QUICK_ORDER_FORM;
		}

		return self::TABLE_TYPE_PRODUCT_TABLE;
	}

	/**
	 * Whether the given post is a Quick Order Form table.
	 *
	 * @param int|\WP_Post|null $post Post ID, post object, or null for current admin context.
	 * @return bool
	 */
	public static function is_quick_order_form( $post = null ) {
		return self::TABLE_TYPE_QUICK_ORDER_FORM === self::get_table_type( $post );
	}

	/**
	 * Whether the current request indicates a quick order form (GET or POST).
	 *
	 * @return bool
	 */
	public static function is_quick_order_form_url_context() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET[ self::URL_PARAM_TABLE_TYPE ] ) && self::TABLE_TYPE_QUICK_ORDER_FORM === sanitize_text_field( wp_unslash( $_GET[ self::URL_PARAM_TABLE_TYPE ] ) ) ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST[ self::POST_KEY_TABLE_TYPE ] ) && self::TABLE_TYPE_QUICK_ORDER_FORM === sanitize_text_field( wp_unslash( $_POST[ self::POST_KEY_TABLE_TYPE ] ) ) ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST[ self::URL_PARAM_TABLE_TYPE ] ) && self::TABLE_TYPE_QUICK_ORDER_FORM === sanitize_text_field( wp_unslash( $_POST[ self::URL_PARAM_TABLE_TYPE ] ) ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Persist table type meta for a post.
	 *
	 * @param int    $post_id    Post ID.
	 * @param string $table_type Table type value.
	 * @return void
	 */
	public static function set_table_type( $post_id, $table_type ) {
		update_post_meta( $post_id, self::META_KEY_TABLE_TYPE, $table_type );
	}

	/**
	 * Resolve a post ID from various inputs.
	 *
	 * @param int|\WP_Post|null $post Post ID, post object, or null.
	 * @return int
	 */
	private static function resolve_post_id( $post ) {
		if ( is_numeric( $post ) ) {
			return (int) $post;
		}

		if ( $post instanceof \WP_Post ) {
			return (int) $post->ID;
		}

		global $post;
		if ( isset( $post ) && $post instanceof \WP_Post ) {
			return (int) $post->ID;
		}

		return 0;
	}
}
