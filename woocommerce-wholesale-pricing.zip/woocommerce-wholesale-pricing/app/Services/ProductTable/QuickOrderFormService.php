<?php

namespace WooCommerceWholesalePricing\App\Services\ProductTable;

use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Admin UX for Quick Order Form table type within the wcpt post type.
 */
class QuickOrderFormService extends Init implements ServiceInterface {

	/**
	 * @var string
	 */
	private $slug;

	public function __construct() {
		$this->slug = wwp_env()->get( 'product_table_slug' );

		add_action( 'admin_footer', array( $this, 'render_table_type_modal' ) );

		parent::__construct();
	}

	public function register() {
		// Hooks registered in constructor.
	}

	/**
	 * Output the table type selection modal on product table list and edit screens.
	 *
	 * @return void
	 */
	public function render_table_type_modal() {
		$screen = get_current_screen();
		if ( ! $screen ) {
			return;
		}

		$is_list_screen = ( 'edit-' . $this->slug === $screen->id );
		$is_edit_screen = ( $this->slug === $screen->id || $this->slug === $screen->post_type );

		if ( ! $is_list_screen && ! $is_edit_screen ) {
			return;
		}

		wwp_view( 'admin.product-table.table-type-modal' );
	}

	/**
	 * Save Quick Order Form post meta (columns + product filters + restrictions).
	 *
	 * @param int $product_table_id Post ID.
	 * @return void
	 */
	public static function save_post( $product_table_id ) {
		if ( ! isset( $_POST['wcpt_settings_display_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['wcpt_settings_display_nonce'] ) ), 'wcpt_settings_display_callback' ) ) {
			return;
		}

		TableTypeHelper::set_table_type( $product_table_id, TableTypeHelper::TABLE_TYPE_QUICK_ORDER_FORM );

		$fields = array();

		$link_key   = 0;
		$descr_key  = 0;
		$stock_key  = 0;
		$expand_key = 0;
		$date_key   = 0;
		$attr_key   = 0;
		$tax_key    = 0;
		$custom_key = 0;
		$cart_key   = 0;

		if ( isset( $_POST['woo_ids'] ) ) {
			$woo_ids = array_map( 'sanitize_text_field', wp_unslash( $_POST['woo_ids'] ) );
			foreach ( $woo_ids as $key => $id ) {
				$fields[ $key ]['woo_ids'] = $id;
				if ( isset( $_POST['woo_label'][ $key ] ) ) {
					$fields[ $key ]['woo_label'] = sanitize_text_field( wp_unslash( $_POST['woo_label'][ $key ] ) );
				}

				if ( isset( $_POST['woo_width_text'] ) ) {
					$width_text = '';
					if ( isset( $_POST['woo_width_text'][ $key ] ) ) {
						$width_text = sanitize_text_field( wp_unslash( $_POST['woo_width_text'][ $key ] ) );
					}

					if ( $width_text ) {
						$width_type = '';
						if ( isset( $_POST['woo_width_type'][ $key ] ) ) {
							$width_type = sanitize_text_field( wp_unslash( $_POST['woo_width_type'][ $key ] ) );
						}
						$option = ( 'percent' === $width_type ) ? '%' : 'px';
						$fields[ $key ]['woo_width']      = $width_text . '' . $option;
						$fields[ $key ]['woo_width_text'] = $width_text;
						$fields[ $key ]['woo_width_type'] = $width_type;
					} else {
						$fields[ $key ]['woo_width']      = '';
						$fields[ $key ]['woo_width_text'] = '';
					}
				}

				if ( isset( $_POST['woo_linkable'][ $link_key ] ) && ( 'title' === $id || 'featured_img' === $id ) ) {
					$fields[ $key ]['woo_expandable'] = ! empty( sanitize_text_field( wp_unslash( $_POST['woo_expandable'][ $expand_key ] ) ) ) ? sanitize_text_field( wp_unslash( $_POST['woo_expandable'][ $expand_key ] ) ) : '';
					$fields[ $key ]['woo_linkable']   = ! empty( sanitize_text_field( wp_unslash( $_POST['woo_linkable'][ $link_key ] ) ) ) ? sanitize_text_field( wp_unslash( $_POST['woo_linkable'][ $link_key ] ) ) : '';
					$expand_key++;
					$link_key++;
				} elseif ( isset( $_POST['woo_show_stock'][ $stock_key ] ) && 'stock' === $id ) {
					$fields[ $key ]['woo_show_stock'] = sanitize_text_field( wp_unslash( $_POST['woo_show_stock'][ $stock_key ] ) );
					$stock_key++;
				} elseif ( isset( $_POST['woo_descr'][ $descr_key ] ) && 'descr' === $id ) {
					$fields[ $key ]['woo_descr'] = sanitize_text_field( wp_unslash( $_POST['woo_descr'][ $descr_key ] ) );
					$descr_key++;
				} elseif ( isset( $_POST['woo_date_format'][ $date_key ] ) && 'date' === $id ) {
					$fields[ $key ]['woo_date_format'] = sanitize_text_field( wp_unslash( $_POST['woo_date_format'][ $date_key ] ) );
					$date_key++;
				} elseif ( isset( $_POST['woo_attrs'][ $attr_key ] ) && 'attributes' === $id ) {
					$fields[ $key ]['woo_attrs'] = sanitize_text_field( wp_unslash( $_POST['woo_attrs'][ $attr_key ] ) );
					$attr_key++;
				} elseif ( isset( $_POST['woo_custom_keys'][ $custom_key ] ) && 'custom_fields' === $id ) {
					$fields[ $key ]['woo_custom_keys'] = sanitize_text_field( wp_unslash( $_POST['woo_custom_keys'][ $custom_key ] ) );
					$custom_key++;
				} elseif ( isset( $_POST['woo_taxonomy'][ $tax_key ] ) && 'taxonomy' === $id ) {
					$fields[ $key ]['woo_taxonomy'] = sanitize_text_field( wp_unslash( $_POST['woo_taxonomy'][ $tax_key ] ) );
					$tax_key++;
				} elseif ( ( isset( $_POST['woo_quantity'][ $cart_key ] ) || isset( $_POST['woo_add_types'][ $cart_key ] ) || isset( $_POST['woo_add_selected_cart'][ $cart_key ] ) ) && 'cart_button' === $id ) {
					$fields[ $key ]['woo_quantity']          = sanitize_text_field( wp_unslash( $_POST['woo_quantity'][ $cart_key ] ) );
					$fields[ $key ]['woo_add_types']         = sanitize_text_field( wp_unslash( $_POST['woo_add_types'][ $cart_key ] ) );
					$fields[ $key ]['woo_add_selected_cart'] = sanitize_text_field( wp_unslash( $_POST['woo_add_selected_cart'][ $cart_key ] ) );
					$cart_key++;
				}
			}
		}

		update_post_meta( $product_table_id, 'product_table_fields', $fields );

		$wcpt_meta_settings = array(
			'display_wholesale_only',
			'wcpt_inc_product_cats',
			'wcpt_ex_product_cats',
			'wcpt_wholesale_selected_roles',
			'wcpt_addon_display',
			'wcpt_product_status',
		);

		foreach ( $wcpt_meta_settings as $wcpt_meta_setting ) {
			if ( isset( $_POST[ $wcpt_meta_setting ] ) ) {
				if ( is_array( $_POST[ $wcpt_meta_setting ] ) ) {
					$wcpt_meta = array_map( 'sanitize_text_field', wp_unslash( $_POST[ $wcpt_meta_setting ] ) );
				} else {
					$wcpt_meta = sanitize_text_field( wp_unslash( $_POST[ $wcpt_meta_setting ] ) );
				}

				update_post_meta( $product_table_id, $wcpt_meta_setting, $wcpt_meta );
			} else {
				update_post_meta( $product_table_id, $wcpt_meta_setting, '' );
			}
		}

		if ( isset( $_POST['wcpt_table_restricted_users'] ) ) {
			$selected_roles = array_map( 'sanitize_text_field', wp_unslash( $_POST['wcpt_table_restricted_users'] ) );
			update_post_meta( $product_table_id, '_wcpt_table_user_restriction', $selected_roles );
		}

		if ( isset( $_POST['wcpt_table_restricted_user_roles'] ) ) {
			$selected_roles = array_map( 'sanitize_text_field', wp_unslash( $_POST['wcpt_table_restricted_user_roles'] ) );
			update_post_meta( $product_table_id, '_wcpt_table_user_role_restriction', $selected_roles );
		}
	}

	public static function resolveDependency() {
		return is_product_table_enabled() && is_quick_order_form_enabled();
	}
}
