<?php
/**
 * SubscriptionService
 *
 * This service class is responsible for managing user roles based on their
 * WooCommerce Subscription status, specifically linking a purchased wholesale
 * subscription product to a corresponding wholesale user role.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * SubscriptionService
 *
 * Handles the logic for automatically assigning and revoking wholesale user
 * roles when a user purchases, updates, or cancels a designated wholesale
 * subscription product.
 *
 * @implements ServiceInterface
 */
class SubscriptionService implements ServiceInterface {

	/**
	 * Trait that provides static access to wholesale pricing settings.
	 */
	use WholesaleSettings;

	/**
	 * SubscriptionService constructor.
	 *
	 * Registers actions to monitor subscription events related to order creation,
	 * role updates, and status changes (cancellation/expiration).
	 */
	public function __construct() {
		// Assigns a wholesale role when a subscription is created from an order.
		add_action('subscriptions_created_for_order', array( $this, 'subscription_order' ), 99, 1);

		// Intercepts and adjusts role updates from WooCommerce Subscriptions.
		add_action('woocommerce_subscriptions_updated_users_role', array( $this, 'role_update' ), 99, 3);

		// Handles role reversal when a subscription is manually cancelled.
		add_action('woocommerce_subscription_status_cancelled', array( $this, 'subscription_status_cancelled' ), 10, 1);

		// Handles role reversal when a subscription expires naturally.
		add_action('woocommerce_subscription_status_expired', array( $this, 'subscription_status_cancelled' ), 10, 1);
	}

	/**
	 * Handles role assignment when a subscription order is processed.
	 *
	 * This function checks the order items for the configured wholesale subscription
	 * product, and if found, removes non-restricted user roles and assigns the
	 * wholesale role associated with the specific subscription variation.
	 *
	 * @param  \WC_Order $order The WooCommerce Order object for which subscriptions were created.
	 * @return void
	 */
	public function subscription_order( $order ) {
		// $subscription, $recurring_cart

		$subscription = wcs_get_subscriptions_for_order($order->id);

		$items                  = $order->get_items();
		$user_id                = $order->get_user_id();
		$user                   = get_user_by('id', $user_id);
		$settings               = self::get_pricing_settings();
		$wholesale_subscription = ! empty($settings['wholesale_subscription']) ? $settings['wholesale_subscription'] : '';
		if (empty($settings['enable_subscription']) || ( ! empty($settings['enable_subscription']) && 'no' == $settings['enable_subscription'] ) || empty($wholesale_subscription) ) {
			return;
		}
		if (! empty(array_intersect($this->resitricted_roles(), $user->roles)) ) {
			return;
		}

		foreach ( $items as $item ) {
			$product = $item->get_product();
			if (! empty($item->get_variation_id()) && 'product_variation' == get_post_type($item->get_variation_id()) && wp_get_post_parent_id($item->get_variation_id()) == $wholesale_subscription ) {
				$args = array(
					'hide_empty' => false,
					'meta_query' => array(
						array(
							'key'     => 'wwp_wholesaler_subscription',
							'value'   => $item->get_variation_id(),
							'compare' => 'IN',
						),
					),
					'taxonomy'   => 'wholesale_user_roles',
				);
				$term = get_terms($args);
				if (! empty($term) && ! empty($term[0]->slug) ) {
					foreach ( $user->roles as $role ) {
						$user->remove_role($role);
					}
					$user->add_role($term[0]->slug);
					
					/**
					 * Action Hook: wwp_wholesale_user_role_upgraded
					 * Fires after a user successfully purchases and is assigned a new wholesale role via subscription.
					 *
					 * @since 3.0.0
					 *
					 * @param int $user_id The ID of the user whose role was upgraded.
					 * @param string $new_role_slug The slug of the new wholesale role assigned.
					 */
					do_action('wwp_wholesale_user_role_upgraded', $user_id, $term[0]->slug);
					break;
				}
			}
		}
	}

	/**
	 * Intercepts and adjusts the role when WooCommerce Subscriptions tries to change it.
	 *
	 * If the *old* role was a **wholesale role** (found in the custom taxonomy), this
	 * function ensures the *new* role is removed, preventing the core Subscriptions
	 * logic from incorrectly setting the user back to the default customer role if
	 * they still have an active wholesale subscription.
	 *
	 * @param  string   $role_new The role slug that WCS is trying to assign.
	 * @param  \WP_User $user     The WP_User object being updated.
	 * @param  string   $role_old The previous role slug.
	 * @return void
	 */
	public function role_update( $role_new, $user, $role_old ) {

		foreach ( $user->roles as $role ) {
			$term = get_term_by('slug', $role, 'wholesale_user_roles');
			if (! empty($term->slug) ) {
				$user->remove_role($role_new);
				break;
			}
		}
	}

	/**
	 * Handles role removal when a subscription status changes to cancelled or expired.
	 *
	 * Finds and removes the user's wholesale role and assigns them the default
	 * cancelled role set in WooCommerce Subscriptions settings.
	 *
	 * @param  \WC_Subscription $subscription The WooCommerce Subscription object.
	 * @return void
	 */
	public function subscription_status_cancelled( $subscription ) {

		$user_id = get_post_meta($subscription->ID, '_customer_user', true);
		if (empty($user_id) ) {
			$user_id = $subscription->customer_id;
		}
		
		 /**
		 * Action Hook: wwp_wholesale_woo_subscription_status_cancelled_before
		 * Fires before a wholesale role is removed due to a subscription cancellation/expiration.
		 *
		 * @since 3.0.0 
		 * @param int $user_id The ID of the user.
		 * @param \WC_Subscription $subscription The subscription object.
		 */
		do_action('wwp_wholesale_woo_subscription_status_cancelled_before', $user_id, $subscription);

		$user = get_userdata($user_id);

		foreach ( $user->roles as $role ) {

			$term = get_term_by('slug', $role, 'wholesale_user_roles');

			if (! empty($term->slug) ) {
			
				/**
				 * Filter Hook: wwp_wholesale_subscription_cancelled_remove_wholesale_role
				 * Allows filtering the role slug to be removed.
				 *
				 * @since 3.0
				 *
				 * @param string $term_slug The wholesale role slug to be removed.
				 */
				$user->remove_role(apply_filters('wwp_wholesale_subscription_cancelled_remove_wholesale_role', $term->slug));

				break;

			}
		}
		
		/**
		 * Filter Hook: wwp_wholesale_subscription_cancelled_set_default_role
		 * Allows filtering the default role to be assigned after cancellation.
		 *
		 * @since 3.0
		 *
		 * @param string $default_role The default role slug from WCS settings.
		 */
		$user->add_role(apply_filters('wwp_wholesale_subscription_cancelled_set_default_role', get_option('woocommerce_subscriptions_cancelled_role')));
		/**
		 * Action Hook: wwp_wholesale_woo_subscription_status_cancelled_after
		 * Fires after the wholesale role is removed and the default role is assigned.
		 *
		 * @since 3.0
		 *
		 * @param int $user_id The ID of the user.
		 * @param \WC_Subscription $subscription The subscription object.
		 */
		do_action('wwp_wholesale_woo_subscription_status_cancelled_after', $user_id, $subscription);
	}

	/**
	 * Defines an array of user roles that should be exempt from role management
	 * by this service (e.g., administrator, editor, shop_manager).
	 *
	 * @return array List of restricted role slugs.
	 */
	public function resitricted_roles() {
		return array( 'editor', 'administrator', 'shop_manager' );
	}

	/**
	 * Determines whether this service should be initialized based on the environment.
	 *
	 * The service should only be loaded if the WooCommerce Subscriptions plugin is active.
	 *
	 * @return bool True if the WooCommerce Subscriptions plugin is active, false otherwise.
	 */
	public static function resolveDependency() {
		return wwp_is_subscription_active();
	}
}
