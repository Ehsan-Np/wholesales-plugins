<?php
/**
 * EmailService class.
 *
 * This service manages all custom email notifications related to wholesale functionality,
 * including registration requests, approvals, rejections, and customizing new order
 * email recipients for wholesale customers.
 *
 * It utilizes several traits to encapsulate the logic for specific email types.
 *
 * @package    WooCommerceWholesalePricing\Services
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Modules\Emails\Traits\ApprovalEmail;
use WooCommerceWholesalePricing\App\Modules\Emails\Traits\RejectionEmail;
use WooCommerceWholesalePricing\App\Modules\Emails\Traits\AdminRequestEmail;
use WooCommerceWholesalePricing\App\Modules\Emails\Traits\RegistrationEmail;
use WooCommerceWholesalePricing\App\Modules\Emails\Traits\SubscriptionUpgradeEmail;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Service class for handling all wholesale-related email notifications and recipient modification.
 *
 * Hooks into various custom actions and WooCommerce filters to dispatch emails
 * based on the user's wholesale lifecycle (registration, approval, upgrade)
 * and to modify where new order notifications are sent.
 */
class EmailService {


	/**
     * Trait providing access to general wholesale pricing settings via get_pricing_settings().
     
*/
	use WholesaleSettings;
	
	/**
	 * Trait containing logic for sending rejection emails to users.
	 */
	use RejectionEmail;

	/**
	 * Trait containing logic for sending new wholesale registration emails to users.
	 */
	use RegistrationEmail;

	/**
	 * Trait containing logic for notifying the admin of a new wholesale registration request.
	 */
	use AdminRequestEmail;

	/**
	 * Trait containing logic for sending approval emails to users.
	 */
	use ApprovalEmail;

	/**
	 * Trait containing logic for sending subscription/role upgrade notification emails.
	 */
	use SubscriptionUpgradeEmail;

	/**
     * Constructor: Registers all email-related actions and filters.
	 *
	 * @return void
     
	 */
	public function __construct() {

		// Filter the recipients of the WooCommerce New Order email.
		add_filter('woocommerce_email_recipient_new_order', array( $this, 'wholesale_new_order_email_recipient' ), 10, 2);

		// admin notification
		add_action('wwp_wholesale_new_request_submitted', array( $this, 'admin_request_notification' ), 10, 1);

		// approved user request
		add_action('wwp_wholesale_user_request_approved', array( $this, 'user_request_approved_notification' ), 10, 1);

		// reject request
		add_action('wwp_wholesale_user_rejection_notification', array( $this, 'user_rejection_notification' ), 10, 1);

		// new user register
		add_action('wwp_wholesale_new_registered_request', array( $this, 'new_registration_request' ), 10, 1);

		// version 1.3.0 subscription
		add_action('wwp_wholesale_user_role_upgraded', array( $this, 'subscription_role_upgraded' ), 10, 2);
	}

	/**
	 * Filters the recipient list for the WooCommerce 'New Order' email.
	 *
	 * If the order is placed by a wholesale customer and settings are enabled,
	 * it adds additional recipients (based on user role or custom email list)
	 * to the default admin recipient list.
	 *
	 * @filter woocommerce_email_recipient_new_order
	 * @param  string   $recipient Comma-separated list of current recipients (usually the site
	 *                              admin).
	 * @param  \WC_Order $order         The order
	 *                              object.
	 * @return string Modified comma-separated list of email recipients.
	 */
	public function wholesale_new_order_email_recipient( $recipient, $order ) {
		if (! is_a($order, 'WC_Order') ) {
			return $recipient;
		}

		$settings = self::get_pricing_settings();

		if ( !isset($settings['emailuserrole']) || '' == $settings['emailuserrole'] ) {
			$settings['emailuserrole'] = 'order_email_custom';
		}

		$customer_id = $order->get_customer_id();
		if (! is_wholesaler_user($customer_id) ) {
			return $recipient;
		}

		if ('order_email_user_role' == $settings['emailuserrole'] && '' != $settings['email_user_role_value'] ) {
			$manager_emails = array( $recipient );
			$users          = get_users(array( 'role' => $settings['email_user_role_value'] ));
			if (count($users) > 0 ) {
				foreach ( $users as $user ) {
					$manager_emails[] = $user->data->user_email;
				}
				if (count($manager_emails) > 0 ) {
					$recipient = implode(',', $manager_emails);
				}
			}
		} elseif ('order_email_custom' == $settings['emailuserrole'] && '' != $settings['order_custom_email_value'] ) {
			$recipient .= ',' . $settings['order_custom_email_value'];
		}
		
		return $recipient;
	}
}
