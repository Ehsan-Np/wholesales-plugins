<?php

namespace WooCommerceWholesalePricing\App\Services\CompanyCredits;

use WooCommerceWholesalePricing\App\Modules\CompanyCredits\PaymentGateway\BlockPaymentMethod;
use WooCommerceWholesalePricing\App\Modules\CompanyCredits\PaymentGateway\PaymentMethod;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Registers the Company Credit Payment gateway with WooCommerce.
 */
class PaymentGatewayService implements ServiceInterface {

	/**
	 * Gateway display name.
	 *
	 * @var string
	 */
	private $gateway_name = 'Company Credit Payment';

	/**
	 * PaymentGatewayService constructor.
	 */
	public function __construct() {
		add_filter( 'woocommerce_payment_gateways', array( $this, 'register_gateway' ) );
		add_action( 'woocommerce_blocks_loaded', array( $this, 'register_block_payment_method' ) );
	}

	/**
	 * Register the company credit payment gateway.
	 *
	 * @param array $gateways Registered gateways.
	 * @return array
	 */
	public function register_gateway( $gateways ) {
		if ( ! class_exists( 'WC_Payment_Gateway' ) || ! is_user_logged_in() ) {
			return $gateways;
		}

		$request_uri     = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( $_SERVER['REQUEST_URI'] ) : '';
		$is_wc_admin_api = str_contains( $request_uri, 'wc-admin/settings/payments/providers' );

		if ( is_admin() || $is_wc_admin_api ) {
			$gateways[] = new PaymentMethod( $this->gateway_name );
			return $gateways;
		}

		$company_id = get_user_meta( get_current_user_id(), 'ccp_company_id', true );
		if ( ! empty( $company_id ) ) {
			$gateways[] = new PaymentMethod( $this->gateway_name );
		}

		return $gateways;
	}

	/**
	 * Register the gateway with WooCommerce Blocks checkout.
	 *
	 * @return void
	 */
	public function register_block_payment_method() {
		if ( ! class_exists( '\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType' ) ) {
			return;
		}

		add_action(
			'woocommerce_blocks_payment_method_type_registration',
			function ( $payment_method_registry ) {
				$payment_method_registry->register( new BlockPaymentMethod() );
			}
		);
	}

	/**
	 * Whether this service should load.
	 *
	 * @return bool
	 */
	public static function resolveDependency() {
		return is_company_credits_enabled();
	}
}
