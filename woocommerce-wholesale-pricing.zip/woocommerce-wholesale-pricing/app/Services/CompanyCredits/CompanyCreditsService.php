<?php

namespace WooCommerceWholesalePricing\App\Services\CompanyCredits;

use WooCommerceWholesalePricing\App\Modules\CompanyCredits\CreditRequestsAjax;
use WooCommerceWholesalePricing\App\Modules\CompanyCredits\MyAccount;
use WooCommerceWholesalePricing\App\Modules\CompanyCredits\OrderStatus;
use WooCommerceWholesalePricing\App\Modules\CompanyCredits\OrdersAjax;
use WooCommerceWholesalePricing\App\Modules\CompanyCredits\SharedCart;
use WooCommerceWholesalePricing\App\Modules\CompanyCredits\SharedCartAjax;
use WooCommerceWholesalePricing\App\Modules\CompanyCredits\UsersAjax;
use WooCommerceWholesalePricing\App\Modules\CompanyCredits\UserEdit;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Company Credits module bootstrapper.
 */
class CompanyCreditsService implements ServiceInterface {

	/**
	 * CompanyCreditsService constructor.
	 */
	public function __construct() {
		new UserEdit();
		new MyAccount();
		new SharedCart();
		new SharedCartAjax();
		new CreditRequestsAjax();
		new OrderStatus();
		new OrdersAjax();
		new UsersAjax();
	}

	/**
	 * Whether this service should load.
	 *
	 * @return bool
	 */
	public static function resolveDependency() {
		return is_company_credits_enabled();
	}
}
