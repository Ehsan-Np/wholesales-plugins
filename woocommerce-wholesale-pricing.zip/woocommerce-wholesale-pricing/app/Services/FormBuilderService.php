<?php
/**
 * FormBuilderService class.
 *
 * Handles the integration, rendering, validation, and saving of custom form fields
 * created by the wholesale form builder module across various WooCommerce touchpoints,
 * including checkout and My Account pages.
 *
 * @package    WooCommerceWholesalePricing\Services
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Service class responsible for managing custom form fields integration.
 *
 * This class hooks into WooCommerce checkout and My Account actions to display,
 * validate, and persist data from custom wholesale registration fields.
 */
class FormBuilderService {

	/**
	 * Trait providing access to general wholesale registration settings via get_registration_settings().
	 */
	use WholesaleSettings;

	/**
	 * Constructor: Registers all necessary WooCommerce actions for form rendering, validation, and saving.
	 *
	 * @return void
	 */
	public function __construct() {
		// Render fields on the checkout page (after order notes)
		add_action( 'woocommerce_after_order_notes', array( $this, 'render_fields_on_checkout' ), 10, 1 );

		// Tax ID below billing on legacy checkout.
		add_action( 'woocommerce_after_checkout_billing_form', array( $this, 'render_tax_id_on_checkout' ) );

		// Validation and saving fields during checkout process
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'validation_on_checkout' ), 10, 2 );
		add_action( 'woocommerce_checkout_create_order', array( $this, 'update_field_in_order_meta' ), 20, 2 );
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'persist_tax_id_after_legacy_checkout' ), 20, 3 );

		// Render and save fields on the My Account edit page
		add_action( 'woocommerce_edit_account_form', array( $this, 'render_fields_on_edit_account' ) );
		add_action( 'woocommerce_save_account_details_errors', array( $this, 'validate_myaccount_fields' ), 10, 2 );
		add_action( 'woocommerce_save_account_details', array( $this, 'update_myaccount_fields' ) );
	}

	/**
	 * Whether Tax ID should appear on checkout.
	 *
	 * @param array|null $registrations Optional settings array.
	 * @return bool
	 */
	public static function is_tax_id_checkout_enabled( $registrations = null ) {
		if ( null === $registrations ) {
			$registrations = self::get_registration_settings();
		}

		return isset( $registrations['show_tax_on_checkout'] ) && 'yes' === $registrations['show_tax_on_checkout'];
	}

	/**
	 * Tax ID field label from settings.
	 *
	 * @param array|null $registrations Optional settings array.
	 * @return string
	 */
	public static function get_tax_id_label( $registrations = null ) {
		if ( null === $registrations ) {
			$registrations = self::get_registration_settings();
		}

		return ! empty( $registrations['woo_tax_id'] ) ? $registrations['woo_tax_id'] : __( 'Tax ID', 'woocommerce-wholesale-pricing' );
	}

	/**
	 * Whether Tax ID is required.
	 *
	 * @param array|null $registrations Optional settings array.
	 * @return bool
	 */
	public static function is_tax_id_required( $registrations = null ) {
		if ( null === $registrations ) {
			$registrations = self::get_registration_settings();
		}

		return isset( $registrations['required_tex_id'] ) && 'yes' === $registrations['required_tex_id'];
	}

	/**
	 * Whether VIES VAT validation is enabled.
	 *
	 * @param array|null $registrations Optional settings array.
	 * @return bool
	 */
	public static function is_vat_validation_enabled( $registrations = null ) {
		if ( null === $registrations ) {
			$registrations = self::get_registration_settings();
		}

		return isset( $registrations['vat_validation'] ) && 'yes' === $registrations['vat_validation'];
	}

	/**
	 * Selected countries for Tax ID visibility (empty = all countries).
	 *
	 * @param array|null $registrations Optional settings array.
	 * @return array<int, string>
	 */
	public static function get_vat_countries( $registrations = null ) {
		if ( null === $registrations ) {
			$registrations = self::get_registration_settings();
		}

		if ( empty( $registrations['vat_countries'] ) || ! is_array( $registrations['vat_countries'] ) ) {
			return array();
		}

		return array_values( array_filter( array_map( 'strval', $registrations['vat_countries'] ) ) );
	}

	/**
	 * Whether Tax ID should show for a billing country.
	 *
	 * @param string     $country       Billing country code.
	 * @param array|null $registrations Optional settings array.
	 * @return bool
	 */
	public static function should_show_tax_id_for_country( $country, $registrations = null ) {
		if ( ! self::is_tax_id_checkout_enabled( $registrations ) ) {
			return false;
		}

		$countries = self::get_vat_countries( $registrations );
		if ( empty( $countries ) ) {
			return true;
		}

		return in_array( strtoupper( (string) $country ), array_map( 'strtoupper', $countries ), true );
	}

	/**
	 * Validate Tax ID value for required / VAT rules.
	 *
	 * @param string     $tax_id            Submitted tax ID.
	 * @param string     $country           Billing country code.
	 * @param array|null $registrations     Optional settings array.
	 * @param bool       $check_visibility  When true, skip validation if field should not show for country.
	 * @return string|\WP_Error Empty string on success, WP_Error on failure.
	 */
	public static function validate_tax_id_value( $tax_id, $country = '', $registrations = null, $check_visibility = true ) {
		if ( null === $registrations ) {
			$registrations = self::get_registration_settings();
		}

		if ( $check_visibility && ! self::should_show_tax_id_for_country( $country, $registrations ) ) {
			return '';
		}

		$tax_id = sanitize_text_field( (string) $tax_id );
		$label  = self::get_tax_id_label( $registrations );

		if ( self::is_tax_id_required( $registrations ) && '' === $tax_id ) {
			return new \WP_Error(
				'wwp_wholesaler_tax_id_required',
				/* translators: %s: field label */
				sprintf( __( '%s is a required field.', 'woocommerce-wholesale-pricing' ), $label )
			);
		}

		// VIES only when a value was entered — never treat empty as VAT-required here.
		if ( '' !== $tax_id && self::is_vat_validation_enabled( $registrations ) ) {
			$validated = validate_vat( $tax_id );
			// validate_vat() returns a string error, or false on success.
			if ( is_string( $validated ) && '' !== $validated ) {
				// Map the empty-VAT message from validate_vat to the field label message.
				if ( false !== stripos( $validated, 'VAT Number is a required field' ) ) {
					return new \WP_Error(
						'wwp_wholesaler_tax_id_required',
						/* translators: %s: field label */
						sprintf( __( '%s is a required field.', 'woocommerce-wholesale-pricing' ), $label )
					);
				}
				return new \WP_Error( 'vat_validation_failed', $validated );
			}
		}

		return '';
	}

	/**
	 * Persist Tax ID on order meta, and on user meta when the shopper is logged in.
	 *
	 * @param \WC_Order $order   Order object.
	 * @param string    $tax_id  Tax ID value.
	 * @param int       $user_id Optional explicit user ID (e.g. before order customer is attached).
	 * @return void
	 */
	public static function save_tax_id_to_order( $order, $tax_id, $user_id = 0 ) {
		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		$tax_id = sanitize_text_field( (string) $tax_id );
		$order->update_meta_data( 'wwp_wholesaler_tax_id', $tax_id );

		if ( method_exists( $order, 'save_meta_data' ) ) {
			$order->save_meta_data();
		}

		$user_id = absint( $user_id );
		if ( ! $user_id ) {
			$user_id = absint( $order->get_user_id() );
		}
		if ( ! $user_id && is_user_logged_in() ) {
			$user_id = get_current_user_id();
		}

		if ( $user_id ) {
			update_user_meta( $user_id, 'wwp_wholesaler_tax_id', $tax_id );
		}
	}

	/**
	 * Extract submitted Tax ID from classic checkout POST.
	 *
	 * @return string|null Null when the field was not part of the request.
	 */
	public static function get_posted_tax_id() {
		if ( ! isset( $_POST['wwp_wholesaler_tax_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return null;
		}

		return sanitize_text_field( wp_unslash( $_POST['wwp_wholesaler_tax_id'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	/**
	 * Renders Tax ID below the billing form on legacy checkout.
	 *
	 * @action woocommerce_after_checkout_billing_form
	 * @return void
	 */
	public function render_tax_id_on_checkout() {
		$registrations = self::get_registration_settings();

		if ( ! self::is_tax_id_checkout_enabled( $registrations ) ) {
			return;
		}

		$label         = self::get_tax_id_label( $registrations );
		$is_required   = self::is_tax_id_required( $registrations );
		$value         = is_user_logged_in() ? get_user_meta( get_current_user_id(), 'wwp_wholesaler_tax_id', true ) : '';
		$countries     = self::get_vat_countries( $registrations );
		$countries_attr = ! empty( $countries ) ? esc_attr( wp_json_encode( $countries ) ) : '';

		woocommerce_form_field(
			'wwp_wholesaler_tax_id',
			array(
				'type'              => 'text',
				'class'             => array( 'form-row-wide', 'wwp-checkout-tax-id-field' ),
				'label'             => $label,
				'required'          => $is_required,
				'custom_attributes' => array_filter(
					array(
						'data-wwp-vat-countries' => $countries_attr,
					)
				),
			),
			$value
		);

		if ( ! empty( $countries ) ) {
			wc_enqueue_js(
				"jQuery(function($){
					var \$field = $('.wwp-checkout-tax-id-field');
					var countries = \$field.find('[data-wwp-vat-countries]').data('wwp-vat-countries') || [];
					if ( typeof countries === 'string' ) {
						try { countries = JSON.parse(countries); } catch(e) { countries = []; }
					}
					function toggleTaxId() {
						var country = ($('#billing_country').val() || '').toUpperCase();
						var allowed = (countries || []).map(function(c){ return String(c).toUpperCase(); });
						var show = !allowed.length || allowed.indexOf(country) !== -1;
						\$field.toggle(show);
						\$field.find('input').prop('disabled', !show);
						if ( ! show ) {
							\$field.find('input').val('');
						}
					}
					$(document.body).on('change updated_checkout', '#billing_country', toggleTaxId);
					$(document.body).on('country_to_state_changed', toggleTaxId);
					toggleTaxId();
				});"
			);
		}
	}

	/**
	 * Renders the custom wholesale form fields on the WooCommerce checkout page.
	 *
	 * Fields are rendered only if the 'display_fields_checkout' setting is enabled.
	 *
	 * @action woocommerce_after_order_notes
	 * @param  mixed $wccs_custom_checkout_field_pro Placeholder parameter (unused).
	 * @return void
	 */
	public function render_fields_on_checkout( $wccs_custom_checkout_field_pro ) {
		$registrations = self::get_registration_settings();
		if ( isset( $registrations['display_fields_checkout'] ) && 'yes' == $registrations['display_fields_checkout'] ) {
			echo wp_kses_post( (string) render_form_builder( 'get_option', '' ) );
		}
	}

	/**
	 * Validates the data submitted for the custom wholesale form fields during checkout.
	 *
	 * @action woocommerce_after_checkout_validation
	 * @param  array     $fields Unused checkout fields array.
	 * @param  \WP_Error $errors The WooCommerce error object where validation messages are added.
	 * @return void
	 */
	public function validation_on_checkout( $fields, $errors ) {
		$registrations = self::get_registration_settings();
		$country       = isset( $fields['billing_country'] ) ? $fields['billing_country'] : '';
		$tax_id        = isset( $_POST['wwp_wholesaler_tax_id'] ) ? sanitize_text_field( wp_unslash( $_POST['wwp_wholesaler_tax_id'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( self::is_tax_id_checkout_enabled( $registrations ) ) {
			$result = self::validate_tax_id_value( $tax_id, $country, $registrations );
			if ( is_wp_error( $result ) ) {
				$errors->add( $result->get_error_code(), $result->get_error_message() );
			}
		}

		if ( ! isset( $_POST['_wwp_nonce'] ) || ( isset( $_POST['_wwp_nonce'] ) && ! wp_verify_nonce( wc_clean( wp_unslash( $_POST['_wwp_nonce'] ) ), '_wwp_nonce' ) ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			return;
		}

		if ( ! isset( $_POST['data'] ) ) {
			return;
		}

		if (! empty(wwp_get_post_data('data')) ) {
			$formData = wwp_get_post_data('data');
			if (is_array($formData) ) {
				foreach ( $formData as $formData_value ) {
					if (isset($formData_value->required) && true == $formData_value->required ) {
						if (empty($_POST[ $formData_value->name ]) ) {
							$form_error = __('<strong> ' . $formData_value->label . ' </strong> is a required field.', 'woocommerce-wholesale-pricing');
							$errors->add('validation', $form_error);
						}
					}
				}
			}
		}
	}

	/**
	 * Saves the custom form data to the WooCommerce Order meta and optionally to the User meta.
	 *
	 * @action woocommerce_checkout_create_order
	 * @param  \WC_Order $order The WC_Order object being created.
	 * @param  array     $data  The submitted checkout data (unused directly).
	 * @return void
	 */
	public function update_field_in_order_meta( $order, $data ) {
		$registrations = self::get_registration_settings();
		$country       = isset( $data['billing_country'] ) ? $data['billing_country'] : $order->get_billing_country();
		$tax_id        = self::get_posted_tax_id();

		// Only persist when the field is shown for the billing country.
		if ( null !== $tax_id && self::should_show_tax_id_for_country( $country, $registrations ) ) {
			self::save_tax_id_to_order( $order, $tax_id );
		}

		if ( ! isset( $_POST['_wwp_nonce'] ) || ( isset( $_POST['_wwp_nonce'] ) && ! wp_verify_nonce( wc_clean( wp_unslash( $_POST['_wwp_nonce'] ) ), '_wwp_nonce' ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			return;
		}

		$post      = $_POST; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$form_data = wwp_get_form_builder_posted_data( $post );
		if ( ! empty( $form_data ) ) {
			if ( is_user_logged_in() ) {
				form_builder_update_user_meta( get_current_user_id(), $post );
			}
			$order->update_meta_data( 'wwp_form_data_json', $form_data );
		}
	}

	/**
	 * Ensure Tax ID is stored on the order (and logged-in user) after classic checkout completes.
	 *
	 * @action woocommerce_checkout_order_processed
	 * @param int       $order_id Order ID.
	 * @param array     $posted   Posted checkout data.
	 * @param \WC_Order $order    Order object.
	 * @return void
	 */
	public function persist_tax_id_after_legacy_checkout( $order_id, $posted, $order ) {
		if ( ! $order instanceof \WC_Order ) {
			$order = wc_get_order( $order_id );
		}
		if ( ! $order instanceof \WC_Order ) {
			return;
		}

		$registrations = self::get_registration_settings();
		$country       = isset( $posted['billing_country'] ) ? $posted['billing_country'] : $order->get_billing_country();
		$tax_id        = self::get_posted_tax_id();

		if ( null === $tax_id || ! self::should_show_tax_id_for_country( $country, $registrations ) ) {
			return;
		}

		self::save_tax_id_to_order( $order, $tax_id );
	}

	/**
	 * Renders the custom wholesale form fields on the My Account -> Account Details page.
	 *
	 * @action woocommerce_edit_account_form
	 * @return void
	 */
	public function render_fields_on_edit_account() {
		$registrations = self::get_registration_settings();

		if ( isset( $registrations['enable_tex_id'] ) && 'yes' == $registrations['enable_tex_id'] ) {
			$label         = self::get_tax_id_label( $registrations );
			$is_required   = self::is_tax_id_required( $registrations );
			$required_html = $is_required ? '<span class="required" aria-hidden="true">*</span>' : '';
			$aria_required = $is_required ? 'true' : 'false';
			$required_attr = $is_required ? 'required' : '';
			$value         = get_user_meta( get_current_user_id(), 'wwp_wholesaler_tax_id', true );

			echo wp_kses(
				'<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
					<label for="wwp_wholesaler_tax_id">' . esc_html( $label ) . ' ' . $required_html . '</label>
					<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="wwp_wholesaler_tax_id" id="wwp_wholesaler_tax_id" aria-required="' . esc_attr( $aria_required ) . '" ' . $required_attr . ' value="' . esc_attr( $value ) . '">
				</p>',
				array(
					'p'     => array( 'class' => true ),
					'label' => array( 'for' => true ),
					'span'  => array(
						'class'       => true,
						'aria-hidden' => true,
					),
					'input' => array(
						'type'          => true,
						'class'         => true,
						'name'          => true,
						'id'            => true,
						'value'         => true,
						'aria-required' => true,
						'required'      => true,
					),
				)
			);
		}

		if ( isset( $registrations['display_fields_myaccount'] ) && 'yes' == $registrations['display_fields_myaccount'] ) {
			wp_nonce_field( 'wwp_my_account_registration_extra_fields', 'wwp_my_account_registration_extra_fields' );
			echo render_form_builder( 'get_user_meta', get_current_user_id() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/**
	 * Updates the user meta with custom form data submitted from the My Account page.
	 *
	 * @action woocommerce_save_account_details
	 * @param  int $user_id The ID of the user whose details are being saved.
	 * @return void
	 */
	public function update_myaccount_fields( $user_id ) {
		$post          = wwp_get_post_data();
		$registrations = self::get_registration_settings();

		if ( isset( $registrations['enable_tex_id'] ) && 'yes' == $registrations['enable_tex_id'] && isset( $post['wwp_wholesaler_tax_id'] ) ) {
			update_user_meta( $user_id, 'wwp_wholesaler_tax_id', sanitize_text_field( $post['wwp_wholesaler_tax_id'] ) );
		}

		if (
			! isset( $post['wwp_my_account_registration_extra_fields'] )
			|| ! wp_verify_nonce( wc_clean( $post['wwp_my_account_registration_extra_fields'] ), 'wwp_my_account_registration_extra_fields' )
		) {
			return;
		}

		$form_data = wwp_get_form_builder_posted_data( $post );
		if ( empty( $form_data ) ) {
			return;
		}

		update_user_meta( $user_id, 'wwp_form_data_json', $form_data );
	}

	/**
	 * Validates Tax ID (required / VAT) on My Account save.
	 *
	 * @action woocommerce_save_account_details_errors
	 * @param  \WP_Error $errors Errors object.
	 * @param  \WP_User  $user   User being updated.
	 * @return void
	 */
	public function validate_myaccount_fields( $errors, $user ) {
		$registrations = self::get_registration_settings();
		$post          = wwp_get_post_data();

		if ( ! isset( $registrations['enable_tex_id'] ) || 'yes' !== $registrations['enable_tex_id'] ) {
			return;
		}

		$tax_id = isset( $post['wwp_wholesaler_tax_id'] ) ? sanitize_text_field( $post['wwp_wholesaler_tax_id'] ) : '';
		$result = self::validate_tax_id_value( $tax_id, '', $registrations, false );

		if ( is_wp_error( $result ) ) {
			$errors->add( $result->get_error_code(), $result->get_error_message() );
		}
	}
}
