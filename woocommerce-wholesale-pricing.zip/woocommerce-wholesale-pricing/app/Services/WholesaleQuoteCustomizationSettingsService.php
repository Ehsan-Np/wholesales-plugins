<?php
/**
 * Read and update quote customization settings (Labels & Customization tab).
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleOption;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

/**
 * Manages wc_quote_customization option from settings.php section6 Quotes.
 */
class WholesaleQuoteCustomizationSettingsService {

	/**
	 * Keys exposed to the ability API.
	 *
	 * @var list<string>
	 */
	const ALLOWED_KEYS = array(
		'build_quote_text',
		'convert_cart_text',
		'send_quote_text',
		'add_quote_text',
		'browse_list_text',
		'return_shop_text',
		'quote_counter_text',
		'quote_btn_positioning',
		'add_quote_btn_color',
		'add_quote_text_color',
		'send_quote_btn_color',
		'send_quote_text_color',
		'quote_counter_text_color',
	);

	/**
	 * Color picker fields.
	 *
	 * @var list<string>
	 */
	const COLOR_KEYS = array(
		'add_quote_btn_color',
		'add_quote_text_color',
		'send_quote_btn_color',
		'send_quote_text_color',
		'quote_counter_text_color',
	);

	/**
	 * Allowed values for quote_btn_positioning.
	 *
	 * @var list<string>
	 */
	const POSITION_VALUES = array(
		'inline',
		'underneath',
	);

	/**
	 * Get formatted quote customization settings.
	 *
	 * @return array<string, string>
	 */
	public function get_settings() {
		return $this->format_settings( $this->get_raw_settings() );
	}

	/**
	 * Update quote customization settings (partial merge).
	 *
	 * @param array<string, mixed> $settings Settings patch.
	 * @return array<string, string>|\WP_Error
	 */
	public function update_settings( array $settings ) {
		if ( empty( $settings ) ) {
			return new \WP_Error(
				'wwp_quote_customization_missing',
				__( 'Quote customization settings are required for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$unknown = array_diff( array_keys( $settings ), self::ALLOWED_KEYS );
		if ( ! empty( $unknown ) ) {
			return new \WP_Error(
				'wwp_quote_customization_invalid_field',
				sprintf(
					/* translators: %s: comma-separated field names */
					__( 'Unknown quote customization setting(s): %s', 'woocommerce-wholesale-pricing' ),
					implode( ', ', $unknown )
				),
				array( 'status' => 400 )
			);
		}

		$stored  = $this->get_raw_settings();
		$updated = $stored;

		foreach ( $settings as $key => $value ) {
			$sanitized = $this->sanitize_value( $key, $value );
			if ( is_wp_error( $sanitized ) ) {
				return $sanitized;
			}

			$updated[ $key ] = $sanitized;
		}

		WholesaleSettingsHelper::update_quote_customization_settings( $updated );

		return $this->get_settings();
	}

	/**
	 * Snapshot raw stored values for undo.
	 *
	 * @return array<string, mixed>
	 */
	public function snapshot_settings() {
		return array(
			'option_key' => WholesaleOption::QUOTE_CUSTOMIZATION_OPTION,
			'value'      => $this->get_raw_settings(),
		);
	}

	/**
	 * Restore a quote customization settings snapshot.
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_settings( array $snapshot ) {
		if ( empty( $snapshot['option_key'] ) || WholesaleOption::QUOTE_CUSTOMIZATION_OPTION !== $snapshot['option_key'] ) {
			return new \WP_Error(
				'wwp_quote_customization_restore_invalid_snapshot',
				__( 'Cannot restore quote customization settings: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$value = is_array( isset( $snapshot['value'] ) ? $snapshot['value'] : null ) ? $snapshot['value'] : array();
		WholesaleSettingsHelper::update_quote_customization_settings( $value );

		return true;
	}

	/**
	 * Get raw stored settings.
	 *
	 * @return array<string, mixed>
	 */
	private function get_raw_settings() {
		$stored = WholesaleSettingsHelper::get_quote_customization_settings();

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Format stored settings for API output.
	 *
	 * @param array<string, mixed> $stored Stored settings.
	 * @return array<string, string>
	 */
	private function format_settings( array $stored ) {
		$formatted = array();

		foreach ( self::ALLOWED_KEYS as $key ) {
			$formatted[ $key ] = $this->format_value( $key, isset( $stored[ $key ] ) ? $stored[ $key ] : '' );
		}

		return $formatted;
	}

	/**
	 * Format a single value for API output.
	 *
	 * @param string $key   Setting key.
	 * @param mixed  $value Stored value.
	 * @return string
	 */
	private function format_value( $key, $value ) {
		if ( 'quote_btn_positioning' === $key ) {
			$value = sanitize_key( (string) $value );

			return in_array( $value, self::POSITION_VALUES, true ) ? $value : 'inline';
		}

		if ( in_array( $key, self::COLOR_KEYS, true ) ) {
			$color = sanitize_hex_color( (string) $value );

			return is_string( $color ) ? $color : '';
		}

		return sanitize_text_field( (string) $value );
	}

	/**
	 * Sanitize an incoming value.
	 *
	 * @param string $key   Setting key.
	 * @param mixed  $value Incoming value.
	 * @return string|\WP_Error
	 */
	private function sanitize_value( $key, $value ) {
		if ( 'quote_btn_positioning' === $key ) {
			$position = sanitize_key( (string) $value );

			if ( ! in_array( $position, self::POSITION_VALUES, true ) ) {
				return new \WP_Error(
					'wwp_quote_customization_invalid_position',
					sprintf(
						/* translators: %s: allowed values */
						__( 'quote_btn_positioning must be one of: %s', 'woocommerce-wholesale-pricing' ),
						implode( ', ', self::POSITION_VALUES )
					),
					array( 'status' => 400 )
				);
			}

			return $position;
		}

		if ( in_array( $key, self::COLOR_KEYS, true ) ) {
			if ( '' === (string) $value ) {
				return '';
			}

			$color = sanitize_hex_color( (string) $value );

			if ( ! is_string( $color ) || '' === $color ) {
				return new \WP_Error(
					'wwp_quote_customization_invalid_color',
					sprintf(
						/* translators: %s: field key */
						__( 'Invalid color value for %s. Use a hex color such as #336699.', 'woocommerce-wholesale-pricing' ),
						$key
					),
					array( 'status' => 400 )
				);
			}

			return $color;
		}

		return sanitize_text_field( (string) $value );
	}
}
