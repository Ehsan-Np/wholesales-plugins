<?php
/**
 * ShopPriceVisibility
 *
 * This service implements the core logic for hiding product prices and the
 * 'Add to Cart' button from non-logged-in users, replacing them with a custom
 * login prompt or link, based on the plugin's settings.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @uses       WooCommerceWholesalePricing\App\Providers\WholesaleSettings
 * @extends    Init
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Controls the visibility of prices and purchasing capability on the shop frontend.
 *
 * Extends Init to ensure execution and implements ServiceInterface for dependency resolution.
 */
class ShopPriceVisibility extends Init implements ServiceInterface {


	/**
	 * Trait that provides static access to wholesale pricing settings.
	 */
	use WholesaleSettings;

	/**
	 * ShopPriceVisibility constructor.
	 *
	 * Initializes the service and registers the parent constructor and necessary hooks.
	 */
	public function __construct() {
		parent::__construct();

		add_filter('product_table_field_after', array( $this, 'price_visibility_product_table' ), 10, 2);
	}

	/**
	 * Registers and applies the price and cart visibility filters.
	 *
	 * This method is called by the parent Init class during initialization.
	 * It checks if the user is not logged in AND if the price hiding setting is enabled.
	 * If true, it removes WooCommerce's default price and add-to-cart actions/filters
	 * and adds custom replacements to hide them.
	 *
	 * @return void
	 */
	public function register() {
		$settings = self::get_pricing_settings();

		if ( $this->should_hide_price($settings) ) {
			remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
			remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 10);
			remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_price', 10);
			remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);
			remove_action('woocommerce_single_variation', 'woocommerce_single_variation_add_to_cart_button', 20);

			add_action('woocommerce_single_variation', array( $this, 'filter_variation_price' ));
			add_action('woocommerce_single_product_summary', array( $this, 'hide_retail_price' ), 10);
			add_action('woocommerce_after_shop_loop_item', array( $this, 'hide_retail_price' ), 11);
			add_filter('woocommerce_get_price_html', array( $this, 'filter_price_html' ), 10, 2);
			add_filter('woocommerce_is_purchasable', array( $this, 'filter_woocommerce_is_purchasable' ), 10, 2);
		}
	}

	/**
	 * Filters the variation price HTML output.
	 *
	 * Used in variable products to ensure the price within the variation form is hidden.
	 * Hooked to `woocommerce_single_variation`.
	 *
	 * @return string Empty string to hide the price.
	 */
	public function filter_variation_price() {
		return '';
	}

	/**
	 * Displays the "Login to see price" message/link.
	 *
	 * Used to replace the standard price/add-to-cart area on the product page and shop loop.
	 * Hooked to `woocommerce_single_product_summary` and `woocommerce_after_shop_loop_item`.
	 *
	 * @return void Outputs HTML directly.
	 */
	public function hide_retail_price() {
		$settings = self::get_pricing_settings();
		if ( ! $this->should_show_login_message($settings) ) {
			return;
		}

		if (isset($settings['display_link_text']) && ! empty($settings['display_link_text']) ) {
			$link_text = $settings['display_link_text'];
		} else {
			$link_text = esc_html__('Login to see price', 'woocommerce-wholesale-pricing');
		}
		echo '<a class="login-to-upgrade" href="' . esc_url(get_permalink(wc_get_page_id('myaccount'))) . '">' . esc_html__($link_text, 'woocommerce-wholesale-pricing') . '</a>';
	}

	/**
	 * Filters the WooCommerce price HTML globally.
	 *
	 * If the conditions for price hiding are met, this filter ensures all standard
	 * price outputs are suppressed. Hooked to `woocommerce_get_price_html`.
	 *
	 * @param  string      $price   The original price HTML.
	 * @param  \WC_Product $product The product object.
	 * @return string An empty string to hide the price.
	 */
	public function filter_price_html( $price, $product ) {
		return '';
	}

	/**
	 * Filters the product purchasability status.
	 *
	 * Prevents non-logged-in users from adding products to the cart even if
	 * the add-to-cart button UI is somehow bypassed. Hooked to `woocommerce_is_purchasable`.
	 *
	 * @param  bool        $is_purchasable Current purchasable status.
	 * @param  \WC_Product $instance       The product instance.
	 * @return bool False, preventing the purchase.
	 */
	public function filter_woocommerce_is_purchasable( $this_exists_publish, $instance ) {
		return false;
	}

	/**
	 * Filters the content of product table fields.
	 *
	 * Used for compatibility with product list/table plugins, replacing the
	 * price or cart button with the login link if price visibility is restricted.
	 * Hooked to `product_table_field_after`.
	 *
	 * @param  array  $product_record      Array of product data fields for the table row.
	 * @param  string $product_table_field The current field being processed (e.g., 'price').
	 * @return array The potentially modified product record.
	 */
	public function price_visibility_product_table( $product_record, $product_table_field ) {
		if ('price'  == $product_table_field || 'cart_button' == $product_table_field ) {
			$lastKey                  = count($product_record)-1;
			$product_record[$lastKey] = $this->login_to_see_price($product_record[$lastKey]);
		}
		return $product_record;
	}

	/**
	 * Helper function to generate the "Login to see price" HTML.
	 *
	 * Applies the visibility logic (non-logged-in + price hide setting) and
	 * returns the login link HTML if conditions are met, otherwise returns original content.
	 *
	 * @param  string $product_record The current product field content (e.g., price HTML).
	 * @return string The login link HTML or the original product record content.
	 */
	public function login_to_see_price( $product_record ) {
		$settings = self::get_pricing_settings();

		if ( $this->should_hide_price($settings) ) {
			if ( ! $this->should_show_login_message($settings) ) {
				return '';
			}

			if (isset($settings['display_link_text']) && ! empty($settings['display_link_text']) ) {
				$link_text = $settings['display_link_text'];
			} else {
				$link_text = esc_html__('Login to see price', 'woocommerce-wholesale-pricing');
			}
			return '<a class="login-to-upgrade" href="' . esc_url(get_permalink(wc_get_page_id('myaccount'))) . '">' . esc_html__($link_text, 'woocommerce-wholesale-pricing') . '</a>';
		} else {
			return $product_record;
		}
	}

	/**
	 * Determine whether shop prices should be hidden.
	 *
	 * Hides prices for:
	 * - Guests when the legacy "price_hide" checkbox is enabled.
	 * - Logged-in users whose role is included in "price_hide_role".
	 *
	 * @param  array $settings Pricing settings array.
	 * @return bool
	 */
	private function should_hide_price( $settings ) {
		$selected_roles = isset( $settings['price_hide_role'] ) && is_array( $settings['price_hide_role'] ) ? array_map( 'strtolower', $settings['price_hide_role'] ) : array();
		$hide_for_guest = ! is_user_logged_in() && in_array( 'guest', $selected_roles, true );

		$hide_for_selected_roles = false;
		if ( is_user_logged_in() && ! empty( $selected_roles ) ) {
			$current_user = wp_get_current_user();
			$user_roles   = is_array( $current_user->roles ) ? array_map( 'strtolower', $current_user->roles ) : array();

			$hide_for_selected_roles = ! empty( array_intersect( $user_roles, $selected_roles ) );
		}

		return $hide_for_guest || $hide_for_selected_roles;
	}

	/**
	 * Show login message only for guest-based price hiding.
	 *
	 * @param  array $settings Pricing settings array.
	 * @return bool
	 */
	private function should_show_login_message( $settings ) {
		$selected_roles = isset( $settings['price_hide_role'] ) && is_array( $settings['price_hide_role'] ) ? array_map( 'strtolower', $settings['price_hide_role'] ) : array();
		return ( ! is_user_logged_in() && in_array( 'guest', $selected_roles, true ) );
	}

	/**
	 * Dependency resolution check for the service.
	 *
	 * This service should only be loaded on the frontend, not in the admin area.
	 *
	 * @return bool True if the service should be initialized (i.e., not in admin).
	 */
	public  static function resolveDependency() {
		return ! is_admin();
	}
}
