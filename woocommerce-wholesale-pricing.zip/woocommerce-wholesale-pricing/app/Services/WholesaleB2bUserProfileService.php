<?php
/**
 * CRUD service for B2B / wholesale WordPress users.
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

/**
 * Manages wholesale customer user profiles, roles, and meta.
 */
class WholesaleB2bUserProfileService {

	/**
	 * User fields allowed on create/update (excluding roles/meta).
	 *
	 * @var list<string>
	 */
	const USER_FIELDS = array(
		'user_email',
		'display_name',
		'first_name',
		'last_name',
		'user_url',
		'description',
		'user_pass',
	);

	/**
	 * Meta keys that must not be read or written via the ability API.
	 *
	 * @var list<string>
	 */
	const PROTECTED_META_KEYS = array(
		'wp_capabilities',
		'wp_user_level',
		'session_tokens',
		'wp_user-settings',
		'wp_user-settings-time',
		'wp_dashboard_quick_press_last_post_id',
		'wp_persisted_preferences',
	);

	/**
	 * Role service for managing wholesale user roles.
	 * 
	 * @var WholesaleUserRoleService
	 */
	private $role_service;

	/**
	 * Constructor.
	 *
	 * @param WholesaleUserRoleService|null $role_service Optional role service.
	 */
	public function __construct( $role_service = null ) {
		$this->role_service = isset( $role_service ) ? $role_service : new WholesaleUserRoleService();
	}

	/**
	 * List users.
	 *
	 * @param array<string, mixed> $args Query args.
	 * @return array{users: list<array<string, mixed>>, total: int}
	 */
	public function list_users( array $args = array() ) {
		$per_page = max( 1, min( 100, (int) ( isset( $args['per_page'] ) ? $args['per_page'] : 20 ) ) );
		$page     = max( 1, (int) ( isset( $args['page'] ) ? $args['page'] : 1 ) );
		$search   = isset( $args['search'] ) ? sanitize_text_field( (string) $args['search'] ) : '';
		$role     = isset( $args['role'] ) ? sanitize_key( (string) $args['role'] ) : '';
		$wholesale_only = ! empty( $args['wholesale_only'] );

		$query_args = array(
			'number'         => $per_page,
			'paged'          => $page,
			'orderby'        => 'registered',
			'order'          => 'DESC',
			'count_total'    => true,
			'fields'         => 'all',
		);

		if ( '' !== $search ) {
			$query_args['search']         = '*' . $search . '*';
			$query_args['search_columns'] = array( 'user_login', 'user_email', 'display_name' );
		}

		if ( '' !== $role ) {
			if ( ! $this->role_exists( $role ) ) {
				return array(
					'users' => array(),
					'total' => 0,
				);
			}
			$query_args['role'] = $role;
		} elseif ( $wholesale_only ) {
			$slugs = $this->get_wholesale_role_slugs();
			if ( empty( $slugs ) ) {
				return array(
					'users' => array(),
					'total' => 0,
				);
			}
			$query_args['role__in'] = $slugs;
		}

		$query = new \WP_User_Query( $query_args );
		$users = array();

		foreach ( (array) $query->get_results() as $user ) {
			if ( $user instanceof \WP_User ) {
				$users[] = $this->format_user( $user, false );
			}
		}

		return array(
			'users' => $users,
			'total' => (int) $query->get_total(),
		);
	}

	/**
	 * Get a single user.
	 *
	 * @param string|int $identifier User ID, email, or login.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function get_user( $identifier ) {
		$user = $this->resolve_user( $identifier );
		if ( is_wp_error( $user ) ) {
			return $user;
		}

		return $this->format_user( $user, true );
	}

	/**
	 * Create a user.
	 *
	 * @param array<string, mixed> $data User payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function create_user( array $data ) {
		$login = isset( $data['user_login'] ) ? sanitize_user( (string) $data['user_login'], true ) : '';
		$email = isset( $data['user_email'] ) ? sanitize_email( (string) $data['user_email'] ) : '';

		if ( '' === $login ) {
			return new \WP_Error(
				'wwp_user_missing_login',
				__( 'user_login is required to create a user.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( '' === $email || ! is_email( $email ) ) {
			return new \WP_Error(
				'wwp_user_invalid_email',
				__( 'A valid user_email is required to create a user.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$user_data = array(
			'user_login' => $login,
			'user_email' => $email,
			'user_pass'  => isset( $data['user_pass'] ) && '' !== (string) $data['user_pass']
				? (string) $data['user_pass']
				: wp_generate_password( 20, true ),
		);

		foreach ( self::USER_FIELDS as $field ) {
			if ( 'user_pass' === $field || 'user_email' === $field ) {
				continue;
			}
			if ( isset( $data[ $field ] ) ) {
				$user_data[ $field ] = $this->sanitize_user_field( $field, $data[ $field ] );
			}
		}

		$user_id = wp_insert_user( $user_data );
		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		$roles_result = $this->apply_roles( (int) $user_id, $data );
		if ( is_wp_error( $roles_result ) ) {
			$this->delete_user_by_id( (int) $user_id );
			return $roles_result;
		}

		if ( isset( $data['meta'] ) && is_array( $data['meta'] ) ) {
			$meta_result = $this->apply_meta( (int) $user_id, $data['meta'] );
			if ( is_wp_error( $meta_result ) ) {
				$this->delete_user_by_id( (int) $user_id );
				return $meta_result;
			}
		}

		$user = get_user_by( 'id', (int) $user_id );
		if ( ! $user ) {
			return new \WP_Error(
				'wwp_user_create_failed',
				__( 'User was created but could not be loaded.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		return $this->format_user( $user, true );
	}

	/**
	 * Update a user.
	 *
	 * @param string|int           $identifier User ID, email, or login.
	 * @param array<string, mixed> $data       Update payload.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_user( $identifier, array $data ) {
		$user = $this->resolve_user( $identifier );
		if ( is_wp_error( $user ) ) {
			return $user;
		}

		if ( empty( $data ) ) {
			return new \WP_Error(
				'wwp_user_missing_data',
				__( 'User data is required for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$guard = $this->guard_mutable_user( (int) $user->ID );
		if ( is_wp_error( $guard ) ) {
			return $guard;
		}

		$user_data = array( 'ID' => (int) $user->ID );
		$has_user_field = false;

		foreach ( self::USER_FIELDS as $field ) {
			if ( ! array_key_exists( $field, $data ) ) {
				continue;
			}
			$user_data[ $field ] = $this->sanitize_user_field( $field, $data[ $field ] );
			$has_user_field      = true;
		}

		if ( $has_user_field ) {
			$updated = wp_update_user( $user_data );
			if ( is_wp_error( $updated ) ) {
				return $updated;
			}
		}

		if ( isset( $data['roles'] ) || isset( $data['role'] ) ) {
			$roles_result = $this->apply_roles( (int) $user->ID, $data );
			if ( is_wp_error( $roles_result ) ) {
				return $roles_result;
			}
		}

		if ( isset( $data['meta'] ) && is_array( $data['meta'] ) ) {
			$meta_result = $this->apply_meta( (int) $user->ID, $data['meta'] );
			if ( is_wp_error( $meta_result ) ) {
				return $meta_result;
			}
		}

		$fresh = get_user_by( 'id', (int) $user->ID );
		if ( ! $fresh ) {
			return new \WP_Error(
				'wwp_user_not_found',
				__( 'User not found after update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		return $this->format_user( $fresh, true );
	}

	/**
	 * Delete a user.
	 *
	 * @param string|int $identifier       User ID, email, or login.
	 * @param int        $reassign_user_id Optional user ID to reassign content to.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function delete_user( $identifier, $reassign_user_id = 0 ) {
		$user = $this->resolve_user( $identifier );
		if ( is_wp_error( $user ) ) {
			return $user;
		}

		$user_id = (int) $user->ID;

		$guard = $this->guard_mutable_user( $user_id, true );
		if ( is_wp_error( $guard ) ) {
			return $guard;
		}

		if ( $reassign_user_id > 0 && ! get_user_by( 'id', $reassign_user_id ) ) {
			return new \WP_Error(
				'wwp_user_invalid_reassign',
				__( 'Reassign user does not exist.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$deleted = $this->delete_user_by_id( $user_id, $reassign_user_id > 0 ? $reassign_user_id : null );
		if ( ! $deleted ) {
			return new \WP_Error(
				'wwp_user_delete_failed',
				__( 'Failed to delete user.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 500 )
			);
		}

		return array(
			'deleted'  => true,
			'user_id'  => $user_id,
			'user_login' => (string) $user->user_login,
		);
	}

	/**
	 * Snapshot user state for undo.
	 *
	 * @param int $user_id User ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function snapshot_user( $user_id ) {
		$user = get_user_by( 'id', $user_id );
		if ( ! $user ) {
			return new \WP_Error(
				'wwp_user_not_found',
				__( 'User not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		return $this->build_undo_state( $user );
	}

	/**
	 * Restore user state from snapshot (update undo).
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_user( array $snapshot ) {
		$user_id = (int) ( isset( $snapshot['ID'] ) ? $snapshot['ID'] : ( isset( $snapshot['id'] ) ? $snapshot['id'] : 0 ) );
		if ( $user_id <= 0 || ! get_user_by( 'id', $user_id ) ) {
			return new \WP_Error(
				'wwp_user_restore_invalid_snapshot',
				__( 'Cannot restore user: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$update = array( 'ID' => $user_id );
		foreach ( self::USER_FIELDS as $field ) {
			if ( array_key_exists( $field, $snapshot ) && 'user_pass' !== $field ) {
				$update[ $field ] = $snapshot[ $field ];
			}
		}

		$result = wp_update_user( $update );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( ! empty( $snapshot['roles'] ) && is_array( $snapshot['roles'] ) ) {
			$wp_user = new \WP_User( $user_id );
			foreach ( (array) $wp_user->roles as $role ) {
				$wp_user->remove_role( $role );
			}
			foreach ( $snapshot['roles'] as $role ) {
				$wp_user->add_role( sanitize_key( (string) $role ) );
			}
		}

		if ( ! empty( $snapshot['meta'] ) && is_array( $snapshot['meta'] ) ) {
			foreach ( $snapshot['meta'] as $meta_key => $meta_value ) {
				update_user_meta( $user_id, (string) $meta_key, $meta_value );
			}
		}

		return true;
	}

	/**
	 * Format a WP_User object for ability API output.
	 * 
	 * @param \WP_User $user          User object.
	 * @param bool     $include_meta  Whether to include meta.
	 * @return array<string, mixed>
	 */
	private function format_user( \WP_User $user, $include_meta ) {
		$roles           = array_values( array_map( 'strval', (array) $user->roles ) );
		$wholesale_roles = $this->get_wholesale_role_slugs();
		$wholesale_role  = '';

		foreach ( $roles as $role ) {
			if ( in_array( $role, $wholesale_roles, true ) ) {
				$wholesale_role = $role;
				break;
			}
		}

		$formatted = array(
			'ID'              => (int) $user->ID,
			'user_login'      => (string) $user->user_login,
			'user_email'      => (string) $user->user_email,
			'display_name'    => (string) $user->display_name,
			'first_name'      => (string) $user->first_name,
			'last_name'       => (string) $user->last_name,
			'user_url'        => (string) $user->user_url,
			'description'     => (string) $user->description,
			'roles'           => $roles,
			'wholesale_role'  => $wholesale_role,
			'is_wholesaler'   => function_exists( 'is_wholesaler_user' ) ? (bool) is_wholesaler_user( (int) $user->ID ) : in_array( $wholesale_role, $wholesale_roles, true ),
			'user_status'     => (string) get_user_meta( (int) $user->ID, '_user_status', true ),
			'registered_date' => (string) $user->user_registered,
		);

		if ( $include_meta ) {
			$formatted['meta'] = $this->export_user_meta( (int) $user->ID );
		}

		return $formatted;
	}

	/**
	 * Build a snapshot of user state for undo (update).
	 * 
	 * @param \WP_User $user User object.
	 * @return array<string, mixed>
	 */
	private function build_undo_state( \WP_User $user ) {
		$state = $this->format_user( $user, true );
		unset( $state['is_wholesaler'], $state['wholesale_role'], $state['registered_date'] );

		return $state;
	}

	/**
	 * Export user meta, excluding protected keys.
	 * 
	 * @param int $user_id User ID.
	 * @return array<string, mixed>
	 */
	private function export_user_meta( $user_id ) {
		$raw    = get_user_meta( $user_id );
		$export = array();

		if ( ! is_array( $raw ) ) {
			return $export;
		}

		foreach ( $raw as $key => $values ) {
			if ( $this->is_protected_meta_key( (string) $key ) ) {
				continue;
			}

			if ( ! is_array( $values ) ) {
				continue;
			}

			if ( 1 === count( $values ) ) {
				$export[ $key ] = maybe_unserialize( $values[0] );
			} else {
				$export[ $key ] = array_map( 'maybe_unserialize', $values );
			}
		}

		return $export;
	}

	/**
	 * Resolve a user by ID, email, or login.
	 * 
	 * @param string|int $identifier User identifier.
	 * @return \WP_User|\WP_Error
	 */
	private function resolve_user( $identifier ) {
		if ( is_numeric( $identifier ) ) {
			$user = get_user_by( 'id', (int) $identifier );
			if ( $user ) {
				return $user;
			}
		}

		$email = sanitize_email( (string) $identifier );
		if ( '' !== $email && is_email( $email ) ) {
			$user = get_user_by( 'email', $email );
			if ( $user ) {
				return $user;
			}
		}

		$login = sanitize_user( (string) $identifier, true );
		if ( '' !== $login ) {
			$user = get_user_by( 'login', $login );
			if ( $user ) {
				return $user;
			}
		}

		return new \WP_Error(
			'wwp_user_not_found',
			__( 'User not found.', 'woocommerce-wholesale-pricing' ),
			array( 'status' => 404 )
		);
	}

	/**
	 * Guard against modifying or deleting protected users (self, admin, editor).
	 * 
	 * @param int  $user_id      User ID.
	 * @param bool $allow_self   Whether self-delete is allowed.
	 * @return true|\WP_Error
	 */
	private function guard_mutable_user( $user_id, $allow_self = false ) {
		if ( ! $allow_self && get_current_user_id() === $user_id ) {
			return new \WP_Error(
				'wwp_user_protected_self',
				__( 'You cannot modify or delete your own account through this ability.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( user_can( $user_id, 'manage_options' ) ) {
			return new \WP_Error(
				'wwp_user_protected_admin',
				__( 'Administrator accounts cannot be modified through this ability.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		if ( user_can( $user_id, 'edit_others_posts' ) ) {
			return new \WP_Error(
				'wwp_user_protected_editor',
				__( 'Editor accounts cannot be modified through this ability.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 403 )
			);
		}

		return true;
	}

	/**
	 * Apply role patches to a user.
	 * 
	 * @param int                  $user_id User ID.
	 * @param array<string, mixed> $data    Payload containing role or roles.
	 * @return true|\WP_Error
	 */
	private function apply_roles( $user_id, array $data ) {
		$roles = array();

		if ( isset( $data['roles'] ) && is_array( $data['roles'] ) ) {
			$roles = array_values(
				array_filter(
					array_map(
						static function ( $role ) {
							return sanitize_key( (string) $role );
						},
						$data['roles']
					)
				)
			);
		} elseif ( isset( $data['role'] ) ) {
			$role = sanitize_key( (string) $data['role'] );
			if ( '' !== $role ) {
				$roles = array( $role );
			}
		} elseif ( isset( $data['user_login'] ) ) {
			$roles = array( WholesaleUserRoleService::DEFAULT_ROLE_SLUG );
		}

		if ( empty( $roles ) ) {
			return true;
		}

		foreach ( $roles as $role ) {
			if ( ! $this->role_exists( $role ) ) {
				return new \WP_Error(
					'wwp_user_invalid_role',
					sprintf(
						/* translators: %s: role slug */
						__( 'Unknown user role: %s', 'woocommerce-wholesale-pricing' ),
						$role
					),
					array( 'status' => 400 )
				);
			}
		}

		$wp_user = new \WP_User( $user_id );
		foreach ( (array) $wp_user->roles as $existing_role ) {
			$wp_user->remove_role( $existing_role );
		}
		foreach ( $roles as $role ) {
			$wp_user->add_role( $role );
		}

		return true;
	}

	/**
	 * Apply meta patches to a user.
	 * 
	 * @param int                  $user_id User ID.
	 * @param array<string, mixed> $meta    Meta patch.
	 * @return true|\WP_Error
	 */
	private function apply_meta( $user_id, array $meta ) {
		foreach ( $meta as $key => $value ) {
			$meta_key = $this->sanitize_meta_key( (string) $key );
			if ( '' === $meta_key || $this->is_protected_meta_key( $meta_key ) ) {
				return new \WP_Error(
					'wwp_user_protected_meta',
					sprintf(
						/* translators: %s: meta key */
						__( 'Meta key "%s" cannot be modified through this ability.', 'woocommerce-wholesale-pricing' ),
						(string) $key
					),
					array( 'status' => 400 )
				);
			}

			if ( null === $value ) {
				delete_user_meta( $user_id, $meta_key );
				continue;
			}

			if ( is_scalar( $value ) || is_array( $value ) ) {
				update_user_meta( $user_id, $meta_key, $value );
				continue;
			}

			return new \WP_Error(
				'wwp_user_invalid_meta_value',
				sprintf(
					/* translators: %s: meta key */
					__( 'Meta value for "%s" must be scalar, array, or null.', 'woocommerce-wholesale-pricing' ),
					$meta_key
				),
				array( 'status' => 400 )
			);
		}

		if ( class_exists( '\WC_Customer' ) && array_key_exists( '_user_status', $meta ) ) {
			$customer = new \WC_Customer( $user_id );
			$customer->update_meta_data( '_user_status', $meta['_user_status'] );
			$customer->save();
		}

		return true;
	}

	/**
	 * Sanitize a user field value based on the field type.
	 * 
	 * @param string $field Field name.
	 * @param mixed  $value Field value.
	 * @return string
	 */
	private function sanitize_user_field( $field, $value ) {
		if ( 'user_email' === $field ) {
			return sanitize_email( (string) $value );
		}

		if ( 'user_url' === $field ) {
			return esc_url_raw( (string) $value );
		}

		if ( 'description' === $field ) {
			return sanitize_textarea_field( (string) $value );
		}

		if ( 'user_pass' === $field ) {
			return (string) $value;
		}

		return sanitize_text_field( (string) $value );
	}

	/**
	 * Return true if a role exists in the system.
	 * 
	 * @param string $role Role slug.
	 * @return bool
	 */
	private function role_exists( $role ) {
		if ( '' === $role ) {
			return false;
		}

		return (bool) get_role( $role );
	}

	/**
	 * Get all wholesale role slugs.
	 * 
	 * @return list<string>
	 */
	private function get_wholesale_role_slugs() {
		$terms = get_terms(
			array(
				'taxonomy'   => $this->role_service->get_taxonomy(),
				'hide_empty' => false,
				'fields'     => 'slugs',
			)
		);

		if ( is_wp_error( $terms ) || ! is_array( $terms ) ) {
			return array( WholesaleUserRoleService::DEFAULT_ROLE_SLUG );
		}

		return array_values( array_map( 'strval', $terms ) );
	}

	/**
	 * Is a meta key protected (cannot be read or written via the ability API).
	 * 
	 * @param string $meta_key Meta key.
	 * @return bool
	 */
	private function is_protected_meta_key( $meta_key ) {
		if ( in_array( $meta_key, self::PROTECTED_META_KEYS, true ) ) {
			return true;
		}

		return 0 === strpos( $meta_key, 'wp_' );
	}

	/**
	 * Sanitize a meta key to allow only alphanumeric characters, underscores, and hyphens.
	 * 
	 * @param string $meta_key Meta key.
	 * @return string
	 */
	private function sanitize_meta_key( $meta_key ) {
		return (string) preg_replace( '/[^a-zA-Z0-9_-]/', '', $meta_key );
	}

	/**
	 * Delete a user by ID (loads admin user helpers when needed).
	 *
	 * @param int      $user_id           User ID.
	 * @param int|null $reassign_user_id  Optional user ID to reassign content to.
	 * @return bool
	 */
	private function delete_user_by_id( $user_id, $reassign_user_id = null ) {
		$this->load_delete_user_function();

		return (bool) \wp_delete_user( $user_id, $reassign_user_id );
	}

	/**
	 * Wp_delete_user() lives in wp-admin/includes/user.php and is not loaded on REST requests.
	 *
	 * @return void
	 */
	private function load_delete_user_function() {
		if ( function_exists( 'wp_delete_user' ) ) {
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/user.php';
	}
}
