<?php
namespace WooCommerceWholesalePricing\App\Services\Quote;

use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;
use WooCommerceWholesalePricing\App\Services\Quote\PDFService;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;


class AjaxService {

	use WholesaleSettings;

	private $quote_settings;

	/**
	 * Contains an array of quote widget list html.
	 *
	 * @var array
	 */
	public $quote_widget_list;
	/**
	 * Contains an array of quote widget icon list html.
	 *
	 * @var array
	 */
	public $quote_widget_icon;

	/**
	 * Contains html of quote widgets.
	 *
	 * @var array
	 */
	public $quote_widgets_elementor;

	private function ensure_guest_quote_session_cookie() {
		if (is_user_logged_in() ) {
			return;
		}

		if (! isset(WC()->session) ) {
			return;
		}

		if (method_exists(WC()->session, 'set_customer_session_cookie') ) {
			WC()->session->set_customer_session_cookie(true);
		}
	}

	public function __construct() {

		$this->quote_settings['general'] = get_option('wc_quote_general');
		$this->quote_settings['customization'] = get_option('wc_quote_customization');

		// Frontend Ajax Actions
		add_action('wp_ajax_wcquote_add_to_quote', array( $this, 'wc_quote_add_to_quote' ));
		add_action('wp_ajax_nopriv_wcquote_add_to_quote', array( $this, 'wc_quote_add_to_quote' ));

		add_action('wp_ajax_wcquote_add_to_quote_single', array( $this, 'wcquote_add_to_quote_single' ));
		add_action('wp_ajax_nopriv_wcquote_add_to_quote_single', array( $this, 'wcquote_add_to_quote_single' ));

		add_action('wp_ajax_wcquote_update_quote_items', array( $this, 'wcquote_update_quote_items' ));
		add_action('wp_ajax_nopriv_wcquote_update_quote_items', array( $this, 'wcquote_update_quote_items' ));

		add_action('wp_ajax_wcquote_remove_quote_item', array( $this, 'wcquote_remove_quote_item' ));
		add_action('wp_ajax_nopriv_wcquote_remove_quote_item', array( $this, 'wcquote_remove_quote_item' ));

		add_action('wp_ajax_wcquote_remove_quote_item', array( $this, 'wcquote_remove_quote_item' ));
		add_action('wp_ajax_nopriv_wcquote_remove_quote_item', array( $this, 'wcquote_remove_quote_item' ));

		add_action('wp_ajax_wc_check_availability_of_quote', array( $this, 'wc_check_availability_of_quote' ));
		add_action('wp_ajax_nopriv_wc_check_availability_of_quote', array( $this, 'wc_check_availability_of_quote' ));

		add_action('wp_ajax_wcquote_add_to_quote_variable', array( $this, 'wcquote_add_to_quote_variable' ));
		add_action('wp_ajax_nopriv_wcquote_add_to_quote_variable', array( $this, 'wcquote_add_to_quote_variable' ));

		add_action('wp_ajax_wcquote_add_to_cart', array( $this, 'wc_quote_add_to_cart' ));
		add_action('wp_ajax_nopriv_wcquote_add_to_cart', array( $this, 'wc_quote_add_to_cart' ));

		add_action('wp_ajax_wcquote_download_account_quote_pdf', array( $this, 'wcquote_download_account_quote_pdf' ));
		add_action('wp_ajax_nopriv_wcquote_download_account_quote_pdf', array( $this, 'wcquote_download_account_quote_pdf' ));

		add_action('wp_ajax_wcquote_build_quote', array( $this, 'wc_quote_build_quote' ));
		add_action('wp_ajax_nopriv_wcquote_build_quote', array( $this, 'wc_quote_build_quote' ));

		// Backend Ajax Actions
		add_action('wp_ajax_wc_quote_insert_product_row', array( $this, 'wc_quote_insert_product_row' ));
		add_action('wp_ajax_wc_quote_delete_quote_item', array( $this, 'wc_quote_delete_quote_item' ));
		add_action('wp_ajax_wc_quote_form_builder_save', array( $this, 'wc_quote_form_builder_save' ));
		add_action('wp_ajax_wc_reset_quote_counter', array( $this, 'wc_reset_quote_counter' ));
		add_action('wp_ajax_wc_quote_status_save', array( $this, 'wc_quote_status_save' ));
		add_action('wp_ajax_wc_quote_page_generate', array( $this, 'generate_quote_page' ));
		add_action('wp_ajax_wc_quote_page_delete', array( $this, 'delete_quote_page' ));

		// wc add custom tax and shipping
		add_action( 'wp_ajax_wc_quote_update_tax_shipping', array( $this, 'wc_quote_update_tax_shipping' ));
	}
	
	/**
	 * Add to Quote Shop Ajax Handler
	 *
	 * @return void
	 */
	public function wc_quote_add_to_quote() {
		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {
			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {
			die('Failed ajax security check!');
		}

		$this->ensure_guest_quote_session_cookie();

		if (isset($_POST) ) {
			$form_data = sanitize_meta('', wp_unslash($_POST), '');
		} else {
			$form_data = '';
		} 

		$ajax_product_name = '';
			
		$product_id = isset($form_data['product_id']) ? intval($form_data['product_id']) : '';
		$quantity   = isset($form_data['quantity']) ? intval($form_data['quantity']) : 1;
		$browse_list_text = ! empty($this->quote_settings['customization']['browse_list_text']) ? $this->quote_settings['customization']['browse_list_text'] : __('Browse the List', 'woocommerce-wholesale-pricing');
		$display_browse_list = isset($this->quote_settings['general']['display_browse_list']) ? $this->quote_settings['general']['display_browse_list'] : '0';
		$of_price_display = isset($this->quote_settings['general']['enable_offered']) ? $this->quote_settings['general']['enable_offered'] : '0';
		$price_display    = isset($this->quote_settings['general']['enable_standard']) ? $this->quote_settings['general']['enable_standard'] : '0';
		$quote_basket_style = isset($this->quote_settings['general']['quote_basket_style']) ? $this->quote_settings['general']['quote_basket_style'] : 'dropdown';
		$mini_cart = isset($this->quote_settings['general']['mini_cart']) ? $this->quote_settings['general']['mini_cart'] : '0';
		$quote_page = isset($this->quote_settings['general']['quote_page']) ? $this->quote_settings['general']['quote_page'] : '';
		$browse_list_btn = '';
		$wc_quote = new QuoteProcess();
			
		/**
		 * Filter wc_quote_add_to_quote_validation
		 * 
		 * @since 1.0
		**/
		$passed_validation = apply_filters('wc_quote_add_to_quote_validation', true, $product_id, $quantity);

		if (!$passed_validation ) {
			echo 'failed';
			die();
		}

		$ajax_item_key = $wc_quote->add_to_quote($form_data, $product_id, $quantity);
			
		if (is_user_logged_in() ) {
			wwp_persist_quote_user_meta();
		}

		$quote_contents = wc()->session->get('wc_quotes');
		$product        = '';
		$product_name   = 'Product';

		if (isset($quote_contents[ $ajax_item_key ]) ) {
			$product = $quote_contents[ $ajax_item_key ]['data'];
		}
			
		if (is_object($product) ) {
			$ajax_product_name = $product->get_name();
				
		}

		if ('yes' === get_option('woocommerce_enable_ajax_add_to_cart') && false !== $ajax_item_key  ) {
			
			ob_start();

			wwp_view( 'quote.quote-table', compact( 'wc_quote' ) );

			$quote_table = ob_get_clean();

			ob_start();

			wwp_view('quote.mini-quote', compact( 'quote_page', 'mini_cart', 'quote_basket_style', 'wc_quote' ));


			$mini_quote = ob_get_clean();

			ob_start();
			
			wwp_view( 'quote.quote-totals-table', compact( 'wc_quote', 'price_display', 'of_price_display' ) );

			$quote_totals = ob_get_clean();

			if ('1' == $display_browse_list) {
				
				$quote_page = get_quote_page_id();

				ob_start();
				?>
				<p class="browse_list">
					<?php
						/**
					 * Filter wcquote_product_added_message
					 * 
					 * @since 1.0
					**/ 
					echo esc_html( apply_filters( 'wcquote_product_added_message', __( 'Product Added to the Quote List', 'woocommerce-wholesale-pricing' ) ) ); 
					?>
				</p>
				<a href="<?php echo !empty($quote_page) ? esc_url(get_page_link($quote_page)) : '#'; ?>" class="wp-element-button button added_to_quote wc-forward" title="browse list"><?php echo esc_attr($browse_list_text); ?></a>
				<?php
				$browse_list_btn = ob_get_clean();
			}
				

			$this->wcquote_get_widgets();

			if (empty($quote_totals) ) {
				$quote_totals = '';
			}
	
			wp_send_json(
				array(
				'quote-item-key' => $ajax_item_key,
				'mini-quote'   => $mini_quote,
				'quote-table'  => $quote_table,
				'quote-totals' => $quote_totals,
				'browse_list'  => $browse_list_btn,
				'quote-widget-list' => $this->quote_widget_list,
				'quote-widget-icon' => $this->quote_widget_icon,
				'quote-widgets-elementor' => $this->quote_widgets_elementor,
						
				)
			);
		} elseif (false === $ajax_item_key ) {

			/* translators: %s: Product name */
			wc_add_notice(sprintf(__('“%s” has not been added to your quote.', 'woocommerce-wholesale-pricing'), $ajax_product_name), 'error');
			echo 'success';
		} else {
			/* translators: %s: Product name */
			wc_add_notice(sprintf(__('<a href="%1$1s" class="wp-element-button button wc-forward">View Quote</a> “%2$2s” has been added to your quote.', 'woocommerce-wholesale-pricing'), !empty($quote_page) ? esc_url(get_page_link($quote_page)) : '#', $ajax_product_name), 'success');
			echo 'success';
				
		}

		die();
	}
	
	/**
	 * Add to Quote Single Product Ajax Handler
	 *
	 * @return void
	 */
	public function wcquote_add_to_quote_single() {

		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {
			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {
			die('Failed ajax security check!');
		}

		$this->ensure_guest_quote_session_cookie();

		if (isset($_POST['form_data']) ) {
			parse_str(sanitize_meta('', wp_unslash($_POST['form_data']), ''), $form_data);
			if (isset($_POST['product_id']) ) {
				$form_data['add-to-cart'] = sanitize_text_field(wp_unslash($_POST['product_id']));
			}
		} else {
			$form_data = array();
		}

		$product_id   = isset($form_data['add-to-cart']) ? intval($form_data['add-to-cart']) : '';
		$browse_list_btn = '';
		$quantity     = isset($form_data['quantity']) ? intval($form_data['quantity']) : 1;
		$quote_page = get_quote_page_id();
		$browse_list_text = ! empty($this->quote_settings['customization']['browse_list_text']) ? $this->quote_settings['customization']['browse_list_text'] : __('Browse the List', 'woocommerce-wholesale-pricing');
		$display_browse_list = isset($this->quote_settings['general']['display_browse_list']) ? $this->quote_settings['general']['display_browse_list'] : '0';
		$mini_cart = isset($this->quote_settings['general']['mini_cart']) ? $this->quote_settings['general']['mini_cart'] : '0';
		$quote_basket_style = isset($this->quote_settings['general']['quote_basket_style']) ? $this->quote_settings['general']['quote_basket_style'] : 'dropdown';

		$wc_quote = new QuoteProcess();
		/**
		 * Filter wc_add_to_quote_validation
		 * 
		 * @since 1.0
		**/
		$passed_validation = apply_filters('wc_add_to_quote_validation', true, $product_id, $quantity, $form_data);

		if (!$passed_validation ) {
			echo 'failed';
			die();
		}
			
		$quote_item_key = $wc_quote->add_to_quote($form_data, $product_id, $quantity);

		$quote_contents = wc()->session->get('wc_quotes');

		if (is_user_logged_in() ) {
			wwp_persist_quote_user_meta();
		}

		$product = '';
		if (isset($quote_contents[ $quote_item_key ]) ) {
			$product = $quote_contents[ $quote_item_key ]['data'];
		} else {
			$product = wc_get_product($product_id);
		}
			
		$product_name = 'Product';
		if (is_object($product) ) {
			$product_name = $product->get_name();
		}
		if ('yes' === get_option('woocommerce_enable_ajax_add_to_cart') && false !== $quote_item_key  ) {
			
			ob_start();

			wwp_view('quote.mini-quote', compact( 'quote_page', 'mini_cart', 'quote_basket_style', 'wc_quote' ));

			$mini_quote = ob_get_clean();
								
			if ('1' == $display_browse_list) {
				ob_start();
				?>
				<p class="browse_list">
					<?php
						/**
					 * Filter wcquote_product_added_message
					 * 
					 * @since 1.0
					**/ 
					echo esc_html( apply_filters( 'wcquote_product_added_message', __( 'Product Added to the Quote List', 'woocommerce-wholesale-pricing' ) ) ); 
					?>
				</p>
				<a href="<?php echo !empty($quote_page) ? esc_url(get_page_link($quote_page)) : '#'; ?>" class="wp-element-button button added_to_quote wc-forward" title="browse list"><?php echo esc_html($browse_list_text); ?></a>
				<?php
				$browse_list_btn = ob_get_clean();
			}

			$this->wcquote_get_widgets();

			wp_send_json(
				array(
				'mini-quote'   => $mini_quote,
				'browse_list'  => $browse_list_btn,
				'quote-widget-list' => $this->quote_widget_list,
				'quote-widget-icon' => $this->quote_widget_icon,
				'quote-widgets-elementor' => $this->quote_widgets_elementor,
				)
			);
		} elseif (false === $quote_item_key ) {
			/* translators: %s: Product name */
			wc_add_notice(sprintf(__('Quote is not available for “%s”.', 'woocommerce-wholesale-pricing'), $product_name), 'error');
			echo 'success';
		} else {
			/* translators: %s: Product name */
			wc_add_notice(sprintf(__('<a href="%1$1s" class="wp-element-button button wc-forward">View Quote</a> “%2$2s” has been added to your quote.', 'woocommerce-wholesale-pricing'), !empty($quote_page) ? esc_url(get_page_link($quote_page)) : '#', $product_name), 'success');
			echo 'success';
		}
		die();
	}

	/**
	 * Get quote widget files 
	 */
	public function wcquote_get_widgets() {
		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {

			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {

			die('Failed ajax security check!');
		}

		$quote_list_ids = isset($_POST['quote_list_ids']) ? sanitize_meta('', wp_unslash($_POST['quote_list_ids']), '') : array();
		$quote_icon_ids = isset($_POST['quote_icon_ids']) ? sanitize_meta('', wp_unslash($_POST['quote_icon_ids']), '') : array();
		$post_id = isset($_POST['post_id']) ? sanitize_meta('', wp_unslash($_POST['post_id']), '') : '';

		$widget_quote_list = get_option('widget_quote_list', true);

		foreach ( $quote_list_ids as $quote_list_id ) {

			$quote_widget_key = str_replace('quote_list-', '', $quote_list_id);
			$instance = $widget_quote_list[$quote_widget_key];
			$args   = array();

			ob_start();

			wwp_view('quote.quote-list-widget', compact( 'instance', 'args' ));

			$this->quote_widget_list[$quote_list_id] = ob_get_clean();
		}


		$widget_quote_list_icon = get_option('widget_quote_list_icon', true);

		foreach ( $quote_icon_ids as $quote_icon_id ) {

			$quote_widget_key = str_replace('quote_list_icon-', '', $quote_icon_id);
			$instance = $widget_quote_list_icon[$quote_widget_key];
			ob_start();

			wwp_view('quote.quote-icon-widget', compact( 'instance' ));

			$this->quote_widget_icon[$quote_icon_id] = ob_get_clean();
		}
		if ( class_exists( '\Elementor\Plugin' ) && ! empty( $post_id ) && is_numeric( $post_id ) ) {
			$post_id = (int) $post_id;
			if (
				'builder' === get_post_meta( $post_id, '_elementor_edit_mode', true )
				&& 
				/**
				 * Filter wwp_quote_ajax_include_elementor_content to allow including Elementor content in the quote ajax response.
				 * 
				 * @since 3.4.0
				 */
				apply_filters( 'wwp_quote_ajax_include_elementor_content', true, $post_id )
			) {
				$this->quote_widgets_elementor = \Elementor\Plugin::$instance->frontend->get_builder_content( $post_id );
			}
		}
	}
	
	/**
	 * Update Quote Items Ajax Handler
	 *
	 * @return void
	 */
	public function wcquote_update_quote_items() {

		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {
			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {

			die('Failed ajax security check!');
		}

		if (isset($_POST['form_data']) ) {
			parse_str(sanitize_meta('', wp_unslash($_POST['form_data']), ''), $form_data);
		} else {
			$form_data = '';
		}

		/**
		* Filter wc_add_to_quote_check_cart_items
		* 
		* @since 1.0
		**/
		$pass_validation = apply_filters( 'wc_add_to_quote_check_cart_items', '' );
		$of_price_display = isset($this->quote_settings['general']['enable_offered']) ? $this->quote_settings['general']['enable_offered'] : '0';
		$price_display    = isset($this->quote_settings['general']['enable_standard']) ? $this->quote_settings['general']['enable_standard'] : '0';
		$mini_cart = isset($this->quote_settings['general']['mini_cart']) ? $this->quote_settings['general']['mini_cart'] : '0';
		$quote_page = isset($this->quote_settings['general']['quote_page']) ? $this->quote_settings['general']['quote_page'] : '';
		$quote_basket_style = isset($this->quote_settings['general']['quote_basket_style']) ? $this->quote_settings['general']['quote_basket_style'] : 'dropdown';

		$wc_quote = new QuoteProcess();

		if (! empty($pass_validation) ) {
			$message = wp_kses_post('<div class="woocommerce-error" role="alert">' . esc_attr($pass_validation) . '</div>');

			ob_start();
			wwp_view( 'quote.quote-table', compact( 'wc_quote' ) );
			$quote_table = ob_get_clean();
			ob_start();
			wwp_view( 'quote.quote-totals-table', compact( 'wc_quote', 'price_display', 'of_price_display' ) );
			$quote_totals = ob_get_clean();

			wp_send_json(
				array(
				'quote_empty'  => true,
				'quote-table'  => $quote_table,
				'message'      => $message,
				'quote-widget-list' => $this->quote_widget_list,
				'quote-widget-icon' => $this->quote_widget_icon,
				'quote-widgets-elementor' => $this->quote_widgets_elementor,
				'quote-totals' => $quote_totals,
				)
			);
			die;
		}

		$quotes = WC()->session->get('wc_quotes');

		foreach ( WC()->session->get('wc_quotes') as $quote_item_key => $quote_item ) {

			if (isset($form_data['quote_qty'][ $quote_item_key ]) ) {

				if (0 == $form_data['quote_qty'][ $quote_item_key ] ) {

					unset($quotes[ $quote_item_key ]);

				} else {

					$quotes[ $quote_item_key ]['quantity'] = intval($form_data['quote_qty'][ $quote_item_key ]);
				}
			}

			if (isset($form_data['offered_price'][ $quote_item_key ]) ) {
				$quotes[ $quote_item_key ]['offered_price'] = floatval($form_data['offered_price'][ $quote_item_key ]);
			}
			if (isset($form_data['offered_signup'][ $quote_item_key ]) ) {
				$quotes[ $quote_item_key ]['offered_signup'] = floatval($form_data['offered_signup'][ $quote_item_key ]);
			}
		}

		WC()->session->set('wc_quotes', $quotes);

		$quotes = WC()->session->get('wc_quotes');

		foreach ( WC()->session->get('wc_quotes') as $quote_item_key => $quote_item ) {

			if (isset($quote_item['quantity']) && empty($quote_item['quantity']) ) {

				unset($quotes[$quote_item_key]);
			}

			if (!isset($quote_item['data']) ) {
				unset($quotes[$quote_item_key]);
			}
		}

		WC()->session->set('wc_quotes', array_filter($quotes));
		/**
		 * Action wc_quote_session_changed
		 * 
		 * @since 1.0
		**/
		do_action('wc_quote_session_changed');

		if (is_user_logged_in() ) {
			wwp_persist_quote_user_meta();
		}

		ob_start();

		wwp_view( 'quote.quote-table', compact( 'wc_quote' ) );

		$quote_table = ob_get_clean();

		ob_start();
		wwp_view('quote.mini-quote', compact( 'quote_page', 'mini_cart', 'quote_basket_style', 'wc_quote' ));
		$mini_quote = ob_get_clean();
		/**
		 * Filter wcquote_quote_updated_message
		 * 
		 * @since 1.0
		**/
		$message = wp_kses_post('<div class="woocommerce-message" role="alert">' . esc_html( apply_filters( 'wcquote_quote_updated_message', __( 'Quote updated', 'woocommerce-wholesale-pricing' ) ) ) . '</div>');

		ob_start();

		wwp_view( 'quote.quote-totals-table', compact( 'wc_quote', 'price_display', 'of_price_display' ) );

		$quote_totals = ob_get_clean();

		$this->wcquote_get_widgets();
		
		if (empty($quote_totals) ) {
			$quote_totals = '';
		}

		$quote_widgets_elementor = $this->quote_widgets_elementor;
		/**
		 * Filter quote_widgets_elementor
		 * 
		 * @since 1.0
		**/
		if ( apply_filters('quote_widgets_elementor', false ) ) {
			$quote_widgets_elementor = '';
		}

		wp_send_json(
			array(
			'quote_empty'  => empty(WC()->session->get('wc_quotes')) ? true : false,
			'quote-table'  => $quote_table,
			'message'      => $message,
			'mini-quote'   => $mini_quote,
			'quote-widget-list' => $this->quote_widget_list,
			'quote-widget-icon' => $this->quote_widget_icon,
			'quote-widgets-elementor' => $quote_widgets_elementor,
			'quote-totals' => $quote_totals,
			)
		);
	}
	
	/**
	 * Remove Quote Item Ajax Handler
	 *
	 * @return void
	 */
	public function wcquote_remove_quote_item() {

		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {

			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {

			die('Failed ajax security check!');
		}

		$quote_key = isset($_POST['quote_key']) ? sanitize_text_field(wp_unslash($_POST['quote_key'])) : '';

			
		if (empty($quote_key) ) {
			die('Quote key is empty');
		}

		$quotes = WC()->session->get('wc_quotes');
		$of_price_display = isset($this->quote_settings['general']['enable_offered']) ? $this->quote_settings['general']['enable_offered'] : '0';
		$price_display    = isset($this->quote_settings['general']['enable_standard']) ? $this->quote_settings['general']['enable_standard'] : '0';
		$mini_cart = isset($this->quote_settings['general']['mini_cart']) ? $this->quote_settings['general']['mini_cart'] : '0';
		$quote_page = isset($this->quote_settings['general']['quote_page']) ? $this->quote_settings['general']['quote_page'] : '';
		$quote_basket_style = isset($this->quote_settings['general']['quote_basket_style']) ? $this->quote_settings['general']['quote_basket_style'] : 'dropdown';

		$wc_quote = new QuoteProcess();
			
		$product = $quotes[ $quote_key ]['data'];
		$deleted_product_name = '';
		if (is_object($product) ) {
			$deleted_product_name = $product->get_name();
		}
		unset($quotes[ $quote_key ]);

		WC()->session->set('wc_quotes', $quotes);
		/**
		 * Action wc_quote_session_changed
		 * 
		 * @since 1.0
		**/
		do_action('wc_quote_session_changed');

		if (is_user_logged_in() ) {
			wwp_persist_quote_user_meta();
		}
		/**
		 * Action wc_quote_item_removed
		 * 
		 * @since 1.0
		**/
		do_action('wc_quote_item_removed', $quote_key, $product);

		ob_start();
		wwp_view( 'quote.quote-table', compact( 'wc_quote' ) );
		$quote_table = ob_get_clean();

		ob_start();
		wwp_view('quote.mini-quote', compact( 'quote_page', 'mini_cart', 'quote_basket_style', 'wc_quote' ));
		$mini_quote = ob_get_clean();
		/* translators: %s: Product name */
		$message      = sprintf(__('“%s” has been removed from quote basket.', 'woocommerce-wholesale-pricing'), $deleted_product_name);
		$message_html = '<div class="woocommerce-message" role="alert">' . $message . '</div>';

		ob_start();
		wwp_view( 'quote.quote-totals-table', compact( 'wc_quote', 'price_display', 'of_price_display' ) );
		$quote_totals = ob_get_clean();
			
		$this->wcquote_get_widgets();

		if (empty($quote_totals) ) {
			$quote_totals = '';
		}

		$quote_widgets_elementor = $this->quote_widgets_elementor;
		/**
		 * Filter quote_widgets_elementor
		 * 
		 * @since 1.0
		**/
		if ( apply_filters('quote_widgets_elementor', false ) ) {
			$quote_widgets_elementor = '';
		}

		wp_send_json(
			array(
			'quote_empty'  => empty(WC()->session->get('wc_quotes')) ? true : false,
			'quote-table'  => $quote_table,
			'message'      => $message_html,
			'mini-quote'   => $mini_quote,
			'quote-widget-list' => $this->quote_widget_list,
			'quote-widget-icon' =>$this->quote_widget_icon,
			'quote-widgets-elementor' => $quote_widgets_elementor,
			'quote-totals' => $quote_totals,
			)
		);

		die();
	}
	
	/**
	 * Check Availability of Quote Ajax Handler
	 *
	 * @return void
	 */
	public function wc_check_availability_of_quote() {

		$nonce = isset($_POST['nonce']) && '' !== $_POST['nonce'] ? sanitize_text_field(wp_unslash($_POST['nonce'])) : 0;

		if (!empty($_POST['nonce']) && ! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {
			die('Failed ajax security check!');
		}

		$variation_id = isset($_POST['variation_id']) ? sanitize_text_field(wp_unslash($_POST['variation_id'])) : '';

		if (empty($variation_id) ) {
			wp_send_json_error();
		}

		$variation = wc_get_product($variation_id);
		$show_on_stock = isset($this->quote_settings['general']['show_on_stock']) ? $this->quote_settings['general']['show_on_stock'] : 'hide';
		if (! $variation->is_in_stock() && 'show' !== $show_on_stock ) {
			wp_send_json_error();
		}

		wp_send_json_success();
		die();
	}
	
	/**
	 * Add to Quote Variable Product Ajax Handler
	 *
	 * @return void
	 */
	public function wcquote_add_to_quote_variable() {

		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {
			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {

			die('Failed ajax security check!');
		}

		$this->ensure_guest_quote_session_cookie();

		if (isset($_POST['form_data']) && ! empty($_POST['form_data']) ) {
			parse_str(sanitize_meta('', wp_unslash($_POST['form_data']), ''), $form_data);
		} else {
			$form_data = map_deep($_POST, 'wc_clean');
		}

		$product_id   = isset($form_data['add-to-cart']) ? intval($form_data['add-to-cart']) : '';
		$quantity     = isset($form_data['quantity']) ? intval($form_data['quantity']) : 1;
		$variation_id = isset($form_data['variation_id']) ? intval($form_data['variation_id']) : '';
		$variation    = array();
		$quote_page = isset($this->quote_settings['general']['quote_page']) ? $this->quote_settings['general']['quote_page'] : '';
		$browse_list_text = ! empty($this->quote_settings['customization']['browse_list_text']) ? $this->quote_settings['customization']['browse_list_text'] : __('Browse the List', 'woocommerce-wholesale-pricing');
		$display_browse_list = isset($this->quote_settings['general']['display_browse_list']) ? $this->quote_settings['general']['display_browse_list'] : '0';
		$quote_basket_style = isset($this->quote_settings['general']['quote_basket_style']) ? $this->quote_settings['general']['quote_basket_style'] : 'dropdown';
		 $mini_cart = isset($this->quote_settings['general']['mini_cart']) ? $this->quote_settings['general']['mini_cart'] : '0';
			
		foreach ( $form_data as $key => $value ) {

			if (! in_array($key, array( 'add-to-cart', 'quantity', 'variation_id', 'product_id' ), true) ) {

				$variation[ $key ] = $value;
			}
		}

		$wc_quote = new QuoteProcess();
		/**
		 * Filter wc_add_to_quote_validation
		 * 
		 * @since 1.0
		**/
		$passed_validation = apply_filters('wc_add_to_quote_validation', true, $product_id, $quantity, $form_data);

		if (!$passed_validation ) {
			echo 'failed';
			die();
		}

		$quote_item_key = $wc_quote->add_to_quote($form_data, $product_id, $quantity, $variation_id, $variation);

		$quote_contents = wc()->session->get('wc_quotes');

		if (is_user_logged_in() ) {
			wwp_persist_quote_user_meta();
		}

		$product = '';

		if (isset($quote_contents[ $quote_item_key ]) ) {
			$product = $quote_contents[ $quote_item_key ]['data'];
		} else {
			$product = wc_get_product($variation_id);
		}

		$product_name = 'Product';
		if (is_object($product) ) {
			$product_name = $product->get_name();
		}
		if ('yes' === get_option('woocommerce_enable_ajax_add_to_cart') && false !== $quote_item_key  ) {
			ob_start();

			wwp_view('quote.mini-quote', compact( 'quote_page', 'mini_cart', 'quote_basket_style', 'wc_quote' ));

			$mini_quote = ob_get_clean();

			if ('1' == $display_browse_list) {
				ob_start();
				?>
				<p class="browse_list">
					<?php
					/**
					 * Filter wcquote_product_added_message
					 * 
					 * @since 1.0
					**/ 
					echo esc_html( apply_filters( 'wcquote_product_added_message', __( 'Product Added to the Quote List', 'woocommerce-wholesale-pricing' ) ) ); 
					?>
				</p>
				<a href="<?php echo !empty($quote_page) ? esc_url(get_page_link($quote_page)) : '#'; ?>" class="wp-element-button button added_to_quote wc-forward" title="browse list"><?php echo esc_html($browse_list_text); ?></a>
				<?php
				$browse_list_btn = ob_get_clean();
			}

			$this->wcquote_get_widgets();

			wp_send_json(
				array(
				'mini-quote'   => $mini_quote,
				'browse_list'  => $browse_list_btn,
				'quote-widget-list' => $this->quote_widget_list,
				'quote-widget-icon' => $this->quote_widget_icon,
				'quote-widgets-elementor' => $this->quote_widgets_elementor,
				)
			);
		} elseif (false === $quote_item_key ) {
			/* translators: %s: Product name */
			wc_add_notice(__('Quote is not available for selected variation.', 'woocommerce-wholesale-pricing'), 'error');
			echo 'success';
		} else {
			/* translators: %s: Product name */
			wc_add_notice(sprintf(__('<a href="%1$1s" class="wp-element-button button wc-forward">View Quote</a> “%2$2s” has been added to your quote.', 'woocommerce-wholesale-pricing'), !empty($quote_page) ? esc_url(get_page_link($quote_page)) : '#', $product_name), 'success');
			echo 'success';
		}
		die();
	}
	
	/**
	 * Quote convert to cart
	 *
	 * @return void
	 */
	public function wc_quote_add_to_cart() {
		global $woocommerce;
		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {
			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {
			die('Failed ajax security check!');
		}

		$items = wc()->session->get('wc_quotes');
		foreach ( $items as $item => $form_data ) {
			$product_id = isset($form_data['product_id']) ? intval($form_data['product_id']) : '';
			$quantity   = isset($form_data['quantity']) ? intval($form_data['quantity']) : 1;
			$variation_id   = isset($form_data['variation_id']) ? intval($form_data['variation_id']) : 0;
			$variation   = isset($form_data['variation']) ? $form_data['variation'] : array();
			/**
			 * Filter wc_quote_add_to_cart_validation
			 * 
			 * @since 1.0
			**/
			$passed_validation = apply_filters('wc_quote_add_to_cart_validation', true, $product_id, $quantity, $form_data);

			if (!$passed_validation ) {
				echo 'failed';
				die();
			}
			$product_cart_id = WC()->cart->generate_cart_id($product_id, $variation_id, $variation);
			$cart_item_key = WC()->cart->find_product_in_cart($product_cart_id);
			if ($cart_item_key ) {
				WC()->cart->remove_cart_item($cart_item_key);
			}
			$cart_item_key = $woocommerce->cart->add_to_cart($product_id, $quantity, $variation_id, $variation);

			$cart_contents = $woocommerce->cart->get_cart();
			$product        = '';
			$product_name   = 'Product';

			if (isset($cart_contents[ $cart_item_key ]) ) {
				$product = $cart_contents[ $cart_item_key ]['data'];
			}

			if (is_object($product) ) {
				$product_name = $product->get_name();
			}

			if (false === $cart_item_key ) {
				/* translators: %s: Product name */
				wc_add_notice(sprintf(__('“%s” has not been added to your cart.', 'woocommerce-wholesale-pricing'), $product_name), 'error');

			} else {
				/* translators: %s: Product name */
				wc_add_notice(sprintf(__('“%s” has been added to your cart.', 'woocommerce-wholesale-pricing'), $product_name), 'success');
			}
				
		}
		echo 'success';

		die();
	}
	
	/**
	 * Save Custom Quote Status Ajax Handler
	 *
	 * @return void
	 */
	public function wc_quote_status_save() {

		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {

			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {

			die('Failed ajax security check!');
		}
		$data = $_POST;
		$post_id = isset($data['postID']) ? $data['postID'] : '';
		$enable_status = isset($data['enable_status']) ? $data['enable_status'] : '';
		$wc_quote_status = get_post_meta( $post_id, 'wc_quote_status', true );
		$wc_quote_status['enable_quote_status'] = $enable_status;
		update_post_meta($post_id, 'wc_quote_status', $wc_quote_status);
	}
	
	/**
	 * Download Quote PDF My Account Ajax Handler
	 *
	 * @return void
	 */
	public function wcquote_download_account_quote_pdf() {

		if ( ! is_user_logged_in() ) {
			wp_send_json_error('User not logged in');
		}

		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {

			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {

			die('Failed ajax security check!'); 
		}

		$quote_id = isset($_POST['quote_id']) ? sanitize_text_field(wp_unslash($_POST['quote_id'])) : 0;

		if ( ! $quote_id ) {
			wp_send_json_error('Invalid post ID');
		}

		$current_user_id = get_current_user_id();

		$post_author_id = (int) get_post_field('post_author', $quote_id);

		if ( $current_user_id !== $post_author_id ) {
			wp_send_json_error('Unauthorized access');
		}

		$quote_pdf_value = get_option('wc_quote_pdf');

		$template = array( 'bronze', 'darkblue', 'lightblue' );

		if ('custom' == $quote_pdf_value['quote_pdf']) {
			if (in_array($quote_pdf_value['custom'], $template)) {
				$postId = quote_get_postId_by_pdf_template_name($quote_pdf_value['custom']);
				if ($postId) {
						// Fetch the post data
						$post_data = get_post($postId);
						$file_name = sanitize_title($post_data->post_title) . '.pdf';
						$generatePDFContent = quote_generate_pdf($postId, false);
						wp_send_json(array( 'pdf_content' => $generatePDFContent, 'file_name' => $file_name ));
							
				} else {
						die('No Post Found');
				}
				
			}
		}

		$pdf_controller = new PDFService();

		echo esc_url($pdf_controller->process_pdf_print(intval($quote_id)));

		die();
	}

	/**
	 * Build Quote Ajax Handler
	 *
	 * @return void
	 */
	public function wc_quote_build_quote() {
		global $woocommerce;
		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {
			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {
			die('Failed ajax security check!');
		}

		$empty_cart = isset($this->quote_settings['general']['empty_cart']) ? $this->quote_settings['general']['empty_cart'] : '0';
		$posted_data = $_POST;
		$items = $woocommerce->cart->get_cart();

		foreach ( $items as $item => $form_data ) {
			$product_id = isset($form_data['product_id']) ? intval($form_data['product_id']) : '';
			$quantity   = isset($form_data['quantity']) ? intval($form_data['quantity']) : 1;
			$variation_id   = isset($form_data['variation_id']) ? intval($form_data['variation_id']) : 0;
			$variation   = isset($form_data['variation']) ? $form_data['variation'] : array();
			$quote_page = isset($this->quote_settings['general']['quote_page']) ? $this->quote_settings['general']['quote_page'] : '';

			$wc_quote = new QuoteProcess();
			/**
			 * Filter wc_quote_add_to_quote_validation
			 * 
			 * @since 1.0
			**/
			$passed_validation = apply_filters('wc_quote_build_to_quote_validation', true, $product_id, $quantity, $form_data);

			if (!$passed_validation ) {
				echo 'failed';
				die();
			}
	  
			$quote_id = $wc_quote->generate_quote_id($product_id, $variation_id, $variation);

			// Find the quote item key in the existing quote.
			$quote_item_key = $wc_quote->find_product_in_quote($quote_id);
			if ($quote_item_key ) {
				$wc_quote->remove_quote_item($quote_item_key);
			}
			$quote_item_key = $wc_quote->add_to_quote($posted_data, $product_id, $quantity, $variation_id, $variation);

			if (is_user_logged_in() ) {
				wwp_persist_quote_user_meta();
			}

			$quote_contents = wc()->session->get('wc_quotes');
			$product        = '';
			$product_name   = 'Product';

			if (isset($quote_contents[ $quote_item_key ]) ) {
				$product = $quote_contents[ $quote_item_key ]['data'];
			}

			if (is_object($product) ) {
				$product_name = $product->get_name();
			}

			if (false === $quote_item_key ) {
				/* translators: %s: Product name */
				wc_add_notice(sprintf(__('“%s” has not been added to your quote.', 'woocommerce-wholesale-pricing'), $product_name), 'error');
			} else {
				/* translators: %s: Product name */
				wc_add_notice(sprintf(__('“%s” has been added to your quote.', 'woocommerce-wholesale-pricing'), $product_name), 'success');
			}

		}
		/**
		 * Action wc_quote_after_build_quote
		 * 
		 * @since 1.0
		**/
		do_action('wc_quote_after_build_quote');
		if ('1' === $empty_cart ) :
			$woocommerce->cart->empty_cart(); 
		endif;

		echo 'success';
		die();
	}

	/**
	 * Ajax response for insert product row.
	 */
	public function wc_quote_insert_product_row() {
		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {

			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {

			die('Failed ajax security check!');
		}

		$product_id = isset($_POST['product_id']) ? intval(wp_unslash($_POST['product_id'])) : 0;
		$quantity   = isset($_POST['quantity']) ? intval(wp_unslash($_POST['quantity'])) : 0;
		$post_id    = isset($_POST['post_id']) ? intval(wp_unslash($_POST['post_id'])) : 0;

		$post = get_post(intval($post_id));

		if (! $post ) {
			die('post not found');
		}
		$form_data = array();
		$form_data['product_id'] = $product_id;
		$form_data['quantity']   = $quantity;

		$product = wc_get_product($product_id);

		$quote_contents = (array) get_post_meta($post->ID, 'quote_contents', true);
		$wc_quote       = new QuoteProcess($quote_contents);

		$quote_contents = $wc_quote->add_to_quote($form_data, $product_id, $quantity, 0, array(), array(), true);
		if (is_array($quote_contents) ) {

			$quote_totals = $wc_quote->get_calculated_totals($quote_contents);

			update_post_meta($post->ID, 'quote_totals', wp_json_encode($quote_totals));
			update_post_meta($post->ID, 'quote_contents', $quote_contents);
				
			ob_start();

			wwp_view('admin.quote.list.metabox.meta-list-items', compact( 'post' ));

			$quote_table = ob_get_clean();
			
			wp_send_json(
				array(
				'success'             => true,
				'quote-details-table' => $quote_table,
				)
			);

			die();

		} else {

			wp_send_json(
				array(
				'success'  => false,
				/* translators: %s: Product name */
				'message'  => sprintf(__('Quote is not permitted for “%s”.', 'woocommerce-wholesale-pricing'), $product->get_name()),
				)
			);
			die();
		}
	}

	/**
	 * Ajax response for delete product row.
	 */
	public function wc_quote_delete_quote_item() {

		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {

			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {

			die('Failed ajax security check!');
		}

		$quote_item_key = isset($_POST['quote_key']) ? sanitize_text_field(wp_unslash($_POST['quote_key'])) : '';
		$post_id        = isset($_POST['post_id']) ? intval(wp_unslash($_POST['post_id'])) : 0;

		$post = get_post(intval($post_id));

		if (! $post ) {
			die('Quote Item not found');
		}

		$quote_contents = get_post_meta($post->ID, 'quote_contents', true);

		if (isset($quote_contents[ $quote_item_key ]) ) {
			unset($quote_contents[ $quote_item_key ]);
		}

		update_post_meta($post->ID, 'quote_contents', $quote_contents);

		$wc_quote       = new QuoteProcess($quote_contents);
		$quote_contents = get_post_meta($post->ID, 'quote_contents', true);
		$quote_totals   = $wc_quote->get_calculated_totals($quote_contents);

		ob_start();
			
		wwp_view('admin.quote.list.metabox.meta-list-items', compact( 'post' ));
			
		$quote_table = ob_get_clean();

		wp_send_json(
			array(
			'quote-details-table' => $quote_table,
			)
		);

		die();
	}

	/**
	 * Ajax response for save builder schema.
	 */
	public function wc_quote_form_builder_save() {

		if (isset($_POST['nonce']) && ! empty($_POST['nonce']) ) {

			$nonce = sanitize_text_field(wp_unslash($_POST['nonce']));
		} else {
			$nonce = 0;
		}

		if (! wp_verify_nonce($nonce, 'wc-quote-ajax-nonce') ) {

			die('Failed ajax security check!');
		}
		$data = $_POST;
		$builder_schema = isset($data['builder_schema']) ? wp_unslash($data['builder_schema']) : '';
		update_option('wc_quote_form_builder', $builder_schema);

		wp_send_json(
			array(
			'success'  => true,
			'message'  => __('Form Builder fields updated.', 'woocommerce-wholesale-pricing'),
			)
		);

		die();
	}
		
	/**
	 * Reset Quote Counter Ajax Handler
	 *
	 * @return void
	 */
	public function wc_reset_quote_counter() {
		if (check_admin_referer('wc-reset-quote-counter')) {
			$products = wc_get_products(array( 'limit' => -1 ));

			foreach ($products as $product) {
				$product->delete_meta_data('quote_counter');
				$product->save();
			}
		}
		wp_safe_redirect(wp_get_referer() ? wp_get_referer() . '&reset-counter=true' : admin_url('admin.php?page=wc-quote-settings&reset-counter=true'));
		exit;
	}

	public function generate_quote_page() {
		$quote_general = self::get_quote_general_settings();
		if (check_ajax_referer('quote_page_generate', 'nonce')) {
			$page_id = wp_insert_post(array(
				'post_title'   => 'Quote',
				'post_name'    => 'quote',
				'post_status'  => 'publish',
				'post_type'    => 'page',
				'post_content' => '[' . wwp_env()->get('quote_page_shortcode') . ']',
			));

			$quote_general['quote_page'] = $page_id;
			self::update_quote_general_settings($quote_general);

			wp_safe_redirect(wp_get_referer() ? wp_get_referer() : admin_url('admin.php?page=wwp_wholesale_settings'));
			exit;
	
		}
	}

	public function delete_quote_page() {
		if (!check_ajax_referer('quote_page_delete', 'nonce')) {
			wp_die(esc_html__('Security check failed.', 'woocommerce-wholesale-pricing'));
		}

		if (!current_user_can('manage_options')) {
			wp_die(esc_html__('You do not have permission to delete the quote page.', 'woocommerce-wholesale-pricing'));
		}

		$quote_general = self::get_quote_general_settings();
		$page_id       = isset($quote_general['quote_page']) ? (int) $quote_general['quote_page'] : 0;

		if ($page_id > 0 && get_post($page_id)) {
			wp_delete_post($page_id, true);
		}

		$quote_general['quote_page'] = '';
		self::update_quote_general_settings($quote_general);

		wp_safe_redirect(wp_get_referer() ? wp_get_referer() : admin_url('admin.php?page=wwp_wholesale_settings'));
		exit;
	}

	public function wc_quote_update_tax_shipping() {
		$quote_general = get_option('wc_quote_general');
		
		if ( ! isset( $quote_general['custom_tax_shipping'] ) || '1' != $quote_general['custom_tax_shipping'] ) {
			wp_send_json( array( 'success' => false, 'message' => 'Custom tax and shipping is not enabled.' ) );
		}


		if ( ! isset( $_POST['nonce'] ) ) {
			wp_send_json( array( 'success' => false, 'message' => 'Missing nonce.' ) );
		}

		$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );
		if ( ! wp_verify_nonce( $nonce, 'wc-quote-ajax-nonce' ) ) {
			wp_send_json( array( 'success' => false, 'message' => 'Invalid nonce.' ) );
		}

		$post_id = isset( $_POST['post_id'] ) ? intval( wp_unslash( $_POST['post_id'] ) ) : 0;
		if ( $post_id <= 0 ) {
			wp_send_json( array( 'success' => false, 'message' => 'Invalid quote ID.' ) );
		}

		$post = get_post( $post_id );
		if ( ! $post || 'wc-quote' !== $post->post_type ) {
			wp_send_json( array( 'success' => false, 'message' => 'Quote not found.' ) );
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json( array( 'success' => false, 'message' => 'You are not allowed to edit this quote.' ) );
		}

		$shipping_raw = isset( $_POST['shipping_value'] ) ? wp_unslash( sanitize_text_field( $_POST['shipping_value'] ) ) : '';
		$tax_raw      = isset( $_POST['tax_value'] ) ? wp_unslash( sanitize_text_field( $_POST['tax_value'] ) ) : '';

		$shipping_value = ( '' === $shipping_raw ) ? 0 : floatval( $shipping_raw );
		$tax_value      = ( '' === $tax_raw ) ? 0 : floatval( $tax_raw );

		if ( empty( $shipping_value ) && empty( $tax_value ) ) {
			wp_send_json( array( 'success' => false, 'message' => 'Enter valid shipping and tax values.' ) );
		}

		update_post_meta( $post_id, 'quote_content_shipping', $shipping_value );
		update_post_meta( $post_id, 'quote_content_shipping_tax', $tax_value );
		
		update_post_meta( $post_id, '_shipping_tax_manually_updated', true );

		$quote_details_table = '';
		ob_start();
		wwp_view( 'admin.quote.list.metabox.meta-list-items', array( 'post' => $post ) );
		$quote_details_table = ob_get_clean();

		wp_send_json(
			array(
				'success'             => true,
				'quote-details-table' => $quote_details_table,
			)
		);
	}
}
