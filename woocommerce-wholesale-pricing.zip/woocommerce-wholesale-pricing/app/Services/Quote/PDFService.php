<?php
namespace WooCommerceWholesalePricing\App\Services\Quote;

use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;

if (file_exists(WWP_PLUGIN_PATH . '/vendor/autoload.php')) {
	require_once WWP_PLUGIN_PATH . '/vendor/autoload.php';
}

use Dompdf\Dompdf;


class PDFService {


	/**
	 * Contains an object of dompdf.
	 *
	 * @var object
	 */
	public $wc_quote_pdf;

	/**
	 * Contains an array of quote fields.
	 *
	 * @var array
	 */
	public $quote_fields;

	/**
	 * Contains an array of quote settings.
	 *
	 * @var array
	 */
	public $quote_settings;

	/**
	 * Constructor for the WC_QUOTE_PDF_Controller class. Loads quote contents.
	 */

	public function __construct( $quote_id = 0 ) {
		$this->quote_fields = json_decode(get_option('wc_quote_form_builder'), true);
		$this->quote_settings['general'] = get_option('wc_quote_general');
		$this->quote_settings['pdf'] = get_option('wc_quote_pdf');
		$this->wc_quote_pdf = new DOMPDF();
	}

	public function get_pdf_print( $quote_id ) {
		//Close and output PDF document
		$site_name = str_replace(' ', '_', wp_unslash(get_bloginfo('name')));
		$site_name  = str_replace('/', '', $site_name);
		$file_name = wp_unslash($site_name) . '_quote_' . substr(md5($quote_id), 5) . '.pdf';
		$path      = WWP_PLUGIN_PATH . '/public/templates/pdf/pdf-files/';
		if (! file_exists($path) ) {
			wp_mkdir_p($path);
		}
		$output_file = $path . esc_attr($file_name);

		if (file_exists($output_file) ) {
			wp_delete_file($output_file);
		}

		$this->wc_quote_pdf->render();
		$output = $this->wc_quote_pdf->output();
		file_put_contents($output_file, $output);
		$output_file_url = WWP_PLUGIN_URL . '/public/templates/pdf/pdf-files/' . esc_attr($file_name);

		return $output_file_url;
	}

	/**
	 * Get attachment quote pdf file
	 */
	public function get_pdf_attachment( $quote_id ) {

		//Close and output PDF document
		$site_name = str_replace(' ', '_', get_bloginfo('name'));
		$file_name = $site_name . '_quote_' . substr(md5($quote_id), 5) . '.pdf';
		$path      = WWP_PLUGIN_PATH . '/public/templates/pdf/pdf-files/';
		if (! file_exists($path) ) {
			wp_mkdir_p($path);
		}
		$output_file = $path . $file_name;
		if (file_exists($output_file) ) {
			wp_delete_file($output_file);
		}
		$this->wc_quote_pdf->render();
		$output = $this->wc_quote_pdf->output();
		file_put_contents($output_file, $output);
		return $output_file;
	}

	/**
	 * Get quote pdf header
	 */
	public function get_wc_quote_pdf( $quote_id ) {
		$customer_info = $this->get_quote_user_info($quote_id);
		$custom_logo_id = isset($this->quote_settings['pdf']['pdf_logo_id']) ? $this->quote_settings['pdf']['pdf_logo_id'] : '';
		$quote_template = isset($this->quote_settings['pdf']['quote_pdf']) ? $this->quote_settings['pdf']['quote_pdf'] : '';
		$quote_template_value = isset($this->quote_settings['pdf']['custom']) ? $this->quote_settings['pdf']['custom'] : 'image1';
		$price_display    = isset($this->quote_settings['general']['enable_standard']) ? $this->quote_settings['general']['enable_standard'] : '0';
		$display_tax = isset($this->quote_settings['general']['display_tax']) ? $this->quote_settings['general']['display_tax'] : '0';
		$pdf_show_link = isset($this->quote_settings['pdf']['pdf_show_link']) ? $this->quote_settings['pdf']['pdf_show_link'] : '0';
		$image_file = wwp_pdf_image_src( $custom_logo_id );
		$quote_contents = get_post_meta($quote_id, 'quote_contents', true);
		$wc_quote = new QuoteProcess();
		$totals = $wc_quote->get_calculated_totals($quote_contents);
		$quote_subtotal   = isset($totals['_subtotal']) ? $totals['_subtotal'] : 0;
		$offered_subtotal = isset($totals['_offered_total']) ? $totals['_offered_total'] : 0;
		$vat_total        = isset($totals['_tax_total']) ? $totals['_tax_total'] : 0;
		$quote_total      = isset($totals['_total']) ? $totals['_total'] : 0;

		if (empty($quote_contents) || ! is_array($quote_contents) ) {
			return;
		}
		if ('default' === $quote_template ) {

			wwp_view( 'quote.pdf.pdf-default', compact( 'customer_info', 'price_display', 'display_tax', 'pdf_show_link', 'quote_contents', 'quote_subtotal', 'offered_subtotal', 'vat_total', 'quote_total', 'quote_id', 'image_file' ) );

		} else {

			wwp_view( 'quote.pdf.pdf-' . $quote_template_value , compact( 'customer_info', 'price_display', 'display_tax', 'pdf_show_link', 'quote_contents', 'quote_subtotal', 'offered_subtotal', 'vat_total', 'quote_total', 'quote_id', 'image_file' ) );
		 
		}
	}

	/**
	 * Set quote pdf properties
	 */
	public function set_properties( $quote_id ) {

		// set default paper size to A4 portrait

		/**
		 * Filter wc_quote_change_paper_orientation
		 * 
		 * @since 1.0
		**/
		$this->wc_quote_pdf->setPaper('A4', apply_filters('wc_quote_change_paper_orientation', 'portrait'));

		// set default html5 paresr enabled to true

		/**
		 * Filter wc_quote_enable_html5_parser
		 * 
		 * @since 1.0
		**/
		$this->wc_quote_pdf->set_option('enable_html5_parser', apply_filters('wc_quote_enable_html5_parser', true));

		// set default remote images enabled to true

		/**
		 * Filter wc_quote_enable_remote_parser
		 * 
		 * @since 1.0
		**/
		$this->wc_quote_pdf->set_option('isRemoteEnabled', apply_filters('wc_quote_enable_remote_parser', true));
		$this->wc_quote_pdf->set_option(
			'chroot',
			/**
			 * Filter wc_quote_pdf_chroot
			 * 
			 * @since 3.1.0
			 */
			apply_filters(
				'wc_quote_pdf_chroot',
				array(
					ABSPATH,
					WP_CONTENT_DIR,
				)
			)
		);

		// set default dejavu sans font

		/**
		 * Filter wc_quote_default_pdf_font
		 * 
		 * @since 1.0
		**/
		$this->wc_quote_pdf->set_option('defaultFont', apply_filters('wc_quote_default_pdf_font', 'dejavu sans'));
	}

	/**
	 * Process quote pdf for print.
	 */
	public function process_pdf_print( $quote_id ) {
		$pdf_enabled = isset($this->quote_settings['pdf']['enable_pdf']) ? $this->quote_settings['pdf']['enable_pdf'] : '0';
		if ('1' === $pdf_enabled ) :
			$this->set_properties($quote_id);
			ob_start();
			$this->get_wc_quote_pdf($quote_id);
			$html = ob_get_clean();
			$this->wc_quote_pdf->load_html($html, 'UTF-8');
			return $this->get_pdf_print($quote_id);
	 else :
		 return '';
	 endif;
	}

	/**
	 * Process quote pdf for attachment.
	 */
	public function process_pdf_attachment( $quote_id ) {
		$pdf_enabled = isset($this->quote_settings['pdf']['enable_pdf']) ? $this->quote_settings['pdf']['enable_pdf'] : '0';
		if ('1' === $pdf_enabled ) :
			$this->set_properties($quote_id);
			ob_start();
			$this->get_wc_quote_pdf($quote_id);
			$html = ob_get_clean();
			$this->wc_quote_pdf->load_html($html, 'UTF-8');
			return $this->get_pdf_attachment($quote_id);
	 else :
		 return '';
	 endif;
	}

	 
	/**
	 * Load the customer info and extra field data in array.
	 */
	public function get_quote_user_info( $quote_id ) {

		$customer_info = array();
		$quote_date    = date_i18n(get_option('date_format'), get_post_time('U', false, $quote_id, true));

		$quote_expiry_date = get_post_meta($quote_id, 'wc_quote_expire_date', true);
		$quote_expire = isset($this->quote_settings['general']['quote_expire']) ? $this->quote_settings['general']['quote_expire'] : '0';

		$customer_info['quote_id']   = array(
		'label' => __('Quote Number', 'woocommerce-wholesale-pricing'),
		'value' => $quote_id,
		);
		$customer_info['quote_date'] = array(
		'label' => __('Quote Date', 'woocommerce-wholesale-pricing'),
		'value' => $quote_date,
		);

		if ('1' === $quote_expire && !in_array(get_post($quote_id)->post_status, array( 'quote_accepted', 'quote_converted', 'quote_new' )) && !empty($quote_expiry_date) ) :
			$customer_info['quote_expiry_date'] = array(
			'label' => __('Expiration Date', 'woocommerce-wholesale-pricing'),
			'value' => $quote_expiry_date,
			);
		endif;

		$quote_fields = $this->quote_fields;

		if (empty($quote_fields) || !is_array($quote_fields) ) {
			return $customer_info;
		}
		 
		foreach ( $quote_fields['components'] as $key => $field ) {

			$wc_quote_field_name  = $field['key'];
			$wc_quote_field_type  = $field['type'];
			$wc_quote_field_label = $field['label'];
			$field_data        = get_post_meta($quote_id, 'quote_fields', true);
			$field_data = isset($field_data[$wc_quote_field_name]) ? $field_data[$wc_quote_field_name] : '';


			if (is_array($field_data) ) {
				$field_data = implode(', ', $field_data);
			}

			if (in_array($wc_quote_field_type, array( 'select', 'radio', 'mutliselect' ), true) ) {
				$field_data = ucwords($field_data);
			}

			if ('file' ==  $wc_quote_field_type ) {
				$file_data = json_decode($field_data, true);
				$field_data = '';
				foreach ( $file_data as $fkey => $fvalue ) {
					$field_data .= '<a href="' . $fvalue['url'] . '" download="' . $fvalue['name'] . '" target="_blank">' . esc_html__('Download File', 'woocommerce-wholesale-pricing') . '</a>';
				}
			}

			if (!empty($field_data) ) {
				$customer_info[ $wc_quote_field_name ] = array(
				'label' => $wc_quote_field_label,
				'value' => $field_data,
				);
			}   
		 
		}

		return $customer_info;
	}
}
