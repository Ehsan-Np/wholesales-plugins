<?php
namespace WooCommerceWholesalePricing\App\Services\Quote;

use WooCommerceWholesalePricing\App\Modules\Quote\QuoteProcess;


class RequestPageService {

	public function __construct() {
		add_shortcode('wc-quote-request-page', array( $this, 'wc_quote_request_page_shortcode_function' ));
		add_filter('the_content', array( $this, 'wc_quote_add_shortcode_content' ));
		add_filter('woocommerce_is_attribute_in_product_name', array( $this, 'wc_quote_attr' ));
		add_action('wp_loaded', array( $this, 'wc_quote_insert_customer_quote' ));
		add_action('woocommerce_after_main_content', array( $this, 'wc_quote_add_shop_shortcode_content' ));
		add_filter('woocommerce_product_addons_show_grand_total', array( $this, 'hide_price_product_addon' ), 100, 2);
		add_filter('wwp_quantity_min_check', array( $this, 'wc_quote_override_wholesale_qty' ), 400, 4);
		add_filter('body_class', array( $this, 'wc_quote_add_class' ));
	}
		
	/**
	 * Quote request page shortcode
	 *
	 * @return void
	 */
	public function wc_quote_request_page_shortcode_function() {
		ob_start();
		wwp_view( 'quote.request-quote-page', array() );
		return ob_get_clean();
	}

	// Add quote request page in content of page selected in general
	public function wc_quote_add_shortcode_content( $content ) {
		$quote_page = isset(get_option('wc_quote_general', false)['quote_page']) ? get_option('wc_quote_general', false)['quote_page'] : '';

		if (get_the_ID() === (int) $quote_page && false !== strpos($content, '[wc-quote-request-page]')) {
			return $content;
		} elseif (get_the_ID() === (int) $quote_page) {
			ob_start();
			wwp_view( 'quote.request-quote-page', array() );
			$additional_content = ob_get_clean();
			return $content . $additional_content;
		}
		return $content;
	}

	/**
	 * For showing variations on quote list
	 *
	 * @return void
	 */
	public function wc_quote_attr() {
		return false;
	}

	public function wc_quote_insert_customer_quote() {

		if (isset($_POST['wc_quote_action']) ) {
			
			check_ajax_referer('save_wcquote', 'wc_quote_nonce');
			$data = (array) sanitize_meta('', wp_unslash($_POST), '');

			$wc_quote = new QuoteProcess();

			$wc_quote->insert_new_quote(array_merge($data, (array) $_FILES));
		}
	}

	public function wc_quote_add_shop_shortcode_content() {
		$quote_page = isset(get_option('wc_quote_general', false)['quote_page']) ? get_option('wc_quote_general', false)['quote_page'] : '';
		if (is_shop() && get_option('woocommerce_shop_page_id', true) == (int) $quote_page ) {
			echo do_shortcode('[wc-quote-request-page]'); 
		}
	}

	public function hide_price_product_addon( $visible, $product ) {

		foreach ( get_quote_rules() as $rule ) {

			$quote_rules = get_post_meta($rule->ID, 'wc_quote_rules', true);
			$hide_price = isset($quote_rules['hide_price']) ? $quote_rules['hide_price'] : '0';

			if (!quote_check_rule_for_product($product->get_id(), $rule->ID) ) {
				continue;
			}

			if ('1' === $hide_price ) {
				return false;
			}
		}

		return $visible;
	}

	public function wc_quote_override_wholesale_qty( $check, $qty, $wholesale_qty, $product ) {

		if ( is_shop() ) {
			return false;
		}

		$url     = wp_get_referer();
		$post_id = 0 !== get_queried_object_id() ? get_queried_object_id() : url_to_postid($url);
		$quote_contents = isset(WC()->session) ? WC()->session->get('wc_quotes') : get_post_meta(get_the_ID(), 'quote_contents', true);
		$quote_page = isset(get_option('wc_quote_general', false)['quote_page']) ? get_option('wc_quote_general', false)['quote_page'] : '';
		$post_content = isset(get_post($post_id)->post_content) ? get_post($post_id)->post_content : '';
		$quote_id = isset($_REQUEST['post_id']) ? sanitize_text_field($_REQUEST['post_id']) : get_the_ID();

		if (
			( 
				!empty($quote_contents) 
				&& 
				$post_id === (int) $quote_page
			) 
			|| 
			( 
				!empty($quote_contents) 
				&& 
				has_shortcode($post_content, 'wc-quote-request-page') 
			) 
			|| 
			( 
				!empty($quote_contents) 
				&& 
				get_post_type($quote_id) === 'wc-quote' 
			) 
			|| 
			( 
				!empty($quote_contents) 
				&& 
				isset($_REQUEST['action']) 
				&& 
				'wcquote_add_to_quote' === sanitize_text_field($_REQUEST['action']) 
			) 
			|| 
			( 
				isset( $_REQUEST['action'] )
				&&
				(
					'wcquote_add_to_quote_single' === sanitize_text_field($_REQUEST['action']) 
					|| 
					'wcquote_add_to_quote_variable' === sanitize_text_field($_REQUEST['action']) 
					|| 
					'wcquote_update_quote_items' === sanitize_text_field($_REQUEST['action']) 
				)
			) 
		) :
			foreach ( (array) $quote_contents as $quote_item_key => $quote_item ) {

				if (isset($quote_item['data']) ) {

					$_product = $quote_item['data'];

				} else {

					continue;
				}

				if (! is_object($_product) ) {
						continue;
				}

				if ($product->get_id() === $_product->get_id() ) {

					$qty = $quote_item['quantity'];
					if ('' != $qty && $qty < $wholesale_qty ) {
						return true;
					}
				}
			}
		endif;
		
		return false;
	}

	/**
	 * For adding cart class on quote page
	 *
	 * @param  mixed $classes
	 * @return void
	 */
	public function wc_quote_add_class( $classes ) {
		$url     = wp_get_referer();
		$post_id = 0 !== get_queried_object_id() ? get_queried_object_id() : url_to_postid($url);
		$quote_page = isset(get_option('wc_quote_general', false)['quote_page']) ? get_option('wc_quote_general', false)['quote_page'] : '';
		$post_content = isset(get_post($post_id)->post_content) ? get_post($post_id)->post_content : '';
		if ($post_id === (int) $quote_page || has_shortcode($post_content, 'wc-quote-request-page') ) :
			$classes[] = 'woocommerce-cart';
			$classes[] = 'woocommerce-page';
			$classes[] = 'woocommerce-quote';
		endif;
		return $classes;
	}
}
