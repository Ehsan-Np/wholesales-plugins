<?php
/**
 * QuoteService
 *
 * This class is the primary registration point for all quote-related
 * functionality on the frontend and administrative sides of the store. It determines
 * if the current user (logged in or guest) is eligible for quote features
 * and, if so, loads the necessary quote modules (e.g., pricing, cart, shipping).
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services\Quote;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

use WooCommerceWholesalePricing\App\Modules\Quote\CartService;
use WooCommerceWholesalePricing\App\Modules\Quote\CheckoutService;
use WooCommerceWholesalePricing\App\Modules\Quote\HidePrice;
use WooCommerceWholesalePricing\App\Modules\Quote\MyAccountService;
use WooCommerceWholesalePricing\App\Modules\Quote\ProductService;
use WooCommerceWholesalePricing\App\Modules\Quote\ShopService;
use WooCommerceWholesalePricing\App\Modules\Quote\QuoteBasketService;
use WooCommerceWholesalePricing\App\Modules\Quote\Admin\OrderHandler;

/**
 * QuoteService
 *
 * Initializes and manages all core quote application modules based on
 * user status and global quote settings.
 *
 * @implements ServiceInterface
 */
class QuoteService implements ServiceInterface {


	/**
	 * Trait that provides static access to wholesale pricing settings.
	 */
	use WholesaleSettings;

	/**
	 * QuoteService constructor.
	 *
	 * Initializes the service by calling the parent constructor.
	 */
	public function __construct() {
		$this->includeQuoteFunctionality();
	}
	/**
	 * Initializes all necessary wholesale modules.
	 *
	 * This method is only called if the current user is confirmed to be a wholesaler
	 * (or is a guest with active wholesale pricing/restrictions). It instantiates
	 * the core modules required for wholesale operations.
	 *
	 * @return void
	 */
	public static function includeQuoteFunctionality() {
		new CartService();
		new CheckoutService();
		new HidePrice();
		new MyAccountService();
		new ProductService();
		new ShopService();
		new QuoteBasketService();
		new OrderHandler();
	}

	/**
	 * Determines whether this service should be initialized.
	 *
	 * This service is essential for both frontend and backend operations, so it
	 * is always resolved to true.
	 *
	 * @return bool Always true.
	 */
	public static function resolveDependency() {
		$settings = self::get_pricing_settings();
		return ( isset( $settings['enable_quote'] ) && 'yes' === $settings['enable_quote'] );
	}   
}
