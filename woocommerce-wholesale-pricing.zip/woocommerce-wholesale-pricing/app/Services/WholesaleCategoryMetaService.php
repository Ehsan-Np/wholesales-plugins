<?php
/**
 * Programmatic read/write of wholesale product category meta.
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\RoleDiscountPatchNormalizer;

/**
 * Manages wholesale-specific product category metadata for the AI abilities API.
 */
class WholesaleCategoryMetaService {

	/**
	 * Get the wholesale role taxonomy slug, using wwp_env() if available.
	 * 
	 * @return string
	 */
	private function get_role_taxonomy() {
		if ( function_exists( 'wwp_env' ) ) {
			$slug = (string) wwp_env()->get( 'role_taxonomy' );
			if ( '' !== $slug ) {
				return $slug;
			}
		}

		return 'wholesale_user_roles';
	}

	/**
	 * Resolve a category term by ID, returning an error if not found.
	 * 
	 * @param int $term_id Category term ID.
	 * @return \WP_Term|\WP_Error
	 */
	private function resolve_term( $term_id ) {
		$term = get_term( $term_id, 'product_cat' );
		if ( ! $term || is_wp_error( $term ) ) {
			return new \WP_Error(
				'wwp_category_not_found',
				__( 'Product category not found.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 404 )
			);
		}

		return $term;
	}

	/**
	 * Get formatted wholesale settings for a category.
	 *
	 * @param int $term_id Category term ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function get_wholesale_settings( $term_id ) {
		$term = $this->resolve_term( $term_id );
		if ( is_wp_error( $term ) ) {
			return $term;
		}

		return $this->format_settings( $term_id );
	}

	/**
	 * Update wholesale settings (partial merge).
	 *
	 * @param int                  $term_id   Category term ID.
	 * @param array<string, mixed> $wholesale Wholesale patch.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_wholesale_settings( $term_id, array $wholesale ) {
		$term = $this->resolve_term( $term_id );
		if ( is_wp_error( $term ) ) {
			return $term;
		}

		if ( empty( $wholesale ) ) {
			return $this->get_wholesale_settings( $term_id );
		}

		if ( array_key_exists( 'hide_for_roles', $wholesale ) ) {
			$roles = is_array( $wholesale['hide_for_roles'] ) ? array_map( 'sanitize_key', $wholesale['hide_for_roles'] ) : array();
			update_term_meta( $term_id, 'wholesale_product_visibility_multi', $roles );
		}

		if ( array_key_exists( 'hide_for_non_wholesale', $wholesale ) ) {
			$value = ! empty( $wholesale['hide_for_non_wholesale'] ) ? array( 'yes' ) : '';
			update_term_meta( $term_id, 'wholesale_product_visibility_multi_customer', $value );
		}

		if ( array_key_exists( 'tier_pricing', $wholesale ) ) {
			update_term_meta( $term_id, 'category_tier_pricing', is_array( $wholesale['tier_pricing'] ) ? wwp_sanitize_tier_prices( $wholesale['tier_pricing'] ) : array() );
		}

		if ( isset( $wholesale['role_pricing'] ) && is_array( $wholesale['role_pricing'] ) ) {
			$result = $this->apply_role_pricing( $term_id, $wholesale['role_pricing'] );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		return $this->get_wholesale_settings( $term_id );
	}

	/**
	 * Snapshot wholesale meta for undo.
	 *
	 * @param int $term_id Category term ID.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function snapshot_wholesale_settings( $term_id ) {
		$term = $this->resolve_term( $term_id );
		if ( is_wp_error( $term ) ) {
			return $term;
		}

		return array(
			'term_id' => $term_id,
			'raw'     => array(
				'wholesale_multi_user_pricing'              => get_term_meta( $term_id, 'wholesale_multi_user_pricing', true ),
				'wholesale_product_visibility_multi'          => get_term_meta( $term_id, 'wholesale_product_visibility_multi', true ),
				'wholesale_product_visibility_multi_customer' => get_term_meta( $term_id, 'wholesale_product_visibility_multi_customer', true ),
				'category_tier_pricing'                     => get_term_meta( $term_id, 'category_tier_pricing', true ),
			),
		);
	}

	/**
	 * Restore wholesale meta from snapshot.
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_wholesale_settings( array $snapshot ) {
		$term_id = (int) ( isset( $snapshot['term_id'] ) ? $snapshot['term_id'] : 0 );
		$raw     = is_array( isset( $snapshot['raw'] ) ? $snapshot['raw'] : null ) ? $snapshot['raw'] : array();

		if ( $term_id <= 0 ) {
			return new \WP_Error(
				'wwp_category_restore_invalid',
				__( 'Cannot restore category wholesale settings: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$term = $this->resolve_term( $term_id );
		if ( is_wp_error( $term ) ) {
			return $term;
		}

		foreach ( $raw as $key => $value ) {
			update_term_meta( $term_id, $key, $value );
		}

		return true;
	}

	/**
	 * Format stored wholesale settings for a category into a structured array.
	 * 
	 * @param int $term_id Category term ID.
	 * @return array<string, mixed>
	 */
	private function format_settings( $term_id ) {
		$stored   = get_term_meta( $term_id, 'wholesale_multi_user_pricing', true );
		$hide     = get_term_meta( $term_id, 'wholesale_product_visibility_multi', true );
		$non_wholesale = get_term_meta( $term_id, 'wholesale_product_visibility_multi_customer', true );
		$tier     = get_term_meta( $term_id, 'category_tier_pricing', true );

		if ( ! is_array( $hide ) ) {
			$hide = empty( $hide ) ? array() : array( (string) $hide );
		}

		return array(
			'hide_for_roles'          => array_values( array_map( 'strval', $hide ) ),
			'hide_for_non_wholesale'  => is_array( $non_wholesale ) && in_array( 'yes', $non_wholesale, true ),
			'tier_pricing'            => is_array( $tier ) ? $tier : array(),
			'role_pricing'            => $this->format_role_pricing( is_array( $stored ) ? $stored : array() ),
		);
	}

	/**
	 * Format stored role pricing into a list of role entries.
	 * 
	 * @param array<int, array<string, mixed>> $stored Stored pricing by term_id.
	 * @return list<array<string, mixed>>
	 */
	private function format_role_pricing( array $stored ) {
		$roles     = get_terms( array( 'taxonomy' => $this->get_role_taxonomy(), 'hide_empty' => false ) );
		$formatted = array();

		if ( is_wp_error( $roles ) || empty( $roles ) ) {
			return $formatted;
		}

		foreach ( $roles as $role_term ) {
			$term_id = (int) $role_term->term_id;
			$entry   = array(
				'role_slug' => (string) $role_term->slug,
				'enabled'   => isset( $stored[ $term_id ] ),
			);

			if ( isset( $stored[ $term_id ] ) && is_array( $stored[ $term_id ] ) ) {
				$row = $stored[ $term_id ];
				$entry['discount_type']   = (string) ( isset( $row['discount_type'] ) ? $row['discount_type'] : 'percent' );
				$entry['wholesale_price'] = isset( $row['wholesale_price'] ) ? (string) $row['wholesale_price'] : '';
				$entry['min_quantity']    = isset( $row['min_quatity'] ) ? (int) $row['min_quatity'] : ( isset( $row['min_quantity'] ) ? (int) $row['min_quantity'] : 1 );
				$entry['step_quantity']   = isset( $row['step_quantity'] ) ? (string) $row['step_quantity'] : '';
			}

			$formatted[] = $entry;
		}

		return $formatted;
	}

	/**
	 * Apply role pricing patch to a category.
	 * 
	 * @param int                  $term_id      Category term ID.
	 * @param list<array<string,mixed>> $role_pricing Role pricing patch.
	 * @return true|\WP_Error
	 */
	private function apply_role_pricing( $term_id, array $role_pricing ) {
		$stored   = get_term_meta( $term_id, 'wholesale_multi_user_pricing', true );
		$stored   = is_array( $stored ) ? $stored : array();
		$slug_map = $this->get_role_slug_map();

		foreach ( $role_pricing as $item ) {
			if ( ! is_array( $item ) || empty( $item['role_slug'] ) ) {
				continue;
			}

			$slug    = sanitize_key( (string) $item['role_slug'] );
			$role_id = isset( $slug_map[ $slug ] ) ? $slug_map[ $slug ] : 0;
			if ( $role_id <= 0 ) {
				return new \WP_Error(
					'wwp_category_invalid_role',
					sprintf(
						/* translators: %s: role slug */
						__( 'Unknown wholesale role slug: %s', 'woocommerce-wholesale-pricing' ),
						$slug
					),
					array( 'status' => 400 )
				);
			}

			$existing_row = isset( $stored[ $role_id ] ) && is_array( $stored[ $role_id ] ) ? $stored[ $role_id ] : array();
			$item         = RoleDiscountPatchNormalizer::prune_role_discount_item( $item, $existing_row );

			if ( array_key_exists( 'enabled', $item ) && ! $this->is_enabled_value( $item['enabled'] ) ) {
				unset( $stored[ $role_id ] );
				continue;
			}

			$explicit_enable = array_key_exists( 'enabled', $item ) && $this->is_enabled_value( $item['enabled'] );
			$has_fields      = $explicit_enable
				|| isset( $item['discount_type'] )
				|| array_key_exists( 'wholesale_price', $item )
				|| isset( $item['min_quantity'] )
				|| array_key_exists( 'step_quantity', $item );

			if ( ! $has_fields ) {
				continue;
			}

			$is_new_row = empty( $existing_row );
			$row        = $is_new_row ? array() : $existing_row;

			if ( $is_new_row ) {
				$row = $this->apply_role_entry_defaults( $row, $item );
			}

			if ( isset( $item['discount_type'] ) ) {
				$type = sanitize_key( (string) $item['discount_type'] );
				if ( ! in_array( $type, array( 'percent', 'fixed' ), true ) ) {
					return new \WP_Error(
						'wwp_category_invalid_discount_type',
						__( 'discount_type must be percent or fixed.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$row['discount_type'] = $type;
			}
			if ( array_key_exists( 'wholesale_price', $item ) ) {
				$row['wholesale_price'] = wwp_sanitize_price( $item['wholesale_price'] );
			}
			if ( isset( $item['min_quantity'] ) ) {
				$row['min_quatity'] = (string) max( 1, (int) $item['min_quantity'] );
			}
			if ( array_key_exists( 'step_quantity', $item ) ) {
				$step = $item['step_quantity'];
				$row['step_quantity'] = is_numeric( $step ) ? (string) $step : '';
			}

			$stored[ $role_id ] = $this->format_role_row_for_storage( $row, $slug );
		}

		update_term_meta( $term_id, 'wholesale_multi_user_pricing', $stored );

		return true;
	}

	/**
	 * Apply admin-style defaults for a new category role pricing row.
	 *
	 * @param array<string, mixed> $entry Existing role row.
	 * @param array<string, mixed> $item  Incoming patch.
	 * @return array<string, mixed>
	 */
	private function apply_role_entry_defaults( array $entry, array $item ) {
		if ( ! isset( $entry['discount_type'] ) && ! isset( $item['discount_type'] ) ) {
			$entry['discount_type'] = 'percent';
		}

		if ( ! isset( $entry['min_quatity'] ) && ! isset( $item['min_quantity'] ) ) {
			$entry['min_quatity'] = '1';
		}

		if ( ! array_key_exists( 'wholesale_price', $entry ) && ! array_key_exists( 'wholesale_price', $item ) ) {
			$entry['wholesale_price'] = '';
		}

		if ( ! array_key_exists( 'step_quantity', $entry ) && ! array_key_exists( 'step_quantity', $item ) ) {
			$entry['step_quantity'] = '';
		}

		return $entry;
	}

	/**
	 * Match admin category save shape.
	 *
	 * @param array<string, mixed> $row  Role row.
	 * @param string               $slug Role slug.
	 * @return array<string, mixed>
	 */
	private function format_role_row_for_storage( array $row, $slug ) {
		$discount_type = isset( $row['discount_type'] ) ? sanitize_key( (string) $row['discount_type'] ) : 'percent';
		if ( ! in_array( $discount_type, array( 'percent', 'fixed' ), true ) ) {
			$discount_type = 'percent';
		}

		$wholesale_price = array_key_exists( 'wholesale_price', $row ) ? $row['wholesale_price'] : '';
		$wholesale_price = wwp_sanitize_price( $wholesale_price );

		$min_quatity = isset( $row['min_quatity'] ) ? $row['min_quatity'] : '1';
		$min_quatity = is_numeric( $min_quatity ) ? (string) max( 1, (int) $min_quatity ) : '1';

		$stored = array(
			'slug'            => $slug,
			'discount_type'   => $discount_type,
			'wholesale_price' => $wholesale_price,
			'min_quatity'     => $min_quatity,
		);

		if ( array_key_exists( 'step_quantity', $row ) ) {
			$step = $row['step_quantity'];
			$stored['step_quantity'] = is_numeric( $step ) ? (string) $step : (string) $step;
		}

		return $stored;
	}

	/**
	 * Whether a value represents an enabled flag.
	 *
	 * @param mixed $value Enabled flag.
	 * @return bool
	 */
	private function is_enabled_value( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_numeric( $value ) ) {
			return (int) 1 === (int) $value;
		}

		if ( is_string( $value ) ) {
			return in_array( strtolower( trim( $value ) ), array( '1', 'true', 'yes', 'on' ), true );
		}

		return false;
	}

	/**
	 * Get a map of wholesale role slugs to term IDs.
	 * 
	 * @return array<string, int>
	 */
	private function get_role_slug_map() {
		$terms = get_terms( array( 'taxonomy' => $this->get_role_taxonomy(), 'hide_empty' => false ) );
		$map   = array();

		if ( is_wp_error( $terms ) ) {
			return $map;
		}

		foreach ( $terms as $term ) {
			$map[ $term->slug ] = (int) $term->term_id;
		}

		return $map;
	}
}
