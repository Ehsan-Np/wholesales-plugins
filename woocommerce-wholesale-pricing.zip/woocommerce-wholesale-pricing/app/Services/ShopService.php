<?php
/**
 * ShopService
 *
 * This service class is responsible for managing the display of prices and the
 * "Add to Cart" button across the WooCommerce shop based on the wholesale
 * pricing settings configured for specific products, categories, or user roles.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * ShopService
 *
 * Implements the core logic for conditionally hiding product prices and purchase
 * buttons on the frontend shop and single product pages.
 *
 * @implements ServiceInterface
 */
class ShopService implements ServiceInterface {

	/**
	 * Trait that provides static access to wholesale pricing settings.
	 */
	use WholesaleSettings;

	/**
	 * Track whether add-to-cart hide CSS has already been printed.
	 *
	 * @var bool
	 */
	private $native_cart_button_css_printed = false;

	/**
	 * ShopService constructor.
	 *
	 * Registers all necessary actions and filters to control the visibility of
	 * the "Add to Cart" button and the product price.
	 */
	public function __construct() {
		// Control 'Add to Cart' button visibility on shop/loop pages
		add_filter('woocommerce_loop_add_to_cart_link', array( $this, 'add_to_cart_button_visibility_shop' ), 10, 3);

		// Control 'Add to Cart' button visibility on single product pages (simple products)
		add_action('woocommerce_single_product_summary', array( $this, 'add_to_cart_button_visibility' ), 10);

		// Control 'Add to Cart' button visibility on variable product pages
		add_action('woocommerce_variable_add_to_cart', array( $this, 'add_to_cart_button_visibility' ), 10);

		// Control Elementor WooCommerce Add to Cart widget output.
		add_filter('elementor/widget/render_content', array( $this, 'elementor_add_to_cart_widget_visibility' ), 10, 2);

		// Controls product purchasability, primarily used by the Pre-orders extension
		// add_filter('woocommerce_is_purchasable', array( $this, 'preorder_is_purchasable' ), 10, 2);

		// Filter to hide price HTML on standard products (priority 210 to run late)
		add_filter('woocommerce_get_price_html', array( $this, 'hide_price_shop' ), 210, 2);

		// Filter to hide price HTML on subscription products (priority 210 to run late)
		add_filter('woocommerce_subscriptions_product_price_string', array( $this, 'hide_price_for_sub_product' ), 210, 3);
	}

	/**
	 * Conditionally hides the 'Add to Cart' button on the main shop and product loop pages.
	 *
	 * Hiding logic is based on global settings targeting specific products, categories, or user roles.
	 * If hidden, it adds an action to display a custom message instead.
	 *
	 * @param  string      $class   The original 'Add to Cart' button HTML.
	 * @param  \WC_Product $product The product object.
	 * @param  array       $args    Arguments passed to the filter (not used directly here).
	 * @return string|false The original HTML string or boolean false to hide the button.
	 */
	public function add_to_cart_button_visibility_shop( $class, $product, $args = array() ) {
		$settings = self::get_pricing_settings();
		/**
		 * Filter Hook: wwp_hide_cart_button_on_shop
		 * Allows bypassing the visibility check on shop loops.
		 *
		 * @since 2.7.0
		 *
		 * @param bool $pass True to bypass, false to proceed with visibility checks.
		 * @param string $class The original add to cart link HTML.
		 * @param \WC_Product $product The product object.
		 */
		$pass = apply_filters('wwp_hide_cart_button_on_shop', false, $class, $product);
		if ($pass ) {
			return $class;
		}

		if (isset($settings['wwp_hide_add_to_cart']) && 'yes' === $settings['wwp_hide_add_to_cart'] ) {

			$hide_on = isset($settings['wwp_hide_add_to_cart_on']) ? $settings['wwp_hide_add_to_cart_on'] : '';
			if ('specific_product' === $hide_on ) {
				$specific_products = isset($settings['wwp_specific_product']) ? $settings['wwp_specific_product'] : array();

				if (in_array($product->get_id(), $specific_products) ) {
					add_action('woocommerce_after_shop_loop_item', array( $this, 'display_custom_message' ), 20);
					return false;
				}
			} elseif ('specific_product_cat' === $hide_on ) {
				$specific_categories = isset($settings['wwp_specific_cat']) ? $settings['wwp_specific_cat'] : array();
				
				$product_categories = wp_get_post_terms($product->get_id(), 'product_cat', array( 'fields' => 'ids' ));
				
				if (! empty(array_intersect($product_categories, $specific_categories)) ) {
					add_action('woocommerce_after_shop_loop_item', array( $this, 'display_custom_message' ), 20);
					return false;
				}
			} elseif ('specific_user_roles' === $hide_on ) {
				$specific_user_roles = isset($settings['wwp_specific_user_role']) ? $settings['wwp_specific_user_role'] : array();
				if ( $this->matches_selected_user_roles( $specific_user_roles ) ) {
					add_action('woocommerce_after_shop_loop_item', array( $this, 'display_custom_message' ), 20);
					return false;
				}
			}
		}

		return $class;
	}

	/**
	 * Conditionally removes the default 'Add to Cart' button from the single product page.
	 *
	 * This method removes the default button hook and adds a hook to display a
	 * custom message based on global settings targeting specific products,
	 * categories, or user roles.
	 *
	 * @global \WC_Product $product
	 * @return void
	 */
	public function add_to_cart_button_visibility() {

		global $product;
		
		if (! $product ) {
			return;
		}

		$settings =  self::get_pricing_settings();

		/**
		 * Filter Hook: wwp_hide_cart_button_on_single_page
		 * Allows bypassing the visibility check on the single product page.
		 *
		 * @since 2.7.0
		 *
		 * @param bool $pass True to bypass, false to proceed with visibility checks.
		 * @param \WC_Product $product The product object.
		 */
		$pass = apply_filters('wwp_hide_cart_button_on_single_page', false, $product);
		if ($pass ) {
			return;
		}

		if (isset($settings['wwp_hide_add_to_cart']) && 'yes' === $settings['wwp_hide_add_to_cart'] ) {
			$hide_on = isset($settings['wwp_hide_add_to_cart_on']) ? $settings['wwp_hide_add_to_cart_on'] : '';
			if ('specific_product' === $hide_on ) {
				$specific_products = isset($settings['wwp_specific_product']) ? $settings['wwp_specific_product'] : array();

				if (in_array($product->get_id(), $specific_products) ) {
					$preserve_quantity_for_quote = $this->should_preserve_quantity_for_quote( $product );

					if ('variable' === $product->get_type() ) {
						if ( $preserve_quantity_for_quote ) {
							add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'hide_native_add_to_cart_button' ), 1 );
						} else {
							add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'suppress_cart_button_start' ), 10 );
							add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'suppress_cart_button_end' ), 1  );
						}
						add_action('woocommerce_single_variation', array( $this, 'display_custom_message' ), 30);
					} else {
						if ( $preserve_quantity_for_quote ) {
							add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'hide_native_add_to_cart_button' ), 1 );
						} else {
							add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'suppress_cart_button_start' ), 10 );
							add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'suppress_cart_button_end' ), 1  );
						}

						add_action('woocommerce_single_product_summary', array( $this, 'display_custom_message' ), 31);
					}
				}
			} elseif ('specific_product_cat' === $hide_on ) {
				$specific_categories = isset($settings['wwp_specific_cat']) ? $settings['wwp_specific_cat'] : array();

				$product_categories = wp_get_post_terms($product->get_id(), 'product_cat', array( 'fields' => 'ids' ));

				if (! empty(array_intersect($product_categories, $specific_categories)) ) {
					$preserve_quantity_for_quote = $this->should_preserve_quantity_for_quote( $product );
					if ('variable' === $product->get_type() ) {
						if ( $preserve_quantity_for_quote ) {
							add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'hide_native_add_to_cart_button' ), 1 );
						} else {
							add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'suppress_cart_button_start' ), 10 );
							add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'suppress_cart_button_end' ), 1  );
						}
						add_action('woocommerce_single_variation', array( $this, 'display_custom_message' ), 30);
					} else {
						if ( $preserve_quantity_for_quote ) {
							add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'hide_native_add_to_cart_button' ), 1 );
						} else {
							add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'suppress_cart_button_start' ), 10 );
							add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'suppress_cart_button_end' ), 1  );
						}
						add_action('woocommerce_single_product_summary', array( $this, 'display_custom_message' ), 31);
					}
				}
			} elseif ('specific_user_roles' === $hide_on ) {
				$specific_user_roles = isset($settings['wwp_specific_user_role']) ? $settings['wwp_specific_user_role'] : array();
				if ( $this->matches_selected_user_roles( $specific_user_roles ) ) {
					$preserve_quantity_for_quote = $this->should_preserve_quantity_for_quote( $product );
					if ('variable' === $product->get_type() ) {
						if ( $preserve_quantity_for_quote ) {
							add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'hide_native_add_to_cart_button' ), 1 );
						} else {
							add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'suppress_cart_button_start' ), 10 );
							add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'suppress_cart_button_end' ), 1  );
						}
						add_action('woocommerce_single_variation', array( $this, 'display_custom_message' ), 30);
					} else {
						if ( $preserve_quantity_for_quote ) {
							add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'hide_native_add_to_cart_button' ), 1 );
						} else {
							add_action( 'woocommerce_before_add_to_cart_button', array( $this, 'suppress_cart_button_start' ), 10 );
							add_action( 'woocommerce_after_add_to_cart_button', array( $this, 'suppress_cart_button_end' ), 1  );
						}
						add_action('woocommerce_single_product_summary', array( $this, 'display_custom_message' ), 31);
					}
				}
			}
		}
	}

	/**
	 * Hide Elementor WooCommerce Add to Cart widget when plugin settings require it.
	 *
	 * @param  string                   $widget_content Rendered widget HTML.
	 * @param  \Elementor\Widget_Base   $widget         Elementor widget instance.
	 * @return string
	 */
	public function elementor_add_to_cart_widget_visibility( $widget_content, $widget ) {
		if ( ! is_object( $widget ) || ! method_exists( $widget, 'get_name' ) || 'woocommerce-product-add-to-cart' !== $widget->get_name() ) {
			return $widget_content;
		}

		$product = $this->get_elementor_widget_product( $widget );
		if ( ! $product ) {
			return $widget_content;
		}

		/**
		 * Filter Hook: wwp_hide_cart_button_on_single_page
		 * Allows bypassing the visibility check on the single product page.
		 *
		 * @since 2.7.0
		 *
		 * @param bool $pass True to bypass, false to proceed with visibility checks.
		 * @param \WC_Product $product The product object.
		 */
		$pass = apply_filters('wwp_hide_cart_button_on_single_page', false, $product);
		if ( $pass ) {
			return $widget_content;
		}

		if ( ! $this->should_hide_add_to_cart_for_product( $product ) ) {
			return $widget_content;
		}

		$settings = self::get_pricing_settings();
		$message  = ! empty( $settings['custom_message_for_cart'] ) ? wp_kses_post( $settings['custom_message_for_cart'] ) : '';

		return $message;
	}

	/**
	 * Resolve the product associated with an Elementor Add to Cart widget.
	 *
	 * @param  \Elementor\Widget_Base $widget Elementor widget instance.
	 * @return \WC_Product|false
	 */
	private function get_elementor_widget_product( $widget ) {
		$product_id = get_the_ID();

		if ( method_exists( $widget, 'get_settings_for_display' ) ) {
			$settings = $widget->get_settings_for_display();
			if ( ! empty( $settings['product_id'] ) ) {
				$product_id = absint( $settings['product_id'] );
			}
		}

		$product = wc_get_product( $product_id );

		return $product ? $product : false;
	}

	/**
	 * Whether add to cart should be hidden for a product based on plugin settings.
	 *
	 * @param  \WC_Product $product Product object.
	 * @return bool
	 */
	private function should_hide_add_to_cart_for_product( $product ) {
		$settings = self::get_pricing_settings();

		if ( ! isset( $settings['wwp_hide_add_to_cart'] ) || 'yes' !== $settings['wwp_hide_add_to_cart'] ) {
			return false;
		}

		$hide_on = isset( $settings['wwp_hide_add_to_cart_on'] ) ? $settings['wwp_hide_add_to_cart_on'] : '';

		if ( 'specific_product' === $hide_on ) {
			$specific_products = isset( $settings['wwp_specific_product'] ) ? $settings['wwp_specific_product'] : array();

			return in_array( $product->get_id(), $specific_products, true );
		}

		if ( 'specific_product_cat' === $hide_on ) {
			$specific_categories = isset( $settings['wwp_specific_cat'] ) ? $settings['wwp_specific_cat'] : array();
			$product_categories  = wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'ids' ) );

			return ! empty( array_intersect( $product_categories, $specific_categories ) );
		}

		if ( 'specific_user_roles' === $hide_on ) {
			$specific_user_roles = isset( $settings['wwp_specific_user_role'] ) ? $settings['wwp_specific_user_role'] : array();
			return $this->matches_selected_user_roles( $specific_user_roles );
		}

		return false;
	}

	/**
	 * Filters the `woocommerce_is_purchasable` property to hide the purchase
	 * functionality based on plugin settings.
	 *
	 * This is especially useful for compatibility with extensions like WooCommerce Pre-Orders.
	 *
	 * @param  bool        $is_purchasable Current purchasability status.
	 * @param  \WC_Product $product        The product object.
	 * @return bool True if purchasable, false otherwise.
	 */
	public function preorder_is_purchasable( $is_purchasable, $product ) {

		$settings = self::get_pricing_settings();
		/**
		 * Filter Hook: wwp_is_purchasable_hide
		 * Allows bypassing the purchasability check.
		 *
		 * @since 2.7.0
		 *
		 * @param bool $pass True to bypass, false to proceed with visibility checks.
		 * @param bool $is_purchasable The current purchasability status.
		 */
		$pass = apply_filters('wwp_is_purchasable_hide', false, $is_purchasable);
		if ($pass ) {
			return $is_purchasable;
		}
		if (isset($settings['wwp_hide_add_to_cart']) && 'yes' === $settings['wwp_hide_add_to_cart'] ) {

			$hide_on = isset($settings['wwp_hide_add_to_cart_on']) ? $settings['wwp_hide_add_to_cart_on'] : '';
			if ('specific_product' === $hide_on ) {
				$specific_products = isset($settings['wwp_specific_product']) ? $settings['wwp_specific_product'] : array();

				if (in_array($product->get_id(), $specific_products) ) {
					add_action('woocommerce_after_shop_loop_item', array( $this, 'display_custom_message' ), 20);
					return false;
				}
			} elseif ('specific_product_cat' === $hide_on ) {
				$specific_categories = isset($settings['wwp_specific_cat']) ? $settings['wwp_specific_cat'] : array();
				
				$product_categories = wp_get_post_terms($product->get_id(), 'product_cat', array( 'fields' => 'ids' ));
				
				if (! empty(array_intersect($product_categories, $specific_categories)) ) {
					add_action('woocommerce_after_shop_loop_item', array( $this, 'display_custom_message' ), 20);
					return false;
				}
			} elseif ('specific_user_roles' === $hide_on ) {
				$specific_user_roles = isset($settings['wwp_specific_user_role']) ? $settings['wwp_specific_user_role'] : array();
				if ( $this->matches_selected_user_roles( $specific_user_roles ) ) {
					add_action('woocommerce_after_shop_loop_item', array( $this, 'display_custom_message' ), 20);
					return false;
				}
			}
		}

		return $is_purchasable;
	}

	/**
	 * Displays the custom message configured in the plugin settings when the
	 * 'Add to Cart' button is hidden.
	 *
	 * @global \WC_Product $product
	 * @return void Outputs the custom message.
	 */
	public function display_custom_message() {
		global $product;
	
		if (! $product ) {
			return;
		}

		$settings = self::get_pricing_settings();

		if (isset($settings['wwp_hide_add_to_cart']) && 'yes' === $settings['wwp_hide_add_to_cart'] ) {
			$hide_on = isset($settings['wwp_hide_add_to_cart_on']) ? $settings['wwp_hide_add_to_cart_on'] : '';
			
			if ('specific_product' === $hide_on ) {
				$specific_products = isset($settings['wwp_specific_product']) ? $settings['wwp_specific_product'] : array();

				if (in_array($product->get_id(), $specific_products) ) {
					echo ! empty($settings['custom_message_for_cart']) ? wp_kses_post($settings['custom_message_for_cart']) : '';
					return;
				}
			}

			if ('specific_product_cat' === $hide_on ) {
				$specific_categories = isset($settings['wwp_specific_cat']) ? $settings['wwp_specific_cat'] : array();

				$product_categories = wp_get_post_terms($product->get_id(), 'product_cat', array( 'fields' => 'ids' ));

				if (! empty(array_intersect($product_categories, $specific_categories)) ) {
					echo ! empty($settings['custom_message_for_cart']) ? wp_kses_post($settings['custom_message_for_cart']) : '';
					return;
				}
			}

			if ('specific_user_roles' === $hide_on ) {
				$specific_user_roles = isset($settings['wwp_specific_user_role']) ? $settings['wwp_specific_user_role'] : array();
				if ( $this->matches_selected_user_roles( $specific_user_roles ) ) {
					echo ! empty($settings['custom_message_for_cart']) ? wp_kses_post($settings['custom_message_for_cart']) : '';
					return;
				}
			}
		}
	}

	/**
	 * Whether current visitor matches selected role targets.
	 *
	 * Supports the virtual "guest" role for non-logged-in visitors.
	 *
	 * @param array $selected_roles Target role keys.
	 * @return bool
	 */
	private function matches_selected_user_roles( $selected_roles ) {
		$selected_roles = array_map( 'strtolower', (array) $selected_roles );
		if ( empty( $selected_roles ) ) {
			return false;
		}

		if ( ! is_user_logged_in() ) {
			return in_array( 'guest', $selected_roles, true );
		}

		$current_user = wp_get_current_user();
		$user_roles   = is_array( $current_user->roles ) ? array_map( 'strtolower', $current_user->roles ) : array();
		return ! empty( array_intersect( $user_roles, $selected_roles ) );
	}

	/**
	 * Conditionally hides the price string (`woocommerce_get_price_html`) for standard products.
	 *
	 * Replaces the price HTML with a custom message if hiding is enabled based on
	 * product, category, or user role settings. Excludes subscription products.
	 *
	 * @param  string      $price   The price HTML string.
	 * @param  \WC_Product $product The product object.
	 * @return string The original price HTML or the custom message.
	 */
	public function hide_price_shop( $price, $product ) {
		
		if ($product->is_type('subscription') || $product->is_type('subscription_variation') ) { 
			return $price;
		}
		$settings = self::get_pricing_settings();

		$product_id = $product->get_id();
		if ($product->get_type() === 'variation' ) {
			$product_id = $product->get_parent_id();
		}

		/**
		 * Filter Hook: wwp_conditionally_hide_price
		 * Allows bypassing the price hiding check for standard products.
		 *
		 * @since 2.7.0
		 *
		 * @param bool $pass True to bypass, false to proceed with hiding checks.
		 * @param string $price The price HTML string.
		 * @param int $product_id The product or parent product ID.
		 * @param \WC_Product $product The product object.
		 */
		$pass = apply_filters('wwp_conditionally_hide_price', false, $price, $product_id, $product);
		if ($pass ) {
			return $price;
		}
		if (isset($settings['wwp_hide_price']) && 'yes' === $settings['wwp_hide_price'] ) {
			$hide_on = isset($settings['wwp_hide_price_on']) ? $settings['wwp_hide_price_on'] : '';
			if ('specific_product' === $hide_on ) {
				$specific_products = isset($settings['wwp_specific_product_price']) ? $settings['wwp_specific_product_price'] : array();

				if (in_array($product_id, $specific_products) ) {
					return ! empty($settings['custom_message_for_price']) ? wp_kses_post($settings['custom_message_for_price']) : '';
				}
			} elseif ('specific_product_cat' === $hide_on ) {
				$specific_categories = isset($settings['wwp_specific_cat_price']) ? $settings['wwp_specific_cat_price'] : array();
				
				$product_categories = wp_get_post_terms($product_id, 'product_cat', array( 'fields' => 'ids' ));
				
				if (! empty(array_intersect($product_categories, $specific_categories)) ) {
					return ! empty($settings['custom_message_for_price']) ? wp_kses_post($settings['custom_message_for_price']) : '';
				}
			} elseif ('specific_user_roles' === $hide_on ) {
				$specific_user_roles = isset($settings['wwp_specific_user_role_price']) ? $settings['wwp_specific_user_role_price'] : array();
				$specific_user_roles = array_map('strtolower', (array) $specific_user_roles);

				if ( ! is_user_logged_in() ) {
					if ( in_array( 'guest', $specific_user_roles, true ) ) {
						return ! empty($settings['custom_message_for_price']) ? wp_kses_post($settings['custom_message_for_price']) : '';
					}
				} else {
					$current_user = wp_get_current_user();
					$user_roles = $current_user->roles;
					if (! empty(array_intersect(array_map('strtolower', $user_roles), $specific_user_roles)) ) {
						return ! empty($settings['custom_message_for_price']) ? wp_kses_post($settings['custom_message_for_price']) : '';
					}
				}
			}
		}

		return $price;
	}

	/**
	 * Conditionally hides the price string (`woocommerce_subscriptions_product_price_string`)
	 * for WooCommerce Subscriptions products.
	 *
	 * Replaces the price HTML with a custom message if hiding is enabled based on
	 * product, category, or user role settings. Excludes standard products.
	 *
	 * @param  string      $subscription_string The price HTML string for the subscription product.
	 * @param  \WC_Product $product             The product object.
	 * @param  bool        $include             Whether to include product details in the price string.
	 * @return string The original price HTML or the custom message.
	 */
	public function hide_price_for_sub_product( $subscription_string, $product, $include ) {
		
		if ($product->is_type('simple') || $product->is_type('variable') ) { 
			return $subscription_string;
		}

		$settings = self::get_pricing_settings();

		$product_id = $product->get_id();
		if ($product->get_type() === 'variable-subscription' || $product->get_type() === 'subscription_variation' ) {
			$product_id = $product->get_parent_id();
		}

		/**
		 * Filter Hook: wwp_conditionally_hide_subs_price
		 * Allows bypassing the price hiding check for subscription products.
		 *
		 * @since 2.7.0
		 *
		 * @param bool $pass True to bypass, false to proceed with hiding checks.
		 * @param string $subscription_string The price HTML string.
		 * @param int $product_id The product or parent product ID.
		 * @param \WC_Product $product The product object.
		 */
		$pass = apply_filters('wwp_conditionally_hide_subs_price', false, $subscription_string, $product_id, $product);
		if ($pass ) {
			return $subscription_string;
		}
		if (isset($settings['wwp_hide_price']) && 'yes' === $settings['wwp_hide_price'] ) {
			$hide_on = isset($settings['wwp_hide_price_on']) ? $settings['wwp_hide_price_on'] : '';
			if ('specific_product' === $hide_on ) {
				$specific_products = isset($settings['wwp_specific_product_price']) ? $settings['wwp_specific_product_price'] : array();
				if (in_array($product_id, $specific_products) ) {
					return ! empty($settings['custom_message_for_price']) ? esc_html($settings['custom_message_for_price']) : '';
				}
			} elseif ('specific_product_cat' === $hide_on ) {
				$specific_categories = isset($settings['wwp_specific_cat_price']) ? $settings['wwp_specific_cat_price'] : array();
				
				$product_categories = wp_get_post_terms($product_id, 'product_cat', array( 'fields' => 'ids' ));
				
				if (! empty(array_intersect($product_categories, $specific_categories)) ) {
					return ! empty($settings['custom_message_for_price']) ? esc_html($settings['custom_message_for_price']) : '';
				}
			} elseif ('specific_user_roles' === $hide_on ) {
				$specific_user_roles = isset($settings['wwp_specific_user_role_price']) ? $settings['wwp_specific_user_role_price'] : array();
				$specific_user_roles = array_map('strtolower', (array) $specific_user_roles);

				if ( ! is_user_logged_in() ) {
					if ( in_array( 'guest', $specific_user_roles, true ) ) {
						return ! empty($settings['custom_message_for_price']) ? esc_html($settings['custom_message_for_price']) : '';
					}
				} else {
					$current_user = wp_get_current_user();
					$user_roles = $current_user->roles;
					if (! empty(array_intersect(array_map('strtolower', $user_roles), $specific_user_roles)) ) {
						return ! empty($settings['custom_message_for_price']) ? esc_html($settings['custom_message_for_price']) : '';
					}
				}
			}
		}

		return $subscription_string;
	}

	/**
	 * Start capturing output right before the quantity + Add to Cart button.
	 */
	public function suppress_cart_button_start() {
		ob_start();
	}

	/**
	 * Discard captured output (quantity field + Add to Cart button).
	 * Runs at priority 1 — BEFORE Plugin 1's button at priority 30.
	 */
	public function suppress_cart_button_end() {
		ob_end_clean(); // Discards: quantity input + <button class="single_add_to_cart_btn">
	}

	/**
	 * Hide only the native Add to Cart button while keeping quantity visible.
	 *
	 * Quote buttons always include .wc_quote_single_page, so exclude those.
	 *
	 * @return void
	 */
	public function hide_native_add_to_cart_button() {
		if ( $this->native_cart_button_css_printed ) {
			return;
		}

		$this->native_cart_button_css_printed = true;
		echo '<style>.single_add_to_cart_button:not(.wc_quote_single_page){display:none !important;}</style>';
	}

	/**
	 * Whether quantity should stay visible because quote button can render.
	 *
	 * @param \WC_Product $product Product object.
	 * @return bool
	 */
	private function should_preserve_quantity_for_quote( $product ) {
		if (
			! function_exists( 'is_quote_enabled' )
			|| ! function_exists( 'get_quote_rules' )
			|| ! function_exists( 'quote_check_rule_for_product' )
			|| ! is_quote_enabled()
		) {
			return false;
		}

		foreach ( get_quote_rules() as $rule ) {
			if ( ! isset( $rule->ID ) || ! quote_check_rule_for_product( $product->get_id(), $rule->ID ) ) {
				continue;
			}

			$quote_rules = get_post_meta( $rule->ID, 'wc_quote_rules', true );
			$show_single = isset( $quote_rules['show_single'] ) ? $quote_rules['show_single'] : '0';

			if ( '1' === $show_single ) {
				return true;
			}
		}

		return false;
	}

	 /**
	  * Determines whether this service should be initialized based on the environment.
	  *
	  * The shop services should only be initialized on the front-end (not in the WP Admin).
	  *
	  * @return bool True if the service should be run (i.e., not in admin), false otherwise.
	  */
	public static function resolveDependency() {
		return ! is_admin();
	}
}
