<?php
/**
 * TaxService
 *
 * This service manages WooCommerce tax rules specifically for wholesale users,
 * allowing for tax exemption or the application of custom tax classes based
 * on the user's assigned wholesale role settings.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @extends    Init
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Strategies\Init;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * TaxService
 *
 * Manages the application of tax exemptions or custom tax classes for products
 * when viewed or purchased by a user assigned a wholesale role.
 *
 * @extends    Init
 * @implements ServiceInterface
 */
class TaxService extends Init implements ServiceInterface {


	/**
	 * TaxService constructor.
	 *
	 * Hooks into WooCommerce to filter the tax class for both simple and
	 * variable products.
	 */
	public function __construct() {
		parent::__construct();

		// Filters the tax class for simple products.
		add_filter('woocommerce_product_get_tax_class', array( $this, 'woocommerce_product_get_tax_class' ), 20, 2);

		// Filters the tax class for product variations.
		add_filter('woocommerce_product_variation_get_tax_class', array( $this, 'woocommerce_product_get_tax_class' ), 20, 2);
	}

	/**
	 * Registers tax exemption status and related filters if the user's wholesale
	 * role is configured as tax-exempt.
	 *
	 * This method is run on various WooCommerce hooks to ensure the customer's
	 * VAT status is set correctly before price calculations.
	 *
	 * @global \WooCommerce $woocommerce The global WooCommerce instance.
	 * @return void
	 */
	public function register() {
		global $woocommerce;

		if (! isset($woocommerce->customer) ) {
			return;
		}

		$woocommerce->customer->set_is_vat_exempt(false);
		
		if (is_user_logged_in() ) {
			$user_info      = get_userdata(get_current_user_id());
			$user_role      = implode(', ', $user_info->roles);
			$wholesale_role = term_exists($user_role, 'wholesale_user_roles');
			if (0 !== $wholesale_role && null !== $wholesale_role ) {
				if (is_array($wholesale_role) && isset($wholesale_role['term_id']) && 'yes' == get_term_meta($wholesale_role['term_id'], 'wwp_tax_exmept_wholesaler', true) ) {
					$woocommerce->customer->set_is_vat_exempt(true);
					add_filter('woocommerce_product_get_tax_class', array( $this, 'remove_tax' ), 10, 2);
					add_action('woocommerce_before_cart_contents', array( $this, 'register' ), 10, 2);
					add_action('woocommerce_before_shipping_calculator', array( $this, 'register' ), 10, 2);
					add_filter('woocommerce_get_price_suffix', array( $this, 'woocommerce_get_price_suffix' ), 99, 4);
				}
			}
		}
	}

	/**
	 * Removes the price suffix (e.g., "+ tax" or "inc. VAT") from prices
	 * for tax-exempt wholesale users.
	 *
	 * @param  string      $html    The price suffix HTML.
	 * @param  \WC_Product $product The product object.
	 * @param  float       $price   The product price.
	 * @param  int         $qty     The quantity.
	 * @return string Empty string to hide the suffix.
	 */
	public function woocommerce_get_price_suffix( $html, $product, $price, $qty ) {
		return '';
	}

	/**
	 * Forces the product tax class to 'Zero Rate'.
	 *
	 * This is used when a wholesale role is explicitly configured as tax-exempt.
	 *
	 * @param  string      $tax_class The original tax class.
	 * @param  \WC_Product $product   The product object.
	 * @return string The 'Zero Rate' tax class slug.
	 */
	public function remove_tax( $tax_class, $product ) {
		return 'Zero Rate';
	}

	/**
	 * Overrides the default product tax class with a custom tax class
	 * configured for the current user's wholesale role.
	 *
	 * This filter runs for all wholesale users, regardless of whether they are
	 * fully tax-exempt or not.
	 *
	 * @param  string      $tax_class The original tax class (from product/variation settings).
	 * @param  \WC_Product $product   The product object.
	 * @return string The custom tax class slug for the wholesale role, or the original tax class.
	 */
	public function woocommerce_product_get_tax_class( $tax_class, $product ) {
		if (is_wholesaler_user(get_current_user_id()) ) {
			if (!empty(is_wholesaler_user(get_current_user_id())) ) {
				$role                       = get_current_user_role_id();
				$user_id                    = get_current_user_id();
				$user_data                  = get_userdata($user_id);
				$wwp_wholesaler_tax_classes = get_term_meta($role, 'wwp_wholesaler_tax_classes', true);
				if (!empty($wwp_wholesaler_tax_classes) ) {
					return $wwp_wholesaler_tax_classes;
				}
			}
		}
		return $tax_class;
	}

	/**
	 * Determines whether this service should be initialized based on the environment.
	 *
	 * The service should only be loaded on the public-facing front end.
	 *
	 * @return bool True if the current request is not in the admin area, false otherwise.
	 */
	public static function resolveDependency() {
		return ! is_admin();
	}
}
