<?php
/**
 * PrivateStoreService class.
 *
 * Manages the "Private Store" feature, which restricts general store access
 * to non-wholesalers and handles temporary access granted via a password.
 * It also manages user role assignment based on temporary access during checkout.
 *
 * @package    WooCommerceWholesalePricing\Services
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Service to handle store access restrictions and temporary wholesale session management.
 */
class PrivateStoreService {

	/**
	 * Includes methods for retrieving general wholesale settings.
	 */
	use WholesaleSettings;

	/**
	 * Constructor.
	 *
	 * Hooks into WordPress and WooCommerce actions related to body output and checkout processes.
	 *
	 * @return void
	 */
	public function __construct() {
		// Renders the "Exit Wholesaler Access" form if a cookie is set.
		add_action('wp_body_open', array( $this, 'wholeslaer_acess_store' ), 10);

		// Handles user role assignment on standard checkout (for registration during checkout).
		add_action('woocommerce_checkout_update_customer', array( $this, 'checkout_update_customer' ), 10, 2);

		// Handles data for guest user role assignment via the WooCommerce Store API (Block checkout).
		add_action('woocommerce_store_api_checkout_update_order_from_request', array( $this, 'checkout_create_order' ), 10, 2);
	}

	/**
	 * Outputs the "Exit" form or displays restriction notices on front-end pages.
	 *
	 * 1. If a temporary access cookie exists and the user is logged out, displays the
	 * "Exit" form to revert to the public store view.
	 * 2. If store access is restricted and the user is logged out (and no access cookie exists),
	 * displays a WooCommerce notice with the restriction message.
	 *
	 * @hooked wp_body_open
	 * @return void
	 */
	public function wholeslaer_acess_store() {
		$settings = self::get_pricing_settings();

		if (isset($settings['restrict_store_access']) && 'yes' == $settings['restrict_store_access'] ) {
			if ('yes' == $settings['restrict_store_access'] && isset($_COOKIE['access_store_id']) && ! empty($_COOKIE['access_store_id']) && ! is_user_logged_in() ) {
				
				/**
				* Hooks
				*
				* @since 3.0
				*/
				$back_to_retailer_form = apply_filters('back_to_retailer_form_text', 'You are accessing this store as a wholesaler <input type="submit" name="back_to_retailer" value="Exit"/>'); 
				?>
					<form class="woocommerce-form back_to_retailer_form" method="post">
						<div id="wholeslaer_acess"><?php echo wp_kses($back_to_retailer_form, shapeSpace_allowed_html()); ?></div>
					</form>
				<?php 
			}
			if (( is_shop() || is_account_page() ) && ! is_user_logged_in() && 'yes' == $settings['restrict_store_access'] && ! isset($_COOKIE['access_store_id']) ) {
				remove_action('woocommerce_no_products_found', 'wc_no_products_found', 10);
				/**
				* Hooks
				*
				* @since 3.0
				*/
				$login = apply_filters('stroe_restict_login_text', '');
				wc_add_notice(__($settings['restrict_store_access_message'] . $login, 'woocommerce-wholesale-pricing'), 'notice');
			}
		}
	}

	/**
	 * Updates the customer's role after registration/checkout based on the
	 * temporary wholesale access cookie.
	 *
	 * This ensures a user registering during checkout is assigned the role
	 * corresponding to their temporary store access. The cookie is then cleared.
	 *
	 * @hooked woocommerce_checkout_update_customer
	 * @param  \WC_Customer $customer The customer object.
	 * @param  array        $data     An array of posted customer data.
	 * @return void
	 */
	public function checkout_update_customer( $customer, $data ) {

		$settings = self::get_pricing_settings();

		if ('yes' == $settings['restrict_store_access'] ) {

			if (isset($_COOKIE['access_store_id']) && ! empty($_COOKIE['access_store_id']) ) {

				$access_store_id      = sanitize_text_field($_COOKIE['access_store_id']);
				$user_id              = $customer->get_id();
				$wholesale_user_roles = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));

				$u = new \WP_User($user_id);

				foreach ( $wholesale_user_roles as  $value ) {
					if ($value->term_id == $access_store_id ) {
						$user_role_set = $value->slug;
					}
				}
				$wp_roles = new \WP_Roles();
				$names    = $wp_roles->get_names();
				foreach ( $names as $key => $value ) {
					$u->remove_role($key);
				}
				if ( isset( $user_role_set ) ) {
					$u->add_role($user_role_set);
				}
				unset($_COOKIE['access_store_id']);
				setcookie('access_store_id', null, 0, '/');

			}
		}
	}

	/**
	 * Saves the temporary wholesale access ID during WooCommerce Store API checkout
	 * for guest users who are registering.
	 *
	 * This function saves the role ID to a temporary option keyed by user email.
	 * The actual role assignment must happen later (e.g., on order complete or user registration hook).
	 *
	 * @hooked woocommerce_store_api_checkout_update_order_from_request
	 * @param  \WC_Order        $order   The order object being created.
	 * @param  \WP_REST_Request $request The REST request object containing checkout data.
	 * @return void
	 */
	public function checkout_create_order( $order, $request ) {

		$settings = self::get_pricing_settings();

		if ('yes' == $settings['restrict_store_access'] ) {
			if (isset($_COOKIE['access_store_id']) && ! empty($_COOKIE['access_store_id']) ) {
				$access_store_id      = sanitize_text_field($_COOKIE['access_store_id']);
				$request = (array) json_decode($request->get_body());
				$user_email = $request['billing_address']->email;
				if (isset($request['customer_password']) && ! empty($request['customer_password']) ) {
					update_option($user_email, $access_store_id);
				}
			}
		}
	}

	/**
	 * Static method to handle the actual password submission for store access
	 * and the 'Exit' action.
	 *
	 * This function is expected to be hooked early (e.g., 'init' or 'template_redirect')
	 * to perform cookie manipulation and redirects before headers are sent.
	 *
	 * @action init (Assumed to be hooked to a pre-header hook).
	 * @return void
	 */
	public static function restrict_store_access() {
		if (is_admin() ) {
			return;
		}
		$post = wwp_get_post_data('');

		$settings = self::get_pricing_settings();

		if (isset($post['access_store_pass']) && ! empty($post['access_store_pass']) ) {
			$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
			foreach ( $allterms as $allterm_key => $allterm_value ) {
				$password = get_term_meta($allterm_value->term_id, 'password', true);
				if ($password == $post['access_store_pass'] ) {
					setcookie('access_store_id', $allterm_value->term_id, time() + 86400, '/', '', 0);
					if (isset($settings['enable_store_access_cookie']) && 'yes' == $settings['enable_store_access_cookie'] && isset($settings['wwp_cookie_interval']) && ! empty($settings['wwp_cookie_interval']) ) {
						$cookie_days = intval($settings['wwp_cookie_interval']);
						$cookie_lifetime = $cookie_days * 86400;
						setcookie('access_store_id', $allterm_value->term_id, time() + $cookie_lifetime, '/', '', 0);
					}
					if (isset($_SERVER['HTTP_REFERER']) ) {
						$refresh = sanitize_text_field($_SERVER['HTTP_REFERER']) . '?message=successfully';
						/**
						 * Hooks
						 *
						 * @since 3.0
						 */                         
						$shop_page_url = apply_filters('wwp_redirect_shop_page_url', get_permalink(wc_get_page_id('shop')));
						if ($shop_page_url ) {
							header('Location: ' . $shop_page_url);
							exit;
						}
						header('Location: ' . $refresh);
						exit;
					}
				}
			}
			$refresh = sanitize_text_field($_SERVER['HTTP_REFERER']);
			wc_add_notice(__('Your password is invalid', 'woocommerce-wholesale-pricing'), 'error');
		}
		if (isset($post['back_to_retailer']) && ! empty($post['back_to_retailer']) ) {
			unset($_COOKIE['access_store_id']);
			setcookie('access_store_id', null, 0, '/');
			header('Location: ' . remove_query_arg('message', site_url('/my-account')));
			exit;
		}
		$get = wwp_get_get_data('');
		if (isset($get['message']) && ! empty($get['message']) ) {
			wc_add_notice(__('You have been successfully access the wholesale store.', 'woocommerce-wholesale-pricing'), 'success');
		}
	}
}
