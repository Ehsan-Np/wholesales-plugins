<?php
/**
 * Read and update quote module settings (Quote + Quote PDF tabs).
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleOption;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

/**
 * Manages quote settings from settings.php section7 and section8.
 */
class WholesaleQuoteSettingsService {

	/**
	 * General quote settings keys, used for formatting and validation.
	 * 
	 * @var list<string>
	 */
	const GENERAL_KEYS = array(
		'quote_page',
		'empty_email',
		'wc_requote',
		'enable_convert_cart',
		'enable_build_quote',
		'empty_cart',
		'enable_show_quote_details',
		'mini_cart',
		'quote_basket_menu',
		'disable_basket_roles',
		'quote_basket_style',
		'enable_offered',
		'inc_dec_offered_price',
		'increase_offered_price',
		'decrease_offered_price',
		'display_tax',
		'enable_standard',
		'return_shop',
		'convert_to_order',
		'send_to_checkout',
		'display_quote_converter',
		'display_quote_counter',
		'counter_shop',
		'counter_single_product',
		'show_on_stock',
		'display_browse_list',
		'custom_tax_shipping',
		'quote_expire',
	);

	/**
	 * NOTIFICATION-related quote settings keys, used for formatting and validation.
	 * 
	 * @var list<string>
	 */
	const NOTIFICATION_KEYS = array(
		'email_success_msg',
		'email_error_msg',
		'email_valid_msg',
		'add_quote_redirect',
		'add_quote_redirect_url',
		'send_quote_redirect',
		'send_quote_redirect_url',
	);

	/**
	 * PDF-related quote settings keys, used for formatting and validation.
	 * 
	 * @var list<string>
	 */
	const PDF_KEYS = array(
		'enable_pdf',
		'enable_pdf_download',
		'enable_pdf_attach',
		'hide_product_list',
		'pdf_logo_id',
		'pdf_show_link',
		'quote_pdf',
		'custom',
	);

	/**
	 * General boolean keys for the 'general' group, used for formatting and validation.
	 * 
	 * @var list<string>
	 */
	const GENERAL_BOOLEAN_KEYS = array(
		'empty_email',
		'wc_requote',
		'enable_convert_cart',
		'enable_build_quote',
		'empty_cart',
		'enable_show_quote_details',
		'mini_cart',
		'enable_offered',
		'display_tax',
		'enable_standard',
		'return_shop',
		'convert_to_order',
		'send_to_checkout',
		'display_quote_converter',
		'display_quote_counter',
		'counter_shop',
		'counter_single_product',
		'display_browse_list',
		'custom_tax_shipping',
		'quote_expire',
	);

	/**
	 * Notification-related boolean keys, used for formatting and validation.
	 * 
	 * @var list<string>
	 */
	const NOTIFICATION_BOOLEAN_KEYS = array(
		'add_quote_redirect',
		'send_quote_redirect',
	);

	/**
	 * PDF-related boolean keys, used for formatting and validation.
	 * 
	 * @var list<string>
	 */
	const PDF_BOOLEAN_KEYS = array(
		'enable_pdf',
		'enable_pdf_download',
		'enable_pdf_attach',
		'hide_product_list',
		'pdf_show_link',
	);

	/**
	 * PDF template color options for the 'custom' template, used for validation.
	 * 
	 * @var list<string>
	 */
	const PDF_TEMPLATE_COLORS = array(
		'bronze',
		'darkblue',
		'lightblue',
	);

	/**
	 * Get formatted quote settings exposed to the ability API.
	 *
	 * @return array<string, mixed>
	 */
	public function get_settings() {
		$pricing = $this->get_raw_pricing_settings();

		return array(
			'pricing_option_key'       => WholesaleOption::PRICING_OPTION,
			'general_option_key'       => WholesaleOption::QUOTE_GENERAL_OPTION,
			'notifications_option_key' => WholesaleOption::QUOTE_NOTIFICATIONS_OPTION,
			'pdf_option_key'           => WholesaleOption::QUOTE_PDF_OPTION,
			'settings'                 => array(
				'enable_quote'  => isset( $pricing['enable_quote'] ) && 'yes' === $pricing['enable_quote'],
				'general'       => $this->format_group( self::GENERAL_KEYS, $this->get_raw_general_settings(), 'general' ),
				'notifications' => $this->format_group( self::NOTIFICATION_KEYS, $this->get_raw_notification_settings(), 'notifications' ),
				'pdf'           => $this->format_group( self::PDF_KEYS, $this->get_raw_pdf_settings(), 'pdf' ),
			),
		);
	}

	/**
	 * Update quote settings (partial merge).
	 *
	 * @param array<string, mixed> $settings Settings patch.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_settings( array $settings ) {
		if ( empty( $settings ) ) {
			return new \WP_Error(
				'wwp_quote_settings_missing',
				__( 'Quote settings are required for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$settings = $this->normalize_settings_patch( $settings );

		$allowed_top = array( 'enable_quote', 'general', 'notifications', 'pdf' );
		$unknown     = array_diff( array_keys( $settings ), $allowed_top );
		if ( ! empty( $unknown ) ) {
			return new \WP_Error(
				'wwp_quote_settings_invalid_group',
				sprintf(
					/* translators: %s: comma-separated group names */
					__( 'Unknown quote setting group(s): %s', 'woocommerce-wholesale-pricing' ),
					implode( ', ', $unknown )
				),
				array( 'status' => 400 )
			);
		}

		if ( array_key_exists( 'enable_quote', $settings ) ) {
			$enable_quote = $this->sanitize_enable_quote( $settings['enable_quote'] );
			if ( is_wp_error( $enable_quote ) ) {
				return $enable_quote;
			}

			$pricing = $this->get_raw_pricing_settings();
			$pricing['enable_quote'] = $enable_quote;
			WholesaleSettingsHelper::update_pricing_settings( $pricing );
		}

		if ( isset( $settings['general'] ) ) {
			$result = $this->update_group(
				self::GENERAL_KEYS,
				$this->get_raw_general_settings(),
				is_array( $settings['general'] ) ? $settings['general'] : array(),
				'general',
				array( WholesaleSettingsHelper::class, 'update_quote_general_settings' )
			);
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		if ( isset( $settings['notifications'] ) ) {
			$result = $this->update_group(
				self::NOTIFICATION_KEYS,
				$this->get_raw_notification_settings(),
				is_array( $settings['notifications'] ) ? $settings['notifications'] : array(),
				'notifications',
				array( WholesaleSettingsHelper::class, 'update_quote_notifications_settings' )
			);
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		if ( isset( $settings['pdf'] ) ) {
			$result = $this->update_group(
				self::PDF_KEYS,
				$this->get_raw_pdf_settings(),
				is_array( $settings['pdf'] ) ? $settings['pdf'] : array(),
				'pdf',
				array( WholesaleSettingsHelper::class, 'update_quote_pdf_settings' )
			);
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}

		return $this->get_settings();
	}

	/**
	 * Hoist flat field keys into nested general/notifications/pdf groups.
	 *
	 * @param array<string, mixed> $settings Incoming settings patch.
	 * @return array<string, mixed>
	 */
	public function normalize_settings_patch( array $settings ) {
		$normalized = array();

		if ( array_key_exists( 'enable_quote', $settings ) ) {
			$normalized['enable_quote'] = $settings['enable_quote'];
		}

		$general = is_array( isset( $settings['general'] ) ? $settings['general'] : null ) ? $settings['general'] : array();
		$notifications = is_array( isset( $settings['notifications'] ) ? $settings['notifications'] : null ) ? $settings['notifications'] : array();
		$pdf = is_array( isset( $settings['pdf'] ) ? $settings['pdf'] : null ) ? $settings['pdf'] : array();

		foreach ( $settings as $key => $value ) {
			if ( in_array( $key, array( 'enable_quote', 'general', 'notifications', 'pdf' ), true ) ) {
				continue;
			}

			if ( in_array( $key, self::GENERAL_KEYS, true ) ) {
				$general[ $key ] = $value;
				continue;
			}

			if ( in_array( $key, self::NOTIFICATION_KEYS, true ) ) {
				$notifications[ $key ] = $value;
				continue;
			}

			if ( in_array( $key, self::PDF_KEYS, true ) ) {
				$pdf[ $key ] = $value;
			}
		}

		if ( ! empty( $general ) ) {
			$normalized['general'] = $general;
		}

		if ( ! empty( $notifications ) ) {
			$normalized['notifications'] = $notifications;
		}

		if ( ! empty( $pdf ) ) {
			$normalized['pdf'] = $pdf;
		}

		return $normalized;
	}

	/**
	 * Snapshot raw stored values for undo.
	 *
	 * @return array<string, mixed>
	 */
	public function snapshot_settings() {
		$pricing = $this->get_raw_pricing_settings();

		return array(
			'enable_quote'  => isset( $pricing['enable_quote'] ) ? $pricing['enable_quote'] : 'no',
			'general'       => $this->get_raw_general_settings(),
			'notifications' => $this->get_raw_notification_settings(),
			'pdf'           => $this->get_raw_pdf_settings(),
		);
	}

	/**
	 * Restore a full quote settings snapshot.
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_settings( $snapshot ) {
		if ( ! array_key_exists( 'general', $snapshot ) || ! array_key_exists( 'notifications', $snapshot ) || ! array_key_exists( 'pdf', $snapshot ) ) {
			return new \WP_Error(
				'wwp_quote_settings_restore_invalid_snapshot',
				__( 'Cannot restore quote settings: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$pricing = $this->get_raw_pricing_settings();
		if ( array_key_exists( 'enable_quote', $snapshot ) ) {
			$pricing['enable_quote'] = (string) $snapshot['enable_quote'];
		}
		WholesaleSettingsHelper::update_pricing_settings( $pricing );

		WholesaleSettingsHelper::update_quote_general_settings( is_array( $snapshot['general'] ) ? $snapshot['general'] : array() );
		WholesaleSettingsHelper::update_quote_notifications_settings( is_array( $snapshot['notifications'] ) ? $snapshot['notifications'] : array() );
		WholesaleSettingsHelper::update_quote_pdf_settings( is_array( $snapshot['pdf'] ) ? $snapshot['pdf'] : array() );

		return true;
	}

	/**
	 * Format a group of stored settings for API output based on allowed keys and group name.
	 * 
	 * @param list<string>         $allowed_keys Allowed keys.
	 * @param array<string, mixed> $stored       Stored values.
	 * @param string               $group        Group name for errors.
	 * @return array<string, mixed>
	 */
	private function format_group( $allowed_keys, $stored, $group ) {
		$formatted = array();

		foreach ( $allowed_keys as $key ) {
			$formatted[ $key ] = $this->format_value( $key, isset( $stored[ $key ] ) ? $stored[ $key ] : null, $group );
		}

		return $formatted;
	}

	/**
	 * Update a group of settings with validation and sanitization, based on allowed keys and an update callback.
	 * 
	 * @param list<string>         $allowed_keys Allowed keys.
	 * @param array<string, mixed> $stored       Stored values.
	 * @param array<string, mixed> $patch        Patch values.
	 * @param string               $group        Group name.
	 * @param callable             $updater      Update callback.
	 * @return true|\WP_Error
	 */
	private function update_group( $allowed_keys, $stored, $patch, $group, $updater ) {
		if ( empty( $patch ) ) {
			return new \WP_Error(
				'wwp_quote_settings_empty_patch',
				__( 'Quote settings patch cannot be empty.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$unknown = array_diff( array_keys( $patch ), $allowed_keys );
		if ( ! empty( $unknown ) ) {
			return new \WP_Error(
				'wwp_quote_settings_invalid_field',
				sprintf(
					/* translators: 1: group name, 2: comma-separated field names */
					__( 'Unknown %1$s quote setting(s): %2$s', 'woocommerce-wholesale-pricing' ),
					$group,
					implode( ', ', $unknown )
				),
				array( 'status' => 400 )
			);
		}

		$updated = $stored;
		foreach ( $patch as $key => $value ) {
			$sanitized = $this->sanitize_value( $key, $value, $group );
			if ( is_wp_error( $sanitized ) ) {
				return $sanitized;
			}

			$updated[ $key ] = $sanitized;
		}

		$updater( $updated );

		return true;
	}

	/**
	 * Format a stored setting value based on its key and group for API output.
	 * 
	 * @param string $key   Setting key.
	 * @param mixed  $value Stored value.
	 * @param string $group Group name.
	 * @return mixed
	 */
	private function format_value( $key, $value, $group ) {
		if ( $this->is_boolean_key( $key, $group ) ) {
			return (bool) $value && '0' !== (string) $value && '' !== (string) $value;
		}

		if ( 'quote_basket_menu' === $key ) {
			if ( ! is_array( $value ) ) {
				return array();
			}

			return array_values( array_map( 'intval', $value ) );
		}

		if ( 'disable_basket_roles' === $key ) {
			if ( ! is_array( $value ) ) {
				return array();
			}

			return array_values( array_map( 'strval', $value ) );
		}

		if ( 'quote_page' === $key || 'pdf_logo_id' === $key ) {
			return is_scalar( $value ) ? (string) $value : '';
		}

		return is_string( $value ) ? $value : ( is_scalar( $value ) ? (string) $value : '' );
	}

	/**
	 * Sanitize a setting value based on its key and group, with validation for specific fields.
	 * 
	 * @param string $key   Setting key.
	 * @param mixed  $value Incoming value.
	 * @param string $group Group name.
	 * @return mixed|\WP_Error
	 */
	private function sanitize_value( $key, $value, $group ) {
		if ( $this->is_boolean_key( $key, $group ) ) {
			return $this->sanitize_quote_boolean( $value );
		}

		if ( 'quote_basket_menu' === $key ) {
			if ( ! is_array( $value ) ) {
				return array();
			}

			return array_values( array_map( 'absint', $value ) );
		}

		if ( 'disable_basket_roles' === $key ) {
			if ( ! is_array( $value ) ) {
				return array();
			}

			return array_values(
				array_filter(
					array_map(
						static function ( $role ) {
							return sanitize_key( (string) $role );
						},
						$value
					)
				)
			);
		}

		if ( 'quote_basket_style' === $key && ! in_array( (string) $value, array( 'dropdown', 'icon' ), true ) ) {
			return new \WP_Error(
				'wwp_quote_settings_invalid_basket_style',
				__( 'quote_basket_style must be dropdown or icon.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( 'inc_dec_offered_price' === $key && ! in_array( (string) $value, array( 'inc', 'dec' ), true ) ) {
			return new \WP_Error(
				'wwp_quote_settings_invalid_offered_price_mode',
				__( 'inc_dec_offered_price must be inc or dec.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( 'show_on_stock' === $key && ! in_array( (string) $value, array( 'show', 'hide' ), true ) ) {
			return new \WP_Error(
				'wwp_quote_settings_invalid_show_on_stock',
				__( 'show_on_stock must be show or hide.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( 'quote_pdf' === $key && ! in_array( (string) $value, array( 'default', 'custom' ), true ) ) {
			return new \WP_Error(
				'wwp_quote_settings_invalid_pdf_template',
				__( 'quote_pdf must be default or custom.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		if ( 'custom' === $key && ! in_array( (string) $value, self::PDF_TEMPLATE_COLORS, true ) ) {
			return new \WP_Error(
				'wwp_quote_settings_invalid_pdf_color',
				sprintf(
					/* translators: %s: comma-separated color slugs */
					__( 'custom PDF template must be one of: %s', 'woocommerce-wholesale-pricing' ),
					implode( ', ', self::PDF_TEMPLATE_COLORS )
				),
				array( 'status' => 400 )
			);
		}

		if ( in_array( $key, array( 'increase_offered_price', 'decrease_offered_price' ), true ) ) {
			if ( '' === (string) $value ) {
				return '';
			}

			if ( ! is_numeric( $value ) ) {
				return new \WP_Error(
					'wwp_quote_settings_invalid_offered_price',
					__( 'Offered price values must be numeric.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			return (string) $value;
		}

		if ( 'quote_page' === $key ) {
			$page_id = absint( $value );
			if ( $page_id > 0 && ! get_post( $page_id ) ) {
				return new \WP_Error(
					'wwp_quote_settings_invalid_page',
					__( 'The selected quote page does not exist.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			return $page_id > 0 ? (string) $page_id : '';
		}

		if ( 'pdf_logo_id' === $key ) {
			$attachment_id = absint( $value );
			if ( $attachment_id > 0 && ! wp_get_attachment_url( $attachment_id ) ) {
				return new \WP_Error(
					'wwp_quote_settings_invalid_logo',
					__( 'The selected PDF logo attachment does not exist.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			return $attachment_id > 0 ? (string) $attachment_id : '';
		}

		if ( in_array( $key, array( 'add_quote_redirect_url', 'send_quote_redirect_url' ), true ) ) {
			return esc_url_raw( (string) $value );
		}

		return is_string( $value ) ? sanitize_text_field( $value ) : sanitize_text_field( (string) $value );
	}

	/**
	 * Sanitize the enable_quote setting, accepting various representations of boolean values.
	 * 
	 * @param mixed $value Incoming value.
	 * @return string|\WP_Error
	 */
	private function sanitize_enable_quote( $value ) {
		if ( is_bool( $value ) ) {
			return $value ? 'yes' : 'no';
		}

		if ( in_array( $value, array( 'yes', 'no', '1', '0', 1, 0 ), true ) ) {
			return in_array( $value, array( 'yes', '1', 1 ), true ) ? 'yes' : 'no';
		}

		return new \WP_Error(
			'wwp_quote_settings_invalid_enable_quote',
			__( 'enable_quote must be true or false.', 'woocommerce-wholesale-pricing' ),
			array( 'status' => 400 )
		);
	}

	/**
	 * Sanitize boolean-like quote fields, accepting various representations of boolean values.
	 * 
	 * @param mixed $value Incoming value.
	 * @return string|\WP_Error
	 */
	private function sanitize_quote_boolean( $value ) {
		if ( is_bool( $value ) ) {
			return $value ? '1' : '0';
		}

		if ( in_array( $value, array( 'yes', 'no', '1', '0', 1, 0, true, false ), true ) ) {
			return in_array( $value, array( 'yes', '1', 1, true ), true ) ? '1' : '0';
		}

		return new \WP_Error(
			'wwp_quote_settings_invalid_boolean',
			__( 'Boolean quote fields must be true or false.', 'woocommerce-wholesale-pricing' ),
			array( 'status' => 400 )
		);
	}

	/**
	 * Is the given key a boolean field?
	 * 
	 * @param string $key   Setting key.
	 * @param string $group Group name.
	 * @return bool
	 */
	private function is_boolean_key( $key, $group ) {
		if ( 'general' === $group ) {
			return in_array( $key, self::GENERAL_BOOLEAN_KEYS, true );
		}

		if ( 'notifications' === $group ) {
			return in_array( $key, self::NOTIFICATION_BOOLEAN_KEYS, true );
		}

		if ( 'pdf' === $group ) {
			return in_array( $key, self::PDF_BOOLEAN_KEYS, true );
		}

		return false;
	}

	/**
	 * Get raw pricing settings without formatting, for snapshot/restore purposes.
	 * 
	 * @return array<string, mixed>
	 */
	private function get_raw_pricing_settings() {
		$stored = WholesaleSettingsHelper::get_pricing_settings();

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Get raw general settings without formatting, for snapshot/restore purposes.
	 * 
	 * @return array<string, mixed>
	 */
	private function get_raw_general_settings() {
		$stored = WholesaleSettingsHelper::get_quote_general_settings();

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Get raw notification settings without formatting, for snapshot/restore purposes.
	 * 
	 * @return array<string, mixed>
	 */
	private function get_raw_notification_settings() {
		$stored = WholesaleSettingsHelper::get_quote_notifications_settings();

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Get raw PDF settings without formatting, for snapshot/restore purposes.
	 * 
	 * @return array<string, mixed>
	 */
	private function get_raw_pdf_settings() {
		$stored = WholesaleSettingsHelper::get_quote_pdf_settings();

		return is_array( $stored ) ? $stored : array();
	}
}
