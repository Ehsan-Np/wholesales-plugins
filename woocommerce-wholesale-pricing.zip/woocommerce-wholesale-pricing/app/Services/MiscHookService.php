<?php
/**
 * MiscHookService class.
 *
 * Handles various miscellaneous WordPress and WooCommerce actions and filters
 * that are essential for the plugin's environment setup, testing, and security.
 *
 * @package    WooCommerceWholesalePricing\Services
 */
namespace WooCommerceWholesalePricing\App\Services;

/**
 * Service class for registering miscellaneous global hooks.
 */
class MiscHookService {

	/**
	 * Constructor.
	 *
	 * Registers all necessary hooks for various miscellaneous functionalities.
	 *
	 * @return void
	 */
	public function __construct() {
		add_filter('woocommerce_screen_ids', array( $this, 'screen_ids' ), 10, 1);

		// for automated testing ?reset_pricing=true
		add_action('template_redirect', array( $this, 'reset_wholesale_pricing' ));

		// add nonce to validate registration form on legacy checkout
		add_action('woocommerce_before_checkout_billing_form', array( $this, 'checkout_nonce' ), 10);
		
		add_filter('wccs_hook_priorities', array( $this, 'wccs_hook_priorities_callback' ));
	}

	/**
	 * Adds the custom taxonomy edit screen ID to the WooCommerce screen list.
	 *
	 * This ensures the custom 'wholesale_user_roles' taxonomy administration screen
	 * receives the proper WooCommerce styling and assets.
	 *
	 * @filter woocommerce_screen_ids
	 * @param  string[] $screen_ids Array of screen IDs recognized as WooCommerce administration pages.
	 * @return string[] Modified array of screen IDs.
	 */
	public function screen_ids( $screen_ids ) {
		$custom     = array( 'edit-wholesale_user_roles' );
		$screen_ids = array_merge($custom, $screen_ids);
		return $screen_ids;
	}

	/**
	 * Provides a URL-based mechanism to reset all wholesale pricing data.
	 *
	 * Used primarily for automated testing purposes by appending `?reset_pricing=true`
	 * to the URL. Deletes product, category, and global pricing metadata.
	 *
	 * @action template_redirect
	 * @return void
	 */
	public function reset_wholesale_pricing() {
		if (filter_input(INPUT_GET, 'reset_pricing', FILTER_SANITIZE_SPECIAL_CHARS) ) {
			// delete product data
			$products = wc_get_products(array( 'limit' => -1, 'return' => 'ids' ));
			
			if (! empty($products) ) {
				foreach ( $products as $product_id ) {
					delete_post_meta($product_id, 'product_tier_pricing');
					delete_post_meta($product_id, 'wholesale_multi_user_pricing');
				}
			}

			// delete category data
			$categories = get_terms(array( 'taxonomy' => 'product_cat', 'fields' => 'ids' ));
			if (! empty($categories) ) {
				foreach ( $categories as $term_id ) {
					delete_term_meta($term_id, 'category_tier_pricing');
					delete_term_meta($term_id, 'wholesale_multi_user_pricing');
				}
			}

			// delete global pricing
			delete_option('wholesale_multi_user_pricing');
		}
	}

	/**
	 * Adds a nonce field to the WooCommerce checkout page before the billing form.
	 *
	 * This nonce is used to validate form submission when a user registers for a
	 * wholesale account via the checkout page.
	 *
	 * @action woocommerce_before_checkout_billing_form
	 * @return void
	 */
	public function checkout_nonce() {
		wp_nonce_field('_wwp_nonce', '_wwp_nonce');
	}

	/**
	 * Adjusts the priority of WooCommerce price hooks for compatibility with
	 * the "WooCommerce Custom Cart Settings" (WCCS) plugin.
	 *
	 * Ensures wholesale pricing calculation happens *after* WCCS hooks, preventing conflicts.
	 *
	 * @filter wccs_hook_priorities
	 * @param  array $priorities Array of hook names and their desired priorities.
	 * @return array Modified array with adjusted priorities.
	 */
	public function wccs_hook_priorities_callback( $priorities ) {
		$priorities['woocommerce_product_get_price'] = 500;
		return $priorities;
	}
}
