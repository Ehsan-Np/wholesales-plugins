<?php
/**
 * Read and update wholesale cart-level discounts and tier pricing.
 *
 * @package WooCommerceWholesalePricing\App\Services
 */

namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Modules\Wholesale\AIAssistant\Services\RoleDiscountPatchNormalizer;
use WooCommerceWholesalePricing\App\Providers\WholesaleOption;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

/**
 * Manages wholesale_multi_user_cart_discount and cart_tire_preces tier pricing.
 */
class WholesaleCartDiscountService {

	/**
	 * Get formatted cart discount settings exposed to the ability API.
	 *
	 * @return array<string, mixed>
	 */
	public function get_settings() {
		$cart_discounts = $this->get_raw_cart_discounts();
		$tier_options   = $this->get_raw_tier_options();
		$tier_raw       = isset( $tier_options['tier_pricing'] ) && is_array( $tier_options['tier_pricing'] )
			? $tier_options['tier_pricing']
			: array();

		return array(
			'cart_discount_option_key' => WholesaleOption::MULTIUSER_CART_DISCOUNT_OPTION,
			'tier_pricing_option_key'  => WholesaleOption::CART_TIER_PRICING_OPTION,
			'role_discounts'           => $this->format_role_discounts( $cart_discounts ),
			'tier_pricing'             => $this->format_tier_pricing( $tier_raw ),
		);
	}

	/**
	 * Update cart discount settings (partial merge).
	 *
	 * @param array<string, mixed> $patch Settings patch.
	 * @return array<string, mixed>|\WP_Error
	 */
	public function update_settings( array $patch ) {
		if ( empty( $patch ) ) {
			return new \WP_Error(
				'wwp_cart_discounts_missing_settings',
				__( 'Settings are required for update.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$unknown = array_diff(
			array_keys( $patch ),
			array( 'role_discounts', 'tier_pricing' )
		);
		if ( ! empty( $unknown ) ) {
			return new \WP_Error(
				'wwp_cart_discounts_invalid_field',
				sprintf(
					/* translators: %s: comma-separated field names */
					__( 'Unknown cart discount setting(s): %s', 'woocommerce-wholesale-pricing' ),
					implode( ', ', $unknown )
				),
				array( 'status' => 400 )
			);
		}

		$cart_discounts = $this->get_raw_cart_discounts();
		$tier_options   = $this->get_raw_tier_options();
		$cart_updated   = false;
		$tier_updated   = false;

		if ( isset( $patch['role_discounts'] ) ) {
			if ( ! is_array( $patch['role_discounts'] ) ) {
				return new \WP_Error(
					'wwp_cart_discounts_invalid_role_discounts',
					__( 'role_discounts must be an array.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			$result = $this->apply_role_discounts( $cart_discounts, $patch['role_discounts'] );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			$cart_discounts = $this->normalize_role_keyed_array( $result );
			$cart_updated   = true;
		}

		if ( isset( $patch['tier_pricing'] ) ) {
			if ( ! is_array( $patch['tier_pricing'] ) ) {
				return new \WP_Error(
					'wwp_cart_discounts_invalid_tier_pricing',
					__( 'tier_pricing must be an array.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			$tier_pricing_patch = RoleDiscountPatchNormalizer::filter_tier_pricing_patch( $patch['tier_pricing'] );

			if ( empty( $tier_pricing_patch ) ) {
				unset( $patch['tier_pricing'] );
			} else {
				$patch['tier_pricing'] = $tier_pricing_patch;
			}
		}

		if ( isset( $patch['tier_pricing'] ) ) {
			if ( ! isset( $tier_options['tier_pricing'] ) || ! is_array( $tier_options['tier_pricing'] ) ) {
				$tier_options['tier_pricing'] = array();
			}

			$result = $this->apply_tier_pricing( $tier_options['tier_pricing'], $patch['tier_pricing'] );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			$tier_options['tier_pricing'] = $this->normalize_role_keyed_array( $result );
			$tier_updated                 = true;
		}

		if ( $cart_updated ) {
			WholesaleSettingsHelper::update_cart_discount_settings( $cart_discounts );
			wp_cache_delete( WholesaleOption::MULTIUSER_CART_DISCOUNT_OPTION, 'options' );
		}

		if ( $tier_updated ) {
			WholesaleSettingsHelper::update_cart_tier_pricing_settings( $tier_options );
			wp_cache_delete( WholesaleOption::CART_TIER_PRICING_OPTION, 'options' );
		}

		return $this->get_settings();
	}

	/**
	 * Snapshot raw stored values for undo.
	 *
	 * @return array<string, mixed>
	 */
	public function snapshot_settings() {
		return array(
			'cart_discounts' => $this->get_raw_cart_discounts(),
			'tier_options'   => $this->get_raw_tier_options(),
		);
	}

	/**
	 * Restore a full cart discount settings snapshot.
	 *
	 * @param array<string, mixed> $snapshot Snapshot data.
	 * @return true|\WP_Error
	 */
	public function restore_settings( array $snapshot ) {
		if ( ! array_key_exists( 'cart_discounts', $snapshot ) || ! array_key_exists( 'tier_options', $snapshot ) ) {
			return new \WP_Error(
				'wwp_cart_discounts_restore_invalid_snapshot',
				__( 'Cannot restore cart discount settings: invalid snapshot.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		$cart_discounts = is_array( $snapshot['cart_discounts'] ) ? $snapshot['cart_discounts'] : array();
		$tier_options   = is_array( $snapshot['tier_options'] ) ? $snapshot['tier_options'] : array();

		WholesaleSettingsHelper::update_cart_discount_settings( $cart_discounts );
		WholesaleSettingsHelper::update_cart_tier_pricing_settings( $tier_options );

		return true;
	}

	/**
	 * Format raw stored cart discounts for ability API output.
	 * 
	 * @param array<int|string, mixed> $cart_discounts Raw cart discount settings.
	 * @return list<array<string, mixed>>
	 */
	private function format_role_discounts( array $cart_discounts ) {
		$roles     = $this->get_role_terms();
		$formatted = array();

		if ( empty( $roles ) ) {
			return $formatted;
		}

		foreach ( $roles as $role_term ) {
			$term_id = (int) $role_term->term_id;
			$entry   = array(
				'role_slug' => (string) $role_term->slug,
				'role_name' => (string) $role_term->name,
				'enabled'   => isset( $cart_discounts[ $term_id ] ) && is_array( $cart_discounts[ $term_id ] ),
			);

			if ( ! $entry['enabled'] ) {
				$formatted[] = $entry;
				continue;
			}

			$row = $cart_discounts[ $term_id ];
			$entry['discount_type']     = (string) ( isset( $row['discount_type'] ) ? $row['discount_type'] : 'percent' );
			$entry['cart_price']        = isset( $row['cart_price'] ) ? (string) $row['cart_price'] : '';
			$entry['discount_on']       = (string) ( isset( $row['discount_on'] ) ? $row['discount_on'] : 'cart_discount_amount' );
			$entry['cart_min_subtotal'] = isset( $row['cart_min_subtotal'] ) ? (string) $row['cart_min_subtotal'] : '';

			$formatted[] = $entry;
		}

		return $formatted;
	}

	/**
	 * Format raw stored tier pricing for ability API output.
	 * 
	 * @param array<int|string, mixed> $tier_raw Raw tier pricing keyed by role term_id.
	 * @return list<array<string, mixed>>
	 */
	private function format_tier_pricing( array $tier_raw ) {
		$id_map    = $this->get_role_id_slug_map();
		$formatted = array();

		foreach ( $tier_raw as $role_id => $tiers ) {
			if ( ! is_array( $tiers ) || empty( $tiers ) ) {
				continue;
			}

			$term_id = (int) $role_id;
			$slug    = isset( $id_map[ $term_id ] ) ? $id_map[ $term_id ] : '';
			if ( '' === $slug ) {
				continue;
			}

			$formatted[] = array(
				'role_slug' => $slug,
				'tiers'     => $this->normalize_tier_rows( $tiers ),
			);
		}

		return $formatted;
	}

	/**
	 * Apply role discount patches to stored cart discounts.
	 * 
	 * @param array<int|string, mixed>  $cart_discounts Stored cart discounts.
	 * @param list<array<string,mixed>> $role_discounts Role discount patches.
	 * @return array<int|string, mixed>|\WP_Error
	 */
	private function apply_role_discounts( array $cart_discounts, array $role_discounts ) {
		foreach ( $role_discounts as $item ) {
			if ( ! is_array( $item ) || empty( $item ) ) {
				continue;
			}

			$resolved = $this->resolve_role_term( $item );
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}

			$term_id = (int) $resolved['term_id'];
			$slug    = (string) $resolved['slug'];
			$stored  = isset( $cart_discounts[ $term_id ] ) && is_array( $cart_discounts[ $term_id ] )
				? $cart_discounts[ $term_id ]
				: array();

			$item = RoleDiscountPatchNormalizer::prune_role_discount_item( $item, $stored );

			if ( array_key_exists( 'enabled', $item ) && ! $this->is_enabled_value( $item['enabled'] ) ) {
				unset( $cart_discounts[ $term_id ] );
				continue;
			}

			$explicit_enable = array_key_exists( 'enabled', $item ) && $this->is_enabled_value( $item['enabled'] );
			$has_fields      = $explicit_enable
				|| isset( $item['discount_type'] )
				|| array_key_exists( 'cart_price', $item )
				|| isset( $item['discount_on'] )
				|| array_key_exists( 'cart_min_subtotal', $item );

			if ( ! $has_fields ) {
				continue;
			}

			$is_new_row = ! isset( $cart_discounts[ $term_id ] ) || ! is_array( $cart_discounts[ $term_id ] );

			$row = $is_new_row
				? array()
				: $cart_discounts[ $term_id ];

			if ( $is_new_row ) {
				$row = $this->apply_role_entry_defaults( $row, $item );
			}

			if ( isset( $item['discount_type'] ) ) {
				$type = sanitize_key( (string) $item['discount_type'] );
				if ( ! in_array( $type, array( 'percent', 'fixed' ), true ) ) {
					return new \WP_Error(
						'wwp_cart_discounts_invalid_discount_type',
						__( 'discount_type must be percent or fixed.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$row['discount_type'] = $type;
			}

			if ( array_key_exists( 'cart_price', $item ) ) {
				$price = $item['cart_price'];
				if ( '' !== $price && null !== $price && ! is_numeric( $price ) ) {
					return new \WP_Error(
						'wwp_cart_discounts_invalid_cart_price',
						__( 'cart_price must be numeric.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$row['cart_price'] = is_numeric( $price ) ? (string) $price : '';
			}

			if ( isset( $item['discount_on'] ) ) {
				$discount_on = sanitize_key( (string) $item['discount_on'] );
				if ( ! in_array( $discount_on, array( 'cart_discount_amount', 'cart_discount_quantity' ), true ) ) {
					return new \WP_Error(
						'wwp_cart_discounts_invalid_discount_on',
						__( 'discount_on must be cart_discount_amount or cart_discount_quantity.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$row['discount_on'] = $discount_on;
			}

			if ( array_key_exists( 'cart_min_subtotal', $item ) ) {
				$subtotal = $item['cart_min_subtotal'];
				if ( '' !== $subtotal && null !== $subtotal && ! is_numeric( $subtotal ) ) {
					return new \WP_Error(
						'wwp_cart_discounts_invalid_cart_min_subtotal',
						__( 'cart_min_subtotal must be numeric.', 'woocommerce-wholesale-pricing' ),
						array( 'status' => 400 )
					);
				}
				$row['cart_min_subtotal'] = is_numeric( $subtotal ) ? (string) $subtotal : '';
			}

			$cart_discounts[ $term_id ] = $this->format_role_row_for_storage( $row, $slug );
		}

		return $cart_discounts;
	}

	/**
	 * Apply tier pricing patches to stored tier pricing.
	 * 
	 * @param array<int|string, mixed>  $tier_raw Stored tier pricing.
	 * @param list<array<string,mixed>> $patches  Tier pricing patches.
	 * @return array<int|string, mixed>|\WP_Error
	 */
	private function apply_tier_pricing( array $tier_raw, array $patches ) {
		foreach ( $patches as $item ) {
			if ( ! is_array( $item ) || empty( $item ) ) {
				continue;
			}

			$resolved = $this->resolve_role_term( $item );
			if ( is_wp_error( $resolved ) ) {
				return $resolved;
			}

			$term_id = (int) $resolved['term_id'];

			if ( ! array_key_exists( 'tiers', $item ) ) {
				continue;
			}

			$tiers = $item['tiers'];
			if ( ! is_array( $tiers ) ) {
				return new \WP_Error(
					'wwp_cart_discounts_invalid_tiers',
					__( 'tiers must be an array.', 'woocommerce-wholesale-pricing' ),
					array( 'status' => 400 )
				);
			}

			if ( empty( $tiers ) ) {
				unset( $tier_raw[ $term_id ] );
				continue;
			}

			$stored_tiers = array();
			foreach ( $tiers as $tier ) {
				if ( ! is_array( $tier ) ) {
					continue;
				}

				$min      = isset( $tier['min'] ) ? $tier['min'] : '';
				$max      = isset( $tier['max'] ) ? $tier['max'] : '';
				$price    = isset( $tier['price'] ) ? $tier['price'] : '';
				$cart_max = isset( $tier['cart_max'] ) ? $tier['cart_max'] : '';

				if ( '' === $min && '' === $max && '' === $price && '' === $cart_max ) {
					continue;
				}

				foreach ( array( 'min' => $min, 'max' => $max, 'price' => $price, 'cart_max' => $cart_max ) as $field => $value ) {
					if ( '' !== $value && null !== $value && ! is_numeric( $value ) ) {
						return new \WP_Error(
							'wwp_cart_discounts_invalid_tier_field',
							sprintf(
								/* translators: %s: tier field name */
								__( 'Tier %s must be numeric.', 'woocommerce-wholesale-pricing' ),
								$field
							),
							array( 'status' => 400 )
						);
					}
				}

				$key = substr( md5( (string) wp_rand() ), 0, 10 );
				$stored_tiers[ $key ] = array(
					'min'      => is_numeric( $min ) ? (string) $min : '',
					'max'      => is_numeric( $max ) ? (string) $max : '',
					'price'    => is_numeric( $price ) ? (string) $price : '',
					'cart_max' => is_numeric( $cart_max ) ? (string) $cart_max : '',
				);
			}

			if ( empty( $stored_tiers ) ) {
				unset( $tier_raw[ $term_id ] );
			} else {
				$tier_raw[ $term_id ] = $stored_tiers;
			}
		}

		return $tier_raw;
	}

	/**
	 * Ensure role rows use the same defaults as the admin settings save handler.
	 *
	 * @param array<string, mixed> $entry Existing role row.
	 * @param array<string, mixed> $item  Incoming patch.
	 * @return array<string, mixed>
	 */
	private function apply_role_entry_defaults( array $entry, array $item ) {
		if ( ! isset( $entry['discount_type'] ) && ! isset( $item['discount_type'] ) ) {
			$entry['discount_type'] = 'percent';
		}

		if ( ! array_key_exists( 'cart_price', $entry ) && ! array_key_exists( 'cart_price', $item ) ) {
			$entry['cart_price'] = '';
		}

		if ( ! isset( $entry['discount_on'] ) && ! isset( $item['discount_on'] ) ) {
			$entry['discount_on'] = 'cart_discount_amount';
		}

		if ( ! array_key_exists( 'cart_min_subtotal', $entry ) && ! array_key_exists( 'cart_min_subtotal', $item ) ) {
			$entry['cart_min_subtotal'] = '';
		}

		return $entry;
	}

	/**
	 * Match the admin settings.php cart discount save shape exactly.
	 *
	 * @param array<string, mixed> $row  Role row before storage.
	 * @param string               $slug Taxonomy slug.
	 * @return array<string, mixed>
	 */
	private function format_role_row_for_storage( array $row, $slug ) {
		$discount_type = isset( $row['discount_type'] ) ? sanitize_key( (string) $row['discount_type'] ) : 'percent';
		if ( ! in_array( $discount_type, array( 'percent', 'fixed' ), true ) ) {
			$discount_type = 'percent';
		}

		$cart_price = array_key_exists( 'cart_price', $row ) ? $row['cart_price'] : '';
		$cart_price = is_numeric( $cart_price ) ? (string) $cart_price : '';

		$discount_on = isset( $row['discount_on'] ) ? sanitize_key( (string) $row['discount_on'] ) : 'cart_discount_amount';
		if ( ! in_array( $discount_on, array( 'cart_discount_amount', 'cart_discount_quantity' ), true ) ) {
			$discount_on = 'cart_discount_amount';
		}

		$cart_min_subtotal = array_key_exists( 'cart_min_subtotal', $row ) ? $row['cart_min_subtotal'] : '';
		$cart_min_subtotal = is_numeric( $cart_min_subtotal ) && '' !== (string) $cart_min_subtotal
			? (string) $cart_min_subtotal
			: '';

		return array(
			'slug'              => $slug,
			'discount_type'     => $discount_type,
			'cart_price'        => $cart_price,
			'discount_on'       => $discount_on,
			'cart_min_subtotal' => $cart_min_subtotal,
		);
	}

	/**
	 * Resolve a wholesale role from ability input fields.
	 *
	 * @param array<string, mixed> $item Role discount patch item.
	 * @return array{term_id: int, slug: string}|\WP_Error
	 */
	private function resolve_role_term( array $item ) {
		foreach ( array( 'role_slug', 'slug', 'role' ) as $key ) {
			if ( empty( $item[ $key ] ) ) {
				continue;
			}

			$resolved = $this->lookup_role_by_slug( (string) $item[ $key ] );
			if ( null !== $resolved ) {
				return $resolved;
			}
		}

		if ( ! empty( $item['role_name'] ) ) {
			$resolved = $this->lookup_role_by_name( (string) $item['role_name'] );
			if ( null !== $resolved ) {
				return $resolved;
			}
		}

		if ( ! empty( $item['role_id'] ) && is_numeric( $item['role_id'] ) ) {
			$term = get_term( (int) $item['role_id'], $this->get_role_taxonomy() );
			if ( $term && ! is_wp_error( $term ) ) {
				return array(
					'term_id' => (int) $term->term_id,
					'slug'    => (string) $term->slug,
				);
			}
		}

		$identifier = '';
		foreach ( array( 'role_slug', 'slug', 'role', 'role_name', 'role_id' ) as $key ) {
			if ( ! empty( $item[ $key ] ) ) {
				$identifier = (string) $item[ $key ];
				break;
			}
		}

		if ( '' === $identifier ) {
			return new \WP_Error(
				'wwp_cart_discounts_missing_role',
				__( 'Each cart role discount must include role_slug, slug, role_id, or role_name.', 'woocommerce-wholesale-pricing' ),
				array( 'status' => 400 )
			);
		}

		return new \WP_Error(
			'wwp_cart_discounts_invalid_role',
			sprintf(
				/* translators: %s: role identifier */
				__( 'Unknown wholesale role: %s', 'woocommerce-wholesale-pricing' ),
				$identifier
			),
			array( 'status' => 400 )
		);
	}

	/**
	 * Lookup a wholesale role by slug (case-insensitive, sanitized).
	 * 
	 * @param string $candidate Role slug candidate.
	 * @return array{term_id: int, slug: string}|null
	 */
	private function lookup_role_by_slug( $candidate ) {
		$candidate = trim( $candidate );
		if ( '' === $candidate ) {
			return null;
		}

		$candidate_key = sanitize_key( $candidate );

		foreach ( $this->get_role_terms() as $term ) {
			if ( $term->slug === $candidate || sanitize_key( (string) $term->slug ) === $candidate_key ) {
				return array(
					'term_id' => (int) $term->term_id,
					'slug'    => (string) $term->slug,
				);
			}
		}

		foreach ( $this->get_role_terms() as $term ) {
			if ( 0 === strcasecmp( (string) $term->name, $candidate ) ) {
				return array(
					'term_id' => (int) $term->term_id,
					'slug'    => (string) $term->slug,
				);
			}
		}

		if ( in_array( $candidate_key, array( 'wholesaler', 'default-wholesaler' ), true ) ) {
			foreach ( $this->get_role_terms() as $term ) {
				if ( WholesaleUserRoleService::DEFAULT_ROLE_SLUG === $term->slug ) {
					return array(
						'term_id' => (int) $term->term_id,
						'slug'    => (string) $term->slug,
					);
				}
			}
		}

		if ( '' !== $candidate_key ) {
			$suffix_matches = array();

			foreach ( $this->get_role_terms() as $term ) {
				$slug = (string) $term->slug;

				if ( str_ends_with( $slug, '_' . $candidate_key ) ) {
					$suffix_matches[] = $term;
				}
			}

			if ( 1 === count( $suffix_matches ) ) {
				return array(
					'term_id' => (int) $suffix_matches[0]->term_id,
					'slug'    => (string) $suffix_matches[0]->slug,
				);
			}
		}

		return null;
	}

	/**
	 * Lookup a wholesale role by display name (case-insensitive).
	 * 
	 * @param string $name Role display name.
	 * @return array{term_id: int, slug: string}|null
	 */
	private function lookup_role_by_name( $name ) {
		$name = trim( $name );
		if ( '' === $name ) {
			return null;
		}

		foreach ( $this->get_role_terms() as $term ) {
			if ( 0 === strcasecmp( (string) $term->name, $name ) ) {
				return array(
					'term_id' => (int) $term->term_id,
					'slug'    => (string) $term->slug,
				);
			}
		}

		return null;
	}

	/**
	 * Is the given value truthy for enabling a role discount?
	 * 
	 * @param mixed $value Enabled flag from ability input.
	 * @return bool
	 */
	private function is_enabled_value( $value ) {
		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_numeric( $value ) ) {
			return (int) 1 === $value;
		}

		if ( is_string( $value ) ) {
			return in_array( strtolower( trim( $value ) ), array( '1', 'true', 'yes', 'on' ), true );
		}

		return false;
	}

	/**
	 * Normalize wholesale role term IDs to integers for option storage.
	 *
	 * @param array<int|string, mixed> $rows Role-keyed rows.
	 * @return array<int|string, mixed>
	 */
	private function normalize_role_keyed_array( array $rows ) {
		$normalized = array();

		foreach ( $rows as $role_id => $row ) {
			$key                = is_numeric( $role_id ) ? (int) $role_id : $role_id;
			$normalized[ $key ] = $row;
		}

		return $normalized;
	}

	/**
	 * Normalize tier rows to ensure all fields are strings and present, even if empty.
	 * 
	 * @param array<int|string, mixed> $tiers Raw tier rows.
	 * @return list<array{min:string,max:string,price:string,cart_max:string}>
	 */
	private function normalize_tier_rows( array $tiers ) {
		$normalized = array();

		foreach ( $tiers as $tier ) {
			if ( ! is_array( $tier ) ) {
				continue;
			}

			$normalized[] = array(
				'min'      => isset( $tier['min'] ) ? (string) $tier['min'] : '',
				'max'      => isset( $tier['max'] ) ? (string) $tier['max'] : '',
				'price'    => isset( $tier['price'] ) ? (string) $tier['price'] : '',
				'cart_max' => isset( $tier['cart_max'] ) ? (string) $tier['cart_max'] : '',
			);
		}

		return $normalized;
	}

	/**
	 * Get the raw cart discount settings, which is an array keyed by wholesale role term_id.
	 * 
	 * @return array<int|string, mixed>
	 */
	private function get_raw_cart_discounts() {
		$stored = WholesaleSettingsHelper::get_cart_discount_settings();

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Get the raw cart tier pricing settings, which is an array with a single key 'tier_pricing' that contains the role-keyed tier pricing.
	 * 
	 * @return array<string, mixed>
	 */
	private function get_raw_tier_options() {
		$stored = WholesaleSettingsHelper::get_cart_tier_pricing_settings();

		return is_array( $stored ) ? $stored : array();
	}

	/**
	 * Get the wholesale role taxonomy slug, either from the WWP environment or default.
	 * 
	 * @return string
	 */
	private function get_role_taxonomy() {
		if ( function_exists( 'wwp_env' ) ) {
			$slug = (string) wwp_env()->get( 'role_taxonomy' );
			if ( '' !== $slug ) {
				return $slug;
			}
		}

		return 'wholesale_user_roles';
	}

	/**
	 * Get all wholesale role terms for the current role taxonomy.
	 * 
	 * @return list<\WP_Term>
	 */
	private function get_role_terms() {
		$terms = get_terms(
			array(
				'taxonomy'   => $this->get_role_taxonomy(),
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return array();
		}

		return $terms;
	}

	/**
	 * Get a map of wholesale role slugs to term IDs.
	 * 
	 * @return array<string, int> slug => term_id
	 */
	private function get_role_slug_map() {
		$map = array();

		foreach ( $this->get_role_terms() as $term ) {
			$map[ $term->slug ] = (int) $term->term_id;
		}

		return $map;
	}

	/**
	 * Get a map of wholesale role term IDs to slugs.
	 * 
	 * @return array<int, string> term_id => slug
	 */
	private function get_role_id_slug_map() {
		$map = array();

		foreach ( $this->get_role_terms() as $term ) {
			$map[ (int) $term->term_id ] = (string) $term->slug;
		}

		return $map;
	}
}
