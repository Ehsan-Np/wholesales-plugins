<?php
/**
 * RoleUpgradeService
 *
 * This service manages the custom 'Upgrade Account' functionality within the
 * WooCommerce My Account section. It registers a custom endpoint, adds a menu
 * item, injects custom styles for the menu icon, and provides the framework
 * for the upgrade request form and processing.
 *
 * @package    WooCommerceWholesalePricing\Services
 * @implements ServiceInterface
 */
namespace WooCommerceWholesalePricing\App\Services;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;
use WooCommerceWholesalePricing\App\Strategies\ServiceInterface;

/**
 * Service class to handle the wholesale role upgrade feature.
 *
 * Implements a custom WooCommerce My Account endpoint for users to request
 * an upgrade to a wholesale user role.
 *
 * @implements ServiceInterface
 */
class RoleUpgradeService implements ServiceInterface {



	/**
	 * Trait that provides access to wholesale pricing settings.
	 */
	use WholesaleSettings;

	/**
	 * The slug used for the custom WooCommerce My Account endpoint.
	 *
	 * @var string
	 */
	public $upgrade_endpoint;

	/**
	 * RoleUpgradeService constructor.
	 *
	 * Initializes the custom endpoint slug and registers all necessary WordPress
	 * and WooCommerce hooks for the account upgrade feature.
	 */
	public function __construct() {

		// Set the upgrade endpoint, allowing it to be filtered.
		/**
		 * Filter 
		 * 
		 * @var string value
		 * 
		 * @since 2.0.0
		 */
		$this->upgrade_endpoint = apply_filters('wholesale_upgrade_account_url', wwp_env()->get('upgrade_endpoint'));

		// WordPress and WooCommerce Hooks
		add_action('init', array( $this, 'upgrade_rewrite' ));
		add_filter('query_vars', array( $this, 'upgrade_query_var' ), 10);
		add_filter('woocommerce_account_menu_items', array( $this, 'upgrade_add_menu_item' ));
		add_action("woocommerce_account_{$this->upgrade_endpoint}_endpoint", array( $this, 'upgrade_tab_content' ));
		add_action('wp_head', array( $this, 'menu_icon_styles' ));
		add_filter('wp_kses_allowed_html', array( $this, 'filter_wp_kses_allowed_html' ), 10, 1);
	}

	/**
	 * Registers the custom rewrite endpoint for the My Account page.
	 *
	 * This method is hooked to the `init` action.
	 *
	 * @global \WP_Rewrite $wp_rewrite
	 * @return void
	 */
	public function upgrade_rewrite() {
		add_rewrite_endpoint( $this->upgrade_endpoint, EP_ROOT | EP_PAGES );

		$flushed_for = get_option( 'wwp_role_upgrade_endpoint_rewrite_flushed', '' );
		if ( $flushed_for !== $this->upgrade_endpoint ) {
			flush_rewrite_rules( false );
			update_option( 'wwp_role_upgrade_endpoint_rewrite_flushed', $this->upgrade_endpoint, false );
		}
	}

	/**
	 * Adds the custom endpoint slug to WordPress's list of recognized query variables.
	 *
	 * This method is hooked to the `query_vars` filter.
	 *
	 * @param  array $vars Array of query variables.
	 * @return array Modified array of query variables.
	 */
	public function upgrade_query_var( $vars ) {
		$vars[] = $this->upgrade_endpoint;
		return $vars;
	}

	/**
	 * Adds the custom "Upgrade Account" link to the WooCommerce My Account menu.
	 *
	 * The menu text is pulled from wholesale settings, defaulting to 'Upgrade Account'.
	 * This method is hooked to the `woocommerce_account_menu_items` filter.
	 *
	 * @param  array $items Array of existing menu items.
	 * @return array Modified array of menu items.
	 */
	public function upgrade_add_menu_item( $items ) {
		$settings = self::get_pricing_settings();
		if (isset($settings['upgrade_tab_text']) && ! empty($settings['upgrade_tab_text']) ) {
			$items[$this->upgrade_endpoint] = $settings['upgrade_tab_text'];
		} else {
			$items[$this->upgrade_endpoint] = esc_html__('Upgrade Account', 'woocommerce-wholesale-pricing');
		}

		return $items;
	}

	/**
	 * Displays the content for the custom upgrade account endpoint.
	 *
	 * This method is hooked to `woocommerce_account_{$endpoint}_endpoint`.
	 * The actual content (form, messages) would be rendered here, likely via a view.
	 *
	 * @return void
	 */
	public function upgrade_tab_content() {
		if (is_user_logged_in() ) {
			$settings      = self::get_pricing_settings();
			$post_data     = wwp_get_post_data();
			$user_id   = get_current_user_id();
			$user_info = get_userdata($user_id);
			$user_role = $user_info->roles;
			$check     = '';
			if (! empty($user_role) ) {
				foreach ( $user_role as $key => $role ) {
					if (term_exists($role, 'wholesale_user_roles') ) {
						$check = 1;
						break;
					}
				}
			}

			if ('waiting' == get_user_meta($user_id, '_user_status', true) ) {
				/**
				* Hooks
				*
				* @since 3.0
				*/
				$notice = apply_filters('wwp_pending_msg', __('Your request for upgrade account is pending.', 'woocommerce-wholesale-pricing'));
				wc_print_notice(esc_html__($notice, 'woocommerce-wholesale-pricing'), 'success');

			} elseif ('rejected' == get_user_meta($user_id, '_user_status', true) ) {

				if (! isset($post_data['wwp_register_upgrade']) ) {
					wc_print_notice(__('Your upgrade request is rejected.', 'woocommerce-wholesale-pricing'), 'error');
					$rejected_note = get_user_meta(get_current_user_id(), 'rejected_note', true);
					echo '<p class="rejected_note">' . esc_html__($rejected_note, 'woocommerce-wholesale-pricing') . '</p>';
				}

				if (isset($settings['request_again_submit']) && 'yes' == $settings['request_again_submit'] ) {
					$this->registration_insert($user_id, $check, $settings);
					if (! isset($post_data['wwp_register_upgrade']) ) {
						echo wp_kses_post($this->registration_form());
					}
				}
			} elseif ('active' == get_user_meta($user_id, '_user_status', true) ) {

				wc_print_notice(__('Your request is approved.', 'woocommerce-wholesale-pricing'), 'success');

			} elseif (! term_exists(get_user_meta($user_id, 'wholesale_role_status', true), 'wholesale_user_roles') ) {
				$this->registration_insert($user_id, $check, $settings);
			}

			if (get_user_meta($user_id, '_user_status', true) ) {
				$check = 1;
			}
			if (empty($check) ) {
				wc_print_notice(__('Apply here to upgrade your account.', 'woocommerce-wholesale-pricing'), 'notice');
				echo $this->registration_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}
	}

	/**
	 * Injects custom CSS into the head to display a Dashicon/FontAwesome icon
	 * next to the "Upgrade Account" menu item in the My Account navigation.
	 *
	 * This method is hooked to `wp_head`.
	 *
	 * @return void
	 */
	public function menu_icon_styles() {
		?>
			<style>.woocommerce-MyAccount-navigation ul li.woocommerce-MyAccount-navigation-link--<?php echo esc_attr($this->upgrade_endpoint); ?> a::before {content: '\f1de';}</style> 
		<?php 
	}

	/**
	 * Filters the allowed HTML tags for WP Kses, potentially adding support
	 * for custom tags or attributes needed in the upgrade form/content.
	 *
	 * This method is hooked to `wp_kses_allowed_html`.
	 *
	 * @param  array $allowedposttags Array of allowed HTML tags and their attributes.
	 * @return array The filtered array of allowed HTML tags.
	 */
	public function filter_wp_kses_allowed_html( $allowedposttags ) {
		if (is_account_page() ) {
			$allowed_atts                = array(
				'align'      => array(),
				'noscript'      => array(),
				'class'      => array(),
				'id'         => array(),
				'dir'        => array(),
				'lang'       => array(),
				'style'      => array(),
				'xml:lang'   => array(),
				'src'        => array(),
				'alt'        => array(),
				'href'       => array(),
				'rel'        => array(),
				'rev'        => array(),
				'target'     => array(),
				'novalidate' => array(),
				'type'       => array(),
				'name'       => array(),
				'tabindex'   => array(),
				'action'     => array(),
				'method'     => array(),
				'for'        => array(),
				'width'      => array(),
				'height'     => array(),
				'data'       => array(),
				'title'      => array(),
				'value'      => array(),
				'selected'   => array(),
				'enctype'    => array(),
				'disable'    => array(),
				'disabled'   => array(),
			);
			$allowedposttags['form']     = $allowed_atts;
			$allowedposttags['label']    = $allowed_atts;
			$allowedposttags['noscript'] = $allowed_atts;
			$allowedposttags['select']   = $allowed_atts;
			$allowedposttags['option']   = $allowed_atts;
			$allowedposttags['input']    = $allowed_atts;
			$allowedposttags['textarea'] = $allowed_atts;
			$allowedposttags['iframe']   = $allowed_atts;
			$allowedposttags['script']   = $allowed_atts;
			$allowedposttags['style']    = $allowed_atts;
			$allowedposttags['strong']   = $allowed_atts;
			$allowedposttags['small']    = $allowed_atts;
			$allowedposttags['table']    = $allowed_atts;
			$allowedposttags['span']     = $allowed_atts;
			$allowedposttags['abbr']     = $allowed_atts;
			$allowedposttags['code']     = $allowed_atts;
			$allowedposttags['pre']      = $allowed_atts;
			$allowedposttags['div']      = $allowed_atts;
			$allowedposttags['img']      = $allowed_atts;
			$allowedposttags['h1']       = $allowed_atts;
			$allowedposttags['h2']       = $allowed_atts;
			$allowedposttags['h3']       = $allowed_atts;
			$allowedposttags['h4']       = $allowed_atts;
			$allowedposttags['h5']       = $allowed_atts;
			$allowedposttags['h6']       = $allowed_atts;
			$allowedposttags['ol']       = $allowed_atts;
			$allowedposttags['ul']       = $allowed_atts;
			$allowedposttags['li']       = $allowed_atts;
			$allowedposttags['em']       = $allowed_atts;
			$allowedposttags['hr']       = $allowed_atts;
			$allowedposttags['br']       = $allowed_atts;
			$allowedposttags['tr']       = $allowed_atts;
			$allowedposttags['td']       = $allowed_atts;
			$allowedposttags['p']        = $allowed_atts;
			$allowedposttags['a']        = $allowed_atts;
			$allowedposttags['b']        = $allowed_atts;
			$allowedposttags['i']        = $allowed_atts;
		}
		return $allowedposttags;
	}

	/**
	 * Placeholder for logic to handle the insertion of user data after registration,
	 * specifically for wholesale users or upgrade requests during registration.
	 *
	 * @param  int   $user_id  The ID of the user being registered.
	 * @param  bool  $check    Check value (often for success/failure).
	 * @param  array $settings Array of settings data.
	 * @return void
	 */
	public function registration_insert( $user_id, $check, $settings ) {

		if (! isset($_POST['wwp_wholesale_registrattion_nonce']) || ( isset($_POST['wwp_wholesale_registrattion_nonce']) && ! wp_verify_nonce(wc_clean($_POST['wwp_wholesale_registrattion_nonce']), 'wwp_wholesale_registrattion_nonce') ) ) {
			return;
		}
		
		if (! isset($_POST['wwp_register_upgrade']) ) {
			return;
		}

		$post = $_POST;
		
		if (isset($_POST['g-recaptcha-response']) ) {
			/**
			* Hooks
			*
			* @since 3.0
			*/
			$notice_recaptcha = apply_filters('wwp_recaptcha_error_msg', esc_html__('Robot verification failed, please try again.', 'woocommerce-wholesale-pricing'));

			if (empty($_POST['g-recaptcha-response']) ) {
				wc_print_notice(esc_html__($notice_recaptcha, 'woocommerce-wholesale-pricing'), 'error');
				return;
			}

			$secret         = get_option('anr_admin_options')['secret_key'];
			$captcha        = wc_clean($_POST['g-recaptcha-response']);
			$verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $secret . '&response=' . $captcha); // nosemgrep: audit.php.lang.security.file.read-write-delete
			$responseData   = json_decode($verifyResponse);
			if (! $responseData->success ) {
				wc_print_notice(esc_html__($notice_recaptcha, 'woocommerce-wholesale-pricing'), 'error');
				return;
			}
		}
		if (! is_wp_error($user_id) ) {
		
			// // Get customers WC_Customer instance.
			$customer = new \WC_Customer($user_id);
		
			// Form builder fields udate in user meta
			form_builder_update_user_meta($user_id, $post);
			if (isset($_POST['wwp_wholesaler_fname']) ) {
				$billing_first_name = wc_clean($_POST['wwp_wholesaler_fname']);
				$customer->set_billing_first_name($billing_first_name);
			}
			if (isset($_POST['wwp_wholesaler_lname']) ) {
				$billing_last_name = wc_clean($_POST['wwp_wholesaler_lname']);
				$customer->set_billing_last_name($billing_last_name);
			}
			if (isset($_POST['wwp_wholesaler_company']) ) {
				$billing_company = wc_clean($_POST['wwp_wholesaler_company']);
				$customer->set_billing_company($billing_company);
			}
			if (isset($_POST['wwp_wholesaler_address_line_1']) ) {
				$billing_address_1 = wc_clean($_POST['wwp_wholesaler_address_line_1']);
				$customer->set_billing_address_1($billing_address_1);
			}
			if (isset($_POST['wwp_wholesaler_address_line_2']) ) {
				$billing_address_2 = wc_clean($_POST['wwp_wholesaler_address_line_2']);
				$customer->set_billing_address_2($billing_address_2);
			}
			if (isset($_POST['wwp_wholesaler_city']) ) {
				$billing_city = wc_clean($_POST['wwp_wholesaler_city']);
				$customer->set_billing_city($billing_city);
			}
			if (isset($_POST['billing_state']) ) {
				$billing_state = wc_clean($_POST['billing_state']);
				$customer->set_billing_state($billing_city);
			}
			if (isset($_POST['wwp_wholesaler_post_code']) ) {
				$billing_postcode = wc_clean($_POST['wwp_wholesaler_post_code']);
				$customer->set_billing_postcode($billing_city);
			}
			if (isset($_POST['billing_country']) ) {
				$billing_country = wc_clean($_POST['billing_country']);
				$customer->set_billing_country($billing_city);
			}
			if (isset($_POST['wwp_wholesaler_phone']) ) {
				$billing_phone = wc_clean($_POST['wwp_wholesaler_phone']);
				$customer->set_billing_phone($billing_phone);
			}
			if (isset($_POST['wwp_wholesaler_tax_id']) ) {
				$wwp_wholesaler_tax_id = wc_clean($_POST['wwp_wholesaler_tax_id']);
				$customer->update_meta_data('wwp_wholesaler_tax_id', $wwp_wholesaler_tax_id);
			}
			if (isset($_POST['wwp_custom_field_1']) ) {
				$wwp_custom_field_1 = wc_clean($_POST['wwp_custom_field_1']);
				$customer->update_meta_data('wwp_custom_field_1', $wwp_custom_field_1);
			}
			if (isset($_POST['wwp_custom_field_2']) ) {
				$wwp_custom_field_2 = wc_clean($_POST['wwp_custom_field_2']);
				$customer->update_meta_data('wwp_custom_field_2', $wwp_custom_field_2);
			}
			if (isset($_POST['wwp_custom_field_3']) ) {
				$wwp_custom_field_3 = wc_clean($_POST['wwp_custom_field_3']);
				$customer->update_meta_data('wwp_custom_field_3', $wwp_custom_field_3);
			}
			if (isset($_POST['wwp_custom_field_4']) ) {
				$wwp_custom_field_4 = wc_clean($_POST['wwp_custom_field_4']);
				$customer->update_meta_data('wwp_custom_field_4', $wwp_custom_field_4);
			}
			if (isset($_POST['wwp_custom_field_5']) ) {
				$wwp_custom_field_5 = wc_clean($_POST['wwp_custom_field_5']);
				$customer->update_meta_data('wwp_custom_field_5', $wwp_custom_field_5);
			}
			form_builder_update_user_meta($user_id, $_POST);
			if (! empty($_FILES['wwp_wholesaler_file_upload']) ) {
				include_once ABSPATH . 'wp-admin/includes/file.php';
				include_once ABSPATH . 'wp-admin/includes/image.php';
				include_once ABSPATH . 'wp-admin/includes/media.php';
				$attach_id = media_handle_upload('wwp_wholesaler_file_upload', $user_id);
				$customer->update_meta_data('wwp_wholesaler_file_upload', $attach_id);
			}
			if (isset($_POST['wwp_wholesaler_copy_billing_address']) ) {
				$wwp_wholesaler_copy_billing_address = wc_clean($_POST['wwp_wholesaler_copy_billing_address']);
			}
			if (isset($wwp_wholesaler_copy_billing_address) ) {
				if (isset($_POST['wwp_wholesaler_fname']) ) {
					$billing_first_name = wc_clean($_POST['wwp_wholesaler_fname']);
					$customer->set_shipping_first_name($billing_first_name);
				}
				if (isset($_POST['wwp_wholesaler_lname']) ) {
					$billing_last_name = wc_clean($_POST['wwp_wholesaler_lname']);
					$customer->set_shipping_last_name($billing_last_name);
				}
				if (isset($_POST['wwp_wholesaler_company']) ) {
					$billing_company = wc_clean($_POST['wwp_wholesaler_company']);
					$customer->set_shipping_company($billing_company);
				}
				if (isset($_POST['wwp_wholesaler_address_line_1']) ) {
					$shipping_address_1 = wc_clean($_POST['wwp_wholesaler_address_line_1']);
					$customer->set_shipping_address_1($shipping_address_1);
				}
				if (isset($_POST['wwp_wholesaler_address_line_2']) ) {
					$shipping_address_2 = wc_clean($_POST['wwp_wholesaler_address_line_2']);
					$customer->set_shipping_address_2($shipping_address_2);
				}
				if (isset($_POST['wwp_wholesaler_city']) ) {
					$shipping_city = wc_clean($_POST['wwp_wholesaler_city']);
					$customer->set_shipping_city($shipping_city);
				}
				if (isset($_POST['billing_state']) ) {
					$billing_state = wc_clean($_POST['billing_state']);
					$customer->set_shipping_state($billing_state);
				}
				if (isset($_POST['wwp_wholesaler_post_code']) ) {
					$shipping_postcode = wc_clean($_POST['wwp_wholesaler_post_code']);
					$customer->set_shipping_postcode($shipping_postcode);
				}
				if (isset($_POST['billing_country']) ) {
					$billing_country = wc_clean($_POST['billing_country']);
					$customer->set_shipping_country($billing_country);
				}
				if (isset($_POST['billing_phone']) ) {
					$billing_phone = wc_clean($_POST['billing_phone']);
					$customer->set_shipping_phone($billing_phone);
				}
			} else {
				if (isset($_POST['wwp_wholesaler_shipping_fname']) ) {
					$shipping_first_name = wc_clean($_POST['wwp_wholesaler_shipping_fname']);
					$customer->set_shipping_first_name($shipping_first_name);
				}
				if (isset($_POST['wwp_wholesaler_shipping_lname']) ) {
					$shipping_last_name = wc_clean($_POST['wwp_wholesaler_shipping_lname']);
					$customer->set_shipping_last_name($shipping_last_name);
				}
				if (isset($_POST['wwp_wholesaler_shipping_company']) ) {
					$shipping_company = wc_clean($_POST['wwp_wholesaler_shipping_company']);
					$customer->set_shipping_company($shipping_company);
				}
				if (isset($_POST['wwp_wholesaler_shipping_address_line_1']) ) {
					$shipping_address_1 = wc_clean($_POST['wwp_wholesaler_shipping_address_line_1']);
					$customer->set_shipping_address_1($shipping_address_1);
				}
				if (isset($_POST['wwp_wholesaler_shipping_address_line_2']) ) {
					$shipping_address_2 = wc_clean($_POST['wwp_wholesaler_shipping_address_line_2']);
					$customer->set_shipping_address_2($shipping_address_2);
				}
				if (isset($_POST['wwp_wholesaler_shipping_city']) ) {
					$shipping_city = wc_clean($_POST['wwp_wholesaler_shipping_city']);
					$customer->set_shipping_city($shipping_city);
				}
				if (isset($_POST['shipping_state']) ) {
					$shipping_state = wc_clean($_POST['shipping_state']);
					$customer->set_shipping_state($shipping_state);
				}
				if (isset($_POST['wwp_wholesaler_shipping_post_code']) ) {
					$shipping_postcode = wc_clean($_POST['wwp_wholesaler_shipping_post_code']);
					$customer->set_shipping_postcode($shipping_postcode);
				}
				if (isset($_POST['shipping_country']) ) {
					$shipping_country = wc_clean($_POST['shipping_country']);
					$customer->set_shipping_country($shipping_country);
				}
			}
			$id = wp_insert_post(
				array(
					'post_type'   => 'wwp_requests',
					'post_title'  => get_userdata(get_current_user_id())->data->user_nicename . ' - ' . get_current_user_id() . ' - Upgrade Request',
					'post_status' => 'publish',
				)
			);
			if (! is_wp_error($id) ) {
			
				
				update_post_meta($id, '_user_id', $user_id);
				

				if (! isset($settings['disable_auto_role']) || ( isset($settings['disable_auto_role']) && 'no' == $settings['disable_auto_role'] ) ) {
					update_post_meta($id, '_user_status', 'active');
					$customer->update_meta_data('_user_status', 'active');
					$u        = new \WP_User($user_id);
					$wp_roles = new \WP_Roles();
					$names    = $wp_roles->get_names();
					foreach ( $names as $key => $value ) {
						$u->remove_role($key);
					}
					if (isset($settings['wholesale_role']) && 'single' == $settings['wholesale_role'] ) {

						wp_set_object_terms($id, 'default_wholesaler', 'wholesale_user_roles', true);
						$u->add_role('default_wholesaler');
					} elseif (isset($settings['default_multipe_wholesale_roles']) ) {
						$u->add_role($settings['default_multipe_wholesale_roles']);
						wp_set_object_terms($id, $settings['default_multipe_wholesale_roles'], 'wholesale_user_roles', true);
					} else {
						$u->add_role('default_wholesaler');
						wp_set_object_terms($id, 'default_wholesaler', 'wholesale_user_roles', true);
					}

					if (! empty($role) ) {
						
						/**
						* Hooks
						*
						* @since 3.0
						*/
						do_action('wwp_wholesale_user_request_approved', $user_id);
						update_post_meta($id, '_approval_notification', 'sent');
					}
				} else {
					update_post_meta($id, '_user_status', 'waiting');
					$customer->update_meta_data('_user_status', 'waiting');
				}
				$customer->save();
				/**
				* Hooks
				*
				* @since 3.0
				*/
				do_action('wwp_wholesale_new_request_submitted', $user_id);
			}
			// On success
			if (! is_wp_error($user_id) ) {
				/**
				* Hooks
				*
				* @since 3.0
				*/
				$notice = apply_filters('wwp_success_msg', esc_html__('Your request for upgrade account is submitted.', 'woocommerce-wholesale-pricing'));
				wc_print_notice(esc_html__($notice, 'woocommerce-wholesale-pricing'), 'success');
			} else {
				/**
				* Hooks
				*
				* @since 3.0
				*/
				$notice = apply_filters('wwp_error_msg', esc_html__($user_id->get_error_message(), 'woocommerce-wholesale-pricing'));
				wc_print_notice(esc_html__($notice, 'woocommerce-wholesale-pricing'), 'error');
			}
			wp_safe_redirect(wp_get_referer());
		}
		$check = 1;
	}

	/**
	 * Renders the HTML fields for wholesale registration form.
	 *
	 * This function retrieves the registration form fields based on settings enabled.
	 *
	 * @return void
	 */
	public function registration_form() {

		global $woocommerce;
		$countries_obj         = new \WC_Countries();
		$countries             = $countries_obj->__get('countries');
		$default_country       = $countries_obj->get_base_country();
		$default_county_states = $countries_obj->get_states($default_country);
		$errors                = array();

		wp_enqueue_script('address-i18n');
		wp_enqueue_script('wc-country-select');

		$username      = '';
		$email         = '';
		$fname         = '';
		$lname         = '';
		$company       = '';
		$addr1         = '';
		$settings      = self::get_pricing_settings();
		$registrations = self::get_registration_settings();
		ob_start();
		if (isset($settings['wholesale_css']) ) {
			?>
		<style type="text/css">
			<?php echo wp_kses_post($settings['wholesale_css']); ?>
		</style>
			<?php
		}
		?>
		<div class="wwp_wholesaler_registration">
		
			<form method="post" action="" enctype="multipart/form-data">
				<?php wp_nonce_field('wwp_wholesale_registrattion_nonce', 'wwp_wholesale_registrattion_nonce'); ?>
				<?php
				if (empty($registrations) || ( isset($registrations['custommer_billing_address']) && 'yes' == $registrations['custommer_billing_address'] ) ) {
					?>
					<h2><?php esc_html_e('Customer billing address', 'woocommerce-wholesale-pricing'); ?></h2>
					<?php
					if (isset($registrations['enable_billing_first_name']) && 'yes' == $registrations['enable_billing_first_name'] ) {
						?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
							<label for="wwp_wholesaler_fname"> <?php echo ! empty($registrations['billing_first_name']) ? esc_html($registrations['billing_first_name']) : esc_html__('First Name', 'woocommerce-wholesale-pricing'); ?> <span class="required">*</span></label>
							<input type="text" name="wwp_wholesaler_fname" id="wwp_wholesaler_fname" value="<?php esc_attr_e($fname); ?>" required>
						</p>
						<?php
					}
					if (isset($registrations['enable_billing_last_name']) && 'yes' == $registrations['enable_billing_last_name'] ) {
						?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
							<label for="wwp_wholesaler_lname"><?php echo ! empty($registrations['billing_last_name']) ? esc_html($registrations['billing_last_name']) : esc_html__('Last Name', 'woocommerce-wholesale-pricing'); ?> <span class="required">*</span></label>
							<input type="text" name="wwp_wholesaler_lname" id="wwp_wholesaler_lname" value="<?php esc_attr_e($lname); ?>" required>
						</p>
						<?php
					}
					if (isset($registrations['enable_billing_company']) && 'yes' == $registrations['enable_billing_company'] ) {
						?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
							<label for="wwp_wholesaler_fname"><?php echo ! empty($registrations['billing_company']) ? esc_html($registrations['billing_company']) : esc_html__('Company', 'woocommerce-wholesale-pricing'); ?> <span class="required">*</span></label>
							<input type="text" name="wwp_wholesaler_company" id="wwp_wholesaler_company" value="<?php esc_attr_e($company); ?>"  required>
						</p>
						<?php
					}
					if (isset($registrations['enable_billing_address_1']) && 'yes' == $registrations['enable_billing_address_1'] ) {
						?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
							<label for="wwp_wholesaler_address_line_1"><?php echo ! empty($registrations['billing_address_1']) ? esc_html($registrations['billing_address_1']) : esc_html__('Address line 1', 'woocommerce-wholesale-pricing'); ?> <span class="required">*</span></label>
							<input type="text" name="wwp_wholesaler_address_line_1" id="wwp_wholesaler_address_line_1" value="<?php esc_attr_e($addr1); ?>" required>
						</p>
						<?php
					}
					if (isset($registrations['enable_billing_address_2']) && 'yes' == $registrations['enable_billing_address_2'] ) {
						?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
							<label for="wwp_wholesaler_address_line_2"><?php echo ! empty($registrations['billing_address_2']) ? esc_html($registrations['billing_address_2']) : esc_html__('Address line 2', 'woocommerce-wholesale-pricing'); ?></label>
							<input type="text" name="wwp_wholesaler_address_line_2" id="wwp_wholesaler_address_line_2">
						</p>
						<?php
					}
					if (isset($registrations['enable_billing_city']) && 'yes' == $registrations['enable_billing_city'] ) {
						?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
							<label for="wwp_wholesaler_city"><?php echo ! empty($registrations['billing_city']) ? esc_html($registrations['billing_city']) : esc_html__('City', 'woocommerce-wholesale-pricing'); ?><span class="required">*</span></label>
							<input type="text" name="wwp_wholesaler_city" id="wwp_wholesaler_city" required>
						</p>
						<?php
					}
					if (isset($registrations['enable_billing_post_code']) && 'yes' == $registrations['enable_billing_post_code'] ) {
						?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
							<label for="wwp_wholesaler_post_code"><?php echo ! empty($registrations['billing_post_code']) ? esc_html($registrations['billing_post_code']) : esc_html__('Postcode / ZIP', 'woocommerce-wholesale-pricing'); ?> <span class="required">*</span></label>
							<input type="text" name="wwp_wholesaler_post_code" id="wwp_wholesaler_post_code" required>
						</p>
						<?php
					}
					?>
					<div class="parent"> 
					<?php
					if (isset($registrations['enable_billing_country']) && 'yes' == $registrations['enable_billing_country'] ) {
						?>
						<<?php wwp_elements('p'); ?> class="<?php echo wp_kses_post(registration_form_class(' woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide wwp_form_css_row ')); ?>">
						<?php
							woocommerce_form_field(
								'billing_country',
								array(
									'type'        => 'country',
									'class'       => array( 'chzn-drop' ),
									'label'       => !empty($registrations['billing_countries']) ? esc_html__(__($registrations['billing_countries']), 'woocommerce-wholesale-pricing') : esc_html__('Select billing country', 'woocommerce-wholesale-pricing'),
									'default'     => $default_country,
									'options'     => $countries,
								)
							);
						?>
						</<?php wwp_elements('p'); ?>>
						
						<?php
					}
					if (isset($registrations['enable_billing_state']) && 'yes' == $registrations['enable_billing_state'] ) {
						?>
						<<?php wwp_elements('p'); ?> class="<?php echo wp_kses_post(registration_form_class(' woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide wwp_form_css_row ')); ?>">
							<?php 
							woocommerce_form_field(
								'billing_state',
								array(
									'type'       => 'state',
									'class'      => array( 'chzn-drop' ),
									'label'      => !empty($registrations['billing_state']) ? esc_html__(__($registrations['billing_state']), 'woocommerce-wholesale-pricing') : esc_html__('State / County or state code', 'woocommerce-wholesale-pricing'),
									'options'     => $default_county_states,
									)
							);
							?>
						</<?php wwp_elements('p'); ?>>
						
						<?php
					}
					?>
						</div> 
					<?php 
					if (isset($registrations['enable_billing_phone']) && 'yes' == $registrations['enable_billing_phone'] ) {
						?>
						<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
							<label for="wwp_wholesaler_phone"><?php echo ! empty($registrations['billing_phone']) ? esc_html($registrations['billing_phone']) : esc_html__('Phone', 'woocommerce-wholesale-pricing'); ?> <span class="required">*</span></label>
							<input type="text" name="wwp_wholesaler_phone" id="wwp_wholesaler_phone" required>
						</p>
						<?php
					}
				}
				if (empty($registrations) || ( isset($registrations['custommer_shipping_address']) && 'yes' == $registrations['custommer_shipping_address'] ) ) {
					?>
					<h2><?php esc_html_e('Customer shipping address', 'woocommerce-wholesale-pricing'); ?></h2>
					<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
						<label for="wwp_wholesaler_copy_billing_address"><?php esc_html_e('Copy from billing address', 'woocommerce-wholesale-pricing'); ?></label>
						<input type="checkbox" name="wwp_wholesaler_copy_billing_address" id="wwp_wholesaler_copy_billing_address" value="yes" >
					</p>
					<div id="wholesaler_shipping_address"> 
						<?php
						if (isset($registrations['enable_shipping_first_name']) && 'yes' == $registrations['enable_shipping_first_name'] ) {
							?>
							<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
								<label for="wwp_wholesaler_shipping_lname"><?php echo ! empty($registrations['shipping_first_name']) ? esc_html($registrations['shipping_first_name']) : esc_html__('First Name', 'woocommerce-wholesale-pricing'); ?> <span class="required">*</span></label>
								<input type="text" name="wwp_wholesaler_shipping_fname" id="wwp_wholesaler_shipping_fname" >
							</p>
							<?php
						}
						if (isset($registrations['enable_shipping_last_name']) && 'yes' == $registrations['enable_shipping_last_name'] ) {
							?>
							<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
								<label for="wwp_wholesaler_shipping_fname"> <?php echo ! empty($registrations['shipping_last_name']) ? esc_html($registrations['shipping_last_name']) : esc_html__('Last Name', 'woocommerce-wholesale-pricing'); ?> <span class="required">*</span> </label>
								<input type="text" name="wwp_wholesaler_shipping_lname" id="wwp_wholesaler_shipping_lname" >
							</p>
							<?php
						}
						if (isset($registrations['enable_shipping_company']) && 'yes' == $registrations['enable_shipping_company'] ) {
							?>
							<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
								<label for="wwp_wholesaler_shipping_company"><?php echo ! empty($registrations['shipping_company']) ? esc_html($registrations['shipping_company']) : esc_html__('Company', 'woocommerce-wholesale-pricing'); ?> <span class="required">*</span></label>
								<input type="text" name="wwp_wholesaler_shipping_company" id="wwp_wholesaler_shipping_company" >
							</p>
							<?php
						}
						if (isset($registrations['enable_shipping_address_1']) && 'yes' == $registrations['enable_shipping_address_1'] ) {
							?>
							<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
								<label for="wwp_wholesaler_shipping_address_line_1"><?php echo ! empty($registrations['shipping_address_1']) ? esc_html($registrations['shipping_address_1']) : esc_html__('Address line 1', 'woocommerce-wholesale-pricing'); ?> <span class="required">*</span></label>
								<input type="text" name="wwp_wholesaler_shipping_address_line_1" id="wwp_wholesaler_shipping_address_line_1" >
							</p>
							<?php
						}
						if (isset($registrations['enable_shipping_address_2']) && 'yes' == $registrations['enable_shipping_address_2'] ) {
							?>
							<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
								<label for="wwp_wholesaler_shipping_address_line_2"><?php echo ! empty($registrations['shipping_address_2']) ? esc_html($registrations['shipping_address_2']) : esc_html__('Address line 2', 'woocommerce-wholesale-pricing'); ?></label>
								<input type="text" name="wwp_wholesaler_shipping_address_line_2" id="wwp_wholesaler_shipping_address_line_2" >
							</p>
							<?php
						}
						if (isset($registrations['enable_shipping_city']) && 'yes' == $registrations['enable_shipping_city'] ) {
							?>
							<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
								<label for="wwp_wholesaler_shipping_city"><?php echo ! empty($registrations['shipping_city']) ? esc_html($registrations['shipping_city']) : esc_html__('City', 'woocommerce-wholesale-pricing'); ?> <span class="required">*</span></label>
								<input type="text" name="wwp_wholesaler_shipping_city" id="wwp_wholesaler_shipping_city" >
							</p>
							<?php
						}
						if (isset($registrations['enable_shipping_post_code']) && 'yes' == $registrations['enable_shipping_post_code'] ) {
							?>
							<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
								<label for="wwp_wholesaler_shipping_post_code"><?php echo ! empty($registrations['shipping_post_code']) ? esc_html($registrations['shipping_post_code']) : esc_html__('Postcode / ZIP', 'woocommerce-wholesale-pricing'); ?> <span class="required">*</span></label>
								<input type="text" name="wwp_wholesaler_shipping_post_code" id="wwp_wholesaler_shipping_post_code">
							</p>
							<?php
						}
						if (isset($registrations['enable_shipping_country']) && 'yes' == $registrations['enable_shipping_country'] ) {
							?>
							<<?php wwp_elements('p'); ?> class="<?php echo wp_kses_post(registration_form_class(' woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide wwp_form_css_row ')); ?>">
							<?php
								woocommerce_form_field(
									'shipping_country',
									array(
										'type'        => 'country',
										'class'       => array( 'chzn-drop' ),
										'label'       => esc_html__('Select shipping country', 'woocommerce-wholesale-pricing'),
										'placeholder' => esc_html__('Enter something', 'woocommerce-wholesale-pricing'),
										'default'     => $default_country,
										'options'     => $countries,
									)
								);
							?>
							</<?php wwp_elements('p'); ?>>
							
							<?php
						}
						if (isset($registrations['enable_shipping_state']) && 'yes' == $registrations['enable_shipping_state'] ) {
							?>
							<<?php wwp_elements('p'); ?> class="<?php echo wp_kses_post(registration_form_class(' woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide wwp_form_css_row ')); ?>">
									
								<?php 
									woocommerce_form_field(
										'shipping_state',
										array(
											'type'       => 'state',
											'class'      => array( 'chzn-drop' ),
											'label'      => ! empty($registrations['shipping_state']) ? esc_html__(__($registrations['shipping_state']), 'woocommerce-wholesale-pricing') : esc_html__('State / County', 'woocommerce-wholesale-pricing'),
											'options'     => $default_county_states,
											)
									);
								?>
							</<?php wwp_elements('p'); ?>>
							
							<?php
						}
						?>
					</div>
					<?php
				}
				if (isset($registrations['enable_tex_id']) && 'yes' == $registrations['enable_tex_id'] ) {
					$required = ( ! empty($registrations['required_tex_id']) && 'yes' == $registrations['required_tex_id'] ) ? 'required' : '';
					?>
					<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
						<label for="wwp_wholesaler_tax_id">
							<?php echo ! empty($registrations['woo_tax_id']) ? esc_html($registrations['woo_tax_id']) : esc_html__('Tax ID', 'woocommerce-wholesale-pricing'); ?>
							<?php
							if ('required' == $required ) {
								echo '<span class="required">*</span>';
							}
							?>
						</label>
						<input type="text" name="wwp_wholesaler_tax_id" id="wwp_wholesaler_tax_id" <?php esc_attr_e($required); ?>>
					</p>
					<?php
				}
				if (isset($registrations['enable_file_upload']) && 'yes' == $registrations['enable_file_upload'] ) {
					$required = ( ! empty($registrations['required_file_upload']) && 'yes' == $registrations['required_file_upload'] ) ? 'required' : '';
					?>
					<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
						<label for="wwp_wholesaler_file_upload"><?php echo ! empty($registrations['woo_file_upload']) ? esc_html($registrations['woo_file_upload']) : esc_html__('File Upload', 'woocommerce-wholesale-pricing'); ?>
						<?php
						if ('required' == $required ) {
							echo '<span class="required">*</span>';
						}
						?>
						</label>
						<input type="file" name="wwp_wholesaler_file_upload" id="wwp_wholesaler_file_upload" <?php esc_attr_e($required); ?> value="">
					</p>
					<?php
				}
				echo render_form_builder('get_option', get_current_user_id()); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

				?>
				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">                  
				<?php
				if (isset(get_option('anr_admin_options')['enabled_forms']) ) {
					if (in_array('wwp_wholesale_recaptcha', get_option('anr_admin_options')['enabled_forms']) ) {
					
						/**
						* Hooks
						*
						* @since 3.0
						*/
						do_action('anr_captcha_form_field');
					}
				}
				?>
				</p>
				<p class="woocomerce-FormRow form-row">                   
					<input type="submit" class="woocommerce-Button button" name="wwp_register_upgrade" value="<?php esc_html_e('Register', 'woocommerce-wholesale-pricing'); ?>">
				</p>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Dependency resolution check.
	 *
	 * Determines if this service should be initialized based on the 'enable_upgrade'
	 * setting in the wholesale pricing configuration.
	 *
	 * @return bool True if the service should be active, false otherwise.
	 */
	public static function resolveDependency() {
		$settings = self::get_pricing_settings();
		return isset($settings['enable_upgrade']) && 'yes' == $settings['enable_upgrade'];
	}
}
