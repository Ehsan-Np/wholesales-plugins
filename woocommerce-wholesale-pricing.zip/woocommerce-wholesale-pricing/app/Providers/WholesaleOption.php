<?php
/**
 * WholesaleOption class.
 *
 * Provides a centralized registry of constant keys used for storing and retrieving
 * wholesale pricing and registration settings in the WordPress options table.
 *
 * @package    WooCommerceWholesalePricing\Providers
 */
namespace WooCommerceWholesalePricing\App\Providers;

/**
 * Defines constants for all WooCommerce Wholesale Pricing plugin option keys.
 *
 * These keys are used globally to access various settings and data arrays
 * stored in the wp_options table.
 */
class WholesaleOption {

	/**
	 * Key for general plugin pricing options (e.g., global settings, visibility).
	 *
	 * @var string
	 */
	const PRICING_OPTION            = 'wwp_wholesale_pricing_options';

	/**
	 * Key for multi-user/role-based pricing configurations (specific discounts per role).
	 *
	 * @var string
	 */
	const MULTIUSER_PRICING_OPTION  = 'wholesale_multi_user_pricing';

	/**
	 * Key for wholesale user registration and approval options.
	 *
	 * @var string
	 */
	const REGISTRATION_OPTION       = 'wwp_wholesale_registration_options';

	/**
	 * Key for cart-level tier pricing rules and data.
	 *
	 * @var string
	 */
	const CART_TIER_PRICING_OPTION  = 'cart_tire_preces';

	/**
	 * Key for per-role wholesale cart discount settings.
	 *
	 * @var string
	 */
	const MULTIUSER_CART_DISCOUNT_OPTION = 'wholesale_multi_user_cart_discount';

	/**
	 * Key for quote general settings.
	 *
	 * @var string
	 */
	const QUOTE_GENERAL_OPTION      = 'wc_quote_general';
	
	/**
	 * Key for quote notifications settings.
	 *
	 * @var string
	 */
	const QUOTE_NOTIFICATIONS_OPTION = 'wc_quote_notifications';

	/**
	 * Key for quote PDF settings.
	 *
	 * @var string
	 */
	const QUOTE_PDF_OPTION = 'wc_quote_pdf';

	const QUOTE_CUSTOMIZATION_OPTION = 'wc_quote_customization';

	/**
	 * Key for AI Assistant settings.
	 *
	 * @var string
	 */
	const AI_ASSISTANT_OPTION = 'wwp_ai_assistant_settings';

	/**
	 * Table name suffix for AI Assistant change history (without wp prefix).
	 *
	 * @var string
	 */
	const AI_CHANGE_HISTORY_TABLE = 'wwp_ai_change_history';

	/**
	 * Table name suffix for sales agent commissions (without wp prefix).
	 *
	 * @var string
	 */
	const AGENTS_COMMISSIONS_TABLE = 'wc_agents_commissions';
}
