<?php
/**
 * WholesaleSettings trait.
 *
 * Provides static helper methods for easily retrieving and updating all
 * primary plugin options stored in the WordPress database.
 * This trait is intended for use by any class that needs to access or modify
 * plugin settings.
 *
 * @package    WooCommerceWholesalePricing\Providers
 */
namespace WooCommerceWholesalePricing\App\Providers;

/**
 * Trait WholesaleSettings
 *
 * Provides a set of static methods to interact with the plugin's
 * primary option keys defined in the WholesaleOption class.
 */
trait WholesaleSettings {


	/**
	 * Retrieves the general plugin pricing settings array.
	 *
	 * @return array|false The array of general pricing options, or an empty array if not found.
	 */
	public static function get_pricing_settings() {
		return get_option(WholesaleOption::PRICING_OPTION, array());
	}

	/**
	 * Retrieves the multi-user/role-based pricing settings array.
	 *
	 * @return array The array of multi-user pricing options, or an empty array if not found.
	 */
	public static function get_multiuser_pricing_settings() {
		return get_option(WholesaleOption::MULTIUSER_PRICING_OPTION, array());
	}

	/**
	 * Retrieves the wholesale user registration settings array.
	 *
	 * @return array The array of registration options, or an empty array if not found.
	 */
	public static function get_registration_settings() {
		return get_option(WholesaleOption::REGISTRATION_OPTION, array());
	}

	/**
	 * Retrieves the cart tier pricing settings array.
	 *
	 * @return array The array of cart tier pricing options, or an empty array if not found.
	 */
	public static function get_cart_tier_pricing_settings() {
		return get_option(WholesaleOption::CART_TIER_PRICING_OPTION, array());
	}

	/**
	 * Retrieves per-role wholesale cart discount settings.
	 *
	 * @return array The array of cart discount options, or an empty array if not found.
	 */
	public static function get_cart_discount_settings() {
		return get_option(WholesaleOption::MULTIUSER_CART_DISCOUNT_OPTION, array());
	}

	/**
	 * Updates the general plugin pricing settings.
	 *
	 * @param  mixed $option_value The new value to store.
	 * @return void
	 */
	public static function update_pricing_settings( $option_value ) {
		update_option(WholesaleOption::PRICING_OPTION, $option_value);
	}

	/**
	 * Updates the multi-user/role-based pricing settings.
	 *
	 * @param  mixed $option_value The new value to store.
	 * @return void
	 */
	public static function update_multiuser_pricing_settings( $option_value ) {
		update_option(WholesaleOption::MULTIUSER_PRICING_OPTION, $option_value);
	}

	/**
	 * Updates the wholesale user registration settings.
	 *
	 * @param  mixed $option_value The new value to store.
	 * @return void
	 */
	public static function update_registration_settings( $option_value ) {
		update_option(WholesaleOption::REGISTRATION_OPTION, $option_value);
	}

	/**
	 * Updates the cart tier pricing settings.
	 *
	 * @param  mixed $option_value The new value to store.
	 * @return void
	 */
	public static function update_cart_tier_pricing_settings( $option_value ) {
		update_option(WholesaleOption::CART_TIER_PRICING_OPTION, $option_value);
	}

	/**
	 * Updates per-role wholesale cart discount settings.
	 *
	 * @param  mixed $option_value The new value to store.
	 * @return void
	 */
	public static function update_cart_discount_settings( $option_value ) {
		update_option(WholesaleOption::MULTIUSER_CART_DISCOUNT_OPTION, $option_value);
	}

	public static function update_quote_general_settings( $option_value ) {
		update_option(WholesaleOption::QUOTE_GENERAL_OPTION, $option_value);
	}

	public static function update_quote_notifications_settings( $option_value ) {
		update_option(WholesaleOption::QUOTE_NOTIFICATIONS_OPTION, $option_value);
	}

	public static function update_quote_pdf_settings( $option_value ) {
		update_option(WholesaleOption::QUOTE_PDF_OPTION, $option_value);
	}

	public static function update_quote_customization_settings( $option_value ) {
		update_option(WholesaleOption::QUOTE_CUSTOMIZATION_OPTION, $option_value);
	}

	public static function get_quote_general_settings() {
		return get_option(WholesaleOption::QUOTE_GENERAL_OPTION, array());
	}

	public static function get_quote_notifications_settings() {
		return get_option(WholesaleOption::QUOTE_NOTIFICATIONS_OPTION, array());
	}

	public static function get_quote_pdf_settings() {
		return get_option(WholesaleOption::QUOTE_PDF_OPTION, array());
	}

	public static function get_quote_customization_settings() {
		return get_option(WholesaleOption::QUOTE_CUSTOMIZATION_OPTION, array());
	}
}
