<?php
/**
 * WholesaleSettingsHelper class.
 *
 * A simple utility class used primarily to instantiate and provide access to the
 * static getter/setter methods defined in the WholesaleSettings trait
 * without requiring those methods to be added to an existing core class.
 *
 * @package    WooCommerceWholesalePricing\Providers
 */
namespace WooCommerceWholesalePricing\App\Providers;

/**
 * WholesaleSettingsHelper
 *
 * A container class that uses the WholesaleSettings trait to provide a dedicated
 * entry point for accessing and managing plugin options.
 */
class WholesaleSettingsHelper {

	use WholesaleSettings;
}
