<?php

use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

if ( ! function_exists('get_quotes_count') ) {
	function get_quotes_count( $status ) {
		global $wpdb;
		return absint($wpdb->get_var($wpdb->prepare("SELECT COUNT( * ) FROM {$wpdb->posts} WHERE post_type = 'wc-quote' AND post_status = %s", $status)));
	}
}

if ( ! function_exists('check_quote_status') ) {
	function check_quote_status() {
		$settings = get_option( 'wc_quote_general', true );
		return (bool) isset( $settings['custom_quote_status'] ) && '1' === $settings['custom_quote_status'];
	}
}

if ( ! function_exists('get_admin_user_ids') ) {
	function get_admin_user_ids() {
		$users = get_users(
		array(
		'role' => 'Administrator',
		'fields' => 'ID', // Only return user IDs
		)
	);

	return $users;
	}
}


if ( ! function_exists('quote_fields') ) {
	function get_quote_fields() {
		static $fields = null;

		if ( null !== $fields ) {
			return $fields;
		}

		$builder = json_decode( get_option( 'wc_quote_form_builder' ), true );
		$fields  = ( ! empty( $builder ) && is_array( $builder ) ) ? $builder : array();

		return $fields;
	}
}

if ( ! function_exists( 'clear_quote_rules_cache' ) ) {
	/**
	 * Clear cached quote rules after rule changes.
	 *
	 * @return void
	 */
	function clear_quote_rules_cache() {
		delete_transient( 'wwp_quote_rules_active' );
		if ( function_exists( 'wwp_purge_litespeed_cache' ) ) {
			wwp_purge_litespeed_cache();
		}
	}
}

if ( ! function_exists('get_quote_rules') ) {
	function get_quote_rules() {
		static $request_cache = null;

		if ( null !== $request_cache ) {
			return $request_cache;
		}

		$cached = get_transient( 'wwp_quote_rules_active' );
		if ( false !== $cached && is_array( $cached ) && ! empty( $cached ) ) {
			if ( is_numeric( $cached[0] ) ) {
				$request_cache = array();
				foreach ( $cached as $rule_id ) {
					$post = get_post( (int) $rule_id );
					if ( $post ) {
						$request_cache[] = $post;
					}
				}
			} else {
				$request_cache = $cached;
			}

			return $request_cache;
		}

		$args = array(
			'post_type'        => wwp_env()->get( 'quote_rules_slug' ),
			'post_status'      => 'publish',
			'numberposts'      => -1,
			'orderby'          => 'menu_order',
			'order'            => 'ASC',
			'suppress_filters' => true,
			'meta_query'       => array(
				array(
					'key'     => 'enable_rule',
					'value'   => '1',
					'compare' => '=',
				),
			),
		);

		$request_cache = get_posts( $args );
		set_transient( 'wwp_quote_rules_active', wp_list_pluck( $request_cache, 'ID' ), DAY_IN_SECONDS );

		return $request_cache;
	}
}

if ( ! function_exists( 'clear_quote_custom_statuses_cache' ) ) {
	/**
	 * Clear cached custom quote status posts.
	 *
	 * @return void
	 */
	function clear_quote_custom_statuses_cache() {
		delete_transient( 'wwp_quote_custom_statuses' );
	}
}

if ( ! function_exists( 'get_quote_custom_status_posts' ) ) {
	/**
	 * Return wc-quote-status posts with request and transient caching.
	 *
	 * @return array
	 */
	function get_quote_custom_status_posts() {
		static $request_cache = null;

		if ( null !== $request_cache ) {
			return $request_cache;
		}

		if ( ! check_quote_status() ) {
			$request_cache = array();
			return $request_cache;
		}

		$cached = get_transient( 'wwp_quote_custom_statuses' );
		if ( false !== $cached && is_array( $cached ) ) {
			$request_cache = $cached;
			return $request_cache;
		}

		$request_cache = get_posts(
			array(
				'post_type'   => 'wc-quote-status',
				'post_status' => 'any',
				'numberposts' => -1,
				'orderby'     => array(
					'menu_order' => 'DESC',
					'modified'   => 'ASC',
				),
			)
		);

		set_transient( 'wwp_quote_custom_statuses', $request_cache, DAY_IN_SECONDS );

		return $request_cache;
	}
}

if ( ! function_exists( 'get_quote_page_id' ) ) {
	/**
	 * Resolve the quote request page ID without scanning all pages on every request.
	 *
	 * @return int
	 */
	function get_quote_page_id() {
		$quote_general = get_option( 'wc_quote_general', array() );
		$quote_page    = isset( $quote_general['quote_page'] ) ? $quote_general['quote_page'] : '';

		if ( ! empty( $quote_page ) ) {
			return (int) $quote_page;
		}

		$cached = get_option( 'wwp_resolved_quote_page_id', 0 );
		if ( $cached ) {
			return (int) $cached;
		}

		$shortcode = wwp_env()->get( 'quote_page_shortcode' );
		$pages     = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'numberposts'    => -1,
				'fields'         => 'ids',
			)
		);

		foreach ( $pages as $page_id ) {
			$content = get_post_field( 'post_content', $page_id );
			if ( $content && has_shortcode( $content, $shortcode ) ) {
				update_option( 'wwp_resolved_quote_page_id', (int) $page_id, false );
				return (int) $page_id;
			}
		}

		return 0;
	}
}

if ( ! function_exists( 'wwp_should_enqueue_quote_assets' ) ) {
	/**
	 * Determine whether quote frontend assets should load on the current request.
	 *
	 * @return bool
	 */
	function wwp_should_enqueue_quote_assets() {
		if ( is_admin() ) {
			return false;
		}

		if ( is_shop() || is_product() || is_cart() || is_checkout() || is_account_page() ) {
			return true;
		}

		if ( function_exists( 'is_quote' ) && is_quote() ) {
			return true;
		}

		if ( get_query_var( 'download_pdf' ) ) {
			return true;
		}

		$quote_general = get_option( 'wc_quote_general', false );
		if ( isset( $quote_general['mini_cart'] ) && '1' === $quote_general['mini_cart'] ) {
			return true;
		}

		return false;
	}
}

if ( ! function_exists( 'quote_product_matches_terms' ) ) {
	/**
	 * Check if a product belongs to any of the given category or tag term IDs.
	 *
	 * @param int    $product_id Product ID.
	 * @param string $type       Either category or tag.
	 * @param array  $term_ids   Term IDs to check.
	 * @return bool
	 */
	function quote_product_matches_terms( $product_id, $type, $term_ids ) {
		if ( empty( $term_ids ) || ! is_array( $term_ids ) ) {
			return false;
		}

		$taxonomy = ( 'category' === $type ) ? 'product_cat' : 'product_tag';

		foreach ( $term_ids as $term_id ) {
			$term_id = (int) $term_id;
			if ( $term_id && has_term( $term_id, $taxonomy, $product_id ) ) {
				return true;
			}
		}

		return false;
	}
}


if ( ! function_exists('quote_check_rule_for_product') ) {
	function quote_check_rule_for_product( $product_id, $rule_id ) {
		static $result_cache = array();
		static $in_progress  = array();

		$product_id = (int) $product_id;
		$rule_id    = (int) $rule_id;

		if ( 'product_variation' === get_post_type( $product_id ) ) {
			$product_id = (int) wp_get_post_parent_id( $product_id );
		}

		$cache_key = $product_id . ':' . $rule_id;
		if ( array_key_exists( $cache_key, $result_cache ) ) {
			return $result_cache[ $cache_key ];
		}

		if ( ! empty( $in_progress[ $cache_key ] ) ) {
			return false;
		}

		$in_progress[ $cache_key ] = true;

		if (is_admin() && ! wp_doing_ajax() ) {
			unset( $in_progress[ $cache_key ] );
			$result_cache[ $cache_key ] = false;
			return false;
		}
		$product = wc_get_product($product_id);
		
		if ( !isset($product) || empty($product) ) {
			unset( $in_progress[ $cache_key ] );
			$result_cache[ $cache_key ] = false;
			return false;
		}
		
		if ('variation' === $product->get_type() || 'subscription_variation' === $product->get_type() ) {
			$product = wc_get_product($product->get_parent_id());
		}
		
		$quote_general = get_option('wc_quote_general', false);
		$product_id = $product->get_id();
		$quote_rules = get_post_meta(intval($rule_id), 'wc_quote_rules', true);
		$show_on_stock = isset($quote_general['show_on_stock']) ? $quote_general['show_on_stock'] : 'hide';

		$user_roles = isset($quote_rules['user_roles']['toggle']) ? $quote_rules['user_roles']['toggle'] : 'all';
		$select_roles = isset($quote_rules['user_roles'][$user_roles]) ? $quote_rules['user_roles'][$user_roles] : array( 0 => 0 );
		$include_products = isset($quote_rules['include_products']['toggle']) ? $quote_rules['include_products']['toggle'] : 'all';
		$include_product_id = isset($quote_rules['include_' . $include_products]) ? $quote_rules['include_' . $include_products] : array( 0 => 0 );
		$exclude_products = isset($quote_rules['exclude_products']['toggle']) ? $quote_rules['exclude_products']['toggle'] : 'product' ;
		$excluded_product_id = isset($quote_rules['exclude_' . $exclude_products]) ? $quote_rules['exclude_' . $exclude_products]: array( 0 => 0 );
		
		if ('hide' == $show_on_stock && ! $product->is_in_stock() ) {
			unset( $in_progress[ $cache_key ] );
			$result_cache[ $cache_key ] = false;
			return false;
		}
		if (! is_user_logged_in() ) {
			
			if (( !in_array('guest', (array) $select_roles, true) ) && 'all' !== $user_roles ) {
				unset( $in_progress[ $cache_key ] );
				$result_cache[ $cache_key ] = false;
				return false;
			}

		} else {

			$curr_user      = wp_get_current_user();
			$curr_user_role = current($curr_user->roles);

			if ('specific' === $user_roles && !in_array($curr_user_role, (array) $select_roles, true) ) {
				unset( $in_progress[ $cache_key ] );
				$result_cache[ $cache_key ] = false;
				return false;
			}
		}

		if ( 'specific_users' === $user_roles && !in_array( get_current_user_id(), $select_roles ) ) {
			unset( $in_progress[ $cache_key ] );
			$result_cache[ $cache_key ] = false;
			return false;
		}
		
		if ('category' == $exclude_products || 'tag' == $exclude_products ) {
			if ( quote_product_matches_terms( $product_id, $exclude_products, (array) $excluded_product_id ) ) {
				unset( $in_progress[ $cache_key ] );
				$result_cache[ $cache_key ] = false;
				return false;
			}
		}

		if (in_array($product_id, $excluded_product_id) ) {
			unset( $in_progress[ $cache_key ] );
			$result_cache[ $cache_key ] = false;
			return false;
		}

		if ('all' == $include_products ) {
			unset( $in_progress[ $cache_key ] );
			$result_cache[ $cache_key ] = true;
			return true;
		}

		if ('category' == $include_products || 'tag' == $include_products ) {
			if ( quote_product_matches_terms( $product_id, $include_products, (array) $include_product_id ) ) {
				unset( $in_progress[ $cache_key ] );
				$result_cache[ $cache_key ] = true;
				return true;
			}
		}
		
		if (in_array($product_id, $include_product_id) ) {
			unset( $in_progress[ $cache_key ] );
			$result_cache[ $cache_key ] = true;
			return true;
		}

		unset( $in_progress[ $cache_key ] );
		$result_cache[ $cache_key ] = false;
		return false;
	}
}

if ( ! function_exists('quote_check_required_addons') ) {
	function quote_check_required_addons( $product_id ) {
		// No parent add-ons, but yes to global.
		/**
		 * Filter active_plugins
		 * 
		 * @since 1.0
		**/
		if (in_array('woocommerce-product-addons/woocommerce-product-addons.php', apply_filters('active_plugins', get_option('active_plugins'))) ) {
			$addons = \WC_Product_Addons_Helper::get_product_addons($product_id);
			if (empty($addons) ) {
				return false;
			}
			foreach ( $addons as $addon ) {
				if (\WC_Product_Addons_Helper::is_addon_required($addon) ) {
					return true;
				}
			}
			
		}
	
		return false;
	}
}


if ( ! function_exists('quote_get_postId_by_pdf_template_name') ) {
	function quote_get_postId_by_pdf_template_name( $templateName ) {
		if (empty($templateName)) {
			return null;
		}

	// Query posts with matching meta key and value
	$posts = get_posts(
		array(
		'post_type'      => 'custom_pdf', // Replace with the correct post type
		'meta_key'       => 'pdf_template_name',
		'meta_value'     => $templateName,
		'posts_per_page' => 1, // Fetch only one post
		'fields'         => 'ids', // Only return IDs
		)
	);

	// Return the post ID if found, otherwise null
	return !empty($posts) ? $posts[0] : null;
	}
}

if ( ! function_exists('quote_generate_pdf') ) {
	function quote_generate_pdf( $post_id, $bool ) {
		if ( $bool ) {
			return wwp_view( 'quote.pdf.custom-template', compact( 'post_id' ) );
		} else {
			ob_start();
			wwp_view( 'quote.pdf.custom-template', compact( 'post_id' ) );
			return ob_get_clean();
		}
	}
}

if ( ! function_exists('quote_get_pdf_template_for_email') ) {
	function quote_get_pdf_template_for_email( $template_type ) {

	// Define the arguments for WP_Query
	$args = array(
		'post_type'      => 'custom_pdf', // Your custom post type
		'posts_per_page' => 1,           // Get only the latest matching post
		'meta_query' => array(
			array(
				'key'     => 'pdf_template_name', // The meta key to match
				'value'   => $template_type,     // The value to match (e.g., 'bronze')
				'compare' => '=',                // Comparison operator
			),
		),
		'orderby' => 'modified',          // Order by last modified date
		'order'   => 'DESC',              // Get the most recently modified post
	);

	// Perform the query
	$query = new \WP_Query($args);

	// Check if any post is found
		if ($query->have_posts()) {
			$query->the_post(); // Set up the post data
			$post_data = array(
			'id'    => get_the_ID(),       // Post ID
			'title' => get_the_title(),    // Post title
			'content' => get_the_content(), // Post content
			);

			wp_reset_postdata(); // Reset post data
			return $post_data;   // Return the post data
		}

	wp_reset_postdata(); // Reset post data if no posts are found
	return false; // Return false if no matching post is found
	}
}

if ( ! function_exists('is_quote') ) {
	function is_quote() {
		if ( is_admin() ) {
			return false;
		}

	global $post;
	
		if ( empty($post) ) {
			return false;
		}

	return ( isset( $post->post_content ) && has_shortcode($post->post_content, wwp_env()->get('quote_page_shortcode')) );
	}
}

if ( ! function_exists('recaptcha_initialize_quote') ) {
	
	function recaptcha_initialize_quote() {
		/**
		 * Core recaptcha Integration
		 */
		static $is_initialized = false;
		static $recaptcha_config = false;

		if ( $is_initialized ) {
			return $recaptcha_config;
		}

		$settings = WholesaleSettingsHelper::get_registration_settings();
		if (isset($settings['enable_recaptcha_quote']) && 'yes' == $settings['enable_recaptcha_quote'] ) {
			include_once WWP_PLUGIN_PATH . 'app/Modules/Recaptcha/Google_Recaptcha.php';
			( new Google_Recaptcha($settings, 'wc-quote') );
			$site_key   = isset($settings['recaptcha_v2_site_key']) ? $settings['recaptcha_v2_site_key'] : '' ;
			$theme      = isset($settings['recaptcha_v2_theme']) ? $settings['recaptcha_v2_theme'] : '' ;
			$recaptcha_config = array( 'site_key' => $site_key, 'theme' => $theme );
			$is_initialized   = true;
			return $recaptcha_config;
		}

		$is_initialized = true;
		$recaptcha_config = false;
		return $recaptcha_config;
	}

}

if ( ! function_exists( 'wwp_pdf_path_to_data_uri' ) ) {
	/**
	 * Encode a local image file as a data URI for DomPDF.
	 *
	 * @param string $path Absolute filesystem path.
	 * @return string
	 */
	function wwp_pdf_path_to_data_uri( $path ) {
		if ( empty( $path ) || ! is_readable( $path ) ) {
			return '';
		}

		$filetype = wp_check_filetype( $path );
		$mime     = ! empty( $filetype['type'] ) ? $filetype['type'] : 'image/jpeg';
		$contents = file_get_contents( $path );

		if ( false === $contents ) {
			return '';
		}

		return 'data:' . $mime . ';base64,' . base64_encode( $contents );
	}
}

if ( ! function_exists( 'wwp_pdf_url_to_local_path' ) ) {
	/**
	 * Map a WordPress media URL to its local filesystem path.
	 *
	 * @param string $url Image URL.
	 * @return string
	 */
	function wwp_pdf_url_to_local_path( $url ) {
		if ( empty( $url ) ) {
			return '';
		}

		$url        = strtok( $url, '?' );
		$upload_dir = wp_upload_dir();

		if ( ! empty( $upload_dir['baseurl'] ) && 0 === strpos( $url, $upload_dir['baseurl'] ) ) {
			return str_replace( $upload_dir['baseurl'], $upload_dir['basedir'], $url );
		}

		$site_url = site_url();
		if ( 0 === strpos( $url, $site_url ) ) {
			$relative = ltrim( substr( $url, strlen( $site_url ) ), '/' );
			return trailingslashit( ABSPATH ) . $relative;
		}

		$home_url = home_url();
		if ( $home_url !== $site_url && 0 === strpos( $url, $home_url ) ) {
			$relative = ltrim( substr( $url, strlen( $home_url ) ), '/' );
			return trailingslashit( ABSPATH ) . $relative;
		}

		return '';
	}
}

if ( ! function_exists( 'wwp_pdf_image_src' ) ) {
	/**
	 * Return an image source DomPDF can render (base64 data URI).
	 *
	 * @param int|string $url_or_attachment_id Attachment ID or image URL.
	 * @return string
	 */
	function wwp_pdf_image_src( $url_or_attachment_id ) {
		if ( empty( $url_or_attachment_id ) ) {
			return '';
		}

		$path = '';

		if ( is_numeric( $url_or_attachment_id ) ) {
			$path = get_attached_file( (int) $url_or_attachment_id );
		} elseif ( is_string( $url_or_attachment_id ) ) {
			$path = wwp_pdf_url_to_local_path( $url_or_attachment_id );
		}

		if ( $path ) {
			$data_uri = wwp_pdf_path_to_data_uri( $path );
			if ( $data_uri ) {
				return $data_uri;
			}
		}

		if ( is_string( $url_or_attachment_id ) && filter_var( $url_or_attachment_id, FILTER_VALIDATE_URL ) ) {
			$response = wp_remote_get(
				$url_or_attachment_id,
				array(
					'timeout'   => 15,
					/**
					 * Filter https_local_ssl_verify
					 * 
					 * @since 3.1.0
					 */
					'sslverify' => apply_filters( 'https_local_ssl_verify', false ),
				)
			);

			if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
				$body = wp_remote_retrieve_body( $response );
				if ( '' !== $body ) {
					$mime = wp_remote_retrieve_header( $response, 'content-type' );
					if ( ! $mime ) {
						$mime = 'image/jpeg';
					}

					return 'data:' . $mime . ';base64,' . base64_encode( $body );
				}
			}
		}

		return '';
	}
}

if ( ! function_exists( 'wwp_pdf_product_thumbnail' ) ) {
	/**
	 * Product thumbnail markup with an embedded image for PDF output.
	 *
	 * @param WC_Product $product Product object.
	 * @param array      $item    Quote line item.
	 * @param array      $size    Image dimensions.
	 * @return string
	 */
	function wwp_pdf_product_thumbnail( $product, $item = array(), $size = array( 50, 50 ) ) {
		if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
			return '';
		}

		$image_id = $product->get_image_id();
		if ( ! $image_id ) {
			return '';
		}

		$src = wwp_pdf_image_src( $image_id );
		if ( ! $src ) {
			return '';
		}

		$width = isset( $size[0] ) ? (int) $size[0] : 50;
		$html  = '<img src="' . esc_attr( $src ) . '" width="' . esc_attr( $width ) . '" style="border: 2px solid #e8e8e8 !important;" alt="" />';

		/**
		 * Filter wc_quote_item_thumbnail
		 *
		 * @since 1.0
		 */
		return apply_filters( 'wc_quote_item_thumbnail', $html, $product->get_id(), $item );
	}
}

if ( ! function_exists('quote_check_status') ) {
	function quote_check_status() {
		$settings = get_option( 'wc_quote_general', true );
		return (bool) isset( $settings['custom_quote_status'] ) && '1' === $settings['custom_quote_status'];
	}

}

if ( ! function_exists( 'wwp_persist_quote_user_meta' ) ) {
	/**
	 * Persist quote session for logged-in users without storing WC_Product objects.
	 *
	 * @param array|null $quotes Quote session contents.
	 * @return void
	 */
	function wwp_persist_quote_user_meta( $quotes = null ) {
		if ( ! is_user_logged_in() ) {
			return;
		}

		if ( null === $quotes && isset( WC()->session ) ) {
			$quotes = WC()->session->get( 'wc_quotes' );
		}

		if ( empty( $quotes ) || ! is_array( $quotes ) ) {
			update_user_meta( get_current_user_id(), 'wc_quote', '' );
			return;
		}

		$persisted = array();
		foreach ( $quotes as $key => $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$persisted[ $key ] = $item;
			unset( $persisted[ $key ]['data'] );
		}

		update_user_meta( get_current_user_id(), 'wc_quote', $persisted );
	}
}
if ( function_exists( 'add_action' ) ) {
	add_action( 'save_post_wc-quote-rules', 'clear_quote_rules_cache' );
	add_action(
		'deleted_post',
		function ( $post_id, $post = null ) {
			if ( $post && isset( $post->post_type ) && 'wc-quote-rules' === $post->post_type ) {
				clear_quote_rules_cache();
			}
		},
		10,
		2
	);
	add_action( 'save_post_wc-quote-status', 'clear_quote_custom_statuses_cache' );
	add_action(
		'deleted_post',
		function ( $post_id, $post = null ) {
			if ( $post && isset( $post->post_type ) && 'wc-quote-status' === $post->post_type ) {
				clear_quote_custom_statuses_cache();
			}
		},
		10,
		2
	);
	add_action(
		'save_post_page',
		function ( $post_id ) {
			delete_option( 'wwp_resolved_quote_page_id' );
		},
		10,
		1
	);

	add_action( 'wwp_deferred_litespeed_purge', 'wwp_run_litespeed_purge' );

	if ( ! function_exists( 'wwp_register_quote_litespeed_purge_hooks' ) ) {
	/**
	 * Register LiteSpeed purge hooks for quote session and admin changes.
	 *
	 * @return void
	 */
		function wwp_register_quote_litespeed_purge_hooks() {
			$purge_actions = array(
			'wc_quote_session_changed',
			'wc_quote_add_to_quote',
			'wc_quote_item_removed',
			'wc_quote_created',
			'wc_quote_contents_updated',
			'wc_quote_status_updated',
			'wc_quote_after_build_quote',
			'wc_quote_converted_to_order',
			);

			foreach ( $purge_actions as $action ) {
				add_action( $action, 'wwp_purge_litespeed_cache', 99 );
			}
		}

	add_action( 'init', 'wwp_register_quote_litespeed_purge_hooks' );
	}
}

if ( ! function_exists( 'wwp_run_litespeed_purge' ) && function_exists('do_action') ) {
	/**
	 * Execute the LiteSpeed purge action.
	 *
	 * @return void
	 */
	function wwp_run_litespeed_purge() {
		/**
		 * Filter litespeed_purge_all to purge all LiteSpeed cache after quote changes.
		 * 
		 * @since 3.4.0
		 */
		do_action( 'litespeed_purge_all' );
	}
}

if ( ! function_exists( 'wwp_purge_litespeed_cache' ) ) {
	/**
	 * Purge LiteSpeed cache once per request after quote changes.
	 *
	 * @return void
	 */
	function wwp_purge_litespeed_cache() {
		static $purged = false;

		if ( $purged ) {
			return;
		}

		$purged = true;

		// Avoid exhausting memory during quote AJAX handlers.
		if ( wp_doing_ajax() ) {
			if ( ! wp_next_scheduled( 'wwp_deferred_litespeed_purge' ) ) {
				wp_schedule_single_event( time() + 1, 'wwp_deferred_litespeed_purge' );
			}
			return;
		}

		wwp_run_litespeed_purge();
	}
}
