<?php
/**
 * Company Credits helper functions.
 *
 * @package WooCommerceWholesalePricing
 */

if ( ! function_exists( 'ccp_add_company_credit' ) ) :
	/**
	 * Insert a credit log entry for a company.
	 *
	 * @param array $args Credit log arguments.
	 * @return bool|string
	 */
	function ccp_add_company_credit( $args = array() ) {
		$company_title = '';
		$company_data  = get_post( $args['company_id'] );
		if ( ! empty( $company_data->post_title ) ) {
			$company_title = $company_data->post_title;
		}

		$affects_pool = ! isset( $args['affects_pool'] ) || false !== $args['affects_pool'];
		$user_id      = isset( $args['user_id'] ) ? absint( $args['user_id'] ) : get_current_user_id();
		$user         = $user_id ? get_user_by( 'id', $user_id ) : wp_get_current_user();
		$user_email   = ( $user && ! empty( $user->user_email ) ) ? $user->user_email : '';

		$ccp_credit_logs = array(
			'post_type'    => 'ccp_credit_logs',
			'post_author'  => 1,
			'post_title'   => $company_title,
			'post_status'  => 'publish',
			'meta_input'   => array(
				'company_id'       => $args['company_id'],
				'ccp_date'         => gmdate( 'Y-m-d H:i:s' ),
				'order_id'         => isset( $args['order_id'] ) ? $args['order_id'] : '',
				'user_email'       => $user_email,
				'user_id'          => $user_id,
				'amount'           => $args['amount'],
				'event'            => $args['event'],
				'ccp_affects_pool' => $affects_pool ? 'yes' : 'no',
			),
		);

		/**
		 * Filter the credit logs insert arguments.
		 *
		 * @since 3.4.0
		 *
		 * @param array $ccp_credit_logs The credit logs insert arguments.
		 */
		$ccp_credit_logs = apply_filters( 'ccp_credit_logs_insert_args', $ccp_credit_logs );
		$id              = wp_insert_post( $ccp_credit_logs );

		if ( ! is_wp_error( $id ) ) {
			return true;
		}

		return wp_kses_post( $id->get_error_message() );
	}
endif;

if ( ! function_exists( 'recently_assigned_credit' ) ) :
	/**
	 * Get the most recently assigned credit amount for a company.
	 *
	 * @param int $company_id Company post ID.
	 * @return float
	 */
	function recently_assigned_credit( $company_id ) {
		$amount = 0;
		$args   = array(
			'post_type'      => 'ccp_credit_logs',
			'posts_per_page' => 1,
			'orderby'        => 'ID',
			'order'          => 'DESC',
			'meta_query'     => array(
				'relation' => 'AND',
				array(
					'key'   => 'company_id',
					'value' => $company_id,
				),
				// Only credit assignments (positive amounts), not purchases/consumption.
				array(
					'key'     => 'amount',
					'value'   => 0,
					'compare' => '>',
					'type'    => 'NUMERIC',
				),
			),
		);

		$ccp_credit_logs = get_posts( $args );
		if ( ! empty( $ccp_credit_logs ) ) {
			$amount = get_post_meta( $ccp_credit_logs[0]->ID, 'amount', true );
		}

		$amount = round( max( 0, (float) $amount ), 2 );

		/**
		 * Filter the recently assigned credit amount.
		 *
		 * @since 3.4.0
		 *
		 * @param float $amount The recently assigned credit amount.
		 */
		return apply_filters( 'recently_assigned_credit', $amount );
	}
endif;

if ( ! function_exists( 'negative_value_check' ) ) :
	/**
	 * Return CSS class for positive/negative credit values.
	 *
	 * @param float $amount Amount value.
	 * @return string
	 */
	function negative_value_check( $amount ) {
		return ( $amount > 0 ) ? 'positive' : 'negative';
	}
endif;

if ( ! function_exists( 'ccp_company_credits' ) ) :
	/**
	 * Calculate company credit totals from log entries.
	 *
	 * @param int $company_id Company post ID.
	 * @return array
	 */
	function ccp_company_credits( $company_id ) {
		$data             = array();
		$data['consumed'] = 0;
		$data['credit']   = 0;
		$args             = array(
			'post_type'      => 'ccp_credit_logs',
			'posts_per_page' => -1,
			'orderby'        => 'ID',
			'order'          => 'DESC',
			'meta_query'     => array(
				array(
					'key'   => 'company_id',
					'value' => $company_id,
				),
			),
		);

		$ccp_credit_logs = get_posts( $args );
		foreach ( $ccp_credit_logs as $ccp_credit_log ) {
			// Wallet spend logs are audit-only; pool was already reduced at allocation.
			if ( 'no' === get_post_meta( $ccp_credit_log->ID, 'ccp_affects_pool', true ) ) {
				continue;
			}
			$amount = get_post_meta( $ccp_credit_log->ID, 'amount', true );
			if ( $amount < 0 ) {
				$data['consumed'] = round( $data['consumed'] + $amount, 2 );
			} else {
				$data['credit'] = round( $data['credit'] + $amount, 2 );
			}
		}

		// Apply expiration baseline snapshot so totals appear reset per expiration cycle.
		$baseline = get_post_meta( $company_id, 'ccp_credit_logs_reset_baseline', true );
		if ( is_array( $baseline ) ) {
			$baseline_credit   = isset( $baseline['credit'] ) && is_numeric( $baseline['credit'] ) ? (float) $baseline['credit'] : null;
			$baseline_consumed = isset( $baseline['consumed'] ) && is_numeric( $baseline['consumed'] ) ? (float) $baseline['consumed'] : null;

			if ( null !== $baseline_credit ) {
				$data['credit'] = round( (float) $data['credit'] - $baseline_credit, 2 );
			}
			if ( null !== $baseline_consumed ) {
				$data['consumed'] = round( (float) $data['consumed'] - $baseline_consumed, 2 );
			}
		}

		// Clamp tiny rounding artifacts to 0.
		if ( is_numeric( $data['credit'] ) && abs( (float) $data['credit'] ) < 0.00001 ) {
			$data['credit'] = 0;
		}
		if ( is_numeric( $data['consumed'] ) && abs( (float) $data['consumed'] ) < 0.00001 ) {
			$data['consumed'] = 0;
		}

		// consumed is negative for debits; remaining is what is still available in the pool.
		$data['remaining'] = round( max( 0, (float) $data['credit'] + (float) $data['consumed'] ), 2 );

		/**
		 * Filter the company credits data.
		 *
		 * @since 3.4.0
		 *
		 * @param array $data The company credits data.
		 */
		return apply_filters( 'ccp_company_credits', $data );
	}
endif;

if ( ! function_exists( 'ccp_get_user_wallet_consumed_amount' ) ) :
	/**
	 * Net wallet consumption for a company user.
	 *
	 * Uses order-linked spend/restore logs (checkout), regardless of whether those
	 * logs also affect the company pool balance.
	 *
	 * @param int $company_id Company post ID.
	 * @param int $user_id    User ID.
	 * @return float
	 */
	function ccp_get_user_wallet_consumed_amount( $company_id, $user_id ) {
		$company_id = absint( $company_id );
		$user_id    = absint( $user_id );
		if ( empty( $company_id ) || empty( $user_id ) ) {
			return 0.0;
		}

		$sum  = 0.0;
		$args = array(
			'post_type'      => 'ccp_credit_logs',
			'posts_per_page' => -1,
			'meta_query'     => array(
				'relation' => 'AND',
				array(
					'key'   => 'company_id',
					'value' => $company_id,
				),
				array(
					'key'   => 'user_id',
					'value' => $user_id,
				),
				array(
					'key'     => 'order_id',
					'value'   => 0,
					'compare' => '>',
					'type'    => 'NUMERIC',
				),
			),
		);

		$logs = get_posts( $args );
		foreach ( $logs as $log ) {
			$amount = get_post_meta( $log->ID, 'amount', true );
			if ( is_numeric( $amount ) ) {
				$sum += (float) $amount; // spent is negative, restore is positive
			}
		}

		return round( abs( $sum ), 2 );
	}
endif;

if ( ! function_exists( 'ccp_post_data' ) ) :
	/**
	 * Sanitized POST data helper.
	 *
	 * @param string $name Optional POST key.
	 * @return mixed
	 */
	function ccp_post_data( $name = '' ) {
		$post = $_POST; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( isset( $post[ $name ] ) ) {
			
			/**
			 * Filter the sanitized POST data.
			 *
			 * @since 3.4.0
			 *
			 * @param string $data The sanitized POST data.
			 */
			return apply_filters( 'ccp_post_data', wp_kses_post( $post[ $name ] ) );
		}

		return $post;
	}
endif;

if ( ! function_exists( 'ccp_get_data' ) ) :
	/**
	 * Sanitized GET data helper.
	 *
	 * @param string $name Optional GET key.
	 * @return mixed
	 */
	function ccp_get_data( $name = '' ) {
		$get = $_GET;
		if ( isset( $get[ $name ] ) ) {
			/**
			 * Filter the sanitized GET data.
			 *
			 * @since 3.4.0
			 *
			 * @param string $data The sanitized GET data.
			 */
			return apply_filters( 'ccp_get_data', wp_kses_post( $get[ $name ] ) );
		}

		return $get;
	}
endif;

if ( ! function_exists( 'wwp_ccp_render_user_select_options' ) ) :
	/**
	 * Render selected user options for WC customer search fields.
	 *
	 * @param array $user_ids User IDs.
	 * @return void
	 */
	function wwp_ccp_render_user_select_options( $user_ids ) {
		if ( ! is_array( $user_ids ) || empty( $user_ids ) ) {
			return;
		}

		foreach ( $user_ids as $user_id ) {
			$user_id = absint( $user_id );
			$user    = get_user_by( 'id', $user_id );
			if ( ! $user ) {
				continue;
			}

			$user_string = sprintf(
				'%1$s (#%2$s – %3$s)',
				$user->display_name,
				absint( $user->ID ),
				$user->user_email
			);
			echo '<option value="' . esc_attr( $user->ID ) . '" selected="selected">' . esc_html( $user_string ) . '</option>';
		}
	}
endif;

if ( ! function_exists( 'wwp_ccp_count_company_users' ) ) :
	/**
	 * Count unique users assigned to a company.
	 *
	 * @param int $post_id Company post ID.
	 * @return int
	 */
	function wwp_ccp_count_company_users( $post_id ) {
		$owner_ids   = get_post_meta( $post_id, 'ccp_company_users_owner', true );
		$manager_ids = get_post_meta( $post_id, 'ccp_company_users_manager', true );
		$member_ids  = get_post_meta( $post_id, 'ccp_company_users_member', true );

		$all_ids = array();
		foreach ( array( $owner_ids, $manager_ids, $member_ids ) as $ids ) {
			if ( is_array( $ids ) ) {
				$all_ids = array_merge( $all_ids, array_map( 'absint', $ids ) );
			}
		}

		$all_ids = array_filter( array_unique( $all_ids ) );

		return count( $all_ids );
	}
endif;

if ( ! function_exists( 'ccp_get_company_user_role_map' ) ) :
	/**
	 * Map company role slugs to company post meta keys.
	 *
	 * @return array
	 */
	function ccp_get_company_user_role_map() {
		return array(
			'ccp_owner'   => 'ccp_company_users_owner',
			'ccp_manager' => 'ccp_company_users_manager',
			'ccp_member'  => 'ccp_company_users_member',
		);
	}
endif;

if ( ! function_exists( 'ccp_is_active_company' ) ) :
	/**
	 * Whether a company post exists and is not in trash.
	 *
	 * @param int $company_id Company post ID.
	 * @return bool
	 */
	function ccp_is_active_company( $company_id ) {
		$company_id = absint( $company_id );
		if ( empty( $company_id ) ) {
			return false;
		}

		$post = get_post( $company_id );
		if ( ! $post instanceof \WP_Post ) {
			return false;
		}

		$company_slug = function_exists( 'wwp_env' ) ? wwp_env()->get( 'company_credits_slug' ) : 'ccp_company';
		if ( $post->post_type !== $company_slug ) {
			return false;
		}

		return ! in_array( $post->post_status, array( 'trash', 'auto-draft' ), true );
	}
endif;

if ( ! function_exists( 'is_company_member' ) ) :
	/**
	 * Whether a user belongs to a company group with wholesale pricing configured.
	 *
	 * The user must appear in a company's owner, manager, or member list and that
	 * company must have a non-empty ccp_wholesale_role_id.
	 *
	 * @param int|null $user_id Optional user ID. Defaults to current user.
	 * @return bool
	 */
	function is_company_member( $user_id = null ) {
		$user_id = null === $user_id ? get_current_user_id() : absint( $user_id );
		if ( empty( $user_id ) ) {
			return false;
		}

		$company_ids = array();
		$assigned    = absint( get_user_meta( $user_id, 'ccp_company_id', true ) );

		if ( $assigned ) {
			$company_ids[] = $assigned;
		} elseif ( function_exists( 'wwp_env' ) && function_exists( 'is_company_credits_enabled' ) && is_company_credits_enabled() ) {
			$company_slug = wwp_env()->get( 'company_credits_slug' );
			if ( ! empty( $company_slug ) ) {
				$all_companies = get_posts(
					array(
						'post_type'      => $company_slug,
						'post_status'    => 'publish',
						'posts_per_page' => -1,
						'fields'         => 'ids',
					)
				);
				if ( is_array( $all_companies ) ) {
					$company_ids = array_map( 'absint', $all_companies );
				}
			}
		}

		$company_ids = array_filter( array_unique( $company_ids ) );
		if ( empty( $company_ids ) ) {
			return false;
		}

		foreach ( $company_ids as $company_id ) {
			$in_group = false;

			foreach ( ccp_get_company_user_role_map() as $meta_key ) {
				$list = get_post_meta( $company_id, $meta_key, true );
				if ( ! is_array( $list ) ) {
					continue;
				}

				if ( in_array( $user_id, array_map( 'absint', $list ), true ) ) {
					$in_group = true;
					break;
				}
			}

			if ( ! $in_group ) {
				continue;
			}

			$wholesale_role_id = absint( get_post_meta( $company_id, 'ccp_wholesale_role_id', true ) );
			if ( ! empty( $wholesale_role_id ) ) {
				return $wholesale_role_id;
			}
		}

		return false;
	}
endif;

if ( ! function_exists( 'ccp_remove_user_from_company_lists' ) ) :
	/**
	 * Remove a user from all role lists on a company.
	 *
	 * @param int $user_id User ID.
	 * @param int $company_id Company post ID.
	 * @return void
	 */
	function ccp_remove_user_from_company_lists( $user_id, $company_id ) {
		$user_id    = absint( $user_id );
		$company_id = absint( $company_id );

		if ( empty( $user_id ) || empty( $company_id ) ) {
			return;
		}

		foreach ( ccp_get_company_user_role_map() as $meta_key ) {
			$user_ids = get_post_meta( $company_id, $meta_key, true );
			if ( is_array( $user_ids ) && in_array( $user_id, $user_ids, true ) ) {
				$user_ids = array_values( array_diff( $user_ids, array( $user_id ) ) );
				update_post_meta( $company_id, $meta_key, $user_ids );
			}
		}
	}
endif;

if ( ! function_exists( 'ccp_assign_user_to_company_lists' ) ) :
	/**
	 * Assign a user to the correct company role list and remove from others.
	 *
	 * @param int    $user_id User ID.
	 * @param int    $company_id Company post ID.
	 * @param string $role Company role slug.
	 * @return void
	 */
	function ccp_assign_user_to_company_lists( $user_id, $company_id, $role ) {
		$user_id    = absint( $user_id );
		$company_id = absint( $company_id );
		$role_map   = ccp_get_company_user_role_map();

		if ( empty( $user_id ) || empty( $company_id ) || ! isset( $role_map[ $role ] ) ) {
			return;
		}

		foreach ( $role_map as $role_slug => $meta_key ) {
			$user_ids = get_post_meta( $company_id, $meta_key, true );
			if ( ! is_array( $user_ids ) ) {
				$user_ids = array();
			}

			if ( $role_slug === $role ) {
				$user_ids = array_values( array_unique( array_merge( $user_ids, array( $user_id ) ) ) );
			} else {
				$user_ids = array_values( array_diff( $user_ids, array( $user_id ) ) );
			}

			update_post_meta( $company_id, $meta_key, $user_ids );
		}
	}
endif;

if ( ! function_exists( 'ccp_clear_user_company_assignment' ) ) :
	/**
	 * Clear company assignment user meta.
	 *
	 * @param int $user_id User ID.
	 * @return void
	 */
	function ccp_clear_user_company_assignment( $user_id ) {
		$user_id = absint( $user_id );
		if ( empty( $user_id ) ) {
			return;
		}

		delete_user_meta( $user_id, 'ccp_company_role' );
		delete_user_meta( $user_id, 'ccp_company_id' );
	}
endif;

if ( ! function_exists( 'ccp_sync_user_company_assignment' ) ) :
	/**
	 * Save user company meta and sync company role lists.
	 *
	 * @param int    $user_id User ID.
	 * @param int    $company_id Company post ID.
	 * @param string $role Company role slug.
	 * @return void
	 */
	function ccp_sync_user_company_assignment( $user_id, $company_id, $role ) {
		$user_id    = absint( $user_id );
		$company_id = absint( $company_id );
		$role       = sanitize_text_field( $role );
		$role_map   = ccp_get_company_user_role_map();

		if ( empty( $user_id ) ) {
			return;
		}

		if ( empty( $role ) || empty( $company_id ) || ! isset( $role_map[ $role ] ) ) {
			$company_id = 0;
			$role       = '';
		}

		$previous_company_id = absint( get_user_meta( $user_id, 'ccp_company_id', true ) );
		if ( ! empty( $previous_company_id ) && $previous_company_id !== $company_id ) {
			ccp_remove_user_from_company_lists( $user_id, $previous_company_id );
		}

		update_user_meta( $user_id, 'ccp_company_role', $role );
		update_user_meta( $user_id, 'ccp_company_id', ! empty( $company_id ) ? $company_id : '' );

		if ( ! empty( $company_id ) && ! empty( $role ) ) {
			ccp_assign_user_to_company_lists( $user_id, $company_id, $role );
		} elseif ( ! empty( $previous_company_id ) ) {
			ccp_remove_user_from_company_lists( $user_id, $previous_company_id );
		}
	}
endif;

if ( ! function_exists( 'ccp_get_stored_user_credit_limit' ) ) :
	/**
	 * Get a stored per-user credit limit override.
	 *
	 * @param array $user_limits Stored user limit overrides.
	 * @param int   $user_id User ID.
	 * @return string|null
	 */
	function ccp_get_stored_user_credit_limit( $user_limits, $user_id ) {
		if ( ! is_array( $user_limits ) ) {
			return null;
		}

		$user_id = absint( $user_id );

		if ( array_key_exists( $user_id, $user_limits ) ) {
			$value = is_scalar( $user_limits[ $user_id ] ) ? sanitize_text_field( $user_limits[ $user_id ] ) : '';
			return '' !== $value ? $value : null;
		}

		if ( array_key_exists( (string) $user_id, $user_limits ) ) {
			$value = is_scalar( $user_limits[ (string) $user_id ] ) ? sanitize_text_field( $user_limits[ (string) $user_id ] ) : '';
			return '' !== $value ? $value : null;
		}

		return null;
	}
endif;

if ( ! function_exists( 'ccp_get_effective_user_credit_limit' ) ) :
	/**
	 * Get the effective credit limit for a company user.
	 *
	 * @param int $company_id Company post ID.
	 * @param int $user_id User ID.
	 * @return string
	 */
	function ccp_get_effective_user_credit_limit( $company_id, $user_id ) {
		$bulk_limit  = get_post_meta( absint( $company_id ), 'ccp_bulk_credit_limit', true );
		$user_limits = get_post_meta( absint( $company_id ), 'ccp_user_credit_limits', true );
		$override    = ccp_get_stored_user_credit_limit( $user_limits, $user_id );

		if ( null !== $override ) {
			return $override;
		}

		return $bulk_limit;
	}
endif;

if ( ! function_exists( 'ccp_increase_user_credit_limit' ) ) :
	/**
	 * Increase a company user's configured credit limit.
	 *
	 * @param int   $company_id Company post ID.
	 * @param int   $user_id    User ID.
	 * @param float $amount     Amount to add to the limit.
	 * @return float New credit limit.
	 */
	function ccp_increase_user_credit_limit( $company_id, $user_id, $amount ) {
		$company_id = absint( $company_id );
		$user_id    = absint( $user_id );
		$amount     = max( 0, (float) $amount );

		if ( empty( $company_id ) || empty( $user_id ) || $amount <= 0 ) {
			return (float) ccp_get_effective_user_credit_limit( $company_id, $user_id );
		}

		$current_limit = (float) ccp_get_effective_user_credit_limit( $company_id, $user_id );
		$new_limit     = round( $current_limit + $amount, 2 );

		$user_limits = get_post_meta( $company_id, 'ccp_user_credit_limits', true );
		if ( ! is_array( $user_limits ) ) {
			$user_limits = array();
		}

		$user_limits[ $user_id ] = wc_format_decimal( $new_limit, 2 );
		update_post_meta( $company_id, 'ccp_user_credit_limits', $user_limits );

		return $new_limit;
	}
endif;

if ( ! function_exists( 'ccp_normalize_user_credit_limit_overrides' ) ) :
	/**
	 * Keep only per-user limits that differ from the bulk limit.
	 *
	 * @param array  $user_limits Posted user limits.
	 * @param string $bulk_limit Bulk credit limit.
	 * @return array
	 */
	function ccp_normalize_user_credit_limit_overrides( $user_limits, $bulk_limit ) {
		$normalized = array();

		if ( ! is_array( $user_limits ) ) {
			return $normalized;
		}

		$bulk_limit = is_scalar( $bulk_limit ) ? sanitize_text_field( $bulk_limit ) : '';

		foreach ( $user_limits as $user_id => $limit ) {
			$user_id = absint( $user_id );
			if ( empty( $user_id ) ) {
				continue;
			}

			$limit = is_scalar( $limit ) ? sanitize_text_field( $limit ) : '';

			if ( '' === $limit ) {
				continue;
			}

			if ( (string) $limit !== (string) $bulk_limit ) {
				$normalized[ $user_id ] = $limit;
			}
		}

		return $normalized;
	}
endif;

if ( ! function_exists( 'ccp_sanitize_restricted_categories' ) ) :
	/**
	 * Convert posted category values (slug or ID) into unique term IDs.
	 *
	 * @param array $categories Posted category values.
	 * @return array
	 */
	function ccp_sanitize_restricted_categories( $categories ) {
		$term_ids = array();

		if ( ! is_array( $categories ) ) {
			return $term_ids;
		}

		foreach ( $categories as $category ) {
			$category = is_scalar( $category ) ? sanitize_text_field( $category ) : '';
			if ( '' === $category ) {
				continue;
			}

			$term = null;
			if ( is_numeric( $category ) ) {
				$term = get_term( absint( $category ), 'product_cat' );
			} else {
				$term = get_term_by( 'slug', $category, 'product_cat' );
			}

			if ( $term && ! is_wp_error( $term ) && ! empty( $term->term_id ) ) {
				$term_ids[] = absint( $term->term_id );
			}
		}

		return array_values( array_unique( array_filter( $term_ids ) ) );
	}
endif;

if ( ! function_exists( 'ccp_get_company_restriction_settings' ) ) :
	/**
	 * Restriction settings for a company.
	 *
	 * @param int $company_id Company post ID.
	 * @return array{type:string,products:array,categories:array}
	 */
	function ccp_get_company_restriction_settings( $company_id ) {
		$company_id = absint( $company_id );
		$type       = get_post_meta( $company_id, 'ccp_restriction_type', true );

		if ( empty( $type ) ) {
			$type = 'all_products';
		}

		$products   = get_post_meta( $company_id, 'ccp_restricted_products', true );
		$categories = get_post_meta( $company_id, 'ccp_restricted_categories', true );

		return array(
			'type'       => (string) $type,
			'products'   => is_array( $products ) ? array_map( 'absint', $products ) : array(),
			'categories' => is_array( $categories ) ? array_map( 'absint', $categories ) : array(),
		);
	}
endif;

if ( ! function_exists( 'ccp_get_product_category_ids_for_restriction' ) ) :
	/**
	 * Product category term IDs used for restriction checks (includes parent for variations).
	 *
	 * @param \WC_Product|null $product Product object.
	 * @return array
	 */
	function ccp_get_product_category_ids_for_restriction( $product ) {
		if ( ! $product instanceof \WC_Product ) {
			return array();
		}

		$cat_ids = wc_get_product_cat_ids( $product->get_id() );
		if ( $product->is_type( 'variation' ) ) {
			$parent_id = $product->get_parent_id();
			if ( $parent_id ) {
				$cat_ids = array_merge( $cat_ids, wc_get_product_cat_ids( $parent_id ) );
			}
		}

		return array_values( array_unique( array_filter( array_map( 'absint', (array) $cat_ids ) ) ) );
	}
endif;

if ( ! function_exists( 'ccp_product_matches_restriction_lists' ) ) :
	/**
	 * Whether a product matches restricted product/category lists.
	 *
	 * @param int   $product_id         Product or variation ID.
	 * @param array $list_product_ids   Restricted product IDs.
	 * @param array $list_category_ids  Restricted category term IDs.
	 * @return bool
	 */
	function ccp_product_matches_restriction_lists( $product_id, $list_product_ids, $list_category_ids ) {
		$product = wc_get_product( absint( $product_id ) );
		if ( ! $product ) {
			return false;
		}

		$check_ids = array( $product->get_id() );
		if ( $product->is_type( 'variation' ) ) {
			$parent_id = $product->get_parent_id();
			if ( $parent_id ) {
				$check_ids[] = $parent_id;
			}
		}
		$check_ids = array_unique( array_map( 'absint', $check_ids ) );

		foreach ( (array) $list_product_ids as $restricted_id ) {
			if ( in_array( absint( $restricted_id ), $check_ids, true ) ) {
				return true;
			}
		}

		if ( ! empty( $list_category_ids ) ) {
			$product_cats = ccp_get_product_category_ids_for_restriction( $product );
			if ( array_intersect( $product_cats, array_map( 'absint', $list_category_ids ) ) ) {
				return true;
			}
		}

		return false;
	}
endif;

if ( ! function_exists( 'ccp_is_product_eligible_for_company_credit' ) ) :
	/**
	 * Whether company credit may be used to purchase a product.
	 *
	 * @param int $product_id Product or variation ID.
	 * @param int $company_id Company post ID.
	 * @return bool
	 */
	function ccp_is_product_eligible_for_company_credit( $product_id, $company_id ) {
		$settings = ccp_get_company_restriction_settings( $company_id );
		$type     = $settings['type'];

		switch ( $type ) {
			case 'all_products':
				return true;

			case 'all_categories':
				$product = wc_get_product( absint( $product_id ) );
				return ! empty( ccp_get_product_category_ids_for_restriction( $product ) );

			case 'include':
				if ( empty( $settings['products'] ) && empty( $settings['categories'] ) ) {
					return false;
				}
				return ccp_product_matches_restriction_lists( $product_id, $settings['products'], $settings['categories'] );

			case 'exclude':
				if ( empty( $settings['products'] ) && empty( $settings['categories'] ) ) {
					return true;
				}
				return ! ccp_product_matches_restriction_lists( $product_id, $settings['products'], $settings['categories'] );

			default:
				return true;
		}
	}
endif;

if ( ! function_exists( 'ccp_get_checkout_product_ids_for_restriction' ) ) :
	/**
	 * Collect product/variation IDs from a cart or order for restriction checks.
	 *
	 * @param \WC_Cart|null  $cart  Cart instance.
	 * @param \WC_Order|null $order Order instance.
	 * @return array
	 */
	function ccp_get_checkout_product_ids_for_restriction( $cart = null, $order = null ) {
		$product_ids = array();

		if ( null === $cart && function_exists( 'WC' ) && WC()->cart ) {
			$cart = WC()->cart;
		}

		if ( $cart && is_a( $cart, 'WC_Cart' ) && ! $cart->is_empty() ) {
			foreach ( $cart->get_cart() as $item ) {
				$product_id   = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
				$variation_id = isset( $item['variation_id'] ) ? absint( $item['variation_id'] ) : 0;
				$check_id     = $variation_id ? $variation_id : $product_id;

				if ( $check_id ) {
					$product_ids[] = $check_id;
				}
			}
		} elseif ( $order instanceof \WC_Order ) {
			foreach ( $order->get_items() as $item ) {
				if ( ! $item instanceof \WC_Order_Item_Product ) {
					continue;
				}

				$variation_id = absint( $item->get_variation_id() );
				$product_id   = absint( $item->get_product_id() );
				$check_id     = $variation_id ? $variation_id : $product_id;

				if ( $check_id ) {
					$product_ids[] = $check_id;
				}
			}
		}

		return array_values( array_unique( array_filter( array_map( 'absint', $product_ids ) ) ) );
	}
endif;

if ( ! function_exists( 'ccp_validate_cart_for_company_credit' ) ) :
	/**
	 * Validate cart or order contents against company credit product/category restrictions.
	 *
	 * @param int              $company_id Company post ID.
	 * @param \WC_Cart|null    $cart       Cart instance.
	 * @param \WC_Order|null   $order      Order instance (used when cart is empty).
	 * @return true|\WP_Error
	 */
	function ccp_validate_cart_for_company_credit( $company_id, $cart = null, $order = null ) {
		$company_id = absint( $company_id );
		if ( empty( $company_id ) ) {
			return new \WP_Error(
				'ccp_no_company',
				__( 'You cannot use this payment gateway.', 'woocommerce-wholesale-pricing' )
			);
		}

		$product_ids = ccp_get_checkout_product_ids_for_restriction( $cart, $order );
		if ( empty( $product_ids ) ) {
			return true;
		}

		$ineligible = array();

		foreach ( $product_ids as $check_id ) {
			if ( ! ccp_is_product_eligible_for_company_credit( $check_id, $company_id ) ) {
				$product      = wc_get_product( $check_id );
				$ineligible[] = $product ? $product->get_name() : '#' . $check_id;
			}
		}

		if ( empty( $ineligible ) ) {
			return true;
		}

		$message = sprintf(
			/* translators: %s: comma-separated product names */
			__( 'Company credit cannot be used for: %s. Please choose another payment method or remove these items from your cart.', 'woocommerce-wholesale-pricing' ),
			implode( ', ', $ineligible )
		);

		return new \WP_Error(
			'ccp_credit_restriction',
			/**
			 * Filter the company credit restriction message.
			 *
			 * @since 3.4.0
			 *
			 * @param string $message The message to display.
			 * @param array $ineligible The products that are ineligible for company credit.
			 * @param int $company_id The company ID.
			 */
			apply_filters( 'ccp_company_credit_restriction_message', $message, $ineligible, $company_id )
		);
	}
endif;

if ( ! function_exists( 'ccp_get_option_yes_default' ) ) :
	/**
	 * Get a CCP option, defaulting to yes when unset.
	 *
	 * @param string $option Option name.
	 * @return string
	 */
	function ccp_get_option_yes_default( $option ) {
		$value = get_option( $option, 'yes' );
		return ( 'yes' === $value ) ? 'yes' : 'no';
	}
endif;

if ( ! function_exists( 'ccp_my_acount_tab_active' ) ) :
	/**
	 * Echo active class for company portal tabs.
	 *
	 * @param string $tab Tab slug.
	 * @return void
	 */
	function ccp_my_acount_tab_active( $tab ) {
		$current = isset( $_GET['tab'] ) ? sanitize_text_field( wp_unslash( $_GET['tab'] ) ) : '';
		if ( $tab === $current ) {
			echo 'active';
		} elseif ( 'orders' === $tab && '' === $current ) {
			echo 'active';
		}
	}
endif;

if ( ! function_exists( 'authentication_role' ) ) :
	/**
	 * Whether the current company role may access a portal section.
	 *
	 * @param string $section Section slug.
	 * @return bool
	 */
	function authentication_role( $section ) {
		$allow            = true;
		$user_id          = get_current_user_id();
		$ccp_company_role = get_user_meta( $user_id, 'ccp_company_role', true );

		if ( 'ccp_member' === $ccp_company_role ) {
			if ( 'users' === $section || 'credit-requests' === $section ) {
				$allow = false;
			}
			if ( 'yes' !== ccp_get_option_yes_default( 'ccp_shareing_member' ) && ( 'my-shared-carts' === $section || 'user-shared-carts' === $section ) ) {
				$allow = false;
			}
		}

		if ( 'ccp_manager' === $ccp_company_role ) {
			if ( 'credit-requests' === $section ) {
				$allow = false;
			}
			if ( 'yes' !== ccp_get_option_yes_default( 'ccp_shareing_manager' ) && ( 'my-shared-carts' === $section || 'user-shared-carts' === $section ) ) {
				$allow = false;
			}
			if ( 'yes' !== ccp_get_option_yes_default( 'ccp_manage_users' ) && 'users' === $section ) {
				$allow = false;
			}
		}

		/**
		 * Filter the authentication role.
		 * 
		 * @since 3.4.0
		 */
		return apply_filters( 'ccp_authentication_role', $allow, $ccp_company_role, $section );
	}
endif;

if ( ! function_exists( 'ccp_post_data' ) ) :
	/**
	 * Read sanitized POST data for CCP AJAX handlers.
	 *
	 * @param string $name Optional field name.
	 * @return mixed
	 */
	function ccp_post_data( $name = '' ) {
		$post = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing

		if ( '' === $name ) {
			return $post;
		}

		if ( ! isset( $post[ $name ] ) ) {
			return null;
		}

		$value = $post[ $name ];

		if ( is_array( $value ) ) {
			return map_deep( $value, 'sanitize_text_field' );
		}

		return sanitize_text_field( (string) $value );
	}
endif;

if ( ! function_exists( 'ccp_get_company_share_users' ) ) :
	/**
	 * Company users available as share-cart targets for the current user.
	 *
	 * @return array<int, array{user_id:int, display_name:string}>
	 */
	function ccp_get_company_share_users() {
		$company_id = get_user_meta( get_current_user_id(), 'ccp_company_id', true );
		$result     = array();

		if ( empty( $company_id ) ) {
			return $result;
		}

		$users = get_users(
			array(
				'meta_key'   => 'ccp_company_id',
				'meta_value' => $company_id,
			)
		);

		foreach ( $users as $user ) {
			if ( (int) get_current_user_id() === (int) $user->ID ) {
				continue;
			}

			$result[] = array(
				'user_id'      => (int) $user->ID,
				'display_name' => $user->display_name,
			);
		}

		return $result;
	}
endif;

if ( ! function_exists( 'ccp_get_credit_requests' ) ) :
	/**
	 * Get credit requests for a company.
	 *
	 * @param int $company_id Company post ID.
	 * @return array
	 */
	function ccp_get_credit_requests( $company_id ) {
		$requests = get_post_meta( absint( $company_id ), 'ccp_credit_requests', true );
		return is_array( $requests ) ? $requests : array();
	}
endif;

if ( ! function_exists( 'ccp_save_credit_requests' ) ) :
	/**
	 * Persist credit requests for a company.
	 *
	 * @param int   $company_id Company post ID.
	 * @param array $requests   Request rows.
	 * @return void
	 */
	function ccp_save_credit_requests( $company_id, $requests ) {
		update_post_meta( absint( $company_id ), 'ccp_credit_requests', is_array( $requests ) ? $requests : array() );
	}
endif;

if ( ! function_exists( 'ccp_user_can_review_credit_requests' ) ) :
	/**
	 * Whether the current user may approve/decline credit requests for a company queue.
	 *
	 * @param int         $company_id Company post ID.
	 * @param string|null $request_to Optional queue: admin|owner. Null = either queue capability.
	 * @return bool
	 */
	function ccp_user_can_review_credit_requests( $company_id, $request_to = null ) {
		$company_id = absint( $company_id );
		if ( empty( $company_id ) ) {
			return false;
		}

		$is_admin = current_user_can( 'edit_post', $company_id );

		if ( null === $request_to ) {
			if ( $is_admin ) {
				return true;
			}
			$user_company = (int) get_user_meta( get_current_user_id(), 'ccp_company_id', true );
			if ( $user_company !== $company_id ) {
				return false;
			}
			return 'ccp_owner' === get_user_meta( get_current_user_id(), 'ccp_company_role', true );
		}

		$request_to = ( 'admin' === $request_to ) ? 'admin' : 'owner';

		if ( 'admin' === $request_to ) {
			return $is_admin;
		}

		// Owner queue: company owner, or WP admin override.
		if ( $is_admin ) {
			return true;
		}

		$user_company = (int) get_user_meta( get_current_user_id(), 'ccp_company_id', true );
		if ( $user_company !== $company_id ) {
			return false;
		}

		return 'ccp_owner' === get_user_meta( get_current_user_id(), 'ccp_company_role', true );
	}
endif;

if ( ! function_exists( 'ccp_filter_credit_requests' ) ) :
	/**
	 * Filter credit requests by request_to queue.
	 *
	 * @param array  $requests   Request rows.
	 * @param string $request_to admin|owner.
	 * @return array Filtered rows keyed by original index.
	 */
	function ccp_filter_credit_requests( $requests, $request_to ) {
		if ( ! is_array( $requests ) ) {
			return array();
		}

		$request_to = ( 'admin' === $request_to ) ? 'admin' : 'owner';
		$filtered   = array();

		foreach ( $requests as $index => $request ) {
			if ( ! is_array( $request ) ) {
				continue;
			}
			$row_to = isset( $request['request_to'] ) ? $request['request_to'] : 'owner';
			// Legacy rows without request_to: treat as owner-queue (pre-dual-queue).
			if ( empty( $request['request_to'] ) ) {
				$row_to = 'owner';
			}
			if ( $row_to === $request_to ) {
				$filtered[ $index ] = $request;
			}
		}

		return $filtered;
	}
endif;

if ( ! function_exists( 'ccp_get_stored_user_wallet_balance' ) ) :
	/**
	 * Get a stored per-user wallet balance.
	 *
	 * @param array $wallet_balances Stored wallet balances.
	 * @param int   $user_id         User ID.
	 * @return float|null
	 */
	function ccp_get_stored_user_wallet_balance( $wallet_balances, $user_id ) {
		if ( ! is_array( $wallet_balances ) ) {
			return null;
		}

		$user_id = absint( $user_id );

		if ( array_key_exists( $user_id, $wallet_balances ) && is_numeric( $wallet_balances[ $user_id ] ) ) {
			return (float) $wallet_balances[ $user_id ];
		}

		if ( array_key_exists( (string) $user_id, $wallet_balances ) && is_numeric( $wallet_balances[ (string) $user_id ] ) ) {
			return (float) $wallet_balances[ (string) $user_id ];
		}

		return null;
	}
endif;

if ( ! function_exists( 'ccp_maybe_migrate_company_wallets' ) ) :
	/**
	 * One-time migration: move spendable balances out of credit limit overrides.
	 *
	 * @param int $company_id Company post ID.
	 * @return void
	 */
	function ccp_maybe_migrate_company_wallets( $company_id ) {
		$company_id = absint( $company_id );
		if ( empty( $company_id ) || get_post_meta( $company_id, '_ccp_wallets_migrated', true ) ) {
			return;
		}

		$wallets     = get_post_meta( $company_id, 'ccp_user_wallet_balances', true );
		$user_limits = get_post_meta( $company_id, 'ccp_user_credit_limits', true );
		if ( ! is_array( $wallets ) ) {
			$wallets = array();
		}

		$user_ids = array();
		foreach ( array( 'ccp_company_users_owner', 'ccp_company_users_manager', 'ccp_company_users_member' ) as $meta_key ) {
			$ids = get_post_meta( $company_id, $meta_key, true );
			if ( is_array( $ids ) ) {
				$user_ids = array_merge( $user_ids, array_map( 'absint', $ids ) );
			}
		}
		$user_ids = array_unique( array_filter( $user_ids ) );

		foreach ( $user_ids as $user_id ) {
			if ( null !== ccp_get_stored_user_wallet_balance( $wallets, $user_id ) ) {
				continue;
			}

			$limit = round( (float) ccp_get_effective_user_credit_limit( $company_id, $user_id ), 2 );
			if ( $limit > 0 ) {
				$wallets[ $user_id ] = $limit;
			}
		}

		update_post_meta( $company_id, 'ccp_user_wallet_balances', $wallets );
		update_post_meta( $company_id, '_ccp_wallets_migrated', 'yes' );
	}
endif;

if ( ! function_exists( 'ccp_get_user_wallet_balance' ) ) :
	/**
	 * Spendable wallet balance for a company user.
	 *
	 * @param int $company_id Company post ID.
	 * @param int $user_id    User ID.
	 * @return float
	 */
	function ccp_get_user_wallet_balance( $company_id, $user_id ) {
		$company_id = absint( $company_id );
		$user_id    = absint( $user_id );
		if ( empty( $company_id ) || empty( $user_id ) ) {
			return 0.0;
		}

		ccp_maybe_migrate_company_wallets( $company_id );

		$wallets = get_post_meta( $company_id, 'ccp_user_wallet_balances', true );
		$stored  = ccp_get_stored_user_wallet_balance( $wallets, $user_id );
		if ( null !== $stored ) {
			return max( 0, $stored );
		}

		$limit = ccp_get_effective_user_credit_limit( $company_id, $user_id );
		return is_numeric( $limit ) ? max( 0, (float) $limit ) : 0.0;
	}
endif;

if ( ! function_exists( 'ccp_set_user_wallet_balance' ) ) :
	/**
	 * Set a company user's wallet balance.
	 *
	 * @param int   $company_id Company post ID.
	 * @param int   $user_id    User ID.
	 * @param float $amount     New wallet amount.
	 * @return bool
	 */
	function ccp_set_user_wallet_balance( $company_id, $user_id, $amount ) {
		$company_id = absint( $company_id );
		$user_id    = absint( $user_id );
		if ( empty( $company_id ) || empty( $user_id ) ) {
			return false;
		}

		ccp_maybe_migrate_company_wallets( $company_id );

		$amount  = max( 0, (float) $amount );
		$wallets = get_post_meta( $company_id, 'ccp_user_wallet_balances', true );
		if ( ! is_array( $wallets ) ) {
			$wallets = array();
		}

		$wallets[ $user_id ] = round( $amount, 2 );
		update_post_meta( $company_id, 'ccp_user_wallet_balances', $wallets );

		return true;
	}
endif;

if ( ! function_exists( 'ccp_increase_user_wallet_balance' ) ) :
	/**
	 * Increase a user's wallet by amount.
	 *
	 * @param int   $company_id Company post ID.
	 * @param int   $user_id    User ID.
	 * @param float $amount     Amount to add.
	 * @return float New balance.
	 */
	function ccp_increase_user_wallet_balance( $company_id, $user_id, $amount ) {
		$current = ccp_get_user_wallet_balance( $company_id, $user_id );
		$new     = round( $current + max( 0, (float) $amount ), 2 );
		ccp_set_user_wallet_balance( $company_id, $user_id, $new );
		return $new;
	}
endif;

if ( ! function_exists( 'ccp_decrease_user_wallet_balance' ) ) :
	/**
	 * Decrease a user's wallet by amount (floored at 0).
	 *
	 * @param int   $company_id Company post ID.
	 * @param int   $user_id    User ID.
	 * @param float $amount     Amount to subtract.
	 * @return float|false New balance, or false if insufficient.
	 */
	function ccp_decrease_user_wallet_balance( $company_id, $user_id, $amount ) {
		$amount  = max( 0, (float) $amount );
		$current = ccp_get_user_wallet_balance( $company_id, $user_id );
		if ( $current < $amount ) {
			return false;
		}
		$new = round( $current - $amount, 2 );
		ccp_set_user_wallet_balance( $company_id, $user_id, $new );
		return $new;
	}
endif;

if ( ! function_exists( 'ccp_company_requires_order_approval' ) ) :
	/**
	 * Whether company credit orders require owner/manager approval.
	 *
	 * @param int $company_id Company post ID.
	 * @return bool
	 */
	function ccp_company_requires_order_approval( $company_id ) {
		$company_id = absint( $company_id );
		if ( empty( $company_id ) ) {
			return false;
		}

		return 'yes' === get_post_meta( $company_id, 'ccp_company_approved_orders', true );
	}
endif;

if ( ! function_exists( 'ccp_user_can_approve_order' ) ) :
	/**
	 * Whether a user may approve/reject a pending company credit order.
	 *
	 * @param \WC_Order|int $order   Order object or ID.
	 * @param int|null      $user_id Reviewer user ID (defaults to current user).
	 * @return bool
	 */
	function ccp_user_can_approve_order( $order, $user_id = null ) {
		$order = is_a( $order, 'WC_Order' ) ? $order : wc_get_order( $order );
		if ( ! $order ) {
			return false;
		}

		if ( ! $order->has_status( 'pending-approval' ) ) {
			return false;
		}

		$user_id = null === $user_id ? get_current_user_id() : absint( $user_id );
		if ( empty( $user_id ) ) {
			return false;
		}

		$company_id = absint( $order->get_meta( '_ccp_company_id' ) );
		$buyer_id   = absint( $order->get_meta( '_ccp_buyer_user_id' ) );
		if ( empty( $buyer_id ) ) {
			$buyer_id = absint( $order->get_user_id() );
		}
		if ( empty( $company_id ) ) {
			$company_id = absint( get_user_meta( $buyer_id, 'ccp_company_id', true ) );
		}

		if ( empty( $company_id ) || empty( $buyer_id ) ) {
			return false;
		}

		// Buyer cannot approve their own order.
		if ( (int) $user_id === (int) $buyer_id ) {
			return false;
		}

		$reviewer_company = absint( get_user_meta( $user_id, 'ccp_company_id', true ) );
		if ( $reviewer_company !== $company_id ) {
			return false;
		}

		if ( ! ccp_company_requires_order_approval( $company_id ) ) {
			return false;
		}

		$reviewer_role = get_user_meta( $user_id, 'ccp_company_role', true );
		$buyer_role    = get_user_meta( $buyer_id, 'ccp_company_role', true );
		$manager_ok    = 'yes' === get_post_meta( $company_id, 'ccp_manager_approval', true );

		if ( 'ccp_member' === $buyer_role ) {
			if ( 'ccp_owner' === $reviewer_role ) {
				return true;
			}
			return $manager_ok && 'ccp_manager' === $reviewer_role;
		}

		if ( 'ccp_manager' === $buyer_role ) {
			return in_array( $reviewer_role, array( 'ccp_owner', 'ccp_manager' ), true );
		}

		if ( 'ccp_owner' === $buyer_role ) {
			return in_array( $reviewer_role, array( 'ccp_owner', 'ccp_manager' ), true );
		}

		return false;
	}
endif;

if ( ! function_exists( 'ccp_approve_company_credit_order' ) ) :
	/**
	 * Approve a pending company credit order.
	 *
	 * @param int $order_id    Order ID.
	 * @param int $reviewer_id Reviewer user ID.
	 * @return true|\WP_Error
	 */
	function ccp_approve_company_credit_order( $order_id, $reviewer_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return new \WP_Error( 'ccp_order_missing', __( 'Order not found.', 'woocommerce-wholesale-pricing' ) );
		}

		if ( ! ccp_user_can_approve_order( $order, $reviewer_id ) ) {
			return new \WP_Error( 'ccp_forbidden', __( 'You are not allowed to approve this order.', 'woocommerce-wholesale-pricing' ) );
		}

		if ( ! $order->has_status( 'pending-approval' ) ) {
			return new \WP_Error( 'ccp_invalid_status', __( 'Only pending approval orders can be approved.', 'woocommerce-wholesale-pricing' ) );
		}

		$order->update_meta_data( '_ccp_approved_by', absint( $reviewer_id ) );
		$order->update_meta_data( '_ccp_approved_on', gmdate( 'Y-m-d H:i:s' ) );
		$order->update_meta_data( '_ccp_wallet_held', 0 );
		$order->update_status(
			'processing',
			sprintf(
				/* translators: %d: reviewer user ID */
				__( 'Company credit order approved by user #%d.', 'woocommerce-wholesale-pricing' ),
				absint( $reviewer_id )
			)
		);

		if ( function_exists( 'wc_reduce_stock_levels' ) ) {
			wc_reduce_stock_levels( $order_id );
		}

		$order->save();

		return true;
	}
endif;

if ( ! function_exists( 'ccp_reject_company_credit_order' ) ) :
	/**
	 * Reject a pending company credit order and restore held wallet funds.
	 *
	 * @param int $order_id    Order ID.
	 * @param int $reviewer_id Reviewer user ID.
	 * @return true|\WP_Error
	 */
	function ccp_reject_company_credit_order( $order_id, $reviewer_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return new \WP_Error( 'ccp_order_missing', __( 'Order not found.', 'woocommerce-wholesale-pricing' ) );
		}

		if ( ! ccp_user_can_approve_order( $order, $reviewer_id ) ) {
			return new \WP_Error( 'ccp_forbidden', __( 'You are not allowed to reject this order.', 'woocommerce-wholesale-pricing' ) );
		}

		if ( ! $order->has_status( 'pending-approval' ) ) {
			return new \WP_Error( 'ccp_invalid_status', __( 'Only pending approval orders can be rejected.', 'woocommerce-wholesale-pricing' ) );
		}

		$company_id = absint( $order->get_meta( '_ccp_company_id' ) );
		$buyer_id   = absint( $order->get_meta( '_ccp_buyer_user_id' ) );
		$held       = (float) $order->get_meta( '_ccp_wallet_held' );
		$restored   = $order->get_meta( '_ccp_wallet_restored' );

		if ( $held > 0 && 'yes' !== $restored && $company_id && $buyer_id ) {
			ccp_increase_user_wallet_balance( $company_id, $buyer_id, $held );
			ccp_add_company_credit(
				array(
					'company_id'   => $company_id,
					'order_id'     => $order_id,
					'amount'       => $held,
					'event'        => __( 'Company Credit Restored', 'woocommerce-wholesale-pricing' ),
					'user_id'      => $buyer_id,
					'affects_pool' => true,
				)
			);
			$order->update_meta_data( '_ccp_wallet_restored', 'yes' );
			$order->update_meta_data( '_ccp_wallet_held', 0 );
		}

		$order->update_meta_data( '_ccp_rejected_by', absint( $reviewer_id ) );
		$order->update_meta_data( '_ccp_rejected_on', gmdate( 'Y-m-d H:i:s' ) );
		$order->update_status(
			'cancelled',
			sprintf(
				/* translators: %d: reviewer user ID */
				__( 'Company credit order rejected by user #%d. Wallet credits restored.', 'woocommerce-wholesale-pricing' ),
				absint( $reviewer_id )
			)
		);
		$order->save();

		return true;
	}
endif;
