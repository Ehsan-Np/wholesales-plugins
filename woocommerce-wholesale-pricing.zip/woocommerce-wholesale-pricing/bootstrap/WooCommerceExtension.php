<?php
/**
 * WooCommerceExtension
 *
 * This class handles all required integrations with WooCommerce, including
 * dependency checks, feature compatibility declarations (like HPOS),
 * and adding admin-side user experience improvements (notices, action links).
 *
 * @package    WooCommerceWholesalePricing\Bootstrap
 */
namespace WooCommerceWholesalePricing\Bootstrap;

use Automattic\WooCommerce\Utilities\FeaturesUtil;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * WooCommerceExtension
 *
 * Manages plugin dependencies, compatibility, and administrative interface actions.
 */
class WooCommerceExtension {


	/**
		* Includes the WholesaleSettings trait to access methods like get_pricing_settings
		* for checking the plugin's initial setup status.
		*/
	use WholesaleSettings;
	  
	/**
	 * Method __construct
	 *
	 * Registers all necessary hooks for checking dependencies, declaring compatibility,
	 * adding action links, and loading translations.
	 *
	 * @return void
	 */
	public function __construct() {

		// Check for WooCommerce dependency on the 'admin_init' hook.
		add_action('admin_init', array( $this, 'check_for_dependencies' ));

		// Declare compatibility with modern WooCommerce features before its components initialize.
		add_action('before_woocommerce_init', array( $this, 'woo_hpos_incompatibility' ));

		// Add 'Settings' link to the plugin entry on the plugins list page.
		add_filter(sprintf('plugin_action_links_%1$s/%1$s.php', WWP_BASENAME), array( $this, 'plugin_action_links' ));
		 
		// Load translations at init (required since WordPress 6.7).
		add_action( 'init', array( $this, 'load_plugin_textdomain' ), 0 );

		// Deactivate merged standalone plugins before they register blocks on init.
		add_action( 'plugins_loaded', array( $this, 'deactivation_conflicts' ), 0 );
		add_action( 'activated_plugin', array( $this, 'deactivate_conflicting_plugin_on_activation' ), 10, 1 );

		// Show a warning notice in the admin area if essential settings are missing.
		if (is_admin() ) {
			add_action('admin_notices', array( $this, 'setting_notice' ));
			add_action('admin_notices', array( $this, 'merged_plugin_deactivation_notice' ));
		}
	}
	  
	/**
	 * Method check_for_dependencies
	 *
	 * Checks if WooCommerce is installed and activated. If not, it registers an
	 * admin notice and deactivates the current plugin.
	 *
	 * @return void
	 */
	public function check_for_dependencies() {
		$this->deactivation_conflicts();

		$plugin = 'woocommerce/woocommerce.php';
		/**
		 * Active plugins
		 * 
		 * @since 1.0.0
		 */
		$subsite_active_plugins = (array) apply_filters( 'active_plugins', get_option( 'active_plugins' ) );
		$is_subsite_active = in_array( $plugin, $subsite_active_plugins );

		$is_network_active = false;
		if ( is_multisite() ) {
			$network_active_plugins = (array) get_site_option( 'active_sitewide_plugins' );
			$is_network_active = array_key_exists( $plugin, $network_active_plugins );
		}

		$class_exists = class_exists( 'WooCommerce' );

		if ( ! $is_network_active && ! $is_subsite_active && ! $class_exists ) {
			add_action( 'admin_notices', array( $this, 'woocommerce_missing_notice' ) );
		}
	}
	  
	/**
	 * Method woocommerce_missing_notice
	 *
	 * Displays a critical error notice in the admin area and deactivates the plugin.
	 *
	 * @return void
	 */
	public function woocommerce_missing_notice() {
		$class = 'notice notice-error';
		$message = esc_html__('Wholesale For WooCommerce requires WooCommerce to be installed and activated, in order to work', 'woocommerce-wholesale-pricing');
		printf('<div class="%1$s"><p>%2$s</p></div>', esc_html($class), esc_html($message));
		deactivate_plugins(plugin_basename(WWP_FILE));
	}

	/**
	 * Method woo_hpos_incompatibility
	 *
	 * Declares compatibility with WooCommerce's High-Performance Order Storage (HPOS)
	 * and the new Cart/Checkout Blocks system using the FeaturesUtil class.
	 * Declaring compatibility is crucial for future-proofing the plugin.
	 *
	 * @return void
	 */
	public function woo_hpos_incompatibility() {
		if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil') ) {
			$_file = sprintf('%s%s.php', WWP_PLUGIN_PATH, WWP_BASENAME);

			FeaturesUtil::declare_compatibility('custom_order_tables', $_file, true);
			FeaturesUtil::declare_compatibility('cart_checkout_blocks', $_file, true);
		}
	}
	 
	/**
	 * Method load_plugin_textdomain
	 *
	 * Loads the plugin's text domain from the 'languages' directory for translation.
	 *
	 * @return void
	 */
	public function load_plugin_textdomain() {
		load_plugin_textdomain('woocommerce-wholesale-pricing', false, dirname(plugin_basename(WWP_FILE)) . '/languages/');
	}
	  
	/**
	 * Method plugin_action_links
	 *
	 * Adds a "Settings" link to the array of action links shown on the Plugins page.
	 *
	 * @param array $actions Existing action links array (e.g., 'Activate', 'Edit').
	 *
	 * @return array Modified array of action links.
	 */
	public function plugin_action_links( array $actions ) {
		$deactivate = '';
		if ( isset($actions['deactivate']) ) {
			$deactivate             = $actions['deactivate'];
			unset($actions['deactivate']);
		}

		$actions['settings']    = sprintf('<a href="%s">%s</a>', admin_url('admin.php?page=wwp_wholesale'), __('Settings', 'woocommerce-wholesale-pricing'));
		
		if ( $deactivate ) {
			$actions['deactivate']  = $deactivate;
		}
		return $actions;
	}

	/**
	 * Displays an administrative notice if the core pricing settings are empty.
	 * This prompts the user to navigate to the settings page to complete the setup.
	 *
	 * @return void
	 */
	public function setting_notice() {
		$wwp_pricing_options = self::get_pricing_settings();
		/**
		 * Hooks
		 *
		 * @since 3.0
		 */
		if (empty($wwp_pricing_options) && apply_filters('wwp_settings_notice', true)) {
			$class = 'notice notice-warning is-dismissible';
			/**
			* Hooks
			*
			* @since 3.0
			*/
			$plugin_name = apply_filters('wwp_wholsale_plg_title', esc_html__('Wholesale For WooCommerce', 'woocommerce-wholesale-pricing'));
			$heading     = esc_html__('Thank You for installing', 'woocommerce-wholesale-pricing');
			$message     = esc_html__('Your current settings are incomplete. Settings must be saved in order to run the plugin. Click here to ', 'woocommerce-wholesale-pricing');
			printf('<div class="%1$s"><h2>%2$s %3$s</h2><p> %4$s <a href="%5$s">%6$s</a></p></div>', esc_html($class), esc_html($heading), esc_html($plugin_name), esc_html($message), esc_url(admin_url('admin.php?page=wwp_wholesale')), esc_html__('Setup', 'woocommerce-wholesale-pricing'));
		}
	}

	public function deactivation_conflicts() {
		static $processed = false;

		if ( $processed ) {
			return;
		}

		$target_plugins = $this->get_conflicting_plugins();

		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$deactivated_plugins = array();

		foreach ( $target_plugins as $plugin ) {
			if ( ! is_plugin_active( $plugin ) ) {
				continue;
			}

			// Do not use deactivate_plugins() here: it loads the plugin bootstrap and can
			// re-register blocks/features already merged into this plugin.
			$this->deactivate_conflicting_plugin_without_bootstrap( $plugin );
			$deactivated_plugins[] = $plugin;
		}

		if ( empty( $deactivated_plugins ) ) {
			return;
		}

		$processed = true;

		set_transient( 'wwp_deactivation_notice', $deactivated_plugins, MINUTE_IN_SECONDS );
	}

	/**
	 * Immediately deactivate a conflicting plugin when it is activated in admin.
	 *
	 * @param string $plugin Activated plugin basename.
	 * @return void
	 */
	public function deactivate_conflicting_plugin_on_activation( $plugin ) {
		$target_plugins = $this->get_conflicting_plugins();

		if ( ! in_array( $plugin, $target_plugins, true ) ) {
			return;
		}

		if ( ! function_exists( 'is_plugin_active' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		if ( ! is_plugin_active( $plugin ) ) {
			return;
		}

		$this->deactivate_conflicting_plugin_without_bootstrap( $plugin );

		$deactivated_plugins = get_transient( 'wwp_deactivation_notice' );
		$deactivated_plugins = is_array( $deactivated_plugins ) ? $deactivated_plugins : array();

		if ( ! in_array( $plugin, $deactivated_plugins, true ) ) {
			$deactivated_plugins[] = $plugin;
		}

		set_transient( 'wwp_deactivation_notice', $deactivated_plugins, MINUTE_IN_SECONDS );
	}

	/**
	 * Standalone plugins whose features are merged into this plugin.
	 *
	 * Sales Agent is only conflicting when the built-in module is enabled.
	 *
	 * @return array<int, string>
	 */
	private function get_conflicting_plugins() {
		$target_plugins = array(
			'quote-for-woocommerce/b2b-request-a-quote.php',
		);

		if ( function_exists( 'is_sales_agent_enabled' ) && is_sales_agent_enabled() ) {
			$target_plugins[] = 'sales-agent-for-woocommerce/wc-sales-agent.php';
		}

		if ( function_exists( 'is_company_credits_enabled' ) && is_company_credits_enabled() ) {
			$target_plugins[] = 'b2b-company-credits-permissions-for-woocommerce/b2b-company-credits-permissions-for-woocommerce.php';
			$target_plugins[] = 'b2b-company-credits-permissions-for-woocommerce/b2b-company-credits-permissions-for-woocommerce-fs.php';
		}

		return $target_plugins;
	}

	/**
	 * Remove a plugin from the active list without loading its main file.
	 *
	 * @param string $plugin Plugin basename.
	 * @return void
	 */
	private function deactivate_conflicting_plugin_without_bootstrap( $plugin ) {
		$active_plugins = (array) get_option( 'active_plugins', array() );
		$plugin_key     = array_search( $plugin, $active_plugins, true );

		if ( false !== $plugin_key ) {
			unset( $active_plugins[ $plugin_key ] );
			update_option( 'active_plugins', array_values( $active_plugins ) );
		}

		if ( is_multisite() ) {
			$network_active = (array) get_site_option( 'active_sitewide_plugins', array() );

			if ( isset( $network_active[ $plugin ] ) ) {
				unset( $network_active[ $plugin ] );
				update_site_option( 'active_sitewide_plugins', $network_active );
			}
		}
	}

	/**
	 * Admin notice after merged standalone plugins were auto-deactivated.
	 *
	 * @return void
	 */
	public function merged_plugin_deactivation_notice() {
		$deactivated_plugins = get_transient( 'wwp_deactivation_notice' );

		if ( empty( $deactivated_plugins ) ) {
			return;
		}

		delete_transient( 'wwp_deactivation_notice' );

		if ( ! is_array( $deactivated_plugins ) ) {
			$deactivated_plugins = array( 'quote-for-woocommerce/b2b-request-a-quote.php' );
		}

		$messages = array(
			'quote-for-woocommerce/b2b-request-a-quote.php'   => __( 'Quote for WooCommerce was deactivated because its features are already included in Wholesale for WooCommerce.', 'woocommerce-wholesale-pricing' ),
			'sales-agent-for-woocommerce/wc-sales-agent.php' => __( 'Sales Agent for WooCommerce was deactivated because its features are already included in Wholesale for WooCommerce.', 'woocommerce-wholesale-pricing' ),
			'b2b-company-credits-permissions-for-woocommerce/b2b-company-credits-permissions-for-woocommerce.php'   => __( 'B2B Company Credits and Permissions was deactivated because its features are already included in Wholesale for WooCommerce.', 'woocommerce-wholesale-pricing' ),
			'b2b-company-credits-permissions-for-woocommerce/b2b-company-credits-permissions-for-woocommerce-fs.php' => __( 'B2B Company Credits and Permissions was deactivated because its features are already included in Wholesale for WooCommerce.', 'woocommerce-wholesale-pricing' ),
		);

		foreach ( $deactivated_plugins as $plugin ) {
			if ( empty( $messages[ $plugin ] ) ) {
				continue;
			}

			printf(
				'<div class="notice notice-warning is-dismissible"><p>%s</p></div>',
				esc_html( $messages[ $plugin ] )
			);
		}
	}
}
