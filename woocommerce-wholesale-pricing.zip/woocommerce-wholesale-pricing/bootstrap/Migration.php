<?php
/**
 * Migration
 *
 * This class handles the data migration required when users update the plugin
 * from an older version to a newer one, ensuring old configuration data is
 * successfully converted to the new schema.
 *
 * @package    WooCommerceWholesalePricing\Bootstrap
 */
namespace WooCommerceWholesalePricing\Bootstrap;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettings;

/**
 * Migration
 *
 * Manages the conversion of legacy options and data structures.
 */
class Migration {
	/**
	 * Includes the WholesaleSettings trait to gain access to helper methods
	 * for reading and writing plugin options (e.g., get_registration_settings).
	 */
	use WholesaleSettings;

	public function __construct() {

		add_action('init', array( $this, 'process' ), 200, 1);
	}

	public function classes() {
		return array(
			'WooCommerceWholesalePricing\App\Migrations\PricingVisibilityMigration',
			'WooCommerceWholesalePricing\App\Migrations\RegistrationUserDataMigration',
			'WooCommerceWholesalePricing\App\Migrations\QuoteBuilderFields',
			'WooCommerceWholesalePricing\App\Migrations\EnableQuoteFromRulesMigration',
			'WooCommerceWholesalePricing\App\Migrations\RecaptchaQuoteMigration',
			'WooCommerceWholesalePricing\App\Migrations\AIAssistantHistoryTableMigration',
			'WooCommerceWholesalePricing\App\Migrations\SalesAgentCommissionsTableMigration',
		);
	}

	public function process() {
		foreach ( $this->classes() as $class ) {
			if ( class_exists($class) ) {
				new $class();
			} else {
				wc_get_logger()->error("Migration class $class not found.", array( 'source' => 'woocommerce-wholesale-pricing' ));
				continue;
			}

		}
	}
}
