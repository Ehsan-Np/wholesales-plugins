<?php

use WooCommerceWholesalePricing\App\Providers\Environment;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

if (! function_exists('wwp_view') ) {
	/**
	 * Method wwp_view template loader prefix resources/views
	 *
	 * @param  string $path
	 * @param  array  $args
	 * @param  bool   $in_loop
	 * @return void|string
	 */
	function wwp_view( $path, $args = array(), $in_loop = false ) {
		extract($args);
		if (empty($path) ) {
			return esc_html__('Incorrect File Path.', 'store-credits-and-gift-cards');
		} else {
			$path = str_replace('.', '/', $path);
			if ($in_loop ) {
				include sprintf('%sresources/views/%s.php', WWP_PLUGIN_PATH, $path); // nosemgrep: audit.php.lang.security.file.inclusion-arg   
			} else {
				include_once sprintf('%sresources/views/%s.php', WWP_PLUGIN_PATH, $path); // nosemgrep: audit.php.lang.security.file.inclusion-arg
			}
		}
	}

}

if (! function_exists('wwp_env') ) {
	/**
	 * Method wwp_env
	 *
	 * @return Environment
	 */
	function wwp_env() {
		return Environment::instance();
	}
}

if ( ! function_exists( 'wwp_sanitize_price' ) ) :
	/**
	 * Sanitize a wholesale price using the store decimal separator (same as WooCommerce core).
	 *
	 * Accepts both "12.50" and "12,50" when the store decimal separator is a comma.
	 * Already-saved dotted values stay valid.
	 *
	 * @param mixed $value Raw price input.
	 * @return string Empty string or a numeric string using a dot decimal.
	 */
	function wwp_sanitize_price( $value ) {
		if ( '' === $value || null === $value ) {
			return '';
		}
		$value = wc_format_decimal( wc_clean( (string) $value ) );
		return is_numeric( $value ) ? (string) $value : '';
	}
endif;

if ( ! function_exists( 'wwp_sanitize_tier_prices' ) ) :
	/**
	 * Sanitize nested tier pricing `price` fields.
	 *
	 * @param mixed $tiers Tier pricing array.
	 * @return array
	 */
	function wwp_sanitize_tier_prices( $tiers ) {
		if ( ! is_array( $tiers ) ) {
			return array();
		}
		foreach ( $tiers as $key => $value ) {
			if ( is_array( $value ) ) {
				$tiers[ $key ] = wwp_sanitize_tier_prices( $value );
			} elseif ( 'price' === $key ) {
				$tiers[ $key ] = wwp_sanitize_price( $value );
			}
		}
		return $tiers;
	}
endif;

if ( ! function_exists( 'wwp_format_price_for_input' ) ) :
	/**
	 * Format a stored price for an admin input using the store decimal separator.
	 *
	 * @param mixed $value Stored price.
	 * @return string
	 */
	function wwp_format_price_for_input( $value ) {
		if ( '' === $value || null === $value ) {
			return '';
		}
		return function_exists( 'wc_format_localized_price' ) ? wc_format_localized_price( $value ) : (string) $value;
	}
endif;

if (! function_exists('shapeSpace_allowed_html') ) :
	function shapeSpace_allowed_html() {

		$allowed_atts                = array(
		'align'      => array(),
		'class'      => array(),
		'type'       => array(),
		'id'         => array(),
		'dir'        => array(),
		'lang'       => array(),
		'style'      => array(),
		'xml:lang'   => array(),
		'src'        => array(),
		'alt'        => array(),
		'href'       => array(),
		'rel'        => array(),
		'rev'        => array(),
		'target'     => array(),
		'novalidate' => array(),
		'required'   => array(),
		'name'       => array(),
		'tabindex'   => array(),
		'action'     => array(),
		'method'     => array(),
		'for'        => array(),
		'width'      => array(),
		'height'     => array(),
		'data'       => array(),
		'title'      => array(),
		'value'      => array(),
		'selected'   => array(),
		'enctype'    => array(),
		'disable'    => array(),
		'disabled'   => array(),
		'noscript'   => array(),
		);
		$allowedposttags['form']     = $allowed_atts;
		$allowedposttags['required'] = $allowed_atts;
		$allowedposttags['noscript'] = $allowed_atts;
		$allowedposttags['label']    = $allowed_atts;
		$allowedposttags['select']   = $allowed_atts;
		$allowedposttags['option']   = $allowed_atts;
		$allowedposttags['input']    = $allowed_atts;
		$allowedposttags['textarea'] = $allowed_atts;
		$allowedposttags['iframe']   = $allowed_atts;
		$allowedposttags['script']   = $allowed_atts;
		$allowedposttags['style']    = $allowed_atts;
		$allowedposttags['strong']   = $allowed_atts;
		$allowedposttags['small']    = $allowed_atts;
		$allowedposttags['table']    = $allowed_atts;
		$allowedposttags['span']     = $allowed_atts;
		$allowedposttags['abbr']     = $allowed_atts;
		$allowedposttags['code']     = $allowed_atts;
		$allowedposttags['pre']      = $allowed_atts;
		$allowedposttags['div']      = $allowed_atts;
		$allowedposttags['img']      = $allowed_atts;
		$allowedposttags['h1']       = $allowed_atts;
		$allowedposttags['h2']       = $allowed_atts;
		$allowedposttags['h3']       = $allowed_atts;
		$allowedposttags['h4']       = $allowed_atts;
		$allowedposttags['h5']       = $allowed_atts;
		$allowedposttags['h6']       = $allowed_atts;
		$allowedposttags['ol']       = $allowed_atts;
		$allowedposttags['ul']       = $allowed_atts;
		$allowedposttags['li']       = $allowed_atts;
		$allowedposttags['em']       = $allowed_atts;
		$allowedposttags['hr']       = $allowed_atts;
		$allowedposttags['br']       = $allowed_atts;
		$allowedposttags['tr']       = $allowed_atts;
		$allowedposttags['td']       = $allowed_atts;
		$allowedposttags['p']        = $allowed_atts;
		$allowedposttags['a']        = $allowed_atts;
		$allowedposttags['b']        = $allowed_atts;
		$allowedposttags['i']        = $allowed_atts;
		return $allowedposttags;
	}
endif;

if (! function_exists('escape_allowed_tags') ) :    
	/**
	 * Method escape_allowed_tags
	 *
	 * @return array
	 */
	function escape_allowed_tags() {
		$allowed_tags = array(
		'a'      => array(
		'class' => array(),
		'href'  => array(),
		'rel'   => array(),
		'title' => array(),
		),
		'b'      => array(),
		'del'    => array(
		'datetime' => array(),
		'title'    => array(),
		),
		'dd'     => array(),
		'select' => array(
		'id'       => array(),
		'class'    => array(),
		'title'    => array(),
		'style'    => array(),
		'name'     => array(),
		'disabled' => array(),
		),
		'table'  => array(
		'id'          => array(),
		'class'       => array(),
		'style'       => array(),
		'cellpadding' => array(),
		),
		'tr'     => array(
		'id'    => array(),
		'class' => array(),
		'style' => array(),
		),
		'td'     => array(
		'id'    => array(),
		'class' => array(),
		'style' => array(),
		),
		'th'     => array(
		'id'    => array(),
		'class' => array(),
		'style' => array(),
		),
		'button' => array(
		'id'          => array(),
		'class'       => array(),
		'type'        => array(),
		'style'       => array(),
		'value'       => array(),
		'placeholder' => array(),
		'name'        => array(),
		'data-id'     => array(),
		),
		'input'  => array(
		'id'          => array(),
		'class'       => array(),
		'type'        => array(),
		'style'       => array(),
		'value'       => array(),
		'placeholder' => array(),
		'name'        => array(),
		'data'        => array(),
		'checked'     => array(),
		'readonly'    => array(),
		'disabled'    => array(),
		),
		'option' => array(
		'selected' => array(),
		'value'    => array(),
		),
		'div'    => array(
		'id'    => array(),
		'class' => array(),
		'title' => array(),
		'style' => array(),
		),
		'dl'     => array(),
		'dt'     => array(),
		'em'     => array(),
		'h1'     => array(),
		'h2'     => array(),
		'h3'     => array(),
		'h4'     => array(),
		'h5'     => array(),
		'h6'     => array(),
		'i'      => array(),
		'img'    => array(
		'alt'    => array(),
		'class'  => array(),
		'height' => array(),
		'src'    => array(),
		'width'  => array(),
		),
		'li'     => array(
		'class' => array(),
		),
		'ol'     => array(
		'class' => array(),
		),
		'p'      => array(
		'id'    => array(),
		'class' => array(),
		'style' => array(),
		),
		'span'   => array(
		'class' => array(),
		'id'    => array(),
		'title' => array(),
		'style' => array(),
		),
		'label'  => array(
		'for'   => array(),
		'id'    => array(),
		'class' => array(),
		),
		'strike' => array(),
		'strong' => array(),
		'ul'     => array(
		'class' => array(),
		),
		);
		return $allowed_tags;
	}
endif;

if (! function_exists('wwp_get_post_data') ) :    
	/**
	 * Method wwp_get_post_data
	 *
	 * @param  string $name
	 * @return string|array
	 */
	function wwp_get_post_data( $name = '' ) {
		if (isset($_POST['wwp_wholesale_registrattion_nonce']) && wp_verify_nonce(wc_clean($_POST['wwp_wholesale_registrattion_nonce']), 'wwp_wholesale_registrattion_nonce') ) {
			$post = $_POST;
		}

		$post = $_POST;
		if (isset($post[ $name ]) ) { 
			/**
			* Hooks
			*
			* @since 3.0
			*/
			return apply_filters('wwp_get_post_data', $post[ $name ]);
		} else {
			return $_POST;
		}
	}
endif;

if (! function_exists('wwp_get_get_data') ) :    
	/**
	 * Method wwp_get_get_data
	 *
	 * @param  string $name
	 * @return string|array
	 */
	function wwp_get_get_data( $name = '' ) {
		if (isset($_GET['wwp_wholesale_registrattion_nonce']) && wp_verify_nonce(wc_clean($_GET['wwp_wholesale_registrattion_nonce']), 'wwp_wholesale_registrattion_nonce') ) {
			$get = $_GET;
		}
		$get = $_GET;
		if (isset($get[ $name ]) ) {
			/**
			* Hooks
			*
			* @since 3.0
			*/
			return apply_filters('wwp_get_get_data', wp_kses_post($get[ $name ]));
		} else {
			return $_GET;
		}
	}
endif;

if (! function_exists('wholesale_tab_link') ) :    
	/**
	 * Method wholesale_tab_link
	 *
	 * @param  string $tab
	 * @return string
	 */
	function wholesale_tab_link( $tab = '' ) {

		if (! empty($tab) ) {
			return admin_url('admin.php?page=wwp-registration-setting&tab=') . $tab;
		} else {
			return admin_url('admin.php?page=wwp-registration-setting');
		}
	}
endif;

if (! function_exists('wholesale_tab_active') ) :    
	/**
	 * Method wholesale_tab_active
	 *
	 * @param  string $active_tab
	 * @return string|void
	 */
	function wholesale_tab_active( $active_tab = '' ) {
		$getdata = '';
		if (isset($_GET['tab']) ) {
			$getdata = sanitize_text_field($_GET['tab']);
		}

		if ($getdata == $active_tab ) {
			return 'nav-tab-active';
		}
	}
endif;

if (! function_exists('wholesale_content_tab_active') ) :    
	/**
	 * Method wholesale_content_tab_active
	 *
	 * @param  string $active_tab
	 * @return string
	 */
	function wholesale_content_tab_active( $active_tab = '' ) {
		$getdata = '';
		if (isset($_GET['tab']) ) {
			$getdata = sanitize_text_field($_GET['tab']);
		}

		if ($getdata == $active_tab ) {
			return 'bolck';
		} else {
			return 'none';
		}
	}
endif;

if (! function_exists('wholesale_load_form_builder') ) :    
	/**
	 * Method wholesale_load_form_builder
	 *
	 * @param  string $active_tab
	 * @return bool
	 */
	function wholesale_load_form_builder( $active_tab = '' ) {
		$tab = '';
		if (isset($_GET['tab']) ) {
			$tab = sanitize_text_field($_GET['tab']);
		}

		if (! in_array($tab, array( 'extra-fields', 'quote-form-builder', 'sales-agent' ), true) ) {
			return true;
		} else {
			return false;
		}
	}
endif;


if (! function_exists('is_wholesaler_user') ) :    
	/**
	 * Method is_wholesaler_user
	 *
	 * @param  int $user_id
	 * @return bool
	 */
	function is_wholesaler_user( $user_id ) {
		if (! empty($user_id) ) {
			$settings  = WholesaleSettingsHelper::get_pricing_settings();
			$user_info = get_userdata($user_id);
			$user_role = implode(', ', $user_info->roles);
			if (function_exists('icl_object_id') && class_exists('SitePress') ) {
				global $sitepress;
				$current_lang = $sitepress->get_current_language();
				$sitepress->switch_lang('en');
				$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
				$sitepress->switch_lang($current_lang);
			} else {
				$allterms = get_terms(array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ));
			}

			if (isset($settings['wholesale_role']) && 'single' == $settings['wholesale_role'] && 'default_wholesaler' == $user_role ) {
				return true;
			} elseif (isset($settings['wholesale_role']) && 'multiple' == $settings['wholesale_role'] ) {
				foreach ( $allterms as $allterm_key => $allterm_value ) {
					if (@$allterm_value->slug == $user_role ) {
						return true;
					}
				}
			}
		}
		if (isset($_COOKIE['access_store_id']) && ! empty($_COOKIE['access_store_id']) ) {
			return true;
		}
		return false;
	}
endif;

if (! function_exists('is_wholesale_product_quantity') ) :    
	/**
	 * Method is_wholesale_product_quantity
	 *
	 * @param  int $product_id
	 * @return int
	 */
	function is_wholesale_product_quantity( $product_id ) {
		$role = get_current_user_role_id();
		$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
		if (isset($data[ $role ]) ) {
			if (isset($data[ $role ]['min_quatity']) ) {
				return (int) $data[ $role ]['min_quatity'];
			} else {
				return 1;
			}
		}
		$terms = get_the_terms($product_id, 'product_cat');
		if (! is_wp_error($terms) && ! empty($terms) ) {
			foreach ( $terms as $term ) {
				$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
				if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
					if (isset($data[ $role ]['min_quatity']) ) {
						return (int) $data[ $role ]['min_quatity'];
					} else {
						return 1;
					}
				}
			}
		}
		$data = WholesaleSettingsHelper::get_multiuser_pricing_settings();
		if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
			if (isset($data[ $role ]['min_quatity']) ) {
				return (int) $data[ $role ]['min_quatity'];
			} else {
				return 1;
			}
		}
		return 1;
	}
endif;

if (! function_exists('multi_wholesale_product_ids') ) :    
	/**
	 * Method multi_wholesale_product_ids
	 *
	 * @return array
	 */
	function multi_wholesale_product_ids() {
		$cate      = array();
		$total_ids = array();

		$categories = get_terms(array( 'taxonomy' => 'product_cat' ));

		if (is_array($categories) ) {

			foreach ( $categories as $category ) {

				$data = get_term_meta($category->term_id, 'wholesale_multi_user_pricing', true);

				if (! empty($data) ) {
					foreach ( $data as $key => $value ) {

						if (isset($data[ $key ]['wholesale_price']) ) {
							$cate[] = $category->term_id;
						}
					}
				}
			}

			$cate = array_unique($cate);

			if (empty($cate) ) {
				return array();
			}

			$cate_string = implode($cate);

			global $wpdb;

			$result = $wpdb->get_results(
				$wpdb->prepare( 
					"SELECT p.ID AS id FROM {$wpdb->prefix}posts AS p LEFT JOIN {$wpdb->prefix}term_relationships AS tr ON p.ID = tr.object_id WHERE tr.term_taxonomy_id IN (%s) AND p.post_type = 'product' AND p.post_status = 'publish' GROUP BY p.ID", $cate_string 
				)
			);

			$ids = wp_list_pluck((array) $result, 'id');

			if (is_array($ids) ) {

				foreach ( $ids  as $id ) {
					$total_ids[] = $id;
				}
			}
		}

		$all_ids = get_products_by_meta();
		 
		foreach ( $all_ids as $id ) {

			$data = get_post_meta($id, 'wholesale_multi_user_pricing', true);
			if (! empty($data) ) {
				foreach ( $data as $key => $value ) {
					if (isset($data[ $key ]) ) {
						$total_ids[] = $id;
					}
				}
			}
		}

		if (is_array($all_ids) ) {
			foreach ( $all_ids  as $id ) {
				$total_ids[] = $id;
			}
		}
		return array_unique($total_ids);
	}
endif;

if (! function_exists('refresh_structure_form') ) :    
	/**
	 * Method refresh_structure_form
	 *
	 * @param  string $formData
	 * @return string
	 */
	function refresh_structure_form( $formData ) {
		$formData = json_decode($formData);
		if (is_array($formData) ) {
			foreach ( $formData as $formData_key => $formData_value ) {
				if (isset($formData_value->userData) ) {
					if (isset($formData_value->required) ) {
						$formData[ $formData_key ]->required = false;
					}
					if (isset($formData_value->values) ) {
						foreach ( $formData_value->values as $formData_value_key => $formData_value_val ) {
							   $formData[ $formData_key ]->values[ $formData_value_key ]->selected = false;
						}
					}
				}
			}
		}
		return json_encode($formData);
	}
endif;

if (! function_exists('wwp_render_characters_remove') ) :    
	/**
	 * Method wwp_render_characters_remove
	 *
	 * @param  string $formData
	 * @return string
	 */
	function wwp_render_characters_remove( $formData ) {
		$formData = refresh_structure_form($formData);
		$formData = str_replace("'", '&#39;', $formData);
		/**
		* Hooks
		*
		* @since 3.0
		*/
		return apply_filters('wwp_render_characters_remove', $formData);
	}
endif;

if (! function_exists('wwp_normalize_form_submission_data') ) :
	/**
	 * Normalize form submission data from option/meta into a PHP array.
	 *
	 * @param mixed $raw Raw stored form submission data.
	 * @return array
	 */
	function wwp_normalize_form_submission_data( $raw ) {
		if ( null === $raw || '' === $raw || false === $raw ) {
			return array();
		}

		$data = $raw;

		if ( is_string( $data ) ) {
			$maybe_unserialized = maybe_unserialize( $data );
			if ( $maybe_unserialized !== $data ) {
				$data = $maybe_unserialized;
			} else {
				$decoded = json_decode( wp_unslash( $data ), true );
				if ( JSON_ERROR_NONE !== json_last_error() ) {
					$decoded = json_decode( stripslashes( $data ), true );
				}
				if ( JSON_ERROR_NONE !== json_last_error() || null === $decoded ) {
					return array();
				}
				$data = $decoded;
			}
		} elseif ( is_object( $data ) ) {
			$data = json_decode( wp_json_encode( $data ), true );
		}

		if ( is_string( $data ) ) {
			$decoded = json_decode( $data, true );
			$data    = ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) ) ? $decoded : array();
		}

		if ( ! is_array( $data ) ) {
			return array();
		}

		$data = wwp_decode_stringified_form_submission_values( $data );

		return wwp_decode_formio_file_fields( $data );
	}
endif;

if ( ! function_exists( 'wwp_decode_stringified_form_submission_values' ) ) :
	/**
	 * Decode JSON object/array strings saved as field values in legacy payloads.
	 *
	 * @param array $data Submission data.
	 * @return array
	 */
	function wwp_decode_stringified_form_submission_values( $data ) {
		if ( ! is_array( $data ) ) {
			return array();
		}

		foreach ( $data as $key => $value ) {
			if ( ! is_string( $value ) ) {
				continue;
			}

			$trimmed = trim( wp_unslash( $value ) );
			if ( '' === $trimmed || ( '[' !== substr( $trimmed, 0, 1 ) && '{' !== substr( $trimmed, 0, 1 ) ) ) {
				continue;
			}

			$decoded = json_decode( $trimmed, true );
			if ( JSON_ERROR_NONE === json_last_error() && is_array( $decoded ) ) {
				$data[ $key ] = $decoded;
			}
		}

		return $data;
	}
endif;

if ( ! function_exists( 'wwp_is_formio_file_value' ) ) :
	/**
	 * Whether a value looks like a Form.io file component payload.
	 *
	 * @param mixed $value Field value.
	 * @return bool
	 */
	function wwp_is_formio_file_value( $value ) {
		if ( is_string( $value ) ) {
			$trimmed = trim( wp_unslash( $value ) );
			if ( '' === $trimmed || ( '[' !== substr( $trimmed, 0, 1 ) && '{' !== substr( $trimmed, 0, 1 ) ) ) {
				return false;
			}
			$decoded = json_decode( $trimmed, true );
			if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
				return false;
			}
			$value = $decoded;
		}

		if ( ! is_array( $value ) || empty( $value ) ) {
			return false;
		}

		$first = isset( $value[0] ) ? $value[0] : $value;

		return is_array( $first ) && ( isset( $first['url'] ) || isset( $first['storage'] ) );
	}
endif;

if ( ! function_exists( 'wwp_decode_formio_file_fields' ) ) :
	/**
	 * Decode JSON-encoded Form.io file fields so Form.io can render them.
	 *
	 * @param array $data Submission data.
	 * @return array
	 */
	function wwp_decode_formio_file_fields( $data ) {
		if ( ! is_array( $data ) ) {
			return array();
		}

		foreach ( $data as $key => $value ) {
			if ( is_string( $value ) && wwp_is_formio_file_value( $value ) ) {
				$decoded = json_decode( wp_unslash( $value ), true );
				if ( is_array( $decoded ) ) {
					$data[ $key ] = $decoded;
				}
			}
		}

		return $data;
	}
endif;

if ( ! function_exists( 'wwp_sideload_formio_file' ) ) :
	/**
	 * Persist a Form.io file (base64 data URI) to the media library.
	 *
	 * @param array $file    Form.io file object.
	 * @param int   $user_id User ID used as attachment author.
	 * @return array
	 */
	function wwp_sideload_formio_file( $file, $user_id ) {
		if ( ! is_array( $file ) || empty( $file['url'] ) || ! is_string( $file['url'] ) ) {
			return $file;
		}

		$url = $file['url'];
		if ( 0 === strpos( $url, 'http://' ) || 0 === strpos( $url, 'https://' ) ) {
			return $file;
		}

		if ( 0 !== strpos( $url, 'data:' ) || ! preg_match( '/^data:([^;]+);base64,(.+)$/s', $url, $matches ) ) {
			return $file;
		}

		$binary = base64_decode( $matches[2], true );
		if ( false === $binary ) {
			return $file;
		}

		$filename = 'upload.bin';
		if ( ! empty( $file['originalName'] ) ) {
			$filename = $file['originalName'];
		} elseif ( ! empty( $file['name'] ) ) {
			$filename = $file['name'];
		}
		$filename = sanitize_file_name( $filename );

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$tmp = wp_tempnam( $filename );
		if ( ! $tmp ) {
			return $file;
		}

		file_put_contents( $tmp, $binary ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

		$attachment_id = media_handle_sideload(
			array(
				'name'     => $filename,
				'tmp_name' => $tmp,
			),
			0,
			null,
			array( 'post_author' => $user_id )
		);

		if ( is_wp_error( $attachment_id ) ) {
			wp_delete_file( $tmp );
			return $file;
		}

		$attachment_url = wp_get_attachment_url( $attachment_id );
		if ( $attachment_url ) {
			$file['url']     = $attachment_url;
			$file['storage'] = 'url';
		}

		return $file;
	}
endif;

if ( ! function_exists( 'wwp_get_form_builder_schema' ) ) :
	/**
	 * Get decoded wholesale registration form builder schema.
	 *
	 * @return array
	 */
	function wwp_get_form_builder_schema() {
		$schema = json_decode(
			str_replace( '"false"', 'false', wp_unslash( (string) get_option( 'wwp_save_form', '{}' ) ) ),
			true
		);

		return is_array( $schema ) ? $schema : array();
	}
endif;

if ( ! function_exists( 'wwp_collect_form_builder_file_keys' ) ) :
	/**
	 * Collect Form.io file component keys from a schema tree.
	 *
	 * @param array $components Form builder components.
	 * @return array<int, string>
	 */
	function wwp_collect_form_builder_file_keys( $components ) {
		$keys = array();

		if ( ! is_array( $components ) ) {
			return $keys;
		}

		foreach ( $components as $component ) {
			if ( ! is_array( $component ) ) {
				continue;
			}

			if ( isset( $component['type'], $component['key'] ) && 'file' === $component['type'] ) {
				$keys[] = $component['key'];
			}

			if ( ! empty( $component['components'] ) && is_array( $component['components'] ) ) {
				$keys = array_merge( $keys, wwp_collect_form_builder_file_keys( $component['components'] ) );
			}
		}

		return $keys;
	}
endif;

if ( ! function_exists( 'wwp_render_form_builder_file_hidden_inputs' ) ) :
	/**
	 * Output hidden inputs used to post Form.io file component values.
	 *
	 * @return void
	 */
	function wwp_render_form_builder_file_hidden_inputs() {
		$schema     = wwp_get_form_builder_schema();
		$components = isset( $schema['components'] ) ? $schema['components'] : array();

		foreach ( wwp_collect_form_builder_file_keys( $components ) as $key ) {
			echo '<input type="hidden" name="data[' . esc_attr( $key ) . ']" value="">';
		}
	}
endif;

if ( ! function_exists( 'wwp_prepare_form_builder_user_data' ) ) :
	/**
	 * Decode posted Form.io data and persist file uploads to the media library.
	 *
	 * @param array $data Posted form data.
	 * @param int   $user_id User ID.
	 * @return array
	 */
	function wwp_prepare_form_builder_user_data( $data, $user_id ) {
		$data = wwp_decode_formio_file_fields( is_array( $data ) ? $data : array() );

		foreach ( $data as $key => $value ) {
			if ( ! wwp_is_formio_file_value( $value ) ) {
				continue;
			}

			$files = $value;
			if ( is_string( $files ) ) {
				$files = json_decode( wp_unslash( $files ), true );
			}
			if ( ! is_array( $files ) ) {
				continue;
			}

			$is_list = isset( $files[0] );
			if ( ! $is_list ) {
				$files = array( $files );
			}

			foreach ( $files as $index => $file ) {
				$files[ $index ] = wwp_sideload_formio_file( $file, $user_id );
			}

			$data[ $key ] = $is_list ? $files : $files[0];
		}

		return $data;
	}
endif;

if (! function_exists('wwp_get_quote_form_builder_config') ) :
	/**
	 * Get decoded quote form builder configuration.
	 *
	 * @return array
	 */
	function wwp_get_quote_form_builder_config() {
		$form_config = json_decode(
			str_replace( '"false"', 'false', wp_unslash( (string) get_option( 'wc_quote_form_builder', '{}' ) ) ),
			true
		);

		return is_array( $form_config ) ? $form_config : array();
	}
endif;

if (! function_exists('wwp_get_posted_form_builder_submission_data') ) :
	/**
	 * Restore Form.io submission data from a failed registration POST.
	 *
	 * @return array
	 */
	function wwp_get_posted_form_builder_submission_data() {
		if (
			! isset( $_POST['wwp_register'], $_POST['data'] )
			|| ! is_array( $_POST['data'] )
		) {
			return array();
		}

		if (
			! isset( $_POST['wwp_wholesale_registrattion_nonce'] )
			|| ! wp_verify_nonce(
				wc_clean( wp_unslash( $_POST['wwp_wholesale_registrattion_nonce'] ) ),
				'wwp_wholesale_registrattion_nonce'
			)
		) {
			return array();
		}

		$posted_data = wc_clean( wp_unslash( $_POST['data'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		return wwp_normalize_form_submission_data( $posted_data );
	}
endif;

if (! function_exists('wwp_get_wholesale_form_builder_config') ) :
	/**
	 * Get decoded wholesale registration form builder schema.
	 *
	 * @return array
	 */
	function wwp_get_wholesale_form_builder_config() {
		$raw = get_option( 'wwp_save_form', '{}' );
		if ( is_array( $raw ) ) {
			$form_config = $raw;
		} else {
			$form_config = json_decode( wp_unslash( (string) $raw ), true );
		}

		if ( ! is_array( $form_config ) ) {
			return array( 'components' => array() );
		}

		$form_config = wwp_cast_formio_schema_flags( $form_config );

		if ( ! isset( $form_config['components'] ) || ! is_array( $form_config['components'] ) ) {
			$form_config['components'] = array();
		}

		return $form_config;
	}
endif;

if ( ! function_exists( 'wwp_cast_formio_schema_flags' ) ) :
	/**
	 * Cast string "true"/"false" flags in a Form.io schema without changing option values.
	 *
	 * @param mixed $data Schema node.
	 * @return mixed
	 */
	function wwp_cast_formio_schema_flags( $data ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}

		$preserve_string_keys = array(
			'value',
			'label',
			'key',
			'placeholder',
			'description',
			'tooltip',
			'defaultValue',
			'content',
			'html',
			'title',
			'suffix',
			'prefix',
		);

		foreach ( $data as $key => $value ) {
			if ( is_array( $value ) ) {
				$data[ $key ] = wwp_cast_formio_schema_flags( $value );
				continue;
			}

			if ( in_array( (string) $key, $preserve_string_keys, true ) ) {
				continue;
			}

			if ( 'false' === $value ) {
				$data[ $key ] = false;
			} elseif ( 'true' === $value ) {
				$data[ $key ] = true;
			}
		}

		return $data;
	}
endif;

if ( ! function_exists( 'wwp_collect_formio_component_types' ) ) :
	/**
	 * Map Form.io component keys to type metadata.
	 *
	 * @param array $components Form.io components.
	 * @param array $map        Accumulator.
	 * @return array
	 */
	function wwp_collect_formio_component_types( $components, &$map = array() ) {
		if ( ! is_array( $components ) ) {
			return $map;
		}

		foreach ( $components as $component ) {
			if ( ! is_array( $component ) ) {
				continue;
			}

			if ( ! empty( $component['key'] ) && ! empty( $component['type'] ) ) {
				$map[ $component['key'] ] = array(
					'type'     => $component['type'],
					'multiple' => ! empty( $component['multiple'] ),
				);
			}

			if ( ! empty( $component['components'] ) && is_array( $component['components'] ) ) {
				wwp_collect_formio_component_types( $component['components'], $map );
			}

			if ( ! empty( $component['columns'] ) && is_array( $component['columns'] ) ) {
				foreach ( $component['columns'] as $column ) {
					if ( ! empty( $column['components'] ) ) {
						wwp_collect_formio_component_types( $column['components'], $map );
					}
				}
			}

			if ( ! empty( $component['rows'] ) && is_array( $component['rows'] ) ) {
				foreach ( $component['rows'] as $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}
					foreach ( $row as $cell ) {
						if ( ! empty( $cell['components'] ) ) {
							wwp_collect_formio_component_types( $cell['components'], $map );
						}
					}
				}
			}
		}

		return $map;
	}
endif;

if ( ! function_exists( 'wwp_normalize_formio_submission_values' ) ) :
	/**
	 * Normalize posted Form.io values so radios/selects remain scalar.
	 *
	 * @param mixed $data   Submission data.
	 * @param array $schema Form schema.
	 * @return array
	 */
	function wwp_normalize_formio_submission_values( $data, $schema = null ) {
		if ( ! is_array( $data ) ) {
			return array();
		}

		if ( ! is_array( $schema ) ) {
			$schema = wwp_get_wholesale_form_builder_config();
		}

		$types = array();
		if ( isset( $schema['components'] ) ) {
			wwp_collect_formio_component_types( $schema['components'], $types );
		}

		foreach ( $data as $key => $value ) {
			if ( is_string( $value ) ) {
				$trimmed = trim( $value );
				if ( '' !== $trimmed && ( '{' === $trimmed[0] || '[' === $trimmed[0] ) ) {
					$decoded = json_decode( $value, true );
					if ( JSON_ERROR_NONE === json_last_error() && null !== $decoded ) {
						$value = $decoded;
					}
				}
			}

			$type     = isset( $types[ $key ]['type'] ) ? $types[ $key ]['type'] : '';
			$multiple = ! empty( $types[ $key ]['multiple'] );
			$flatten  = ( 'radio' === $type ) || ( 'select' === $type && ! $multiple );

			if ( $flatten && is_array( $value ) ) {
				if ( isset( $value['value'] ) && ! is_array( $value['value'] ) ) {
					$value = $value['value'];
				} elseif ( 1 === count( $value ) ) {
					$value = reset( $value );
				}
			}

			$data[ $key ] = $value;
		}

		return $data;
	}
endif;

if ( ! function_exists( 'wwp_get_form_builder_posted_data' ) ) :
	/**
	 * Read Form.io submission data from a request.
	 *
	 * @param array|null $post Request data.
	 * @return array
	 */
	function wwp_get_form_builder_posted_data( $post = null ) {
		if ( ! is_array( $post ) ) {
			$post = $_POST; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		}

		$candidates = array();
		foreach ( array( 'wwp_formio_submission', 'wwp_form_data_json' ) as $key ) {
			if ( ! empty( $post[ $key ] ) && is_string( $post[ $key ] ) ) {
				$candidates[] = wp_unslash( $post[ $key ] );
			}
		}

		foreach ( $candidates as $raw ) {
			$decoded = json_decode( $raw, true );
			if ( is_array( $decoded ) ) {
				return wwp_normalize_formio_submission_values( $decoded );
			}
		}

		if ( isset( $post['data'] ) && is_array( $post['data'] ) && ! empty( $post['data'] ) ) {
			return wwp_normalize_formio_submission_values( wp_unslash( $post['data'] ) );
		}

		return array();
	}
endif;

if (! function_exists('wwp_get_initial_form_submission_data') ) :
	/**
	 * Load and normalize initial form submission data for Formio rendering.
	 *
	 * @param string $callbach_data_form Data source identifier.
	 * @param int    $user_id            User ID.
	 * @param bool   $is_admin_context   Whether the admin context is active.
	 * @param bool   $is_myaccount_context Whether the my account context is active.
	 * @return array
	 */
	function wwp_get_initial_form_submission_data( $callbach_data_form, $user_id, $is_admin_context, $is_myaccount_context ) {
		if ( $is_admin_context ) {
			$wwp_save_form = '[]';
			if ( 'get_option' === $callbach_data_form ) {
				$wwp_save_form = get_option( 'wwp_save_form', '[]' );
			} elseif ( 'get_post_meta' === $callbach_data_form ) {
				$wwp_save_form = get_post_meta( $user_id, 'wwp_form_data_json', true ) ? get_post_meta( $user_id, 'wwp_form_data_json', true ) : '[]';
			} elseif ( ( 'get_user_meta' === $callbach_data_form || ! empty( $user_id ) ) && ! empty( get_user_meta( $user_id, 'wwp_form_data_json', true ) ) ) {
				$wwp_save_form = get_user_meta( $user_id, 'wwp_form_data_json', true );
			} else {
				$wwp_save_form = get_option( 'wwp_save_form', '[]' );
			}

			return wwp_normalize_formio_submission_values( wwp_normalize_form_submission_data( $wwp_save_form ) );
		}

		if ( $is_myaccount_context ) {
			$wwp_save_form = get_user_meta($user_id, 'wwp_form_data_json', true) ? get_user_meta($user_id, 'wwp_form_data_json', true) : '[]';
			return wwp_normalize_formio_submission_values( wwp_normalize_form_submission_data( $wwp_save_form ) );
		}

		return wwp_get_posted_form_builder_submission_data();
	}
endif;

if (! function_exists('render_form_builder') ) :    
	/**
	 * Method render_form_builder
	 *
	 * @param  string $callbach_data_form
	 * @param  int    $user_id
	 * @return void
	 */
	function render_form_builder( $callbach_data_form, $user_id = '' ) {
		$form_wrap_id = 'wc-wholesale-fields-render-wrap';
		$is_admin_context       = is_admin();
		$is_myaccount_context   = is_account_page();
		$wp_doing_ajax          = wp_doing_ajax();
		$current_user           = wp_get_current_user();
		$user_email             = ( $current_user instanceof \WP_User && $current_user->exists() ) ? $current_user->user_email : '';
		$builder_schema         = wwp_get_wholesale_form_builder_config();

		if ( wp_script_is( 'wwp_formbuilder', 'registered' ) ) {
			wp_enqueue_style( 'wwp_formbuilder' );
			wp_enqueue_script( 'wwp_formbuilder' );
		}

		$initial_submission_data = wwp_get_initial_form_submission_data(
			$callbach_data_form,
			$user_id,
			$is_admin_context,
			$is_myaccount_context
		);
		
		?>
		<div id="container-wrap">
			<div id="<?php echo esc_attr($form_wrap_id); ?>"></div>
			<?php wwp_render_form_builder_file_hidden_inputs(); ?>
			<?php if ( $is_admin_context ) { ?>
				<input type="hidden" name="wwp_form_data_json" id="wwp_form_data_json" value="">
			<?php } ?>
		</div>

		<script>
			jQuery( document ).ready(function($) {
				var isAdminContext = <?php echo wp_json_encode($is_admin_context); ?>;
				var isMyAccountContext = <?php echo wp_json_encode($is_myaccount_context); ?>;
				var isDoingAjax = <?php echo wp_json_encode($wp_doing_ajax); ?>;
				var components = <?php echo wp_json_encode( $builder_schema, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ); ?>;
				var user_email = <?php echo wp_json_encode( $user_email ); ?>;
				
				var builderElement = document.getElementById('<?php echo esc_js($form_wrap_id); ?>');
				var registerButtonSelector = '.wwp_wholesaler_registration #register';
				var registrationFormSelector = '.wwp_wholesaler_registration_form';

				if ( jQuery('button[name="save_account_details"]').length > 0 ) {
					registerButtonSelector = 'button[name="save_account_details"]';
					registrationFormSelector = '.woocommerce-EditAccountForm.edit-account';
				} else if ( jQuery('input[name="wwp_register_upgrade"]').length > 0 ) {
					registerButtonSelector = 'input[name="wwp_register_upgrade"]';
					registrationFormSelector = '.wwp_wholesaler_registration form';
				}
				var formDataInputPrefix = 'input[name="data[';
				var formDataInputSuffix = ']"]';
				var formOptions = isAdminContext ? { readOnly: false } : { language: 'en' };
				var initialSubmissionData = <?php echo wp_json_encode( $initial_submission_data, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ); ?>;
				if (Array.isArray(initialSubmissionData) && !initialSubmissionData.length) {
					initialSubmissionData = {};
				}

				var getParentForm = function() {
					if (jQuery(registrationFormSelector).length) {
						return jQuery(registrationFormSelector).first();
					}
					if (builderElement && builderElement.closest) {
						var closestForm = builderElement.closest('form');
						if (closestForm) {
							return jQuery(closestForm);
						}
					}
					return jQuery();
				};

				var syncAllComponentValues = function(submissionData) {
					if (!submissionData) {
						return;
					}

					Object.keys(submissionData).forEach(function(key) {
						var value = submissionData[key];
						var $input = jQuery(formDataInputPrefix + key + formDataInputSuffix);

						if (!$input.length) {
							jQuery(registrationFormSelector).append(
								jQuery('<input>', { type: 'hidden', name: 'data[' + key + ']' })
							);
							$input = jQuery(formDataInputPrefix + key + formDataInputSuffix);
						}
						if (item.columns) {
							jQuery.each(item.columns, function(columnIndex, column) {
								if (column.components) {
									setFileComponentValues(column.components, submissionData);
								}
							});
						}

						if (typeof value === 'undefined' || value === null) {
							$input.val('');
							return;
						}

						if (typeof value === 'object') {
							$input.val(JSON.stringify(value));
							return;
						}

						$input.val(value);
					});
				};

				var syncFileComponentValues = function(schemaItems, submissionData) {
					syncAllComponentValues(submissionData);
				};

				var getComponentTypeMap = function(schemaItems, typeMap) {
					if (schemaItems && !Array.isArray(schemaItems) && Array.isArray(schemaItems.components)) {
						schemaItems = schemaItems.components;
					}

					if (!Array.isArray(schemaItems)) {
						return typeMap;
					}

					schemaItems.forEach(function(item) {
						if (!item || typeof item !== 'object') {
							return;
						}

						if (item.key && item.type) {
							typeMap[item.key] = item.type;
						}

						if (Array.isArray(item.components)) {
							getComponentTypeMap(item.components, typeMap);
						}
					});

					return typeMap;
				};

				var maybeParseJsonString = function(value) {
					if (typeof value !== 'string') {
						return value;
					}

					var trimmed = value.trim();
					if (!trimmed || (trimmed[0] !== '{' && trimmed[0] !== '[')) {
						return value;
					}

					try {
						return JSON.parse(trimmed);
					} catch (e) {
						return value;
					}
				};

				var normalizeSelectboxesValue = function(value) {
					if (Array.isArray(value)) {
						var normalized = {};
						value.forEach(function(entry) {
							if (typeof entry === 'string' || typeof entry === 'number') {
								normalized[String(entry)] = true;
								return;
							}

							if (entry && typeof entry === 'object') {
								Object.keys(entry).forEach(function(entryKey) {
									normalized[entryKey] = !!entry[entryKey];
								});
							}
						});
						return normalized;
					}

					if (value && typeof value === 'object') {
						return value;
					}

					return {};
				};

				var normalizeComparableKey = function(value) {
					return String(value || '')
						.toLowerCase()
						.replace(/&/g, 'and')
						.replace(/[^a-z0-9]+/g, '_')
						.replace(/^_+|_+$/g, '');
				};

				var normalizeSelectboxesValueForComponent = function(value, component) {
					var normalized = normalizeSelectboxesValue(value);
					if (!component || !component.component) {
						return normalized;
					}

					var options = [];
					if (Array.isArray(component.component.values)) {
						options = component.component.values;
					} else if (
						component.component.data
						&& Array.isArray(component.component.data.values)
					) {
						options = component.component.data.values;
					}

					if (!options.length) {
						return normalized;
					}

					var currentKeys = {};
					Object.keys(normalized).forEach(function(existingKey) {
						currentKeys[normalizeComparableKey(existingKey)] = !!normalized[existingKey];
					});

					var remapped = {};
					options.forEach(function(option) {
						if (!option || typeof option !== 'object') {
							return;
						}

						var optionValue = String(option.value || '');
						if (!optionValue) {
							return;
						}

						var exact = Object.prototype.hasOwnProperty.call(normalized, optionValue)
							? !!normalized[optionValue]
							: null;
						if (exact !== null) {
							remapped[optionValue] = exact;
							return;
						}

						var comparableCandidates = [
							normalizeComparableKey(optionValue),
							normalizeComparableKey(option.label || ''),
						];

						var matched = false;
						comparableCandidates.forEach(function(candidate) {
							if (!candidate || matched) {
								return;
							}
							if (Object.prototype.hasOwnProperty.call(currentKeys, candidate)) {
								remapped[optionValue] = !!currentKeys[candidate];
								matched = true;
							}
						});

						if (!matched) {
							remapped[optionValue] = false;
						}
					});

					return remapped;
				};

				var normalizeCheckboxValue = function(value) {
					if (typeof value === 'boolean') {
						return value;
					}

					if (Array.isArray(value)) {
						return value.length > 0;
					}

					if (value && typeof value === 'object') {
						var keys = Object.keys(value);
						if (keys.length === 1 && typeof value[keys[0]] === 'boolean') {
							return value[keys[0]];
						}
						return keys.length > 0;
					}

					if (typeof value === 'string') {
						var normalized = value.trim().toLowerCase();
						return normalized === 'true' || normalized === '1' || normalized === 'yes' || normalized === 'on';
					}

					return !!value;
				};

				var resolveComponentType = function(form, key, componentTypeMap) {
					if (form && typeof form.getComponent === 'function') {
						var component = form.getComponent(key);
						if (component && component.component && component.component.type) {
							return component.component.type;
						}
					}

					return componentTypeMap[key];
				};

				var normalizeSubmissionDataBySchema = function(schemaItems, submissionData, form) {
					if (!submissionData || typeof submissionData !== 'object') {
						return {};
					}

					var componentTypeMap = getComponentTypeMap(schemaItems, {});
					var normalizedData = {};

					Object.keys(submissionData).forEach(function(key) {
						var componentType = resolveComponentType(form, key, componentTypeMap);
						var component = (form && typeof form.getComponent === 'function') ? form.getComponent(key) : null;
						var value = maybeParseJsonString(submissionData[key]);

						if (componentType === 'selectboxes') {
							normalizedData[key] = normalizeSelectboxesValueForComponent(value, component);
							return;
						}

						if (componentType === 'checkbox') {
							normalizedData[key] = normalizeCheckboxValue(value);
							return;
						}

						normalizedData[key] = value;
					});

					return normalizedData;
				};

				var syncFormioSubmissionToParentForm = function(submissionData) {
					var payload = JSON.stringify(submissionData && !Array.isArray(submissionData) ? submissionData : {});
					var $parentForm = getParentForm();
					var $hidden = $parentForm.find('input.wwp-formio-data, input[name="wwp_formio_submission"]').first();
					if (!$hidden.length) {
						$hidden = jQuery('input.wwp-formio-data, input[name="wwp_formio_submission"]').first();
					}
					if (!$hidden.length) {
						$hidden = jQuery('<input>', {
							type: 'hidden',
							name: 'wwp_formio_submission',
							'class': 'wwp-formio-data'
						});
						if ($parentForm.length) {
							$parentForm.append($hidden);
						} else if (builderElement) {
							jQuery(builderElement).after($hidden);
						}
					}
					$hidden.val(payload);

					var $legacy = jQuery('#wwp_form_data_json');
					if ($legacy.length) {
						$legacy.val(payload);
					}

					setFileComponentValues(components.components, submissionData || {});
				};

				var applySavedSubmission = function(form) {
					var data = initialSubmissionData;
					if (!data || (Array.isArray(data) && !data.length)) {
						data = {};
					}
					var fallback = jQuery.Deferred().resolve().promise();
					if (typeof form.setSubmission !== 'function') {
						form.submission = { data: data };
						return fallback;
					}
					try {
						var result = form.setSubmission({ data: data });
						if (result && typeof result.then === 'function') {
							return result.catch(function() {
								form.submission = { data: data };
							});
						}
						return fallback;
					} catch (e) {
						form.submission = { data: data };
						return fallback;
					}
				};

				var initFormBuilder = function() {
					if (!builderElement || typeof Formio === 'undefined' || typeof components === 'undefined') {
						return false;
					}

					// Keep custom components available in frontend rendering, not only admin builder.
					if (
						Formio.Components
						&& Formio.Components.components
						&& ! Formio.Components.components.color
						&& Formio.Components.components.textfield
					) {
						var TextFieldComponent = Formio.Components.components.textfield;

						class ColorComponent extends TextFieldComponent {
							static schema() {
								return TextFieldComponent.schema({
									type: 'color',
									label: 'Color',
									key: 'color',
									input: true,
									defaultValue: '#000000'
								});
							}

							get inputInfo() {
								var info = super.inputInfo;
								info.attr.type = 'color';
								return info;
							}
						}

						Formio.Components.addComponent('color', ColorComponent);
					}

					Formio.createForm(builderElement, components, formOptions).then(function(form) {
						form.nosubmit = true;
						var normalizedInitialSubmissionData = normalizeSubmissionDataBySchema(components, initialSubmissionData, form);

						if (isAdminContext || isMyAccountContext) {
							form.submission = { data: normalizedInitialSubmissionData };

							form.on('change', function() {
								syncAllComponentValues(form.submission.data);
							});

							if (isAdminContext && ! isDoingAjax) {
								jQuery('#submit, #createusersub').on('click', function() {
									syncAllComponentValues(form.submission.data);
								});
								syncAllComponentValues(form.submission.data);
								return;
							}
						} else if (normalizedInitialSubmissionData && Object.keys(normalizedInitialSubmissionData).length) {
							form.submission = { data: normalizedInitialSubmissionData };
							syncAllComponentValues(form.submission.data);
						}

						const email = form.getComponent('email');
						if ( email && !email.getValue() ) {
							email.setValue(user_email);
						}

						jQuery(registerButtonSelector).on('click', function(e) {
							e.preventDefault();
							form.emit('submitButton');
						});

						form.on('submit', function(submission) {
							var current_button = jQuery(registerButtonSelector);
							let isValid = true;
							let errorMessages = [];
							Object.keys(submission.data).forEach(function(key) {
								let value = submission.data[key];
								let formattedKey = key
									.replace(/([a-z])([A-Z])/g, "$1 $2")
									.toUpperCase();
								if (key === "email") {
									if (!value || (typeof value === "string" && value.trim() === "")) {
										isValid = false;
										errorMessages.push(
											`<p style="color: red; font-size: 16px;">
												Field "${formattedKey}" cannot be empty.
											</p>`
										);
									}
								}
							});
							// Stop here if validation failed.
							if (!isValid) {
								// Make sure the button can be clicked again.
								current_button.removeClass('loading');
								// current_button.css('opacity', '1');
								// Display errors if required.
								console.log(errorMessages);
								return false;
							}
							// Only disable the button when the form is actually valid.
							current_button.addClass('loading');
							// current_button.css('opacity', '0.2');
							syncAllComponentValues(form.submission.data);
							jQuery(registrationFormSelector)[0].requestSubmit(
								document.querySelector(registerButtonSelector)
							);
							return false;
						});

						if (normalizedInitialSubmissionData && Object.keys(normalizedInitialSubmissionData).length) {
							syncAllComponentValues(normalizedInitialSubmissionData);
						}
					});

					return true;
				};

				if (!initFormBuilder()) {
					jQuery(window).on('load', function() {
						initFormBuilder();
					});
				}
			});
		</script>
		<?php
	}
endif;

if (! function_exists('wwp_wholesale_css') ) :    
	/**
	 * Method wwp_wholesale_css
	 *
	 * @param  array $settings
	 * @return void
	 */
	function wwp_wholesale_css( $settings ) {
		if (isset($settings['wholesale_css']) ) {
			?>
			<style type="text/css">
			<?php 
			/**
			 * Hooks
			 *
			 * @since 3.0
			 */
			$wwp_registration_form_css = apply_filters('wwp_registration_form_css', $settings['wholesale_css']);
			echo wp_kses_post($wwp_registration_form_css);
			?>
			</style>
			<?php
		}
	}
endif;

if (! function_exists('registration_form_class') ) :    
	/**
	 * Method registration_form_class
	 *
	 * @param  string $css
	 * @return string
	 */
	function registration_form_class( $css ) {
		/**
		* Hooks
		*
		* @since 3.0
		*/
		return apply_filters('registration_form_class', $css);
	}
endif;

if (! function_exists('wwp_elements') ) :    
	/**
	 * Method wwp_elements
	 *
	 * @param  string $elements
	 * @return void prints \HTML
	 */
	function wwp_elements( $elements ) {
		/**
		* Hooks
		*
		* @since 3.0
		*/
		echo wp_kses_post(apply_filters('wwp_registration_form_elements', $elements));
	}
endif;

if (! function_exists('form_builder_update_user_meta') ) :    
	/**
	 * Method form_builder_update_user_meta
	 *
	 * @param  int   $user_id
	 * @param  array $post
	 * @return void
	 */
	function form_builder_update_user_meta( $user_id, $post ) {
		$data = wwp_get_form_builder_posted_data( $post );
		if ( ! empty( $data ) ) {
			update_user_meta( $user_id, 'wwp_form_data_json', $data );
		}

		$data = array();
		if ( isset( $post['data'] ) ) {
			$raw_data = wp_unslash( $post['data'] );
			if ( is_array( $raw_data ) ) {
				$data = $raw_data;
			}
		}

		foreach ( $data as $key => $value ) {
			if ( null === $value || '' === $value ) {
				unset( $data[ $key ] );
			}
		}

		if ( empty( $data ) ) {
			return;
		}

		$existing = get_user_meta( $user_id, 'wwp_form_data_json', true );
		if ( is_string( $existing ) ) {
			$existing = wwp_normalize_form_submission_data( $existing );
		} elseif ( ! is_array( $existing ) ) {
			$existing = array();
		}

		$data = array_merge( $existing, $data );
		$data = wwp_prepare_form_builder_user_data( $data, $user_id );

		update_user_meta( $user_id, 'wwp_form_data_json', $data );
	}
endif;

if (! function_exists('wwp_get_tax_price_display_suffix') ) :    
	/**
	 * Method wwp_get_tax_price_display_suffix
	 *
	 * @param  int $product_id
	 * @return void|string
	 */
	function wwp_get_tax_price_display_suffix( $product_id ) {

		if (is_admin() ) {
			return;
		}

		global $woocommerce;
		$product = wc_get_product($product_id);

		$tax_display_suffix = '';
		if (isset( $woocommerce->customer ) && is_object( $woocommerce->customer ) && $woocommerce->customer->is_vat_exempt() == false && get_option('woocommerce_price_display_suffix') && 'taxable' == get_post_meta($product_id, '_tax_status', true) ) {
			$tax_display_suffix = get_option('woocommerce_price_display_suffix');
			$tax_display_suffix = '<small class="woocommerce-price-suffix">' . $tax_display_suffix . '</small>';
		}

		/**
		* Hooks
		*
		* @since 3.0
		*/
		return apply_filters('wwp_get_tax_price_display_suffix', $tax_display_suffix);
	}
endif;

if (! function_exists('wwp_get_price_including_tax') ) :    
	/**
	 * Method wwp_get_price_including_tax
	 *
	 * @param  \WC_Product $product
	 * @param  array       $args
	 * @return int
	 */
	function wwp_get_price_including_tax( $product, $args = array() ) {

		if (is_admin() ) {
			return $args['price'];
		}
		 
		global $woocommerce;
		if (isset($woocommerce) && is_object($woocommerce) && isset( $woocommerce->customer ) && is_object( $woocommerce->customer ) && method_exists($woocommerce->customer, 'is_vat_exempt') ) {
			if ($woocommerce->customer->is_vat_exempt() == false && 'taxable' == get_post_meta($product->get_id(), '_tax_status', true) ) {
				if (( ! is_cart() || ! is_checkout() ) && 'excl' == get_option('woocommerce_tax_display_shop') ) {
					$price = $args['price'];
				} else {
					$price = wc_get_price_including_tax($product, array( 'price' => $args['price'] ));
				}
			} else {
				$price = $args['price'] ;
			}
		} else {
			// Handle the case when $woocommerce object is not available
			$price = $args['price'] ;
		}

		if (class_exists('Wpexperts\CurrencySwitcherForWoocommerce\WCCS') ) {
			global $WCCS;
			$price = $WCCS->wccs_price_conveter($price, false);
		}
		 
		/**
		* Hooks
		*
		* @since 3.0
		*/
		return apply_filters('wwp_get_price_including_tax', $price, $product);
	}
endif;

if (! function_exists('wwp_get_price_including_tax_for_requisition') ) :    
	/**
	 * Method wwp_get_price_including_tax_for_requisition
	 *
	 * @param  \WC_Product $product
	 * @param  array       $args
	 * @return string
	 */
	function wwp_get_price_including_tax_for_requisition( $product, $args = array() ) {

		global $woocommerce;
		if (isset( $woocommerce->customer ) && is_object( $woocommerce->customer ) && $woocommerce->customer->is_vat_exempt() == false && 'taxable' == get_post_meta($product->get_id(), '_tax_status', true) ) {
			if (( ! is_cart() || ! is_checkout() ) && 'excl' == get_option('woocommerce_tax_display_shop') ) {
				$price = $args['price'];
			} else {
				$price = wc_get_price_including_tax($product, array( 'price' => $args['price'] ));
			}
		} else {
			$price = $args['price'];
		}

		if (class_exists('Wpexperts\CurrencySwitcherForWoocommerce\WCCS') ) {
			global $WCCS;
			$price = $WCCS->wccs_price_conveter($price, false);
		}
		 
		/**
		* Hooks
		*
		* @since 3.0
		*/
		return apply_filters('wwp_get_price_including_tax_for_requisition', $price, $product);
	}
endif;

if (! function_exists('get_wholesale_role_id') ) :    
	/**
	 * Method get_wholesale_role_id
	 *
	 * @param  string $user_role
	 * @return int|void
	 */
	function get_wholesale_role_id( $user_role = '' ) {
		$wholesale_role = term_exists($user_role, 'wholesale_user_roles');
		if (0 !== $wholesale_role && null !== $wholesale_role ) {
			if (is_array($wholesale_role) && isset($wholesale_role['term_id']) ) {
				return $wholesale_role['term_id'];
			}
		}
	}
endif;

if (! function_exists('tier_pricing_modal_popup') ) :    
	/**
	 * Method tier_pricing_modal_popup
	 *
	 * @param  string     $title
	 * @param  string     $id
	 * @param  string     $role_id
	 * @param  string     $data
	 * @param  string     $name
	 * @param  int|string $product_id
	 * @return void
	 */
	function tier_pricing_modal_popup( $title = '', $id = '', $role_id = '', $data = '', $name = '', $product_id = '' ) {

		if ('product_variation' == get_post_type($product_id) ) {
			$variation_slug = '[' . $product_id . ']';

			if (isset($data[ $role_id ]) && ! empty($data[ $role_id ] && isset($data[ $role_id ][ $product_id ])) ) {
				@$data[ $role_id ] = $data[ $role_id ][ $product_id ];
			}

		} else {
			$variation_slug = '';
		}
		$class = '';
		$minclass = '';
		if ('wholesale_multi_user_cart_discount[tier_pricing]' == $name ) { 
			$class = 'cart-tier-popup';
			$minclass = 'cartstartqty';
		}
		?>
	<!-- Modal -->
	<div class="modal fade tier_popup <?php echo esc_attr($class); ?>" id="<?php esc_attr_e($id); ?>" tabindex="-1" aria-labelledby="<?php esc_attr_e($id); ?>Label" aria-hidden="true">
	  <div class="modal-dialog modal-lg modal-dialog-centered">
		<div class="modal-content">
		  <div class="modal-header">
			<h5 class="modal-title" id="<?php esc_attr_e($id); ?>Label"><?php esc_attr_e($title); ?></h5>
			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			  <span aria-hidden="true">&times;</span>
			</button>
		  </div>
		  <div class="modal-body">
		  <p class="wwp_required_field" style=" width: 100%;"><?php esc_html_e('Invalid Quantity or Rquierd price', 'woocommerce-wholesale-pricing'); ?></p>
			<div class="row_tire">
				<div class="tire_table_lable lable_first">
		<?php esc_html_e('Starting Quantity', 'woocommerce-wholesale-pricing'); ?> 
				</div>
		<?php if ('wholesale_multi_user_cart_discount[tier_pricing]' == $name ) { ?>
					<div class="tire_table_lable lable_secound">
			<?php esc_html_e('Test Quantity', 'woocommerce-wholesale-pricing'); ?> 
					</div> 
			<?php
		}
		?>
				<div class="tire_table_lable lable_third">
		<?php esc_html_e('Ending Quantity', 'woocommerce-wholesale-pricing'); ?> 
				</div> 
				<div class="tire_table_lable lable_forth">
		<?php esc_html_e('Wholesale Price', 'woocommerce-wholesale-pricing'); ?> 
				</div>
			</div>
			<div style="clear:both;"></div>
		<?php

		if (! empty($data[ $role_id ]) ) {
			foreach ( $data[ $role_id ] as $key => $value ) {
				?>
				<div class="form-inline append-data">
					<div class="bunch_row" data-role="<?php esc_attr_e($role_id); ?>">
						<div class="col-md-4 wrapper_my_input">
							<input type="number" value="<?php isset($value['min']) ? esc_attr_e($value['min']) : ''; ?>" name="<?php esc_attr_e($name); ?>[<?php esc_attr_e($role_id); ?>]<?php esc_attr_e($variation_slug); ?>[<?php esc_attr_e($key); ?>][min]" min="1" class="startingqty <?php esc_attr_e($minclass); ?> form-control form-control-sm" data-id="<?php esc_attr_e($role_id); ?>" placeholder="Starting Quantity">
							<span class="wwp_error_span str_qty_error" style="display:none" ><?php esc_html_e('Invalid Quantity', 'woocommerce-wholesale-pricing'); ?></span>
						</div>

				<?php if ('wholesale_multi_user_cart_discount[tier_pricing]' == $name ) { ?>
							<div class="col-md-4 wrapper_my_input">
								<input type="number" value="<?php isset($value['cart_max']) ? esc_attr_e($value['cart_max']) : ''; ?>" name="<?php esc_attr_e($name); ?>[<?php esc_attr_e($role_id); ?>]<?php esc_attr_e($variation_slug); ?>[<?php esc_attr_e($key); ?>][cart_max]" min="1" class="endingqty cartmaxqty form-control form-control-sm" placeholder="Cart Max Quantity">
								<span class="wwp_error_span cart_max_qty_error" style="display:none" ><?php esc_html_e('Invalid Quantity', 'woocommerce-wholesale-pricing'); ?></span>
							</div> 
					<?php
				}
				?>

						<div class="col-md-4 wrapper_my_input">
							<input type="number" value="<?php isset($value['max']) ? esc_attr_e($value['max']) : ''; ?>" name="<?php esc_attr_e($name); ?>[<?php esc_attr_e($role_id); ?>]<?php esc_attr_e($variation_slug); ?>[<?php esc_attr_e($key); ?>][max]"  min="1" step="<?php echo ( 'wholesale_multi_user_cart_discount[tier_pricing]' == $name ) ? 0.1 : 1; ?>" class="endingqty form-control form-control-sm" placeholder="Ending Quantity">
							<span class="wwp_error_span end_qty_error" style="display:none" ><?php esc_html_e('Invalid Quantity', 'woocommerce-wholesale-pricing'); ?></span>
						</div>

						<div class="col-md-4 wrapper_my_input">
							<input type="text" value="<?php isset($value['price']) ? esc_attr_e( wwp_format_price_for_input( $value['price'] ) ) : ''; ?>" name="<?php esc_attr_e($name); ?>[<?php esc_attr_e($role_id); ?>]<?php esc_attr_e($variation_slug); ?>[<?php esc_attr_e($key); ?>][price]" class="wwp_tire_price form-control form-control-sm" placeholder="Wholesale Price">

							<span class="wwp_error_span price_error" style="display:none" ><?php esc_html_e('Price Required', 'woocommerce-wholesale-pricing'); ?></span>
						</div>

						<div class="icons">
							<span class="dashicons dashicons-trash"></span>
							<span class="dashicons dashicons-plus-alt"  onclick="add_row_tier_price(jQuery(this),'<?php esc_attr_e($name); ?>','<?php esc_attr_e($variation_slug); ?>')"></span>
						</div>

					</div>
				</div>
				<?php
			}
		} else {

			$random = substr(md5(mt_rand()), 0, 10);
			?>
			<div class="form-inline append-data">            
				<div class="bunch_row" data-role="<?php esc_attr_e($role_id); ?>">
					<div class="col-md-4 wrapper_my_input">
						<input type="text" name="<?php esc_attr_e($name); ?>[<?php esc_attr_e($role_id); ?>]<?php esc_attr_e($variation_slug); ?>[<?php esc_attr_e($random); ?>][min]" min="1" class="form-control form-control-sm" placeholder="Starting Quantity">
						<span class="wwp_error_span str_qty_error" style="display:none" ><?php esc_html_e('Invalid quantity', 'woocommerce-wholesale-pricing'); ?></span>
					</div>
					<div class="col-md-4 wrapper_my_input">
						<input type="text" name="<?php esc_attr_e($name); ?>[<?php esc_attr_e($role_id); ?>]<?php esc_attr_e($variation_slug); ?>[<?php esc_attr_e($random); ?>][max]" min="1" class="form-control form-control-sm" placeholder="Ending Quantity">
						<span class="wwp_error_span end_qty_error" style="display:none" ><?php esc_html_e('Invalid quantity', 'woocommerce-wholesale-pricing'); ?></span>
					</div>
					<div class="col-md-4 wrapper_my_input">
						<input type="text" name="<?php esc_attr_e($name); ?>[<?php esc_attr_e($role_id); ?>]<?php esc_attr_e($variation_slug); ?>[<?php esc_attr_e($random); ?>][price]" class="wwp_tire_price form-control form-control-sm" placeholder="Wholesale Price">
						<span class="wwp_error_span price_error" style="display:none" ><?php esc_html_e('Price required', 'woocommerce-wholesale-pricing'); ?></span>
					</div>
					<div class="icons">
						<span class="dashicons dashicons-trash" ></span>
						<span class="dashicons dashicons-plus-alt" onclick="add_row_tier_price(jQuery(this),'<?php esc_attr_e($name); ?>','<?php esc_attr_e($variation_slug); ?>')"></span>
					</div>
				</div>
			</div>
			<?php
		}
		?>
		  </div>
		  <div class="modal-footer">
			<button type="button" class="btn btn-secondary" data-dismiss="modal"><?php esc_html_e('Close', 'woocommerce-wholesale-pricing'); ?></button>
			<button name="save-wwp_wholesale" class="wwp-button-primary" type="submit" value="<?php esc_html_e('Save changes', 'woocommerce-wholesale-pricing'); ?>"><?php esc_html_e('Save changes', 'woocommerce-wholesale-pricing'); ?></button>
		  </div>
		</div>
	  </div>
	</div>
	<script>
		jQuery(document).on("click","#<?php esc_attr_e($id); ?> .bunch_row span.dashicons.dashicons-trash",function() { 
			if (jQuery( "#<?php esc_attr_e($id); ?> .bunch_row" ).length > 1) {
				bunch_row = jQuery(this).parents( ".bunch_row" );
				bunch_row.slideUp("normal", function() {
					jQuery(this).remove(); 
				});
			} else {
				jQuery(this).parents( ".bunch_row" ).find("input").val("");
			}
		});
	</script>
		<?php
	}
endif;

if (! function_exists('get_current_user_role_id') ) :    
	/**
	 * Method get_current_user_role_id
	 *
	 * @return bool|int
	 */
	function get_current_user_role_id() {
		 
		/**
		* Hooks
		*
		* @since 3.0
		*/
		do_action('wwp_get_current_user_role_id');
		if (( isset($_REQUEST['oauth_consumer_key']) && isset($_REQUEST['wholesale_request']['role']) && !empty($_REQUEST['wholesale_request']['role']) ) 
			|| ( isset($_REQUEST['wholesale_request']['role']) && !empty($_REQUEST['wholesale_request']['role']) )
		) { 
			$user_role      = isset($_REQUEST['wholesale_request']['role']) ? sanitize_text_field($_REQUEST['wholesale_request']['role']) : '';
			$wholesale_role = term_exists($user_role, 'wholesale_user_roles');
			if (0 !== $wholesale_role && null !== $wholesale_role ) {
				if (is_array($wholesale_role) && isset($wholesale_role['term_id']) ) {
					return $wholesale_role['term_id'];
				}
			}
		} elseif (isset($_REQUEST['wholesale_rolebypass']) && !empty($_REQUEST['wholesale_rolebypass']) ) { 
			$wholesale_role = term_exists(wc_clean($_REQUEST['wholesale_rolebypass']), 'wholesale_user_roles');
			if (0 !== $wholesale_role && null !== $wholesale_role ) {
				if (is_array($wholesale_role) && isset($wholesale_role['term_id']) ) {
					return $wholesale_role['term_id'];
				}
			}
		}

		$order_id = isset($_REQUEST['order_id']) ? sanitize_text_field($_REQUEST['order_id']) : get_the_ID();

		if (get_option('woocommerce_custom_orders_table_enabled') && isset($_REQUEST['page'], $_REQUEST['id']) && sanitize_text_field('wc-orders') == $_REQUEST['page'] ) {
			$order_id = sanitize_text_field($_REQUEST['id']);
		}

		if (in_array(get_post_type($order_id), array( 'shop_order', 'shop_order_placehold' ))  ) {
			$order   = wc_get_order($order_id);
			if (! $order ) {
				return false;
			}
			$user_id = $order->get_user_id();
			$user    = get_userdata($user_id);
			if ($user && !empty($user->roles) ) {
				$user_role = implode(', ', $user->roles);
				return get_wholesale_role_id($user_role);
			} else {
				return false;
			}
		}
		 
		// Add to Quote compatibility
		$quote_id = isset($_REQUEST['post_id']) ? sanitize_text_field($_REQUEST['post_id']) : get_the_ID();
		if ('wc-quote' == get_post_type($quote_id) ) {
			$quote   = get_post($quote_id);
			if ( ! $quote ) {
				return false;
			}
			$user_id = $quote->post_author;
			$user    = get_userdata($user_id);
			if ($user && ! empty($user->roles) ) {
				$user_role = implode(', ', $user->roles);
				return get_wholesale_role_id($user_role);
			}

		}
		 
		if (is_user_logged_in() ) {
			$user_info      = get_userdata(get_current_user_id());
			$user_role      = implode(', ', $user_info->roles);
			$wholesale_role = term_exists($user_role, 'wholesale_user_roles');
			$is_company_member = is_company_member();

			if ( $is_company_member ) {
				return $is_company_member; // company member role id
			}
			if (0 !== $wholesale_role && null !== $wholesale_role ) {
				if (is_array($wholesale_role) && isset($wholesale_role['term_id']) ) {
					return $wholesale_role['term_id'];
				}
			}
		} else {
			$settings = WholesaleSettingsHelper::get_pricing_settings();
			if (isset( $settings['restrict_store_access'] ) && 'yes' == $settings['restrict_store_access'] && isset($_COOKIE['access_store_id']) && ! empty($_COOKIE['access_store_id']) ) {
				return sanitize_text_field($_COOKIE['access_store_id']);
			}
		}
		return false;
	}
endif;

if (! function_exists('wholesale_type_price') ) :    
	/**
	 * Method wholesale_type_price
	 *
	 * @param  int    $price
	 * @param  string $type
	 * @param  int    $amount
	 * @return int
	 */
	function wholesale_type_price( $price, $type, $amount ) {
	 
		if (empty($price) || empty($amount) ) {
			return $price;
		}
		if ('fixed' == $type ) {
			$price = $amount; 
		} else { 
			$price = $price * $amount / 100;
		}
		 
		return $price;
	}
endif;
 
if (! function_exists('tire_get_type') ) :    
	/**
	 * Method tire_get_type
	 *
	 * @param  int         $id
	 * @param  \WC_Product $product
	 * @param  int         $tire_price
	 * @param  int         $regular_price
	 * @param  string      $type
	 * @return int
	 */
	function tire_get_type( $id, $product, $tire_price, $regular_price, $type ) {

		if (empty($regular_price) || empty($tire_price) ) {
			return $regular_price;
		}
		 
		if ('fixed' == $type ) {
			$regular_price = $tire_price;
		} else {
			$regular_price = $regular_price * $tire_price / 100;
		}
		return $regular_price;
	}
endif;
 
if (! function_exists('tire_simple_wholesale_product_price_html') ) :    
	/**
	 * Method tire_simple_wholesale_product_price_html
	 *
	 * @param  int         $id
	 * @param  \WC_Product $product
	 * @param  string      $type
	 * @return bool|string HTML
	 */
	function tire_simple_wholesale_product_price_html( $id, $product, $type = '' ) {

		if (is_admin() ) {
			return false;
		}

		$role = get_current_user_role_id();
		$group_min_quantity = 0;
		$group_max_quantity = 0;

		$wholesale_product_variations = array();
		$original_variation_price     = array();
		$up_to_save                   = array();
		$settings                     = WholesaleSettingsHelper::get_pricing_settings();

		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );
		$raise_matcher_class = '\WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMatcher';
		$raise_rules = null;
		$apply_dynamic_raise = static function ( $price ) use ( $product, $raise_matcher_class, &$raise_rules ) {
			$price = (float) $price;

			if ( ! $product instanceof \WC_Product || $price <= 0 || ! class_exists( $raise_matcher_class ) ) {
				return $price;
			}

			if ( ! $raise_matcher_class::has_wholesale_discount( $price, $product ) ) {
				return $price;
			}

			if ( null === $raise_rules ) {
				$raise_rules = $raise_matcher_class::get_matching_rules( 'raise-percentage', $product );
			}

			if ( empty( $raise_rules ) ) {
				return $price;
			}

			$raised = $price;
			foreach ( $raise_rules as $rule ) {
				$increase = isset( $rule['price_increase'] ) ? absint( $rule['price_increase'] ) : 0;
				if ( $increase > 0 ) {
					$raised = $raised * ( 1 + ( $increase / 100 ) );
				}
			}

			return (float) apply_filters( 'wwp_dynamic_rule_raise_percentage_price', $raised, $price, $product, $raise_rules );
		};

		if ('product' == $type ) {
	 
			$product_tier_pricing = get_post_meta($id, 'product_tier_pricing', true);
			if (isset($product_tier_pricing[ $role ]) ) {

				$data   = get_post_meta($product->get_id(), 'wholesale_multi_user_pricing', true);
				$prices = array();
				foreach ( $product_tier_pricing[ $role ] as $key => $value ) {
					if (isset($value['price']) && ! empty($value['price']) ) {
						$wholesale_price = tire_get_type($id, $product, $value['price'], get_post_meta($id, $price_key, true), $data[ $role ]['discount_type']);
						$wholesale_product_variations[] = $apply_dynamic_raise( $wholesale_price );
						$original_variation_price[]     = get_post_meta($id, $price_key, true);
					}
				}
			} else {
				return false;

			}
		} elseif ('category' == $type ) {
			$wholesale_product_variations = array();
			$original_variation_price     = array();

			$terms = get_the_terms($id, 'product_cat');

			if (! is_wp_error($terms) && ! empty($terms) ) {
				foreach ( $terms as $term ) {
					$data           = get_term_meta($term->term_id, 'category_tier_pricing', true);
					$data_wholesale = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);

					if (isset($data['tier_pricing'][ $role ]) ) {
						if (isset($data_wholesale[ $role ]) ) {
							foreach ( $data['tier_pricing'][ $role ] as $key => $value ) {
								if (isset($value['price']) && ! empty($value['price']) ) {
											 $wholesale_price = tire_get_type($id, $product, $value['price'], get_post_meta($id, $price_key, true), $data_wholesale[ $role ]['discount_type']);
											 $wholesale_product_variations[] = $apply_dynamic_raise( $wholesale_price );
											 $original_variation_price[]     = get_post_meta($id, $price_key, true);
								}
							}
						}

					}

				}
			}
		} elseif ('global' == $type ) {

			if (isset($settings['tier_pricing']) ) {
				if (isset($settings['tier_pricing'][ $role ]) ) {
					$data_wholesale = WholesaleSettingsHelper::get_multiuser_pricing_settings();
					foreach ( $settings['tier_pricing'][ $role ] as $key => $value ) {
						if (isset($value['price']) && ! empty($value['price']) ) {
							   $wholesale_price = tire_get_type($id, $product, $value['price'], get_post_meta($id, $price_key, true), $data_wholesale[ $role ]['discount_type']);
							   $wholesale_product_variations[] = $apply_dynamic_raise( $wholesale_price );
							   $original_variation_price[]     = get_post_meta($id, $price_key, true);
						}
					}

				} else {
					return false;

				}
			}
		} elseif ('group' == $type ) {
			$ws_group = wwp_get_group_post_by_proid($id, get_current_user_id());
			if ($ws_group ) { 
				$group_id = isset($ws_group[0]) ? $ws_group[0] : '';
				if (! empty($group_id) ) {
					$discount_type = get_post_meta($group_id, '_discount_type', true);
					$group_min_quantity = absint(get_post_meta($group_id, '_min_quantity', true));
					$group_max_quantity = absint(get_post_meta($group_id, '_max_quantity', true));
					$wwp_price = get_post_meta($group_id, '_wwp_group_price', true);
					$wholesale_price = tire_get_type($id, $product, $wwp_price, get_post_meta($id, $price_key, true), $discount_type);
					$wholesale_product_variations[] = $apply_dynamic_raise( $wholesale_price );
					$original_variation_price[]     = get_post_meta($id, $price_key, true);
				}
			}
		}

		if (empty($wholesale_product_variations) ) {
			return false;
		}
		 
		sort($wholesale_product_variations);
		sort($original_variation_price);
		foreach ( $original_variation_price as $key => $value ) {
			if (empty($value) ) {
				$value = 1;
			}

			if (empty($wholesale_product_variations[$key]) ) {
				$wholesale_product_variations[$key] = 1;
			}
			$up_to_save[] = ( $value - $wholesale_product_variations[$key] ) / $value * 100;
		}
		// orignal price add tax
		$original_variation_price[0] = wwp_get_price_including_tax($product, array( 'price' => $original_variation_price[0] ));
		if ( count($original_variation_price) > 1 ) {
			$original_variation_price[ count($original_variation_price) - 1 ] = wwp_get_price_including_tax($product, array( 'price' => $original_variation_price[ count($original_variation_price) - 1 ] ));
		}
		// wholesale price add tax
		$wholesale_product_variations[0] = wwp_get_price_including_tax($product, array( 'price' => $wholesale_product_variations[0] ));
		if ( count($wholesale_product_variations) > 1 ) {
			$wholesale_product_variations[ count($wholesale_product_variations) - 1 ] = wwp_get_price_including_tax($product, array( 'price' => $wholesale_product_variations[ count($wholesale_product_variations) - 1 ] ));
		}

		$min_wholesale_price          = $wholesale_product_variations[0];
		$max_wholesale_price          = $wholesale_product_variations[ count($wholesale_product_variations) - 1 ];
		$min_original_variation_price = $original_variation_price[0];
		$max_original_variation_price = $original_variation_price[ count($original_variation_price) - 1 ];
		 
		if (empty($min_original_variation_price) ) {
			$min_original_variation_price = 1;
		}

		$min_saving_amount  = round(( $min_original_variation_price - $min_wholesale_price ));
		 
		if (empty($max_original_variation_price) ) {
			$max_original_variation_price = 1;
		}

		if (0 == $min_original_variation_price ) {
			$min_saving_percent = 0;
		} else {
			$min_saving_percent = ( $min_original_variation_price - $min_wholesale_price ) / $min_original_variation_price * 100;
		}
		 
		$max_saving_amount  = round(( $max_original_variation_price - $max_wholesale_price ));

		if (0 == $max_original_variation_price ) {
			$max_saving_percent = 0;
		} else {
			$max_saving_percent = ( $max_original_variation_price - $max_wholesale_price ) / $max_original_variation_price * 100;
		}


		//$min_quantity = get_post_meta( $prod_id, '_wwp_wholesale_min_quantity', true );
		$settings = WholesaleSettingsHelper::get_pricing_settings();
		$actual   = ( isset($settings['retailer_label']) && ! empty($settings['retailer_label']) ) ? esc_html($settings['retailer_label']) : esc_html__('Actual', 'woocommerce-wholesale-pricing');
		$save     = ( isset($settings['save_label']) && ! empty($settings['save_label']) ) ? esc_html($settings['save_label']) : esc_html__('Save Up To', 'woocommerce-wholesale-pricing');
		$new      = ( isset($settings['wholesaler_label']) && ! empty($settings['wholesaler_label']) ) ? esc_html($settings['wholesaler_label']) : esc_html__('New', 'woocommerce-wholesale-pricing');
		$html     = '<div class="wwp-wholesale-pricing-details">';

		$wcv_max_price = $max_original_variation_price;
		$wcv_min_price = $min_original_variation_price;

		// Tax display suffix function call
		$tax_display_suffix = wwp_get_tax_price_display_suffix($product->get_id());

		$retailer_label_hidden = ( isset( $settings['retailer_disabled'] ) && 'yes' === $settings['retailer_disabled'] );
		$retailer_price_hidden = ( isset( $settings['retailer_price_disabled'] ) && 'yes' === $settings['retailer_price_disabled'] );

		if ( ! $retailer_label_hidden || ! $retailer_price_hidden ) {
			$retailer_price_html = wwp_strike_through_price_element('start');
			if ( $wcv_min_price == $wcv_max_price ) {
				$retailer_price_html .= wc_price($wcv_min_price) . ' ' . $product->get_price_suffix(get_post_meta($product->get_id(), $price_key, true));
			} else {
				$retailer_price_html .= wc_price($wcv_min_price) . ' - ' . wc_price($wcv_max_price) . ' ' . $product->get_price_suffix(get_post_meta($product->get_id(), $price_key, true));
			}
			$retailer_price_html .= wwp_strike_through_price_element('end');

			$html .= '<p>';
			if ( ! $retailer_label_hidden ) {
				$html .= '<span class="retailer-text">' . esc_html__($actual, 'woocommerce-wholesale-pricing') . '</span>';
				if ( ! $retailer_price_hidden ) {
					$html .= ': ';
				}
			}
			if ( ! $retailer_price_hidden ) {
				$html .= $retailer_price_html;
			}
			$html .= '</p>';
		}

		$wholesaler_label_hidden = ( isset( $settings['wholesaler_disabled'] ) && 'yes' === $settings['wholesaler_disabled'] );
		$wholesaler_price_hidden = ( isset( $settings['wholesaler_price_disabled'] ) && 'yes' === $settings['wholesaler_price_disabled'] );
		$wholesale_price_html    = wc_price($wholesale_product_variations[0]) . ' ' . $product->get_price_suffix($wholesale_product_variations[ count($wholesale_product_variations) - 1 ]);

		if ( wc_price($wholesale_product_variations[0]) !== wc_price($wholesale_product_variations[ count($wholesale_product_variations) - 1 ]) ) {
			$wholesale_price_html = wc_price($wholesale_product_variations[0]) . ' - ' . wc_price($wholesale_product_variations[ count($wholesale_product_variations) - 1 ]) . ' ' . $product->get_price_suffix($wholesale_product_variations[ count($wholesale_product_variations) - 1 ]);
		}

		if ( ! $wholesaler_label_hidden || ! $wholesaler_price_hidden ) {
			$html .= '<p><b>';
			if ( ! $wholesaler_label_hidden ) {
				$html .= '<span class="price-text">' . esc_html__($new, 'woocommerce-wholesale-pricing') . '</span>';
				if ( ! $wholesaler_price_hidden ) {
					$html .= ': ';
				}
			}
			if ( ! $wholesaler_price_hidden ) {
				$html .= $wholesale_price_html;
			}
			$html .= '</b></p>';
		}

		$save_label_hidden = ( isset( $settings['save_price_label_disabled'] ) && 'yes' === $settings['save_price_label_disabled'] );
		$save_price_hidden = ( isset( $settings['save_price_disabled'] ) && 'yes' === $settings['save_price_disabled'] );

		if ( ! $save_label_hidden || ! $save_price_hidden ) {
			$html .= '<p><b>';
			if ( ! $save_label_hidden ) {
				$html .= '<span class="save-price-text">' . esc_html__($save, 'woocommerce-wholesale-pricing') . '</span>';
				if ( ! $save_price_hidden ) {
					$html .= ': ';
				}
			}
			if ( ! $save_price_hidden ) {
				$html .= ' (' . round(max($up_to_save)) . '%) ';
			}
			$html .= '</b></p>';
		}
		if ('group' === $type ) {
			$group_qty_text = wwp_get_group_quantity_notice_text($group_min_quantity, $group_max_quantity);
			if ('' !== $group_qty_text ) {
				$html .= apply_filters('wwp_group_quantity_text', '<p style="font-size: 10px;">' . esc_html($group_qty_text) . '</p>', $group_min_quantity, $group_max_quantity, $product, $type);
			}
		}
		$html .= '</div>';
		return $html;
	}
endif;

if (! function_exists('tire_variable_wholesale_product_price_html') ) :    
	/**
	 * Method tire_variable_wholesale_product_price_html
	 *
	 * @param  int         $id
	 * @param  \WC_Product $product
	 * @param  string      $type
	 * @return false|void|string HTML
	 */
	function tire_variable_wholesale_product_price_html( $id, $product, $type = '' ) {
		 
		if (is_admin() ) {
			return;
		}
		$role                         = get_current_user_role_id();
		$wholesale_product_variations = array();
		$original_variation_price     = array();
		$up_to_save                   = array();
		$product_variations           = $product->get_children();
		$settings                     = WholesaleSettingsHelper::get_pricing_settings();
		$group_min_quantity           = 0;
		$group_max_quantity           = 0;

		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );
		$raise_matcher_class = '\WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMatcher';
		$raise_rules_by_product = array();
		$apply_dynamic_raise = static function ( $price, $rule_product ) use ( $raise_matcher_class, &$raise_rules_by_product ) {
			$price = (float) $price;

			if ( ! $rule_product instanceof \WC_Product || $price <= 0 || ! class_exists( $raise_matcher_class ) ) {
				return $price;
			}

			if ( ! $raise_matcher_class::has_wholesale_discount( $price, $rule_product ) ) {
				return $price;
			}

			$rule_product_id = (int) $rule_product->get_id();
			if ( ! array_key_exists( $rule_product_id, $raise_rules_by_product ) ) {
				$raise_rules_by_product[ $rule_product_id ] = $raise_matcher_class::get_matching_rules( 'raise-percentage', $rule_product );
			}

			$raise_rules = $raise_rules_by_product[ $rule_product_id ];
			if ( empty( $raise_rules ) ) {
				return $price;
			}

			$raised = $price;
			foreach ( $raise_rules as $rule ) {
				$increase = isset( $rule['price_increase'] ) ? absint( $rule['price_increase'] ) : 0;
				if ( $increase > 0 ) {
					$raised = $raised * ( 1 + ( $increase / 100 ) );
				}
			}

			return (float) apply_filters( 'wwp_dynamic_rule_raise_percentage_price', $raised, $price, $rule_product, $raise_rules );
		};

		if ('product' == $type ) {
			$product_tier_pricing = get_post_meta($id, 'product_tier_pricing', true);
			if (isset($product_tier_pricing[ $role ]) ) { 
				$data_wholesale = get_post_meta($id, 'wholesale_multi_user_pricing', true);
				$prices         = array();
				foreach ( $product_tier_pricing[ $role ] as $keys => $parent ) {
					foreach ( $parent as  $key => $value ) {
						if (isset($value['price']) && ! empty($value['price']) ) {
							   $wholesale_price = tire_get_type($keys, $product, $value['price'], get_post_meta($keys, $price_key, true), $data_wholesale[ $role ]['discount_type']);
							   $wholesale_product_variations[] = $apply_dynamic_raise( $wholesale_price, wc_get_product( $keys ) );
							   $original_variation_price[]     = get_post_meta($keys, $price_key, true);
						}
					}
				}
			}
		} elseif ('category' == $type ) {

			$wholesale_product_variations = array();
			$original_variation_price     = array();

			$terms = get_the_terms($id, 'product_cat');
			if (! is_wp_error($terms) && ! empty($terms) ) {
				foreach ( $terms as $term ) {
					$data           = get_term_meta($term->term_id, 'category_tier_pricing', true);
					$data_wholesale = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
					if (isset($data_wholesale[ $role ]) ) {
						if (isset($data['tier_pricing'][ $role ]) ) {
							foreach ( $product_variations as $product_variation ) {
								foreach ( $data['tier_pricing'][ $role ] as $key => $value ) {
									if (isset($value['price']) && ! empty($value['price']) ) {
										$original_variation_price[]     = get_post_meta($product_variation, $price_key, true);
										$wholesale_price = tire_get_type($product_variation, $product, $value['price'], get_post_meta($product_variation, $price_key, true), $data_wholesale[ $role ]['discount_type']);
										$wholesale_product_variations[] = $apply_dynamic_raise( $wholesale_price, wc_get_product( $product_variation ) );
									}
								}
							}
						} else {
							return false;
						}
					}
				}
			}
		} elseif ('global' == $type ) {
			if (isset($settings['tier_pricing']) ) {

				$wholesale_product_variations = array();
				$original_variation_price     = array();
				$key                          = array();
				$value                        = array();
				if (isset($settings['tier_pricing'][ $role ]) ) {
					$data_wholesale = WholesaleSettingsHelper::get_multiuser_pricing_settings();
					foreach ( $product_variations as $product_variation ) {
						foreach ( $settings['tier_pricing'][ $role ] as $key => $value ) {
							if (isset($value['price']) && ! empty($value['price']) ) {
								$original_variation_price[]     = get_post_meta($product_variation, $price_key, true);
								$wholesale_price = tire_get_type($product_variation, $product, $value['price'], get_post_meta($product_variation, $price_key, true), $data_wholesale[ $role ]['discount_type']);
								$wholesale_product_variations[] = $apply_dynamic_raise( $wholesale_price, wc_get_product( $product_variation ) );
							}
						}
					}
				} else {
					return false;
				}
			}
		} elseif ('group' == $type ) {
			$ws_group = wwp_get_group_post_by_proid($id, get_current_user_id());
			if ($ws_group ) { 
				$group_id = isset($ws_group[0]) ? $ws_group[0] : '';
				if (! empty($group_id) ) {
					$discount_type = get_post_meta($group_id, '_discount_type', true);
					$group_min_quantity = absint(get_post_meta($group_id, '_min_quantity', true));
					$group_max_quantity = absint(get_post_meta($group_id, '_max_quantity', true));
					$wwp_price = get_post_meta($group_id, '_wwp_group_price', true);
					foreach ( $product_variations as $product_variation ) { 
						$wholesale_price = tire_get_type($product_variation, $product, $wwp_price, get_post_meta($product_variation, $price_key, true), $discount_type);
						$wholesale_product_variations[] = $apply_dynamic_raise( $wholesale_price, wc_get_product( $product_variation ) );
						$original_variation_price[]     = get_post_meta($product_variation, $price_key, true);

					}
				}
			}
		}

		if (empty($wholesale_product_variations) ) {
			return false;
		}
		foreach ( $original_variation_price as $key => $value ) { 
			if (empty($value) ) {
				$value = 1;
			}

			if (empty($wholesale_product_variations[$key]) ) {
				$wholesale_product_variations[$key] = 1;
			}
			$up_to_save[] = ( $value - $wholesale_product_variations[$key] ) / $value * 100;
		}

		sort($wholesale_product_variations);
		sort($original_variation_price);
		 
		// orignal price add tax
		$original_variation_price[0] = wwp_get_price_including_tax($product, array( 'price' => $original_variation_price[0] ));
		if ( count($original_variation_price) > 1 ) {
			$original_variation_price[ count($original_variation_price) - 1 ] = wwp_get_price_including_tax($product, array( 'price' => $original_variation_price[ count($original_variation_price) - 1 ] ));
		}
		// wholesale price add tax
		$wholesale_product_variations[0] = wwp_get_price_including_tax($product, array( 'price' => $wholesale_product_variations[0] ));
		if ( count($wholesale_product_variations) > 1 ) {
			$wholesale_product_variations[ count($wholesale_product_variations) - 1 ] = wwp_get_price_including_tax($product, array( 'price' => $wholesale_product_variations[ count($wholesale_product_variations) - 1 ] ));
		}

		$min_wholesale_price = $wholesale_product_variations[0];
		$max_wholesale_price = $wholesale_product_variations[ count($wholesale_product_variations) - 1 ];

		$min_original_variation_price = $original_variation_price[0];
		$max_original_variation_price = $original_variation_price[ count($original_variation_price) - 1 ];
		 
		if (empty($min_original_variation_price) ) {
			$min_original_variation_price = 1;
		}

		if (empty($max_original_variation_price) ) {
			$max_original_variation_price = 1;
		}

		$min_saving_amount  = round(( (float) $min_original_variation_price - (float) $min_wholesale_price ));
		$min_saving_percent = ( (float) $min_original_variation_price - (float) $min_wholesale_price ) / (float) $min_original_variation_price * 100;
		 
		$max_saving_amount  = round(( (float) $max_original_variation_price - (float) $max_wholesale_price ));
		$max_saving_percent = ( (float) $max_original_variation_price - (float) $max_wholesale_price ) / (float) $max_original_variation_price * 100;

		//$min_quantity = get_post_meta( $prod_id, '_wwp_wholesale_min_quantity', true );
		$settings = WholesaleSettingsHelper::get_pricing_settings();
		$actual   = ( isset($settings['retailer_label']) && ! empty($settings['retailer_label']) ) ? esc_html($settings['retailer_label']) : esc_html__('Actual', 'woocommerce-wholesale-pricing');
		$save     = ( isset($settings['save_label']) && ! empty($settings['save_label']) ) ? esc_html($settings['save_label']) : esc_html__('Save Up To', 'woocommerce-wholesale-pricing');
		$new      = ( isset($settings['wholesaler_label']) && ! empty($settings['wholesaler_label']) ) ? esc_html($settings['wholesaler_label']) : esc_html__('New', 'woocommerce-wholesale-pricing');
		$html     = '<div class="wwp-wholesale-pricing-details">';

		$wcv_max_price = $max_original_variation_price;
		$wcv_min_price = $min_original_variation_price;

		$retailer_label_hidden = ( isset( $settings['retailer_disabled'] ) && 'yes' === $settings['retailer_disabled'] );
		$retailer_price_hidden = ( isset( $settings['retailer_price_disabled'] ) && 'yes' === $settings['retailer_price_disabled'] );

		if ( ! $retailer_label_hidden || ! $retailer_price_hidden ) {
			$retailer_price_html = wwp_strike_through_price_element('start');
			if ( $wcv_min_price == $wcv_max_price ) {
				$retailer_price_html .= wc_price($wcv_min_price) . ' ';
			} else {
				$retailer_price_html .= wc_price($wcv_min_price) . '  - ' . wc_price($wcv_max_price) . ' ';
			}
			$retailer_price_html .= wwp_strike_through_price_element('end');

			$html .= '<p>';
			if ( ! $retailer_label_hidden ) {
				$html .= '<span class="retailer-text">' . esc_html__($actual, 'woocommerce-wholesale-pricing') . '</span>';
				if ( ! $retailer_price_hidden ) {
					$html .= ': ';
				}
			}
			if ( ! $retailer_price_hidden ) {
				$html .= $retailer_price_html;
			}
			$html .= '</p>';
		}

		$wholesaler_label_hidden = ( isset( $settings['wholesaler_disabled'] ) && 'yes' === $settings['wholesaler_disabled'] );
		$wholesaler_price_hidden = ( isset( $settings['wholesaler_price_disabled'] ) && 'yes' === $settings['wholesaler_price_disabled'] );
		$wholesale_price_html    = wc_price($wholesale_product_variations[0]) . ' ';

		if ( wc_price($wholesale_product_variations[0]) !== wc_price($wholesale_product_variations[ count($wholesale_product_variations) - 1 ]) ) {
			$wholesale_price_html = wc_price($wholesale_product_variations[0]) . ' - ' . wc_price($wholesale_product_variations[ count($wholesale_product_variations) - 1 ]) . ' ';
		}

		if ( ! $wholesaler_label_hidden || ! $wholesaler_price_hidden ) {
			$html .= '<p><b>';
			if ( ! $wholesaler_label_hidden ) {
				$html .= '<span class="price-text">' . esc_html__($new, 'woocommerce-wholesale-pricing') . '</span>';
				if ( ! $wholesaler_price_hidden ) {
					$html .= ': ';
				}
			}
			if ( ! $wholesaler_price_hidden ) {
				$html .= $wholesale_price_html;
			}
			$html .= '</b></p>';
		}

		$save_label_hidden = ( isset( $settings['save_price_label_disabled'] ) && 'yes' === $settings['save_price_label_disabled'] );
		$save_price_hidden = ( isset( $settings['save_price_disabled'] ) && 'yes' === $settings['save_price_disabled'] );

		if ( ! $save_label_hidden || ! $save_price_hidden ) {
			$html .= '<p><b>';
			if ( ! $save_label_hidden ) {
				$html .= '<span class="save-price-text">' . esc_html__($save, 'woocommerce-wholesale-pricing') . '</span>';
				if ( ! $save_price_hidden ) {
					$html .= ': ';
				}
			}
			if ( ! $save_price_hidden ) {
				$html .= ' (' . round(max($up_to_save)) . '%) ';
			}
			$html .= '</b></p>';
		}
		if ('group' === $type ) {
			$group_qty_text = wwp_get_group_quantity_notice_text($group_min_quantity, $group_max_quantity);
			if ('' !== $group_qty_text ) {
				$html .= apply_filters('wwp_group_quantity_text', '<p style="font-size: 10px;">' . esc_html($group_qty_text) . '</p>', $group_min_quantity, $group_max_quantity, $product, $type);
			}
		}
		$html .= '</div>';
		return $html;
	}
endif;

if (! function_exists('tire_simple_subsc_wholesale_product_price_html') ) :    
	/**
	 * Method tire_simple_subsc_wholesale_product_price_html
	 *
	 * @param  int         $id
	 * @param  \WC_Product $product
	 * @param  string      $type
	 * @return false|string HTML
	 */
	function tire_simple_subsc_wholesale_product_price_html( $id, $product, $type = '' ) {

		if (is_admin() ) {
			return false;
		}

		$role = get_current_user_role_id();
		$group_min_quantity = 0;
		$group_max_quantity = 0;

		$wholesale_product_variations = array();
		$original_variation_price     = array();
		$up_to_save                   = array();
		$settings                     = WholesaleSettingsHelper::get_pricing_settings();

		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );
		$raise_matcher_class = '\WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMatcher';
		$raise_rules = null;
		$apply_dynamic_raise = static function ( $price ) use ( $product, $raise_matcher_class, &$raise_rules ) {
			$price = (float) $price;

			if ( ! $product instanceof \WC_Product || $price <= 0 || ! class_exists( $raise_matcher_class ) ) {
				return $price;
			}

			if ( ! $raise_matcher_class::has_wholesale_discount( $price, $product ) ) {
				return $price;
			}

			if ( null === $raise_rules ) {
				$raise_rules = $raise_matcher_class::get_matching_rules( 'raise-percentage', $product );
			}

			if ( empty( $raise_rules ) ) {
				return $price;
			}

			$raised = $price;
			foreach ( $raise_rules as $rule ) {
				$increase = isset( $rule['price_increase'] ) ? absint( $rule['price_increase'] ) : 0;
				if ( $increase > 0 ) {
					$raised = $raised * ( 1 + ( $increase / 100 ) );
				}
			}

			return (float) apply_filters( 'wwp_dynamic_rule_raise_percentage_price', $raised, $price, $product, $raise_rules );
		};

		if ('product' == $type ) {
	 
			$product_tier_pricing = get_post_meta($id, 'product_tier_pricing', true);
			if (isset($product_tier_pricing[ $role ]) ) {

				$data   = get_post_meta($product->get_id(), 'wholesale_multi_user_pricing', true);
				$prices = array();
				foreach ( $product_tier_pricing[ $role ] as $key => $value ) {
					if (isset($value['price']) && ! empty($value['price']) ) {
						$wholesale_price = tire_get_type($id, $product, $value['price'], get_post_meta($id, $price_key, true), $data[ $role ]['discount_type']);
						$wholesale_product_variations[] = $apply_dynamic_raise( $wholesale_price );
						$original_variation_price[]     = get_post_meta($id, $price_key, true);
					}
				}
			} else {
				return false;

			}
		} elseif ('category' == $type ) {
			$wholesale_product_variations = array();
			$original_variation_price     = array();

			$terms = get_the_terms($id, 'product_cat');

			if (! is_wp_error($terms) && ! empty($terms) ) {
				foreach ( $terms as $term ) {
					$data           = get_term_meta($term->term_id, 'category_tier_pricing', true);
					$data_wholesale = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);

					if (isset($data['tier_pricing'][ $role ]) ) {
						if (isset($data_wholesale[ $role ]) ) {
							foreach ( $data['tier_pricing'][ $role ] as $key => $value ) {
								if (isset($value['price']) && ! empty($value['price']) ) {
											 $wholesale_price = tire_get_type($id, $product, $value['price'], get_post_meta($id, $price_key, true), $data_wholesale[ $role ]['discount_type']);
											 $wholesale_product_variations[] = $apply_dynamic_raise( $wholesale_price );
											 $original_variation_price[]     = get_post_meta($id, $price_key, true);
								}
							}
						}

					}

				}
			}
		} elseif ('global' == $type ) {

			if (isset($settings['tier_pricing']) ) {
				if (isset($settings['tier_pricing'][ $role ]) ) {
					$data_wholesale = WholesaleSettingsHelper::get_multiuser_pricing_settings();
					foreach ( $settings['tier_pricing'][ $role ] as $key => $value ) {
						if (isset($value['price']) && ! empty($value['price']) ) {
							   $wholesale_price = tire_get_type($id, $product, $value['price'], get_post_meta($id, $price_key, true), $data_wholesale[ $role ]['discount_type']);
							   $wholesale_product_variations[] = $apply_dynamic_raise( $wholesale_price );
							   $original_variation_price[]     = get_post_meta($id, $price_key, true);
						}
					}

				} else {
					return false;

				}
			}
		} elseif ('group' == $type ) {
			$ws_group = wwp_get_group_post_by_proid($id, get_current_user_id());
			if ($ws_group ) { 
				$group_id = isset($ws_group[0]) ? $ws_group[0] : '';
				if (! empty($group_id) ) {
					$discount_type = get_post_meta($group_id, '_discount_type', true);
					$group_min_quantity = absint(get_post_meta($group_id, '_min_quantity', true));
					$group_max_quantity = absint(get_post_meta($group_id, '_max_quantity', true));
					$wwp_price = get_post_meta($group_id, '_wwp_group_price', true);
					$wholesale_price = tire_get_type($id, $product, $wwp_price, get_post_meta($id, $price_key, true), $discount_type);
					$wholesale_product_variations[] = $apply_dynamic_raise( $wholesale_price );
					$original_variation_price[]     = get_post_meta($id, $price_key, true);
				}
			}
		}

		if (empty($wholesale_product_variations) ) {
			return false;
		}
		 
		sort($wholesale_product_variations);
		sort($original_variation_price);
		foreach ( $original_variation_price as $key => $value ) {
			if (empty($value) ) {
				$value = 1;
			}

			if (empty($wholesale_product_variations[$key]) ) {
				$wholesale_product_variations[$key] = 1;
			}
			$up_to_save[] = ( $value - $wholesale_product_variations[$key] ) / $value * 100;
		}
		// orignal price add tax
		$original_variation_price[0] = wwp_get_price_including_tax($product, array( 'price' => $original_variation_price[0] ));
		if ( count($original_variation_price) > 1 ) {
			$original_variation_price[ count($original_variation_price) - 1 ] = wwp_get_price_including_tax($product, array( 'price' => $original_variation_price[ count($original_variation_price) - 1 ] ));
		}
		// wholesale price add tax
		$wholesale_product_variations[0] = wwp_get_price_including_tax($product, array( 'price' => $wholesale_product_variations[0] ));
		if ( count($wholesale_product_variations) > 1 ) {
			$wholesale_product_variations[ count($wholesale_product_variations) - 1 ] = wwp_get_price_including_tax($product, array( 'price' => $wholesale_product_variations[ count($wholesale_product_variations) - 1 ] ));
		}

		$min_wholesale_price          = $wholesale_product_variations[0];
		$max_wholesale_price          = $wholesale_product_variations[ count($wholesale_product_variations) - 1 ];
		$min_original_variation_price = $original_variation_price[0];
		$max_original_variation_price = $original_variation_price[ count($original_variation_price) - 1 ];
		 
		if (empty($min_original_variation_price) ) {
			$min_original_variation_price = 1;
		}

		$min_saving_amount  = round(( $min_original_variation_price - $min_wholesale_price ));
		 
		if (empty($max_original_variation_price) ) {
			$max_original_variation_price = 1;
		}

		if (0 == $min_original_variation_price ) {
			$min_saving_percent = 0;
		} else {
			$min_saving_percent = ( $min_original_variation_price - $min_wholesale_price ) / $min_original_variation_price * 100;
		}
		 
		$max_saving_amount  = round(( $max_original_variation_price - $max_wholesale_price ));

		if (0 == $max_original_variation_price ) {
			$max_saving_percent = 0;
		} else {
			$max_saving_percent = ( $max_original_variation_price - $max_wholesale_price ) / $max_original_variation_price * 100;
		}


		//$min_quantity = get_post_meta( $prod_id, '_wwp_wholesale_min_quantity', true );
		$settings = WholesaleSettingsHelper::get_pricing_settings();
		$actual   = ( isset($settings['retailer_label']) && ! empty($settings['retailer_label']) ) ? esc_html($settings['retailer_label']) : esc_html__('Actual', 'woocommerce-wholesale-pricing');
		$save     = ( isset($settings['save_label']) && ! empty($settings['save_label']) ) ? esc_html($settings['save_label']) : esc_html__('Save Up To', 'woocommerce-wholesale-pricing');
		$new      = ( isset($settings['wholesaler_label']) && ! empty($settings['wholesaler_label']) ) ? esc_html($settings['wholesaler_label']) : esc_html__('New', 'woocommerce-wholesale-pricing');
		$html     = '<div class="wwp-wholesale-pricing-details">';

		$wcv_max_price = $max_original_variation_price;
		$wcv_min_price = $min_original_variation_price;
		$charge_price =$product->get_meta('_subscription_period_interval');
		if (1 == $charge_price ) {
			$charge_price = '/';
		}
		$period = $product->get_meta('_subscription_period');
		$cancel = $product->get_meta('_subscription_length');
		$sign_up_fee = $product->get_meta('_subscription_sign_up_fee');
		$sign_up_fee_text = '';
		if (! empty($sign_up_fee) ) {
			$sign_up_fee_text = ' and a ' . get_woocommerce_currency_symbol() . ' ' . $sign_up_fee . ' sign-up fee';
		} 
		$cancelation = '';
		if (! empty($cancel) ) {
			$cancelation = ' for ' . $cancel . ' ' . $period;
		}
		// Tax display suffix function call
		$tax_display_suffix = wwp_get_tax_price_display_suffix($product->get_id());

		$retailer_label_hidden = ( isset( $settings['retailer_disabled'] ) && 'yes' === $settings['retailer_disabled'] );
		$retailer_price_hidden = ( isset( $settings['retailer_price_disabled'] ) && 'yes' === $settings['retailer_price_disabled'] );

		if ( ! $retailer_label_hidden || ! $retailer_price_hidden ) {
			$retailer_price_html = wwp_strike_through_price_element('start');
			if ( $wcv_min_price == $wcv_max_price ) {
				$retailer_price_html .= wc_price($wcv_min_price) . ' ' . $product->get_price_suffix(get_post_meta($product->get_id(), $price_key, true));
			} else {
				$retailer_price_html .= wc_price($wcv_min_price) . ' - ' . wc_price($wcv_max_price) . ' ' . $product->get_price_suffix(get_post_meta($product->get_id(), $price_key, true));
			}
			$retailer_price_html .= wwp_strike_through_price_element('end');

			$html .= '<p>';
			if ( ! $retailer_label_hidden ) {
				$html .= '<span class="retailer-text">' . esc_html__($actual, 'woocommerce-wholesale-pricing') . '</span>';
				if ( ! $retailer_price_hidden ) {
					$html .= ': ';
				}
			}
			if ( ! $retailer_price_hidden ) {
				$html .= $retailer_price_html;
			}
			$html .= '</p>';
		}

		$wholesaler_label_hidden = ( isset( $settings['wholesaler_disabled'] ) && 'yes' === $settings['wholesaler_disabled'] );
		$wholesaler_price_hidden = ( isset( $settings['wholesaler_price_disabled'] ) && 'yes' === $settings['wholesaler_price_disabled'] );
		$wholesale_price_html    = wc_price($wholesale_product_variations[0]) . ' ' . $product->get_price_suffix($wholesale_product_variations[ count($wholesale_product_variations) - 1 ]);

		if ( wc_price($wholesale_product_variations[0]) !== wc_price($wholesale_product_variations[ count($wholesale_product_variations) - 1 ]) ) {
			$wholesale_price_html = wc_price($wholesale_product_variations[0]) . ' - ' . wc_price($wholesale_product_variations[ count($wholesale_product_variations) - 1 ]) . ' ' . $product->get_price_suffix($wholesale_product_variations[ count($wholesale_product_variations) - 1 ]) . $charge_price . ' ' . $period . $cancelation . $sign_up_fee_text;
		}

		if ( ! $wholesaler_label_hidden || ! $wholesaler_price_hidden ) {
			$html .= '<p><b>';
			if ( ! $wholesaler_label_hidden ) {
				$html .= '<span class="price-text">' . esc_html__($new, 'woocommerce-wholesale-pricing') . '</span>';
				if ( ! $wholesaler_price_hidden ) {
					$html .= ': ';
				}
			}
			if ( ! $wholesaler_price_hidden ) {
				$html .= $wholesale_price_html;
			}
			$html .= '</b></p>';
		}

		$save_label_hidden = ( isset( $settings['save_price_label_disabled'] ) && 'yes' === $settings['save_price_label_disabled'] );
		$save_price_hidden = ( isset( $settings['save_price_disabled'] ) && 'yes' === $settings['save_price_disabled'] );

		if ( ! $save_label_hidden || ! $save_price_hidden ) {
			$html .= '<p><b>';
			if ( ! $save_label_hidden ) {
				$html .= '<span class="save-price-text">' . esc_html__($save, 'woocommerce-wholesale-pricing') . '</span>';
				if ( ! $save_price_hidden ) {
					$html .= ': ';
				}
			}
			if ( ! $save_price_hidden ) {
				$html .= ' (' . round(max($up_to_save)) . '%) ';
			}
			$html .= '</b></p>';
		}
		if ('group' === $type ) {
			$group_qty_text = wwp_get_group_quantity_notice_text($group_min_quantity, $group_max_quantity);
			if ('' !== $group_qty_text ) {
				$html .= apply_filters('wwp_group_quantity_text', '<p style="font-size: 10px;">' . esc_html($group_qty_text) . '</p>', $group_min_quantity, $group_max_quantity, $product, $type);
			}
		}
		$html .= '</div>';
		return $html;
	}
endif;

if (! function_exists('wwp_get_group_quantity_notice_text') ) :
	/**
	 * Build a quantity rule notice for group discounts.
	 *
	 * @param int $min_quantity Minimum quantity.
	 * @param int $max_quantity Maximum quantity.
	 * @return string
	 */
	function wwp_get_group_quantity_notice_text( $min_quantity, $max_quantity ) {
		$min_quantity = absint($min_quantity);
		$max_quantity = absint($max_quantity);

		if ($min_quantity > 0 && $max_quantity > 0 ) {
			return sprintf(
				/* translators: 1: minimum quantity, 2: maximum quantity */
				esc_html__('Wholesale price will only be applied to quantities between %1$s and %2$s products', 'woocommerce-wholesale-pricing'),
				$min_quantity,
				$max_quantity
			);
		}

		if ($min_quantity > 0 ) {
			return sprintf(
				/* translators: %s: minimum quantity */
				esc_html__('Wholesale price will only be applied to a minimum quantity of %1$s products', 'woocommerce-wholesale-pricing'),
				$min_quantity
			);
		}

		if ($max_quantity > 0 ) {
			return sprintf(
				/* translators: %s: maximum quantity */
				esc_html__('Wholesale price will only be applied up to a maximum quantity of %1$s products', 'woocommerce-wholesale-pricing'),
				$max_quantity
			);
		}

		return '';
	}
endif;
	 
if (! function_exists('wholesale_tire_prices') ) :    
	/**
	 * Method wholesale_tire_prices
	 *
	 * @param  \WC_Product $product
	 * @return array
	 */
	function wholesale_tire_prices( $product ) {
	 
		$role                 = get_current_user_role_id();
		if ( ! empty( $role ) && is_product_category_excluded_global( $product->get_id() ) ) {
			return false;
		}
		 
		$ws_group = wwp_get_group_post_by_proid($product->get_id(), get_current_user_id());
		if ($ws_group ) { 
			$group_id = isset($ws_group[0]) ? $ws_group[0] : '';
			if (! empty($group_id) ) {
				$discount_type = get_post_meta($group_id, '_discount_type', true);
				$min_quantity = get_post_meta($group_id, '_min_quantity', true);
				$max_quantity = get_post_meta($group_id, '_max_quantity', true);
				$wwp_price = get_post_meta($group_id, '_wwp_group_price', true);
				$group = array();
				if (! empty($wwp_price) ) {
					$group[$role] = array( array( 'min' => $min_quantity, 'max' => $max_quantity, 'price' => $wwp_price ), 'discount_type' => $discount_type, 'run' => 'group' );
					return $group;
				}
			}
		}

		$product_tier_pricing = get_post_meta($product->get_id(), 'product_tier_pricing', true);
		 
		if (isset($product_tier_pricing[ $role ]) ) {
			if ($product->get_type() == 'variable' ) {
				$data_wholesale = get_post_meta($product->get_id(), 'wholesale_multi_user_pricing', true);
				if (isset($data_wholesale[ $role ]) ) {
					foreach ( $product_tier_pricing[ $role ] as $product_data ) {
						foreach ( $product_data as $variable_product_data ) {
							if (isset($variable_product_data['price']) && ! empty($variable_product_data['price']) ) {
								$product_tier_pricing[ $role ]['discount_type'] = $data_wholesale[ $role ]['discount_type'];
								$product_tier_pricing[ $role ]['run']           = 'product';
								return $product_tier_pricing;
							}
						}
					}               
				} 
			}

			if ($product->get_type() == 'simple' ) {
				$data_wholesale = get_post_meta($product->get_id(), 'wholesale_multi_user_pricing', true);
				if (isset($data_wholesale[ $role ]) ) {
					foreach ( $product_tier_pricing[ $role ] as $product_data ) {
						if (isset($product_data['price']) && ! empty($product_data['price']) ) {
							$product_tier_pricing[ $role ]['discount_type'] = $data_wholesale[ $role ]['discount_type'];
							$product_tier_pricing[ $role ]['run']           = 'product';
							return $product_tier_pricing;
						}
					}
				}
			}

			if ($product->get_type() == 'subscription' ) {
				$data_wholesale = get_post_meta($product->get_id(), 'wholesale_multi_user_pricing', true);
				if (isset($data_wholesale[ $role ]) ) {
					foreach ( $product_tier_pricing[ $role ] as $product_data ) {
						if (isset($product_data['price']) && ! empty($product_data['price']) ) {
							$product_tier_pricing[ $role ]['discount_type'] = $data_wholesale[ $role ]['discount_type'];
							$product_tier_pricing[ $role ]['run']           = 'product-subscription';
							return $product_tier_pricing;
						}
					}
				}
			}
		}

		$terms = get_the_terms($product->get_id(), 'product_cat');

		if (! is_wp_error($terms) && ! empty($terms) ) {
			foreach ( $terms as $term ) {
				$product_tier_pricing = get_term_meta($term->term_id, 'category_tier_pricing', true);
				if (isset($product_tier_pricing['tier_pricing'][ $role ]) ) {
					$data_wholesale = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
					if (isset($data_wholesale[ $role ]) ) {
						foreach ( $product_tier_pricing['tier_pricing'][ $role ] as $key => $value ) {
							if (isset($value['price']) && ! empty($value['price']) ) {
								$product_tier_pricing['tier_pricing'][ $role ]['discount_type'] = $data_wholesale[ $role ]['discount_type'];
								$product_tier_pricing['tier_pricing'][ $role ]['run']           = 'category';
								return $product_tier_pricing['tier_pricing'];
							}
						}
					}   
				}
			}
		}

		$settings = WholesaleSettingsHelper::get_pricing_settings();
		if (isset($settings['tier_pricing']) ) {
			if (isset($settings['tier_pricing'][ $role ]) ) {
				$data_wholesale = WholesaleSettingsHelper::get_multiuser_pricing_settings();
				if (isset($data_wholesale[ $role ]) ) {
					foreach ( $settings['tier_pricing'][ $role ] as $key => $value ) {
						if (isset($value['price']) && ! empty($value['price']) ) {
							   $settings['tier_pricing'][ $role ]['discount_type'] = $data_wholesale[ $role ]['discount_type'];
							   $settings['tier_pricing'][ $role ]['run']           = 'global';
							   return $settings['tier_pricing'];
	 
						}
					}
				}
			}
		}
		return false;
	}
endif;

if (! function_exists('get_cart_qty') ) :    
	/**
	 * Method get_cart_qty
	 *
	 * @param  int $product_id
	 * @return int
	 */
	function get_cart_qty( $product_id ) {

		if (! current_user_can('edit_post', $product_id) && ( is_cart() || is_checkout() || ( defined('REST_REQUEST') && REST_REQUEST ) ) ) {
		 
			if (isset(WC()->cart) ) {
				foreach ( WC()->cart->get_cart() as $cart_item ) {
					if ($cart_item['product_id'] == $product_id ) {
						return $cart_item['quantity'];
					}
				}
			}
		}
		 
		$data = $_REQUEST;
		if (isset($data['data']) && is_admin() ) {
			foreach ($data['data'] as $key => $value ) {
				if (isset($value['id']) && $value['id'] == $product_id ) {
					return $value['qty'];
				}
			}
		}
		/**
		* Hooks
		*
		* @since 3.0
		*/
		return apply_filters('wwp_cart_quantity', 1, $product_id);
	}
endif;

if (! function_exists('get_cart_variation_qty') ) :    
	/**
	 * Method get_cart_variation_qty
	 *
	 * @param  int $current_variation_id
	 * @return int|void
	 */
	function get_cart_variation_qty( $current_variation_id ) {
		if (( defined('REST_REQUEST') && REST_REQUEST ) || is_cart() || is_checkout() ) {
			if (isset(WC()->cart) ) {
				foreach ( WC()->cart->get_cart() as $cart_item ) {
					if ($cart_item['variation_id'] == $current_variation_id ) {
						return $cart_item['quantity'];
					}
				}
			}
		}
	}
endif;


if (! function_exists('tire_wholesale_qty_price') ) :    
	/**
	 * Method tire_wholesale_qty_price
	 *
	 * @param  array       $data
	 * @param  \WC_Product $product
	 * @return false|int
	 */
	function tire_wholesale_qty_price( $data, $product ) {
		$tire_variation_price = array();
		if (! empty($data) ) {

			if (is_array($data) ) {
				foreach ( $data as $keys => $value ) {
					if (isset($value['price']) && ! empty($value['price']) ) {
						$tire_variation_price[] = $value['price'];
					}
				}
			} else {
				$tire_variation_price[] = $data;
			}
		} 

		if ($tire_variation_price ) {
			return min($tire_variation_price);
		} else {
			return false;
		}
	}
endif;
 
if (! function_exists('tire_wholesale_qty_price_simple') ) :    
	/**
	 * Method tire_wholesale_qty_price_simple
	 *
	 * @param  array       $data
	 * @param  \WC_Product $product
	 * @return false|int
	 */
	function tire_wholesale_qty_price_simple( $data, $product ) {
		 
		$tire_variation_price = array();
		if ($data ) {
			foreach ( $data as $keys => $value ) {
				if (isset($value['price']) && ! empty($value['price']) ) {
					$tire_variation_price[] = $value['price'];
				}
			}
		}
		 
		if (isset($data[ $product->get_id() ]) ) {
			foreach ( $data[ $product->get_id() ] as $keys => $value ) {
				if (isset($value['price']) && ! empty($value['price']) ) {
					$tire_variation_price[] = $value['price'];
				}
			}
		}
		 
		if ($tire_variation_price ) {
			return min($tire_variation_price);
		} else {
			return false;
		}
	}
endif;

if (! function_exists('tire_variable_wholesale_product_price') ) :    
	/**
	 * Tire_variable_wholesale_product_price
	 *
	 * @param  mixed $current_variation_id
	 * @param  mixed $product
	 * @param  mixed $type
	 * @return void
	 */
	function tire_variable_wholesale_product_price( $current_variation_id, $product, $type = '' ) {
		 
		/**
		* Hooks
		*
		* @since 3.0
		*/
		if (apply_filters('wwp_is_admin_product_price', is_admin()) ) {
			return;
		}
		$role                         = get_current_user_role_id();
		$product_variations           = $product->get_children();
		$product_id                   = $product->get_id();
		$main_product_id              = wp_get_post_parent_id($product_id);
		$wholesale_product_variations = array();
		$original_variation_price     = array();
		$prices                       = array();
		$qty                          = 1;
		/**
		* Hooks
		*
		* @since 3.0
		*/
		$is_cart_or_checkout_page =   apply_filters('wwp_is_cart_or_checkout_page', ( ( defined('REST_REQUEST') && REST_REQUEST ) || is_cart() || is_checkout() ) ? true : false);   
		$variation_id             = $product_id;

		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

		if ('product' == $type ) {
			if ('product' == get_post_type($product_id) ) {
				$qty                  = get_cart_qty($product_id);
				$product_tier_pricing = get_post_meta($product_id, 'product_tier_pricing', true);
				if (isset($product_tier_pricing[ $role ]) ) {
					$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
					if (isset($data[ $role ]) ) {
						foreach ( $product_tier_pricing[ $role ] as $product_data ) { 
							if (isset($product_data['price']) && ! empty($product_data['price']) ) { 
								if ($is_cart_or_checkout_page ) { 
									if ($qty >= $product_data['min'] && $qty <= $product_data['max'] ) {
										return tire_get_type($product_id, $product, $product_data['price'], get_post_meta($product_id, $price_key, true), $data[ $role ]['discount_type']);
									}
								} else { 
									return tire_get_type($product_id, $product, tire_wholesale_qty_price_simple($product_tier_pricing[ $role ], $product), get_post_meta($product_id, $price_key, true), $data[ $role ]['discount_type']);
								}
							}
						}
					}
				}
			} elseif ('product_variation' == get_post_type($product_id) ) {

				$variation_id         = $product_id;
				$product_id           = wp_get_post_parent_id($product_id);
				$qty                  = get_cart_variation_qty($variation_id);
				$product_tier_pricing = get_post_meta($product_id, 'product_tier_pricing', true);
				$data                 = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
				if (isset($product_tier_pricing[ $role ][ $variation_id ]) ) {
					if (isset($data[ $role ]) ) { 
						foreach ( $product_tier_pricing[ $role ][ $variation_id ] as $keys => $value ) {
							if (isset($value['price']) && ! empty($value['price']) ) { 
								if ($is_cart_or_checkout_page ) {
									if ($qty >= $value['min'] && $qty <= $value['max'] ) {
										   return tire_get_type($variation_id, $product, $value['price'], get_post_meta($variation_id, $price_key, true), $data[ $role ]['discount_type']);
									}
								} else { 
									return tire_get_type($variation_id, $product, tire_wholesale_qty_price($product_tier_pricing[ $role ][ $variation_id ], $product), get_post_meta($variation_id, $price_key, true), $data[ $role ]['discount_type']);
								}
							}
						}
					}
				}
			}
		} elseif ('category' == $type ) {

			if ('product_variation' == get_post_type($product_id) ) {  
				$variation_id = $product_id;
				$product_id   = wp_get_post_parent_id($product_id);
				$qty = get_cart_variation_qty($variation_id);

			} else {
				$qty = get_cart_qty($product_id);
			}

			$terms = get_the_terms($product_id, 'product_cat');

			if (! is_wp_error($terms) && ! empty($terms) ) {

				foreach ( $terms as $term ) { 
					$product_tier_pricing = get_term_meta($term->term_id, 'category_tier_pricing', true);
					$data_wholesale       = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
					if (isset($product_tier_pricing['tier_pricing'][ $role ]) ) {
						if (isset($data_wholesale[ $role ]) ) {
							foreach ( $product_tier_pricing['tier_pricing'][ $role ] as $key => $value ) {
								if (isset($value['price']) && ! empty($value['price']) ) {
									if ($is_cart_or_checkout_page ) {
										if ($qty >= $value['min'] && $qty <= $value['max'] ) { 
											return tire_get_type($variation_id, $product, $value['price'], get_post_meta($variation_id, $price_key, true), $data_wholesale[ $role ]['discount_type']);
										}
									} else { 
										return tire_get_type($variation_id, $product, tire_wholesale_qty_price_simple($product_tier_pricing['tier_pricing'][ $role ], $product), get_post_meta($variation_id, $price_key, true), $data_wholesale[ $role ]['discount_type']);
									}
								}
							}
						}
					}
				}
			}
		} elseif ('global' == $type ) {
		 
			if ('product_variation' == get_post_type($product_id) ) {  
				$variation_id = $product_id;
				$product_id   = wp_get_post_parent_id($product_id);
			}
			$settings = WholesaleSettingsHelper::get_pricing_settings();
			if (isset($settings['tier_pricing']) ) {
				if (isset($settings['tier_pricing'][ $role ]) ) {
					$qty            = get_cart_qty($current_variation_id);
					$data_wholesale = WholesaleSettingsHelper::get_multiuser_pricing_settings();
					if (isset($data_wholesale[ $role ]) ) {
						foreach ( $settings['tier_pricing'][ $role ] as $key => $value ) {
							if (isset($value['price']) && ! empty($value['price']) ) {
								if ($is_cart_or_checkout_page ) {  
	 
									if ($qty >= $value['min'] && $qty <= $value['max'] ) {      
										   return tire_get_type($variation_id, $product, $value['price'], get_post_meta($variation_id, $price_key, true), $data_wholesale[ $role ]['discount_type']);
									}
								} else { 
									return tire_get_type($variation_id, $product, tire_wholesale_qty_price($settings['tier_pricing'][ $role ], $product), get_post_meta($variation_id, $price_key, true), $data_wholesale[ $role ]['discount_type']);
								}
							}
						}
					}
				}
			}
		} elseif ('group' == $type ) {
			$ws_group = wwp_get_group_post_by_proid($product_id, get_current_user_id());
			if ($ws_group ) { 
				$group_id = isset($ws_group[0]) ? $ws_group[0] : '';
				if (! empty($group_id) ) {
					$qty            = get_cart_qty($current_variation_id);
					$discount_type = get_post_meta($group_id, '_discount_type', true);
					$min_quantity = get_post_meta($group_id, '_min_quantity', true);
					$max_quantity = get_post_meta($group_id, '_max_quantity', true);
					$wwp_price = get_post_meta($group_id, '_wwp_group_price', true);

					if (! empty($wwp_price) ) {
						if ($is_cart_or_checkout_page ) { 
							if ($qty >= $min_quantity && $qty <= $max_quantity ) {
								return tire_get_type($product_id, $product, $wwp_price, get_post_meta($product_id, $price_key, true), $discount_type);
							}
						} else {
							return tire_get_type($variation_id, $product, tire_wholesale_qty_price($wwp_price, $product), get_post_meta($variation_id, $price_key, true), $discount_type);
						}
					}
				}
			}

		}
	}
endif;

if (! function_exists('variable_wholesale_product_price_html') ) :    
	/**
	 * Method variable_wholesale_product_price_html
	 *
	 * @param  array       $wholesale_product_variations
	 * @param  array       $original_variation_price
	 * @param  \WC_Product $product
	 * @return string HTML
	 */
	function variable_wholesale_product_price_html( $wholesale_product_variations, $original_variation_price, $product ) {

		sort($wholesale_product_variations);
		sort($original_variation_price);

		if (class_exists('Wpexperts\CurrencySwitcherForWoocommerce\WCCS') ) {
			global $WCCS;
			if (is_array($wholesale_product_variations) && count($wholesale_product_variations) > 0 ) {
				foreach ( $wholesale_product_variations as $key => $price ) {
					$wholesale_product_variations[$key] = $WCCS->wccs_price_conveter((float) $price);
				}
			}

			if (is_array($original_variation_price) && count($original_variation_price) > 0 ) {
				foreach ( $original_variation_price as $key => $price ) {
					$original_variation_price[$key] = $WCCS->wccs_price_conveter((float) $price);
				}
			}

		}

		/**
		 * Filter
		 * 
		 *  @since 2.5
		 */
		$check_page = apply_filters('wwp_check_page_for_inclusive_tax', false);

		$order_id = isset($_REQUEST['order_id']) ? sanitize_text_field($_REQUEST['order_id']) : get_the_ID();
		 
		// orignal price add tax
		if (( ( $check_page || is_shop() || is_product() || is_product_category() || ( 'shop_order' != get_post_type($order_id) && shortcode_exists('wc_products_table') ) ) && 'incl' === get_option('woocommerce_tax_display_shop') ) || ( ( is_cart() || is_checkout() ) && 'incl' === get_option('woocommerce_tax_display_cart') ) ) {
			$original_variation_price[0] = wwp_get_price_including_tax($product, array( 'price' => $original_variation_price[0] ));
			if ( count($original_variation_price) > 1 ) {
				$original_variation_price[ count($original_variation_price) - 1 ] = wwp_get_price_including_tax($product, array( 'price' => $original_variation_price[ count($original_variation_price) - 1 ] ));
			}
			// wholesale price add tax
			$wholesale_product_variations[0] = wwp_get_price_including_tax($product, array( 'price' => $wholesale_product_variations[0] ));
			if ( count($wholesale_product_variations) > 1 ) {
				$wholesale_product_variations[ count($wholesale_product_variations) - 1 ] = wwp_get_price_including_tax($product, array( 'price' => $wholesale_product_variations[ count($wholesale_product_variations) - 1 ] ));
			}
		} else {
			$original_variation_price[0] = wc_get_price_excluding_tax($product, array( 'price' => $original_variation_price[0] ));
			if ( count($original_variation_price) > 1 ) {
				$original_variation_price[ count($original_variation_price) - 1 ] = wc_get_price_excluding_tax($product, array( 'price' => $original_variation_price[ count($original_variation_price) - 1 ] ));
			}
			// wholesale price add tax
			$wholesale_product_variations[0] = wc_get_price_excluding_tax($product, array( 'price' => $wholesale_product_variations[0] ));
			if ( count($wholesale_product_variations) > 1 ) {
				$wholesale_product_variations[ count($wholesale_product_variations) - 1 ] = wc_get_price_excluding_tax($product, array( 'price' => $wholesale_product_variations[ count($wholesale_product_variations) - 1 ] ));
			}
		}
		// $original_variation_price[0]                                        = wwp_get_price_including_tax( $product, array( 'price' => $original_variation_price[0] ) );
		// $original_variation_price[ count( $original_variation_price ) - 1 ] = wwp_get_price_including_tax( $product, array( 'price' => $original_variation_price[ count( $original_variation_price ) - 1 ] ) );
		// // wholesale price add tax
		// $wholesale_product_variations[0] = wwp_get_price_including_tax( $product, array( 'price' => $wholesale_product_variations[0] ) );

		// $wholesale_product_variations[ count( $wholesale_product_variations ) - 1 ] = wwp_get_price_including_tax( $product, array( 'price' => $wholesale_product_variations[ count( $wholesale_product_variations ) - 1 ] ) );


		$min_wholesale_price          = $wholesale_product_variations[0];
		$max_wholesale_price          = $wholesale_product_variations[ count($wholesale_product_variations) - 1 ];
		$min_original_variation_price = ( empty($original_variation_price[0]) || 0 == $original_variation_price[0] ) ? 1 : $original_variation_price[0];
		$max_original_variation_price = $original_variation_price[ count($original_variation_price) - 1 ];
		$max_original_variation_price = ( empty($max_original_variation_price) || 0 == $max_original_variation_price ) ? 1 : $max_original_variation_price;
		 
		if (0 == $min_original_variation_price ) {
			$min_original_variation_price = 1;
		}

		if (0 == $max_original_variation_price ) {
			$max_original_variation_price = 1;
		}
		 
		 
		$min_saving_amount  = round(( $min_original_variation_price - $min_wholesale_price ));
		$min_saving_percent = ( $min_original_variation_price - $min_wholesale_price ) / $min_original_variation_price * 100;

		$max_saving_amount  = round(( $max_original_variation_price - $max_wholesale_price ));
		$max_saving_percent = ( $max_original_variation_price - $max_wholesale_price ) / $max_original_variation_price * 100;

		$min_max_sort = array( $min_saving_percent, $max_saving_percent );
		$min_saving_percent = min($min_max_sort);
		$max_saving_percent = max($min_max_sort);

		$settings = WholesaleSettingsHelper::get_pricing_settings();
		$actual   = ( isset($settings['retailer_label']) && ! empty($settings['retailer_label']) ) ? esc_html($settings['retailer_label']) : esc_html__('Actual', 'woocommerce-wholesale-pricing');
		$save     = ( isset($settings['save_label']) && ! empty($settings['save_label']) ) ? esc_html($settings['save_label']) : esc_html__('Save', 'woocommerce-wholesale-pricing');
		$new      = ( isset($settings['wholesaler_label']) && ! empty($settings['wholesaler_label']) ) ? esc_html($settings['wholesaler_label']) : esc_html__('New', 'woocommerce-wholesale-pricing');
		$html     = '';
		 
		/**
		* Hooks
		*
		* @since 3.0
		*/
		$html .= do_action('wwp_before_pricing', $product);
		$html  = '<div class="wwp-wholesale-pricing-details">';

		$wcv_max_price = $max_original_variation_price;
		$wcv_min_price = $min_original_variation_price;

		$retailer_label_hidden = ( isset( $settings['retailer_disabled'] ) && 'yes' === $settings['retailer_disabled'] );
		$retailer_price_hidden = ( isset( $settings['retailer_price_disabled'] ) && 'yes' === $settings['retailer_price_disabled'] );

		if ( ! $retailer_label_hidden || ! $retailer_price_hidden ) {
			$retailer_price_html = wwp_strike_through_price_element('start');

			if ( $wcv_min_price == $wcv_max_price ) {
				$retailer_price_html .= wc_price($wcv_min_price) . ' ';
			} else {
				$retailer_price_html .= wc_price($wcv_min_price) . '  - ' . wc_price($wcv_max_price) . ' ';
			}

			$retailer_price_html .= wwp_strike_through_price_element('end');
			$html .= '<p>';

			if ( ! $retailer_label_hidden ) {
				$html .= '<span class="retailer-text">' . esc_html__($actual, 'woocommerce-wholesale-pricing') . '</span>';

				if ( ! $retailer_price_hidden ) {
					$html .= ': ';
				}
			}

			if ( ! $retailer_price_hidden ) {
				$html .= $retailer_price_html;
			}

			$html .= '</p>';
		}

		$wholesaler_label_hidden = ( isset( $settings['wholesaler_disabled'] ) && 'yes' === $settings['wholesaler_disabled'] );
		$wholesaler_price_hidden = ( isset( $settings['wholesaler_price_disabled'] ) && 'yes' === $settings['wholesaler_price_disabled'] );
		$wholesale_price_html    = wc_price($wholesale_product_variations[0]) . ' ';

		if ( wc_price($wholesale_product_variations[0]) !== wc_price($wholesale_product_variations[ count($wholesale_product_variations) - 1 ]) ) {
			$wholesale_price_html = wc_price($wholesale_product_variations[0]) . '  - ' . wc_price($wholesale_product_variations[ count($wholesale_product_variations) - 1 ]) . ' ';
		}

		if ( ! $wholesaler_label_hidden || ! $wholesaler_price_hidden ) {
			$html .= '<p><b>';

			if ( ! $wholesaler_label_hidden ) {
				$html .= '<span class="price-text">' . esc_html__($new, 'woocommerce-wholesale-pricing') . '</span>';

				if ( ! $wholesaler_price_hidden ) {
					$html .= ': ';
				}
			}

			if ( ! $wholesaler_price_hidden ) {
				$html .= $wholesale_price_html;
			}

			$html .= '</b></p>';
		}

		$save_label_hidden = ( isset( $settings['save_price_label_disabled'] ) && 'yes' === $settings['save_price_label_disabled'] );
		$save_price_hidden = ( isset( $settings['save_price_disabled'] ) && 'yes' === $settings['save_price_disabled'] );

		if ( ! $save_label_hidden || ! $save_price_hidden ) {
			$save_variable = '';

			if ( ! $save_price_hidden ) {
				if ( round($min_saving_percent) !== round($max_saving_percent) ) {
					/**
					* Hooks
					*
					* @since 2.6.1
					*/
					$save_variable = apply_filters('wwp_remove_save_variable_wholesale_percent', ' (' . round($min_saving_percent) . '% - ' . round($max_saving_percent) . '%)');
				} else {
					/**
					* Hooks
					*
					* @since 2.6.1
					*/
					$save_variable = apply_filters('wwp_remove_save_variable_wholesale_percent_same', '(' . round($min_saving_percent) . '%)');
				}
			}

			$html .= '<p><b>';

			if ( ! $save_label_hidden ) {
				$html .= '<span class="save-price-text">' . esc_html__($save, 'woocommerce-wholesale-pricing') . '</span>';

				if ( ! $save_price_hidden ) {
					$html .= ': ';
				}
			}

			if ( ! $save_price_hidden ) {
				$html .= $save_variable;
			}

			$html .= '</b></p>';
		}
		if (wwp_guest_wholesale_pricing_enabled() ) {
			$min = ( float ) $min_original_variation_price - ( float ) $wholesale_product_variations[0];
			$max =  ( float ) $max_original_variation_price -  ( float ) $wholesale_product_variations[ count($wholesale_product_variations) - 1 ];
			$text = str_replace('{saved_amount}', '<strong>' . wc_price($min) . ' - ' . wc_price($max) . '</strong>', wwp_guest_wholesale_pricing_enabled('message'));
			$text = str_replace('{saved_percentage}', '<strong>' . round($max_saving_percent) . '%</strong>', $text);
			$html .= '<p>' . wp_kses_post($text) . '</p>';
		}
		$html .= '</div>';
		 
		/**
		* Hooks
		*
		* @since 3.0
		*/
		$html .= do_action('wwp_after_pricing', $product);
		/**
		* Hooks
		*
		* @since 3.0
		*/
		return apply_filters('wwp_product_price_variable', $html);
	}
endif;

if (! function_exists('simple_wholesale_product_price_html') ) :    
	/**
	 * Method simple_wholesale_product_price_html
	 *
	 * @param  string      $discountType
	 * @param  int         $wholesale_price
	 * @param  int         $r_price
	 * @param  int         $min
	 * @param  \WC_Product $product
	 * @return string HTML
	 */
	function simple_wholesale_product_price_html( $discountType = '', $wholesale_price = '', $r_price = '', $min = '', $product = '' ) {
		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

		$r_price = get_post_meta($product->get_id(), $price_key, true);
		 
		if (class_exists('Wpexperts\CurrencySwitcherForWoocommerce\WCCS') ) {
			global $WCCS;
			$r_price = $WCCS->wccs_price_conveter($r_price);
		}

		$Wprice  = '_price'==$price_key ? $product->get_price() : $product->get_regular_price();
		 
		if (is_admin() ) {
			$Wprice =   wholesale_type_price($r_price, $discountType, $wholesale_price);
		}
		 
		if (empty($r_price) || '0' == $r_price ) {
			return wc_price($r_price);
		}

		/**
		 * Filter
		 * 
		 *  @since 2.5
		 */
		$check_page = apply_filters('wwp_check_page_for_inclusive_tax', false);
		$order_id = isset($_REQUEST['order_id']) ? sanitize_text_field($_REQUEST['order_id']) : get_the_ID();
		// Normal price include tax
		if (( ( $check_page || is_shop() || is_product() || is_product_category() || ( 'shop_order' != get_post_type($order_id) && shortcode_exists('wc_products_table') ) ) && 'incl' === get_option('woocommerce_tax_display_shop') ) || ( ( is_cart() || is_checkout() ) && 'incl' === get_option('woocommerce_tax_display_cart') ) ) {
			$r_price = wwp_get_price_including_tax($product, array( 'price' => $r_price ));
			$Wprice  = wwp_get_price_including_tax($product, array( 'price' => $Wprice ));
		} else {
			$r_price = wc_get_price_excluding_tax($product, array( 'price' => $r_price ));
			$Wprice  = wc_get_price_excluding_tax($product, array( 'price' => $Wprice ));
		}

		/**
		 * Filter
		 * 
		 *  @since 2.6
		 */
		$r_price = apply_filters('wwp_regular_price_on_product_page', $r_price, $product);
		/**
		 * Filter
		 * 
		 *  @since 2.6
		 */
		$Wprice = apply_filters('wwp_wholesale_price_on_product_page', $Wprice, $product);

		$saving_amount  = ( $r_price - $Wprice );
		$saving_amount  = number_format((float) $saving_amount, 2, '.', '');
		$saving_percent = ( $r_price - $Wprice ) / $r_price * 100;
		$saving_percent = number_format((float) $saving_percent, 2, '.', '');
		$settings       = WholesaleSettingsHelper::get_pricing_settings();
		$actual         = ( isset($settings['retailer_label']) && ! empty($settings['retailer_label']) ) ? esc_html($settings['retailer_label']) : esc_html__('Actual', 'woocommerce-wholesale-pricing');
		$save           = ( isset($settings['save_label']) && ! empty($settings['save_label']) ) ? esc_html($settings['save_label']) : esc_html__('Save', 'woocommerce-wholesale-pricing');
		$new            = ( isset($settings['wholesaler_label']) && ! empty($settings['wholesaler_label']) ) ? esc_html($settings['wholesaler_label']) : esc_html__('New', 'woocommerce-wholesale-pricing');
		$html           = '';
		if (! empty($Wprice) ) {
			/**
			* Hooks
			*
			* @since 3.0
			*/
			$html .= do_action('wwp_before_pricing', $product);
			$html .= '<div class="wwp-wholesale-pricing-details">';
			
			$retailer_label_hidden = ( isset( $settings['retailer_disabled'] ) && 'yes' === $settings['retailer_disabled'] );
			$retailer_price_hidden = ( isset( $settings['retailer_price_disabled'] ) && 'yes' === $settings['retailer_price_disabled'] );

			if ( ! $retailer_label_hidden || ! $retailer_price_hidden ) {
				$html .= '<p>';

				if ( ! $retailer_label_hidden ) {
					$html .= '<span class="retailer-text">' . esc_html__( $actual, 'woocommerce-wholesale-pricing' ) . '</span>';

					if ( ! $retailer_price_hidden ) {
						$html .= ': ';
					}
				}

				if ( ! $retailer_price_hidden ) {
					$html .= wwp_strike_through_price_element('start') .
						wc_price($r_price) . ' ' . $product->get_price_suffix(get_post_meta($product->get_id(), $price_key, true)) .
						wwp_strike_through_price_element('end');
				}

				$html .= '</p>';
			}
			
			$wholesaler_label_hidden = ( isset( $settings['wholesaler_disabled'] ) && 'yes' === $settings['wholesaler_disabled'] );
			$wholesaler_price_hidden = ( isset( $settings['wholesaler_price_disabled'] ) && 'yes' === $settings['wholesaler_price_disabled'] );

			if ( ! $wholesaler_label_hidden || ! $wholesaler_price_hidden ) {
				$html .= '<p>';

				if ( ! $wholesaler_label_hidden ) {
					$html .= '<span class="price-text">' . esc_html__($new, 'woocommerce-wholesale-pricing') . '</span>';

					if ( ! $wholesaler_price_hidden ) {
						$html .= ': ';
					}
				}

				if ( ! $wholesaler_price_hidden ) {
					$html .= wc_price($Wprice) . ' ' . $product->get_price_suffix();
				}

				$html .= '</p>';
			}
			$save_label_hidden = ( isset( $settings['save_price_label_disabled'] ) && 'yes' === $settings['save_price_label_disabled'] );
			$save_price_hidden = ( isset( $settings['save_price_disabled'] ) && 'yes' === $settings['save_price_disabled'] );

			if ( ! $save_label_hidden || ! $save_price_hidden ) {
				/**
				* Hooks
				*
				* @since 2.6.1
				*/
				$save_percent = apply_filters('wwp_remove_save_wholesale_percent', ' (' . round($saving_percent) . '%)');
				$html .= '<p><b>';

				if ( ! $save_label_hidden ) {
					$html .= '<span class="save-price-text">' . esc_html__($save, 'woocommerce-wholesale-pricing') . '</span>';

					if ( ! $save_price_hidden ) {
						$html .= ': ';
					}
				}

				if ( ! $save_price_hidden ) {
					$html .= wc_price($saving_amount) . $save_percent;
				}

				$html .= '</b></p>';
			}
			if ($min > 1 ) {
				if ($product->get_type() == 'simple' || $product->get_type() == 'subscription' ) {

					/* translators: %s: wholesale price on minmum */
					$qtytext = sprintf(esc_html__('Wholesale price will only be applied to a minimum quantity of %1$s products', 'woocommerce-wholesale-pricing'), $min);

					/**
					* Hooks
					*
					* @since 3.0
					*/
					$html .= apply_filters('wwp_product_minimum_quantity_text', '<p style="font-size: 10px;">' . $qtytext . '</p>', $min);
				}
			}
			if (wwp_guest_wholesale_pricing_enabled() ) {
				$text = str_replace('{saved_amount}', '<strong>' . wc_price($saving_amount) . '</strong>', wwp_guest_wholesale_pricing_enabled('message'));
				$text = str_replace('{saved_percentage}', '<strong>' . round($saving_percent) . '%</strong>', $text);
				$html .= '<p>' . wp_kses_post($text) . '</p>';
			}
			$html .= '</div>';

			/**
			* Hooks
			*
			* @since 3.0
			*/
			$html .= do_action('wwp_after_pricing', $product);
		}

		/**
		* Hooks
		*
		* @since 3.0
		*/
		return apply_filters('wwp_product_price_simple', $html, $product);
	}
endif;

if (! function_exists('simple_subsc_wholesale_product_price_html') ) :    
	/**
	 * Method simple_subsc_wholesale_product_price_html
	 *
	 * @param  string      $discountType
	 * @param  int         $wholesale_price
	 * @param  int         $min
	 * @param  \WC_Product $product
	 * @return string HTML
	 */
	function simple_subsc_wholesale_product_price_html( $discountType = '', $wholesale_price = '', $min = '', $product = '' ) {

		$charge_price =$product->get_meta('_subscription_period_interval');
		if (1 == $charge_price ) {
			$charge_price = '/';
		}
		$period = $product->get_meta('_subscription_period');
		$cancel = $product->get_meta('_subscription_length');
		$sign_up_fee = $product->get_meta('_subscription_sign_up_fee');
		$cancelation = '';
		if (! empty($cancel) ) {
			$cancelation = ' for ' . $cancel . ' ' . $period;
		}

		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

		$r_price = get_post_meta($product->get_id(), $price_key, true);
		 
		if (class_exists('Wpexperts\CurrencySwitcherForWoocommerce\WCCS') ) {
			global $WCCS;
			$r_price = $WCCS->wccs_price_conveter($r_price);
		}

		$Wprice  = $product->get_regular_price();
		 
		if (is_admin() ) {
			$Wprice =   wholesale_type_price($r_price, $discountType, $wholesale_price);
		}
		 
		if (empty($r_price) || '0' == $r_price ) {
			return wc_price($r_price);
		}

		/**
		 * Filter
		 * 
		 *  @since 2.5
		 */
		$check_page = apply_filters('wwp_check_page_for_inclusive_tax', false);
		$order_id = isset($_REQUEST['order_id']) ? sanitize_text_field($_REQUEST['order_id']) : get_the_ID();
		// Normal price include tax
		if (( ( $check_page || is_shop() || is_product() || is_product_category() || ( 'shop_order' != get_post_type($order_id) && shortcode_exists('wc_products_table') ) ) && 'incl' === get_option('woocommerce_tax_display_shop') ) || ( ( is_cart() || is_checkout() ) && 'incl' === get_option('woocommerce_tax_display_cart') ) ) {
			$r_price = wwp_get_price_including_tax($product, array( 'price' => $r_price ));
			$Wprice  = wwp_get_price_including_tax($product, array( 'price' => $Wprice ));
		} else {
			$r_price = wc_get_price_excluding_tax($product, array( 'price' => $r_price ));
			$Wprice  = wc_get_price_excluding_tax($product, array( 'price' => $Wprice ));
		}
		$saving_amount  = ( $r_price - $Wprice );
		$saving_amount  = number_format((float) $saving_amount, 2, '.', '');
		$saving_percent = ( $r_price - $Wprice ) / $r_price * 100;
		$saving_percent = number_format((float) $saving_percent, 2, '.', '');
		$settings       = WholesaleSettingsHelper::get_pricing_settings();
		$actual         = ( isset($settings['retailer_label']) && ! empty($settings['retailer_label']) ) ? esc_html($settings['retailer_label']) : esc_html__('Actual', 'woocommerce-wholesale-pricing');
		$save           = ( isset($settings['save_label']) && ! empty($settings['save_label']) ) ? esc_html($settings['save_label']) : esc_html__('Save', 'woocommerce-wholesale-pricing');
		$new            = ( isset($settings['wholesaler_label']) && ! empty($settings['wholesaler_label']) ) ? esc_html($settings['wholesaler_label']) : esc_html__('New', 'woocommerce-wholesale-pricing');
		$html           = '';
		if (! empty($Wprice) ) {
		 
			/**
			* Hooks
			*
			* @since 3.0
			*/
			$html .= do_action('wwp_before_pricing', $product);
			$sign_up_fee_text = !empty($sign_up_fee) ? ' and a ' . get_woocommerce_currency_symbol() . $sign_up_fee . ' sign-up fee' : '';
			$html .= '<div class="wwp-wholesale-pricing-details">';
			if ('yes' != $settings['retailer_disabled'] ) {
				$html .= '<p><span class="retailer-text">' . esc_html__($actual, 'woocommerce-wholesale-pricing') . '</span>: ' . wwp_strike_through_price_element('start') . wc_price($r_price) . ' ' . $product->get_price_suffix(get_post_meta($product->get_id(), $price_key, true)) . wwp_strike_through_price_element('end') . '</p>';
			}
			$html .= sprintf('<p><span class="price-text">%s</span>: %s %s%s%s%s%s</p>', esc_html__($new, 'woocommerce-wholesale-pricing'), wc_price($Wprice), $product->get_price_suffix(), $charge_price, $period, $cancelation, $sign_up_fee_text);
			if ('yes' != $settings['save_price_disabled'] ) {
				$html .= '<p><b><span class="save-price-text">' . esc_html__($save, 'woocommerce-wholesale-pricing') . '</span>: (' . round($saving_percent) . '%) </b></p>';
			}
			if ($min > 1 ) {
				if ($product->get_type() == 'simple' || $product->get_type() == 'subscription' ) {

					/* translators: %s: wholesale price on minmum */
					$qtytext = sprintf(esc_html__('Wholesale price will only be applied to a minimum quantity of %1$s products', 'woocommerce-wholesale-pricing'), $min);

					/**
					* Hooks
					*
					* @since 3.0
					*/
					$html .= apply_filters('wwp_product_minimum_quantity_text', '<p style="font-size: 10px;">' . $qtytext . '</p>', $min);
				}
			}
			if (wwp_guest_wholesale_pricing_enabled() ) {
				$text = str_replace('{saved_amount}', '<strong>' . wc_price($saving_amount) . '</strong>', wwp_guest_wholesale_pricing_enabled('message'));
				$text = str_replace('{saved_percentage}', '<strong>' . round($saving_percent) . '%</strong>', $text);
				$html .= '<p>' . wp_kses_post($text) . '</p>';
			}
			$html .= '</div>';

			/**
			* Hooks
			*
			* @since 3.0
			*/
			$html .= do_action('wwp_after_pricing', $product);
		}
		 
		/**
		* Hooks
		*
		* @since 3.0
		*/
		return apply_filters('wwp_product_price_simple', $html, $product);
	}
endif;

if (! function_exists('is_wholesale_product') ) :    
	/**
	 * Method is_wholesale_product
	 *
	 * @param  int $product_id
	 * @return bool
	 */
	function is_wholesale_product( $product_id = '' ) {
		$role = get_current_user_role_id();
		$data = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
		if (isset($data[ $role ]) ) {
			return true;
		}
		$terms = get_the_terms($product_id, 'product_cat');
		if (! is_wp_error($terms) && ! empty($terms) ) {
			foreach ( $terms as $term ) {
				$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
				if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
					return true;
				}
			}
		}
		$data = WholesaleSettingsHelper::get_multiuser_pricing_settings();
		if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
			return true;
		}
		return false;
	}
endif;

if (! function_exists('calculate_percentage') ) {
	/**
	 * Method calculate_percentage
	 *
	 * @param  int $price
	 * @param  int $wholesale_price
	 * @return int|false
	 */
	function calculate_percentage( $price, $wholesale_price ) {
		if (empty($price) || empty($wholesale_price) ) {
			return false;
		}
		$wholesale_price = $price * $wholesale_price / 100;
		$saving_percent  = ( $price - $wholesale_price ) / $price * 100;
		$saving_percent  = number_format((float) $saving_percent, 2, '.', '');
		return round($saving_percent);
	}
}

if (! function_exists('get_wholesale_percentage') ) :    
	/**
	 * Method get_wholesale_percentage
	 *
	 * @param  int $product_id
	 * @return int|false
	 */
	function get_wholesale_percentage( $product_id = '' ) {
		/**
		 * Filter
		 * 
		 * @var string $price_key The price key to apply wholesale percentage on. Default is '_regular_price'.
		 * 
		 * @since 3.1.0
		 */
		$price_key = apply_filters( 'wwp_wholesale_apply_on_sale_price', '_regular_price' );

		if (is_wholesale_product($product_id) ) {
			$role         = get_current_user_role_id();
			$variation_id = $product_id;
			$data         = get_post_meta($product_id, 'wholesale_multi_user_pricing', true);
			if (isset($data[ $role ]) && 'product' == get_post_type($product_id) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
				$wholesale = $data[ $role ];
				$price     = get_post_meta($product_id, $price_key, true);
				return calculate_percentage($price, $wholesale['wholesale_price']);
			} elseif ('product_variation' == get_post_type($product_id) ) { 
				if (isset($data[ $role ]) ) {  
					if (isset($data[ $role ][ $product_id ]['wholesaleprice']) && !empty($data[ $role ][ $product_id ]['wholesaleprice']) ) { 
						$wholesale = $data[ $role ][ $product_id ]; 
						$price     = get_post_meta($product_id, $price_key, true);
						return calculate_percentage($price, $wholesale['wholesaleprice']);
					}
				}
			}
			if ('product_variation' == get_post_type($product_id) ) {  
				$variation_id = $product_id;
				$product_id   = wp_get_post_parent_id($product_id);
			}

			$terms = get_the_terms($product_id, 'product_cat');
			if (! is_wp_error($terms) && ! empty($terms) ) {
				foreach ( $terms as $term ) { 
					$data = get_term_meta($term->term_id, 'wholesale_multi_user_pricing', true);
					if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
						$wholesale = $data[ $role ];
						$price     = get_post_meta($variation_id, $price_key, true); 
						return calculate_percentage($price, $wholesale['wholesale_price']);
					}
				}
			}

			$data = WholesaleSettingsHelper::get_multiuser_pricing_settings();
			if (isset($data[ $role ]) && isset($data[ $role ]['discount_type']) && isset($data[ $role ]['wholesale_price']) ) {
				$price = get_post_meta($variation_id, $price_key, true);
				return calculate_percentage($price, $data[ $role ]['wholesale_price']);
			}
		}
		return false;
	}
endif;

if (! function_exists('get_products_by_meta') ) :
	 
	/**
	 * Method get_products_by_meta
	 *
	 * @param  string|null $key
	 * @param  string|null $value
	 * @return array
	 */
	function get_products_by_meta( $key = null, $value = null ) {

		$transient_key = 'wwp_excluded_' . md5($key . $value);
		$cached = get_transient($transient_key);

		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;

		if (! is_null($key) && ! is_null($value) ) {
			$result = $wpdb->get_results( 
				$wpdb->prepare(
					"SELECT DISTINCT p.ID AS id FROM {$wpdb->prefix}posts AS p LEFT JOIN {$wpdb->prefix}postmeta AS pm ON p.ID = pm.post_id WHERE p.post_type = %s AND p.post_status = %s AND pm.meta_key = %s AND pm.meta_value = %s", 'product', 'publish', $key, $value 
				),
				ARRAY_A
			);
		} else {
			$result = $wpdb->get_results( 
				$wpdb->prepare(
					"SELECT p.ID AS id FROM {$wpdb->prefix}posts AS p WHERE p.post_type = %s AND p.post_status = %s", 'product', 'publish'
				),
				ARRAY_A
			);
		}

		$all_ids = wp_list_pluck((array) $result, 'id');

		set_transient($transient_key, $all_ids, DAY_IN_SECONDS);

		return $all_ids;
	}

endif; 

if (! function_exists('wwp_registration_field_required_attr') ) {
		 
	/**
	 * Method wwp_registration_field_required_attr
	 *
	 * @param  string $data
	 * @param  string $attr
	 * @return string|null HTML element
	 */
	function wwp_registration_field_required_attr( $data = '', $attr = 'required' ) {

		if (isset($data) && 'yes' == $data ) {
			if ('required' == $attr ) {
				echo 'required';
			} else {
				echo '<span class="required"> *</span>';
			}
		} else if ('span' == $attr ) {
			echo '<span class="optional"> (optional)</span>';
		}

		return null;
	}

}

if (! function_exists('wwp_get_active_payment_methods') ) {    
	/**
	 * Method wwp_get_active_payment_methods
	 *
	 * @return array
	 */
	function wwp_get_active_payment_methods() {
		$active_payment_methods = array();
		$payment_methods = array();
		$settings = WholesaleSettingsHelper::get_pricing_settings();
		 
		if (! isset($settings['enable_custom_payment_method']) || 'yes' != $settings['enable_custom_payment_method'] ) {
			return array();
		}
		if (! is_wholesaler_user(get_current_user_id()) && ! is_admin() ) {
			return array();
		}

		$role = get_current_user_role_id();
		 
		if ($role ) {  
			$payment_methods = get_term_meta($role, 'wwp_wholesale_payment_method_name', true);
		}

		if (empty($payment_methods) ) {
			return array();
		}

		foreach ( $payment_methods as $index => $active ) {
			if ('yes' == $active ) {
				$active_payment_methods[] = strtolower(str_replace(' ', '_', $index));
			}
		}

		return $active_payment_methods;
	}
}

/**
 * Method wwp_strike_through_price_element
 *
 * @param  string $type
 * @return string HTML element
 */
function wwp_strike_through_price_element( $type ) {
	$settings = WholesaleSettingsHelper::get_pricing_settings();
	if (isset($settings['enable_strike_through_price']) && 'no' == $settings['enable_strike_through_price'] ) {
		return ( $type ) ? '<span>' : '</span>';
	}

	return ( 'start' == $type ) ? '<s>' : '</s>';
}

/**
 * Method wwp_guest_wholesale_pricing_enabled
 *
 * @param  string $key
 * @return bool|string|array
 */
function wwp_guest_wholesale_pricing_enabled( $key = '' ) {
	 
	$settings = WholesaleSettingsHelper::get_pricing_settings();

	if (isset($settings['enable_wholesale_price'], $settings['wwp_select_wholesale_role_for_non_logged_in']) && 'yes' == $settings['enable_wholesale_price'] && -1 != $settings['wwp_select_wholesale_role_for_non_logged_in'] && function_exists('is_user_logged_in') &&! is_user_logged_in() ) {

		$guest_wholesaler_data = array( 
		'role' => $settings['wwp_select_wholesale_role_for_non_logged_in'],
		'display_on_shop'   => ( isset($settings['enable_non_logged_shop_page_wholesale_price']) && 'yes' == $settings['enable_non_logged_shop_page_wholesale_price'] ) ? true : false,
		'display_on_single' => ( isset($settings['enable_non_logged_product_page_wholesale_price']) && 'yes' == $settings['enable_non_logged_product_page_wholesale_price'] ) ? true : false,
		'message'   => isset($settings['wwp_custom_message_non_logged_in']) ? $settings['wwp_custom_message_non_logged_in'] : '',
		);

		if (! empty($key) && isset($guest_wholesaler_data[$key]) ) {
			return $guest_wholesaler_data[$key];
		}

		return $guest_wholesaler_data;
	} else {
		return false;
	}
}

if (! function_exists('wwp_get_group_post_by_proid') ) {    
	/**
	 * Method wwp_get_group_post_by_proid
	 *
	 * @param  int $product_id
	 * @param  int $user_id
	 * @return array
	 */
	function wwp_get_group_post_by_proid( $product_id = 0, $user_id = 0 ) {
		$settings = WholesaleSettingsHelper::get_pricing_settings();
		if (isset($settings['enable_groups']) && 'yes' !== $settings['enable_groups'] ) { 
			return array();
		}
		 
		// Check if user_id is empty, return empty array
		if (empty($user_id) ) {
			return array();
		}

		$args = array(
			'post_type'      => 'wwp_groups',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'post_status'    => 'publish',
			'meta_query'     => array(
				'relation' => 'OR',
				array(
					'key'     => '_add_users',
					'value'   => '"' . $user_id . '"',
					'compare' => 'LIKE',
				),
				array(
					'key'     => '_add_users',
					'value'   => 'i:' . absint($user_id) . ';',
					'compare' => 'LIKE',
				),
			),
		);

		$user_posts = get_posts($args);
		$assigned_group = absint(get_user_meta($user_id, 'user_wwp_groupname', true));
		if ($assigned_group > 0 && 'publish' === get_post_status($assigned_group) && 'wwp_groups' === get_post_type($assigned_group) ) {
			$user_posts[] = $assigned_group;
		}
		$user_posts = array_values(array_unique(array_map('absint', (array) $user_posts)));

		if (empty($user_posts) ) {
			return array();
		}

		if ($product_id > 0 ) {

			$product = wc_get_product($product_id);

			if (! $product ) {
				return array();
			}

			$product_excluded = false;

			// Loop through all posts to check if the product is excluded in any post
			foreach ( $user_posts as $post_id ) {

				$exclude_products = get_post_meta($post_id, '_exclude_products', true);

				if (! empty($exclude_products) && in_array($product_id, $exclude_products) ) {
					$product_excluded = true;
					break;
				}
			}

			if ($product_excluded && $product_id > 0 ) {
				return array();
			}

			$included_posts = array();

			foreach ( $user_posts as $post_id ) {
				$include_products = get_post_meta($post_id, '_include_specific_products', true);
				$include_type      = get_post_meta($post_id, '_include_products', true);
				if (( 'specific' == $include_type && ! empty($include_products) &&  in_array($product_id, $include_products) ) || 'all' == $include_type ) {
					$included_posts[] = $post_id;
				}
			}
			return $included_posts;
		}

		return $user_posts;
	}

}

/**
 * Method wwp_exclude_variations
 *
 * @param  array      $variations
 * @param  int|string $mine
 * @return array of variations
 */
function wwp_exclude_variations( $variations, $mine = '' ) {
	if (! empty($variations) ) {
		$args  = array(
		'hide_empty'     => false,
		'fields'         => 'ids',
		'posts_per_page' => -1,
		'meta_query'     => array(
		array(
		'key'     => 'wwp_wholesaler_subscription',
		'compare' => 'EXISTS',
		),
		),
		'taxonomy'       => 'wholesale_user_roles',
		);
		$terms = get_terms($args);

		if ( is_wp_error( $terms ) ) {
			return array();
		}

		if (! empty($terms) ) {
			foreach ( $terms as $term_id ) {
				$variation_id = get_term_meta($term_id, 'wwp_wholesaler_subscription', true);
				if ($mine == $variation_id ) {
					continue;
				}
				$variations = array_filter(
					$variations,
					function ( $element ) use ( $variation_id ) {
						return ( $element['variation_id'] != $variation_id );
					}
				);
			}
		}
	}
	return $variations;
}

/**
 * Method recaptcha_initialize
 *
 * @return array of recaptcha setting keys
 */
function recaptcha_initialize() {
	/**
	 * Core recaptcha Integration
	 */
	$settings = WholesaleSettingsHelper::get_registration_settings();

	if (isset($settings['enable_recaptcha']) && 'yes' == $settings['enable_recaptcha'] ) {
		include_once WWP_PLUGIN_PATH . 'app/Modules/Recaptcha/Google_Recaptcha.php';
		( new Google_Recaptcha($settings) );
		$site_key   = isset($settings['recaptcha_v2_site_key']) ? $settings['recaptcha_v2_site_key'] : '' ;
		$theme      = isset($settings['recaptcha_v2_theme']) ? $settings['recaptcha_v2_theme'] : '' ;
		return array( 'site_key' => $site_key, 'theme' => $theme );
	}

	/**
	 * C4wp recaptcha integration
	 * 
	 * V2 Only
	 */
	$settings = ( is_multisite() ) ? get_site_option('c4wp_admin_options') : get_option('c4wp_admin_options');

	if (function_exists('anr_verify_captcha') ) {
		include_once WWP_PLUGIN_PATH . 'app/Modules/Recaptcha/C4WP_Recaptcha.php';
		( new C4WP_Recaptcha($settings) );
		$site_key   = isset($settings['site_key']) ? $settings['site_key'] : '';
		$theme      = isset($settings['theme']) ? $settings['theme'] : '';
		return array( 'site_key' => $site_key, 'theme' => $theme );
	}

	/**
	 * I13_woo reCaptcha for WooCommerce V2 and V3 Integration
	 */
	$settings = array(
	'enable'            => get_option('wwp_recapcha_enable_on_woo_wholesale'),
	'error_message'     => get_option('i13_recapcha_error_msg_v3_invalid_captcha'),
	'version'           => get_option('i13_recapcha_version'),
	'v2_site_key'       => get_option('wc_settings_tab_recapcha_site_key'),
	'v2_secret_key'     => get_option('wc_settings_tab_recapcha_secret_key'),
	'v3_site_key'       => get_option('wc_settings_tab_recapcha_site_key_v3'),
	'v3_secret_key'     => get_option('wc_settings_tab_recapcha_secret_key_v3'),
	);

	if (class_exists('I13_Woo_Recpatcha') ) {
		include_once WWP_PLUGIN_PATH . 'app/Modules/Recaptcha/I13_Recaptcha.php';
		( new I13_Recaptcha($settings) );
		return array( 'site_key' => $settings['v2_site_key'], 'theme' => 'light' );
	}

	return array( 'site_key' => false, 'theme' => false );
}

/**
 * Method get_registration_requests_count
 *
 * @return string Html response
 */
function get_registration_requests_count() {
	$args        = array(
	'posts_per_page' => -1,
	'post_type'      => 'wwp_requests',
	'post_status'    => 'publish',
	'meta_key'       => '_user_status',
	'meta_value'     => 'waiting',
	);
	$posts_query = new \WP_Query($args);
	return ( 0 != $posts_query->post_count ) ? sprintf('<span class="awaiting-mod">%s</span>', $posts_query->post_count) : '';
}

/**
 * Method wwp_is_subscription_active
 *
 * @return bool
 */
function wwp_is_subscription_active() {
	/**
	 * Filter array active plugins
	 *
	 * @since 1.5.0
	 */
	return in_array('woocommerce-subscriptions/woocommerce-subscriptions.php', apply_filters('active_plugins', get_option('active_plugins')));
}

/**
 * Method wwp_get_current_user_role
 *
 * @return string|false
 */
function wwp_get_current_user_role() {
	if (! is_user_logged_in() ) {
		return false;
	}
	$user = get_userdata(get_current_user_id());
	$user_role = implode(', ', $user->roles);
	return $user_role;
}

/**
 * Method get_sorted_admin_discounts_view
 *
 * @param  array $discounts
 * @return array
 */
function get_sorted_admin_discounts_view( $discounts = array() ) {
	uksort(
		$discounts, function ( $a, $b ) {
			$order = array( 'product_', 'category_', 'global_' );

			$a_prefix = '';
			$b_prefix = '';

			foreach ($order as $prefix) {
				if (strpos($a, $prefix) === 0) {
					$a_prefix = $prefix;
					break;
				}
			}

			foreach ($order as $prefix) {
				if (strpos($b, $prefix) === 0) {
					$b_prefix = $prefix;
					break;
				}
			}

			$a_index = array_search( $a_prefix, $order );
			$b_index = array_search( $b_prefix, $order );

			if ( $a_index == $b_index ) {
				$result = 0;
			} elseif ( $a_index < $b_index ) {
				$result = -1;
			} else {
				$result = 1;
			}
			if (0 !== $result) {
				return $result;
			}

			preg_match('/_(\d+)/', $a, $a_num);
			preg_match('/_(\d+)/', $b, $b_num);
			return ( ( isset( $a_num[1] ) ? $a_num[1] : 0 ) < ( isset( $b_num[1] ) ? $b_num[1] : 0 ) ) ? -1 : ( ( isset( $a_num[1] ) ? $a_num[1] : 0 ) > ( isset( $b_num[1] ) ? $b_num[1] : 0 ) ? 1 : 0 );
		}
	);

	return $discounts;
}

/**
 * Method get_admin_discount_type_link
 *
 * @param  string $type
 * @param  int    $post_id
 * @param  array  $keys
 * @return string URL to redirect
 */
function get_admin_discount_type_link( $type, $post_id, $keys ) {
	switch ( $type ) {
		case 'global':
			return admin_url('admin.php?page=wwp_wholesale_settings&tab=global');
		case 'category':
			return admin_url(sprintf('term.php?taxonomy=product_cat&tag_ID=%s&post_type=product', $keys[1]));
		case 'product':
			return get_edit_post_link($post_id);
		default:
			return '';
	}
}


function freemius_license_missing_notice() {
	add_action(
		'admin_notices', function () {
			echo '<div class="notice notice-error"><p>' . esc_html__('Wholesale for WooCommerce requires a valid license to function properly. Please activate your license.', 'quick-commerce') . '</p></div>';
		}
	);
}

function is_product_category_excluded_global( $product_id ) {
	$role               = get_current_user_role_id();
	$category_ids       = (array) wp_get_post_terms($product_id, 'product_cat', array( 'fields' => 'ids' ));
	$all_category_ids   = array();

	foreach ( $category_ids as $cat_id ) {
		$all_category_ids[] = $cat_id;

		$parent_id = get_term($cat_id, 'product_cat')->parent;

		while ( 0 != $parent_id && ! in_array($parent_id, $all_category_ids) ) {
			$all_category_ids[] = $parent_id;
			$parent_id = get_term($parent_id, 'product_cat')->parent;
		}
	}

	$flag = false;
	$excluded_categories = get_excluded_categories_for_wholesale_roles();
	
	if (! empty($all_category_ids) && ! empty($excluded_categories) && isset($excluded_categories[$role]) ) {
		foreach ( $all_category_ids as $cat_id ) {
			if (in_array($cat_id, $excluded_categories[$role]) ) {
				$flag = true;
				break;
			}
		}
	}

	return $flag;
}

function get_excluded_categories_for_wholesale_roles() {

	$user_roles = get_terms(array( 'taxonomy' => wwp_env()->get('role_taxonomy'), 'hide_empty' => false ));

	if (empty($user_roles) || is_wp_error($user_roles) ) {
		return array();
	}
	// Get saved excluded categories from options
	$settings = get_option('wholesale_multi_user_pricing');
	if (empty($settings) || ! is_array($settings) ) {
		return array();
	}

	$excluded_cat_ids = array();

	foreach ( $user_roles as $role ) {
		$term_id = $role->term_id;
		if (isset($settings[ $term_id ]['exclude_categories']) 
			&& is_array($settings[ $term_id ]['exclude_categories'])
		) {
			$excluded_cat_ids[$term_id] = $settings[ $term_id ]['exclude_categories'];
		}
	}

	if (empty($excluded_cat_ids) ) {
		return array();
	}

	return $excluded_cat_ids;
}

function maybe_set_registration_page( $page_id = '' ) {
	if ( empty( $page_id ) ) {
		return;
	}

	$shortcode     = wwp_env()->get('registration_shortcode');
	$shortcode_tag = '[' . $shortcode . ']';

	$old_page_id = get_option('wwp_registration_page_id');

	if ( $old_page_id && $old_page_id != $page_id ) {

		$old_page = get_post( $old_page_id );

		if ( $old_page ) {
			wp_update_post(array(
				'ID'           => $old_page_id,
				'post_content' => wwp_remove_registration_form_markup( $old_page->post_content ),
			));
		}
	}

	$new_page = get_post( $page_id );

	if ( $new_page && ! wwp_content_has_registration_form( $new_page->post_content ) ) {

		wp_update_post(array(
			'ID'           => $page_id,
			'post_content' => trim($new_page->post_content) . "\n" . $shortcode_tag,
		));
	}

	update_option('wwp_registration_page_id', $page_id);
}

/**
 * Whether content already contains the registration shortcode or Gutenberg block.
 *
 * @param string $content Post content.
 * @return bool
 */
function wwp_content_has_registration_form( $content ) {
	if ( empty( $content ) ) {
		return false;
	}

	if ( function_exists( 'has_block' ) && has_block( 'wholesale/wholesale-registration', $content ) ) {
		return true;
	}

	$shortcode = wwp_env()->get( 'registration_shortcode' );

	return $shortcode && has_shortcode( $content, $shortcode );
}

/**
 * Strip registration shortcode and Gutenberg block from post content.
 *
 * @param string $content Post content.
 * @return string
 */
function wwp_remove_registration_form_markup( $content ) {
	$shortcode = wwp_env()->get( 'registration_shortcode' );

	if ( $shortcode ) {
		$content = preg_replace( '/\[' . preg_quote( $shortcode, '/' ) . '.*?\]/', '', $content );
	}

	// Self-closing Gutenberg block: <!-- wp:wholesale/wholesale-registration /-->
	$content = preg_replace(
		'/<!--\s+wp:wholesale\/wholesale-registration(?:\s+\{.*?\})?\s+\/-->/',
		'',
		$content
	);

	// Paired Gutenberg block.
	$content = preg_replace(
		'/<!--\s+wp:wholesale\/wholesale-registration(?:\s+\{.*?\})?\s+-->.*?<!--\s+\/wp:wholesale\/wholesale-registration\s+-->/s',
		'',
		$content
	);

	return trim( $content );
}

function is_wholesale_registration_page() {
	if ( is_admin() && ! wp_doing_ajax() ) {
		return false;
	}

	$registration_page_id = absint( get_option( 'wwp_registration_page_id' ) );
	if ( $registration_page_id && function_exists( 'is_page' ) && is_page( $registration_page_id ) ) {
		return true;
	}

	global $post;

	if ( empty($post) ) {
		return false;
	}

	return isset( $post->post_content ) && wwp_content_has_registration_form( $post->post_content );
}

function email_placeholders_content() {
	ob_start();
	?>
		<p><strong><?php esc_html_e('Additional Placeholders:', 'woocommerce-wholesale-pricing'); ?></strong>
		</p>
		<ul style="margin-left: 20px; list-style: disc;">
			<li><?php esc_html_e('Billing: {billing_first_name}, {billing_last_name}, {billing_company}, {billing_address_1}, {billing_address_2}, {billing_city}, {billing_state}, {billing_postcode}, {billing_country}, {billing_phone}', 'woocommerce-wholesale-pricing'); ?>
			</li>
			<li><?php esc_html_e('Shipping: {shipping_first_name}, {shipping_last_name}, {shipping_company}, {shipping_address_1}, {shipping_address_2}, {shipping_city}, {shipping_state}, {shipping_postcode}, {shipping_country}, {shipping_phone}', 'woocommerce-wholesale-pricing'); ?>
			</li>
			<li><?php esc_html_e('Other: {tax_id}', 'woocommerce-wholesale-pricing'); ?>
			</li>
		</ul>
		<?php
		$form_builder_fields = json_decode(get_option('wwp_save_form', '[]'), true);
		if (isset($form_builder_fields['components']) && !empty($form_builder_fields['components'])) :
			?>
			<p><strong><?php esc_html_e('Extra Fields (from Form Builder):', 'woocommerce-wholesale-pricing'); ?></strong>
			</p>
			<ul style="margin-left: 20px; list-style: disc;">
				<?php foreach ($form_builder_fields['components'] as $index => $field) : ?>
					<?php
					if ( 'content' == $field['type'] ) {
continue;}
					?>
					<li><code>{<?php echo esc_html($field['key']); ?>}</code> -
						<?php echo esc_html($field['label']); ?></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	
	<?php 
	return ob_get_clean();
}

function wp_get_roles_except_wholesale() {
	$roles      = array();
	$all_roles  = wp_roles()->role_names;

	$wholesale_roles = get_terms( array( 'taxonomy' => 'wholesale_user_roles', 'hide_empty' => false ) );
	$wholesale_roles = array_column( (array) $wholesale_roles, 'slug');

	foreach ( $all_roles as $role_key => $role_name ) {
		if ( ! in_array($role_key, $wholesale_roles) ) {
			$roles[$role_key] = $role_name;
		}
	}

	return $roles;
}

/**
 * Retrieve split country list for optgroups.
 */
function get_optgroup_countries_data() {
	$countries_obj = new WC_Countries();
	$all_countries = $countries_obj->get_countries();
	$eu_countries  = $countries_obj->get_european_union_countries();

	$eu_group    = array();
	$other_group = array();

	foreach ( $all_countries as $code => $name ) {
		if ( in_array( $code, $eu_countries, true ) ) {
			$eu_group[ $code ] = $name;
		} else {
			$other_group[ $code ] = $name;
		}
	}

	return array(
		__( 'EU Countries', 'woocommerce' )        => $eu_group,
		__( 'All Other Countries', 'woocommerce' ) => $other_group,
	);
}

function validate_vat( $vat ) {
	$settings = \WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper::get_registration_settings();
	$enable_vat_authentication = isset($settings['vat_validation']) && 'yes' == $settings['vat_validation'];
	$vat_error_message = esc_html__('Invalid VAT number, please try again', 'woocommerce-wholesale-pricing');

	$wc_vat_number = ! empty( $vat ) ? $vat : '';

	if ( $enable_vat_authentication  ) {

		// Check if $wc_vat_number is empty
		if (empty($wc_vat_number) ) {
			return esc_html__('VAT Number is a required field', 'woocommerce-wholesale-pricing');

		} else {
			try {
				$api_url = wwp_env()->get('vat_validation_wsdl_url');
				$client = new SoapClient($api_url);

				$response = $client->checkVat(
					array(
					'countryCode' => substr($wc_vat_number, 0, 2),
					'vatNumber' => substr($wc_vat_number, 2),
					)
				);

				if (!$response->valid) {
					return $vat_error_message;
				} else {
					return false;
				}

			} catch (SoapFault $e) {

				// Handle the specific error condition
				if ($e->getMessage() == 'INVALID_INPUT') {

					return esc_html__('Invalid input error occurred. Please check the VAT number format.', 'wc-user-registration');
				} else {
					// Handle other SOAP errors
					return esc_html__('SOAP Error: ' . $e->getMessage(), 'wc-user-registration');
				}

			} catch (Exception $e) {
				// Handle other errors
				return esc_html__('SOAP Error: ' . $e->getMessage(), 'wc-user-registration');                        
			}
		}
	}       
	return false;
}

function validate_uk_postcode( $original_postcode ) {
	// Set callback's custom error message (CI specific)
	// $this->set_message('check_postcode_uk', 'Invalid UK postcode format.');

	// Permitted letters depend upon their position in the postcode.
	// Character 1
	$alpha1 = '[abcdefghijklmnoprstuwyz]';
	// Character 2
	$alpha2 = '[abcdefghklmnopqrstuvwxy]';
	// Character 3
	$alpha3 = '[abcdefghjkpmnrstuvwxy]';
	// Character 4
	$alpha4 = '[abehmnprvwxy]';
	// Character 5
	$alpha5 = '[abdefghjlnpqrstuwxyz]';

	// Expression for postcodes: AN NAA, ANN NAA, AAN NAA, and AANN NAA with a space
	$pcexp[0] = '/^(' . $alpha1 . '{1}' . $alpha2 . '{0,1}[0-9]{1,2})([[:space:]]{0,})([0-9]{1}' . $alpha5 . '{2})$/';

	// Expression for postcodes: ANA NAA
	$pcexp[1] = '/^(' . $alpha1 . '{1}[0-9]{1}' . $alpha3 . '{1})([[:space:]]{0,})([0-9]{1}' . $alpha5 . '{2})$/';

	// Expression for postcodes: AANA NAA
	$pcexp[2] = '/^(' . $alpha1 . '{1}' . $alpha2 . '{1}[0-9]{1}' . $alpha4 . ')([[:space:]]{0,})([0-9]{1}' . $alpha5 . '{2})$/';

	// Exception for the special postcode GIR 0AA
	$pcexp[3] = '/^(gir)([[:space:]]{0,})(0aa)$/';

	// Standard BFPO numbers
	$pcexp[4] = '/^(bfpo)([[:space:]]{0,})([0-9]{1,4})$/';

	// c/o BFPO numbers
	$pcexp[5] = '/^(bfpo)([[:space:]]{0,})(c\/o([[:space:]]{0,})[0-9]{1,3})$/';

	// Overseas Territories
	$pcexp[6] = '/^([a-z]{4})([[:space:]]{0,})(1zz)$/';

	// Anquilla
	$pcexp[7] = '/^ai-2640$/';

	// Load up the string to check, converting into lowercase
	$postcode = strtolower($original_postcode);

	// Assume we are not going to find a valid postcode
	$valid = false;

	// Check the string against the six types of postcodes
	foreach ($pcexp as $regexp) {
		if (preg_match($regexp, $postcode, $matches)) {
			// Load new postcode back into the form element
			$postcode = strtoupper ($matches[1] . ' ' . $matches [3]);

			// Take account of the special BFPO c/o format
			$postcode = preg_replace ('/C\/O([[:space:]]{0,})/', 'c/o ', $postcode);

			// Take acount of special Anquilla postcode format (a pain, but that's the way it is)
			if (preg_match($pcexp[7], strtolower($original_postcode))) {
				$postcode = 'AI-2640';
			}

			// Remember that we have found that the code is valid and break from loop
			$valid = true;
			break;
		}
	}

	// Return with the reformatted valid postcode in uppercase if the postcode was
	return $valid ? $postcode : false;
}

function is_quote_enabled() {
	$settings = \WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper::get_pricing_settings();
	return isset( $settings['enable_quote'] ) && 'yes' == $settings['enable_quote'];
}

function is_product_table_enabled() {
	$settings = \WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper::get_pricing_settings();
	return isset( $settings['product_table'] ) && 'yes' == $settings['product_table'];
}

function is_quick_order_form_enabled() {
	$settings = \WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper::get_pricing_settings();
	return isset( $settings['quick_order_form'] ) && 'yes' === $settings['quick_order_form'];
}

function is_sales_agent_enabled() {
	$settings = \WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper::get_pricing_settings();
	return isset($settings['sales_agent']) && 'yes' == $settings['sales_agent'];
}

function is_company_credits_enabled() {
	$settings = \WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper::get_pricing_settings();
	return isset($settings['b2b_company_credits']) && 'yes' == $settings['b2b_company_credits'];
}

/**
 * Get Dynamic Rule meta for a post.
 *
 * @param int $post_id Post ID.
 * @return array
 */
function wwp_get_dynamic_rule( $post_id ) {
	return \WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMetaHelper::get_rule( $post_id );
}

/**
 * Get Dynamic Rule summary rows for a post.
 *
 * @param int $post_id Post ID.
 * @return array
 */
function wwp_get_dynamic_rule_summary( $post_id ) {
	$rule = wwp_get_dynamic_rule( $post_id );
	return \WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMetaHelper::build_summary( $rule );
}

if ( ! function_exists( 'wwp_normalize_settings_user_roles' ) ) {
	/**
	 * Map posted role values to real role keys.
	 *
	 * The role multi-selects previously rendered selected options without a
	 * space before the value attribute, so the browser submitted the role
	 * label instead of the key. Accept both so an existing selection survives
	 * the next save.
	 *
	 * @param mixed $roles Posted or stored role values.
	 * @return array<int, string>
	 */
	function wwp_normalize_settings_user_roles( $roles ) {
		$lookup = array();
		// Virtual role supported by pricing/cart visibility selectors.
		$lookup['guest'] = 'guest';
		foreach ( get_editable_roles() as $role_key => $role_data ) {
			$lookup[ strtolower( (string) $role_key ) ] = (string) $role_key;
			if ( isset( $role_data['name'] ) ) {
				$lookup[ strtolower( (string) $role_data['name'] ) ] = (string) $role_key;
			}
		}

		$normalized = array();
		foreach ( (array) $roles as $role ) {
			$needle = strtolower( trim( (string) $role ) );
			if ( '' === $needle || ! isset( $lookup[ $needle ] ) ) {
				continue;
			}
			$normalized[] = $lookup[ $needle ];
		}

		return array_values( array_unique( $normalized ) );
	}
}