/**
 * Dynamic Rules admin UI — conditional fields, live Summary, applicable products preview.
 */
(function ($) {
	'use strict';

	var params = window.wwp_dynamic_rules_params || {};
	var ruleTypeLabels = params.ruleTypeLabels || {};
	var conditionLabels = params.conditionLabels || {};
	var appliesToLabels = params.appliesToLabels || {};
	var groupsEnabled = !!params.groupsEnabled;
	var i18n = params.i18n || {};
	var applicableProductsCfg = params.applicableProducts || {};
	var previewTimer = null;
	var previewXhr = null;
	var previewRequestId = 0;

	function getRuleType() {
		return $('#wwp_dr_rule_type').val() || 'raise-percentage';
	}

	function isChangeGroup() {
		return getRuleType() === 'change-group';
	}

	function toggleRuleTypeFields() {
		var type = getRuleType();
		if ( 'raise-percentage' === type ) {
			$('.wwp-dr-customer-types').hide();
		} else {
			$('.wwp-dr-customer-types').show();
		}
		$('.wwp-dr-field-group[data-rule-type]').each(function () {
			var $group = $(this);
			var match = $group.data('rule-type') === type;
			$group.toggle(match);
			$group.find(':input').prop('disabled', !match);
		});

		var showProductScope = !isChangeGroup();
		$('.wwp-dr-product-scope').toggle(showProductScope);
		$('.wwp-dr-product-scope').find(':input').prop('disabled', !showProductScope);

		toggleAppliesToFields();
		toggleApplicabilityMetaboxes();
		toggleThresholdSuffix();
		updateSummary();
		scheduleApplicableProductsRefresh();
	}

	function toggleThresholdSuffix() {
		var $suffix = $('.wwp-dr-threshold-suffix');
		if (!$suffix.length) {
			return;
		}

		if (!isChangeGroup()) {
			return;
		}

		var condition = $('#wwp_dr_condition').val() || 'total_spent';
		var currency = $suffix.data('currency') || params.currencySymbol || '';
		var text = currency;

		if (condition === 'no_of_orders') {
			text = '(orders)';
		} else if (condition === 'days_since_registration') {
			text = i18n.days || 'days';
		}

		$suffix.text(text);
	}

	function toggleAppliesToFields() {
		var appliesTo = $('#wwp_dr_applies_to').val() || 'all_products';
		var showScope = !isChangeGroup();

		$('.wwp-dr-applies-to-group').each(function () {
			var $row = $(this);
			var match = showScope && $row.data('applies-to') === appliesTo;
			$row.toggle(match);
			$row.find(':input').prop('disabled', !match);
		});
	}

	function toggleApplicabilityMetaboxes() {
		var hide = isChangeGroup();
		$('#wwp-dr-applicable-roles, #wwp-dr-applicable-groups, #wwp-dr-applicable-customers, #wwp-dr-applicable-products').each(function () {
			$(this).toggle(!hide);
		});

		// Also toggle inner wrappers used on first paint.
		$('.wwp-dr-applicable-roles, .wwp-dr-applicable-groups, .wwp-dr-applicable-customers, .wwp-dr-applicable-products').toggle(!hide);
	}

	function toggleAllRoles() {
		var all = $('#wwp_dr_apply_all_roles').is(':checked');
		var $list = $('.wwp-dr-roles-list');
		$list.css({ opacity: all ? 0.5 : 1, pointerEvents: all ? 'none' : 'auto' });
		$list.find('.wwp-dr-role-checkbox').prop('disabled', all);
		updateSummary();
		scheduleApplicableProductsRefresh();
	}

	function toggleAllGroups() {
		var all = $('#wwp_dr_apply_all_groups').is(':checked');
		var $list = $('.wwp-dr-groups-list');
		$list.css({ opacity: all ? 0.5 : 1, pointerEvents: all ? 'none' : 'auto' });
		// Do not disable inputs — disabled checkboxes are omitted from POST and wipe selections.
		updateSummary();
		scheduleApplicableProductsRefresh();
	}

	function formatAppliesToSummary() {
		if (isChangeGroup()) {
			var condition = $('#wwp_dr_condition').val();
			return conditionLabels[condition] || '—';
		}

		var appliesTo = $('#wwp_dr_applies_to').val() || 'all_products';

		if (appliesTo === 'specific_products') {
			var productCount = $('#wwp_dr_products').val();
			productCount = productCount ? productCount.length : 0;
			if (productCount > 0) {
				return productCount === 1
					? '1 product'
					: productCount + ' products';
			}
		}

		if (appliesTo === 'specific_categories') {
			var catCount = $('#wwp_dr_categories').val();
			catCount = catCount ? catCount.length : 0;
			if (catCount > 0) {
				return catCount === 1
					? '1 category'
					: catCount + ' categories';
			}
		}

		return appliesToLabels[appliesTo] || '—';
	}

	function formatRolesSummary() {
		if (isChangeGroup()) {
			return '—';
		}

		if ($('#wwp_dr_apply_all_roles').is(':checked')) {
			return i18n.allWholesaleRoles || 'All wholesale roles';
		}

		var checked = $('.wwp-dr-role-checkbox:checked');
		if (!checked.length) {
			return '—';
		}

		return checked.map(function () {
			return $(this).closest('p').find('label span').last().text();
		}).get().join(', ');
	}

	function formatGroupsSummary() {
		if (!groupsEnabled) {
			return '—';
		}

		if (isChangeGroup()) {
			var $from = $('#wwp_dr_applies_to_groups option:selected');
			var fromLabels = $from.map(function () {
				return $.trim($(this).text());
			}).get().filter(Boolean);
			var toVal = $('#wwp_dr_move_to_group').val();
			var toLabel = (toVal && toVal !== '0')
				? $.trim($('#wwp_dr_move_to_group option:selected').text())
				: '';

			if (!fromLabels.length && !toLabel) {
				return '—';
			}
			if (!toLabel) {
				return fromLabels.join(', ');
			}
			if (!fromLabels.length) {
				return toLabel;
			}
			return fromLabels.join(', ') + ' → ' + toLabel;
		}

		if ($('#wwp_dr_apply_all_groups').is(':checked')) {
			return i18n.allGroups || 'All groups';
		}

		var checked = $('.wwp-dr-group-checkbox:checked');
		if (!checked.length) {
			return '—';
		}

		return checked.map(function () {
			return $(this).closest('p').find('label span').last().text();
		}).get().join(', ');
	}

	function formatCustomersSummary() {
		if (isChangeGroup()) {
			return '—';
		}

		var parts = [];
		if ($('#wwp_dr_b2c_customer').is(':checked')) {
			parts.push(i18n.b2c || 'B2C (retail)');
		}
		if ($('#wwp_dr_guest_users').is(':checked')) {
			parts.push(i18n.guests || 'Guest users');
		}

		return parts.length ? parts.join(', ') : '—';
	}

	function formatSpecificUsersSummary() {
		if (isChangeGroup()) {
			return i18n.all || 'All';
		}

		var $users = $('#wwp_dr_specific_users');
		var selected = $users.find('option:selected');
		if (!selected.length) {
			return i18n.all || 'All';
		}

		return selected.map(function () {
			return $(this).text();
		}).get().join(', ');
	}

	function updateSummary() {
		var type = getRuleType();
		var values = {
			type: type || '—',
			applies_to: formatAppliesToSummary(),
			roles: formatRolesSummary(),
			groups: formatGroupsSummary(),
			customers: formatCustomersSummary(),
			specific_users: formatSpecificUsersSummary()
		};

		$.each(values, function (key, value) {
			$('#wwp-dr-summary .wwp-dr-summary-value[data-summary-key="' + key + '"]').text(value);
		});
	}

	function requireTitle() {
		$('#post').on('submit', function (e) {
			var title = $('#title').val();
			if (!title || !$.trim(title)) {
				e.preventDefault();
				$('#title').focus();
				window.alert(i18n.titleRequired || 'Rule title is required.');
				return false;
			}
		});
	}

	function getApplicableProductsRoot() {
		return $('#wwp-dr-applicable-products .wwp-dr-applicable-products');
	}

	function setPreviewLoading(isLoading) {
		var $root = getApplicableProductsRoot();
		if (!$root.length) {
			return;
		}

		$root.toggleClass('is-loading', !!isLoading);
		$root.find('.wwp-dr-ap-loading-label').toggle(!!isLoading);
		$root.find('.wwp-dr-ap-loader').attr('aria-busy', isLoading ? 'true' : 'false');
	}

	function renderApplicableProducts(data) {
		var $root = getApplicableProductsRoot();
		if (!$root.length) {
			return;
		}

		var $list = $root.find('.wwp-dr-ap-list');
		var $note = $root.find('.wwp-dr-ap-note');
		var $empty = $root.find('.wwp-dr-ap-empty');
		var $error = $root.find('.wwp-dr-ap-error');
		var $total = $root.find('.wwp-dr-ap-total');

		$error.hide().text('');
		$list.empty();

		if (!data || data.supported === false) {
			$total.text('0');
			$note.hide().text('');
			$empty.show().text((data && data.note) || i18n.unsupportedRule || '');
			return;
		}

		if (data.is_all) {
			$total.text(i18n.all || 'All');
			$note.hide().text('');
			$empty.show().text(i18n.allProducts || 'All products');
			return;
		}

		var total = typeof data.total === 'number' ? data.total : 0;
		var products = $.isArray(data.products) ? data.products : [];

		$total.text(String(total));

		if (data.note) {
			$note.show().text(data.note);
		} else {
			$note.hide().text('');
		}

		if (!products.length) {
			$note.hide().text('');
			$empty.show().text(data.note || i18n.noProducts || 'No products match.');
			return;
		}

		$empty.hide().text('');

		$.each(products, function (_i, product) {
			var name = product.name || ('#' + product.id);
			var $li = $('<li/>').css({
				padding: '8px 10px',
				borderBottom: '1px solid #f0f0f1',
				margin: 0
			});

			if (product.edit_url) {
				$('<a/>')
					.attr('href', product.edit_url)
					.attr('target', '_blank')
					.attr('rel', 'noopener noreferrer')
					.text(name)
					.appendTo($li);
			} else {
				$li.text(name);
			}

			$('<span/>')
				.css({ color: '#646970', marginLeft: '6px', fontSize: '12px' })
				.text('#' + product.id)
				.appendTo($li);

			$list.append($li);
		});
	}

	function showPreviewError(message) {
		var $root = getApplicableProductsRoot();
		if (!$root.length) {
			return;
		}
		$root.find('.wwp-dr-ap-error').show().text(message || i18n.previewFailed || 'Could not refresh applicable products.');
		$root.find('.wwp-dr-ap-empty').hide();
	}

	function collectRuleFormData() {
		var formQuery = '';
		var $post = $('#post');
		if ($post.length) {
			formQuery = $post.serialize();
		}

		var extras = $.param({
			action: applicableProductsCfg.action || 'wwp_dynamic_rule_applicable_products',
			nonce: applicableProductsCfg.nonce || ''
		});

		return formQuery ? (formQuery + '&' + extras) : extras;
	}

	function refreshApplicableProducts() {
		var $root = getApplicableProductsRoot();
		if (!$root.length) {
			return;
		}

		if (isChangeGroup()) {
			renderApplicableProducts({
				supported: false,
				total: 0,
				products: [],
				note: i18n.unsupportedRule || ''
			});
			return;
		}

		if (!applicableProductsCfg.nonce) {
			return;
		}

		if (previewXhr && previewXhr.readyState !== 4) {
			previewXhr.abort();
		}

		var requestId = ++previewRequestId;
		setPreviewLoading(true);

		previewXhr = $.ajax({
			url: params.ajaxUrl || (window.ajaxurl || ''),
			type: 'POST',
			dataType: 'json',
			data: collectRuleFormData()
		}).done(function (response) {
			if (requestId !== previewRequestId) {
				return;
			}
			if (response && response.success && response.data) {
				renderApplicableProducts(response.data);
			} else {
				var message = (response && response.data && response.data.message)
					? response.data.message
					: (i18n.previewFailed || 'Could not refresh applicable products.');
				showPreviewError(message);
			}
		}).fail(function (xhr, status) {
			if (requestId !== previewRequestId || status === 'abort') {
				return;
			}
			showPreviewError(i18n.previewFailed || 'Could not refresh applicable products.');
		}).always(function () {
			if (requestId === previewRequestId) {
				setPreviewLoading(false);
			}
		});
	}

	function scheduleApplicableProductsRefresh() {
		if (previewTimer) {
			window.clearTimeout(previewTimer);
		}
		previewTimer = window.setTimeout(refreshApplicableProducts, 350);
	}

	function bindEvents() {
		$(document.body).on('change', '#wwp_dr_rule_type', toggleRuleTypeFields);
		$(document.body).on('change', '#wwp_dr_applies_to', function () {
			toggleAppliesToFields();
			updateSummary();
			scheduleApplicableProductsRefresh();
		});
		$(document.body).on('change', '#wwp_dr_apply_all_roles', toggleAllRoles);
		$(document.body).on('change', '#wwp_dr_apply_all_groups', toggleAllGroups);

		$(document.body).on(
			'change',
			'#wwp_dr_condition, #wwp_dr_move_to_group, #wwp_dr_applies_to_groups, #wwp_dr_products, #wwp_dr_categories, #wwp_dr_specific_users, .wwp-dr-role-checkbox, .wwp-dr-group-checkbox, #wwp_dr_b2c_customer, #wwp_dr_guest_users',
			function () {
				toggleThresholdSuffix();
				updateSummary();
				scheduleApplicableProductsRefresh();
			}
		);

		// Select2 / enhanced select change events.
		$(document.body).on(
			'change select2:select select2:unselect',
			'#wwp_dr_products, #wwp_dr_categories, #wwp_dr_specific_users, #wwp_dr_applies_to_groups',
			function () {
				updateSummary();
				scheduleApplicableProductsRefresh();
			}
		);
	}

	$(function () {
		if (!$('#wwp_dr_rule_type').length) {
			return;
		}

		bindEvents();
		requireTitle();
		toggleRuleTypeFields();
		toggleAllRoles();
		toggleAllGroups();
		toggleThresholdSuffix();
		updateSummary();
		scheduleApplicableProductsRefresh();
	});
})(jQuery);
