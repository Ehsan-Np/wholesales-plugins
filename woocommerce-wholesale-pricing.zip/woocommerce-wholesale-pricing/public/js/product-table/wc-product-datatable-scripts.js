var wcbp = [];
jQuery(
	function ($) {
		$( document ).ready(
			function () {
				$( '.product-table' ).each(
					function (index) {
						var current_table          = $( this ),
						table_id               = current_table.data( 'id' ),
						hidden_col_ids         = current_table.data( 'hidden-col-ids' ),
						search                 = current_table.data( 'search' ),
						search_term            = current_table.attr( 'data-search-term' ) || '',
						filter                 = current_table.data( 'filter' ),
						column_width           = [],
						rows_per_page          = 10,
						default_sort_col       = 0,
						default_sort_dir       = "asc",
						hidden_col_mobile_ids  = current_table.data( 'hidden-col-mob-ids' ),
						hidden_col_tab_ids     = current_table.data( 'hidden-col-tab-ids' ),
						use_column_breakpts    = 'yes' === current_table.data( 'column_breakpts' ),
						paging_type            = current_table.data( 'paging-type' ),
						empty_message          = current_table.find( '.wcpt-no-product-message' ).val(),
						display_page_length    = current_table.data( 'display-page-length' ),
						display_product_totals = current_table.data( 'display-product-totals' ),
						display_pagination     = current_table.data( 'display-pagination' ),
						wcpt_scroll            = current_table.data( 'scroll-offset' );
						wcpt_scroll                = parseInt( wcpt_scroll );

						function parse_column_id_list( value ) {
							if ( value === undefined || value === null || value === '' ) {
								return [];
							}

							if ( Array.isArray( value ) ) {
								return value.map( Number ).filter( function ( id ) {
									return ! isNaN( id );
								} );
							}

							return String( value ).split( ',' ).map( Number ).filter( function ( id ) {
								return ! isNaN( id );
							} );
						}

						hidden_col_ids        = parse_column_id_list( hidden_col_ids );
						hidden_col_mobile_ids = parse_column_id_list( hidden_col_mobile_ids );
						hidden_col_tab_ids    = parse_column_id_list( hidden_col_tab_ids );

						// prepae datable parameters
						var datatable_params = {
							processing: true,
							serverSide: true,
							responsive: true,
							lengthMenu: [10, 20, 50],
							columnDefs: [],
						}

						if (empty_message !== 'undefined') {
							datatable_params.language = {
								emptyTable: empty_message
							}
						}

						if ( hidden_col_ids.length > 0 ) {
							datatable_params.columnDefs.push(
								{
									responsivePriority: 10001,
									targets: hidden_col_ids
								}
							);
						}

						function apply_breakpoint_column_visibility( dt ) {
							if ( ! use_column_breakpts ) {
								return;
							}

							var width       = $( window ).width();
							var visible_ids = null;

							if ( width <= 480 && hidden_col_mobile_ids.length > 0 ) {
								visible_ids = hidden_col_mobile_ids;
							} else if ( width <= 768 && width > 480 && hidden_col_tab_ids.length > 0 ) {
								visible_ids = hidden_col_tab_ids;
							}

							dt.columns().every(
								function ( index ) {
									if ( null === visible_ids ) {
										this.visible( true );
										return;
									}

									this.visible( visible_ids.indexOf( index ) !== -1 );
								}
							);
						}

						function init_search_clear_control( table ) {
							if ( search !== 'yes' ) {
								return;
							}

							var wrapper     = current_table.closest( '.dataTables_wrapper' ),
							filter_wrap = wrapper.find( '.dataTables_filter' ),
							search_input = filter_wrap.find( 'input[type="search"]' );

							if ( ! search_input.length ) {
								return;
							}

							var clear_class = 'wcpt-search-clear',
							$clear_btn  = filter_wrap.find( '.' + clear_class );

							if ( ! $clear_btn.length ) {
								filter_wrap.css( 'position', 'relative' );
								search_input.css( 'padding-right', '28px' );

								$clear_btn = $( '<button type="button" class="' + clear_class + '" aria-label="Clear search" title="Clear search">&times;</button>' );
								$clear_btn.css(
									{
										position: 'absolute',
										right: '4px',
										top: '50%',
										transform: 'translateY(-50%)',
										border: 'none',
										background: 'transparent',
										cursor: 'pointer',
										fontSize: '18px',
										lineHeight: '1',
										padding: '0 4px',
									}
								);
								filter_wrap.append( $clear_btn );
							}

							function toggle_clear_button() {
								$clear_btn.toggle( search_input.val().length > 0 );
							}

							toggle_clear_button();

							search_input.off( '.wcptSearchClear' + table_id ).on(
								'input.wcptSearchClear' + table_id + ' keyup.wcptSearchClear' + table_id + ' change.wcptSearchClear' + table_id,
								function () {
									toggle_clear_button();
								}
							);

							$clear_btn.off( '.wcptSearchClear' + table_id ).on(
								'click.wcptSearchClear' + table_id,
								function (e) {
									e.preventDefault();
									search_input.val( '' );
									table.clearPipeline();
									table.search( '' ).draw();
									toggle_clear_button();
								}
							);
						}
						// set number of rows in datatable
						if (current_table.data( 'rows' )) {
							rows_per_page = current_table.data( 'rows' );
						}
						
						/**
						 * animate to table top on pagination
						 */
						$( current_table ).on(
							"page.dt",
							function () {
								var wcpt_scroll   = parseFloat( current_table.data( 'scroll-offset' ) );
								var targer_offset = $( current_table ).offset().top - wcpt_scroll;
								$( "html,body" ).animate( {scrollTop: targer_offset}, "slow" );
							}
							);
						// ajax to load woocommerce product data
						var ajax_data = {
							table_id: table_id,
							nonce:product_table_params.nonce,
							action: 'wcpt_load_products',
						};

						if (filter === 1) {
							var filters_id = [];
							$( '#select-filter-' + table_id + ' select' ).each(
								function () {
									var all_filters = $( this );
									all_filters.val( '' );
									filters_id.push( all_filters.attr( 'id' ) );
								}
								);
							$( '#select-filter-' + table_id + ' input[type=number]' ).each(
								function () {
									var all_filters = $( this );
									all_filters.val( '' );
									filters_id.push( all_filters.attr( 'id' ) );
								}
								);

							ajax_data['filters'] = function () {
								var val = [];
								filters_id.map(
									function (i, e) {
										val.push(
										{
											key: i,
											value: $( '#' + i ).val()
										}
										);
									}
									);
								return JSON.stringify( val );
							};

						}
						// set column width
						if (current_table.find( 'thead' ).length > 0) {
							current_table.find( "thead tr th" ).each(
								function (index) {
									if ($( this ).data( 'width' )) {
										column_width.push(
										{
											width: $( this ).data( 'width' ),
											targets: index
										}
										);
									}
								}
								);
							if (column_width.length > 0) {
								datatable_params.autoWidth = false;
							}
						}
						// default sort column
						if (current_table.find( "thead" ).data( 'sort_col' )) {
							default_sort_col = current_table.find( "thead" ).data( 'sort_col' );
						}
						if (current_table.find( "thead" ).data( 'sort_dir' )) {
							default_sort_dir = current_table.find( "thead" ).data( 'sort_dir' );
						}
						// set number of rows per page
						datatable_params.pageLength = rows_per_page;
						// set default sort column
						datatable_params.order              = [[default_sort_col, default_sort_dir]];
						datatable_params.pagingType = paging_type;
						datatable_params.columnDefs.push( column_width, {targets: 'no-sort', orderable: false} );
						datatable_params.dom     = 'Bfrltip';
						datatable_params.buttons = [
						{
							text: 'show all <span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span>',
							action: function (e, dt, node, config) {
								if ($( window ).width() <= 768 && $( window ).width() > 480 && typeof hidden_col_tab_ids !== 'undefined') {
									dt.columns().every(
										function () {
											if ( ! hidden_col_tab_ids.includes( this.index() )) {
												this.visible( ! this.visible() );
											}
										}
										)
								}
								if ($( window ).width() <= 480 && typeof hidden_col_mobile_ids != 'undefined') {
									dt.columns().every(
										function () {
											if ( ! hidden_col_mobile_ids.includes( this.index() )) {
												this.visible( ! this.visible() );
											}
										}
										)
								}

							},
							available: function (dt, config) {
								return 768 > $( window ).width() && $( window ).width() >= 320 && (typeof hidden_col_tab_ids !== 'undefined' || typeof hidden_col_mobile_ids != 'undefined');
							}
						},
						];

						if (display_pagination == 'yes') {
							datatable_params.paging = false;
							var custom_pages = '9999';
						} else {
							var custom_pages = '9999';
						}
						if (display_page_length == 'yes') {
							datatable_params.lengthChange = false;
						}

						if (display_product_totals == 'yes') {
							datatable_params.info = false;
						}
						if (search === 'yes') {
							datatable_params.searching = true;
							datatable_params.oSearch = {
								sSearch: String( search_term || '' ),
								bRegex: false,
								bSmart: true,
								bCaseInsensitive: true,
							};
						}

						datatable_params.ajax         = 
						{
							url: product_table_params.ajax_url,
							data: ajax_data,
							type: "POST",
							pages: custom_pages,
						};
						
						datatable_params.drawCallback = function (settings) {
							apply_breakpoint_column_visibility( current_table.DataTable() );

							if ( current_table.DataTable().responsive ) {
								current_table.DataTable().responsive.recalc();
							}

							// hidde qantity and add to cat button according to woocommerce settings
							current_table.find( ".product-cart-chechbox-wrapper.hide-quantity" ).each(
								function (index) {
									$( this ).find( '.quantity' ).hide();
								}
								);
							current_table.find( ".product-cart-chechbox-wrapper.hide-submit-btn" ).each(
								function (index) {
									$( this ).find( '.single_add_to_cart_button' ).hide();
								}
								);
							// apply product variations functions
							if (typeof wc_add_to_cart_variation_params !== 'undefined') {
								current_table.find( '.variations_form' ).each(
									function () {
										$( this ).wc_variation_form();
									}
									);
								current_table.find( '.variable-product-add-cart .variation_id' ).each(
									function () {
										enable_disable_varitaion_buttons( $( this ) );
									}
									)
							}
							// load variation change price
							
							jQuery( "input.variation_id" ).change(function() {

								load_variation_total_price();
							});
							load_variation_total_price();
							
							
						}
						var table = current_table.DataTable( datatable_params );

						apply_breakpoint_column_visibility( table );

						if ( table.responsive ) {
							table.responsive.recalc();
						}

						init_search_clear_control( table );

						$( window ).on(
							'resize.wcptResponsive' + table_id,
							function () {
								apply_breakpoint_column_visibility( table );

								if ( table.responsive ) {
									table.responsive.recalc();
								}
							}
						);

						if ((filter === 1) && ($( '#select-filter-' + table_id ).data( 'col-filter' ) == 'load_archive')) {
							$( '#select-filter-' + table_id ).find( '.filter-attr' ).bind(
								"change",
								function () {
									if ($( this ).data( 'filter-link' ) === '') {
										var sel = $( this ).find( ':selected' );
										if (sel.data( 'tax-link' )) {
											window.location.href = sel.data( 'tax-link' );
										}
									} else {
										table.ajax.reload();
										table.clearPipeline().draw();
									}
								}
								);
						}

						$('#select-filter-' + table_id).find('.min-filter-attr').on('input', function () {
							var maxValue = parseInt($(this).attr('max'));
							var minValue = parseInt($(this).attr('min'));
							var enteredValue = parseInt($(this).val());

							if (enteredValue > maxValue) {
								$(this).val(maxValue);
							}
							if (enteredValue < minValue) {
								$(this).val(minValue);
							}

							table.ajax.reload();
							table.clearPipeline().draw();
						});
						$('#select-filter-' + table_id).find('#fromSlider').on('mouseup', function () {
							table.ajax.reload();
							table.clearPipeline().draw();
						});
						$('#select-filter-' + table_id).find('#toSlider').on('mouseup', function () {
							table.ajax.reload();
							table.clearPipeline().draw();
						});
						
						$( '#select-filter-' + table_id ).find('.max-filter-attr').on('input', function () {
							var maxValue = parseInt($(this).attr('max'));
							var minValue = parseInt($(this).attr('min'));
							var enteredValue = parseInt($(this).val());

							if (enteredValue > maxValue) {
								$(this).val(maxValue);
							}
							if (enteredValue < minValue) {
								$(this).val(minValue);
							}
							table.ajax.reload();
							table.clearPipeline().draw();
						});

						// reset filter button
						$( '#select-filter-' + table_id ).find( '.reset-filters' ).on(
							"click",
							function (e) {
								e.preventDefault();
								$( '.filter-attr' ).each(
									function () {
										$( this ).val( '' );
									}
									);

								 // Reset sliders to default min/max
								let fromSlider = $('#fromSlider');
								let toSlider   = $('#toSlider');
								if (fromSlider.length && toSlider.length) {
									fromSlider.val(fromSlider.attr('min'));
									toSlider.val(toSlider.attr('max'));
									updateSliderBackground(fromSlider[0], toSlider[0]);
								}

								// First trigger input events (for gradient, table refresh, etc.)
								fromSlider.trigger('input');
								toSlider.trigger('input');

								// Finally clear inputs
								$('.min-filter-attr').val('');
								$('.max-filter-attr').val('');


								table.ajax.reload();
								// console.log(table.clearPipeline().draw());
								table.clearPipeline().draw();
							}
							);

						if ((filter === 1) && ($( '#select-filter-' + table_id ).data( 'col-filter' ) == 'perform_filter')) {
							$( '#select-filter-' + table_id ).find( '.filter-attr' ).bind(
								"change",
								function () {
									table.ajax.reload();
									table.clearPipeline().draw();
								}
								);
						}

						table.on(
							'responsive-display',
							function (e, datatable, row, showHide, update) {
								if (row.child()) {
									row.child().find( '.variations_form' ).each(
										function () {
											$( this ).wc_variation_form();
											enable_disable_varitaion_buttons( $( this ).find( '.variation_id' ) );
										}
										);
									// hidde qantity and add to cat button according to woocommerce settings
									if ($( this ).find( ".product-cart-chechbox-wrapper.hide-quantity" ).length > 0) {
										$( this ).find( '.quantity' ).hide();
									}
									if ($( this ).find( ".product-cart-chechbox-wrapper.hide-submit-btn" ).length > 0) {
										$( this ).find( '.single_add_to_cart_button' ).hide();
									}
								}
							}
							);
					}
					);

					// Helper to update gradient
					function updateSliderBackground(fromSlider, toSlider) {
					    const min = parseInt(fromSlider.min);
					    const max = parseInt(toSlider.max);

					    const from = parseInt(fromSlider.value);
					    const to = parseInt(toSlider.value);

					    const percent1 = ((from - min) / (max - min)) * 100;
					    const percent2 = ((to - min) / (max - min)) * 100;

					    toSlider.style.background = `linear-gradient(to right, #c6c6c6 ${percent1}%,
					        #733d80 ${percent1}%, #733d80 ${percent2}%, #c6c6c6 ${percent2}%)`;
					}

jQuery(document).on("click", ".quick_view_btn", function (a) {
	a.preventDefault();
	var current_button = jQuery(this);
	if (!current_button.hasClass("loading")) {
		current_button.addClass("loading");
		var prod_id = jQuery(this).attr("data-id");

		jQuery.post({
			type: "POST",
			url: product_table_params.ajax_url,
			dataType: "json",
			data: { action: "wcpt_popup_content", productId: prod_id, nonce: product_table_params.nonce },
			success: function (response) {
		
				current_button.removeClass("loading"),
				jQuery("html body").css("overflow", "hidden");
				jQuery("#popup_quickview").html(response.fragments);
									// jQuery(".modal-overlay").fadeIn(),
									// jQuery(".wcpt_popup_quickview_content_wrapper").fadeIn();
				jQuery("#popup_quickview").show();

				if ( 'bundle_product' == response.productType ) {
					wcbp = response.wcbp_bundle;
					jQuery.getScript( response.wcbp_url, function( data, textStatus, jqxhr ) {});
				}

				if ( 'variable' == response.productType && 'undefined' != typeof wc_add_to_cart_variation_params) {
					jQuery(".variable_form_wrapper .variations_form").each(function () {
						jQuery(this).wc_variation_form();
					});
				}

				
				if(jQuery('#wtp-tier-data').length){
					if ($("#popup_quickview").is(":visible")) {

						
						// Remove display:none from the tier data container
						$('#popup_quickview #wtp-discount-list-container').show();
						$('#popup_quickview #wtp-tier-data').removeClass('wtp-hide');
						
						if(jQuery('.wcpt_popup_quickview_content_wrapper .variable_form_wrapper').length >= 1){
							$('#popup_quickview #wtp-tier-data').addClass('wtp-hide');

							jQuery( ".single_variation_wrap" ).on( "show_variation", function ( event, variation ) {
								$('#popup_quickview #wtp-discount-list-container').show();
								$('#popup_quickview .wtp-summary').show();

								$('#popup_quickview #wtp-tier-data').removeClass('wtp-hide');
							});
						}

		
						qty = jQuery('.wcpt_quick_view_cart').find('div.quantity .qty').val();
						
						if(jQuery('.wcpt_popup_quickview_content_wrapper .variable_form_wrapper').is(":visible")){
							qty =  jQuery( '.variable_form_wrapper div.quantity .qty' ).val();
						}
					
						if (typeof qty === 'undefined') {
							return;
						}
						
						check_qty_level( qty );
					
					} else {
						$('#popup_quickview #wtp-discount-list-container').hide();
						$('#popup_quickview #wtp-tier-data').addClass('wtp-hide');
					}
				}
      
			},
			error: function (t, a) {},
		});
	}
}),

jQuery(document).on("click", ".close-wcpt-modal", function (t) {
	jQuery(".modal-overlay").fadeOut(), jQuery(".wcpt_popup_quickview_content_wrapper").fadeOut();
	jQuery("html body").css("overflow", "unset");
}),
jQuery(document).on("click", function (a) {
	jQuery(a.target).closest("#popup_quickview").length > 0 || jQuery(a.target).closest(".quick_view_btn").length > 0 || (jQuery(".modal-overlay").fadeOut(), jQuery(".wcpt_popup_quickview_content_wrapper").fadeOut(),jQuery("html body").css("overflow", "unset"));
}),


$( document ).on(
	'submit',
	'.product-cart-wrapper form.cart',
	function (e) {
		e.preventDefault();
		var current_button   = $( this ).find('button[type="submit"]:not(.disabled)'),
		product_id       = false,
		onepagecheckout = jQuery(".one_page_check").val();
		
		// Check for selected quantity button first (for box display type)
		var $selectedQtyButton = current_button.closest( '.product-cart-wrapper' ).find( '.pqy-quantity-button.selected' );
		if ( $selectedQtyButton.length ) {
			product_quantity = $selectedQtyButton.data('quantity') || $selectedQtyButton.attr('data-quantity');
		} else {
			// Fallback to quantity input
			product_quantity = current_button.closest( '.product-cart-wrapper' ).find( '.quantity .qty' ).val();
		}
		
		current_button.closest( '.product-table-wrap' ).find( '.product-table-loader' ).show();
						// get product id for variation product
		if (current_button.closest( '.variable-product-add-cart' ).length > 0) {
			product_id = current_button.closest( '.product-cart-wrapper' ).find( '.variation_id' ).val();
		} else {
			product_id = current_button.val();
		}

		if (product_id) {
			nyc_price = $( this ).closest( '.product-cart-chechbox-wrapper' ).find( '.nyp-input' ).val();
			var formData = $(':not(input[type=hidden])',this).serialize();
			
			// Check if using quantity buttons (box display type)
			var $qtyButtons = current_button.closest( '.product-cart-wrapper' ).find('.pqy-quantity-buttons-wrapper, .pqy-boxes-product');
			var hasQtyButtons = $qtyButtons.length > 0;
			
			// compatible with product quantity
			if ( ( current_button.closest( '.product-cart-wrapper' ).find('.pqy-fixed-quantity').length > 0 || 
			       current_button.closest( '.product-cart-wrapper' ).find('.pqy-default-quantity-buttons').length > 0 || 
			       current_button.closest( '.product-cart-wrapper' ).find('.pqy-default-quantity-buttons-variation').length > 0 ||
			       current_button.closest( '.product-cart-wrapper' ).find('.pqy-step-quantity-buttons').length > 0 ||
			       current_button.closest( '.product-cart-wrapper' ).find('.pqy-step-quantity-buttons-variation').length > 0 ||
			       current_button.closest( '.product-cart-wrapper' ).find('.pqy-custom-quantity-buttons').length > 0 ||
			       current_button.closest( '.product-cart-wrapper' ).find('.pqy-custom-quantity-buttons-variation').length > 0 ) && 
			     ( formData == '' || current_button.closest( '.variable-product-add-cart' ).length > 0 ) ) {
				var formData = $('input[type=hidden]',this).not('[name="add-to-cart"]').serialize();
			}
			
			// Ensure quantity is included in formData when using box buttons
			if (hasQtyButtons && product_quantity) {
				// Parse formData to remove existing quantity and add the correct one
				var formDataParts = formData.split('&');
				var newFormDataParts = [];
				for (var i = 0; i < formDataParts.length; i++) {
					if (!formDataParts[i].startsWith('quantity=')) {
						newFormDataParts.push(formDataParts[i]);
					}
				}
				// Add the correct quantity
				newFormDataParts.push('quantity=' + encodeURIComponent(product_quantity));
				formData = newFormDataParts.join('&');
			}
			// Check for inventory section within the current form context to get the correct inventory fields
			// Look in the product-cart-wrapper first, then the parent table row to find the inventory section
			// This ensures we get the inventory fields for the specific product being added, not the first one on the page
			var $formContext = $(this).closest('.product-cart-wrapper');
			var $tableRow = $(this).closest('tr');
			var $inventorySection = $formContext.find('.product-inventory-section');
			
			// If not found in wrapper, check the table row (inventory might be in a different cell of the same row)
			if ( $inventorySection.length === 0 && $tableRow.length > 0 ) {
				$inventorySection = $tableRow.find('.product-inventory-section');
			}
			
			if ( $inventorySection.length > 0 && formData != '' ) {
				// Find inventory fields within the specific inventory section for this product
				// Using find() ensures we get fields from THIS product's inventory section, not the first one on the page
				var inventoryProductId = $inventorySection.find('[id="inventory_product_id"], [name="inventory_product_id"]').first().val() || '';
				var inventoryTitle = $inventorySection.find('[id="inventory_title"], [name="inventory_title"]').first().val() || '';
				var inventoryLocation = $inventorySection.find('[id="inventory_location"], [name="inventory_location"]').first().val() || '';

				// Clean inventory title to remove duplicates and trim whitespace
				if (inventoryTitle) {
					// Split by whitespace/newlines, filter out empty strings, get unique values
					var titleParts = inventoryTitle.split(/\s+/).filter(function(part) {
						return part.trim().length > 0;
					});
					// Get unique values only
					var uniqueTitleParts = [];
					var seen = {};
					for (var i = 0; i < titleParts.length; i++) {
						var part = titleParts[i].trim();
						if (part && !seen[part]) {
							seen[part] = true;
							uniqueTitleParts.push(part);
						}
					}
					inventoryTitle = uniqueTitleParts.join(' ').trim();
				}

				formData += '&inventory_product_id=' + encodeURIComponent(inventoryProductId);
				formData += '&inventory_title=' + encodeURIComponent(inventoryTitle);
				formData += '&inventory_location=' + encodeURIComponent(inventoryLocation);
			}
			var formData = formData + '&action=wcpt_add_to_cart&nyp=' + nyc_price + '&product_id=' + product_id + "&nonce=" + product_table_params.nonce;
			$.post(
				product_table_params.ajax_url,
				formData,
				function (response) {
					jQuery(".cart-drawer_right").css("right", "0");
					jQuery(".wcpt-minicart-icon").hide();
					jQuery(".cart-drawer_left").css("left", "0");
					current_button.closest( '.product-table-wrap' ).find( '.product-table-loader' ).hide();
					// window.location.reload();
					after_add_products_cart( response, current_button );
					if('yes' === onepagecheckout){
						window.location.reload();
					}
									
					reset_product_data( current_button );
				}
				);
		}

	}
	);

	$( document ).on(
		'click',
		'.widget_shopping_cart_content .remove_from_cart_button',function(e){
			var mini_counts = parseInt($('.cart-contents .count').text()) - 1 || 0;			
			setTimeout(function(){
				if(parseInt($('.cart-contents .count').text()) == 0 ){
					mini_counts = 0;
				}
				$('.mini_cart_contents_count').text(mini_counts);
			},500);
			$('.mini_cart_contents_count').text(mini_counts);
	});

	// jQuery(document.body).on('removed_from_cart', function() {
	// 	let mini_counts = parseInt(jQuery('.cart-contents .count').text()) - 1 || 0;
	// 	jQuery('.mini_cart_contents_count').text(mini_counts);
	// });

$( document ).on(
	'click',
	'.product-table-wrap .wcpt-selected-cart',
	function (e) {
		e.preventDefault();
						// simple products
		var current_button    = $( this );
		var onepagecheckout = jQuery(".one_page_check").val();
		var selected_products = current_button.closest( '.product-table-wrap' ).find( '.product-cart-chechbox-wrapper .product-cart-chechbox:checked' ),
		quantity          = '',
		product_id        = '',
		product_ids       = [],
		nyc_product_ids	  = [],
		nyp               = {},
		product_quantites = [];
		formData = {};
		groupedFormsDone    = [];

		selected_products.each(
			function (index) {

				
								// get product id for variation product
				if ($( this ).closest( '.variable-product-add-cart' ).length > 0) {
					product_id = $( this ).closest( '.variable-product-add-cart' ).find( '.variation_id' ).val();
				} else {
					product_id = $( this ).val();
				}


				if (product_id) {
					quantity = $( this ).closest( '.product-cart-chechbox-wrapper' ).find( '.quantity .qty' ).val();
					formData[product_id] = $( this ).closest( '.product-cart-chechbox-wrapper' ).find( 'form.cart' ).serialize();
					nyc_price = $( this ).closest( '.product-cart-chechbox-wrapper' ).find( '.nyp-input' ).val();
					product_ids.push( product_id );
					product_quantites.push( quantity );
					if(nyc_price){  
						nyp[product_id] = nyc_price ;
						

					}
				}
			}
			);	

			// Check if grouped product checkbox is checked
			var $groupedWrapper = current_button.closest('.product-table-wrap').find('.product-cart-wrapper');
			var $groupedCheckbox = $groupedWrapper.find('.product-cart-chechbox');

			if ($groupedCheckbox.is(':checked')) {
				let $groupedForm = $groupedWrapper.find('form.grouped_form');

				if ($groupedForm.length > 0 && !groupedFormsDone.includes($groupedForm[0])) {
					let groupedData = {};

					// Loop through selected products inside the form
					$groupedForm.find('.product-details-wrapper').each(function () {
						let productId = $(this).data('product-id');
						let qty = $(this).find('.selected-product-qty').val();

						if (productId && qty && parseInt(qty) > 0) {
							groupedData[productId] = 'quantity=' + qty;
							product_ids.push(productId);
							product_quantites.push(qty);
						}
					});

					if (Object.keys(groupedData).length > 0) {
						formData['grouped'] = groupedData;
						groupedFormsDone.push($groupedForm[0]);
					}
				}
			}


				
		if (product_id == '' && typeof formData === 'undefined' ) {
			current_button.closest( '.product-table-wrap' ).find( '.no-product-added' ).remove();
			current_button.closest( '.product-table-wrap' ).find( '.wcpt-added-products' ).remove();
			current_button.closest( '.product-table-wrap' ).find( '.added_to_cart.wc-forward' ).remove();
			current_button.closest( '.wcpt-selected-cart-wrapper' ).append( "<span class='no-product-added'>" + product_table_params.error_message + "</span>" );

		} else {
			current_button.closest( '.product-table-wrap' ).find( '.no-product-added' ).remove();
			current_button.closest( '.product-table-wrap' ).find( '.product-table-loader' ).show();


			$.post(
				product_table_params.ajax_url,
				{
					'action': 'wcpt_add_selected_products_cart',
					'product_ids': product_ids,
					'nyp_data': nyp,
					'product_quantites': product_quantites,
					'nonce': product_table_params.nonce,
					'formdata': formData
				},
				function (response) {
					current_button.closest( '.product-table-wrap' ).find( '.product-table-loader' ).hide();
					after_add_products_cart( response, current_button );
					if (response.fragments && response.fragments.wcpt_added_products) {
						if (current_button.closest( '.product-table-wrap' ).find( '.wcpt-added-products' ).length > 0) {
							current_button.closest( '.product-table-wrap' ).find( '.wcpt-added-products' ).remove();
						}
						current_button.after( response.fragments.wcpt_added_products );
						if('yes' === onepagecheckout){
							window.location.reload();
											// jQuery('html, body').animate({
											// 	scrollTop: jQuery("#wcpt_one_page_checkout").offset().top
											//   }, 1000);
											//$.cookie("reload", 0);
						}
					}

					selected_products.each(
						function (index) {
							reset_product_data( $( this ) );
							$( this ).attr( 'checked', false );
						}
						);
				}
				);
		}
	}
	);

$( document ).on(
	'change',
	'.product-cart-wrapper .variation_id',
	function (e) {
		enable_disable_varitaion_buttons( $( this ) );
	}
	);

$( document ).on(
	'change keyup',
	'.quantity-wrapper .wc-quantity',
	function () {
		$( this ).parents( 'tr' ).find( '.product-cart-chechbox-wrapper .quantity .qty' ).val( $( this ).val() );
	}
	);

}
);

function enable_disable_varitaion_buttons(variation_element) {
	if (variation_element.val() == 0 || ! variation_element.val()) {
		variation_element.closest( '.product-cart-chechbox-wrapper' ).find( '.product-cart-chechbox' ).attr( 'disabled', 'disabled' );
		variation_element.closest( '.product-cart-chechbox-wrapper' ).find( '.single_add_to_cart_button' ).addClass( 'disabled' );
		variation_element.closest( '.product-cart-chechbox-wrapper' ).find( '.product-cart-chechbox' ).attr( 'checked', false );
	} else {
		variation_element.closest( '.product-cart-chechbox-wrapper' ).find( '.product-cart-chechbox' ).removeAttr( 'disabled', 'disabled' );
		variation_element.closest( '.product-cart-chechbox-wrapper' ).find( '.single_add_to_cart_button' ).removeClass( 'disabled' );
	}
}

function reset_product_data(product_element) {
			// set quantity to min value
	var qty_field = product_element.closest( '.product-cart-chechbox-wrapper' ).find( '.quantity .qty' );
	if (qty_field.attr( 'min' )) {
		qty_field.val( qty_field.attr( 'min' ) );
	}
			// reser variatiobs
	if (product_element.closest( '.variable-product-add-cart' ).length > 0) {
		product_element.closest( '.variable-product-add-cart' ).find( '.reset_variations' ).click();
		enable_disable_varitaion_buttons( product_element.closest( '.variable-product-add-cart' ).find( '.variation_id' ) );
	}
}

function after_add_products_cart(response, current_button) {
	if ( ! response) {
		return;
	}

	if (response.error && response.product_url) {
		window.location = response.product_url;
		return;
	}

			// Redirect to cart option
	if (wc_add_to_cart_params.cart_redirect_after_add === 'yes') {
		window.location = wc_add_to_cart_params.cart_url;
		return;
	}

			// Trigger event so themes can refresh other areas.
	$( document.body ).trigger( 'added_to_cart', [response.fragments, response.cart_hash, current_button] );
}
		// Register an API method that will empty the pipelined data, forcing an Ajax
		// fetch on the next draw (i.e. `table.clearPipeline().draw()`)
$.fn.dataTable.Api.register(
	'clearPipeline()',
	function () {
		return this.iterator(
			'table',
			function (settings) {
				settings.clearCache = true;
			}
			);
	}
	);

		// price variation change and stock
function load_variation_total_price(){ 
	jQuery( '.variations_form' ).each( function() { 

		product_id = jQuery(this).attr('data-product_id');
		variation_id = jQuery(this).find('.variation_id').val();
		if( jQuery(this).find('.variation_id').val() == '' ) {
			jQuery('.price_'+product_id).hide();
			jQuery('.stock_'+product_id).html(jQuery('.stock_'+product_id).attr('data-stock') ); 
		}
	});

}

 $(document).on(
    "found_variation",
    "form.variations_form",
    function (event, variation) {
      // Get the product ID from the variation object
      let product_id = jQuery(this).attr("data-product_id");

      if (variation.display_price) {
        // Make an AJAX request to process the price change
        $.ajax({
          url: product_table_params.ajax_url,
          type: "POST",
          data: {
            action: "wcpt_get_wholesale_price",
            variation_id: variation.variation_id,
            price: variation.display_price,
            nonce: product_table_params.nonce,
          },
          success: function (response) {
            // Update the displayed price with the new wholesale price
            if (response.success) {
              jQuery(".price_" + product_id).html(
                `<hr> ${response.data.wwp_price}`
              );
              jQuery(".price_" + product_id).show();
            }
          },
        });
      }

      if (variation.availability_html) {
        // stock append
        jQuery(".stock_" + product_id).html(variation.availability_html);
        jQuery(".stock_" + product_id).show();
      }

      if (!variation.is_in_stock) {
        jQuery(this).find(".single_add_to_cart_button").addClass("disabled");
      }
    }
  );


// for wholesale minimum step quantity
jQuery(document).on('found_variation', 'form.variations_form', function(event, variation) {
	document.dispatchEvent(new CustomEvent('wholesale_quantity_variation', { detail: {data: variation, This: jQuery(this)}}));
});

if ( jQuery('.wcpt-price-range').length > 0 ){

// Function to debounce the execution of a function
	function debounce(func, delay) {
		let timeoutId;
		return function() {
			const context = this;
			const args = arguments;
			clearTimeout(timeoutId);
			timeoutId = setTimeout(() => {
				func.apply(context, args);
			}, delay);
		};
	}

	// Debounced functions for controlling from_min and to_max
	const debouncedControlFromMin = debounce((fromSlider, from_min, to_max, controlSlider) => {
		const [from, to] = getParsed(from_min, to_max);
		fillSlider(from_min, to_max, "#C6C6C6", "#733D80", controlSlider);
		fromSlider.value = from;

		if (from > to) {
			fromSlider.value = to;
			from_min.value = to;
		} else {
			fromSlider.value = from;
		}
		updateSliderPosition(fromSlider, toSlider, from_min, to_max);
	}, 1500); // Adjust the delay as needed (e.g., 1000 milliseconds)

	const debouncedControlToMax = debounce((toSlider, from_min, to_max, controlSlider) => {
		const [from, to] = getParsed(from_min, to_max);
		fillSlider(from_min, to_max, "#C6C6C6", "#733D80", controlSlider);
		setToggleAccessible(to_max);
		toSlider.value = to;

		if (to < from) {
			to_max.value = from;
		} else {
			to_max.value = to;
		}
		updateSliderPosition(fromSlider, toSlider, from_min, to_max);
	}, 1500); // Adjust the delay as needed (e.g., 1000 milliseconds)

	function updateSliderPosition(fromSlider, toSlider, from_min, to_max) {
		const [from, to] = getParsed(from_min, to_max);
		fillSlider(from_min, to_max, "#C6C6C6", "#733D80", toSlider);

		// Set the slider positions
		fromSlider.value = from;
		toSlider.value = to;
	}

	function controlfrom_min(fromSlider, from_min, to_max, controlSlider) {
		debouncedControlFromMin(fromSlider, from_min, to_max, controlSlider);
	}

	function controlto_max(toSlider, from_min, to_max, controlSlider) {
		debouncedControlToMax(toSlider, from_min, to_max, controlSlider);
	}


	function controlFromSlider(fromSlider, toSlider, from_min) {
		const [from, to] = getParsed(fromSlider, toSlider);
		
		fillSlider(fromSlider, toSlider, "#C6C6C6", "#733D80", toSlider);
		from_min.value = from;
		
		if (from > to) {
			from_min.value = to;
			to_max.value = from;
		}
	}




		// Sliding event of the To slider
	function controlToSlider(fromSlider, toSlider, to_max) {
		const [from, to] = getParsed(fromSlider, toSlider);
		fillSlider(fromSlider, toSlider, "#C6C6C6", "#733D80", toSlider);
		setToggleAccessible(toSlider);
		toSlider.value = to;
		to_max.value = to;

		if (from > to) {
			from_min.value = to;
			to_max.value = from;
		}
	}

		// Parsign values of the Inputs
	function getParsed(currentFrom, currentTo) {
		const from = parseInt(currentFrom.value, 10);
		const to = parseInt(currentTo.value, 10);
		return [from, to];
	}

	// Changing and Filling the color in the selected part...
	function fillSlider(from, to, sliderColor, rangeColor, controlSlider) {
		let rangeDistance = to.max - to.min;
		let fromPosition = from.value - to.min;
		let toPosition = to.value - to.min;
		if (fromPosition > toPosition) {
			let spare = fromPosition;
			fromPosition = toPosition;
			toPosition = spare;
		}
		controlSlider.style.background = `linear-gradient(
		to right,
		${sliderColor} 0%,
		${sliderColor} ${(fromPosition / rangeDistance) * 100}%,
		${rangeColor} ${(fromPosition / rangeDistance) * 100}%,
		${rangeColor} ${(toPosition / rangeDistance) * 100}%, 
		${sliderColor} ${(toPosition / rangeDistance) * 100}%, 
		${sliderColor} 100%)`;
	}

	// Making sure the toggle which we are using is accesible to change the range
	function setToggleAccessible(currentTarget) {
		const toSlider = document.querySelector("#toSlider");
		if (Number(currentTarget.value) <= 0) {
			toSlider.style.zIndex = 2;
		} else {
			toSlider.style.zIndex = 0;
		}
	}

	const fromSlider = document.querySelector("#fromSlider");
	const toSlider = document.querySelector("#toSlider");
	const from_min = document.querySelector("#from_min");
	const to_max = document.querySelector("#to_max");

	// Initially filling the slider using default values...
	fillSlider(fromSlider, toSlider, "#C6C6C6", "#733D80", toSlider);
	setToggleAccessible(toSlider);

	// Assigning listner methonds to respective events.
	fromSlider.oninput = () => controlFromSlider(fromSlider, toSlider, from_min);
	toSlider.oninput = () => controlToSlider(fromSlider, toSlider, to_max);
	from_min.oninput = () =>
	controlfrom_min(fromSlider, from_min, to_max, toSlider);
	to_max.oninput = () => controlto_max(toSlider, from_min, to_max, toSlider);
}

jQuery(document).on('wholesale_quantity_variation', function(event) {
	setTimeout(function() {
		var variation = event.detail.data;
		var This = event.detail.This;
		console.log(This);
		if (variation.is_wholesale == true ) {

			if ( variation.step ) {

				jQuery(This).find('.qty').attr( 'step', variation.step );
				jQuery(This).find('.qty').attr( 'min', variation.input_value );
			} 
			else {
				jQuery(This).find('.qty').attr( 'step', 1 );
				jQuery(This).find('.qty').attr( 'min', 1 );
			}

			if ( variation.input_value ) {
				jQuery(This).find('.qty').val( variation.input_value );
			}
		}
	}, 500);

});



jQuery(document).on("click", ".product-table-expandable", function (a) {
	a.preventDefault();
	var prod_id = jQuery(this).attr("data-id");
	jQuery('.loader-icon_' + prod_id).show();

	jQuery.ajax({
		type: "POST",
		url: product_table_params.ajax_url, 
		data: {
			action: 'get_product_image',
			product_id: prod_id
		},
		success: function(response) {
			jQuery('.loader-icon_' + prod_id).hide();
			jQuery(".popupContainer img").attr("src", response);
			jQuery(".popupContainer").show();
		}
	});
});


jQuery(document).on('click',function() {
	jQuery(".popupContainer").hide();
});

jQuery(document).on('click','.closePopup', function() {
	jQuery(".popupContainer").hide();
});


jQuery('.wcpt-minicart-icon').appendTo('#ptholder');
jQuery('#ptholder').css('position', 'relative');

jQuery(".wcpt-minicart-icon_right").click(function () {
	jQuery(".cart-drawer_right").css("right", "0");
	// jQuery(".wcpt-minicart-icon").hide();

});

jQuery(".wcpt-minicart-icon").click(function () {
	jQuery(".wcpt-minicart-icon").hide();

});

jQuery(".wcpt-minicart-icon_left").click(function () {
	jQuery(".cart-drawer_left").css("left", "0");
});

jQuery(document).on("click", function (event) {
	if (!jQuery(event.target).closest(".cart-drawer, .wcpt-minicart-icon_left").length) {
		// jQuery(".cart-drawer_left").css("left", "-410px");
		// jQuery(".wcpt-minicart-icon_left").show();
	}
});

jQuery(document).on("click", function (event) {
	if (!jQuery(event.target).closest(".cart-drawer, .wcpt-minicart-icon_right").length) {
		jQuery(".cart-drawer_right").css("right", "-410px");
		jQuery(".wcpt-minicart-icon_right").show();
	}
});

jQuery(document).on('click', '.mini-cart-close', function(event) {
	event.preventDefault(); 
	jQuery(".cart-drawer_right").css("right", "-410px");
	jQuery(".cart-drawer_left").css("left", "-410px");
	jQuery(".wcpt-minicart-icon").show();

});

}
);

function check_qty_level( qty = 0 ) {

	const instance = tippy(document.getElementById('wtp-tier-data'));                    
	instance.destroy();

	if ( qty >= 0 ) {            
		jQuery( '#wtp-discount-list-container ul li' ).removeClass('wtp-selected');
		var discount_container = jQuery( '#wtp-discount-list-container ul li' );

		if(jQuery("#popup_quickview").is(":visible")){

			discount_container = jQuery('.wcpt_quick_view_cart #wtp-discount-list-container ul li');

			if(jQuery('.wcpt_popup_quickview_content_wrapper .variable_form_wrapper').is(":visible")){
				discount_container = jQuery('.wcpt_popup_quickview_content_wrapper .variable_form_wrapper .wtp-bulk-product-list ul li');
			}
		}

		

		jQuery( discount_container ).each(function() {
			var min_qty = jQuery(this).data('min');
			var max_qty = jQuery(this).data('max');
			var set_qty = jQuery(this).data('set');
			
			if( set_qty == qty ) {

				jQuery(this).addClass('wtp-selected');
				return false;
			}
			
			if ( max_qty == -1 ) {


				if ( qty >= min_qty ) {
					jQuery(this).addClass('wtp-selected');
					return false;
				}
			} else {
 
	
				if ( qty >= min_qty && qty <= max_qty ) {
					jQuery(this).addClass('wtp-selected');
					return false;
				}
			}               
		});


		if ( wtp_front_script.summary != 'none' ) {
			var price = jQuery('#wtp-discount-list-container ul li.wtp-selected').data('price');
			var type = jQuery('#wtp-discount-list-container ul li.wtp-selected').data('type');
			var data = {
				action: 'wtp_calculate_summary',
				price: price,
				qty: qty,
				type: type
			};

			jQuery.post( wtp_front_script.ajaxurl, data, function ( success ) {
				var obj = JSON.parse( success );
				
				if ( obj != '' ) {
					jQuery('.wtp-summary #wtp-unit').html( obj.price );
					jQuery('.wtp-summary #wtp-subtotal').html( obj.subtotal );
					jQuery('.wtp-summary').removeClass('wtp-hide');
				} else {
					jQuery('.wtp-summary #wtp-unit').html( '' );
					jQuery('.wtp-summary #wtp-subtotal').html( '' );
					jQuery('.wtp-summary').addClass('wtp-hide');
				}              

			});
		}
		
		//whenever you change the quantity
		tippy('#wtp-tooltip', {
			content: jQuery('#wtp-tier-data').html(),
			allowHTML: true,
		});
	}
}




jQuery(document).ready(function ($) {

    // Enable checkbox when a variation is selected
    $(document).on('found_variation', '.variations_form', function (event, variation) {
        let $wrapper = $(this).closest('.product-cart-chechbox-wrapper');
        $wrapper.data('variation_price', variation.display_price);
        $wrapper.find('.product-cart-chechbox').prop('disabled', false).trigger('change');
    });

    // Reset variation selection
    $(document).on('reset_data', '.variations_form', function () {
        let $wrapper = $(this).closest('.product-cart-chechbox-wrapper');
        $wrapper.removeData('variation_price');
        $wrapper.find('.product-cart-chechbox').prop('checked', false);
        $wrapper.find('.qty').val(1);
        $wrapper.find('.product-cart-chechbox').trigger('change');
    });

    // Enable checkbox on selecting from grouped dropdown
    $('.grouped-product-selector').on('change', function () {
        const selectedOption = $(this).find('option:selected');
        const selectedProductName = selectedOption.data('name');
        const productPriceRaw = selectedOption.data('price');

        let numericPrice = '';
        if (productPriceRaw) {
            numericPrice = productPriceRaw.replace(/[^0-9.]/g, '');
        }

        $(this).closest('.grouped_product').find('.product-cart-chechbox').prop('disabled', false).prop('checked', true).trigger('change');
        $(this).closest('.grouped_product').find('.group-product-btn').prop('disabled', false);
    });

    // Disable checkboxes for grouped and variation by default
    $('.product-cart-chechbox-wrapper').each(function () {
        let $wrapper = $(this);
        if ($wrapper.find('.variations_form').length > 0 || $wrapper.hasClass('grouped_product')) {
            $wrapper.find('.product-cart-chechbox').prop('disabled', true);
        }
    });

     // ✅ Unified remove handler for grouped product blocks
$(document).on('click', '.remove-product', function () {
    const $button = $(this);
    const $form = $button.closest('form');
    const productId = $button.data('remove-id');
    const $groupWrapper = $button.closest('.grouped_product');
    const $checkbox = $groupWrapper.find('.product-cart-chechbox');
    const $productWrapper = $button.closest('.product-details-wrapper');
    const $addToCartBtn = $form.find('.group-product-btn');

    // Remove product block from DOM
    $productWrapper.remove();

    // Remove product row by ID (if needed)
    $form.find('[data-product-id="' + productId + '"]').remove();

    // Disable checkbox if no products left
    if ($groupWrapper.find('.product-details-wrapper').length === 0) {
        $checkbox.prop('checked', false).trigger('change');
    }

    // Disable Add to Cart button if no products
    if ($form.find('[data-product-id]').length === 0) {
        $addToCartBtn.prop('disabled', true);

        // Optionally disable the checkbox completely (if needed)
        $('.product-cart-chechbox[value="' + $form.find('.group-product-add-to-cart').val() + '"]').prop('disabled', true);
    }

    // Refresh total price
    updateTotalPrice();
});

	$('a.wcpt-selected-cart').css('pointer-events', 'none').css('opacity', '0.5');

    // Bind change on checkbox and quantity
    $(document).on('change input', '.product-cart-chechbox, .qty, .selected-product-qty', function () {
        updateTotalPrice();
    });

     // compatible with product quantity
    $(document).on( 'click button', '.pqy-quantity-button', function () {
        updateTotalPrice();
    });

    // 🔥 Single function to calculate price for all types
    function updateTotalPrice() {
        let total_price = 0;
        let total_items = 0;

        // ✅ Handle variable/simple products
        $('.product-cart-chechbox-wrapper').each(function () {
            let $wrapper = $(this);
            let $checkbox = $wrapper.find('.product-cart-chechbox');

            if ($checkbox.is(':checked')) {
                let qty = parseInt($wrapper.find('.qty').val()) || 1;
                let price = 0;

                if ($wrapper.find('.variations_form').length) {
                    price = parseFloat($wrapper.data('variation_price')) || 0;
                } else {
                    price = parseFloat($checkbox.attr('data-price')) || 0;
                }

                total_price += price * qty;
                total_items += qty;
            }
        });
        // ✅ Handle grouped products
        $('.grouped_product').each(function () {
            let $wrapper = $(this);
            let $checkbox = $wrapper.find('.product-cart-chechbox');

            if ($checkbox.is(':checked')) {
                $wrapper.find('.selected-product-qty').each(function () {
                    let qty = parseInt($(this).val()) || 0;
                    let price = parseFloat($(this).attr('data-price')) || 0;

                    total_price += qty * price;
                    total_items += qty;
                });
            }
        });

        // ✅ Update button
        let $cartButton = $('.wcpt-selected-cart');
        if (total_items === 0) {
            $cartButton.text('Add Selected Products to Cart');
            $('a.wcpt-selected-cart').css('pointer-events', 'none').css('opacity', '0.5'); 
        } else {
            let formatted_price = new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: 'USD'
            }).format(total_price);
            $cartButton.text(`Add ${total_items} items for ${formatted_price}`);
            $('a.wcpt-selected-cart').css('pointer-events', 'auto').css('opacity', '1');
        }
    }

});










jQuery(document).ready(function ($) {
	if ( product_table_params.display_onepage_checkout == 'yes' ) {
	    setTimeout(function () {
	        // $('.checkout').on('click', function (e) {
	    jQuery(document).on('click', 'a.checkout', function(e) {

	            e.preventDefault();

	            $('.widget_shopping_cart_content').html('<p>Loading checkout…</p>');

	            jQuery('.wcpt-global-loader').addClass('active');
	   			jQuery('.wcpt-spinner').addClass('active');
	            $(".wcpt-minicart-icon").hide();
	            jQuery('.wcpt-my-cart').text('Checkout');

	            jQuery.post(
	                product_table_params.ajax_url,
	                {
	                    action: 'load_mini_cart_checkout',
	                    nonce: product_table_params.nonce
	                },
	                function (response) {
	                    if (response.success) {
	                       $('.widget_shopping_cart_content').html(response.data);
	                       if ($('.wcpt-mini-cart-title .back-to-cart').length === 0) {
	                            $('.wcpt-mini-cart-title').append(
	                                `<span class="dashicons dashicons-arrow-left-alt back-to-cart" title="Back to Cart"></span>`
	                            );
	                        }
	                    }
	                    $(".cart-drawer").css("right", "0");
	                    jQuery('.wcpt-global-loader').removeClass('active');
	   					jQuery('.wcpt-spinner').removeClass('active');
	                }
	            );
	        });
	    }, 500);


	  jQuery(document).on('click', '.back-to-cart', function(e) {
	  e.preventDefault();

	  // Show loader
	  jQuery('.wcpt-global-loader').addClass('active');
	   jQuery('.wcpt-spinner').addClass('active');
	            jQuery('.wcpt-my-cart').text('My Cart');


	  jQuery.post(
	      product_table_params.ajax_url,
	      {
	          action: 'load_mini_cart_content',
	          nonce: product_table_params.nonce
	      },
	      function(response) {
	          if (response.success) {
	              jQuery('.widget_shopping_cart_content').html(response.data);
	              // Remove back-to-cart button
	              jQuery('.back-to-cart').remove();
	          }
	      }
	  ).always(function() {
	    // Hide loader after success or failure
	    jQuery('.wcpt-global-loader').removeClass('active');
	   jQuery('.wcpt-spinner').removeClass('active');

	  });
	});
	}


// jQuery(document).ready(function ($) {
//     $(document).on('change', '.grouped_child_product', function () {
//         const selectedID = $(this).val();
//         const selectedText = $(this).find('option:selected').text();
//         const $form = $(this).closest('form');
//         const $output = $form.find('.grouped_child_products_output');

//         if (!selectedID) return;
//         if ($form.find(`.grouped-child-product[data-id="${selectedID}"]`).length) return;

//         const html = `
//             <div class="grouped-child-product" data-id="${selectedID}">
//                 <label>${selectedText}</label>
//                 <input type="number" name="quantity[${selectedID}]" value="1" min="1" />
//                 <button type="button" class="remove-child-product">×</button>
//             </div>
//         `;
//         $output.append(html);
//     });

//     $(document).on('click', '.remove-child-product', function () {
//         $(this).closest('.grouped-child-product').remove();
//     });
// });

jQuery(document).ready(function($){
   
      $(document).on('change', '.grouped-product-selector', function() {
        var $form = $(this).closest('form');
        var $container = $form.find('.selected-products-container');

        var selectedOption = $(this).find('option:selected');
        var productId = selectedOption.val();
        var productName = selectedOption.data('name');
        var rawPrice = selectedOption.data('price'); // Could be "$45.00" or similar
		var productPrice = parseFloat(rawPrice.toString().replace(/[^\d.]/g, ''));
        var cartBtn = $(this).find('.group-product-btn');
         $form.find('.group-product-btn').prop('disabled', false);

        if (!productId) return;

        // Check if already selected
        if ($container.find('[data-product-id="' + productId + '"]').length > 0) {
            alert('This product is already selected.');
            $(this).val('');
            return;
        }

        // Create and append new block
        var productHTML = `
            <div class="product-details-wrapper" data-product-id="${productId}" style="margin-bottom: 15px; border: 1px solid #ccc; padding: 10px;">
                <p>
				    <input type="number" class="selected-product-qty" name="quantity[${productId}]" data-price="${productPrice}" value="1" min="1" />
				    <label>${productName}</label>
				    <a href="javascript:void(0);" class="remove-product" data-remove-id="${productId}">
					   <i class="fas fa-trash-alt"></i>
					</a>
				</p>

            </div>
        `;

        $container.append(productHTML);

       // Enable the parent checkbox dynamically
var parentProductId = $form.find('.group-product-add-to-cart').val();
$('.product-cart-chechbox[value="' + parentProductId + '"]').prop('disabled', false);
        // Reset dropdown
        $(this).val('');
    });



 jQuery(document).on('submit', '.product-cart-wrapper form.grouped_form', function (e) {
    e.preventDefault();
    var $form = jQuery(this);

    // Filter out only fields with quantity > 0
    var formDataArray = $form.serializeArray().filter(function (field) {
        return !(field.name.startsWith('quantity') && (field.value === '0' || field.value === ''));
    });

    // Add WooCommerce required action
    formDataArray.push({ name: 'action', value: 'woocommerce_add_to_cart' });

    var formData = jQuery.param(formDataArray);

    jQuery.ajax({
        url: wc_add_to_cart_params.ajax_url,
        type: 'POST',
        data: formData,
        success: function (response) {

            // Manually refresh WooCommerce cart fragments
            jQuery.ajax({
                url: wc_add_to_cart_params.wc_ajax_url.toString().replace('%%endpoint%%', 'get_refreshed_fragments'),
                type: 'POST',
                success: function (fragmentResponse) {
                    if (fragmentResponse && fragmentResponse.fragments) {
                        jQuery.each(fragmentResponse.fragments, function (key, value) {
                            jQuery(key).replaceWith(value);
                        });
                    }
                }
            });

            // Clear WooCommerce notices to prevent reload notice
            jQuery.ajax({
                url: wc_add_to_cart_params.ajax_url,
                type: 'POST',
                data: {
                    action: 'clear_wc_notices'
                }
            });

            // Fire default WooCommerce event
            jQuery(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash, $form]);

            // ✅ Show "View Cart" link next to Add to Cart
            if (wc_add_to_cart_params && wc_add_to_cart_params.cart_url) {
                var viewCartLink = '<a href="' + wc_add_to_cart_params.cart_url + '" class="added_to_cart wc-forward">View cart</a>';
                $form.find('.added_to_cart').remove(); // prevent duplicates
                $form.find('button[type="submit"], .single_add_to_cart_button').after(viewCartLink);
            }
            // UI cleanup
            jQuery('.product-table-loader').hide();
            $form.find('.grouped-product-selector').val('');
            $form.find('.selected-products-list').empty();
            $form.find('.product-details-wrapper').remove();
        }
    });
});



});

});

jQuery(function ($) {
  $(document).on('submit', '.grouped_form_ajax', function (e) {
    e.preventDefault();

    let $form = $(this);
    let $button = $form.find('.single_add_to_cart_button');

    // Filter out only quantity fields > 0
    let formDataArray = $form.serializeArray().filter(function (field) {
      return !(field.name.startsWith('quantity') && (field.value === '0' || field.value === ''));
    });

    if (!formDataArray.some(field => field.name.startsWith('quantity'))) {
      alert('Please select quantity for at least one item.');
      return;
    }

    // Add WooCommerce required action
    formDataArray.push({ name: 'action', value: 'woocommerce_add_to_cart' });

    // Disable button and show loading spinner
    $button.prop('disabled', true).addClass('loading').html('<span class="spinner"></span> Adding...');

    // Send to WooCommerce AJAX add_to_cart handler
    $.ajax({
      url: wc_add_to_cart_params.ajax_url,
      type: 'POST',
      data: $.param(formDataArray),
      success: function (response) {
        // Refresh cart fragments
        $.ajax({
          url: wc_add_to_cart_params.wc_ajax_url.toString().replace('%%endpoint%%', 'get_refreshed_fragments'),
          type: 'POST',
          success: function (fragments) {
            if (fragments && fragments.fragments) {
              $.each(fragments.fragments, function (key, value) {
                $(key).replaceWith(value);
              });
            }
          }
        });

        // Trigger WooCommerce JS event
        $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash, $form]);

        // Optional: clear custom UI (if you use selected list)
        $form.find('.grouped-product-selector').val('');
        $form.find('.selected-products-list, .product-details-wrapper').empty();

        // Reset button
        $button.prop('disabled', false).removeClass('loading').html('Add to Cart');
      	 location.reload();
      },
      error: function (xhr) {
        alert('AJAX error: ' + xhr.responseText);
        $button.prop('disabled', false).removeClass('loading').html('Add to Cart');
      }
    });
  });
});
