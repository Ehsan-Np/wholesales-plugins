(function ($) {
	'use strict';

	var cfg = window.wwp_ccp_frontend || window.admin_ccp_script || {};
	var ajaxUrl = cfg.ajax_url || '';
	var nonce = cfg.nonce || '';
	var i18n = cfg.i18n || {};

	function openModal($modal) {
		$modal = $modal && $modal.length ? $modal : $('#ccp_myModal');
		$modal.removeAttr('hidden').addClass('is-open').css('display', 'flex');
	}

	function closeModal($modal) {
		$modal = $modal && $modal.length ? $modal : $('#ccp_myModal');
		$modal.attr('hidden', 'hidden').removeClass('is-open').hide();
	}

	function toggleFilterPanel($btn) {
		var $panel = $('#ccp_filter_panel_wrap');
		if (!$panel.length) {
			return;
		}
		var isHidden = $panel.prop('hidden') || $panel.is('[hidden]');
		if (isHidden) {
			$panel.prop('hidden', false).removeAttr('hidden');
			$btn.attr('aria-expanded', 'true');
		} else {
			$panel.prop('hidden', true).attr('hidden', 'hidden');
			$btn.attr('aria-expanded', 'false');
		}
	}

	$(document).on('click', '#ccp_filter_panel', function (e) {
		e.preventDefault();
		toggleFilterPanel($(this));
	});

	$(document).on('click', '.wwp-ccp-modal__close, .wwp-ccp-modal .close, #ccp_myModal .close', function (e) {
		e.preventDefault();
		closeModal($(this).closest('#ccp_myModal').length ? $(this).closest('#ccp_myModal') : $('#ccp_myModal'));
	});

	$(document).on('click', '#ccp_myModal', function (e) {
		if (e.target === this) {
			closeModal($(this));
		}
	});

	$(document).on('click', '#ccp_sahre_cart', function (e) {
		e.preventDefault();
		openModal($('#ccp_myModal'));
	});

	$(document).on('click', '#ccp_sahre_cart_save', function (event) {
		event.preventDefault();
		var $btn = $(this);
		$btn.prop('disabled', true);

		var title = $('#ccp_share_title').val();
		var userId = $('#ccp_share_user').val();

		if (!title) {
			alert(i18n.requiredTitle || 'Required Title');
			$btn.prop('disabled', false);
			return false;
		}

		if (!userId) {
			alert(i18n.selectUser || 'Please select user');
			$btn.prop('disabled', false);
			return false;
		}

		$.ajax({
			type: 'POST',
			dataType: 'json',
			url: ajaxUrl,
			data: {
				action: 'ccp_sahre_cart_save',
				ccp_share_title: title,
				ccp_share_user: userId,
				nonce: nonce
			},
			success: function (response) {
				alert(response.message || '');
				if (response.status === 'success') {
					closeModal();
					$('#ccp_share_title').val('');
					$('#ccp_share_user').val('');
				}
				$btn.prop('disabled', false);
			},
			error: function () {
				$btn.prop('disabled', false);
			}
		});

		return false;
	});

	function initSharedCartTables() {
		if (typeof $.fn.DataTable === 'undefined') {
			return;
		}

		if ($('#ccp_my_shared_cart').length && !$.fn.DataTable.isDataTable('#ccp_my_shared_cart')) {
			$('#ccp_my_shared_cart').DataTable({
				processing: true,
				serverSide: false,
				ajax: ajaxUrl + '?action=ccp_shared_cart_datatable',
				columns: [
					{ data: 'title' },
					{ data: 'shared_with' },
					{ data: 'count_list' },
					{
						data: null,
						orderable: false,
						render: function (data) {
							return (
								'<button type="button" class="open_list wwp-ccp-icon-btn" data-id="' +
								data.id +
								'"><span class="dashicons dashicons-visibility"></span></button> ' +
								'<button type="button" class="delete_list wwp-ccp-icon-btn" data-id="' +
								data.id +
								'"><span class="dashicons dashicons-trash"></span></button>'
							);
						}
					}
				]
			});
		}

		if ($('#ccp_user_shared_cart').length && !$.fn.DataTable.isDataTable('#ccp_user_shared_cart')) {
			$('#ccp_user_shared_cart').DataTable({
				processing: true,
				serverSide: false,
				ajax: ajaxUrl + '?action=ccp_user_shared_cart',
				columns: [
					{ data: 'title' },
					{ data: 'shared_with' },
					{ data: 'count_list' },
					{
						data: null,
						orderable: false,
						render: function (data) {
							return (
								'<button type="button" class="open_list wwp-ccp-icon-btn" data-id="' +
								data.id +
								'"><span class="dashicons dashicons-visibility"></span></button> ' +
								'<button type="button" class="delete_list wwp-ccp-icon-btn" data-id="' +
								data.id +
								'"><span class="dashicons dashicons-trash"></span></button>'
							);
						}
					}
				]
			});
		}
	}

	var ccpOrderTable = null;
	var ccpCreditsTable = null;

	function renderOrderActions(row) {
		var html = '<div class="wwp-ccp-row-actions">';
		html +=
			'<button type="button" class="ccp_order_view wwp-ccp-btn wwp-ccp-btn--sm" data-id="' +
			row.user_id +
			'">' +
			(i18n.view || 'View') +
			' <span class="dashicons dashicons-visibility" aria-hidden="true"></span></button>';

		if (row.can_approve) {
			html +=
				' <button type="button" class="wwp-ccp-order-approve wwp-ccp-btn wwp-ccp-btn--sm wwp-ccp-btn--success" data-id="' +
				row.user_id +
				'">' +
				(i18n.approve || 'Approve') +
				'</button>';
			html +=
				' <button type="button" class="wwp-ccp-order-reject wwp-ccp-btn wwp-ccp-btn--sm wwp-ccp-btn--danger" data-id="' +
				row.user_id +
				'">' +
				(i18n.reject || 'Reject') +
				'</button>';
		}

		html += '</div>';
		return html;
	}

	function initOrdersAndCreditsTables() {
		if (typeof $.fn.DataTable === 'undefined') {
			return;
		}

		if ($('#ccp_order_table').length && !$.fn.DataTable.isDataTable('#ccp_order_table')) {
			ccpOrderTable = $('#ccp_order_table').DataTable({
				processing: true,
				serverSide: false,
				autoWidth: false,
				order: [],
				ajax: {
					url: ajaxUrl,
					type: 'POST',
					data: function () {
						var data = $('.wwp-ccp-panel--orders #ccp_form_filter').serializeArray();
						var payload = { action: 'ccp_get_company_orders', nonce: nonce };
						$.each(data, function (i, field) {
							payload[field.name] = field.value;
						});
						return payload;
					}
				},
				columns: [
					{ data: 'user_id' },
					{ data: 'post_date' },
					{ data: 'user_email' },
					{ data: 'user_status' },
					{
						data: null,
						orderable: false,
						render: function (data, type, row) {
							return renderOrderActions(row);
						}
					}
				]
			});
		}

		if ($('#ccp_credits_table').length && !$.fn.DataTable.isDataTable('#ccp_credits_table')) {
			ccpCreditsTable = $('#ccp_credits_table').DataTable({
				processing: true,
				serverSide: false,
				autoWidth: false,
				order: [],
				ajax: {
					url: ajaxUrl,
					type: 'POST',
					data: function () {
						var data = $('.wwp-ccp-panel--credit #ccp_form_filter').serializeArray();
						var payload = { action: 'ccp_get_company_credits', nonce: nonce };
						$.each(data, function (i, field) {
							payload[field.name] = field.value;
						});
						return payload;
					}
				},
				columns: [
					{ data: 'ID' },
					{ data: 'user_email' },
					{ data: 'amount' },
					{ data: 'event' },
					{ data: 'post_date' }
				]
			});
		}
	}

	function initUsersTable() {
		if (typeof $.fn.DataTable === 'undefined') {
			return;
		}

		if (!$('#ccp_users_table').length || $.fn.DataTable.isDataTable('#ccp_users_table')) {
			return;
		}

		$('#ccp_users_table').DataTable({
			processing: true,
			serverSide: false,
			autoWidth: false,
			order: [],
			ajax: {
				url: ajaxUrl,
				type: 'POST',
				data: { action: 'ccp_get_company_users', nonce: nonce }
			},
			columns: [
				{ data: 'user_id' },
				{ data: 'display_name' },
				{ data: 'user_email' },
				{ data: 'user_role' },
				{
					data: null,
					orderable: false,
					render: function (data, type, row) {
						var buttons = [];

						if (row.can_edit) {
							buttons.push(
								'<button type="button" class="wwp-ccp-btn wwp-ccp-btn--ghost wwp-ccp-btn--sm ccp_user_edit" data-id="' +
								row.user_id +
								'">' +
								(i18n.edit || 'Edit') +
								'</button>'
							);
						}

						if (row.can_remove) {
							buttons.push(
								'<button type="button" class="wwp-ccp-btn wwp-ccp-btn--danger wwp-ccp-btn--sm ccp_user_remove" data-id="' +
								row.user_id +
								'">' +
								(i18n.remove || 'Remove') +
								'</button>'
							);
						}

						if (!buttons.length) {
							return '<span class="wwp-ccp-muted">—</span>';
						}

						return '<span class="wwp-ccp-user-actions">' + buttons.join('') + '</span>';
					}
				}
			]
		});
	}

	function loadUserFormModal(options) {
		options = options || {};
		var isEdit = !!options.userId;
		var $modal = $('#ccp_myModal');
		var requestData = {
			action: 'ccp_get_add_user_form',
			nonce: nonce
		};

		if (isEdit) {
			requestData.user_id = options.userId;
		}

		$modal.find('.ccp_response_heading').text(
			isEdit
				? (i18n.editUser || 'Edit User')
				: (i18n.addNewUser || 'Add New User')
		);
		$modal.find('.modal-body').html('');
		openModal($modal);

		$.ajax({
			type: 'POST',
			url: ajaxUrl,
			data: requestData,
			beforeSend: function () {
				$modal.find('.loader').show().removeAttr('hidden');
			},
			success: function (response) {
				$modal.find('.modal-body').html(response);
			},
			complete: function () {
				$modal.find('.loader').hide().attr('hidden', 'hidden');
			}
		});
	}

	$(document).on('click', '#open_modal, .wwp-ccp-panel--users .add_new_user', function (event) {
		event.preventDefault();
		loadUserFormModal();
		return false;
	});

	$(document).on('click', '#ccp_users_table tbody .ccp_user_edit', function (event) {
		event.preventDefault();
		var userId = $(this).data('id');
		if (!userId) {
			return false;
		}
		loadUserFormModal({ userId: userId });
		return false;
	});

	$(document).on('submit', '#ccp_add_user_form', function (event) {
		event.preventDefault();
		var $form = $(this);
		var $btn = $('#ccp_add_user_submit');
		var isEdit = $form.data('mode') === 'edit';
		var editUserId = parseInt($('#ccp_edit_user_id').val(), 10) || 0;
		var firstName = $.trim($('#account_first_name').val());
		var lastName = $.trim($('#account_last_name').val());
		var username = $.trim($('#account_user_login').val());
		var email = $.trim($('#account_email').val());
		var requestData;

		if (!firstName) {
			alert(i18n.firstNameRequired || 'First name is required.');
			return false;
		}
		if (!lastName) {
			alert(i18n.lastNameRequired || 'Last name is required.');
			return false;
		}

		if (isEdit) {
			if (!editUserId) {
				alert(i18n.requestFailed || 'Request failed.');
				return false;
			}

			requestData = {
				action: 'ccp_update_company_user',
				nonce: nonce,
				user_id: editUserId,
				account_first_name: firstName,
				account_last_name: lastName
			};
		} else {
			if (!username) {
				alert(i18n.usernameRequired || 'Username is required.');
				return false;
			}
			if (!email) {
				alert(i18n.emailRequired || 'Email address is required.');
				return false;
			}

			requestData = {
				action: 'ccp_add_company_user',
				nonce: nonce,
				account_first_name: firstName,
				account_last_name: lastName,
				account_user_login: username,
				account_email: email
			};
		}

		$btn.prop('disabled', true);

		$.ajax({
			type: 'POST',
			dataType: 'json',
			url: ajaxUrl,
			data: requestData,
			success: function (response) {
				if (response && response.success) {
					alert(
						(response.data && response.data.message) ||
						(isEdit ? (i18n.userUpdated || 'User updated successfully.') : (i18n.userAdded || 'User added successfully.'))
					);
					closeModal();
					if ($.fn.DataTable.isDataTable('#ccp_users_table')) {
						$('#ccp_users_table').DataTable().ajax.reload();
					}
				} else {
					alert((response && response.data && response.data.message) || (i18n.requestFailed || 'Request failed.'));
				}
				$btn.prop('disabled', false);
			},
			error: function (xhr) {
				var message = i18n.requestFailed || 'Request failed.';
				if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
					message = xhr.responseJSON.data.message;
				}
				alert(message);
				$btn.prop('disabled', false);
			}
		});

		return false;
	});

	$(document).on('click', '#ccp_users_table tbody .ccp_user_remove', function (event) {
		event.preventDefault();
		var $btn = $(this);
		var userId = $btn.data('id');

		if (!confirm(i18n.confirmRemoveMember || 'Remove this member from the company?')) {
			return false;
		}

		$btn.prop('disabled', true);

		$.ajax({
			type: 'POST',
			dataType: 'json',
			url: ajaxUrl,
			data: {
				action: 'ccp_remove_company_member',
				user_id: userId,
				nonce: nonce
			},
			success: function (response) {
				if (response && response.success) {
					if ($.fn.DataTable.isDataTable('#ccp_users_table')) {
						$('#ccp_users_table').DataTable().ajax.reload();
					}
				} else {
					alert((response && response.data && response.data.message) || (i18n.requestFailed || 'Request failed.'));
					$btn.prop('disabled', false);
				}
			},
			error: function (xhr) {
				var message = i18n.requestFailed || 'Request failed.';
				if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
					message = xhr.responseJSON.data.message;
				}
				alert(message);
				$btn.prop('disabled', false);
			}
		});

		return false;
	});

	$(document).ready(function () {
		initSharedCartTables();
		initOrdersAndCreditsTables();
		initUsersTable();
	});

	$(document).on('click', '.wwp-ccp-panel--orders #ccp-search-now, .wwp-ccp-panel--credit #ccp-search-now', function (event) {
		event.preventDefault();
		if ($(this).closest('.wwp-ccp-panel--orders').length && ccpOrderTable) {
			ccpOrderTable.ajax.reload();
		}
		if ($(this).closest('.wwp-ccp-panel--credit').length && ccpCreditsTable) {
			ccpCreditsTable.ajax.reload();
		}
		return false;
	});

	$(document).on('click', '.wwp-ccp-panel--orders #ccp-search-clear, .wwp-ccp-panel--credit #ccp-search-clear', function () {
		var $form = $(this).closest('form');
		setTimeout(function () {
			if ($form.closest('.wwp-ccp-panel--orders').length && ccpOrderTable) {
				ccpOrderTable.ajax.reload();
			}
			if ($form.closest('.wwp-ccp-panel--credit').length && ccpCreditsTable) {
				ccpCreditsTable.ajax.reload();
			}
		}, 0);
	});

	$(document).on('click', '.ccp_order_view', function (event) {
		event.preventDefault();
		var orderId = $(this).data('id');
		$.ajax({
			type: 'POST',
			url: ajaxUrl,
			data: {
				action: 'ccp_get_order_view',
				nonce: nonce,
				order_id: orderId
			},
			success: function (html) {
				var $modal = $('#ccp_myModal');
				$modal.find('.ccp_response_heading').text(i18n.orderDetails || 'Order details');
				$modal.find('.ccp_response_body').html(html);
				openModal($modal);
			}
		});
		return false;
	});

	function reviewCompanyOrder(action, orderId, $btn) {
		$btn.prop('disabled', true);
		$.ajax({
			type: 'POST',
			url: ajaxUrl,
			dataType: 'json',
			data: {
				action: action,
				nonce: nonce,
				order_id: orderId
			},
			success: function (response) {
				if (response && response.success) {
					if (ccpOrderTable) {
						ccpOrderTable.ajax.reload(null, false);
					} else {
						window.location.reload();
					}
				} else {
					alert((response && response.data && response.data.message) || (i18n.requestFailed || 'Request failed.'));
					$btn.prop('disabled', false);
				}
			},
			error: function (xhr) {
				var message = i18n.requestFailed || 'Request failed.';
				if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
					message = xhr.responseJSON.data.message;
				}
				alert(message);
				$btn.prop('disabled', false);
			}
		});
	}

	$(document).on('click', '.wwp-ccp-order-approve', function (event) {
		event.preventDefault();
		reviewCompanyOrder('ccp_approve_company_order', $(this).data('id'), $(this));
		return false;
	});

	$(document).on('click', '.wwp-ccp-order-reject', function (event) {
		event.preventDefault();
		if (!confirm(i18n.confirmRejectOrder || 'Reject this order? Credits will be restored to the buyer.')) {
			return false;
		}
		reviewCompanyOrder('ccp_reject_company_order', $(this).data('id'), $(this));
		return false;
	});

	$(document).on('click', '#ccp_my_shared_cart tbody .delete_list', function () {
		var id = $(this).data('id');
		var $btn = $(this);
		if (!confirm(i18n.confirmDeleteShared || 'Are you sure you want to delete this shared cart?')) {
			return false;
		}
		$btn.prop('disabled', true);
		$.ajax({
			type: 'POST',
			url: ajaxUrl,
			data: { action: 'ccp_my_shared_cart_delete', post_id: id, nonce: nonce },
			success: function () {
				$('#ccp_my_shared_cart').DataTable().ajax.reload();
			}
		});
		return false;
	});

	$(document).on('click', '#ccp_user_shared_cart tbody .delete_list', function () {
		var id = $(this).data('id');
		var $btn = $(this);
		if (!confirm(i18n.confirmDeleteShared || 'Are you sure you want to delete this shared cart?')) {
			return false;
		}
		$btn.prop('disabled', true);
		$.ajax({
			type: 'POST',
			url: ajaxUrl,
			data: { action: 'ccp_user_shared_cart_delete', post_id: id, nonce: nonce },
			success: function () {
				$('#ccp_user_shared_cart').DataTable().ajax.reload();
			}
		});
		return false;
	});

	$(document).on('click', '#ccp_my_shared_cart tbody .open_list, #ccp_user_shared_cart tbody .open_list', function () {
		var id = $(this).data('id');
		var $modal = $('#ccp_myModal');
		$modal.find('.ccp_response_heading').text(i18n.sharedCartDetails || 'Shared Carts Detail');
		$modal.find('.modal-body').html('');
		openModal($modal);

		$.ajax({
			type: 'POST',
			url: ajaxUrl,
			data: { action: 'ccp_shared_cart_template', post_id: id },
			beforeSend: function () {
				$modal.find('.loader').show().removeAttr('hidden');
			},
			success: function (response) {
				$modal.find('.modal-body').html(response);
			},
			complete: function () {
				$modal.find('.loader').hide().attr('hidden', 'hidden');
			}
		});
		return false;
	});

	$(document).on('click', '#ccp_add_to_cart_shared', function (event) {
		event.preventDefault();
		var $btn = $(this);
		var values = $('#form_sahre_cart_list').serializeArray();
		values.push({ name: 'nonce', value: nonce });

		$.ajax({
			type: 'POST',
			url: ajaxUrl,
			data: values,
			beforeSend: function () {
				$btn.prop('disabled', true);
			},
			success: function () {
				alert(i18n.itemsAdded || 'Items added to the cart successfully');
				closeModal();
				$btn.prop('disabled', false);
				$(document.body).trigger('wc_fragment_refresh');
			},
			error: function () {
				$btn.prop('disabled', false);
			}
		});
		return false;
	});

	$(document).on('submit', '#ccp_credit_request_form', function (event) {
		event.preventDefault();
		var $btn = $('#ccp_credit_request_submit');
		var amount = $('#ccp_credit_request_amount').val();
		var reason = $('#ccp_credit_request_reason').val();

		$btn.prop('disabled', true);

		$.ajax({
			type: 'POST',
			url: ajaxUrl,
			dataType: 'json',
			data: {
				action: 'ccp_submit_credit_request',
				nonce: nonce,
				amount: amount,
				reason: reason
			},
			success: function (response) {
				var message = (response && response.data && response.data.message) || (i18n.requestSubmitted || 'Credit request submitted successfully.');
				if (response && response.success) {
					alert(message);
					location.reload();
					return;
				}
				alert((response && response.data && response.data.message) || (i18n.requestFailed || 'Request failed.'));
				$btn.prop('disabled', false);
			},
			error: function (xhr) {
				var message = i18n.requestFailed || 'Request failed.';
				if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
					message = xhr.responseJSON.data.message;
				}
				alert(message);
				$btn.prop('disabled', false);
			}
		});

		return false;
	});

	function updateRequestRow($row, status) {
		var label = status.charAt(0).toUpperCase() + status.slice(1);
		var badgeClass = 'pending' === status ? 'wwp-ccp-badge--pending' : ('approved' === status ? 'wwp-ccp-badge--approved' : 'wwp-ccp-badge--declined');
		$row.find('.wwp-ccp-request-status-cell').html('<span class="wwp-ccp-badge ' + badgeClass + '">' + label + '</span>');
		$row.find('.wwp-ccp-request-actions-cell').html('<span class="wwp-ccp-muted">—</span>');
	}

	function reviewCreditRequest(action, index, $btn) {
		var companyId = $('.wwp-ccp-panel--credit-requests').data('company-id');
		if (!companyId && window.wwp_ccp_frontend && wwp_ccp_frontend.company_id) {
			companyId = wwp_ccp_frontend.company_id;
		}

		$btn.prop('disabled', true);

		$.ajax({
			type: 'POST',
			url: ajaxUrl,
			dataType: 'json',
			data: {
				action: action,
				nonce: nonce,
				company_id: companyId,
				index: index
			},
			success: function (response) {
				if (response && response.success) {
					var status = response.data && response.data.status ? response.data.status : '';
					var $row = $btn.closest('tr');
					if (status && $row.length) {
						updateRequestRow($row, status);
					} else {
						window.location.reload();
					}
				} else {
					alert((response && response.data && response.data.message) || (i18n.requestFailed || 'Request failed.'));
					$btn.prop('disabled', false);
				}
			},
			error: function (xhr) {
				var message = i18n.requestFailed || 'Request failed.';
				if (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
					message = xhr.responseJSON.data.message;
				}
				alert(message);
				$btn.prop('disabled', false);
			}
		});
	}

	$(document).on('click', '.wwp-ccp-request-approve', function (event) {
		event.preventDefault();
		var $btn = $(this);
		reviewCreditRequest('ccp_approve_credit_request', $btn.data('index'), $btn);
		return false;
	});

	$(document).on('click', '.wwp-ccp-request-decline', function (event) {
		event.preventDefault();
		var $btn = $(this);
		if (!confirm(i18n.confirmDeclineRequest || 'Decline this credit request?')) {
			return false;
		}
		reviewCreditRequest('ccp_decline_credit_request', $btn.data('index'), $btn);
		return false;
	});
})(jQuery);
