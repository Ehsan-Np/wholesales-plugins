(function ($) {
	'use strict';

	var settings = window.wwpPoCheckout || {};
	var gatewayId = settings.gatewayId || 'wwp_purchase_order';
	var uploading = false;

	function selectedGateway() {
		return $('input[name="payment_method"]:checked').val();
	}

	function setAttachmentId(id) {
		$('#wwp_po_attachment_id').val(id || '');
	}

	function showFileError(message) {
		var $row = $('#wwp_po_document').closest('.form-row');
		$row.find('.wwp-po-checkout-error').remove();
		if (message) {
			$row.append(
				$('<span/>', {
					class: 'wwp-po-checkout-error',
					text: message,
					css: { display: 'block', color: '#b32d2e', marginTop: '4px' },
				})
			);
		}
	}

	function validateFile(file) {
		if (!file) {
			return '';
		}

		var name = String(file.name || '');
		var ext = name.indexOf('.') !== -1 ? name.split('.').pop().toLowerCase() : '';
		var allowed = Array.isArray(settings.fileTypes)
			? settings.fileTypes.map(function (type) {
					return String(type).toLowerCase();
			  })
			: [];

		if (allowed.length && allowed.indexOf(ext) === -1) {
			return settings.errorFileType || 'This file type is not allowed.';
		}

		var maxMb = Number(settings.maxFileSize || 5);
		if (file.size > maxMb * 1024 * 1024) {
			return settings.errorFileSize || 'The document is too large.';
		}

		return '';
	}

	function uploadFile(file) {
		var error = validateFile(file);
		if (error) {
			setAttachmentId('');
			showFileError(error);
			return $.Deferred().reject(error).promise();
		}

		showFileError('');
		uploading = true;

		var body = new FormData();
		body.append('file', file);

		return $.ajax({
			url: settings.uploadUrl,
			method: 'POST',
			data: body,
			processData: false,
			contentType: false,
			xhrFields: { withCredentials: true },
			beforeSend: function (xhr) {
				if (settings.uploadNonce) {
					xhr.setRequestHeader('X-WP-Nonce', settings.uploadNonce);
				}
			},
		})
			.done(function (payload) {
				var id = payload && payload.attachment_id ? Number(payload.attachment_id) : 0;
				if (!id) {
					setAttachmentId('');
					showFileError(settings.errorUpload || 'The document could not be uploaded. Please try again.');
					return;
				}
				setAttachmentId(id);
			})
			.fail(function (xhr) {
				setAttachmentId('');
				var message = settings.errorUpload || 'The document could not be uploaded. Please try again.';
				if (xhr && xhr.responseJSON && xhr.responseJSON.message) {
					message = xhr.responseJSON.message;
				}
				showFileError(message);
			})
			.always(function () {
				uploading = false;
			});
	}

	$(document.body).on('change', '#wwp_po_document', function () {
		var file = this.files && this.files[0] ? this.files[0] : null;
		if (!file) {
			setAttachmentId('');
			showFileError('');
			return;
		}
		uploadFile(file);
	});

	$(document.body).on('checkout_place_order_' + gatewayId, function () {
		if (uploading) {
			showFileError(settings.errorUpload || 'Please wait for the document to finish uploading.');
			return false;
		}
		return true;
	});

	// Classic checkout AJAX uses serialize(), which drops file inputs. Send FormData instead.
	if (typeof $.ajaxPrefilter === 'function') {
		$.ajaxPrefilter(function (options) {
			if (!options.url || String(options.url).indexOf('wc-ajax=checkout') === -1) {
				return;
			}
			if (selectedGateway() !== gatewayId) {
				return;
			}

			var form = document.querySelector('form.checkout');
			if (!form) {
				return;
			}

			var fileInput = form.querySelector('#wwp_po_document');
			if (!fileInput || !fileInput.files || !fileInput.files.length) {
				return;
			}

			options.data = new FormData(form);
			options.processData = false;
			options.contentType = false;
		});
	}
})(jQuery);
