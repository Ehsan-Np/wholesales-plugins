<?php
/**
 * Vars
 * 
 * WP_Post $post
 */

// Use nonce for verification
wp_nonce_field('wwp_save_group', 'wwp_group_nonce');

// Get meta data for the group
$include_products = get_post_meta($post->ID, '_include_products', true);
$include_specific_products = get_post_meta($post->ID, '_include_specific_products', true);
$exclude_products = get_post_meta($post->ID, '_exclude_products', true);
$add_users = get_post_meta($post->ID, '_add_users', true);
$discount_type = get_post_meta($post->ID, '_discount_type', true);
$min_quantity = get_post_meta($post->ID, '_min_quantity', true);
$wwp_price = get_post_meta($post->ID, '_wwp_group_price', true);
$max_quantity = get_post_meta($post->ID, '_max_quantity', true);
$disable_payment_methods = get_post_meta($post->ID, '_disable_payment_methods', true);
$disable_shipping_methods = get_post_meta($post->ID, '_disable_shipping_methods', true);

// Get all users
$users = get_users();

// Get available payment methods
$payment_gateways = WC()->payment_gateways->payment_gateways();

// Get available shipping methods
$shipping_methods = WC()->shipping()->get_shipping_methods();

// Get all WooCommerce products
$args = array(
	'post_type' => 'product',
	'posts_per_page' => -1, // Get all products
	'post_status' => 'publish',
);
$products = get_posts($args);

?>

<table class="form-table">
	<tbody>
		<input id="wwp-group-id" type="hidden" value="<?php esc_attr_e($post->id); ?>">
		<!-- Include Products -->
		<tr>
			<th>
				<strong><?php esc_html_e('Include Products', 'woocommerce-wholesale-pricing'); ?></strong>
			</th>
			<td id="include-products">
				<input type="radio" id="all_products" name="include_products" value="all" <?php checked($include_products, 'all'); ?>>
				<label for="all_products"><?php esc_html_e('All', 'woocommerce-wholesale-pricing'); ?></label>
				<input type="radio" id="specific_products" name="include_products" value="specific" <?php checked($include_products, 'specific'); ?>>
				<label for="specific_products"><?php esc_html_e('Specific Products', 'woocommerce-wholesale-pricing'); ?></label><br>
				<div class="test" >
					<select class="include-specific-product wc-enhanced-select" name="include_specific_products[]" multiple>
						<?php
						foreach ( $products as $product ) { 
							$product_id = $product->ID;
							$selected = in_array($product_id, (array) $include_specific_products) ? 'selected' : '';
							?>
							<option value="<?php echo esc_attr($product_id); ?>" <?php echo esc_attr($selected); ?>>
								<?php echo esc_html($product->post_title); ?>
							</option>
						<?php } ?>
					</select>
				</div>
			</td>
		</tr>

		<!-- Exclude Products -->
		<tr>
			<th>
				<strong><?php esc_html_e('Exclude Products', 'woocommerce-wholesale-pricing'); ?></strong>
			</th>
			<td>
				<select class="exclude-specific-product wc-enhanced-select" name="exclude_products[]" multiple>
					<?php
					foreach ( $products as $product ) { 
						$product_id = $product->ID;
						$selected = in_array($product_id, (array) $exclude_products) ? 'selected' : '';
						?>
						<option value="<?php echo esc_attr($product_id); ?>" <?php echo esc_attr($selected); ?>>
							<?php echo esc_html($product->post_title); ?>
						</option>
					<?php } ?>
				</select>
			</td>
		</tr>

		<!-- Add Users in Group -->
		<tr>
			<th>
				<strong><?php esc_html_e('Add Users in Group', 'woocommerce-wholesale-pricing'); ?></strong>
			</th>
			<td>
				<select class="wc-enhanced-select" name="add_users_in_group[]" multiple>
					<?php
					foreach ( $users as $user ) {
						$selected = in_array($user->ID, (array) $add_users) ? 'selected' : '';
						echo '<option value="' . esc_attr($user->ID) . '" ' . esc_attr($selected) . '>' . esc_html($user->display_name) . ' (' . esc_html($user->user_email) . ')</option>';
					}
					?>
				</select>
			</td>
		</tr>

		<!-- Discount Type -->
		<tr>
			<th>
				<strong><?php esc_html_e('Discount Type', 'woocommerce-wholesale-pricing'); ?></strong>
			</th>
			<td>
				<select class="wc-enhanced-select" name="discount_type">
					<option value="percent" <?php selected($discount_type, 'percent'); ?>><?php esc_html_e('Percent', 'woocommerce-wholesale-pricing'); ?></option>
					<option value="fixed" <?php selected($discount_type, 'fixed'); ?>><?php esc_html_e('Fixed', 'woocommerce-wholesale-pricing'); ?></option>
				</select>
			</td>
		</tr>

		<!-- Min Quantity -->
		<tr>
			<th>
				<strong><?php esc_html_e('Min Quantity', 'woocommerce-wholesale-pricing'); ?></strong>
			</th>
			<td>
				<input style="padding: 5px;" type="number" name="min_quantity" min="1" value="<?php echo esc_attr($min_quantity); ?>">
			</td>
		</tr>

		<!-- Max Quantity -->
		<tr>
			<th>
				<strong><?php esc_html_e('Max Quantity', 'woocommerce-wholesale-pricing'); ?></strong>
			</th>
			<td>
				<input style="padding: 5px;" type="number" name="max_quantity" min="1" value="<?php echo esc_attr($max_quantity); ?>">
			</td>
		</tr>

		<!-- Wholesale value -->
		<tr>
			<th>
				<strong><?php esc_html_e('Wholesale Value', 'woocommerce-wholesale-pricing'); ?></strong>
			</th>
			<td>
				<input style="padding: 5px;" type="number" name="wwp_group_price" min=".01" step=".01" value="<?php echo esc_attr($wwp_price); ?>">
			</td>
		</tr>
	</tbody>
</table>

<!-- Disable Payment Methods -->
<div>
	<p>
		<strong><?php esc_html_e('Disable Payment Methods', 'woocommerce-wholesale-pricing'); ?></strong>

	</p>
	<p>
		<select class="wc-enhanced-select" name="disable_payment_methods[]" multiple>
			<?php
			foreach ( $payment_gateways as $gateway_id => $gateway ) { 
				if ( empty( $gateway->title ) ) {
					continue;
				}
				$selected = in_array($gateway_id, (array) $disable_payment_methods) ? 'selected' : '';
				?>
				<option value="<?php echo esc_attr($gateway_id); ?>" <?php echo esc_attr($selected); ?>>
					<?php esc_html_e($gateway->title); ?>
				</option>
			<?php } ?>
		</select>
		<p class="description"><?php esc_html_e('Select payment methods to restrict for group members.', 'woocommerce-wholesale-pricing'); ?></p>
	</p>
</div>

<!-- Disable Shipping Methods -->
<div>
	<p>
		<strong><?php esc_html_e('Disable Shipping Methods', 'woocommerce-wholesale-pricing'); ?></strong>
	</p>
	<p>
		<select class="wc-enhanced-select" name="disable_shipping_methods[]" multiple>
			<?php
			foreach ( $shipping_methods as $method_id => $method ) {
				if ( 'pickup_location' == $method_id ) {
					continue; // Skip local pickup as it behaves differently.
				}
				$selected = in_array($method_id, (array) $disable_shipping_methods) ? 'selected' : '';
				?>
				<option value="<?php echo esc_attr($method_id); ?>" <?php echo esc_attr($selected); ?>>
					<?php echo esc_html($method->get_method_title()); ?>
				</option>
			<?php } ?>
		</select>
		<p class="description"><?php esc_html_e('Select shipping methods to restrict for group members.', 'woocommerce-wholesale-pricing'); ?></p>
	</p>
</div>
