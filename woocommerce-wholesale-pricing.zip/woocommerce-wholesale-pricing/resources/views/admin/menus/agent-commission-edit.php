<?php

use WooCommerceWholesalePricing\App\Models\SalesAgent\Commission;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

$settings = WholesaleSettingsHelper::get_pricing_settings();

$general_action = new Commission();
$saved          = $general_action->save_commission_edit();
if ( $saved ) {
	?>
	<div  id="commission-updated" class="updated settings-error notice is-dismissible"> 
		<p>
			<strong> <?php esc_html_e( 'Commission Update successfully', 'woocommerce-wholesale-pricing' ); ?></strong>
		</p>
		<button type="button" class="notice-dismiss">

		</button>
	</div>
	<?php
}
$commission_id       = isset( $_REQUEST['commission_id'] ) ? sanitize_text_field( $_REQUEST['commission_id'] ) : '';
$commission          = $general_action->get_commission_by_id( $commission_id );
$commission          = isset( $commission[0] ) ? $commission[0] : '';
$agent_payout_detail = get_post_meta( $commission->agent_id, 'agent_payout_detail', true );
$payout_method       = isset( $agent_payout_detail['payout-method'] ) ? $agent_payout_detail['payout-method'] : '';
// print_r($commission);
?>

<div class="wrap-btn-top ">
	<h2 class='payment_title'><?php /* translators: %s: payout method */ printf( esc_html__( '%s Commission Edit', 'woocommerce-wholesale-pricing' ), esc_html( ucwords( $payout_method ) ) ); ?> </h2>
	<a href='<?php echo esc_url( admin_url( 'admin.php?page=agent-payout-view&agent_id=' . absint( $commission->agent_id ) ) ); ?>' class='back_payout_btn'><?php echo esc_html__( 'Back to Payout Details', 'woocommerce-wholesale-pricing' ); ?></a>
</div>
<form action="" method="post" class="commission_edit">
	<?php wp_nonce_field( 'save_commission_edit_nonce' ); ?>
	<input name="order_id" class="order_id" type="hidden"  value="<?php echo esc_attr( $commission->order_id ); ?>" size="50" />
	<div class="wrap">
		<table class="widefat" style="margin-top: 20px;">
			<tr><th colspan="2" style="color: #007cba ; font-weight: bold;"><?php esc_html_e( 'Commission Details', 'woocommerce-wholesale-pricing' ); ?></th></tr>
			<tr>
				<th style="width: 30%;"><?php esc_html_e( 'Agent Name', 'woocommerce-wholesale-pricing' ); ?></th>
				<td style="width: 70%">
					<select style="padding: 0 8px; width: 37%;" name="agent-filter" class="wc-agent-select2 agent-filter" data-placeholder="<?php esc_attr_e( 'search by agent name', 'woocommerce-wholesale-pricing' ); ?>" >

						<?php
						$agent_filter = $commission->agent_id;
						$agent_title  = get_the_title( $agent_filter );
						$flags        = ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401;
						?>
						<option value="<?php echo esc_attr( $agent_filter ); ?>" selected="selected"><?php echo esc_html( $agent_title ); ?></option>
												</select>
				</td>
			</tr>

			<tr>
				<th><?php esc_html_e( 'Order No', 'woocommerce-wholesale-pricing' ); ?></th>
				<td>
					<input type="text" readonly value="<?php echo esc_attr( $commission->order_id ); ?>" size="50" />
					<?php /* translators: %s is link  */ ?>
					<p class="description"><?php printf( esc_html__( 'Order edit from %s', 'woocommerce-wholesale-pricing' ), sprintf( '<a href="%s">%s</a>', esc_url( get_edit_post_link( $commission->order_id ) ), esc_html__( 'Here', 'woocommerce-wholesale-pricing' ) ) ); ?></p>
				</td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Order Date', 'woocommerce-wholesale-pricing' ); ?></th>
				<td><input type="text" readonly value="<?php echo esc_attr( $commission->create_date ); ?>" size="50" /></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Commission Type', 'woocommerce-wholesale-pricing' ); ?></th>
				<td><input type="text" readonly value="<?php echo esc_attr( $commission->commission_type ); ?>" size="50" /></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Commission Value', 'woocommerce-wholesale-pricing' ); ?></th>
				<td><input name="commission_amount" class="commission_amount" type="text" readonly value="<?php echo esc_attr( wp_strip_all_tags( wc_price( (float) wp_kses_post( $commission->commission_value ) ) ) ); ?>" size="50" /></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'Commission Status', 'woocommerce-wholesale-pricing' ); ?></th>
				<?php
				$is_payout_allowed = isset( $agent_payout_detail['payout-method'] ) && (
					( 'paypal' === $agent_payout_detail['payout-method'] && isset( $settings['sales_agent_paypal_payout'] ) && 'yes' === $settings['sales_agent_paypal_payout'] ) ||
					( 'bank' === $agent_payout_detail['payout-method'] && isset( $settings['sales_agent_bacs_payout'] ) && 'yes' === $settings['sales_agent_bacs_payout'] )
				);

				/**
				* Filter.
				*
				* @since 1.6
				*/
				$is_payout_allowed = apply_filters( 'allow_agent_payout', $is_payout_allowed, $agent_payout_detail );

				if ( $is_payout_allowed ) {
					?>
										<td>
						<select name="commission_status" class="commission_status" data-placeholder="<?php esc_attr_e( 'commission status', 'woocommerce-wholesale-pricing' ); ?>" style="width: 37%;" >

							<?php
							$commission_status = $commission->commission_status;
							?>
							<option value="pending" <?php selected( 'pending', $commission_status ); ?>><?php esc_html_e( 'Pending', 'woocommerce-wholesale-pricing' ); ?></option>
							<option value="paid"   <?php selected( 'paid', $commission_status ); ?>><?php esc_html_e( 'Paid', 'woocommerce-wholesale-pricing' ); ?></option>
							<option value="cancelled"  <?php selected( 'cancelled', $commission_status ); ?>><?php esc_html_e( 'Cancelled', 'woocommerce-wholesale-pricing' ); ?></option>
						</select>
					</td>
					<?php
				} else {
					?>
					<td>
						<?php echo esc_html__( 'Agent needs to set payout details first.', 'woocommerce-wholesale-pricing' ); ?>
					</td>
					<?php
				}
				?>
			</tr>

		</table>
	</div>


	<div><p class="submit"><input type="submit" name="submit-commission" id="submit" class="button button-primary" value="<?php esc_attr_e( 'Save Changes', 'woocommerce-wholesale-pricing' ); ?>"></p></div>
</form>
