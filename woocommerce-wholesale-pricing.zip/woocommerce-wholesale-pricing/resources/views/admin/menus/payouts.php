<?php
$ListTable = new \WooCommerceWholesalePricing\App\Modules\SalesAgent\ListTable\PayoutListTable();
$ListTable->prepare_items();

?>

<div class="wrap">
	<div id="icon-users" class="icon32"><br/></div>
	<h1 class='wp-heading-inline'><?php esc_html_e( 'Payout List', 'woocommerce-wholesale-pricing' ); ?></h1>
	<input type="hidden" id="page_name" value="<?php echo isset( $_REQUEST['page'] ) ? esc_attr( sanitize_text_field( $_REQUEST['page'] ) ) : ''; ?>" />
	<input type="hidden" id="save_action" value="<?php esc_html_e( 'Save', 'woocommerce-wholesale-pricing' ); ?>" />
	<input type="hidden" id="cancel_action" value="<?php esc_html_e( 'Cancel', 'woocommerce-wholesale-pricing' ); ?>" />
	<div id="commission-filter" method="get">
		<?php $ListTable->display(); ?>
	</div>
</div>