<?php

use WooCommerceWholesalePricing\App\Models\SalesAgent\Commission;
use WooCommerceWholesalePricing\App\Modules\SalesAgent\ListTable\CommissionListTable;

use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

$settings = WholesaleSettingsHelper::get_pricing_settings();

$agent_id            = isset( $_REQUEST['agent_id'] ) ? sanitize_text_field( $_REQUEST['agent_id'] ) : '';
$general_action      = new Commission();
$commission          = $general_action->get_commission_by_id( $agent_id );
$commission          = isset( $commission[0] ) ? $commission[0] : '';
$agent_payout_detail = get_post_meta( $agent_id, 'agent_payout_detail', true );
$payout_method       = isset( $agent_payout_detail['payout-method'] ) ? $agent_payout_detail['payout-method'] : '';
$payout_info         = isset( $agent_payout_detail[ $payout_method ] ) ? $agent_payout_detail[ $payout_method ] : '';
// Create an instance of our package class...
$ListTable = new CommissionListTable();
// Fetch, prepare, sort, and filter our data...
$ListTable->prepare_items();
?>
<div class="wrap">

	<?php
	/**
	 * Filter.
	 *
	 * @since 1.0.4
	 */
	do_action( 'wc_agent_payout_admin_order_details' );
	?>

	<a href='<?php echo esc_url( admin_url( 'admin.php?page=agent-payout' ), 'woocommerce-wholesale-pricing' ); ?>' class='back_payout_btn'><?php echo esc_html__( 'Back to Payout', 'woocommerce-wholesale-pricing' ); ?></a>

	<?php

	if ( is_array( $payout_info ) && ! empty( $payout_info ) && ( ( 'paypal' === $payout_method &&  isset( $settings['sales_agent_paypal_payout'] ) && 'yes' === $settings['sales_agent_paypal_payout'] ) || ( 'bank' === $payout_method && isset( $settings['sales_agent_bacs_payout'] ) && 'yes' === $settings['sales_agent_bacs_payout'] ) ) ) {
		?>
		
		<div class="wrap">

			<h2 class='payment_title'><?php esc_html_e( ucwords( $payout_method ) . ' Payout Detail', 'woocommerce-wholesale-pricing' ); ?> </h2>

			<table class="widefat" style="margin-top: 20px;">

			<?php
			foreach ( $payout_info as $key => $val ) {
				$label = str_replace( '_', ' ', $key );
				?>
				<tr>
					<th><?php esc_html_e( ucwords( $label ), 'woocommerce-wholesale-pricing' ); ?></th>
					<td>
						<input type="text" readonly value="<?php echo esc_attr( $val ); ?>" size="50" />
					</td>
				</tr>
				<?php
			}
			?>
			</table>
		</div>
		<?php
	} else {
		echo '<h3 class="no-payment-detail">' . esc_html__( 'No Payment Detail', 'woocommerce-wholesale-pricing' ) . '</h3>';
	}
	?>
	<?php
	$class = '';
	if ( isset( $_GET['page'] ) && 'agent-payout-view' == $_GET['page'] ) {
		$class = 'nav-tab-active';
	}
	?>
	<br>
	<nav class="nav-tab-wrapper">
		<a href="<?php echo esc_url( admin_url() . 'admin.php?&page=agent-payout-view&agent_id=' . $agent_id ); ?>" class="nav-tab <?php esc_attr_e( $class ); ?>"><?php esc_html_e( 'Commissions List', 'woocommerce-wholesale-pricing' ); ?></a>
	</nav>
	<!-- Forms are NOT created automatically, so you need to wrap the table in one to use features like bulk actions -->
	<?php if ( isset( $_GET['page'] ) && 'agent-payout-view' == $_GET['page'] ) { ?>
		<div id="commission-filter">
			<br>
			<br>
			<h2><?php esc_html_e( 'Commissions List', 'woocommerce-wholesale-pricing' ); ?></h2>
			<?php
			/**
			 * Action.
			 * 
			 * @since 3.2.0
			 */
			do_action( 'before_payout_list_table' );
			wwp_view( 'admin.sales-agent.list-table.commission.wc-customer-filter' );
			/**
			 * Action.
			 * 
			 * @since 3.2.0
			 */
			do_action( 'after_payout_list_table' );
			?>
			<?php $ListTable->display(); ?>
		</div>
	<?php } ?>
	
</div>
<?php
