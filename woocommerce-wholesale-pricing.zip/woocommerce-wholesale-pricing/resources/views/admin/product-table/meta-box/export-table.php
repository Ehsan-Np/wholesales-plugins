<div class="wcpt_export_product_table"> 
	<a class="button-primary export-product-table" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-ajax.php?action=wcpt_export_product_table&post=' . $post_id), 'wcpt_export_product_table')); ?>">
		<?php esc_html_e('Export Product Table', 'woocommerce-wholesale-pricing'); ?>
	</a>
</div>
