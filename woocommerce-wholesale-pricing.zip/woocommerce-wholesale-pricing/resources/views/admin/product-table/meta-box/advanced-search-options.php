<?php
/**
 * Advanced search
 *
 * @package Woocommerce Product Table/metaboxes views
 */
$show_search        = get_post_meta($post_id, 'show_search', true);
$show_filter        = get_post_meta($post_id, 'show_filter', true);
$show_reset         = get_post_meta($post_id, 'display_reset', true);
$product_taxonomies = get_object_taxonomies('product', 'objects');


$saved_filters      = get_post_meta($post_id, 'wcpt_filters_obj', true);
if ($product_taxonomies ) {
$selected_option     = array();
$product_tax_objects = array();

$taxonomy_excluded = array(
	'product_visibility',
	'product_type',
	'product_shipping_class',
);

	foreach ( $product_taxonomies as $k => $product_taxonomy ) {
		if (in_array($k, $taxonomy_excluded, true) ) {
			continue;
		}
		$product_tax_objects[ $k ] = $product_taxonomy->label;
	}
$product_tax_objects['sort_by'] = __('Product Sort By', 'woocommerce-wholesale-pricing');
$product_tax_objects['price'] = __('Product Price', 'woocommerce-wholesale-pricing');
$product_tax_objects['weight'] = __('Product Weight', 'woocommerce-wholesale-pricing');

$product_tax_objects['dem_length'] = __('Dimension Length', 'woocommerce-wholesale-pricing');
$product_tax_objects['dem_width'] = __('Dimension Width', 'woocommerce-wholesale-pricing');
$product_tax_objects['dem_height'] = __('Dimension Height', 'woocommerce-wholesale-pricing');
	if ($saved_filters ) {
		foreach ( $saved_filters as $saved_filter ) {
			$selected_option[ $saved_filter ] = $product_tax_objects[ $saved_filter ];
		}
	}

unset( $product_tax_objects['pa_dimensions'] );

$selected_option = $selected_option + $product_tax_objects;
}
?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_checkbox(
		array(
		'id'    => 'show_search',
		'name'  => 'show_search',
		'label' => __('Search box appears', 'woocommerce-wholesale-pricing'),
		'value' => wc_bool_to_string($show_search),
		)
	);

	woocommerce_wp_text_input(
		array(
		'id'            => 'filter_product_based_term',
		'name'          => 'filter_product_based_term',
		'wrapper_class' => 'show_search_filter',
		'label'         => __('Search Term', 'woocommerce-wholesale-pricing'),
		'desc_tip'      => true,
		'description'   => __('Filter the products by search term when the table loads', 'woo-product-table'),
		'value'         => get_post_meta($post_id, 'filter_product_based_term', true),
		)
	);


	woocommerce_wp_checkbox(
		array(
		'id'    => 'show_filter',
		'name'  => 'show_filter',
		'label' => __('Filter appears', 'woocommerce-wholesale-pricing'),
		'value' => wc_bool_to_string($show_filter),
		)
	);


	if ($product_taxonomies ) {
		woocommerce_wp_select(
			array(
			'id'                => 'wcpt_filters_obj',
			'name'              => 'wcpt_filters_obj[]',
			'class'             => 'wcpt-enhanced-select',
			'wrapper_class'     => 'show_filter',
			'label'             => __('Add filter dropdown lists above the table', 'woocommerce-wholesale-pricing'),
			'options'           => $selected_option,
			'custom_attributes' => array( 'multiple' => 'multiple' ),
			)
		);
	}

	woocommerce_wp_checkbox(
		array(
		'id'            => 'display_reset',
		'name'          => 'display_reset',
		'label'         => __('Show the reset link', 'woocommerce-wholesale-pricing'),
		'wrapper_class' => 'show_filter',
		'value'         => wc_bool_to_string($show_reset),
		)
	);

	woocommerce_wp_select(
		array(
		'id'          => 'wcpt_filters_col',
		'name'        => 'wcpt_filters_col',
		'class'       => 'wcpt-enhanced-select',
		'label'       => __('Customizable column filters', 'woocommerce-wholesale-pricing'),
		'desc_tip'    => true,
		'description' => __('Choose whether clicking on a category, tag or custom taxonomy in the table will perform a filter or load the relevant archive page', 'woocommerce-wholesale-pricing'),
		'options'     => array(
				'perform_filter' => __('Perform a filter', 'woocommerce-wholesale-pricing'),
				'load_archive'   => __('Load the relevant archive page', 'woocommerce-wholesale-pricing'),
		),
		)
	);
	?>
</div>
