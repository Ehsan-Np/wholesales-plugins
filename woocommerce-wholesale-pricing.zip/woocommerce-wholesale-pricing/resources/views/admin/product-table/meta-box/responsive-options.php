<?php
/**
 * Responsive Options
 *
 * @package Woocommerce Product Table/metaboxes views
 */
$mobile_check       = get_post_meta($post_id, 'mobile_icon_chck', true);
$tablet_check       = get_post_meta($post_id, 'tablet_icon_chck', true);
$responsive_checked = get_post_meta($post_id, 'display_responsive', true) ? get_post_meta($post_id, 'display_responsive', true) : 'fully_resp';

$product_table_fields = get_post_meta($post_id, 'product_table_fields', true);

$acceptable_fields = array(
	'id',
	'title',
	'sku',
	'date',
	'price',
	'descr',
	'short_desc',
	'reviews',
	'price',
);

$selected_option        = array();
$selected_mobile_option = array();
$selected_tablet_option = array();
$saved_fields           = get_post_meta($post_id, 'columns_show', true);
$mobile_save_fields     = get_post_meta($post_id, 'columns_mobile_show', true);
$tablet_save_fields     = get_post_meta($post_id, 'columns_tablet_show', true);

if ($product_table_fields ) {
	foreach ( $product_table_fields as $i => $product_table_field ) {
		$field_option[ $product_table_field['woo_ids'] . '_' . $i ] = $product_table_field['woo_label'];
		/*if ( in_array( $product_table_field['woo_ids'], $acceptable_fields, true ) ) {
			
		}*/
	}

	if ($saved_fields ) {
		foreach ( $saved_fields as $saved_field ) {
			$selected[] = (int) substr(strrchr($saved_field, '_'), 1);
		}
		foreach ( $selected as $select ) {
			$selected_option[ $product_table_fields[ $select ]['woo_ids'] . '_' . $select ] = $product_table_fields[ $select ]['woo_label'];
		}
	}
	if ($mobile_save_fields ) {
		foreach ( $mobile_save_fields as $mobile_save_field ) {
			$selected_mobile[] = (int) substr(strrchr($mobile_save_field, '_'), 1);
		}
		foreach ( $selected_mobile as $select ) {
			$selected_mobile_option[ $product_table_fields[ $select ]['woo_ids'] . '_' . $select ] = $product_table_fields[ $select ]['woo_label'];
		}
	}
	if ($tablet_save_fields ) {
		foreach ( $tablet_save_fields as $tablet_save_field ) {
			$selected_tablet[] = (int) substr(strrchr($tablet_save_field, '_'), 1);
		}
		foreach ( $selected_tablet as $select ) {
			$selected_tablet_option[ $product_table_fields[ $select ]['woo_ids'] . '_' . $select ] = $product_table_fields[ $select ]['woo_label'];
		}
	}
	$selected_option        = $selected_option + $field_option;
	$selected_mobile_option = $selected_mobile_option + $field_option;
	$selected_tablet_option = $selected_tablet_option + $field_option;
}
?>
<?php
woocommerce_wp_radio(
	array(
		'id'      => 'display_responsive',
		'name'    => 'display_responsive',
		'label'   => '',
		'class'   => 'wcpt-resp-display',
		'value'   => $responsive_checked,
		'options' => array(
			'fully_resp'      => __(' 100% responsive ', 'woocommerce-wholesale-pricing'),
			'priority_opt'    => __('Controls which columns are hidden on screen sizes when there are too many to fit on the page ', 'woocommerce-wholesale-pricing'),
			'column_breakpts' => __('Choose which columns are shown on different screen sizes and devices', 'woocommerce-wholesale-pricing'),
		),
	)
);
?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_select(
		array(
		'id'                => 'columns_show',
		'name'              => 'columns_show[]',
		'wrapper_class'     => 'wcpt-based-priority',
		'label'             => __('Columns to hide', 'woocommerce-wholesale-pricing'),
		'class'             => 'wcpt-enhanced-select',
		'options'           => $selected_option,
		'custom_attributes' => array( 'multiple' => 'multiple' ),
		)
	);
	?>
	<div class="column-brk-pts">
			<strong><?php esc_html_e('Mobile', 'woocommerce-wholesale-pricing'); ?></strong>
		<?php
		woocommerce_wp_checkbox(
			array(
				'id'    => 'mobile_icon_chck',
				'name'  => 'mobile_icon_chck',
				'label' => __('Show Icon', 'woocommerce-wholesale-pricing'),
				'value' => wc_bool_to_string($mobile_check),
			)
		);

		woocommerce_wp_select(
			array(
				'id'                => 'columns_mobile_show',
				'name'              => 'columns_mobile_show[]',
				'label'             => __('Columns to show in mobile', 'woocommerce-wholesale-pricing'),
				'class'             => 'wcpt-enhanced-select',
				'options'           => $selected_mobile_option,
				'custom_attributes' => array( 'multiple' => 'multiple' ),
			)
		);
		?>
		<strong><?php esc_html_e('Tablet', 'woocommerce-wholesale-pricing'); ?></strong>
		<?php
		woocommerce_wp_checkbox(
			array(
				'id'    => 'tablet_icon_chck',
				'name'  => 'tablet_icon_chck',
				'label' => __('Show Icon', 'woocommerce-wholesale-pricing'),
				'value' => wc_bool_to_string($tablet_check),
			)
		);


		woocommerce_wp_select(
			array(
				'id'                => 'columns_tablet_show',
				'name'              => 'columns_tablet_show[]',
				'label'             => __('Columns to show in tablet', 'woocommerce-wholesale-pricing'),
				'class'             => 'wcpt-enhanced-select',
				'options'           => $selected_tablet_option,
				'custom_attributes' => array( 'multiple' => 'multiple' ),
			)
		);
		?>
	</div>
</div>
