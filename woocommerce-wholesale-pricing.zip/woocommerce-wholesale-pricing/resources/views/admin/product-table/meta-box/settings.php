<?php
/**
 * Settings for product table
 *
 * @package Woocommerce Product Table/Views
 */

use WooCommerceWholesalePricing\App\Services\ProductTable\TableTypeHelper;

$table_fields = get_post_meta($post_id, 'product_table_fields', true);
$taxonomies = get_object_taxonomies('product', 'objects');
$column_names        = array(	'woo_column_ids'               => 'woo_ids',
	'woo_column_name'              => 'woo_label',
	'woo_column_linkable'          => 'woo_linkable',
	'woo_column_expandable'        => 'woo_expandable',
	'woo_column_width'             => 'woo_width_text',
	'woo_column_width_type'        => 'woo_width_type',
	'woo_column_show_stock'        => 'woo_show_stock',
	'woo_column_descr'             => 'woo_descr',
	'woo_column_date_format'       => 'woo_date_format',
	'woo_column_add_types'         => 'woo_add_types',
	'woo_column_add_selected_cart' => 'woo_add_selected_cart',
	'woo_column_quantity'          => 'woo_quantity',
	'woo_column_attrs'             => 'woo_attrs',
	'woo_column_custom_keys'       => 'woo_custom_keys',
	'woo_column_taxonomy'          => 'woo_taxonomy',
);

$mapping_labels = array(
	'id'            => __('ID', 'woocommerce-wholesale-pricing'),
	'title'         => __('Title', 'woocommerce-wholesale-pricing'),
	'sku'           => __('SKU', 'woocommerce-wholesale-pricing'),
	'short_desc'    => __('Short Description', 'woocommerce-wholesale-pricing'),
	'descr'         => __('Description', 'woocommerce-wholesale-pricing'),
	'date'          => __('Date', 'woocommerce-wholesale-pricing'),
	'cat'           => __('Categories', 'woocommerce-wholesale-pricing'),
	'featured_img'  => __('Featured Image', 'woocommerce-wholesale-pricing'),
	'reviews'       => __('Reviews', 'woocommerce-wholesale-pricing'),
	'stock'         => __('Stock', 'woocommerce-wholesale-pricing'),
	'weight'        => __('Weight', 'woocommerce-wholesale-pricing'),
	'dimensions'    => __('Dimensions', 'woocommerce-wholesale-pricing'),
	'price'         => __('Price', 'woocommerce-wholesale-pricing'),
	'cart_button'   => __('Add To Cart Button', 'woocommerce-wholesale-pricing'),
	'attributes'    => __('Attributes', 'woocommerce-wholesale-pricing'),
	'custom_fields' => __('Custom Fields', 'woocommerce-wholesale-pricing'),
	'tags'          => __('Tags', 'woocommerce-wholesale-pricing'),
	'taxonomy'      => __('Taxonomy', 'woocommerce-wholesale-pricing'),
	'quick_view'      => __('Quick View', 'woocommerce-wholesale-pricing'),
);

$is_quick_order_form = TableTypeHelper::is_quick_order_form( $post );

if ( $is_quick_order_form ) {
	$quick_order_columns = array(
		'sku',
		'short_desc',
		'cat',
		'featured_img',
		'stock',
		'weight',
		'dimensions',
		'price',
	);
	$mapping_labels = array_intersect_key( $mapping_labels, array_flip( $quick_order_columns ) );
}

wp_nonce_field('wcpt_settings_display_callback', 'wcpt_settings_display_nonce');

$table_type_value = $is_quick_order_form
	? TableTypeHelper::TABLE_TYPE_QUICK_ORDER_FORM
	: TableTypeHelper::TABLE_TYPE_PRODUCT_TABLE;
?>
<input type="hidden" name="<?php echo esc_attr( TableTypeHelper::POST_KEY_TABLE_TYPE ); ?>" value="<?php echo esc_attr( $table_type_value ); ?>" />
<input type="hidden" name="<?php echo esc_attr( TableTypeHelper::URL_PARAM_TABLE_TYPE ); ?>" value="<?php echo esc_attr( $table_type_value ); ?>" />

<div class="wcpt-sections">
	<section class="wcpt-section columns">
			<h3><?php esc_html_e('Columns', 'woocommerce-wholesale-pricing'); ?></h3>
		<ul class="wcpt-columns-draggable">
			<?php if ($mapping_labels ) { ?>
				<?php foreach ( $mapping_labels as $label_type => $mapping_label ) { ?>
					<li class="ui-state-default" data-type="<?php echo esc_attr($label_type); ?>" data-def-name="<?php echo esc_attr($mapping_label); ?>"><span class="label-title"><?php echo esc_attr($mapping_label); ?></span></li>
				<?php } ?>
			<?php } ?>
		</ul>

		<div id="custom-hidden-fields">
			<?php foreach ( $column_names as $n => $name ) { ?>
				<input type="hidden" data-opt="<?php echo esc_attr($n); ?>" name="<?php echo esc_attr($name); ?>[]" />
			<?php } ?>
		</div>
		<ul class="wcpt-columns-sortable">
			<?php if ($table_fields ) { ?>
				<?php
				foreach ( $table_fields as $i => $field ) {
					?>
					<li class="ui-state-default wcpt-saved-columns" data-type="<?php echo esc_attr($field['woo_ids']); ?>" data-def-name="<?php echo esc_attr($field['woo_label']); ?>"><span class="label-title"><?php echo $field['woo_label'] ? esc_html($field['woo_label']) : esc_html($mapping_labels[ $field['woo_ids'] ]); ?></span>
						<div id="custom-hidden-fields">
					<?php
				
					foreach ( $field as $key => $value ) {
						?>
							<input type="hidden" data-opt="<?php echo esc_attr(array_search($key, $column_names, true)); ?>" name="<?php echo esc_attr($key); ?>[]" value="<?php echo esc_attr($value); ?>"/>
						<?php
					}
					?>
						</div>
					</li>
					<?php
				}
				?>
				<?php
			}
			?>
		</ul>
	</section>

	<div id="dialog" class="woo-setings-dialog">
	<form>

<div class="woo-product-table-field-options">
	<label style="padding:4px; display: block;"><?php esc_html_e('Column name', 'woocommerce-wholesale-pricing'); ?></label>
	<div class="clear"></div>
	<input type="text" class="woo_column_name" value=""/>
	<?php if ( ! $is_quick_order_form ) : ?>		<div class="woo-column-width all-fields-options" style="display:block;">
			<div class="d-flex">
				<label style="padding:4px; display: block;"><?php esc_html_e('Column Width', 'woocommerce-wholesale-pricing'); ?></label>
				<input type="text" class="woo_column_width" value=""/>
				<select name="woo_column_width_type">
					<option value="percent"><?php esc_html_e('%', 'woocommerce-wholesale-pricing'); ?></option>
					<option value="px"><?php esc_html_e('px', 'woocommerce-wholesale-pricing'); ?></option>
				</select>
			</div>
		</div>
	<?php endif; ?>
	<div class="woo-title-img-link all-fields-options">
		
		<label style="padding:4px;"><?php esc_html_e('Linkable', 'woocommerce-wholesale-pricing'); ?></label>
		<select name="woo_column_linkable">
			<option value="" ><?php esc_html_e('No', 'woocommerce-wholesale-pricing'); ?></option>
			<option value="true"><?php esc_html_e('Yes', 'woocommerce-wholesale-pricing'); ?></option>
		</select>

	</div>

	<div class="woo-expand-img-link all-fields-options" >
		<label style="padding:4px;"><?php esc_html_e('Expand Image', 'woocommerce-wholesale-pricing'); ?></label>
		<select name="woo_column_expandable">
			<option value="" ><?php esc_html_e('No', 'woocommerce-wholesale-pricing'); ?></option>
			<option value="true"><?php esc_html_e('Yes', 'woocommerce-wholesale-pricing'); ?></option>
		</select>
	</div>

	<div class="woo-short-descr all-fields-options" >
		<label style="padding:4px; "><?php esc_html_e('Set the length of product description', 'woocommerce-wholesale-pricing'); ?></label>
		<input type="text" class="woo_column_descr" value=""/>
	</div>
	
	<div class="woo-show-stock all-fields-options" >
		<label style="padding:4px; "><?php esc_html_e('Show Stock Level ', 'woocommerce-wholesale-pricing'); ?></label>
		<input type="checkbox" class="woo_column_show_stock" value="1">
	</div>

	<div class="woo-date-format all-fields-options">
		<label style="padding:4px;"><?php esc_html_e('Date Format', 'woocommerce-wholesale-pricing'); ?></label>
		<select name="woo_column_date_format">
			<option value=""><?php esc_html_e('--Select Date Format--', 'woocommerce-wholesale-pricing'); ?></option>
			<option value="F j,Y"><?php echo esc_html(gmdate('F j, Y')); ?></option>
			<option value="Y-m-d"><?php echo esc_html(gmdate('Y-m-d')); ?></option>
			<option value='m/d/Y'><?php echo esc_html(gmdate('m/d/Y') . __(' Month/Day/Year', 'woocommerce-wholesale-pricing')); ?></option>
			<option value='d/m/Y'><?php echo esc_html(gmdate('d/m/Y') . __(' Day/Month/Year', 'woocommerce-wholesale-pricing')); ?></option>
		</select>
	</div>


	<div class="woo-add-cart-options all-fields-options">
		<label style="padding:4px;"><?php esc_html_e('Add to cart button Types', 'woocommerce-wholesale-pricing'); ?></label>
		<select name="woo_column_add_types" id="cart-types">
			<option value="add_button"><?php esc_html_e('Add to cart button', 'woocommerce-wholesale-pricing'); ?></option>
			<option value="add_quick_view_button"><?php esc_html_e('Quick View', 'woocommerce-wholesale-pricing'); ?></option>
			<option value="add_checkbox"><?php esc_html_e('Multi-Select check-boxes', 'woocommerce-wholesale-pricing'); ?></option>
			<option value="add_button_checkbox"><?php esc_html_e('both button and checkbox', 'woocommerce-wholesale-pricing'); ?></option>
		</select>   

		<div class="cart_position">
			<label style="padding:4px;"><?php esc_html_e('Add Selected to Cart button Position', 'woocommerce-wholesale-pricing'); ?></label>
			<select name="woo_column_add_selected_cart">
				<option value="above_add"><?php esc_html_e('above the product table', 'woocommerce-wholesale-pricing'); ?></option>
				<option value="below_add"><?php esc_html_e('below the product table', 'woocommerce-wholesale-pricing'); ?></option>
				<option value="both_add"><?php esc_html_e('both', 'woocommerce-wholesale-pricing'); ?></option>
			</select> 
		</div> 
		<div class="show_quantity_content">
			<label style="padding:4px;"><?php esc_html_e('Show Quantity', 'woocommerce-wholesale-pricing'); ?></label>
			<select name="woo_column_quantity">
				<option value="true"><?php esc_html_e('Yes', 'woocommerce-wholesale-pricing'); ?></option>
				<option value="false"><?php esc_html_e('No', 'woocommerce-wholesale-pricing'); ?></option>
			</select>  
		</div>
	</div>

	<div class="woo-attr-options all-fields-options">
		<label style="padding:4px; display: block;"><?php esc_html_e('Attribute Name', 'woocommerce-wholesale-pricing'); ?></label>
		<input type="text" class="woo_column_attrs" value=""/>
	</div>

	<div class="woo-custom-fields-options all-fields-options">
		<label style="padding:4px; display: block;"><?php esc_html_e('Custom Field Key', 'woocommerce-wholesale-pricing'); ?></label>
		<input type="text" class="woo_column_custom_keys" value=""/>
	</div>


	<div class="woo-tax-options all-fields-options">
		<label style="padding:4px;"><?php esc_html_e('Taxonomy', 'woocommerce-wholesale-pricing'); ?></label>
		<input type="text" class="woo_column_taxonomy" value=""/>
	</div>

</div>
</form>

	</div>


</div>