<?php
/**
 * Control table design settings
 *
 * @package Woocommerce Product Table/metaboxes views
 */
$display_table_design     = !empty(get_post_meta($post_id, 'display_table_design', true)) ? get_post_meta($post_id, 'display_table_design', true) : 'default_design';

$get_external_bdcolor = ( ! empty(get_post_meta($post_id, 'external_bdcolor', true)) ? get_post_meta($post_id, 'external_bdcolor', true) : '#cccccc' );
$get_external_bdsize = get_post_meta($post_id, 'external_bdsize', true);
$get_header_bdcolor = ( ! empty(get_post_meta($post_id, 'header_bdcolor', true)) ? get_post_meta($post_id, 'header_bdcolor', true): '#cccccc' );
$get_header_bdsize = get_post_meta($post_id, 'header_bdsize', true);

$get_footer_bdcolor = ( ! empty(get_post_meta($post_id, 'footer_bdcolor', true)) ? get_post_meta($post_id, 'footer_bdcolor', true): '#cccccc' );
$get_footer_bdsize = get_post_meta($post_id, 'footer_bdsize', true);

$get_border_cells_color = ( ! empty(get_post_meta($post_id, 'border_cells_color', true)) ? get_post_meta($post_id, 'border_cells_color', true): '#cccccc' );
$get_border_cells_size = get_post_meta($post_id, 'border_cells_size', true);
$get_table_header_bg = ( ! empty(get_post_meta($post_id, 'table_header_bg', true)) ? get_post_meta($post_id, 'table_header_bg', true): '#ffffff' );

$get_table_footer_bg = ( ! empty(get_post_meta($post_id, 'table_footer_bg', true)) ? get_post_meta($post_id, 'table_footer_bg', true): '#ffffff' );


$get_table_cell_bg = ( ! empty(get_post_meta($post_id, 'table_cell_bg', true)) ? get_post_meta($post_id, 'table_cell_bg', true): '#f1f1f1' );
$table_header_font_clr = ( ! empty(get_post_meta($post_id, 'table_header_font_clr', true)) ? get_post_meta($post_id, 'table_header_font_clr', true): '#333333' );
$table_header_font_size = get_post_meta($post_id, 'table_header_font_size', true);

$table_footer_font_clr = ( ! empty(get_post_meta($post_id, 'table_footer_font_clr', true)) ? get_post_meta($post_id, 'table_footer_font_clr', true): '#333333' );
$table_footer_font_size = get_post_meta($post_id, 'table_footer_font_size', true);

$table_cell_font = ( ! empty(get_post_meta($post_id, 'table_cell_font', true)) ? get_post_meta($post_id, 'table_cell_font', true): '#333333' );
$table_cell_size = get_post_meta($post_id, 'table_cell_size', true);
?>

<?php

woocommerce_wp_radio(
	array(
		'id'      => 'display_table_design',
		'name'    => 'display_table_design',
		'label'   => '',
		'class'   => 'wcpt_table_design',
		'value'   => $display_table_design,
		'options' => array(
			'default_design'      => __('Default', 'woocommerce-wholesale-pricing'),
			'custom_design'    => __('Custom'),
		),
	)
);
?>
<!-- Custom options -->

<div class ="wcpt_custom_options">
<div class="woocommerce_options_panel">
<?php

	woocommerce_wp_text_input(
		array(
			'id'                => 'external_bdcolor',
			'name'              => 'external_bdcolor',
			'wrapper_class'     => 'wcpt_bdcolor',
			'label'             => __('Borders External', 'woocommerce-wholesale-pricing'),
			'value'                => $get_external_bdcolor,
			'class'             => 'wcpt-design_input',
			'type'               => 'color',
			'desc_tip'          => true,
			'description'       => __('choose external border color and size', 'woocommerce-wholesale-pricing'),

		)
	);
	woocommerce_wp_text_input(
		array(
			'id'                => 'external_bdsize',
			'name'              => 'external_bdsize',
			'wrapper_class'     => 'wcpt_bdsize',
			'label'             => 'Size',
			'value'                => isset($get_external_bdsize) && !empty($get_external_bdsize) ? $get_external_bdsize  : 2,
			'class'             => 'wcpt-design_input',
			'placeholder'        => 'Size',
			'type'               => 'number',
			'custom_attributes' => array(
				'min' => '0',
			),
		)
	);
	?>

</div>

<!-- header Font -->
<div class="woocommerce_options_panel">
<?php
	woocommerce_wp_text_input(
		array(
			'id'                => 'table_header_font_clr',
			'name'              => 'table_header_font_clr',
			'wrapper_class'     => 'wcpt_bdcolor',
			'label'             => __('Header Font', 'woocommerce-wholesale-pricing'),
			'value'                =>$table_header_font_clr,
			'class'             => 'wcpt-design_input',
			'type'               => 'color',
			'desc_tip'          => true,
			'description'       => __('choose header font color and size', 'woocommerce-wholesale-pricing'),

		)
	);
	woocommerce_wp_text_input(
		array(
			'id'                => 'table_header_font_size',
			'name'              => 'table_header_font_size',
			'wrapper_class'     => 'wcpt_bdsize',
			'label'             => 'Size',
			'value'                => isset($table_header_font_size) && !empty($table_header_font_size) ? $table_header_font_size  : 14,
			'class'             => 'wcpt-design_input',
			'placeholder'        => 'Size',
			'type'              => 'number',
			'custom_attributes' => array(
				'min' => '0',
			),
		)
	);
	?>

</div>

<!-- Border header -->
<div class="woocommerce_options_panel ">
<?php
	woocommerce_wp_text_input(
		array(
			'id'                => 'header_bdcolor',
			'name'              => 'header_bdcolor',
			'wrapper_class'     => 'wcpt_bdcolor',
			'label'             => __('Borders Header', 'woocommerce-wholesale-pricing'),
			'value'                => $get_header_bdcolor,
			'class'             => 'wcpt-design_input',
			'type'               => 'color',
			'desc_tip'          => true,
			'description'       => __('choose header border color and size', 'woocommerce-wholesale-pricing'),

		)
	);
	woocommerce_wp_text_input(
		array(
			'id'                => 'header_bdsize',
			'name'              => 'header_bdsize',
			'wrapper_class'     => 'wcpt_bdsize',
			'label'             => 'Size',
			'value'                => isset($get_header_bdsize) && !empty($get_header_bdsize) ? $get_header_bdsize  : 2,
			'class'             => 'wcpt-design_input',
			'placeholder'        => 'Size',
			'type'               => 'number',
			'custom_attributes' => array(
				'min' => '0',
			),
		)
	);
	?>

</div>

<!-- Header background -->
<div class="woocommerce_options_panel">
<?php
woocommerce_wp_text_input(
	array(
		'id'                => 'table_header_bg',
		'name'              => 'table_header_bg',
		'wrapper_class'     => 'wcpt_bg_color',
		'label'             => __('Header Background', 'woocommerce-wholesale-pricing'),
		'value'                => $get_table_header_bg,
		'class'             => 'wcpt-design_input',
		'type'               => 'color',
		'desc_tip'              => true,
		'description'       => __('choose header background color of table', 'woocommerce-wholesale-pricing'),
	)
);
?>
</div>

<!-- Footer Font -->
<div class="woocommerce_options_panel">
<?php
	woocommerce_wp_text_input(
		array(
			'id'                => 'table_footer_font_clr',
			'name'              => 'table_footer_font_clr',
			'wrapper_class'     => 'wcpt_bdcolor',
			'label'             => __('Footer Font', 'woocommerce-wholesale-pricing'),
			'value'                =>$table_footer_font_clr,
			'class'             => 'wcpt-design_input',
			'type'               => 'color',
			'desc_tip'          => true,
			'description'       => __('choose footer font color and size', 'woocommerce-wholesale-pricing'),

		)
	);
	woocommerce_wp_text_input(
		array(
			'id'                => 'table_footer_font_size',
			'name'              => 'table_footer_font_size',
			'wrapper_class'     => 'wcpt_bdsize',
			'label'             => 'Size',
			'value'                => isset($table_footer_font_size) && !empty($table_footer_font_size) ? $table_footer_font_size  : 14,
			'class'             => 'wcpt-design_input',
			'placeholder'        => 'Size',
			'type'              => 'number',
			'custom_attributes' => array(
				'min' => '0',
			),
		)
	);
	?>

</div>

<!-- Border Footer -->
<div class="woocommerce_options_panel ">
<?php
	woocommerce_wp_text_input(
		array(
			'id'                => 'footer_bdcolor',
			'name'              => 'footer_bdcolor',
			'wrapper_class'     => 'wcpt_bdcolor',
			'label'             => __('Borders Footer', 'woocommerce-wholesale-pricing'),
			'value'                => $get_footer_bdcolor,
			'class'             => 'wcpt-design_input',
			'type'               => 'color',
			'desc_tip'          => true,
			'description'       => __('choose footer border color and size', 'woocommerce-wholesale-pricing'),

		)
	);
	woocommerce_wp_text_input(
		array(
			'id'                => 'footer_bdsize',
			'name'              => 'footer_bdsize',
			'wrapper_class'     => 'wcpt_bdsize',
			'label'             => 'Size',
			'value'                => isset($get_footer_bdsize) && !empty($get_footer_bdsize) ? $get_footer_bdsize  : 2,
			'class'             => 'wcpt-design_input',
			'placeholder'        => 'Size',
			'type'               => 'number',
			'custom_attributes' => array(
				'min' => '0',
			),
		)
	);
	?>

</div>

<!-- Footer background -->
<div class="woocommerce_options_panel">
<?php
woocommerce_wp_text_input(
	array(
		'id'                => 'table_footer_bg',
		'name'              => 'table_footer_bg',
		'wrapper_class'     => 'wcpt_bg_color',
		'label'             => __('Footer Background', 'woocommerce-wholesale-pricing'),
		'value'                => $get_table_footer_bg,
		'class'             => 'wcpt-design_input',
		'type'               => 'color',
		'desc_tip'              => true,
		'description'       => __('choose footer background color of table', 'woocommerce-wholesale-pricing'),
	)
);
?>
</div>

<!-- Border cells -->
<div class="woocommerce_options_panel">
<?php
	woocommerce_wp_text_input(
		array(
			'id'                => 'border_cells_color',
			'name'              => 'border_cells_color',
			'wrapper_class'     => 'wcpt_bdcolor',
			'label'             => __('Borders Cells', 'woocommerce-wholesale-pricing'),
			'value'                => $get_border_cells_color,
			'class'             => 'wcpt-design_input',
			'type'               => 'color',
			'desc_tip'          => true,
			'description'       => __('choose border cells color and size', 'woocommerce-wholesale-pricing'),

		)
	);
	woocommerce_wp_text_input(
		array(
			'id'                => 'border_cells_size',
			'name'              => 'border_cells_size',
			'wrapper_class'     => 'wcpt_bdsize',
			'label'             => 'Size',
			'value'                => isset($get_border_cells_size) && !empty($get_border_cells_size) ? $get_border_cells_size  : 0,
			'class'             => 'wcpt-design_input',
			'placeholder'        => 'Size',
			'type'              => 'number',
			'custom_attributes' => array(
				'min' => '0',
			),
		)
	);
	?>

</div>

<!-- Cell background -->
<div class="woocommerce_options_panel">
<?php
woocommerce_wp_text_input(
	array(
		'id'                => 'table_cell_bg',
		'name'              => 'table_cell_bg',
		'wrapper_class'     => 'wcpt_bg_color',
		'label'             => __('Cell Background', 'woocommerce-wholesale-pricing'),
		'value'                => $get_table_cell_bg,
		'class'             => 'wcpt-design_input',
		'type'               => 'color',
		'desc_tip'              => true,
		'description'       => __('choose cell background color of table', 'woocommerce-wholesale-pricing'),
	)
);
?>
</div>

<!-- cell font -->
<div class="woocommerce_options_panel">
<?php
	woocommerce_wp_text_input(
		array(
			'id'                => 'table_cell_font',
			'name'              => 'table_cell_font',
			'wrapper_class'     => 'wcpt_bdcolor',
			'label'             => __('Cell Font', 'woocommerce-wholesale-pricing'),
			'value'                => $table_cell_font,
			'class'             => 'wcpt-design_input',
			'type'               => 'color',
			'desc_tip'          => true,
			'description'       => __('choose header font color and size', 'woocommerce-wholesale-pricing'),

		)
	);
	woocommerce_wp_text_input(
		array(
			'id'                => 'table_cell_size',
			'name'              => 'table_cell_size',
			'wrapper_class'     => 'wcpt_bdsize',
			'label'             => 'Size',
			'value'                => isset($table_cell_size) && !empty($table_cell_size) ? $table_cell_size  : 14,
			'class'             => 'wcpt-design_input',
			'placeholder'        => 'Size',
			'type'              => 'number',
			'custom_attributes' => array(
				'min' => '0',
			),
		)
	);
	?>

</div>
</div>
