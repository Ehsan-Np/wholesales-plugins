<?php
/**
 * One-page checkout
 *
 * @package Woocommerce Product Table/metaboxes views
 */

?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_checkbox(
		array(
		'id'    => 'display_onepage_checkout',
		'name'  => 'display_onepage_checkout',
		'label' => __('Enable One page checkout', 'woocommerce-wholesale-pricing'),
		'value' => wc_bool_to_string(get_post_meta($post_id, 'display_onepage_checkout', true)),
		)
	);

	?>
</div>
