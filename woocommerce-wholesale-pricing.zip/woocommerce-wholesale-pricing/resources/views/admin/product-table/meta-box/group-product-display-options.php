<?php
/**
 * Group list products
 *
 * @package Woocommerce Product Table/metaboxes views
 */

?>
<div class="woocommerce_options_panel">
	<?php
	woocommerce_wp_select(
		array(
		'id'      => 'group_list_view',
		'name'    => 'group_list_view',
		'label'   => __('Controls how group products appear in the table', 'woocommerce-wholesale-pricing'),
		'options' => array(
				''                     => __('--Select the view for group product--', 'woocommerce-wholesale-pricing'),
				'include_group_dp' => __('Include group dropdown', 'woocommerce-wholesale-pricing'),
				'separate_row'         => __('List each group in a separate row', 'woocommerce-wholesale-pricing'),
				'link_button'          => __('Add a "Select Options" button linking to the single product', 'woocommerce-wholesale-pricing'),
		),
		)
	);
	?>
</div>
`