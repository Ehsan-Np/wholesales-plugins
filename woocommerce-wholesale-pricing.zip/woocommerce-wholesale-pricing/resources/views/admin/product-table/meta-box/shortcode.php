<?php echo esc_html("[wc_products_table id=$post->ID]");
