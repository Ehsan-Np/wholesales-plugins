<?php
/**
 * Control which products appear in the table
 *
 * @package Woocommerce Product Table/metaboxes views
 */

use WooCommerceWholesalePricing\App\Services\ProductTable\TableTypeHelper;

$product_ids     = get_post_meta($post_id, 'wcpt_inc_product_ids', true);
$product_exc_ids = get_post_meta($post_id, 'wcpt_ex_product_ids', true);

$product_categories = get_terms('product_cat');
$product_tags       = get_terms('product_tag');

if ($product_categories ) {
	$category_options = array();
	foreach ( $product_categories as $product_category ) {
		$category_options[ $product_category->term_id ] = $product_category->name;
	}
}

if ($product_tags ) {
	$tag_options = array();
	foreach ( $product_tags as $product_tag ) {
		$tag_options[ $product_tag->term_id ] = $product_tag->name;
	}
}

$is_quick_order_form = TableTypeHelper::is_quick_order_form( $post );
?>
<div class="woocommerce_options_panel">
	<?php
	if ($product_categories ) {
		woocommerce_wp_select(
			array(
			'id'                => 'wcpt_inc_product_cats',
			'name'              => 'wcpt_inc_product_cats[]',
			'class'             => 'wcpt-enhanced-select',
			'label'             => __('Included Product categories', 'woocommerce-wholesale-pricing'),
			'options'           => $category_options,
			'custom_attributes' => array( 'multiple' => 'multiple' ),
			)
		);
	}

	woocommerce_wp_select(
		array(
		'id'                => 'wcpt_ex_product_cats',
		'name'              => 'wcpt_ex_product_cats[]',
		'class'             => 'wcpt-enhanced-select',
		'label'             => __('Excluded Product categories', 'woocommerce-wholesale-pricing'),
		'options'           => $category_options,
		'custom_attributes' => array( 'multiple' => 'multiple' ),
		)
	);

	if ($product_tags && ! $is_quick_order_form ) {
		woocommerce_wp_select(
			array(
			'id'                => 'wcpt_inc_product_tags',
			'name'              => 'wcpt_inc_product_tags[]',
			'class'             => 'wcpt-enhanced-select',
			'label'             => __('Included Product Tags', 'woocommerce-wholesale-pricing'),
			'options'           => $tag_options,
			'custom_attributes' => array( 'multiple' => 'multiple' ),
			)
		);
	}


	woocommerce_wp_select(
		array(
		'id'      => 'wcpt_product_status',
		'name'    => 'wcpt_product_status',
		'label'   => __('Stock Status', 'woocommerce-wholesale-pricing'),
		'options' => array(
				''           => __('--Select Stock Status--', 'woocommerce-wholesale-pricing'),
				'instock'    => __('In Stock', 'woocommerce-wholesale-pricing'),
				'outofstock' => __('Out of Stock', 'woocommerce-wholesale-pricing'),
		),
		)
	);
	if ( ! $is_quick_order_form ) {
		woocommerce_wp_textarea_input(
			array(
			'id'          => 'wcpt_inc_product_ids',
			'name'        => 'wcpt_inc_product_ids',
			'label'       => __('Included Products', 'woocommerce-wholesale-pricing'),
			'desc_tip'    => true,
			'description' => __('Include specific products based on their ID by comma separated', 'woocommerce-wholesale-pricing'),
			'value'       => $product_ids ? implode(',', $product_ids) : '',
			)
		);

		woocommerce_wp_textarea_input(
			array(
			'id'          => 'wcpt_ex_product_ids',
			'name'        => 'wcpt_ex_product_ids',
			'label'       => __('Excluded Products', 'woocommerce-wholesale-pricing'),
			'desc_tip'    => true,
			'description' => __('Exclude specific products based on their ID by comma separated', 'woocommerce-wholesale-pricing'),
			'value'       => $product_exc_ids ? implode(',', $product_exc_ids) : '',
			)
		);

		
		woocommerce_wp_select(
			array(
			'id'      => 'wcpt_date_opt',
			'name'    => 'wcpt_date_opt',
			'label'   => __('Choose the products before or after date', 'woocommerce-wholesale-pricing'),
			'options' => array(
			'before' => __('Before the selected date', 'woocommerce-wholesale-pricing'),
			'after'  => __('After the selected date', 'woocommerce-wholesale-pricing'),
			),
			)
		);

		woocommerce_wp_text_input(
			array(
			'id'          => 'wcpt_date',
			'name'        => 'wcpt_date',
			'label'       => __('Date', 'woocommerce-wholesale-pricing'),
			'class'       => 'wcpt-date-picker',
			'desc_tip'    => true,
			'description' => __('Choosing which products appear in the table', 'woocommerce-wholesale-pricing'),
			)
		);
	}
	?>
</div>
