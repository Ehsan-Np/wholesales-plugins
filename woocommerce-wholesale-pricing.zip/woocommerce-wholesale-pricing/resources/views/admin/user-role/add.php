<?php
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;
wp_nonce_field('wwp_tax_exempt_nonce', 'wwp_tax_exempt_nonce');
// version 1.3.0
$settings                 = WholesaleSettingsHelper::get_pricing_settings();
$variable_subscription_id = ! empty($settings['wholesale_subscription']) ? $settings['wholesale_subscription'] : '';
// ends version 1.3.0
?>
<div class="form-field term-tax-wrap">
	<label for="wwp_tax_exmept_wholesaler"><strong><?php esc_html_e('Tax Exempt', 'woocommerce-wholesale-pricing'); ?></strong></label>
	<input type="checkbox" name="wwp_tax_exmept_wholesaler" id="wwp_tax_exmept_wholesaler" value="yes">
	<span><?php esc_html_e('Tax exempt for wholesale user role.', 'woocommerce-wholesale-pricing'); ?></span>
</div>
<div class="form-field role-tax-wrap">
	<label for="wwp_tax_exmept_wholesaler"><strong><?php esc_html_e('Role Tax Exempt', 'woocommerce-wholesale-pricing'); ?></strong></label>
	<select name="wwp_wholesaler_tax_classes" id="wwp_wholesaler_tax_classes" class="">
	<option value=""><?php esc_html_e('Select Tax Class', 'woocommerce-wholesale-pricing'); ?></option>
		<?php 
		$tax_classes = \WC_Tax::get_tax_rate_classes();
		if (!empty($tax_classes) ) {
			foreach ( $tax_classes as $tax_class ) {
				echo '<option value="' . esc_attr($tax_class->slug) . '">' . esc_attr($tax_class->name) . '</option>';
			}
		}
		?>
		</select>
	<br><span><?php esc_html_e('Tax exempt for wholesale user role.', 'woocommerce-wholesale-pricing'); ?></span>
</div>

<div class="form-field term-coupons-wrap">
	<label for="wwp_wholesale_disable_coupons"><strong><?php esc_html_e('Disable Coupons', 'woocommerce-wholesale-pricing'); ?></strong></label>
	<input type="checkbox" name="wwp_wholesale_disable_coupons" id="wwp_wholesale_disable_coupons" value="yes">
	<span><?php esc_html_e('Disable Coupons for wholesale user role.', 'woocommerce-wholesale-pricing'); ?></span>
</div>

<?php if ( isset( $settings['payment_method_name'], $settings['enable_custom_payment_method'] ) && 'yes' === $settings['enable_custom_payment_method'] && ! empty( $settings['payment_method_name'] ) ) : ?>
<strong><?php esc_html_e('Payment Methods', 'woocommerce-wholesale-pricing'); ?></strong>
<?php foreach ( (array) @$settings['payment_method_name'] as $key => $value) { ?>
<div class="form-field payment_method_role_settings" style="padding:3px;">
<input type="checkbox" name="wwp_wholesale_payment_method_name[<?php echo esc_attr($key); ?>]" value="yes">
<span><?php esc_html_e($key, 'woocommerce-wholesale-pricing'); ?></span>
</div>
<?php } ?>
<?php endif; ?>
<?php wwp_view( 'admin.user-role.payment-method-conditions', array( 'is_edit' => false, 'term_id' => 0 ), true ); ?>
<?php wwp_view( 'admin.user-role.purchase-order-gateway', array( 'is_edit' => false, 'term_id' => 0 ), true ); ?>
<div class="form-field term-shipping-wrap">
	<label for="wwp_restricted_smethods_wholesaler">
		<strong><?php esc_html_e( 'Disable Shipping Methods', 'woocommerce-wholesale-pricing' ); ?></strong>
	</label>

	<?php
	// Get all shipping zones
	$shipping_zones = WC_Shipping_Zones::get_zones();

	// Include the "Rest of the World" zone too
	$shipping_zones[0] = array(
		'zone_name'    => __( 'Rest of the world', 'woocommerce' ),
		'shipping_methods' => WC_Shipping_Zones::get_zone( 0 )->get_shipping_methods(),
	);
	?>

	<select name="wwp_restricted_smethods_wholesaler[]" id="wwp_restricted_smethods_wholesaler" data-placeholder="<?php esc_html_e('Select Shipping Methods', 'woocommerce-wholesale-pricing'); ?>" class="regular-text wc-enhanced-select" multiple>
		<?php
		if ( ! empty( $shipping_zones ) ) {
			foreach ( $shipping_zones as $zone_id => $zone_data ) {
				$zone_name = $zone_data['zone_name'];
				$methods   = $zone_data['shipping_methods'];

				if ( ! empty( $methods ) ) {
					echo '<optgroup label="' . esc_html( $zone_name ) . '">';

					foreach ( $methods as $method ) {
						$instance_id   = $method->instance_id;
						$method_title  = $method->get_title();
						$method_label  = sprintf( '%s (%s)', $method_title, $method->method_title );

						echo '<option value="' . esc_attr( $instance_id ) . '">' . esc_html( $method_label ) . '</option>';
					}

					echo '</optgroup>';
				}
			}
		} else {
			echo '<option disabled>' . esc_html__( 'No shipping methods found.', 'woocommerce-wholesale-pricing' ) . '</option>';
		}
		?>
	</select>

	<p><?php esc_html_e( 'Select shipping methods to restrict for wholesale users.', 'woocommerce-wholesale-pricing' ); ?></p>
</div>
<div class="form-field role_password-wrap">
	<div>
		<label for="role_password">
			<strong><?php esc_html_e('Password', 'woocommerce-wholesale-pricing'); ?></strong>
		</label>
	</div>
	<div>
	<div>
	<input name="password" id="role_password" type="password" value="" size="40" aria-required="true" class="" placeholder="**********">
	<button type="button" id="role_password_btn" class="button wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="Show password">
	<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
	<span class="text"><?php esc_html_e('Show', 'woocommerce-wholesale-pricing'); ?></span>
	</button>
	<button type="button" id="genratepassword" class="button" onclick="generatePassword()">
	<span class="text"><?php esc_html_e('Generate Password', 'woocommerce-wholesale-pricing'); ?></span>
	</button>
	</div>
	<p class="description"><?php esc_html_e('Password to access wholesale store.', 'woocommerce-wholesale-pricing'); ?></p>
	</div>
</div>
<?php
$registrations           = WholesaleSettingsHelper::get_registration_settings();
$role_approval_enabled   = isset( $registrations['extra_role_fields'] ) && 'yes' === $registrations['extra_role_fields'];
$role_approval_style     = $role_approval_enabled ? '' : 'opacity:0.6;pointer-events:none;';
?>
<div class="form-field term-user-request-approval-wrap" <?php echo $role_approval_style ? 'style="' . esc_attr( $role_approval_style ) . '"' : ''; ?>>
	<label><strong><?php esc_html_e( 'User Request Approval', 'woocommerce-wholesale-pricing' ); ?></strong></label>
	<p>
		<label>
			<input type="radio" name="wwp_user_request_approval" value="auto" <?php disabled( ! $role_approval_enabled ); ?>>
			<?php esc_html_e( 'Auto', 'woocommerce-wholesale-pricing' ); ?>
		</label>
		<label>
			<input type="radio" name="wwp_user_request_approval" value="manual" <?php checked( true ); ?> <?php disabled( ! $role_approval_enabled ); ?>>
			<?php esc_html_e( 'Manual', 'woocommerce-wholesale-pricing' ); ?>
		</label>
	</p>
	<p class="description"><?php esc_html_e( 'Choose whether users are approved automatically or require admin approval.', 'woocommerce-wholesale-pricing' ); ?></p>
	<?php if ( ! $role_approval_enabled ) : ?>
		<p class="description">
			<?php esc_html_e( 'These settings work when Enable User Role is checked in Wholesale → Registration Settings → Other Fields.', 'woocommerce-wholesale-pricing' ); ?>
		</p>
	<?php endif; ?>
</div>
<?php
if (! empty($variable_subscription_id) && 'publish' == get_post_status($variable_subscription_id) ) {
	$product    = wc_get_product($variable_subscription_id);
	if (! $product->is_type('simple') ) {
		$variations = $product->get_available_variations();
		$variations = wwp_exclude_variations($variations); 
		?>
		<div class="form-field term-subscription-wrap">
			<label for="wwp_wholesaler_subscription"><?php esc_html_e('Select Subscription Variation', 'woocommerce-wholesale-pricing'); ?></label>
			<select name="wwp_wholesaler_subscription" id="wwp_wholesaler_subscription">
				<option value=""><?php esc_html_e('Select Subscription Variation', 'woocommerce-wholesale-pricing'); ?></option>
					<?php foreach ( $variations as $key => $variation ) { ?> 
						<option value="<?php echo esc_attr($variation['variation_id']); ?>"><?php echo esc_attr(implode(',', $variation['attributes'])); ?></option>
					<?php } ?>
			</select>
			<p><?php esc_html_e('On the purchase of the selected variation the users will be assigned this role.', 'woocommerce-wholesale-pricing'); ?></p>
		</div>
		<?php
	}
}
