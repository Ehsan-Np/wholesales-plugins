<?php

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
echo esc_html( wp_strip_all_tags( $email_heading ) );
echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

/* translators: $s: CustomerName */
echo esc_html__( sprintf( 'You’ve received the new order from %s.', $customer_name ), 'woocommerce-wholesale-pricing' ) . "\n\n";

/* translators: %1$s: AgentName, %2$s:CommissionAmmount , %3$s: OrderID */
echo esc_html__( sprintf( '%1$s will receive %2$s for  Order: #%3$s.', $agent_name, $commission_amount, $order_id ), 'woocommerce-wholesale-pricing' ) . "\n\n";

if ( $additional_content ) {
	echo esc_html( wp_strip_all_tags( wptexturize( $additional_content ) ) );
}
