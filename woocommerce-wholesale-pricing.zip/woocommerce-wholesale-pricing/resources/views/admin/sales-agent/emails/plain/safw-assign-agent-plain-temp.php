<?php

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
echo esc_html( wp_strip_all_tags( $email_heading ) );
echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

/* translators: %s: UserName */
echo esc_html__( sprintf( 'Dear %s,', $user_name ), 'woocommerce-wholesale-pricing' ) . "\n\n";

/* translators: %1\$s: AgentName, %2\$s: CommissionCategory */
echo esc_html__( sprintf( "Congratulations! you have been assigned a new role as a Sales Agent! Your sales agent name is %1\$s. You've been assigned to the %2\$s category.", $agent_name, $commission_category ), 'woocommerce-wholesale-pricing' ) . "\n\n";

if ( $additional_content ) {
	echo esc_html( wp_strip_all_tags( wptexturize( $additional_content ) ) );
}
