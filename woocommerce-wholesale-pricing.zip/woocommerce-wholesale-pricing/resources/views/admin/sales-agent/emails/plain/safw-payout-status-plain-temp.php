<?php

echo "=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n";
echo esc_html( wp_strip_all_tags( $email_heading ) );
echo "\n=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=\n\n";

/* translators: $s: AgentName */
echo esc_html__( sprintf( 'Dear %s,', $agent_name ), 'woocommerce-wholesale-pricing' ) . "\n\n";

/* translators: $s: PayoutAmmount */
echo esc_html__( sprintf( 'Your %s commission amount has been paid. You will receive the commission shortly.', $payout_amount ), 'woocommerce-wholesale-pricing' ) . "\n\n";

if ( $additional_content ) {
	echo esc_html( wp_strip_all_tags( wptexturize( $additional_content ) ) );
}
