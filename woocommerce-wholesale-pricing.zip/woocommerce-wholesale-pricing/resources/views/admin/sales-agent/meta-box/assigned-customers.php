
<div id="customer_based_commission_section" style="display: block;">

	<?php
	$general_action = new \WooCommerceWholesalePricing\App\Models\SalesAgent\Agent();

	// Pagination settings
	$total_per_page = 10;
	$all_pages    = isset($_REQUEST['paged']) ? max(1, intval($_REQUEST['paged'])) : 1;

	// Retrieve paginated data
	$customer_commission_list = get_option('customer_commission_list', true);
	$data                     = $general_action->query($total_per_page, $all_pages, true, get_the_ID());
	if ( ! isset( $data['users'] ) || empty( $data['users'] ) ) : ?>
	<p>No customers assigned to this agent.</p>
	<?php else : ?>
		<table class="wp-list-table widefat fixed striped customer-commission-table">
			<thead>
				<tr>
					<th style="width:7%;"><?php esc_html_e('Customer ID', 'woocommerce-wholesale-pricing'); ?></th>
					<th style="width:20%;"><?php esc_html_e('Customer', 'woocommerce-wholesale-pricing'); ?></th>
					<th style="width:10%;"><?php esc_html_e('Total Amount', 'woocommerce-wholesale-pricing'); ?></th>
					<th style="width:10%;"><?php esc_html_e('Total Orders', 'woocommerce-wholesale-pricing'); ?></th>
					<th style="width:10%;"><?php esc_html_e('Total Commissions', 'woocommerce-wholesale-pricing'); ?></th>
				</tr>
			</thead>
	
			<tbody>
				<?php
				if (!empty($data['users']) && is_array($data['users'])) {
	
					foreach ($data['users'] as $user) {
						$user_id = $user->ID;
	
						$order_details = $general_action->get_customer_total_order($user_id, get_the_ID());
						$name          = $user->data->display_name;
						$total_amount  = $order_details['total'];
						$total_orders  = $order_details['count'];
	
						global $wpdb;
						$agent_id = $post->ID;
	
						// Fetch commissions for this customer
						$customer_commissions = array();
						$commissions          = $wpdb->get_results(
							$wpdb->prepare(
								"SELECT * FROM {$wpdb->prefix}wc_agents_commissions WHERE agent_id = %d",
								$agent_id
							)
						);
	
						foreach ($commissions as $commission) {
							$order_id = $commission->order_id;
	
							$agent_order = $wpdb->get_row(
								$wpdb->prepare(
									"SELECT customer_id FROM {$wpdb->prefix}wc_orders WHERE id = %d",
									$order_id
								)
							);

							if ($agent_order && $agent_order->customer_id) {
								if (!isset($customer_commissions[$agent_order->customer_id])) {
									$customer_commissions[$agent_order->customer_id] = 0;
								}

								$customer_commissions[$agent_order->customer_id] += floatval($commission->commission_value);
							}
	
							
						}
	
						$total_commissions = isset($customer_commissions[$user_id])
							? number_format($customer_commissions[$user_id], 2)
							: 'N/A';
	
						$agent_id             = get_the_ID();
						$customer_commission = isset($customer_commission_list[$agent_id][$user_id]) ? $customer_commission_list[$agent_id][$user_id] : 'N/A';

						?>
	
						<tr>
							<td>
								<a href="<?php echo esc_url(get_edit_user_link($user_id)); ?>" target="_blank" style="text-decoration: underline;">
									<?php echo esc_html($user_id); ?>
								</a>
							</td>
							<td><?php echo esc_html($name); ?> <br> <?php echo esc_html($user->data->user_email); ?></td>
							<td><?php echo wp_kses_post( wc_price( $total_amount ) ); ?></td>
							<td><?php echo esc_html($total_orders); ?></td>
							<td><?php echo wp_kses_post(wc_price( $total_commissions )); ?></td>
						</tr>
	
						<?php
					}
				} else {
					echo '<tr><td colspan="11">' . esc_html__('No customers found.', 'woocommerce-wholesale-pricing') . '</td></tr>';
				}
				?>
			</tbody>
		</table>
		<?php
		// Pagination
		$total_users = isset($data['total_items']) ? intval($data['total_items']) : 0;
		$total_pages = $total_users > 0 ? ceil($total_users / $total_per_page) : 1;

		if ($total_pages > 1) {
			echo '<div class="tablenav bottom">';
			echo '<div class="tablenav-pages">';

			echo wp_kses_post(
				paginate_links(array(
				'base'      => admin_url('post.php?post=' . get_the_ID() . '&action=edit&paged=%#%'),
				'format'    => '',
				'prev_text' => __('« Prev', 'woocommerce-wholesale-pricing'),
				'next_text' => __('Next »', 'woocommerce-wholesale-pricing'),
				'current'   => $all_pages,
				'total'     => $total_pages,
				))
			);

			echo '</div></div>';
		}
		?>
	<?php endif; ?>


</div>