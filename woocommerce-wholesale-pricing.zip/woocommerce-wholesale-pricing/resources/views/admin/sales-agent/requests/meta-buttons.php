<ul id="blkTabs" class="nav nav-tabs">
	<li role="presentation">
		<a href="<?php echo esc_url( admin_url('edit.php?post_type=wwp_requests') ); ?>" class="<?php echo in_array( $current_screen->id, array( 'edit-wwp_requests', 'wwp_requests' ) ) ? 'active' : ''; ?>"><?php esc_html_e( 'Wholesale Registration Requests', 'woocommerce-wholesale-pricing' ); ?></a>
	</li>
	<li role="presentation">
		<a href="<?php echo esc_url( admin_url('edit.php?post_type=agent_approval') ); ?>" class="<?php echo in_array( $current_screen->id, array( 'edit-agent_approval', 'agent_approval' ) ) ? 'active' : ''; ?>"><?php esc_html_e( 'Sales Agent Registration Requests', 'woocommerce-wholesale-pricing' ); ?></a>
	</li>
</ul>