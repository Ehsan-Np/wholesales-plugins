<?php
/**
 * Companies list table wholesale role filter.
 *
 * @package WooCommerceWholesalePricing
 */

$selected_role = isset( $_GET['ccp_wholesale_role_id'] ) ? absint( $_GET['ccp_wholesale_role_id'] ) : 0;
$wholesale_roles = get_terms(
	array(
		'taxonomy'   => 'wholesale_user_roles',
		'hide_empty' => false,
	)
);
?>
<select name="ccp_wholesale_role_id" id="ccp_wholesale_role_id" class="wwp-ccp-filter-select">
	<option value=""><?php esc_html_e( 'All Wholesale Roles', 'woocommerce-wholesale-pricing' ); ?></option>
	<?php if ( ! is_wp_error( $wholesale_roles ) && ! empty( $wholesale_roles ) ) : ?>
		<?php foreach ( $wholesale_roles as $wwp_role ) : ?>
			<option value="<?php echo esc_attr( $wwp_role->term_id ); ?>" <?php selected( $selected_role, $wwp_role->term_id ); ?>><?php echo esc_html( $wwp_role->name ); ?></option>
		<?php endforeach; ?>
	<?php endif; ?>
</select>
