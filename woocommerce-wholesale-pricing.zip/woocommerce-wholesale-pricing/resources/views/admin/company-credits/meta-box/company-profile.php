<?php
/**
 * Company profile metabox.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 */

$ccp_company_email    = get_post_meta( $post_id, 'ccp_company_email', true );
$ccp_wholesale_role_id = get_post_meta( $post_id, 'ccp_wholesale_role_id', true );
$wholesale_roles      = get_terms(
	array(
		'taxonomy'   => 'wholesale_user_roles',
		'hide_empty' => false,
	)
);
?>
<div class="wwp-ccp-metabox">

	<p class="wwp-ccp-field">
		<label for="ccp_company_email"><?php esc_html_e( 'Email Address', 'woocommerce-wholesale-pricing' ); ?></label>
		<input type="email" class="widefat" id="ccp_company_email" name="ccp_company_email" value="<?php echo esc_attr( $ccp_company_email ); ?>" placeholder="<?php esc_attr_e( 'contact@company.com', 'woocommerce-wholesale-pricing' ); ?>" required>
	</p>

	<p class="wwp-ccp-field">
		<label for="ccp_wholesale_role_id"><?php esc_html_e( 'Wholesale Pricing', 'woocommerce-wholesale-pricing' ); ?></label>
		<select class="widefat" id="ccp_wholesale_role_id" name="ccp_wholesale_role_id" required>
			<option value=""><?php esc_html_e( 'Select wholesale role', 'woocommerce-wholesale-pricing' ); ?></option>
			<?php if ( ! is_wp_error( $wholesale_roles ) && ! empty( $wholesale_roles ) ) : ?>
				<?php foreach ( $wholesale_roles as $wwp_role ) : ?>
					<option value="<?php echo esc_attr( $wwp_role->term_id ); ?>" <?php selected( $ccp_wholesale_role_id, $wwp_role->term_id ); ?>><?php echo esc_html( $wwp_role->name ); ?></option>
				<?php endforeach; ?>
			<?php endif; ?>
		</select>
	</p>
</div>
