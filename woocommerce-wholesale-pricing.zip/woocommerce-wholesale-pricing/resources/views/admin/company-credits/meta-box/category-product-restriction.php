<?php
/**
 * Category/product restriction metabox.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 */

$restriction_type      = get_post_meta( $post_id, 'ccp_restriction_type', true );
$restricted_products   = get_post_meta( $post_id, 'ccp_restricted_products', true );
$restricted_categories = get_post_meta( $post_id, 'ccp_restricted_categories', true );

if ( empty( $restriction_type ) ) {
	$restriction_type = 'all_products';
}
if ( ! is_array( $restricted_products ) ) {
	$restricted_products = array();
}
if ( ! is_array( $restricted_categories ) ) {
	$restricted_categories = array();
}

$show_specific = in_array( $restriction_type, array( 'include', 'exclude' ), true );
?>
<div class="wwp-ccp-metabox wwp-ccp-restrictions">
	<p class="description"><?php esc_html_e( 'Restrict credit usage for purchasing specific products or categories.', 'woocommerce-wholesale-pricing' ); ?></p>

	<fieldset class="wwp-ccp-radio-group">
		<label><input type="radio" name="ccp_restriction_type" value="all_products" <?php checked( 'all_products', $restriction_type ); ?>> <?php esc_html_e( 'All Products', 'woocommerce-wholesale-pricing' ); ?></label><br>
		<label><input type="radio" name="ccp_restriction_type" value="all_categories" <?php checked( 'all_categories', $restriction_type ); ?>> <?php esc_html_e( 'All Categories', 'woocommerce-wholesale-pricing' ); ?></label><br>
		<label><input type="radio" name="ccp_restriction_type" value="include" <?php checked( 'include', $restriction_type ); ?>> <?php esc_html_e( 'Include Specific Products/Categories', 'woocommerce-wholesale-pricing' ); ?></label><br>
		<label><input type="radio" name="ccp_restriction_type" value="exclude" <?php checked( 'exclude', $restriction_type ); ?>> <?php esc_html_e( 'Exclude Specific Products/Categories', 'woocommerce-wholesale-pricing' ); ?></label>
	</fieldset>

	<div class="wwp-ccp-restriction-fields" <?php echo $show_specific ? '' : 'style="display:none;"'; ?>>
		<p class="wwp-ccp-field">
			<label for="ccp_restricted_products"><?php esc_html_e( 'Products', 'woocommerce-wholesale-pricing' ); ?></label>
			<select multiple="multiple" class="wc-product-search wwp-ccp-product-select" id="ccp_restricted_products" name="ccp_restricted_products[]" data-placeholder="<?php esc_attr_e( 'Select products...', 'woocommerce-wholesale-pricing' ); ?>" style="width:100%;">
				<?php foreach ( $restricted_products as $product_id ) : ?>
					<?php $product = wc_get_product( $product_id ); ?>
					<?php if ( $product ) : ?>
						<option value="<?php echo esc_attr( $product_id ); ?>" selected="selected"><?php echo esc_html( $product->get_formatted_name() ); ?></option>
					<?php endif; ?>
				<?php endforeach; ?>
			</select>
		</p>

		<p class="wwp-ccp-field">
			<label for="ccp_restricted_categories"><?php esc_html_e( 'Categories', 'woocommerce-wholesale-pricing' ); ?></label>
			<select multiple="multiple" class="wc-category-search wwp-ccp-category-select" id="ccp_restricted_categories" name="ccp_restricted_categories[]" data-placeholder="<?php esc_attr_e( 'Search for a category&hellip;', 'woocommerce-wholesale-pricing' ); ?>" data-action="woocommerce_json_search_categories" data-exclude="" style="width:100%;">
				<?php foreach ( $restricted_categories as $restricted_cat_id ) : ?>
					<?php $restricted_term = get_term( absint( $restricted_cat_id ), 'product_cat' ); ?>
					<?php if ( $restricted_term && ! is_wp_error( $restricted_term ) ) : ?>
						<option value="<?php echo esc_attr( $restricted_term->slug ); ?>" selected="selected"><?php echo esc_html( $restricted_term->name . ' (#' . $restricted_term->term_id . ')' ); ?></option>
					<?php endif; ?>
				<?php endforeach; ?>
			</select>
		</p>
	</div>

	<p class="description"><?php esc_html_e( 'Credits can ONLY be used to purchase the selected products/categories.', 'woocommerce-wholesale-pricing' ); ?></p>
</div>
