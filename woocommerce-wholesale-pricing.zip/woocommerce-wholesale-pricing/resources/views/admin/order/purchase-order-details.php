<?php
/**
 * Admin order Purchase Order details.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var string $po_number        Saved PO number.
 * @var bool   $require_number  Whether number should be shown.
 * @var bool   $allow_upload    Whether document row should be shown.
 * @var string $attachment_url  Document URL.
 * @var string $attachment_name Document filename.
 */

$po_number        = isset( $po_number ) ? (string) $po_number : '';
$require_number  = ! empty( $require_number );
$allow_upload    = ! empty( $allow_upload );
$attachment_url  = isset( $attachment_url ) ? (string) $attachment_url : '';
$attachment_name = isset( $attachment_name ) ? (string) $attachment_name : '';
?>
<div class="wwp-po-order-details">
	<h3><?php esc_html_e( 'Purchase Order', 'woocommerce-wholesale-pricing' ); ?></h3>
	<?php if ( $require_number || '' !== $po_number ) : ?>
		<p>
			<strong><?php esc_html_e( 'PO number:', 'woocommerce-wholesale-pricing' ); ?></strong>
			<?php echo '' !== $po_number ? esc_html( $po_number ) : '&mdash;'; ?>
		</p>
	<?php endif; ?>
	<?php if ( $allow_upload || $attachment_url ) : ?>
		<p>
			<strong><?php esc_html_e( 'PO document:', 'woocommerce-wholesale-pricing' ); ?></strong>
			<?php if ( $attachment_url ) : ?>
				<a href="<?php echo esc_url( $attachment_url ); ?>" target="_blank" rel="noopener noreferrer">
					<?php echo esc_html( $attachment_name ? $attachment_name : __( 'Download document', 'woocommerce-wholesale-pricing' ) ); ?>
				</a>
			<?php else : ?>
				&mdash;
			<?php endif; ?>
		</p>
	<?php endif; ?>
</div>
