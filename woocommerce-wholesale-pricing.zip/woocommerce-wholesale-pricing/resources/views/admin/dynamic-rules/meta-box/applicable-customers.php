<?php
/**
 * Applicable Customers metabox.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 * @var array   $rule    Rule meta.
 */

$b2c_customer    = isset( $rule['b2c_customer'] ) ? $rule['b2c_customer'] : 'no';
$guest_users     = isset( $rule['guest_users'] ) ? $rule['guest_users'] : 'no';
$specific_users  = isset( $rule['specific_users'] ) && is_array( $rule['specific_users'] ) ? $rule['specific_users'] : array();
$is_change_group = isset( $rule['rule_type'] ) && 'change-group' === $rule['rule_type'];
?>
<div class="wwp-dr-applicable-customers" <?php echo $is_change_group ? 'style="display:none;"' : ''; ?>>
	<div class="wwp-dr-customer-types">
		<input type="hidden" name="wwp_dynamic_rule[b2c_customer]" value="no" />
		<p>
			<input
				class="inp-cbx wwp-dr-b2c-customer"
				id="wwp_dr_b2c_customer"
				type="checkbox"
				value="yes"
				name="wwp_dynamic_rule[b2c_customer]"
				<?php checked( 'yes', $b2c_customer ); ?>
			/>
			<label class="cbx cbx-square" for="wwp_dr_b2c_customer">
				<span><?php esc_html_e( 'B2C (retail) customer', 'woocommerce-wholesale-pricing' ); ?></span>
			</label>
		</p>

		<input type="hidden" name="wwp_dynamic_rule[guest_users]" value="no" />
		<p>
			<input
				class="inp-cbx wwp-dr-guest-users"
				id="wwp_dr_guest_users"
				type="checkbox"
				value="yes"
				name="wwp_dynamic_rule[guest_users]"
				<?php checked( 'yes', $guest_users ); ?>
			/>
			<label class="cbx cbx-square" for="wwp_dr_guest_users">
				<span><?php esc_html_e( 'Guest users (not logged in)', 'woocommerce-wholesale-pricing' ); ?></span>
			</label>
		</p>
	</div>

	<p>
		<label for="wwp_dr_specific_users"><strong><?php esc_html_e( 'Specific users', 'woocommerce-wholesale-pricing' ); ?></strong></label>
	</p>
	<p>
		<select
			multiple="multiple"
			class="wc-customer-search wwp-dr-specific-users"
			id="wwp_dr_specific_users"
			name="wwp_dynamic_rule[specific_users][]"
			data-placeholder="<?php esc_attr_e( 'Search for a customer&hellip;', 'woocommerce-wholesale-pricing' ); ?>"
		>
			<?php foreach ( $specific_users as $user_id ) : ?>
				<?php
				$user = get_user_by( 'id', absint( $user_id ) );
				if ( ! $user ) {
					continue;
				}
				$user_string = sprintf(
					/* translators: 1: display name, 2: user ID, 3: email */
					esc_html__( '%1$s (#%2$s &ndash; %3$s)', 'woocommerce-wholesale-pricing' ),
					$user->display_name,
					absint( $user->ID ),
					$user->user_email
				);
				?>
				<option value="<?php echo esc_attr( $user_id ); ?>" selected="selected"><?php echo wp_kses_post( $user_string ); ?></option>
			<?php endforeach; ?>
		</select>
		<br />
		<small class="description">
			<?php esc_html_e( 'Leave empty to apply to everyone matching the roles, groups and customer types above.', 'woocommerce-wholesale-pricing' ); ?>
		</small>
	</p>
</div>
