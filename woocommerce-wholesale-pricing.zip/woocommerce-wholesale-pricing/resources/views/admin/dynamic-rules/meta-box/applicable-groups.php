<?php
/**
 * Applicable Groups metabox.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 * @var array   $rule    Rule meta.
 */

use WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMetaHelper;

$groups_enabled  = RuleMetaHelper::is_groups_enabled();
$apply_all_groups = isset( $rule['apply_all_groups'] ) ? $rule['apply_all_groups'] : 'yes';
$selected_groups  = isset( $rule['groups'] ) && is_array( $rule['groups'] ) ? array_map( 'absint', $rule['groups'] ) : array();
$is_change_group  = isset( $rule['rule_type'] ) && 'change-group' === $rule['rule_type'];

if ( ! $groups_enabled ) {
	echo '<p class="description">' . esc_html__( 'Wholesale groups are disabled. Enable groups in Wholesale Settings to use this option.', 'woocommerce-wholesale-pricing' ) . '</p>';
	return;
}

$wholesale_groups = get_posts(
	array(
		'post_type'      => wwp_env()->get( 'group_slug' ),
		'posts_per_page' => -1,
		'post_status'    => 'publish',
		'orderby'        => 'title',
		'order'          => 'ASC',
	)
);
?>
<div class="wwp-dr-applicable-groups" <?php echo $is_change_group ? 'style="display:none;"' : ''; ?>>
	<p>
		<input
			class="inp-cbx wwp-dr-apply-all-groups"
			id="wwp_dr_apply_all_groups"
			type="checkbox"
			value="yes"
			name="wwp_dynamic_rule[apply_all_groups]"
			<?php checked( 'yes', $apply_all_groups ); ?>
		/>
		<label class="cbx cbx-square" for="wwp_dr_apply_all_groups">
			<span><?php esc_html_e( 'Apply to all groups', 'woocommerce-wholesale-pricing' ); ?></span>
		</label>
	</p>
	<p class="description">
		<?php esc_html_e( 'Uses members and products from wholesale group settings. Uncheck to pick specific groups, or leave checked to use every group.', 'woocommerce-wholesale-pricing' ); ?>
	</p>

	<div class="wwp-dr-groups-list" <?php echo ( 'yes' === $apply_all_groups ) ? 'style="opacity:0.5;pointer-events:none;"' : ''; ?>>
		<?php if ( empty( $wholesale_groups ) ) : ?>
			<p class="description"><?php esc_html_e( 'No wholesale groups found.', 'woocommerce-wholesale-pricing' ); ?></p>
		<?php else : ?>
			<?php foreach ( $wholesale_groups as $group_post ) : ?>
				<p>
					<input
						class="inp-cbx wwp-dr-group-checkbox"
						id="wwp_dr_group_<?php echo esc_attr( $group_post->ID ); ?>"
						type="checkbox"
						value="<?php echo esc_attr( $group_post->ID ); ?>"
						name="wwp_dynamic_rule[groups][]"
						<?php checked( in_array( (int) $group_post->ID, $selected_groups, true ) ); ?>
					/>
					<label class="cbx cbx-square" for="wwp_dr_group_<?php echo esc_attr( $group_post->ID ); ?>">
						<span><?php echo esc_html( $group_post->post_title ); ?></span>
					</label>
				</p>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>
</div>
