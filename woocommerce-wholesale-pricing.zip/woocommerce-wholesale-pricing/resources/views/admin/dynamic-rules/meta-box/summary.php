<?php
/**
 * Summary metabox (side).
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 * @var array   $rule    Rule meta.
 */

use WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMetaHelper;

$summary = RuleMetaHelper::build_summary( $rule );

$labels = array(
	'type'           => __( 'Type', 'woocommerce-wholesale-pricing' ),
	'applies_to'     => __( 'Applies to', 'woocommerce-wholesale-pricing' ),
	'roles'          => __( 'Roles', 'woocommerce-wholesale-pricing' ),
	'groups'         => __( 'Groups', 'woocommerce-wholesale-pricing' ),
	'customers'      => __( 'Customers', 'woocommerce-wholesale-pricing' ),
	'specific_users' => __( 'Specific users', 'woocommerce-wholesale-pricing' ),
);
?>
<div id="wwp-dr-summary" class="wwp-dr-summary">
	<?php foreach ( $labels as $key => $label ) : ?>
		<p class="wwp-dr-summary-row">
			<strong><?php echo esc_html( $label ); ?>:</strong>
			<span class="wwp-dr-summary-value" data-summary-key="<?php echo esc_attr( $key ); ?>">
				<?php echo esc_html( isset( $summary[ $key ] ) ? $summary[ $key ] : '—' ); ?>
			</span>
		</p>
	<?php endforeach; ?>
</div>
