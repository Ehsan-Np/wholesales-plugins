<?php
/**
 * Rule Settings metabox.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int     $post_id Post ID.
 * @var WP_Post $post    Post object.
 * @var array   $rule    Rule meta.
 */

use WooCommerceWholesalePricing\App\Services\DynamicRules\RuleMetaHelper;

$groups_enabled     = RuleMetaHelper::is_groups_enabled();
$rule_type_options  = RuleMetaHelper::get_rule_type_options( $groups_enabled );
$applies_to_options = RuleMetaHelper::get_applies_to_options();
$condition_options  = RuleMetaHelper::get_condition_options();
$currency_symbol    = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '';

$wholesale_groups = array();
if ( $groups_enabled ) {
	$wholesale_groups = get_posts(
		array(
			'post_type'      => wwp_env()->get( 'group_slug' ),
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'orderby'        => 'title',
			'order'          => 'ASC',
		)
	);
}

$current_type       = isset( $rule['rule_type'] ) ? $rule['rule_type'] : 'raise-percentage';
$current_applies_to = isset( $rule['applies_to'] ) ? $rule['applies_to'] : 'all_products';
$products           = isset( $rule['products'] ) && is_array( $rule['products'] ) ? $rule['products'] : array();
$categories         = isset( $rule['categories'] ) && is_array( $rule['categories'] ) ? $rule['categories'] : array();
$applies_to_groups  = isset( $rule['applies_to_groups'] ) && is_array( $rule['applies_to_groups'] ) ? array_map( 'absint', $rule['applies_to_groups'] ) : array();
$is_change_group    = ( 'change-group' === $current_type );
$show_product_scope = ! $is_change_group;

/**
 * Action before dynamic rule settings fields.
 *
 * @since 3.2.0
 * @param WP_Post $post Post object.
 * @param array   $rule Rule meta.
 */
do_action( 'wwp_dynamic_rule_metabox_start', $post, $rule );
?>
<table class="form-table wwp-dr-rule-settings">
	<tbody>
		<tr>
			<th scope="row">
				<label for="wwp_dr_rule_type"><?php esc_html_e( 'Rule Type', 'woocommerce-wholesale-pricing' ); ?></label>
			</th>
			<td>
				<select name="wwp_dynamic_rule[rule_type]" id="wwp_dr_rule_type" class="wwp-dr-rule-type wc-enhanced-select">
					<?php foreach ( $rule_type_options as $slug => $label ) : ?>
						<?php $disabled = ( 'change-group' === $slug && ! $groups_enabled ); ?>
						<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $current_type, $slug ); ?> <?php disabled( $disabled ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</td>
		</tr>
	</tbody>
</table>

<div class="wwp-dr-field-group wwp-dr-product-scope" data-scope="product" <?php echo $show_product_scope ? '' : 'style="display:none;"'; ?>>
	<table class="form-table">
		<tbody>
			<tr>
				<th scope="row">
					<label for="wwp_dr_applies_to"><?php esc_html_e( 'Applies to', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<select name="wwp_dynamic_rule[applies_to]" id="wwp_dr_applies_to" class="wwp-dr-applies-to wc-enhanced-select" <?php disabled( ! $show_product_scope ); ?>>
						<?php foreach ( $applies_to_options as $opt_slug => $opt_label ) : ?>
							<option value="<?php echo esc_attr( $opt_slug ); ?>" <?php selected( $current_applies_to, $opt_slug ); ?>>
								<?php echo esc_html( $opt_label ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>

			<tr class="wwp-dr-applies-to-group" data-applies-to="specific_products" <?php echo ( 'specific_products' === $current_applies_to && $show_product_scope ) ? '' : 'style="display:none;"'; ?>>
				<th scope="row">
					<label for="wwp_dr_products"><?php esc_html_e( 'Products', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<select
						multiple="multiple"
						class="wc-product-search wwp-dr-product-search"
						id="wwp_dr_products"
						name="wwp_dynamic_rule[products][]"
						data-placeholder="<?php esc_attr_e( 'Search for a product&hellip;', 'woocommerce-wholesale-pricing' ); ?>"
						data-action="woocommerce_json_search_products_and_variations"
						style="width:100%;"
						<?php disabled( ! $show_product_scope || 'specific_products' !== $current_applies_to ); ?>
					>
						<?php foreach ( $products as $product_id ) : ?>
							<?php $product = wc_get_product( $product_id ); ?>
							<?php if ( $product ) : ?>
								<option value="<?php echo esc_attr( $product_id ); ?>" selected="selected"><?php echo esc_html( $product->get_formatted_name() ); ?></option>
							<?php endif; ?>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>

			<tr class="wwp-dr-applies-to-group" data-applies-to="specific_categories" <?php echo ( 'specific_categories' === $current_applies_to && $show_product_scope ) ? '' : 'style="display:none;"'; ?>>
				<th scope="row">
					<label for="wwp_dr_categories"><?php esc_html_e( 'Categories', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<select
						multiple="multiple"
						class="wc-category-search wwp-dr-category-search"
						id="wwp_dr_categories"
						name="wwp_dynamic_rule[categories][]"
						data-placeholder="<?php esc_attr_e( 'Search for a category&hellip;', 'woocommerce-wholesale-pricing' ); ?>"
						data-action="woocommerce_json_search_categories"
						style="width:100%;"
						<?php disabled( ! $show_product_scope || 'specific_categories' !== $current_applies_to ); ?>
					>
						<?php foreach ( $categories as $cat_slug ) : ?>
							<?php
							$term = get_term_by( 'slug', $cat_slug, 'product_cat' );
							if ( ! $term || is_wp_error( $term ) ) {
								continue;
							}
							?>
							<option value="<?php echo esc_attr( $term->slug ); ?>" selected="selected"><?php echo esc_html( $term->name . ' (#' . $term->term_id . ')' ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
		</tbody>
	</table>
</div>

<div class="wwp-dr-field-group" data-rule-type="raise-percentage" <?php echo ( 'raise-percentage' === $current_type ) ? '' : 'style="display:none;"'; ?>>
	<table class="form-table">
		<tbody>
			<tr>
				<th scope="row">
					<label for="wwp_dr_price_increase"><?php esc_html_e( 'Price increase', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<input
						type="number"
						min="1"
						step="1"
						id="wwp_dr_price_increase"
						class="wwp-dr-price-increase"
						name="wwp_dynamic_rule[price_increase]"
						value="<?php echo esc_attr( isset( $rule['price_increase'] ) ? $rule['price_increase'] : 1 ); ?>"
						<?php disabled( 'raise-percentage' !== $current_type ); ?>
					/>
					<span class="wwp-dr-field-suffix">%</span>
				</td>
			</tr>
		</tbody>
	</table>
</div>

<div class="wwp-dr-field-group" data-rule-type="buy-x-get-x" <?php echo ( 'buy-x-get-x' === $current_type ) ? '' : 'style="display:none;"'; ?>>
	<table class="form-table">
		<tbody>
			<tr>
				<th scope="row">
					<label for="wwp_dr_free_items"><?php esc_html_e( 'Free items', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<input
						type="number"
						min="1"
						step="1"
						id="wwp_dr_free_items"
						class="wwp-dr-free-items"
						name="wwp_dynamic_rule[free_items]"
						value="<?php echo esc_attr( isset( $rule['free_items'] ) ? $rule['free_items'] : 1 ); ?>"
						<?php disabled( 'buy-x-get-x' !== $current_type ); ?>
					/>
					<span class="wwp-dr-field-suffix"><?php esc_html_e( '(free unit(s))', 'woocommerce-wholesale-pricing' ); ?></span>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="wwp_dr_buy_quantity"><?php esc_html_e( 'Buy quantity (X)', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<input
						type="number"
						min="1"
						step="1"
						id="wwp_dr_buy_quantity"
						class="wwp-dr-buy-quantity"
						name="wwp_dynamic_rule[buy_quantity]"
						value="<?php echo esc_attr( isset( $rule['buy_quantity'] ) ? $rule['buy_quantity'] : 1 ); ?>"
						<?php disabled( 'buy-x-get-x' !== $current_type ); ?>
					/>
				</td>
			</tr>
		</tbody>
	</table>
</div>

<div class="wwp-dr-field-group" data-rule-type="add-tax-fee-percentage" <?php echo ( 'add-tax-fee-percentage' === $current_type ) ? '' : 'style="display:none;"'; ?>>
	<table class="form-table">
		<tbody>
			<tr>
				<th scope="row">
					<label for="wwp_dr_tax_fee_pct"><?php esc_html_e( 'Tax fee', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<input
						type="number"
						min="1"
						step="1"
						id="wwp_dr_tax_fee_pct"
						class="wwp-dr-tax-fee"
						name="wwp_dynamic_rule[tax_fee]"
						value="<?php echo esc_attr( isset( $rule['tax_fee'] ) ? $rule['tax_fee'] : 1 ); ?>"
						<?php disabled( 'add-tax-fee-percentage' !== $current_type ); ?>
					/>
					<span class="wwp-dr-field-suffix">%</span>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="wwp_dr_tax_label_pct"><?php esc_html_e( 'Tax Label', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<input
						type="text"
						id="wwp_dr_tax_label_pct"
						class="regular-text"
						name="wwp_dynamic_rule[tax_label]"
						value="<?php echo esc_attr( isset( $rule['tax_label'] ) && '' !== $rule['tax_label'] ? $rule['tax_label'] : 'Additional Tax' ); ?>"
						<?php disabled( 'add-tax-fee-percentage' !== $current_type ); ?>
					/>
				</td>
			</tr>
		</tbody>
	</table>
</div>

<div class="wwp-dr-field-group" data-rule-type="add-tax-fee-fixed" <?php echo ( 'add-tax-fee-fixed' === $current_type ) ? '' : 'style="display:none;"'; ?>>
	<table class="form-table">
		<tbody>
			<tr>
				<th scope="row">
					<label for="wwp_dr_tax_fee_fixed"><?php esc_html_e( 'Tax fee', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<input
						type="number"
						min="1"
						step="1"
						id="wwp_dr_tax_fee_fixed"
						class="wwp-dr-tax-fee-fixed"
						name="wwp_dynamic_rule[tax_fee]"
						value="<?php echo esc_attr( isset( $rule['tax_fee'] ) ? $rule['tax_fee'] : 1 ); ?>"
						<?php disabled( 'add-tax-fee-fixed' !== $current_type ); ?>
					/>
					<span class="wwp-dr-field-suffix"><?php esc_html_e( 'per order', 'woocommerce-wholesale-pricing' ); ?></span>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="wwp_dr_tax_label_fixed"><?php esc_html_e( 'Tax Label', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<input
						type="text"
						id="wwp_dr_tax_label_fixed"
						class="regular-text"
						name="wwp_dynamic_rule[tax_label]"
						value="<?php echo esc_attr( isset( $rule['tax_label'] ) && '' !== $rule['tax_label'] ? $rule['tax_label'] : 'Additional Tax' ); ?>"
						<?php disabled( 'add-tax-fee-fixed' !== $current_type ); ?>
					/>
				</td>
			</tr>
		</tbody>
	</table>
</div>
<!-- here -->
<div class="wwp-dr-field-group" data-rule-type="change-group" <?php echo ( $is_change_group && $groups_enabled ) ? '' : 'style="display:none;"'; ?>>
	<table class="form-table">
		<tbody>
			<tr>
				<th scope="row">
					<label for="wwp_dr_condition"><?php esc_html_e( 'Condition', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<select name="wwp_dynamic_rule[condition]" id="wwp_dr_condition" class="wwp-dr-condition wc-enhanced-select" <?php disabled( ! $is_change_group ); ?>>
						<?php foreach ( $condition_options as $cond_slug => $cond_label ) : ?>
							<option value="<?php echo esc_attr( $cond_slug ); ?>" <?php selected( isset( $rule['condition'] ) ? $rule['condition'] : '', $cond_slug ); ?>>
								<?php echo esc_html( $cond_label ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="wwp_dr_threshold"><?php esc_html_e( 'Threshold', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<input
						type="number"
						min="1"
						step="1"
						id="wwp_dr_threshold"
						class="wwp-dr-threshold"
						name="wwp_dynamic_rule[threshold]"
						value="<?php echo esc_attr( isset( $rule['threshold'] ) ? $rule['threshold'] : 1 ); ?>"
						<?php disabled( ! $is_change_group ); ?>
					/>
					<span class="wwp-dr-field-suffix wwp-dr-threshold-suffix" data-currency="<?php echo esc_attr( $currency_symbol ); ?>"><?php echo esc_html( $currency_symbol ); ?></span>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="wwp_dr_applies_to_groups"><?php esc_html_e( 'Applies to (current group)', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<select
						multiple="multiple"
						class="wc-enhanced-select wwp-dr-applies-to-groups"
						id="wwp_dr_applies_to_groups"
						name="wwp_dynamic_rule[applies_to_groups][]"
						data-placeholder="<?php esc_attr_e( 'Select wholesale groups&hellip;', 'woocommerce-wholesale-pricing' ); ?>"
						style="width:100%;"
						<?php disabled( ! $is_change_group || ! $groups_enabled ); ?>
					>
						<?php if ( empty( $wholesale_groups ) ) : ?>
							<option value="" disabled><?php esc_html_e( 'No wholesale groups found.', 'woocommerce-wholesale-pricing' ); ?></option>
						<?php else : ?>
							<?php foreach ( $wholesale_groups as $group_post ) : ?>
								<option value="<?php echo esc_attr( $group_post->ID ); ?>" <?php selected( in_array( (int) $group_post->ID, $applies_to_groups, true ) ); ?>>
									<?php echo esc_html( $group_post->post_title ); ?>
								</option>
							<?php endforeach; ?>
						<?php endif; ?>
					</select>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="wwp_dr_move_to_group"><?php esc_html_e( 'Move to group', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<select name="wwp_dynamic_rule[move_to_group]" id="wwp_dr_move_to_group" class="wwp-dr-move-to-group wc-enhanced-select" <?php disabled( ! $is_change_group ); ?>>
						<option value="0"><?php esc_html_e( 'Select a group', 'woocommerce-wholesale-pricing' ); ?></option>
						<?php foreach ( $wholesale_groups as $group_post ) : ?>
							<option value="<?php echo esc_attr( $group_post->ID ); ?>" <?php selected( isset( $rule['move_to_group'] ) ? (int) $rule['move_to_group'] : 0, (int) $group_post->ID ); ?>>
								<?php echo esc_html( $group_post->post_title ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<th scope="row">
					<label for="wwp_dr_notify_customer"><?php esc_html_e( 'Notify customer on change', 'woocommerce-wholesale-pricing' ); ?></label>
				</th>
				<td>
					<select name="wwp_dynamic_rule[notify_customer]" id="wwp_dr_notify_customer" class="wwp-dr-notify-customer wc-enhanced-select" <?php disabled( ! $is_change_group ); ?>>
						<option value="yes" <?php selected( isset( $rule['notify_customer'] ) ? $rule['notify_customer'] : '', 'yes' ); ?>>
							<?php esc_html_e( 'Yes, Send email', 'woocommerce-wholesale-pricing' ); ?>
						</option>
						<option value="no" <?php selected( isset( $rule['notify_customer'] ) ? $rule['notify_customer'] : 'no', 'no' ); ?>>
							<?php esc_html_e( 'No', 'woocommerce-wholesale-pricing' ); ?>
						</option>
					</select>
				</td>
			</tr>
		</tbody>
	</table>
</div>
