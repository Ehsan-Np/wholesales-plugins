<div class="wrap wc-quote col-xs-9 col-sm-9 col-md-9">
	<div class="registration-form-message">
		<span class="dashicons dashicons-yes-alt"></span>
		<span class="message_text"> <?php echo esc_html__('Successfully Form Saved.', 'woocommerce-wholesale-pricing'); ?></span> 
		<span class="dashicons dashicons-no-alt" onclick="jQuery('.registration-form-message').fadeOut();"></span>
	</div>
	<div id="wc-quote-formbuilder"></div>
	<div class="row">
		<div class="col-xs-4 col-sm-3 col-md-2 formcomponents">
			<?php
			$other_attributes = array( 'id' => 'wc-quote-save-formbuilder' );
			submit_button(esc_html__('Save Changes', 'woocommerce-wholesale-pricing'), 'primary wwp-button-primary', 'submit', true, $other_attributes);
			?>
		</div>
	</div>
</div>
