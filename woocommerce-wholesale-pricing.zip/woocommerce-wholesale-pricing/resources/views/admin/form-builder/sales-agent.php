<?php

wp_enqueue_style( 'sales_agent_bootstrap' );
wp_enqueue_style( 'sales_agent_form_builder' );
wp_enqueue_script( 'sales-agent-form-builder' );
// minify css
$extra_css = '.formbuilder {width: 100%;padding: 50px 0;}input[type=checkbox]{margin:0 0 0 -20px!important}input[type=radio]{margin:2px 0 0 -20px!important}.btn-primary:hover{background:-webkit-linear-gradient(left,#69f,#89f)!important;border-color:#89f!important}.col-xs-4.col-sm-3.col-md-2.formcomponents{max-width:25%!important;flex:0 0 25%}.col-xs-8.col-sm-9.col-md-10.formarea{max-width:74%!important;flex:0 0 74%}.formio-component .card {max-width: unset!important}';

/**
*  Filter
*
*  @since 1.4
*/
$formbuilder_css = apply_filters( 'wc_agent_additional_css_formbuilder', $extra_css );
// adding additional css in formbuilder
wp_add_inline_style( 'sales_agent_form_builder', $formbuilder_css );
$args             = array(
	'taxonomy'   => 'commission_cat',
	'hide_empty' => false,
);
$agent_categories = get_terms( $args );
$mendatory_fields = mendatory_fields();

/**
*  Filter
*
*  @since 1.4
*/
$fields = apply_filters( 'wc_agent_additional_field_formbuilder', $mendatory_fields );

$builder_config = ! empty( get_option( 'sales_agent_form_builder_data' ) ) ? str_replace( 'false', 'false', wp_unslash( get_option( 'sales_agent_form_builder_data' ) ) ) : array();

if ( empty( $builder_config ) && ! isset( $builder_config['components'] ) ) {
	$builder_config['components'] = $fields;
} else {
	$builder_config = get_form_result_with_catagory( json_decode( $builder_config ), $agent_categories );
}

$localize_data = array(
	'ajax_url'       => admin_url( 'admin-ajax.php' ),
	'nonce'          => wp_create_nonce( 'sales-agent-ajax-nonce' ),
	'builder_config' => $builder_config,
);

wp_localize_script( 'sales-agent-init-builder', 'REGISTER_FORM', $localize_data );

wp_enqueue_script( 'sales-agent-init-builder' );
?>

<div class="wrap">
	<?php
	if ( empty( $agent_categories ) ) {
		/* translators: Please create agent commission category */
		printf( esc_html__( '%1$sPlease create agent commission category first to view registration form builder.%2$s', 'woocommerce-wholesale-pricing' ), '<p><strong>', '</strong></p>' );
		return false;
	}
	?>

	
	<div class="wrap wc-sales-agent col-xs-9 col-sm-9 col-md-9">
	<div id="agent-metabox-shortcode" class="agent-metabox-shortcode">
		<h3><?php esc_html_e( 'Shortcode', 'woocommerce-wholesale-pricing' ); ?></h3>
		<p>
		<?php
			/* translators: Copy the following shortcode */
			echo esc_html__( 'Copy the following shortcode, and paste it on a page where you would like to display the registration form.', 'woocommerce-wholesale-pricing' );
		?>
		</p>
		<code id="shortcode" style="color: black;">[sales_agent_registeration_form]</code>
	</div>
		<div id="agent-register-formbuilder"></div>
		<div class="row" data-id="agent-register-formbuilder" style="display:none;">
			<div class="col-md-12">
				<?php
				$other_attributes = array( 'id' => 'sales-agent-save-formbuilder' );
				submit_button( esc_html__( 'Save Changes', 'woocommerce-wholesale-pricing' ), 'button button-primary wwp-button-primary', 'submit', true, $other_attributes );
				?>
			</div>
		</div>
	</div>
</div>