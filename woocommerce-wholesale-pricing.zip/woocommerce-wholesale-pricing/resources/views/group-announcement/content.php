<?php

if (is_user_logged_in() ) {
	$user_id = get_current_user_id();
	$user_group = get_user_meta($user_id, 'add_in_wwp_group', true);
	if (! empty($user_group) && 'true' == $user_group ) {

		$group_id = get_user_meta($user_id, 'user_wwp_groupname', true);
		$group_announcements = get_post_meta($group_id, '_wholesale_group_announcements', true);

		if (! empty($group_announcements) && is_array($group_announcements) ) {
			
			// Display the announcement table
			?>
			<table class="wwp_group_announcement_table">
				<thead>
					<tr>
						<th><?php esc_html_e('Subject', 'woocommerce-wholesale-pricing'); ?></th>
						<th><?php esc_html_e('Date Published', 'woocommerce-wholesale-pricing'); ?></th>
						<th><?php esc_html_e('Status', 'woocommerce-wholesale-pricing'); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $group_announcements as $index => $announcement ) : ?>
						<tr>
							<td>
								<a href="#" data-nonce="<?php esc_attr_e(wp_create_nonce('wwp_user_annoucement')); ?>" class="show-announcement-popup" data-index="<?php echo esc_attr($index); ?>">
									<?php echo esc_html($announcement['subject']); ?>
								</a>
								<?php 
								// Check if this announcement has been read
								$announcement_read_status = get_user_meta($user_id, 'wwp_read_announcement_' . $index, true);
								$new_announce = empty($announcement_read_status) || 'true' !== $announcement_read_status;
								?>
								<span class="<?php echo $new_announce ? 'wwp-new-label' : ''; ?>"><?php echo $new_announce ? 'New' : ''; ?></span>
							</td>
							<td><?php echo esc_html($announcement['date']); ?></td>
							<td><?php echo $new_announce ? esc_html__('Unread', 'woocommerce-wholesale-pricing') : esc_html__('Read', 'woocommerce-wholesale-pricing'); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<!-- Popup HTML (hidden by default) -->
			<div class="wwp-announcement-popup-overlay" id="popup-overlay" style="display:none;">
				<div class="wwp-announcement-popup">
					<div class="wwp-announcement-header">
						<h2 id="popup-subject"></h2>
						<span class="wwp-close-popup" id="close-popup">&times;</span>
					</div>
					<div class="announcement-content">
						<p id="popup-content"></p>
					</div>
				</div>
			</div>
			<?php
		} else {
			echo '<p>' . esc_html__('No announcements available.', 'woocommerce-wholesale-pricing') . '</p>';
		}
	}
}
