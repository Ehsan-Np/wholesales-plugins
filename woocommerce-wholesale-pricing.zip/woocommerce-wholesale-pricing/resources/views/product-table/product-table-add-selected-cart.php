<?php
/**
 * Product Table Add Selected Cart Button
 *
 * @package WooCommerce Product Table/Templates
 */

?>

<div class="wcpt-selected-cart-wrapper">
	<a href="#" class="wcpt-selected-cart button alt"><?php esc_html_e('Add Selected Products Cart', 'woocommerce-wholesale-pricing'); ?></a>
</div>
