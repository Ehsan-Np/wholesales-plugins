<?php
/**
 * Quick Order Form table rows template.
 *
 * @package WooCommerceWholesalePricing
 */

defined( 'ABSPATH' ) || exit;

use WooCommerceWholesalePricing\App\Modules\ProductTable\Traits\Fields;
use WooCommerceWholesalePricing\App\Services\ProductTable\QuickOrderProcess;

if ( ! isset( $quick_order_fields ) || ! is_array( $quick_order_fields ) ) {
	$quick_order_fields = Fields::get_product_table_fields( $quick_order_id );
}
if ( ! is_array( $quick_order_fields ) ) {
	$quick_order_fields = array();
}

if ( ! isset( $product_ids ) ) {
	$product_ids = '0';
}

if ( ! isset( $wc_quick_order ) ) {
	$wc_quick_order = new QuickOrderProcess( array(), $quick_order_id );
}

do_action( 'quick_order_before_table' );
?>

<table class="wc-quick-order__contents shop_table_responsive" cellspacing="0">
	<thead>
		<tr>
			<th class="product-remove"></th>
			<th class="product-name"><?php esc_html_e( 'Product', 'woocommerce-wholesale-pricing' ); ?></th>
			<?php foreach ( $quick_order_fields as $value ) : ?>
				<th class="product-<?php echo esc_attr( $value['woo_ids'] ); ?>"><?php echo esc_html( $value['woo_label'] ); ?></th>
			<?php endforeach; ?>
			<th class="product-qty"><?php esc_html_e( 'Quantity', 'woocommerce-wholesale-pricing' ); ?></th>
		</tr>
	</thead>
	<tbody>
		<?php do_action( 'wc_quick_order_before_content' ); ?>

		<?php
		$session_items = WC()->session ? WC()->session->get( 'wc_quick_order_' . $quick_order_id ) : array();
		if ( ! is_array( $session_items ) ) {
			$session_items = array();
		}

		foreach ( $session_items as $form_item_key => $form_item ) {
			if ( ! isset( $form_item['data'] ) || ! is_object( $form_item['data'] ) ) {
				continue;
			}

			$_product   = apply_filters( 'wc_quick_order_item_product', $form_item['data'], $form_item, $form_item_key );
			$product_id = apply_filters( 'wc_quick_order_item_product_id', $form_item['product_id'], $form_item, $form_item_key );

			if ( $_product && $_product->exists() && $form_item['quantity'] > 0 && apply_filters( 'quick_order_item_visible', true, $form_item, $form_item_key ) ) {
				$product_permalink = apply_filters( 'quick_order_item_permalink', $_product->is_visible() ? $_product->get_permalink( $form_item ) : '', $form_item, $form_item_key );
				?>
				<tr class="woocommerce-cart-form__order-item <?php echo esc_attr( apply_filters( 'quick_order_item_class', 'cart_item', $form_item, $form_item_key ) ); ?>">
					<td class="product-remove">
						<?php
						echo wp_kses_post(
							apply_filters(
								'quick_order_item_remove_link',
								sprintf(
									'<a href="%s" class="remove remove-cart-item wc-order-remove-item" aria-label="%s" data-cart_item_key="%s" data-product_id="%s" data-product_sku="%s">&times;</a>',
									esc_attr( $form_item_key ),
									esc_html__( 'Remove this item', 'woocommerce-wholesale-pricing' ),
									esc_attr( $form_item_key ),
									esc_attr( $product_id ),
									esc_attr( $_product->get_sku() )
								),
								$form_item_key
							)
						);
						?>
					</td>
					<td class="product-name" data-title="<?php esc_attr_e( 'Product', 'woocommerce-wholesale-pricing' ); ?>">
						<select style="width:100%" class="wc-product-search" data-placeholder="<?php esc_attr_e( 'Search for a product&hellip;', 'woocommerce' ); ?>" data-action="woocommerce_json_search_products_and_variations" data-include="[<?php echo esc_attr( $product_ids ); ?>]" data-exclude="<?php echo esc_attr( $product_id ); ?>" data-update="true" data-exclude_type="variable" data-cart_item_key="<?php echo esc_attr( $form_item_key ); ?>">
							<option value="<?php echo esc_attr( $product_id ); ?>" selected><?php echo esc_html( $_product->get_name() ); ?></option>
						</select>
						<?php do_action( 'quick_order_after_item_name', $form_item, $form_item_key ); ?>
					</td>
					<?php
					foreach ( $quick_order_fields as $quick_order_field ) {
						switch ( $quick_order_field['woo_ids'] ) {
							case 'sku':
								?>
								<td class="product-sku" data-title="<?php esc_attr_e( 'SKU', 'woocommerce-wholesale-pricing' ); ?>">
									<?php echo esc_html( $_product->get_sku() ); ?>
								</td>
								<?php
								break;
							case 'short_desc':
								?>
								<td class="product-short_desc" data-title="<?php esc_attr_e( 'Short Description', 'woocommerce-wholesale-pricing' ); ?>">
									<?php echo esc_html( $_product->get_short_description() ); ?>
								</td>
								<?php
								break;
							case 'descr':
								?>
								<td class="product-descr" data-title="<?php esc_attr_e( 'Description', 'woocommerce-wholesale-pricing' ); ?>">
									<?php echo wp_kses_post( $_product->get_description() ); ?>
								</td>
								<?php
								break;
							case 'cat':
								?>
								<td class="product-cat" data-title="<?php esc_attr_e( 'Categories', 'woocommerce-wholesale-pricing' ); ?>">
									<?php echo wp_kses_post( wc_get_product_category_list( $product_id ) ); ?>
								</td>
								<?php
								break;
							case 'featured_img':
								?>
								<td class="product-featured_img" data-title="<?php esc_attr_e( 'Featured Image', 'woocommerce-wholesale-pricing' ); ?>">
									<?php
									$thumbnail = apply_filters( 'quick_order_item_thumbnail', $_product->get_image(), $form_item, $form_item_key );
									if ( empty( $quick_order_field['woo_linkable'] ) ) {
										echo wp_kses_post( $thumbnail );
									} else {
										printf( '<a href="%s">%s</a>', esc_url( $product_permalink ), wp_kses_post( $thumbnail ) );
									}
									?>
								</td>
								<?php
								break;
							case 'reviews':
								?>
								<td class="product-reviews" data-title="<?php esc_attr_e( 'Reviews', 'woocommerce-wholesale-pricing' ); ?>">
									<?php echo esc_html( $_product->get_average_rating() ); ?>
								</td>
								<?php
								break;
							case 'stock':
								$stock_text = '';
								$class      = 'in-stock';
								if ( ! $_product->is_in_stock() || ( $_product->managing_stock() && $_product->is_on_backorder( 1 ) ) || ( ! $_product->managing_stock() && $_product->is_on_backorder( 1 ) ) ) {
									$class      = 'out-of-stock';
									$stock_text = __( 'Out Of Stock', 'woocommerce-wholesale-pricing' );
								} elseif ( ! empty( $quick_order_field['woo_show_stock'] ) && '1' == $quick_order_field['woo_show_stock'] ) {
									$stock_text = $_product->get_stock_quantity() . ' ' . __( 'In Stock', 'woocommerce-wholesale-pricing' );
								} else {
									$stock_text = __( 'In Stock', 'woocommerce-wholesale-pricing' );
								}
								?>
								<td class="product-stock" data-title="<?php esc_attr_e( 'Stock', 'woocommerce-wholesale-pricing' ); ?>">
									<span class="stock <?php echo esc_attr( $class ); ?>"><?php echo esc_html( $stock_text ); ?></span>
								</td>
								<?php
								break;
							case 'weight':
								?>
								<td class="product-weight" data-title="<?php esc_attr_e( 'Weight', 'woocommerce-wholesale-pricing' ); ?>">
									<?php echo esc_html( $_product->get_weight() ); ?>
								</td>
								<?php
								break;
							case 'dimensions':
								?>
								<td class="product-dimensions" data-title="<?php esc_attr_e( 'Dimensions', 'woocommerce-wholesale-pricing' ); ?>">
									<?php echo esc_html( wc_format_dimensions( $_product->get_dimensions( false ) ) ); ?>
								</td>
								<?php
								break;
							case 'price':
								?>
								<td class="product-price" data-title="<?php esc_attr_e( 'Price', 'woocommerce-wholesale-pricing' ); ?>">
									<?php echo wp_kses_post( $_product->get_price_html() ); ?>
								</td>
								<?php
								break;
							case 'cart_button':
								?>
								<td class="product-cart_button" data-title="<?php esc_attr_e( 'Add To Cart Button', 'woocommerce-wholesale-pricing' ); ?>"></td>
								<?php
								break;
						}
					}
					?>
					<td class="product-quantity" data-title="<?php esc_attr_e( 'Quantity', 'woocommerce-wholesale-pricing' ); ?>">
						<?php
						if ( $_product->is_sold_individually() ) {
							printf( '<input type="hidden" name="order_qty[%s]" value="1" data-cart_item_key="%s"/>', esc_attr( $form_item_key ), esc_attr( $form_item_key ) );
						} else {
							woocommerce_quantity_input(
								array(
									'input_id'     => 'quantity_' . $form_item_key,
									'input_name'   => "order_qty[{$form_item_key}]",
									'input_value'  => $form_item['quantity'],
									'min_value'    => apply_filters( 'woocommerce_quantity_input_min', 0, $_product ),
									'max_value'    => apply_filters( 'woocommerce_quantity_input_max', $_product->get_max_purchase_quantity(), $_product ),
									'product_name' => $_product->get_name(),
								),
								$_product,
								true
							);
						}
						?>
					</td>
				</tr>
				<?php
			}
		}
		?>
		<?php do_action( 'quick_order_contents' ); ?>
	</tbody>
</table>
<?php
do_action( 'quick_order_after_contents' );
do_action( 'quick_order_after_table' );
