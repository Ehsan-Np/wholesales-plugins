<?php
/**
 * Product Table Header
 *
 * This template can be overridden by copying it to yourtheme/wc_product_table/product-table-header.php.
 *
 * @package WooCommerce Product Table/Templates
 */

$device_class         = '';
$data_hidden_priority = 10001;

if ( ! function_exists( 'wcpt_assign_default_header_labels' ) ) {
	function wcpt_assign_default_header_labels( &$headings ) {
		foreach ( $headings as &$heading ) {
			if ( empty( $heading['label'] ) ) {
				switch ( $heading['type'] ) {
					case 'id':
						$heading['label'] = 'ID';
						break;
					case 'title':
						$heading['label'] = 'Title';
						break;
					case 'sku':
						$heading['label'] = 'SKU';
						break;
					case 'short_desc':
						$heading['label'] = 'Short Description';
						break;
					case 'descr':
						$heading['label'] = 'Description';
						break;
					case 'date':
						$heading['label'] = 'Date';
						break;
					case 'cat':
						$heading['label'] = 'Categories';
						break;
					case 'featured_img':
						$heading['label'] = 'Featured Image';
						break;
					case 'reviews':
						$heading['label'] = 'Reviews';
						break;
					case 'stock':
						$heading['label'] = 'Stock';
						break;
					case 'dimensions':
						$heading['label'] = 'Dimensions';
						break;
					case 'price':
						$heading['label'] = 'Price';
						break;
					case 'attributes':
						$heading['label'] = 'Attributes';
						break;
					case 'custom_fields':
						$heading['label'] = 'Custom Fields';
						break;
					case 'tags':
						$heading['label'] = 'Tags';
						break;
					case 'quick_view':
						$heading['label'] = 'Quick View';
						break;
					case 'taxonomy':
						$heading['label'] = 'Taxonomy';
						break;
					case 'cart_button':
						$heading['label'] = 'Add To Cart Button';
						break;
				}
			}
		}
	}
}


wcpt_assign_default_header_labels($product_table_headings);

if ($product_table_headings ) {
	?>
	<thead <?php echo ( ! $product_table_header ) ? 'style="visibility:hidden"' : ''; ?> data-sort_col="<?php echo esc_attr($default_sorted_col); ?>" data-sort_dir="<?php echo esc_attr($default_sorted_dir); ?>">
		<tr>
	<?php
	foreach ( $product_table_headings as $key => $product_table_heading ) {
		$device_class   = '';
		$column_index   = (int) $key;
		$data_piriority = $column_index;

		if ( ! empty( $responsive_options['hidden_col_mobile_ids'] ) && is_array( $responsive_options['hidden_col_mobile_ids'] ) && in_array( $column_index, array_map( 'intval', $responsive_options['hidden_col_mobile_ids'] ), true ) ) {
			$device_class = 'min-phone-l';
		}
		if ( ! empty( $responsive_options['hidden_col_tablet_ids'] ) && is_array( $responsive_options['hidden_col_tablet_ids'] ) && in_array( $column_index, array_map( 'intval', $responsive_options['hidden_col_tablet_ids'] ), true ) ) {
			$device_class = 'min-tablet';
		}
		if ( ! empty( $responsive_options['hidden_col_ids'] ) && is_array( $responsive_options['hidden_col_ids'] ) && in_array( $column_index, array_map( 'intval', $responsive_options['hidden_col_ids'] ), true ) ) {
			$data_piriority = $data_hidden_priority--;
		}
		$sort_col       = $product_table_heading['type'] . '_' . $key;
		$header_classes = ( ! $sorted_cols || ! in_array($sort_col, $sorted_cols, true) ) ? $device_class . ' no-sort' : $device_class;
		?>
				<th class="<?php echo esc_attr($header_classes); ?>" data-name="<?php echo esc_attr($product_table_heading['type']); ?>" data-width="<?php echo ( isset($product_table_heading['width']) ) ? esc_attr($product_table_heading['width']) : ''; ?>" data-priority="<?php echo esc_attr($data_piriority); ?>">
		<?php echo esc_attr($product_table_heading['label']); ?>
				</th>
		<?php
	}
	?>
		</tr>
	</thead>
	<?php
}
if ($no_products_msg ) {
	?>
	<input  class="wcpt-no-product-message" type="hidden" value="<?php echo esc_attr($no_products_msg); ?>">
	<?php
}


