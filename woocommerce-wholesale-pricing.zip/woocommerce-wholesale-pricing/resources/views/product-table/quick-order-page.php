<?php
/**
 * Quick Order Form page template.
 *
 * @package WooCommerceWholesalePricing
 */

use WooCommerceWholesalePricing\App\Modules\ProductTable\Traits\Fields;
use WooCommerceWholesalePricing\App\Services\ProductTable\QuickOrderShortcodeService;

if ( ! isset( $quick_order_fields ) || ! is_array( $quick_order_fields ) ) {
	$quick_order_fields = Fields::get_product_table_fields( $quick_order_id );
}
if ( ! is_array( $quick_order_fields ) ) {
	$quick_order_fields = array();
}
?>
<div class="woocommerce">
	<div class="woocommerce-notices-wrapper">
	</div>
	<form class="woocommerce-cart-form wc-quick-order-form wc-quick-order-form-<?php echo esc_attr( $quick_order_id ); ?>"
	  method="post" enctype="multipart/form-data"
	  data-form-id="<?php echo esc_attr( $quick_order_id ); ?>">
		<?php
		$cat_ids            = get_post_meta( $quick_order_id, 'wcpt_inc_product_cats', true );
		$stock_status       = get_post_meta( $quick_order_id, 'wcpt_product_status', true );
		$meta_product_query = array();
		$tax_product_query  = array();
		$product_ids        = array();
		if ( $stock_status ) {
			$meta_product_query = array(
				array(
					'key'   => '_stock_status',
					'value' => $stock_status,
				),
			);
		}
		if ( $cat_ids ) {
			$tax_product_query = array(
				array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $cat_ids,
					'operator' => 'IN',
				),
			);
		}

		$all_ids = get_posts(
			array(
				'post_type'      => array( 'product' ),
				'posts_per_page' => -1,
				'post_status'    => 'publish',
				'fields'         => 'ids',
				'tax_query'      => $tax_product_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				'meta_query'     => $meta_product_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			)
		);

		foreach ( $all_ids as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}
			if ( 'variable' === $product->get_type() ) {
				$variations    = $product->get_available_variations();
				$variations_id = wp_list_pluck( $variations, 'variation_id' );
				$product_ids   = array_merge( $product_ids, $variations_id );
			} else {
				$product_ids[] = $product_id;
			}
		}
		$product_ids = implode( ',', $product_ids );
		if ( empty( $product_ids ) ) {
			$product_ids = '0';
		}
		?>
		<script type="text/javascript">
			jQuery(document).ready(function(){
				function initSearch(){
					var select2_args = {
						allowClear:  jQuery( '.wc-product-search' ).data( 'allow_clear' ) ? true : false,
						placeholder: jQuery( '.wc-product-search' ).data( 'placeholder' ),
						minimumInputLength: jQuery( '.wc-product-search' ).data( 'minimum_input_length' ) ? jQuery( '.wc-product-search' ).data( 'minimum_input_length' ) : '3',
						escapeMarkup: function( m ) {
							return m;
						},
						ajax: {
							url:         wc_enhanced_select_params.ajax_url,
							dataType:    'json',
							delay:       250,
							data:        function( params ) {
								return {
									term         : params.term,
									action       : jQuery( '.wc-product-search' ).data( 'action' ) || 'woocommerce_json_search_products_and_variations',
									security     : wc_enhanced_select_params.search_products_nonce,
									exclude      : jQuery( '.wc-product-search' ).data( 'exclude' ),
									exclude_type : jQuery( '.wc-product-search' ).data( 'exclude_type' ),
									include      : jQuery( '.wc-product-search' ).data( 'include' ),
									limit        : jQuery( '.wc-product-search' ).data( 'limit' ),
									display_stock: jQuery( '.wc-product-search' ).data( 'display_stock' )
								};
							},
							processResults: function( data ) {
								var terms = [];
								if ( data ) {
									jQuery.each( data, function( id, text ) {
										terms.push( { id: id, text: text } );
									});
								}
								return {
									results: terms
								};
							},
							cache: true
						}
					};
					jQuery('.wc-product-search').selectWoo(select2_args);
				}

				jQuery(document).on('select2:select','.wc-product-search', function (e) {
					var product = e.params.data;
					var quantity = 1;
					var update = jQuery(this).data('update');
					var form_id = jQuery(this).closest('form').data('form-id');

					if (!form_id || form_id !== <?php echo (int) $quick_order_id; ?>) {
						return;
					}

					var action_name = update ? 'wc_quick_order_update' : 'wc_quick_order_add';
					var form_key = update ? jQuery(this).data('cart_item_key') : '';

					jQuery.ajax({
						url: wc_enhanced_select_params.ajax_url,
						type: 'POST',
						dataType: 'JSON',
						data: {
							action: action_name,
							product_id: product.id,
							form_id: form_id,
							quantity: quantity,
							form_key: form_key,
							nonce: wc_enhanced_select_params.search_products_nonce
						},
						success: function (response) {
							if( response['form_empty'] ){
								location.reload();
							}
							jQuery('table.wc-quick-order__contents').replaceWith( response['form-table'] );
							initSearch();
							window.location.reload();
						}
					});
				});

				initSearch();

				jQuery(document).on('click', '.wc_quick_order_add_row', function(e) {
					let $tableBody = jQuery(this).closest('form').find('.wc-quick-order__contents tbody');
					$tableBody.find('.new-row').remove();
					$tableBody.append(`
						<tr class="new-row">
							<td class="product-remove">
								<a href="javascript:void(0)" class="remove remove-cart-item remove-row">&times;</a>
							</td>
							<td class="product-name" data-title="Product">
								<select style="width:100%" class="wc-product-search" data-placeholder="<?php echo esc_js( __( 'Search for a product&hellip;', 'woocommerce' ) ); ?>" data-action="woocommerce_json_search_products_and_variations" data-include="[<?php echo esc_attr( $product_ids ); ?>]" data-exclude_type="variable"></select>
							</td>
							<?php foreach ( $quick_order_fields as $value ) : ?>
							<td class="product-<?php echo esc_attr( $value['woo_ids'] ); ?>"></td>
							<?php endforeach; ?>
							<td class="product-quantity"></td>
						</tr>
					`);
					initSearch();
				});

				jQuery(document).on('click', 'a.remove-row', function(e) {
					e.preventDefault();
					jQuery(this).closest('tr').remove();
				});

				jQuery(document).on('click', '.wc-order-remove-item', function (event) {
					event.preventDefault();
					if( jQuery(this).closest('tr').css('opacity') == 0.5 ){
						return;
					}
					jQuery(this).closest('tr').css('opacity', '0.5' );
					var form_id = jQuery(this).closest('form').data('form-id');

					jQuery.ajax({
						url: wc_enhanced_select_params.ajax_url,
						type: 'POST',
						data: {
							action: 'wc_quick_order_remove_item',
							form_key: jQuery(this).data('cart_item_key'),
							form_id: form_id,
							nonce: wc_enhanced_select_params.search_products_nonce
						},
						success: function (response) {
							if( response['form_empty'] ){
								location.reload();
							}
							jQuery('table.wc-quick-order__contents').replaceWith( response['form-table'] );
							initSearch();
							window.location.reload();
						}
					});
				});

				jQuery(document).on('click', 'a.wc_quick_order_add_to_cart', function () {
					var redirect_url = jQuery(this).attr('data-url');
					var current_button = jQuery(this);
					if ( current_button.hasClass('loading') || current_button.hasClass('disabled') ) {
						return;
					}
					current_button.addClass('loading');
					jQuery.ajax({
						url: wc_enhanced_select_params.ajax_url,
						type: 'POST',
						data: {
							action: 'wc_quick_order_add_to_cart',
							form_id: <?php echo (int) $quick_order_id; ?>,
							nonce: wc_enhanced_select_params.search_products_nonce
						},
						success: function (response) {
							if ( 'success' == jQuery.trim(response) ) {
								window.location.href = redirect_url;
							} else if( 'failed' == jQuery.trim(response) ){
								location.reload();
							} else {
								current_button.removeClass('loading');
							}
						}
					});
					return false;
				});

				var qtyUpdateTimer;

				jQuery(document).on('input', '.wc-quick-order__contents tbody tr .quantity .qty', function () {

					var $this = jQuery(this);

					// Clear the previous timer whenever quantity changes
					clearTimeout(qtyUpdateTimer);

					// Wait 500ms after the last quantity change
					qtyUpdateTimer = setTimeout(function () {

						if (jQuery('a.wc_quick_order_add_to_cart').hasClass('loading')) {
							return;
						}

						jQuery('a.wc_quick_order_add_to_cart').addClass('loading');

						var form_key = $this.attr('name');
						var quantity = $this.val();

						form_key = form_key.replace('order_qty[', '').replace(']', '');

						jQuery.ajax({
							url: wc_enhanced_select_params.ajax_url,
							type: 'POST',
							dataType: 'JSON',
							data: {
								action: 'wc_quick_order_update_items',
								form_id: <?php echo (int) $quick_order_id; ?>,
								form_key: form_key,
								quantity: quantity,
								nonce: wc_enhanced_select_params.search_products_nonce
							},
							success: function (response) {

								if (response['form_empty']) {
									location.reload();
									return;
								}

								jQuery('a.wc_quick_order_add_to_cart').removeClass('loading');
							},
							error: function () {
								jQuery('a.wc_quick_order_add_to_cart').removeClass('loading');
							}
						});

					}, 500); // 500ms delay
				});

			});
		</script>
		<?php
		if ( isset( WC()->session ) && ! empty( WC()->session->get( 'wc_quick_order_' . $quick_order_id ) ) ) :
			QuickOrderShortcodeService::get_template( 'quick-order-table.php', compact( 'quick_order_id', 'quick_order_fields', 'product_ids' ) );
			?>
	   <?php else : ?>
			<table class="wc-quick-order__contents shop_table_responsive" cellspacing="0">
				<thead>
					<tr>
						<th class="product-remove"></th>
						<th class="product-name"><?php esc_html_e( 'Product', 'woocommerce-wholesale-pricing' ); ?></th>
		   <?php foreach ( $quick_order_fields as $value ) : ?>
							<th class="product-<?php echo esc_attr( $value['woo_ids'] ); ?>"><?php echo esc_html( $value['woo_label'] ); ?></th>
		   <?php endforeach; ?>
						<th class="product-quantity"><?php esc_html_e( 'Quantity', 'woocommerce-wholesale-pricing' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr class="woocommerce-cart-form__order-item">
						<td class="product-remove"></td>
						<td class="product-name" data-title="<?php esc_attr_e( 'Product', 'woocommerce-wholesale-pricing' ); ?>">
							<select style="width:100%" class="wc-product-search" data-placeholder="<?php esc_attr_e( 'Search for a product&hellip;', 'woocommerce' ); ?>" data-action="woocommerce_json_search_products_and_variations" data-include="[<?php echo esc_attr( $product_ids ); ?>]" data-exclude_type="variable"></select>
						</td>
		   <?php foreach ( $quick_order_fields as $value ) : ?>
							<td class="product-<?php echo esc_attr( $value['woo_ids'] ); ?>"></td>
		   <?php endforeach; ?>
						<td class="product-quantity"></td>
					</tr>
				</tbody>
			</table>
	   <?php endif; ?>

		<div class="order-collapse">
			<div id="order_actions" class="action-btn">
				<?php do_action( 'quick_order_before_actions' ); ?>
				<div class="wc-proceed-to-checkout form_row">
					<a href="javascript:void(0)" class="button alt wc_quick_order_add_row"><?php esc_html_e( 'Add Another Row', 'woocommerce-wholesale-pricing' ); ?></a>
					<a href="javascript:void(0)" class="button alt wc_quick_order_add_to_cart wc-forward" data-url="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php esc_html_e( 'Add To Cart', 'woocommerce-wholesale-pricing' ); ?></a>
				</div>
			</div>
		</div>
		<?php do_action( 'quick_order_after_actions' ); ?>
	</form>
</div>
