<?php
/**
 * Add to Cart for subscription product
 *
 * @package WooCommerce Product Table/Templates
 */

?>
<div class="product-cart-chechbox-wrapper simple-product-add-cart <?php echo esc_attr($classes); ?>">
	<div class="product-cart-wrapper">
		<?php 
		if ( 'enable' == $enable && ! is_user_logged_in() ) {
			?>
			<a class="button" href="<?php echo esc_url(get_page_link($guest_users_redirection)); ?>"><?php echo esc_html( $wcpt_add_to_cart_label ); ?></a>
			<?php
		} else {
				/**
				 * Action woocommerce simple cart button
				 * 
				 * @since 1.1.6
				 **/
				do_action('woocommerce_simple_add_to_cart'); 
			?>
				<?php
				if ('add_button' !== $cart_button_type && $product->is_in_stock() ) {
					?>
					<input type="checkbox" class="product-cart-chechbox" name="product_ids[]" value="<?php echo absint($product->get_id()); ?>">
					<?php
				}
		}
		?>
		</div>
	</div>
