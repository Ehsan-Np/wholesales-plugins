<?php
/**
 * Product Table Custom Field
 *
 * @package WooCommerce Product Table/Templates
 */

?>

<span><?php echo esc_html($product_custom_field); ?></span>
