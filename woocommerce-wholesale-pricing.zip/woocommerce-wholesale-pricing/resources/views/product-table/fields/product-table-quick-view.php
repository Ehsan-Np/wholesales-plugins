<?php
/**
 * Quick View for product
 *
 * @package WooCommerce Product Table/Templates
 */

?>
<div class="product-cart-chechbox-wrapper quickview_product">
	<div class="product-cart-wrapper">
		<?php
		global $product;
		$box_office = '';
		if ( class_exists('WC_Box_Office') ) {
			$box_office = wc_box_office_is_product_ticket($product);
		}
		if ( $box_office ) :
			?>
		<button type="submit" name="quick_view" data-id="<?php echo absint($product->get_id()); ?>" class="button quick_view_btn alt wp-element-button">
			<span class="icon"></span>View Tickets
		</button>
		<?php
		elseif ('bundle_product' === $product->get_type() || 'bundle' === $product->get_type()) :
			?>
			<button type="submit" name="quick_view" data-id="<?php echo absint($product->get_id()); ?>" class="button quick_view_btn alt wp-element-button">
				<span class="icon"></span>View Bundle
			</button>
			<?php
		else :
			?>
			<button type="submit" name="quick_view" data-id="<?php echo absint($product->get_id()); ?>" class="button quick_view_btn alt wp-element-button">
				<span class="icon"></span>Quick View
			</button>
			<?php
		endif;
		?>

	</div>
</div>
