<?php
/**
 * Product Table Tags Field
 *
 * @package WooCommerce Product Table/Templates
 */

?>
<span><?php echo esc_html($product_tags); ?></span>
