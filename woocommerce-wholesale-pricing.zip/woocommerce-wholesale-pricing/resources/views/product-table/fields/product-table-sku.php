<?php
/**
 * Product Table SKU Field
 *
 * @package WooCommerce Product Table/Templates
 */

?>
<span><?php echo esc_html($product_sku); ?></span>
