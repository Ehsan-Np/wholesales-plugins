<?php
/**
 * Product Table Price Field
 *
 * @package WooCommerce Product Table/Templates
 */


if ( 'enable' == $enable && ! is_user_logged_in() ) {
	?>
	<p><?php echo esc_html( $wcpt_price_text ) ; ?></a>
	<?php
} else {
	?>
	<span class="wcpt-product-price-<?php echo esc_attr( $product_id ); ?>">
		<?php
		echo wp_kses_post($product_price);
		?>
	</span>
<span class="wcpt_v_p price_<?php echo wp_kses_post($product_id); ?>"></span> 
									   <?php
}

