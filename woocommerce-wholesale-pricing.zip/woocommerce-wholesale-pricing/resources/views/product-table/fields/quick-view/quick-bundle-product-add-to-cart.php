<?php

if (! defined('ABSPATH') ) {
	exit; // Exit if accessed directly.
}


if ($product->is_in_stock() ) {
	/**
	 * Action woocommerce_before_add_to_cart_form
	 * 
	 * @since 1.0
	**/
	do_action('woocommerce_before_add_to_cart_form'); 
   
	if (class_exists('WCUBP_Ultimate_Bundle_Product') ) { 
	

		$product_maximum_qty = get_post_meta($product->get_id(), 'wcbp_bundle_max_quantity', true);
		$product_minimum_qty = get_post_meta($product->get_id(), 'wcbp_bundle_min_quantity', true);
		$prod_max_qty_display = isset($product_maximum_qty) && !empty($product_maximum_qty);
		$prod_min_qty_display = isset($product_minimum_qty) && !empty($product_minimum_qty);
		if ($prod_max_qty_display && $prod_min_qty_display ) { ?>
		<div class="woocommerce-info">
			<?php echo esc_html_e('Bundle minimum quantity is ' . $product_minimum_qty . ' and maximum is ' . $product_maximum_qty . '.', 'woocommerce-wholesale-pricing'); ?>
		</div>
			<?php
		} elseif ($prod_min_qty_display ) { 
			?>
		<div class="woocommerce-info">
			<?php esc_html_e('Bundle minimum quantity is ' . $product_minimum_qty . '.', 'woocommerce-wholesale-pricing'); ?>
		</div>
			<?php
		} elseif ($prod_max_qty_display ) { 
			?>
		<div class="woocommerce-info">
			<?php esc_html_e('Bundle maximum quantity is ' . $product_maximum_qty . '.', 'woocommerce-wholesale-pricing'); ?>
		</div>
			<?php
		}
		/**
		 * Filter woocommerce_add_to_cart_form_action
		 * 
		 * @since 1.0
		**/ 
		$form_action= apply_filters('woocommerce_add_to_cart_form_action', $product->get_permalink());
		?>
	<form class="cart" action="<?php echo esc_url($form_action); ?>" method="post" enctype='multipart/form-data'>
		<?php 

		include_once WC_UBP_DIR . 'includes/classes/class-wcbp-frontened.php';
		$smart_bundle = new \UBP_Bundle_Product_Frontend();
		$smart_bundle->add_before_product_to_cart(array(), $product->get_id());

		$data = $smart_bundle->scripts_data($product);
		

	
		/**
		*  Action woocommerce_before_add_to_cart_button
		*                            
		*  @since 2.0.7 
		*/
		do_action('woocommerce_before_add_to_cart_button'); 
		/**
		*  Action woocommerce_before_add_to_cart_quantity
		*                            
		*  @since 2.0.7 
		*/
		do_action('woocommerce_before_add_to_cart_quantity'); 

		woocommerce_quantity_input(
			array(
			'min_value'   =>
			/**
			*  Filter woocommerce_quantity_input_min
			*                            
			*  @since 2.0.7 
			*/
			apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
			/**
			*  Filter woocommerce_quantity_input_max
			*                            
			*  @since 2.0.7 
			*/
			'max_value'   => apply_filters('woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product),
			'input_value' => $product->get_min_purchase_quantity(), // WPCS: CSRF ok, input var ok.
			)
		);
		/**
		*  Action woocommerce_before_add_to_cart_quantity
		*                            
		*  @since 2.0.7 
		*/
		do_action('woocommerce_before_add_to_cart_quantity');
		?>

		<button type="submit" name="add-to-cart" value="<?php echo esc_attr($product->get_id()); ?>" class="single_add_to_cart_button button alt<?php echo esc_attr(wc_wp_theme_get_element_class_name('button') ? ' ' . wc_wp_theme_get_element_class_name('button') : ''); ?>"><?php echo esc_html('Add to Cart', 'woocommerce-wholesale-pricing'); ?></button>

		<?php
		/**
		 *  Action woocommerce_after_add_to_cart_button
		 *                            
		 * @since 2.0.7 
		 */
		do_action('woocommerce_after_add_to_cart_button'); 
		?>
	</form>
		<?php
		/**
		 *  Action woocommerce_after_add_to_cart_form
		 *                            
		 * @since 2.0.7 
		 */ 
		do_action('woocommerce_after_add_to_cart_form');
	}
}
