<?php

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}


if ($product->is_in_stock()) {
	/**
	*  Action woocommerce_before_add_to_cart_form
	*                            
	*  @since 2.0.7 
	*/
	do_action('woocommerce_before_add_to_cart_form');
	/**
	*  Filter woocommerce_add_to_cart_form_action
	*                            
	*  @since 2.0.7 
	*/
	$form_action = apply_filters('woocommerce_add_to_cart_form_action', $product->get_permalink()); ?>
	<form class="cart wcpt_quick_view_cart" action="<?php echo esc_url($form_action); ?>" method="post" enctype='multipart/form-data'>
	<?php 
	/**
	 *  Action woocommerce_quantity_input_min
	 *                            
	 * @since 2.0.7 
	 */
	do_action('woocommerce_before_add_to_cart_button');
	/**
	 *  Action 
	 *                            
	 *  @since 2.0.7 
	 */
	do_action('woocommerce_before_add_to_cart_quantity');

	woocommerce_quantity_input(
		array(
				/**
				 * Filter woocommerce_quantity_input_min
				 * 
				 * @since 1.0
				 **/
				'min_value'   => apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product),
				/**
				 * Filter woocommerce_quantity_input_max
				 * 
				 * @since 1.0
				 **/
				'max_value'   => apply_filters('woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product),
				'input_value' => $product->get_min_purchase_quantity(), // WPCS: CSRF ok, input var ok.
		)
	);
	/**
	*  Action woocommerce_before_add_to_cart_quantity
	*                            
	*  @since 2.0.7 
	*/
		do_action('woocommerce_before_add_to_cart_quantity'); 
	?>
		<button type="submit" name="add-to-cart" data-id="<?php echo esc_attr($product->get_id()); ?>" value="<?php echo esc_attr($product->get_id()); ?>" class="wcpt_quick_add_to_cart ajax_add_to_cart single_add_to_cart_button button alt<?php echo esc_attr(wc_wp_theme_get_element_class_name('button') ? ' ' . wc_wp_theme_get_element_class_name('button') : ''); ?>"><?php echo esc_html($product->single_add_to_cart_text()); ?></button>
	<?php
	/**
	 *  Action woocommerce_after_add_to_cart_button
	 *                            
	 * @since 2.0.7 
	 */
	do_action('woocommerce_after_add_to_cart_button'); 
	?>
	</form>
	<?php 
	/**
	 *  Action woocommerce_after_add_to_cart_form
	 *                            
	 * @since 2.0.7 
	 */
	do_action('woocommerce_after_add_to_cart_form');
}
