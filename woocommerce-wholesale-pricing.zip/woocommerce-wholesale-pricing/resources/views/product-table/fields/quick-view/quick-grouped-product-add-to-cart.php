<div class="product-cart-chechbox-wrapper simple-product-add-cart <?php echo esc_attr($classes); ?>">
	<div class="product-cart-wrapper">
		<?php
		$children = $product->get_children();
		if (empty($children)) {
			return;
		}
	/**
	 * Action woocommerce_before_add_to_cart_form
	 * 
	 * @since 1.1.6
	**/
		do_action('woocommerce_before_add_to_cart_form');
		?>

		<form class="cart grouped_form_ajax" method="post">
  <table class="group_table">
	<tbody>
	  <?php
		foreach ($children as $child_id) :
		  $child = wc_get_product($child_id);
			if (!$child || !$child->exists() || !$child->is_purchasable() || !$child->is_in_stock()) {
			  continue;
			}
			?>
		<tr>
		  <td><?php echo wp_kses_post($child->get_image()); ?></td>
		  <td>
			<?php echo esc_html($child->get_name()); ?><br>
			<?php echo wp_kses_post($child->get_price_html()); ?>
		  </td>
		  <td>
			<?php
			woocommerce_quantity_input(array(
			  'input_name'  => "quantity[{$child_id}]",
			  'input_value' => 0,
			  'min_value'   => 0,
			  'max_value'   => $child->get_max_purchase_quantity(),
			));
			?>
			<input type="hidden" name="products[]" value="<?php echo esc_attr($child_id); ?>">
		  </td>
		</tr>
		<?php endforeach; ?>
	</tbody>
  </table>

  <input type="hidden" name="add-to-cart" value="<?php echo esc_attr($product->get_id()); ?>">
  <?php wp_nonce_field('woocommerce-add-to-cart', 'add-to-cart-nonce'); ?>

  <button type="submit" class="single_add_to_cart_button button alt">
	<?php esc_html_e('Add to Cart', 'woocommerce-wholesale-pricing'); ?>
  </button>
</form>

		<?php
	  /**
	   * Action woocommerce_after_add_to_cart_form
	   * 
	   * @since 1.1.6
	  **/
	  do_action('woocommerce_after_add_to_cart_form'); 
		?>
	</div>
</div>

