<?php
/**
 * Product Table Add to cart for variation product
 *
 * @package WooCommerce Product Table/Templates
 */

?>

<div class="product-cart-chechbox-wrapper simple-product-add-cart <?php echo esc_attr($classes); ?>">
	<div class="product-cart-wrapper"> 
		<?php
		if ( 'enable' ==  $enable && ! is_user_logged_in() ) {
			?>
			<a class="button" href="<?php echo esc_url(get_page_link($guest_users_redirection)); ?>"><?php echo esc_html($wcpt_add_to_cart_label) ; ?></a>
			<?php
		} else {
			if (class_exists('WC_Min_Max_Quantities')) {
				/**
				 * Filter woocommerce_quantity_input_max
				 * 
				 * @since 1.1.6
				 **/
				$max = ( isset($product) && is_object($product) ) ? get_post_meta($product->get_id(), 'variation_maximum_allowed_quantity', true) : apply_filters('woocommerce_quantity_input_max', $product->get_max_purchase_quantity(), $product);
				/**
				 * Filter woocommerce_quantity_input_min
				 * 
				 * @since 1.1.6
				 **/
				$min = ( isset($product) && is_object($product) ) ? ( !empty(get_post_meta($product->get_id(), 'variation_minimum_allowed_quantity', true)) ? get_post_meta($product->get_id(), 'variation_minimum_allowed_quantity', true) : $product->get_min_purchase_quantity() ) : apply_filters('woocommerce_quantity_input_min', $product->get_min_purchase_quantity(), $product);
				$step = ( isset($product) && is_object($product) ) ? get_post_meta($product->get_id(), 'variation_group_of_quantity', true) : null;
				?>
				<form class="cart" action="
				<?php 
				/**
				 * Filter woocommerce_add_to_cart_form_action
				 * 
				 * @since 1.1.6
				 **/
				echo esc_url( apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() ) ); 
				?>
			" method="post" enctype='multipart/form-data'>
			<?php
			woocommerce_quantity_input(
				array(
					'min_value' => $min,
					'max_value' => $max,
					'step'      => $step,
					'input_value' => $min,
				)
			);
			?>
			<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="single_add_to_cart_button button alt<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button></form>
			<?php
			} else {
				/**
				 * Action woocommerce simple cart button
				 * 
				 * @since 1.1.6
				 **/
				do_action('woocommerce_simple_add_to_cart'); 
			}


			if ('add_button' !== $cart_button_type && $product->is_in_stock() ) {
				?>
				<input type="checkbox" class="product-cart-chechbox" name="product_ids[]" value="<?php echo absint($product->get_id()); ?>">
				<?php
			}
		}
		?>
	</div>
</div>
