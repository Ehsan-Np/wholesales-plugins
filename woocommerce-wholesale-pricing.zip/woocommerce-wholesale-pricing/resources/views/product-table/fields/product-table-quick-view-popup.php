<?php
	/**
	 * Quick View of Product
	 *
	 * @package WooCommerce Product Table/Templates
	 */

?>
	<div class="pd-quick-view">
		<a class="button pd-quick-view-button" ><?php echo esc_html_e('Quick View', 'woocommerce-wholesale-pricing'); ?></a>
	</div>
</div>