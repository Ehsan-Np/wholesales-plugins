<?php
/**
 * Product Table Image Field
 *
 * @package WooCommerce Product Table/Templates
 */
if ('true' === $product_linkable ) {
	?>
	<a href="<?php echo esc_url($product_url); ?>"><?php echo wp_kses_post($product_image); ?></a>
	<?php
} else {
	echo wp_kses_post($product_image);
}
$url = WWP_PLUGIN_URL . 'public/images/product-table/loader.svg';
if ( 'true' === $product_image_expandable ) {
	?>
	<a href="javascript:void(0)"  data-id="<?php echo absint($product_id); ?>" class="product-table-expandable"><img class="zoomer-image" src="<?php echo esc_url( WWP_PLUGIN_URL . 'public/images/product-table/zoomer.png' ); ?> "></a>
	<img class="loader-icon loader-icon_<?php echo esc_attr( $product_id ); ?>" src="<?php echo esc_url( $url ); ?>">
	<div class="popupContainer"> 
		<button class="closePopup">✕</button>
		<img class="popup_image" src="">
	</div>
	<?php
} 

