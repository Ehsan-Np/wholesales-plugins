<?php
/**
 * Product Table Stock Status Field
 *
 * @package WooCommerce Product Table/Templates
 */
if (class_exists('WC_Min_Max_Quantities')) {

	$parent_id         = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
	$allow_combination = 'yes' === get_post_meta( $parent_id, 'allow_combination', true );

	if ( '1' == $allow_combination ) {
		$min   = absint( get_post_meta($parent_id, 'minimum_allowed_quantity', true) );
	} else {
		$min   = absint( get_post_meta($product->get_id(), 'variation_minimum_allowed_quantity', true) );
		if ( $product->get_type('simple') ) {
			$min   = absint( get_post_meta($product->get_id(), 'minimum_allowed_quantity', true) );
		}
	}


}
$stockText =  '';
if (! $product->is_in_stock() ) {
	$class = 'out-of-stock';
	$stockText = 'Out Of Stock';
} elseif (( $product->managing_stock() && $product->is_on_backorder(1) ) || ( ! $product->managing_stock() && $product->is_on_backorder(1) ) ) {
	$class = 'available-on-backorder';
	$stockText = 'Available On Backorder';

} elseif ( 1 == $woo_show_stock ) {
	if ( class_exists('WC_Min_Max_Quantities') ) {
		if (  $product->get_stock_quantity() < $min ) {
			$class = 'out-of-stock';
			$stockText = 'Out Of Stock';
		} else {
			$class = 'in-stock';
			$stockText = $product->get_stock_quantity() . ' In Stock';
		}
	} else {
		$class = 'in-stock';
		$stockText = $product->get_stock_quantity() . ' In Stock';
	}
	
	
} else {
	$class = 'in-stock';
	$stockText = 'In Stock';
}
?>
<span class="stock_<?php echo esc_attr($product->get_id()); ?>" data-stock='<span class="stock <?php echo esc_attr($class); ?>">
	<?php echo esc_html($product_stock_status); ?>
</span>'>
<span class="stock <?php echo esc_attr($class); ?>">
	<?php 
	echo esc_html($stockText);
	?>
</span>
</span>
