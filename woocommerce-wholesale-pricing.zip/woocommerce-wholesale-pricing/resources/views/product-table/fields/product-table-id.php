<?php

/**
 * Product Table ID Field
 *
 * @package WooCommerce Product Table/Templates
 */
if (! defined('ABSPATH') ) {
	exit; // Exit if accessed directly.
}

?>
<span><?php echo esc_html($product_id); ?></span>
