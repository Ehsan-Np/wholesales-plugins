<?php
/**
 * Add / edit company user form (loaded in modal).
 *
 * @package WooCommerceWholesalePricing
 *
 * @var \WP_User|null $edit_user User being edited, or null when adding.
 */

$is_edit     = ! empty( $edit_user ) && $edit_user instanceof \WP_User;
$first_name  = $is_edit ? (string) $edit_user->first_name : '';
$last_name   = $is_edit ? (string) $edit_user->last_name : '';
$member_login  = $is_edit ? (string) $edit_user->user_login : '';
$member_email  = $is_edit ? (string) $edit_user->user_email : '';
$edit_user_id = $is_edit ? (int) $edit_user->ID : 0;
?>
<form class="wwp-ccp-add-user-form" id="ccp_add_user_form" action="" method="post" novalidate data-mode="<?php echo $is_edit ? 'edit' : 'add'; ?>">
	<?php if ( $is_edit ) : ?>
		<input type="hidden" name="ccp_edit_user_id" id="ccp_edit_user_id" value="<?php echo esc_attr( $edit_user_id ); ?>">
	<?php endif; ?>
	<p class="form-row form-row-first">
		<label for="account_first_name">
			<?php esc_html_e( 'First name', 'woocommerce-wholesale-pricing' ); ?>
			<span class="required">*</span>
		</label>
		<input type="text" class="input-text" name="account_first_name" id="account_first_name" value="<?php echo esc_attr( $first_name ); ?>" autocomplete="given-name" required>
	</p>
	<p class="form-row form-row-last">
		<label for="account_last_name">
			<?php esc_html_e( 'Last name', 'woocommerce-wholesale-pricing' ); ?>
			<span class="required">*</span>
		</label>
		<input type="text" class="input-text" name="account_last_name" id="account_last_name" value="<?php echo esc_attr( $last_name ); ?>" autocomplete="family-name" required>
	</p>
	<div class="clear"></div>
	<p class="form-row form-row-wide">
		<label for="account_user_login">
			<?php esc_html_e( 'Username', 'woocommerce-wholesale-pricing' ); ?>
			<span class="required">*</span>
		</label>
		<input type="text" class="input-text" name="account_user_login" id="account_user_login" value="<?php echo esc_attr( $member_login ); ?>" autocomplete="username" required <?php disabled( $is_edit ); ?>>
	</p>
	<p class="form-row form-row-wide">
		<label for="account_email">
			<?php esc_html_e( 'Email address', 'woocommerce-wholesale-pricing' ); ?>
			<span class="required">*</span>
		</label>
		<input type="email" class="input-text" name="account_email" id="account_email" value="<?php echo esc_attr( $member_email ); ?>" autocomplete="email" required <?php disabled( $is_edit ); ?>>
	</p>
	<p class="form-row form-row-wide wwp-ccp-add-user-form__actions">
		<button type="submit" id="ccp_add_user_submit" class="wwp-ccp-btn wwp-ccp-btn--primary">
			<?php
			echo $is_edit
				? esc_html__( 'Update User', 'woocommerce-wholesale-pricing' )
				: esc_html__( 'Add User', 'woocommerce-wholesale-pricing' );
			?>
		</button>
	</p>
</form>
