<?php
/**
 * Company credit tab — request form + credit history.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int    $company_id Company post ID.
 * @var string $ccp_company_role Company role.
 */

if ( ! authentication_role( 'credit' ) ) {
	return;
}

$company_users = get_users(
	array(
		'meta_key'   => 'ccp_company_id',
		'meta_value' => $company_id,
	)
);

$can_filter_users = in_array( $ccp_company_role, array( 'ccp_manager', 'ccp_owner' ), true );

$my_requests     = array();
$all_requests    = ccp_get_credit_requests( $company_id );
$current_user_id = get_current_user_id();
foreach ( $all_requests as $request_row ) {
	if ( is_array( $request_row ) && isset( $request_row['user_id'] ) && (int) $request_row['user_id'] === $current_user_id ) {
		$my_requests[] = $request_row;
	}
}
$my_requests = array_reverse( $my_requests );
?>
<section class="wwp-ccp-panel wwp-ccp-panel--credit">
	<div class="wwp-ccp-request-card">
		<div class="wwp-ccp-request-card__header">
			<span class="wwp-ccp-panel__icon dashicons dashicons-plus-alt" aria-hidden="true"></span>
			<h4 class="wwp-ccp-panel__title"><?php esc_html_e( 'Credit Request', 'woocommerce-wholesale-pricing' ); ?></h4>
		</div>
		<form id="ccp_credit_request_form" class="wwp-ccp-request-form" method="post" action="#">
			<?php
			$helper_text = in_array( $ccp_company_role, array( 'ccp_owner' ), true )
				? __( 'Your request will be sent to the store admin. When approved, credits are added to the company pool.', 'woocommerce-wholesale-pricing' )
				: __( 'Your request will be sent to the company owner. When approved, credits are added to your wallet.', 'woocommerce-wholesale-pricing' );
			?>
			<p class="wwp-ccp-request-form__hint"><?php echo esc_html( $helper_text ); ?></p>
			<p class="woocommerce-form-row form-row form-row-wide">
				<label for="ccp_credit_request_amount"><?php esc_html_e( 'Amount', 'woocommerce-wholesale-pricing' ); ?></label>
				<input type="number" min="0" step="0.01" class="woocommerce-Input woocommerce-Input--text input-text" name="ccp_credit_request_amount" id="ccp_credit_request_amount" placeholder="<?php esc_attr_e( 'Enter amount', 'woocommerce-wholesale-pricing' ); ?>" required>
			</p>
			<p class="woocommerce-form-row form-row form-row-wide">
				<label for="ccp_credit_request_reason"><?php esc_html_e( 'Reason', 'woocommerce-wholesale-pricing' ); ?></label>
				<textarea class="woocommerce-Input woocommerce-Input--textarea input-text" name="ccp_credit_request_reason" id="ccp_credit_request_reason" rows="3" placeholder="<?php esc_attr_e( 'Why do you need additional credit?', 'woocommerce-wholesale-pricing' ); ?>" required></textarea>
			</p>
			<p class="form-row">
				<button type="submit" id="ccp_credit_request_submit" class="wwp-ccp-btn wwp-ccp-btn--primary"><?php esc_html_e( 'Submit', 'woocommerce-wholesale-pricing' ); ?></button>
			</p>
		</form>

		<div class="wwp-ccp-my-requests">
			<h5 class="wwp-ccp-my-requests__title"><?php esc_html_e( 'My Credit Requests', 'woocommerce-wholesale-pricing' ); ?></h5>
			<?php if ( ! empty( $my_requests ) ) : ?>
				<table class="wwp-ccp-table wwp-ccp-my-requests__table" style="width:100%">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Amount', 'woocommerce-wholesale-pricing' ); ?></th>
							<th><?php esc_html_e( 'Sent To', 'woocommerce-wholesale-pricing' ); ?></th>
							<th><?php esc_html_e( 'Reason', 'woocommerce-wholesale-pricing' ); ?></th>
							<th><?php esc_html_e( 'Status', 'woocommerce-wholesale-pricing' ); ?></th>
							<th><?php esc_html_e( 'Requested On', 'woocommerce-wholesale-pricing' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $my_requests as $request_row ) : ?>
							<?php
							$row_status  = isset( $request_row['status'] ) ? $request_row['status'] : 'pending';
							$badge_class = 'pending' === $row_status ? 'wwp-ccp-badge--pending' : ( 'approved' === $row_status ? 'wwp-ccp-badge--approved' : 'wwp-ccp-badge--declined' );
							$sent_to     = ( isset( $request_row['request_to'] ) && 'admin' === $request_row['request_to'] )
								? __( 'Store Admin', 'woocommerce-wholesale-pricing' )
								: __( 'Company Owner', 'woocommerce-wholesale-pricing' );
							?>
							<tr>
								<td><?php echo esc_html( isset( $request_row['requested_limit'] ) ? $request_row['requested_limit'] : '' ); ?></td>
								<td><?php echo esc_html( $sent_to ); ?></td>
								<td><?php echo esc_html( isset( $request_row['reason'] ) ? $request_row['reason'] : '' ); ?></td>
								<td><span class="wwp-ccp-badge <?php echo esc_attr( $badge_class ); ?>"><?php echo esc_html( ucfirst( $row_status ) ); ?></span></td>
								<td><?php echo esc_html( isset( $request_row['requested_on'] ) ? $request_row['requested_on'] : '' ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p class="wwp-ccp-empty"><?php esc_html_e( 'You have not submitted any credit requests yet.', 'woocommerce-wholesale-pricing' ); ?></p>
			<?php endif; ?>
		</div>
	</div>

	<div class="wwp-ccp-history-card">
		<div class="wwp-ccp-panel__header">
			<div class="wwp-ccp-panel__heading-wrap">
				<span class="wwp-ccp-panel__icon dashicons dashicons-backup" aria-hidden="true"></span>
				<h4 class="ccp_headding wwp-ccp-panel__title"><?php esc_html_e( 'Credit History', 'woocommerce-wholesale-pricing' ); ?></h4>
			</div>
			<button type="button" id="ccp_filter_panel" class="ccp_Orders add_buttn wwp-ccp-icon-btn" aria-expanded="false" aria-controls="ccp_filter_panel_wrap" title="<?php esc_attr_e( 'Filters', 'woocommerce-wholesale-pricing' ); ?>">
				<span class="dashicons dashicons-filter" aria-hidden="true"></span>
				<span class="screen-reader-text"><?php esc_html_e( 'Filters', 'woocommerce-wholesale-pricing' ); ?></span>
			</button>
		</div>

		<div id="ccp_filter_panel_wrap" class="wwp-ccp-filters" hidden>
			<p class="wwp-ccp-filters__title"><?php esc_html_e( 'Filters', 'woocommerce-wholesale-pricing' ); ?></p>
			<form id="ccp_form_filter" class="wwp-ccp-filters__form" method="post" action="#">
				<p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
					<label for="start_date"><?php esc_html_e( 'Start Date', 'woocommerce-wholesale-pricing' ); ?></label>
					<input type="date" class="woocommerce-Input woocommerce-Input--text input-text" name="start_date" id="start_date">
				</p>
				<p class="woocommerce-form-row woocommerce-form-row--last form-row form-row-last">
					<label for="end_date"><?php esc_html_e( 'End Date', 'woocommerce-wholesale-pricing' ); ?></label>
					<input type="date" class="woocommerce-Input woocommerce-Input--text input-text" name="end_date" id="end_date">
				</p>
				<?php if ( $can_filter_users ) : ?>
					<p class="woocommerce-form-row woocommerce-form-row--ccp_select_user form-row form-row-ccp_select_user">
						<label for="ccp_select_user"><?php esc_html_e( 'Select User', 'woocommerce-wholesale-pricing' ); ?></label>
						<select name="ccp_select_user" id="ccp_select_user">
							<option value=""><?php esc_html_e( 'Select User', 'woocommerce-wholesale-pricing' ); ?></option>
							<?php foreach ( $company_users as $company_user ) : ?>
								<option value="<?php echo esc_attr( $company_user->ID ); ?>"><?php echo esc_html( $company_user->display_name ); ?></option>
							<?php endforeach; ?>
						</select>
					</p>
				<?php endif; ?>
				<p class="woocommerce-form-row woocommerce-form-row--search form-row form-row-search wwp-ccp-filters__actions">
					<button type="button" id="ccp-search-now" class="wwp-ccp-btn wwp-ccp-btn--primary"><?php esc_html_e( 'Search', 'woocommerce-wholesale-pricing' ); ?></button>
					<button type="reset" id="ccp-search-clear" class="wwp-ccp-btn wwp-ccp-btn--ghost"><?php esc_html_e( 'Clear', 'woocommerce-wholesale-pricing' ); ?></button>
				</p>
			</form>
		</div>

		<div class="wwp-ccp-table-card">
			<table id="ccp_credits_table" class="display wwp-ccp-table" style="width:100%">
				<thead>
					<tr>
						<th><?php esc_html_e( 'ID', 'woocommerce-wholesale-pricing' ); ?></th>
						<th><?php esc_html_e( 'User', 'woocommerce-wholesale-pricing' ); ?></th>
						<th><?php esc_html_e( 'Amount', 'woocommerce-wholesale-pricing' ); ?></th>
						<th><?php esc_html_e( 'Event', 'woocommerce-wholesale-pricing' ); ?></th>
						<th><?php esc_html_e( 'Create On', 'woocommerce-wholesale-pricing' ); ?></th>
					</tr>
				</thead>
				<tbody></tbody>
			</table>
		</div>
	</div>
</section>
