<?php
/**
 * Users shared carts tab.
 *
 * @package WooCommerceWholesalePricing
 */

if ( ! authentication_role( 'user-shared-carts' ) ) {
	return;
}
?>
<section class="wwp-ccp-panel wwp-ccp-panel--user-shared-carts">
	<div class="wwp-ccp-panel__header">
		<div class="wwp-ccp-panel__heading-wrap">
			<span class="wwp-ccp-panel__icon dashicons dashicons-networking" aria-hidden="true"></span>
			<h4 class="ccp_headding wwp-ccp-panel__title"><?php esc_html_e( 'Users Shared Carts', 'woocommerce-wholesale-pricing' ); ?></h4>
		</div>
	</div>
	<p class="divclear wwp-ccp-panel__desc"><?php esc_html_e( 'View carts shared by other users.', 'woocommerce-wholesale-pricing' ); ?></p>

	<div class="wwp-ccp-table-card">
		<table id="ccp_user_shared_cart" class="display wwp-ccp-table" style="width:100%">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Cart Title', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Shared By', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Number of items', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'woocommerce-wholesale-pricing' ); ?></th>
				</tr>
			</thead>
			<tbody></tbody>
		</table>
	</div>
</section>
