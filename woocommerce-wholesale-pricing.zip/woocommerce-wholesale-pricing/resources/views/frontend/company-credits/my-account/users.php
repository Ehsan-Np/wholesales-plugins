<?php
/**
 * Company users tab.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int $company_id Company post ID.
 */

if ( ! authentication_role( 'users' ) || 'yes' !== ccp_get_option_yes_default( 'ccp_manage_users' ) ) {
	return;
}
?>
<section class="wwp-ccp-panel wwp-ccp-panel--users" data-company-id="<?php echo esc_attr( $company_id ); ?>">
	<div class="wwp-ccp-panel__header">
		<div class="wwp-ccp-panel__heading-wrap">
			<span class="wwp-ccp-panel__icon dashicons dashicons-groups" aria-hidden="true"></span>
			<h4 class="ccp_headding wwp-ccp-panel__title"><?php esc_html_e( 'Users', 'woocommerce-wholesale-pricing' ); ?></h4>
		</div>
		<button type="button" id="open_modal" class="add_new_user add_buttn wwp-ccp-btn wwp-ccp-btn--primary wwp-ccp-btn--with-icon">
			<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
			<?php esc_html_e( 'Add User', 'woocommerce-wholesale-pricing' ); ?>
		</button>
	</div>

	<div class="wwp-ccp-table-card">
		<table id="ccp_users_table" class="display wwp-ccp-table" style="width:100%">
			<thead>
				<tr>
					<th><?php esc_html_e( 'ID', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Name', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Email', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Role', 'woocommerce-wholesale-pricing' ); ?></th>
					<th><?php esc_html_e( 'Action', 'woocommerce-wholesale-pricing' ); ?></th>
				</tr>
			</thead>
			<tbody></tbody>
		</table>
	</div>
</section>
