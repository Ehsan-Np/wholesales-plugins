<?php
/**
 * Shared cart detail modal body.
 *
 * @package WooCommerceWholesalePricing
 *
 * @var int $post_id Shared cart post ID.
 */

$post_data  = get_post( $post_id );
$share_cart = get_post_meta( $post_id, 'ccp_sahre_cart', true );

if ( ! $post_data || ! is_array( $share_cart ) ) {
	return;
}
?>
<div class="ccp_sahre_cart_list_new">
	<form id="form_sahre_cart_list" action="#" method="post">
		<table class="ccp_sahre_cart_list_table">
			<tr>
				<th class="ccp_search_by_header"><?php esc_html_e( 'Title', 'woocommerce-wholesale-pricing' ); ?></th>
				<th class="ccp_table_qty_header"><?php esc_html_e( 'Qty', 'woocommerce-wholesale-pricing' ); ?></th>
				<th class="ccp_table_subtotal_header" scope="col"><?php esc_html_e( 'Price', 'woocommerce-wholesale-pricing' ); ?></th>
				<th class="ccp_table_subtotal_header" scope="col"><?php esc_html_e( 'Subtotal', 'woocommerce-wholesale-pricing' ); ?></th>
			</tr>
			<?php foreach ( $share_cart as $list ) : ?>
				<?php
				if ( empty( $list['ccp_product_id'] ) ) {
					continue;
				}
				$product = wc_get_product( $list['ccp_product_id'] );
				if ( ! $product ) {
					continue;
				}
				?>
				<tr class="ccp_table_row">
					<td>
						<div class="ccp_product_title">
							<a target="_blank" href="<?php echo esc_url( get_permalink( $list['ccp_product_id'] ) ); ?>">
								<?php echo esc_html( $product->get_title() ); ?>
							</a>
						</div>
					</td>
					<td>
						<div class="ccp_product_qty">
							<?php echo esc_html( isset( $list['ccp_product_qty'] ) ? $list['ccp_product_qty'] : 1 ); ?>
						</div>
					</td>
					<td>
						<div class="ccp_product_subtotal">
							<span class="ccp_sahre_cart_list_price_display">
								<?php echo wp_kses_post( $product->get_price_html() ); ?>
							</span>
						</div>
					</td>
					<td>
						<div class="ccp_product_subtotal">
							<span class="ccp_sahre_cart_list_price_display">
								<?php echo wp_kses_post( wc_price( $product->get_price() * $list['ccp_product_qty'] ) ); ?>
							</span>
						</div>
					</td>
				</tr>
				<?php if ( ! empty( $list['ccp_booking'] ) && is_array( $list['ccp_booking'] ) ) : ?>
					<?php
					$booking_rows = array();
					$booking_data = $list['ccp_booking'];
					$date_format  = function_exists( 'wc_bookings_date_format' ) ? wc_bookings_date_format() : get_option( 'date_format' );
					$time_format  = function_exists( 'wc_bookings_time_format' ) ? wc_bookings_time_format() : get_option( 'time_format' );

					if ( function_exists( 'get_wc_booking_data_label' ) ) {
						foreach ( $booking_data as $booking_key => $booking_value ) {
							if ( '_' === substr( $booking_key, 0, 1 ) ) {
								continue;
							}
							$label = get_wc_booking_data_label( $booking_key, $product );
							if ( is_array( $booking_value ) ) {
								$booking_value = implode( ', ', array_map( 'wc_clean', array_map( 'wp_strip_all_tags', $booking_value ) ) );
							}
							$booking_value = trim( (string) $booking_value );
							if ( '' === $booking_value ) {
								continue;
							}
							$booking_rows[] = array(
								'label' => $label,
								'value' => $booking_value,
							);
						}
					}

					if ( empty( $booking_rows ) && ! empty( $booking_data['_start_date'] ) ) {
						$start_timestamp = absint( $booking_data['_start_date'] );
						$booking_rows[]  = array(
							'label' => __( 'Start', 'woocommerce-wholesale-pricing' ),
							'value' => trim( date_i18n( $date_format, $start_timestamp ) . ' ' . date_i18n( $time_format, $start_timestamp ) ),
						);
					}
					?>
					<?php if ( ! empty( $booking_rows ) ) : ?>
						<tr class="ccp_table_row_booking">
							<td colspan="3">
								<div class="ccp_booking_details">
									<strong><?php esc_html_e( 'Booking Details', 'woocommerce-wholesale-pricing' ); ?></strong>
									<ul>
										<?php foreach ( $booking_rows as $booking_row ) : ?>
											<li>
												<span class="ccp_booking_label"><?php echo esc_html( $booking_row['label'] ); ?>:</span>
												<span class="ccp_booking_value"><?php echo esc_html( $booking_row['value'] ); ?></span>
											</li>
										<?php endforeach; ?>
									</ul>
								</div>
							</td>
						</tr>
					<?php endif; ?>
				<?php endif; ?>
			<?php endforeach; ?>
		</table>

		<div class="ccp_totalcoloum">
			<button type="button" id="ccp_add_to_cart_shared" class="wwp-ccp-btn wwp-ccp-btn--primary">
				<?php esc_html_e( 'Add to Cart', 'woocommerce-wholesale-pricing' ); ?>
			</button>
		</div>
		<input type="hidden" name="action" value="ccp_add_to_cart_shared">
		<input type="hidden" name="post_id" value="<?php echo esc_attr( $post_data->ID ); ?>">
		<input type="hidden" name="nonce" value="<?php echo esc_attr( wp_create_nonce( 'ccp_user_security' ) ); ?>">
	</form>
</div>
