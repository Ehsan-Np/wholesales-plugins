<div class="wwp_requisition_list_main">
	<div class="container wwp_requisition_list">
		<h2><?php esc_html_e('Shopping lists', 'woocommerce-wholesale-pricing'); ?></h2>
			<button id="add_new_list" class="add_new_list"> + <?php esc_html_e('New List', 'woocommerce-wholesale-pricing'); ?></button>
			<table id="table_id" class="display">
				<thead>
					<tr>
						<td><?php esc_html_e('List name', 'woocommerce-wholesale-pricing'); ?></td>
						<td><?php esc_html_e('Number of items', 'woocommerce-wholesale-pricing'); ?></td>
						<td><?php esc_html_e('Actions', 'woocommerce-wholesale-pricing'); ?></td>
						<td><?php esc_html_e('Delete', 'woocommerce-wholesale-pricing'); ?></td>
					</tr>
				</thead>
				<tbody></tbody>
			</table>
		</div>
		<div id="myModal" class="modal">
			<div class="modal-content">
				<div class="modal-header">
					<h3><?php esc_html_e('Requisition list', 'woocommerce-wholesale-pricing'); ?></h3><span class="close">&times;</span>
				</div>
				<center>
					<div class="loader"></div>
				</center>
				<div class="modal-body"></div>
		</div>
	</div>
</div>
