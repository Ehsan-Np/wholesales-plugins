<section class="woocommerce-order-details">
	<?php /* translators: %s customer name */ ?>
	<h2 class="woocommerce-order-details__title"><?php printf( esc_html__( '%s Details', 'woocommerce-wholesale-pricing' ), esc_html( $customer->get_display_name() ) ); ?></h2>

	<table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
		<tbody>
			<tr >
				<td class="woocommerce-table__product-name product-name">
					<?php esc_html_e( 'Role:', 'woocommerce-wholesale-pricing' ); ?>
				</td>
				<td class="woocommerce-table__product-total product-total">					
					<?php echo esc_html( $customer->get_role() ); ?>
				</td>
			</tr>

			<tr >
				<td class="woocommerce-table__product-name product-name">
					<?php esc_html_e( 'Username:', 'woocommerce-wholesale-pricing' ); ?>
				</td>
				<td class="woocommerce-table__product-total product-total">
					<?php echo esc_html( $customer->get_username() ); ?>
				</td>
			</tr>

			<tr >
				<td class="woocommerce-table__product-name product-name">
					<?php esc_html_e( 'Email:', 'woocommerce-wholesale-pricing' ); ?>
				</td>
				<td class="woocommerce-table__product-total product-total">
					<?php echo esc_html( $customer->get_email() ); ?>
				</td>
			</tr>

			<tr >
				<td class="woocommerce-table__product-name product-name">
					<?php esc_html_e( 'Address:', 'woocommerce-wholesale-pricing' ); ?>
				</td>
				<td class="woocommerce-table__product-total product-total">
					<?php echo ( $customer->get_billing_address() ) ? esc_html( $customer->get_billing_address() ) : '-'; ?>
				</td>
			</tr>

			<tr >
				<td class="woocommerce-table__product-name product-name">
					<?php esc_html_e( 'City:', 'woocommerce-wholesale-pricing' ); ?>
				</td>
				<td class="woocommerce-table__product-total product-total">
					<?php
					$billing_city = get_user_meta( $customer->get_id(), 'billing_city', true );

					if ( $billing_city && ! empty( $billing_city ) ) {
						echo esc_html( $billing_city );
					} else {
						echo '-';
					}
					?>

				</td>
			</tr>

			<tr >
				<td class="woocommerce-table__product-name product-name">
					<?php esc_html_e( 'Country:', 'woocommerce-wholesale-pricing' ); ?>
				</td>
				<td class="woocommerce-table__product-total product-total">
					<?php
					$billing_country = get_user_meta( $customer->get_id(), 'billing_country', true );

					if ( $billing_country && ! empty( $billing_country ) ) {
						echo esc_html( WC()->countries->countries[ $billing_country ] );
					} else {
						echo '-';
					}
					?>

				</td>
			</tr>
			<tr >
				<td class="woocommerce-table__product-name product-name">
					<?php esc_html_e( 'Phone:', 'woocommerce-wholesale-pricing' ); ?>
				</td>
				<td class="woocommerce-table__product-total product-total">
					<?php echo ( $customer->get_billing_phone() ) ? esc_html( $customer->get_billing_phone() ) : '-'; ?>
				</td>
			</tr>

			<?php
			/**
			 * Filter.
			 *
			 * @since 1.0.4
			 */
			do_action( 'wc_view_customer_details', $customer->get_id() );

			if ( 'yes' == get_post_meta( $agent_id, 'customer_registration', true ) ) {
				?>
			<tr >
				<td colspan="2" class="woocommerce-table__product-name product-name">
					<a href="<?php echo esc_url( wc_get_endpoint_url( 'agent-customer', $customer->get_id() ) ); ?>" class="woocommerce-button button view">
						<?php esc_html_e( 'Edit', 'woocommerce-wholesale-pricing' ); ?>
					</a>
				</td>
			</tr>
				<?php
			}
			?>

		</tbody>

	</table>


	<section class="wc-agent-customer-orders">
		<?php
		wwp_view('sales-agent.my-account.wc-agent-orders-list-view', compact('action', 'orders', 'per_page', 'end_point', 'current_page', 'num_pages'));
		?>
	</section>

</section>
