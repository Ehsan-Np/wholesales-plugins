<div class="wc_list_commissions_my_account" data-url="<?php echo esc_url( wc_get_endpoint_url( $end_point ) ); ?>">
<?php
// part filters

/**
 * Filter.
 *
 * @since 1.0.4
 */
do_action( 'before_front_end_filters_agent_commissions' );
wwp_view('sales-agent.my-account.components.wc-agent-commissions-filters', compact('agent_id', 'end_point'));
/**
	* Filter.
	*
	* @since 1.0.4
	*/
do_action( 'after_front_end_filters_agent_commissions' );
// part list
/**
	* Filter.
	*
	* @since 1.0.4
	*/
do_action( 'before_front_end_list_agent_commissions' );
wwp_view('sales-agent.my-account.components.wc-agent-commissions-table-view', compact('commissions', 'offset', 'per_page'));
/**
	* Filter.
	*
	* @since 1.0.4
	*/
do_action( 'after_front_end_list_agent_commissions' );

// part pagenation
/**
	* Filter.
	*
	* @since 1.0.4
	*/
do_action( 'before_front_end_pagentation_agent_commissions' );
wwp_view('sales-agent.my-account.components.wc-agent-list-pagination-view', compact('per_page', 'end_point', 'current_page', 'num_pages'));
/**
	* Filter.
	*
	* @since 1.0.4
	*/
do_action( 'after_front_end_pagentation_agent_commissions' );
?>
</div>
