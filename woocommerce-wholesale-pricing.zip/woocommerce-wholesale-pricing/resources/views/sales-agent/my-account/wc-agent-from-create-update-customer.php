<?php
defined( 'ABSPATH' ) || exit;
/**
* Filter.
*
* @since 1.0.4
*/
do_action( 'wc_before_edit_customer_form' );
/**
* Filter.
*
* @since 1.0.4
*/
?>
<form class="woocommerce-EditAccountForm edit-account" action="" method="post">
	<?php
	/**
	 * Filter.
	 *
	 * @since 1.0.4
	 */
	do_action( 'wc_before_edit_customer_form_tag' );
	/**
	* Filter.
	*
	* @since 1.0.4
	*/
	do_action( 'wc_before_edit_customer_form_start' );
	/**
	* Filter.
	*
	* @since 1.0.4
	*/
	if ( true === apply_filters( 'wc_sales_agent_show_wholesale_roles', true ) ) {
		$roles = get_terms(
			array(
				'taxonomy'   => 'wholesale_user_roles',
				'hide_empty' => false,
			)
		);

		$data = '';
		if ( isset( $_REQUEST['customer_ws_role'] ) && ! empty( $_REQUEST['customer_ws_role'] ) ) {
			$data = sanitize_text_field( $_REQUEST['customer_ws_role'] );
		} elseif ( isset( $user ) ) {
			$data = implode( ',', $user->roles );
		}

		if ( ! empty( $roles ) ) {
			?>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="customer_display_name">
					<?php esc_html_e( 'Assign Wholesale Role', 'woocommerce-wholesale-pricing' ); ?>&nbsp;<span class="required">*</span>
				</label>		
				<select name="customer_ws_role" class="woocommerce-Input woocommerce-Input--text input-text customer_ws_role">
					<option value="">--Select Role--</option>
					<?php foreach ( $roles as $key => $user_role ) : ?>
						<option value="<?php echo esc_attr( $user_role->slug ); ?>" <?php echo ( isset( $data ) && $data == $user_role->slug ? 'selected="selected"' : '' ); ?> >
							<?php echo esc_html( $user_role->name ); ?>						
						</option>                              
					<?php endforeach; ?>
				</select>
			</p>
			<?php
		}
	}
	?>

	<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
		<label for="customer_display_name"><?php esc_html_e( 'Username', 'woocommerce-wholesale-pricing' ); ?>&nbsp;<span class="required">*</span></label>
		<?php
		$data = '';
		if ( isset( $_REQUEST['customer_display_name'] ) ) {
			$data = sanitize_text_field( $_REQUEST['customer_display_name'] );
		} elseif ( isset( $user ) ) {
			$data = esc_attr( $user->user_login );
		}
		?>
		<input type="text" class="woocommerce-Input woocommerce-Input--email input-text" name="customer_display_name" id="customer_display_name" value="<?php echo esc_attr( $data ); ?>" <?php echo ( $user_id ) ? 'readonly' : ''; ?>/>
	</p>
	<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
		<label for="customer_email"><?php esc_html_e( 'Email address', 'woocommerce-wholesale-pricing' ); ?>&nbsp;<span class="required">*</span></label>

		<?php
		$data = '';
		if ( isset( $_REQUEST['customer_email'] ) ) {
			$data = sanitize_text_field( $_REQUEST['customer_email'] );
		} elseif ( isset( $user ) ) {
			$data = esc_attr( $user->user_email );
		}
		?>
		<input type="email" class="woocommerce-Input woocommerce-Input--email input-text" name="customer_email" id="customer_email" autocomplete="customer_email" value="<?php echo esc_attr( $data ); ?>" />
	</p>
	<p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
		<label for="customer_first_name"><?php esc_html_e( 'First name', 'woocommerce-wholesale-pricing' ); ?></label>
		<?php
		$data = '';
		if ( isset( $_REQUEST['customer_first_name'] ) ) {
			$data = sanitize_text_field( $_REQUEST['customer_first_name'] );
		} elseif ( isset( $user ) ) {
			$data = esc_attr( $user->first_name );
		}
		?>

		<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="customer_first_name" id="customer_first_name" autocomplete="given-name" value="<?php echo esc_attr( $data ); ?>" />
	</p>
	<p class="woocommerce-form-row woocommerce-form-row--last form-row form-row-last">
		<label for="customer_last_name"><?php esc_html_e( 'Last name', 'woocommerce-wholesale-pricing' ); ?></label>

		<?php
		$data = '';
		if ( isset( $_REQUEST['customer_last_name'] ) ) {
			$data = sanitize_text_field( $_REQUEST['customer_last_name'] );
		} elseif ( isset( $user ) ) {
			$data = esc_attr( $user->last_name );
		}
		?>
		<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="customer_last_name" id="customer_last_name" autocomplete="family-name" value="<?php echo esc_attr( $data ); ?>"/>
	</p>
	<div class="clear"></div>
	<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
		<label for="customer_password"><?php esc_html_e( 'Password', 'woocommerce-wholesale-pricing' ); ?>
			<?php if ( empty( $user_id ) ) { ?>
				&nbsp;<span class="required">*</span>
			<?php } ?>
		</label>
		<input type="password" class="woocommerce-Input woocommerce-Input--text input-text" name="customer_password" id="customer_password" value="" /> 
	</p>
	<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
		<label for="customer_company"><?php esc_html_e( 'Company', 'woocommerce-wholesale-pricing' ); ?></label>

		<?php
		$data = '';
		if ( isset( $_REQUEST['customer_company'] ) ) {
			$data = sanitize_text_field( $_REQUEST['customer_company'] );
		} elseif ( isset( $user ) ) {
			$data = esc_attr( $user->billing_company );
		}
		?>
		<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="customer_company" id="customer_company" value="<?php echo esc_attr( $data ); ?>" /> 
	</p>

	<div class="clear"></div>

	<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
		<label for="customer_country"><?php esc_html_e( 'Country', 'woocommerce-wholesale-pricing' ); ?></label>
		<select name="customer_country" class="woocommerce-Input woocommerce-Input--text input-text customer_country">
			<?php foreach ( WC()->countries->get_allowed_countries() as $key_country => $country ) { ?>
				<option value="<?php echo esc_attr( $key_country ); ?>" <?php echo ( isset( $user ) && $user->billing_country == $key_country ) ? "selected='selected'" : ''; ?>><?php echo esc_html( $country ); ?></option>                              
			<?php } ?>
		</select>
	</p>

	<p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
		<label for="customer_address"><?php esc_html_e( 'Street Address', 'woocommerce-wholesale-pricing' ); ?></label>
		<?php
		$data = '';
		if ( isset( $_REQUEST['customer_address'] ) ) {
			$data = sanitize_text_field( $_REQUEST['customer_address'] );
		} elseif ( isset( $user ) ) {
			$data = esc_attr( $user->billing_address_1 );
		}
		?>
		<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="customer_address" id="customer_address" autocomplete="given-name" value="<?php echo esc_attr( $data ); ?>" />
	</p>


	<p class="woocommerce-form-row woocommerce-form-row--last form-row form-row-last">
		<label for="customer_city"><?php esc_html_e( 'Town  / City', 'woocommerce-wholesale-pricing' ); ?></label>
		<?php
		$data = '';
		if ( isset( $_REQUEST['customer_city'] ) ) {
			$data = sanitize_text_field( $_REQUEST['customer_city'] );
		} elseif ( isset( $user ) ) {
			$data = esc_attr( $user->billing_city );
		}
		?>
		<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="customer_city" id="customer_city" autocomplete="family-name" value="<?php echo esc_attr( $data ); ?>" />
	</p>
	<p class="woocommerce-form-row woocommerce-form-row--first form-row form-row-first">
		<label for="customer_state"><?php esc_html_e( 'State', 'woocommerce-wholesale-pricing' ); ?></label>
		<?php
		$data = '';
		if ( isset( $_REQUEST['customer_state'] ) ) {
			$data = sanitize_text_field( $_REQUEST['customer_state'] );
		} elseif ( isset( $user ) ) {
			$data = esc_attr( $user->billing_state );
		}
		?>
		<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="customer_state" id="customer_state" autocomplete="given-name" value="<?php echo esc_attr( $data ); ?>" />
	</p>

	<p class="woocommerce-form-row woocommerce-form-row--last form-row form-row-last">
		<label for="customer_zip"><?php esc_html_e( 'Zip', 'woocommerce-wholesale-pricing' ); ?></label>
		<?php
			$data = '';
		if ( isset( $_REQUEST['customer_zip'] ) ) {
			$data = sanitize_text_field( $_REQUEST['customer_zip'] );
		} elseif ( isset( $user ) ) {
			$data = esc_attr( $user->billing_postcode );
		}
		?>
		<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="customer_zip" id="customer_zip" autocomplete="family-name" value="<?php echo esc_attr( $data ); ?>" />
	</p>

	<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
		<label for="customer_phone"><?php esc_html_e( 'Phone', 'woocommerce-wholesale-pricing' ); ?></label>
				<?php
				$data = '';
				if ( isset( $_REQUEST['customer_phone'] ) ) {
					$data = sanitize_text_field( $_REQUEST['customer_phone'] );
				} elseif ( isset( $user ) ) {
					$data = esc_attr( $user->billing_phone );
				}
				?>
		<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="customer_phone" id="customer_phone" value="<?php echo esc_attr( $data ); ?>" /> 
	</p>


	<div class="clear"></div>

	<?php
	/**
	 * Filter.
	 *
	 * @since 1.0.4
	 */
	do_action( 'wc_edit_customer_form', $user_id );
	?>

	<p>
		<?php wp_nonce_field( 'sales_agent_nonce', 'sales_agent_nonce' ); ?>
		<button type="submit" class="woocommerce-Button button" name="save_customer_details" value="<?php esc_attr_e( 'Save changes', 'woocommerce-wholesale-pricing' ); ?>"><?php esc_html_e( 'Save changes', 'woocommerce-wholesale-pricing' ); ?></button>
		<input type="hidden" name="action" value="save_customer_details" />
		<input type="hidden" name="customer_id" value="<?php echo esc_attr( $user_id ); ?>" />
	</p>

	<?php
	/**
	 * Filter.
	 *
	 * @since 1.0.4
	 */
	do_action( 'wc_edit_customer_form_end', $user_id );
	?>
</form>

<?php
/**
 * Filter.
 *
 * @since 1.0.4
 */
do_action( 'wc_after_edit_customer_form' );
?>
