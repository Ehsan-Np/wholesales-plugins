<?php
if ( isset( $total_rows ) && ! empty( $total_rows ) ) {
	$num_pages = ! empty( $total_rows ) ? ceil( count( $total_rows ) / $per_page ) : '';
}
$total_num_page = isset( $total_rows ) && ! empty( $total_rows ) ? $total_rows : $num_pages;
if ( 1 < $total_num_page ) : ?>
	<div class="woocommerce-pagination woocommerce-pagination--without-numbers woocommerce-Pagination">
	<?php if ( 1 !== (int) $current_page ) : ?>
		<a class="woocommerce-button woocommerce-button--previous woocommerce-Button woocommerce-Button--previous button" href="
		<?php
		/**
		 * Filter.
		 *
		 * @since 1.0.4
		 */
		echo esc_url( apply_filters( 'wc_agent_myaccount_pagination_previous', wc_get_endpoint_url( $end_point, $current_page - 1 ), $end_point ) );
		?>
		">
		<?php esc_html_e( 'Previous', 'woocommerce-wholesale-pricing' ); ?></a>
	<?php endif; ?>
	<?php if ( intval( $num_pages ) !== $current_page && $current_page < $num_pages ) : ?>
		<a class="woocommerce-button woocommerce-button--next woocommerce-Button woocommerce-Button--next button" href="
		<?php
		/**
		 * Filter.
		 *
		 * @since 1.0.4
		 */
		echo esc_url( apply_filters( 'wc_agent_myaccount_pagination_next', wc_get_endpoint_url( $end_point, $current_page + 1 ), $end_point ) );
		?>
		">
		<?php
		esc_html_e( 'Next', 'woocommerce-wholesale-pricing' );
		?>
		</a>
	<?php endif; ?>
	</div>
<?php endif; ?>
