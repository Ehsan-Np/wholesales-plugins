<?php 
	use WooCommerceWholesalePricing\App\Models\SalesAgent\Agent;
	use WooCommerceWholesalePricing\App\Modules\SalesAgent\Actions;
	use WooCommerceWholesalePricing\App\Modules\SalesAgent\UserSwitching;
?>
<div class="account-orders-table-wrapper">
	<?php if ( ! empty( $users ) ) : ?>
		<table class="account-orders-table-wrapper woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
			<thead>
				<tr>
					<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-number"><span class="nobr"><?php esc_html_e( 'Customer', 'woocommerce-wholesale-pricing' ); ?></span></th>
					<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-status"><span class="nobr"><?php esc_html_e( 'Country', 'woocommerce-wholesale-pricing' ); ?></span></th>
					<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-status"><span class="nobr"><?php esc_html_e( 'Company', 'woocommerce-wholesale-pricing' ); ?></span></th>
					<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-status"><span class="nobr"><?php esc_html_e( 'Phone', 'woocommerce-wholesale-pricing' ); ?></span></th>
					<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-status"><span class="nobr"><?php esc_html_e( 'Role', 'woocommerce-wholesale-pricing' ); ?></span></th>
					<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-total"><span class="nobr"><?php esc_html_e( 'Total Amount', 'woocommerce-wholesale-pricing' ); ?></span></th>
					<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-total"><span class="nobr"><?php esc_html_e( 'Total Orders', 'woocommerce-wholesale-pricing' ); ?></span></th>
					<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-actions"><span class="nobr"><?php esc_html_e( 'Actions', 'woocommerce-wholesale-pricing' ); ?></span></th>
				</tr>
			</thead>

			<tbody>
		<?php
		foreach ( $users as $key => $item ) {
			$agent = new Agent();
			$agent_id   = Actions::is_agent();
			
			if ( get_post_meta($agent_id, 'assign_user', true) == $item->ID ) {
continue;
			}
			
			$order_details       = $agent->get_customer_total_order( $item->ID, $agent_id );
			?>
						<tr class="woocommerce-orders-table__row woocommerce-orders-table__row--status-processing order">
							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number" data-title="Customer">
			<?php
			echo esc_html( $item->display_name );
			echo '<br>';
			echo esc_html( $item->user_email );
			?>
							</td>
							<!-- <td  class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number" data-title="Order">
			<?php
			$address_1 = get_user_meta( $item->ID, 'billing_address_1', true );
			if ( $address_1 ) {
				echo esc_html( $address_1 );
			} else {
				echo '-';
			}
			?>
							</td> -->
						<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-status" data-title="Country">
			<?php
			$billing_country = get_user_meta( $item->ID, 'billing_country', true );
			if ( $billing_country && ! empty( $billing_country ) ) {
				echo esc_html( WC()->countries->countries[ $billing_country ] );
			} else {
				echo '-';
			}
			?>
							</td>							
							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-status" data-title="Company	">
								<?php echo ! empty( get_user_meta( $item->ID, 'billing_company', true ) ) ? esc_html( get_user_meta( $item->ID, 'billing_company', true ) ) : '-'; ?>
							</td>
							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-status" data-title="Phone">
								<?php echo ! empty( get_user_meta( $item->ID, 'billing_phone', true ) ) ? esc_html( get_user_meta( $item->ID, 'billing_phone', true ) ) : '-'; ?>
							</td>
							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-status" data-title="Role">
								<?php
								if ( is_array( $item->roles ) && count( $item->roles ) > 0 ) {
									$roles = implode( ', ', $item->roles );
									echo esc_html( $roles );
								} else {
									echo '-';
								}
								?>
							</td>

							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-total" data-title="Total Amount">
			<?php echo wp_kses_post( wc_price( $order_details['total'] ) ); ?>
							</td>
							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-total" data-title="Total Orders">
			<?php echo esc_html( $order_details['count'] ); ?>      
							</td>

							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-actions action-agent-front" data-title="Actions">
								<a class="woocommerce-button button view-agent-front" href="<?php echo esc_url( wc_get_endpoint_url( 'view-customer', $item->ID ) ); ?>" class=""><?php esc_html_e( 'View', 'woocommerce-wholesale-pricing' ); ?></a>

			<?php
			$user = get_userdata( $item->ID );
			/**
			 *
			 * FIlter.
			 *
			 * @since 1.6.0
			*/
			$url = apply_filters( 'wc_agent_switch_to_user', UserSwitching::switch_to_url( $user ) );

			if ( $url ) {
				?>

									<a href="<?php echo esc_url( $url ); ?>" class="woocommerce-button button "><?php esc_html_e( 'Make Order', 'woocommerce-wholesale-pricing' ); ?></a>    
			<?php } ?>
							</td>
						</tr>
			<?php
		}

		?>
			</tbody>
		</table>
	<?php else : ?>
		<div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info agent_dashboard_msg">
		<?php esc_html_e( 'No Customers Found!', 'woocommerce-wholesale-pricing' ); ?>
		</div>
	<?php endif; ?>
</div>
