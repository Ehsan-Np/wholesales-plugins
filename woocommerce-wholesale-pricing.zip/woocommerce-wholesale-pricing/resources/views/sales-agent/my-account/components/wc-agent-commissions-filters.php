<div class="filter-actions mb-30">
	<form method="get" class="commission-filters-form" action="<?php echo esc_url( wc_get_endpoint_url( $end_point ) ); ?>">
		<div class="filter-row">
			<div class="filter-col" style="">
				<label> <?php esc_html_e( 'Filter customer', 'woocommerce-wholesale-pricing' ); ?> </label>				
				<?php
				$user   = get_current_user_id();
				$args   = array(
					'post_type'   => 'agent',
					'post_status' => 'publish',
					'meta_key'    => 'assign_user',
					'meta_value'  => $user,
				);
				$agents = get_posts( $args );

				if ( ! empty( $agents ) ) {
					$agent_id = $agents[0]->ID;
				}
				?>

				<input name="agent_id" value="<?php echo ( isset( $agent_id ) ) ? esc_attr( sanitize_text_field( $agent_id ) ) : ''; ?>" type="hidden">
				<select name="user-filter" class="user-filter" data-placeholder="<?php esc_attr_e( 'search by customer name or email', 'woocommerce-wholesale-pricing' ); ?>"> 
					<?php
						$user_string = '';
						$user_filter = '';
						// get user that filter with

					if ( isset( $_REQUEST['user-filter'] ) && ! empty( $_REQUEST['user-filter'] ) ) {

						$selected    = ' selected = "selected"';
						$user_filter = isset( $_REQUEST['user-filter'] ) ? sanitize_text_field( $_REQUEST['user-filter'] ) : '';
						$user        = get_user_by( 'id', $user_filter );
						$user_string = sprintf(
						/* translators: 1: user display name 2: user ID 3: user email */
							esc_html__( '%1$s (#%2$s ; %3$s)', 'woocommerce-wholesale-pricing' ),
							$user->display_name,
							absint( $user->ID ),
							$user->user_email
						);
					}
					$flags = ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401;
					?>
					<option class="user_selected" value="<?php echo esc_attr( $user_filter ); ?>" selected="selected"> <?php echo esc_html( $user_string ); ?> </option>
					
				</select>
			</div>
		</div>
		<div class="filter-row">
			<div class="filter-col">
				<label> <?php esc_html_e( 'Filter Date', 'woocommerce-wholesale-pricing' ); ?> </label>
				<div class="filter-datepicker flex-wrapper align-center">
					<input type="text" id="commission_date_from" name="date_from" size="5" placeholder="<?php esc_html_e( 'Start Date', 'woocommerce-wholesale-pricing' ); ?>" value="<?php echo ( isset( $_REQUEST['date_from'] ) ) ? esc_attr( sanitize_text_field( $_REQUEST['date_from'] ) ) : ''; ?>" autocomplete="off">
					<label class="px-10">:</label>
					<input type="text" id="commission_date_to" name="date_to" size="5" placeholder="<?php esc_html_e( 'End Date', 'woocommerce-wholesale-pricing' ); ?>" value="<?php echo ( isset( $_REQUEST['date_to'] ) ) ? esc_attr( sanitize_text_field( $_REQUEST['date_to'] ) ) : ''; ?>" autocomplete="off">
				</div>
			</div>
		</div>
		<div class="flex-wrapper justify-end pull-right" style="margin-top: 20px;">
			<input type="submit" class="button commission-filter-submit agent-commission-filter" value="<?php esc_attr_e( 'Filter', 'woocommerce-wholesale-pricing' ); ?>">
			<input type="button" data-url="<?php echo esc_url( wc_get_endpoint_url( $end_point ) ); ?>" class="button clear-filters" value="<?php esc_attr_e( 'Clear', 'woocommerce-wholesale-pricing' ); ?>">
		</div>
	</form>
	<form method="post" class="form-export" style="display:inline;">
		<?php wp_nonce_field( '_export_commissions_nonce', 'export_commissions_nonce' ); ?>
		<input name="agent_id" value="<?php echo ( isset( $agent_id ) ) ? absint( $agent_id ) : ''; ?>" type="hidden">
		<input type="submit" name="export_commissions" id="export_commissions" class="button button-primary" value="<?php esc_attr_e( 'Export', 'woocommerce-wholesale-pricing' ); ?>">
	</form>
</div>
