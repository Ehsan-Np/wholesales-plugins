<div class="filter-actions ">

	<select name="user-filter" class="user-filter" data-placeholder="<?php esc_attr_e( 'search by customer name or email', 'woocommerce-wholesale-pricing' ); ?>" >

		<?php
		$user_string = '';
		$user_filter = '';
		$flags       = ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401;
		// get user that filter with
		if ( isset( $_GET['user-filter'] ) ) {
			$selected    = ' selected = "selected"';
			$user_filter = isset( $_GET['user-filter'] ) ? sanitize_text_field( $_GET['user-filter'] ) : '';
			$user        = get_user_by( 'id', $user_filter );
			$user_string = sprintf(
			/* translators: 1: user display name 2: user ID 3: user email */
				esc_html__( '%1$s (#%2$s ; %3$s)', 'woocommerce-wholesale-pricing' ),
				$user->display_name,
				absint( $user->ID ),
				$user->user_email
			);
		}
		?>
		<option value="<?php echo esc_attr( $user_filter ); ?>" selected="selected"><?php echo wp_kses_post( htmlspecialchars( $user_string, $flags ) ); // htmlspecialchars to prevent XSS when rendered by selectWoo. ?><option>
				</select>
	<div class="flex-wrapper align-center justify-between mt-10" style="display: flex;justify-content: space-between;">
		<input type="submit" class="button submit-filters pull-right" value="<?php esc_html_e( 'Filter', 'woocommerce-wholesale-pricing' ); ?>">

		<?php
		if ( 'yes' == get_post_meta( $agent_id, 'customer_registration', true ) ) {
			?>
				<a href="<?php echo esc_url( wc_get_endpoint_url( 'agent-customer' ) ); ?>" class="button create-customer"><?php esc_html_e( 'Create Customer', 'woocommerce-wholesale-pricing' ); ?></a>
			<?php
		}
		?>
	</div>
</div>
