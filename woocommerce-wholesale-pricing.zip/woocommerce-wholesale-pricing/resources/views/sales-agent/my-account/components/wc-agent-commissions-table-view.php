<?php
global $wpdb;
$user_id = get_current_user_id();

$agent_post = get_posts(
	array(
		'post_type'        => 'agent',
		'numberposts'      => 1,
		'meta_key'         => 'assign_user',
		'meta_value'       => $user_id,
		'suppress_filters' => true,
	)
);

if ( isset( $agent_post[0] ) && ! empty( $agent_post[0] ) ) {
	$agent_id    = $agent_post[0]->ID;
	$prepare     = 'prepare';
	$get_results = 'get_results';
	/**
	 *
	 * FIlter.
	 *
	 * @since 1.6
	 */
	$commission_status = apply_filters( 'wc_agent_commission_status_filter', 'all' );
	if (
		isset( $_REQUEST['agent_id'] ) &&
		(
			(
				isset( $_REQUEST['date_from'] ) &&
				isset( $_REQUEST['date_to'] ) &&
				isset( $_REQUEST['user-filter'] ) &&
				! empty( sanitize_text_field( $_REQUEST['user-filter'] ) )
			) ||
			(
				isset( $_REQUEST['date_from'] ) &&
				! empty( sanitize_text_field( $_REQUEST['date_from'] ) )
			) ||
			(
				isset( $_REQUEST['date_to'] ) &&
				! empty( sanitize_text_field( $_REQUEST['date_to'] ) )
			)
		)
	) {
		if ( ! empty( sanitize_text_field( $_REQUEST['user-filter'] ) )
			&& ! empty( sanitize_text_field( $_REQUEST['date_from'] ) )
			&& ! empty( sanitize_text_field( $_REQUEST['date_to'] ) ) ) {

			$from        = gmdate( 'Y-m-d 00:00:01', strtotime( sanitize_text_field( $_REQUEST['date_from'] ) ) );
			$to          = gmdate( 'Y-m-d 23:59:59', strtotime( sanitize_text_field( $_REQUEST['date_to'] ) ) );
			$user_filter = sanitize_text_field( $_REQUEST['user-filter'] );
			$agent_id    = ! empty( $_REQUEST['agent_id'] ) ? sanitize_text_field( $_REQUEST['agent_id'] ) : $agent_id;
			$rows        = $wpdb->get_results(
				$wpdb->prepare(
					"
			        SELECT DISTINCT com.agent_id, com.order_id, com.create_date, 
			                        com.commission_type, com.commission_percentage, 
			                        com.commission_value, com.commission_status, com.id
			        FROM {$wpdb->prefix}wc_agents_commissions com
					LEFT JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
			        WHERE com.agent_id = %d 
			        AND o.customer_id = %d 
			        AND com.commission_status = %s
			        AND (com.create_date >= %s AND com.create_date <= %s)
			        ",
					$agent_id,
					$user_filter,
					$commission_status,
					$from,
					$to
				)
			);

			$total_rows = $wpdb->get_results(
				$wpdb->prepare(
					"
			        SELECT DISTINCT com.agent_id, com.order_id, com.create_date, 
			                        com.commission_type, com.commission_percentage, 
			                        com.commission_value, com.commission_status, com.id
			        FROM {$wpdb->prefix}wc_agents_commissions com
					LEFT JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
			        WHERE com.agent_id = %d 
			        AND o.customer_id = %d 
			        AND com.commission_status = %s
			        AND (com.create_date >= %s AND com.create_date <= %s)
			        ",
					$agent_id,
					$user_filter,
					$commission_status,
					$from,
					$to
				)
			);

		} elseif ( ! empty( sanitize_text_field( $_REQUEST['user-filter'] ) )
			&& empty( sanitize_text_field( $_REQUEST['date_from'] ) )
			&& empty( sanitize_text_field( $_REQUEST['date_to'] ) ) ) {

			$user_filter = sanitize_text_field( $_REQUEST['user-filter'] );
			$agent_id    = ! empty( $_REQUEST['agent_id'] ) ? sanitize_text_field( $_REQUEST['agent_id'] ) : $agent_id;
			$rows        = $wpdb->get_results(
				$wpdb->prepare(
					"
			        SELECT DISTINCT com.agent_id, com.order_id, com.create_date, 
			                        com.commission_type, com.commission_percentage, 
			                        com.commission_value, com.commission_status, com.id
			        FROM {$wpdb->prefix}wc_agents_commissions com
					LEFT JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
			        WHERE com.agent_id = %d 
			        AND o.customer_id = %d 
			        AND com.commission_status = %s
			        ",
					$agent_id,
					$user_filter,
					$commission_status
				)
			);
			$total_rows  = $wpdb->get_results(
				$wpdb->prepare(
					"
			        SELECT DISTINCT com.agent_id, com.order_id, com.create_date, 
			                        com.commission_type, com.commission_percentage, 
			                        com.commission_value, com.commission_status, com.id
			        FROM {$wpdb->prefix}wc_agents_commissions com
					LEFT JOIN {$wpdb->prefix}wc_orders o ON com.order_id = o.id
			        WHERE com.agent_id = %d 
			        AND o.customer_id = %d 
			        AND com.commission_status = %s
			        ",
					$agent_id,
					$user_filter,
					$commission_status
				)
			);
		} elseif ( empty( sanitize_text_field( $_REQUEST['user-filter'] ) )
			&& ! empty( sanitize_text_field( $_REQUEST['date_from'] ) )
			&& ! empty( sanitize_text_field( $_REQUEST['date_to'] ) ) ) {

			$from     = gmdate( 'Y-m-d 00:00:01', strtotime( sanitize_text_field( $_REQUEST['date_from'] ) ) );
			$to       = gmdate( 'Y-m-d 23:59:59', strtotime( sanitize_text_field( $_REQUEST['date_to'] ) ) );
			$agent_id = ! empty( $_REQUEST['agent_id'] ) ? sanitize_text_field( $_REQUEST['agent_id'] ) : $agent_id;

			$rows       = $wpdb->$get_results( // phpcs:ignore QITStandard.DB.DynamicWpdbMethodCall.DynamicMethod
				$wpdb->$prepare( // phpcs:ignore QITStandard.DB.DynamicWpdbMethodCall.DynamicMethod
					"
					SELECT DISTINCT agent_id, order_id, create_date, commission_type, commission_percentage, commission_value, commission_status, id  
					FROM {$wpdb->prefix}wc_agents_commissions
					LEFT JOIN {$wpdb->prefix}postmeta ON {$wpdb->prefix}wc_agents_commissions.order_id = {$wpdb->prefix}postmeta.post_id
					WHERE agent_id = %d  
					" . ( 'all' != $commission_status ? "AND {$wpdb->prefix}wc_agents_commissions.commission_status = %s " : '' ) . '
					AND ( create_date >= %s AND create_date <= %s ) 
					ORDER BY id DESC LIMIT %d, %d
					',
					...( 'all' != $commission_status ? array( $agent_id, $commission_status, $from, $to, $offset, $per_page ) : array( $agent_id, $from, $to, $offset, $per_page ) )
				)
			);
			$total_rows = $wpdb->$get_results( // phpcs:ignore QITStandard.DB.DynamicWpdbMethodCall.DynamicMethod
				$wpdb->$prepare( // phpcs:ignore QITStandard.DB.DynamicWpdbMethodCall.DynamicMethod
					"
					SELECT DISTINCT agent_id, order_id, create_date, commission_type, commission_percentage, commission_value, commission_status, id  
					FROM {$wpdb->prefix}wc_agents_commissions
					LEFT JOIN {$wpdb->prefix}postmeta ON {$wpdb->prefix}wc_agents_commissions.order_id = {$wpdb->prefix}postmeta.post_id
					WHERE agent_id = %d  
					" . ( 'all' != $commission_status ? "AND {$wpdb->prefix}wc_agents_commissions.commission_status = %s " : '' ) . '
					AND ( create_date >= %s AND create_date <= %s ) 
					ORDER BY id DESC
					',
					...( 'all' != $commission_status ? array( $agent_id, $commission_status, $from, $to ) : array( $agent_id, $from, $to ) )
				)
			);
		}
	} else {
		$rows = $wpdb->$get_results( // phpcs:ignore QITStandard.DB.DynamicWpdbMethodCall.DynamicMethod
			$wpdb->$prepare( // phpcs:ignore QITStandard.DB.DynamicWpdbMethodCall.DynamicMethod
				"
				SELECT * FROM {$wpdb->prefix}wc_agents_commissions ac
				LEFT JOIN {$wpdb->prefix}posts p ON p.ID = ac.agent_id 
				WHERE agent_id = %s 
				" . ( 'all' != $commission_status ? 'AND ac.commission_status = %s ' : '' ) . '
				ORDER BY ac.id DESC LIMIT %d, %d
				',
				...( 'all' != $commission_status ? array( $agent_id, $commission_status, $offset, $per_page ) : array( $agent_id, $offset, $per_page ) )
			)
		);
		

		$total_rows = $wpdb->$get_results( // phpcs:ignore QITStandard.DB.DynamicWpdbMethodCall.DynamicMethod
			$wpdb->$prepare( // phpcs:ignore QITStandard.DB.DynamicWpdbMethodCall.DynamicMethod
				"
				SELECT * FROM {$wpdb->prefix}wc_agents_commissions ac
				LEFT JOIN {$wpdb->prefix}posts p ON p.ID = ac.agent_id 
				WHERE agent_id = %s AND ac.commission_status != 'pending' ORDER BY 'id' DESC
				",
				$agent_id
			)
		);
	}
}

?>
<div class="account-orders-table-wrapper">
<?php if ( ! empty( $rows ) ) : ?>
	<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
		<thead>
			<tr>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-number"><span class="nobr"><?php esc_html_e( 'Order No.', 'woocommerce-wholesale-pricing' ); ?></span></th>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-number"><span class="nobr"><?php esc_html_e( 'Customer Name', 'woocommerce-wholesale-pricing' ); ?></span></th>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-status"><span class="nobr">
				<?php
				/**
				 * Filter.
				 *
				 * @since 1.3
				 */
				esc_html_e( apply_filters( 'safw_endpoint_comm_list_order_date_heading', 'Order Date' ), 'woocommerce-wholesale-pricing' );
				?>
				</span></th>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-total"><span class="nobr"><?php esc_html_e( 'Commissions', 'woocommerce-wholesale-pricing' ); ?></span></th>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-total"><span class="nobr"><?php esc_html_e( 'Status', 'woocommerce-wholesale-pricing' ); ?></span></th>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-actions"><span class="nobr"><?php esc_html_e( 'Actions', 'woocommerce-wholesale-pricing' ); ?></span></th>
			</tr>
		</thead>

		<tbody>
			<?php
			foreach ( $rows as $key => $item ) {
				?>
						<tr class="woocommerce-orders-table__row woocommerce-orders-table__row--status-processing order">
							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number" data-title="Order No.">
								<a href="<?php echo esc_url( wc_get_endpoint_url( 'view-order', $item->order_id ) ); ?>"> 
									<?php
									echo esc_html( $item->order_id );
									?>
								</a>
							</td>

							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number" data-title="Customer Name">
								<?php
								$user_id  = wc_get_order( $item->order_id )->get_user();
								$fullname = $user_id->display_name;
								echo esc_html( $fullname );
								?>
							</td>

							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-status" data-title="Order Date">
							<?php
							/**
							 * Filter.
							 *
							 * @since 1.2
							 *
							 * Custom Task - CT-220
							 */
							$date = apply_filters( 'safw_endpoint_order_comm_list_date', gmdate( 'F d,Y', strtotime( $item->create_date ) ), $item );
							echo esc_html( $date );
							?>

							</td>
							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-total" data-title="Commissions">
				<?php echo wp_kses_post( wc_price( $item->commission_value ) ); ?>      
							</td>
							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-total" data-title="Status">
								<?php echo esc_html( $item->commission_status ); ?>
							</td>

							<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-actions action-agent-front" data-title="Actions">
								<a class="woocommerce-button button  view-agent-front" href="<?php echo esc_url( wc_get_endpoint_url( 'view-order', $item->order_id ) ); ?>" data-commss="<?php echo esc_attr( $item->id ); ?>" data-order="<?php echo esc_attr( $item->order_id ); ?>"><?php esc_html_e( 'Details', 'woocommerce-wholesale-pricing' ); ?></a>
								<a class="delete-commission woocommerce-button button " href="#" data-commss="<?php echo esc_attr( $item->id ); ?>" data-order="<?php echo esc_attr( $item->order_id ); ?>"><?php esc_html_e( 'Delete', 'woocommerce-wholesale-pricing' ); ?></a>

							</td>
						</tr>
				<?php
			}
			?>
		</tbody>
	</table>

<?php else : ?>
	<div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info agent_dashboard_msg">
	<?php esc_html_e( 'No Commission Found!', 'woocommerce-wholesale-pricing' ); ?>
	</div>
<?php endif; ?>
</div>
