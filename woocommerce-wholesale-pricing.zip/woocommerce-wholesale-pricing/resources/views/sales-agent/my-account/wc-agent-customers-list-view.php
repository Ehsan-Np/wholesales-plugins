<div class="wc_list_customers_my_account">
	<?php
	// part filters
	/**
	 * Filter.
	 *
	 * @since 1.0.4
	 */
	do_action( 'before_front_end_filters_agent_customers' );
	wwp_view('sales-agent.my-account.components.wc-agent-details-filters', compact('agent_id'));
	/**
	* Filter.
	*
	* @since 1.0.4
	*/
	do_action( 'after_front_end_filters_agent_customers' );

	// part list
	/**
	* Filter.
	*
	* @since 1.0.4
	*/
	do_action( 'before_front_end_list_agent_customers' );
	if ( file_exists( get_stylesheet_directory() . '/sales-agent/endpoint/agent/wc-agent-customers-table-view.php' ) ) {
		require_once get_stylesheet_directory() . '/sales-agent/endpoint/agent/wc-agent-customers-table-view.php';
	} else {
		wwp_view('sales-agent.my-account.components.wc-agent-customers-table-view', compact('users'));
	}
	/**
	* Filter.
	*
	* @since 1.0.4
	*/
	do_action( 'after_front_end_list_agent_customers' );
	/**
	* Filter.
	*
	* @since 1.0.4
	*/
	do_action( 'before_front_end_pagentation_agent_customers' );
	wwp_view('sales-agent.my-account.components.wc-agent-list-pagination-view', compact('per_page', 'end_point', 'current_page', 'num_pages'));
	/**
	* Filter.
	*
	* @since 1.0.4
	*/
	do_action( 'after_front_end_pagentation_agent_customers' );
	?>
</div>
