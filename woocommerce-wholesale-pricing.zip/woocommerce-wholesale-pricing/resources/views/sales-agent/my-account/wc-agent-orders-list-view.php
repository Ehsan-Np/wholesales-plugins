<?php

defined( 'ABSPATH' ) || exit;
$has_orders = count( $orders );
/**
 * Filter.
 *
 * @since 1.0.4
 */
do_action( 'wc_agent_before_customer_orders', $has_orders );
?>


<form method="GET" action="<?php echo ( isset( $action ) ) ? esc_attr( $action ) : ''; ?>" class="search-order-from">
	<div class="search-box flex-wrapper justify-end">
		<label class="screen-reader-text" for="post-search-input"><?php esc_html_e( 'Search orders:', 'woocommerce-wholesale-pricing' ); ?></label>
		<input type="search" id="post-search-input" name="serch" value="<?php echo ( isset( $_GET['serch'] ) ) ? esc_attr( sanitize_text_field( $_GET['serch'] ) ) : ''; ?>">
		<input type="submit" id="search-submit" class="button" value="<?php esc_html_e( 'Search orders', 'woocommerce-wholesale-pricing' ); ?>">
	</div>
</form>

<?php if ( $has_orders ) : ?>
	<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table agent-orders-table">
		<thead>
			<tr>
				<?php
				// Get columns with the filter applied
				/**
				 * Filter.
				 *
				 * @since 1.6
				 */
				$columns = apply_filters( 'wc_agent_my_account_orders_columns', wc_get_account_orders_columns() );

				foreach ( $columns as $column_id => $column_name ) :
					?>
					<th class="woocommerce-orders-table__header woocommerce-orders-table__header-<?php echo esc_attr( $column_id ); ?>">
						<span class="nobr"><?php echo esc_html( $column_name ); ?></span>
					</th>
				<?php endforeach; ?>
			</tr>
		</thead>

		<tbody>
			<?php
			foreach ( $orders as $c_order ) :
				// Get row data with the filter applied
				/**
				 * Filter.
				 *
				 * @since 1.6
				*/
				$row_data = apply_filters( 'wc_agent_my_account_orders_columns_data', array(), $c_order );
				?>
				<tr class="woocommerce-orders-table__row woocommerce-orders-table__row--status-<?php echo esc_attr( $c_order->get_status() ); ?> order">
					<?php foreach ( $columns as $column_id => $column_name ) : ?>
						<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-<?php echo esc_attr( $column_id ); ?>" data-title="<?php echo esc_attr( $column_name ); ?>">
							<?php if ( has_action( 'woocommerce_my_account_my_orders_column_' . $column_id ) ) : ?>
								<?php
								/**
								 * Filter.
								 *
								 * @since 1.0.4
								 */
								do_action( 'woocommerce_my_account_my_orders_column_' . $column_id, $c_order );
								?>

							<?php elseif ( isset( $row_data[ $column_id ] ) ) : ?>
								<?php echo esc_html( $row_data[ $column_id ] ); ?>

							<?php elseif ( 'order-number' === $column_id ) : ?>
								<a href="<?php echo esc_url( $c_order->get_view_order_url() ); ?>#agentsCustomerOrder">
									<?php echo wp_kses_post( _x( '#', 'hash before order number', 'woocommerce-wholesale-pricing' ) . $c_order->get_order_number() ); ?>
								</a>

							<?php elseif ( 'order-date' === $column_id ) : ?>
								<time datetime="<?php echo esc_attr( $c_order->get_date_created()->date( 'c' ) ); ?>">
									<?php echo esc_html( wc_format_datetime( $c_order->get_date_created() ) ); ?>
								</time>

							<?php elseif ( 'order-status' === $column_id ) : ?>
								<?php echo wp_kses_post( wc_get_order_status_name( $c_order->get_status() ) ); ?>

							<?php elseif ( 'order-total' === $column_id ) : ?>
								<?php
								/* translators: 1: formatted order total 2: total order items */
								echo wp_kses_post( $c_order->get_formatted_order_total() );
								?>

							<?php elseif ( 'order-actions' === $column_id ) : ?>
								<?php
								$actions = wc_get_account_orders_actions( $c_order );

								if ( ! empty( $actions ) ) {
									foreach ( $actions as $key => $value ) {
										if ( 'view' == $key ) {
											echo '<a href="' . esc_url( $value['url'] ) . '#agentsCustomerOrder" class="woocommerce-button button ' . sanitize_html_class( $key ) . '">' . esc_html( $value['name'] ) . '</a>';
										}
									}
								}
								?>
							<?php endif; ?>
						</td>
					<?php endforeach; ?>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<?php
	/**
	 * Filter.
	 *
	 * @since 1.0.4
	 */
	do_action( 'wc_agent_before_customer_orders_pagination' );

	wwp_view('sales-agent.my-account.components.wc-agent-list-pagination-view', compact('per_page', 'end_point', 'current_page', 'num_pages'));
	?>

<?php else : ?>
	<div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info agent_dashboard_msg">
		<?php esc_html_e( 'No order found.', 'woocommerce-wholesale-pricing' ); ?>
	</div>
<?php endif; ?>

<?php
/**
 * Filter.
 *
 * @since 1.0.4
 */
do_action( 'wc_agent_after_customer_orders', $has_orders );
?>
