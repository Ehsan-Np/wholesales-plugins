<?php

use WooCommerceWholesalePricing\App\Models\SalesAgent\AgentCommission;
use WooCommerceWholesalePricing\App\Providers\WholesaleSettingsHelper;

$agent_payout_detail = get_post_meta( $agent_id, 'agent_payout_detail', true );
$payout_method       = isset( $agent_payout_detail['payout-method'] ) ? $agent_payout_detail['payout-method'] : '';
$bank_info           = isset( $agent_payout_detail['bank'] ) ? $agent_payout_detail['bank'] : '';
$paypal_info         = isset( $agent_payout_detail['paypal'] ) ? $agent_payout_detail['paypal'] : '';

$agent_paypal_email         = isset( $paypal_info['paypal_email'] ) ? $paypal_info['paypal_email'] : '';
$agent_bank_full_name       = isset( $bank_info['full_name'] ) ? $bank_info['full_name'] : '';
$agent_bank_billing_address = isset( $bank_info['billing_address'] ) ? $bank_info['billing_address'] : '';
$agent_bank_city            = isset( $bank_info['bank_city'] ) ? $bank_info['bank_city'] : '';
$agent_bank_state           = isset( $bank_info['bank_state'] ) ? $bank_info['bank_state'] : '';
$agent_bank_bank_name       = isset( $bank_info['bank_name'] ) ? $bank_info['bank_name'] : '';
$agent_bank_account_number  = isset( $bank_info['account_number'] ) ? $bank_info['account_number'] : '';
$agent_bank_postal_code     = isset( $bank_info['postal_code'] ) ? $bank_info['postal_code'] : '';
$agent_bank_phone_number    = isset( $bank_info['phone_number'] ) ? $bank_info['phone_number'] : '';
$commission_db              = new AgentCommission();
$select_commissions         = $commission_db->get_pending_commission_by_agent_id( $agent_id, 'pending' );

$pending_commission = 0.0;
if ( is_array( $select_commissions ) && count( $select_commissions ) > 0 ) {
	foreach ( $select_commissions as $commission ) {
		$pending_commission += (float) $commission->commission_value;
	}
}

$settings = WholesaleSettingsHelper::get_pricing_settings();

?>

<div class='payout-title'>
	<h1><?php echo esc_html__( 'Payouts', 'woocommerce-wholesale-pricing' ); ?></h1>
	<p><?php echo esc_html__( 'View and keep track of your payouts.', 'woocommerce-wholesale-pricing' ); ?></p>
</div>
<div class='flex-container'>
	<div class='payout-box'>
		<h2><?php echo esc_html__( 'Available for Payout', 'woocommerce-wholesale-pricing' ); ?></h2>
		<div class='payout-content'>
			<h1><?php echo wp_kses_post( wc_price( $pending_commission ) ); ?></h1>
			<p><?php echo esc_html__( 'This is amount you currently have in earnings, available for your next payouts.', 'woocommerce-wholesale-pricing' ); ?></p>
			<img src="<?php echo esc_url( WWP_PLUGIN_URL . 'public/images/sales-agent/payout.png' ); ?>" />
		</div>
	</div>
	<?php if ( ( isset( $settings['sales_agent_paypal_payout'] ) && 'yes' == $settings['sales_agent_paypal_payout'] ) || ( isset( $settings['sales_agent_bacs_payout'] ) && 'yes' == $settings['sales_agent_bacs_payout'] ) ) : ?>
		<div class='payout-box set_account'>
			<h2><?php echo esc_html__( 'Payout Account', 'woocommerce-wholesale-pricing' ); ?></h2>
			<div class='payout-content'>
				<h1><?php echo esc_html__( 'Set payout Account', 'woocommerce-wholesale-pricing' ); ?></h1>
				<a class='configure-setup'><i class="fas fa-cog"></i><?php echo esc_html__( 'Configure', 'woocommerce-wholesale-pricing' ); ?></a>
				<img src="<?php echo esc_url( WWP_PLUGIN_URL . 'public/images/sales-agent/account-payout.png' ); ?>" />
			</div>
		</div>
	<?php endif; ?>
</div>

<?php
$is_manager       = get_post_meta( $agent_id, 'is_manager', true );
$paid_commissions = $commission_db->get_pending_commission_by_agent_id( $agent_id, 'paid' );
$rows             = array();
if ( is_array( $paid_commissions ) ) {
	foreach ( $paid_commissions as $commission ) {
		$commission->type = 'commission';
		$rows[]           = $commission;
	}
}
?>
<div class="account-orders-table-wrapper agent_commission_status">

<?php if ( ! empty( $rows ) ) { ?>
	<table class="woocommerce-orders-table woocommerce-MyAccount-orders shop_table shop_table_responsive my_account_orders account-orders-table">
		<thead>
			<tr>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-number"><span class="nobr"><?php esc_html_e( 'Order No.', 'woocommerce-wholesale-pricing' ); ?></span></th>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-status"><span class="nobr">
				<?php
				/**
				 * Filter.
				 *
				 * @since 1.3
				 */
				esc_html_e( apply_filters( 'safw_endpoint_payout_order_date_heading', 'Order Date' ), 'woocommerce-wholesale-pricing' );
				?>
				</span></th>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-total"><span class="nobr"><?php esc_html_e( 'Commissions', 'woocommerce-wholesale-pricing' ); ?></span></th>
				<?php if ( ! empty( $is_manager ) && 'yes' == $is_manager ) : ?>
					<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-total"><span class="nobr"><?php esc_html_e( 'Sub Commissions', 'woocommerce-wholesale-pricing' ); ?></span></th>
				<?php endif; ?>
				<th class="woocommerce-orders-table__header woocommerce-orders-table__header-order-total"><span class="nobr"><?php esc_html_e( 'Status', 'woocommerce-wholesale-pricing' ); ?></span></th>
			</tr>
		</thead>
		<tbody>
			<?php
			foreach ( $rows as $key => $item ) {
				?>
				<tr class="woocommerce-orders-table__row woocommerce-orders-table__row--status-processing order">
					<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-number" data-title="Order">
						<a href="<?php echo esc_url( wc_get_endpoint_url( 'view-order', $item->order_id ) ); ?>"> 
							<?php
							echo esc_html( $item->order_id );
							?>
						</a>
					</td>
					<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-status" data-title="Status">
					<?php
					/**
					 * Filters.
					 *
					 * @since 1.2
					 *
					 * Custom Task - CT-220
					 */
					$date = apply_filters( 'safw_endpoint_order_payout_date', gmdate( 'F d,Y', strtotime( $item->create_date ) ), $item );
					echo esc_html( $date );
					?>
					</td>
					<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-total" data-title="Total">
						<?php if ( 'commission' == $item->type ) : ?>
							<?php echo wp_kses_post( wc_price( $item->commission_value ) ); ?>      
						<?php else : ?>
							-
						<?php endif; ?>
					</td>
					<?php if ( ! empty( $is_manager ) && 'yes' == $is_manager ) : ?>
						<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-total" data-title="Total">
							<?php if ( 'subcommission' == $item->type ) : ?>
								<?php echo wp_kses_post( wc_price( $item->commission_value ) ); ?>      
							<?php else : ?>
								-
							<?php endif; ?>   
						</td>
					<?php endif; ?>
					<td class="woocommerce-orders-table__cell woocommerce-orders-table__cell-order-total" data-title="Total">
						<?php echo esc_html( $item->commission_status ); ?>      
					</td>
				</tr>
				<?php
			}
			?>
		</tbody>
	</table>

<?php } else { ?>
	<div class="woocommerce-message woocommerce-message--info woocommerce-Message woocommerce-Message--info woocommerce-info agent_dashboard_msg">
		<?php esc_html_e( 'No Payouts Found!', 'woocommerce-wholesale-pricing' ); ?>
	</div>
<?php } ?>
</div>

<!-- The Modal -->
<div id="SalesAgentModal" class="modal">
	<!-- Modal content -->
	<div class="payment_configure">
	<div class="modal-header">
		<h3><?php echo esc_html__( 'Set Payout Method', 'woocommerce-wholesale-pricing' ); ?></h3>
		<span class="close">&times;</span>
	</div>
	<div class="modal-body">
	<h3><?php echo esc_html__( 'Select a Payment Method', 'woocommerce-wholesale-pricing' ); ?></h3>
		<form id='payment_form' method='post'>
			<?php
			if ( isset( $settings['sales_agent_paypal_payout'] ) && 'yes' === $settings['sales_agent_paypal_payout'] ) {
				?>
				<div class='payout_option'>
					<input type="radio" <?php checked( 'paypal', $payout_method, true ); ?>  id="paypal" class='payment-opt' name="payout-method" value="paypal" required>
					<label for="paypal"><?php echo esc_html__( 'Paypal', 'woocommerce-wholesale-pricing' ); ?></label>	
				</div>
				<?php
			}

			if ( isset( $settings['sales_agent_bacs_payout'] ) && 'yes' === $settings['sales_agent_bacs_payout'] ) {
				?>
				<div class='payout_option'>
					<input type="radio" <?php checked( 'bank', $payout_method, true ); ?> id="banktransfer" class='payment-opt' name="payout-method" value="bank" required>
					<label for="banktransfer"><?php echo esc_html__( 'Bank Transfer', 'woocommerce-wholesale-pricing' ); ?></label>
				</div>
				<?php
			}
			?>
			<div class='payment-info'>
				<?php
				if ( isset( $settings['sales_agent_paypal_payout'] ) && 'yes' === $settings['sales_agent_paypal_payout'] ) {
					?>
					<div class='paypal-info'>
						<div class='info-field'>
							<label for="paypal_email"><?php echo esc_html__( 'Paypal Email Address', 'woocommerce-wholesale-pricing' ); ?></label><br>
							<input type="email" name='paypal[paypal_email]' class='info-field paypal_email' value='<?php echo esc_attr_e( $agent_paypal_email, 'woocommerce-wholesale-pricing' ); ?>'/>
						</div>
					</div>
					<?php
				}
				if ( isset( $settings['sales_agent_bacs_payout'] ) && 'yes' === $settings['sales_agent_bacs_payout'] ) {
					$fields = '<div class="bank-info">
                        <div class="info-field">
                            <label for="full_name">' . esc_html__( 'Full Name', 'woocommerce-wholesale-pricing' ) . '*</label><br>
                            <input type="text" name="bank[full_name]" class="info-field" value="' . esc_attr( $agent_bank_full_name ) . '"/>
                        </div>
                        <div class="info-field">
                            <label for="billing_address">' . esc_html__( 'Billing Address', 'woocommerce-wholesale-pricing' ) . '</label><br>
                            <input type="text" name="bank[billing_address]" class="info-field" value="' . esc_attr( $agent_bank_billing_address ) . '"/>
                        </div>
                        <div class="info-field">
                            <label for="bank_city">' . esc_html__( 'City', 'woocommerce-wholesale-pricing' ) . '*</label><br>
                            <input type="text" name="bank[bank_city]" class="info-field" value="' . esc_attr( $agent_bank_city ) . '"/>
                        </div>
                        <div class="info-field">
                            <label for="bank_state">' . esc_html__( 'State', 'woocommerce-wholesale-pricing' ) . '</label><br>
                            <input type="text" name="bank[bank_state]" class="info-field" value="' . esc_attr( $agent_bank_state ) . '"/>
                        </div>
                        <div class="info-field">
                            <label for="bank_name">' . esc_html__( 'Bank Name', 'woocommerce-wholesale-pricing' ) . '*</label><br>
                            <input type="text" name="bank[bank_name]" class="info-field" value="' . esc_attr( $agent_bank_bank_name ) . '"/>
                        </div>
                        <div class="info-field">
                            <label for="account_number">' . esc_html__( 'Account No#', 'woocommerce-wholesale-pricing' ) . '*</label><br>
                            <input type="text" name="bank[account_number]" class="info-field" value="' . esc_attr( $agent_bank_account_number ) . '"/>
                        </div>
                        <div class="info-field">
                            <label for="postal_code">' . esc_html__( 'Postal Code', 'woocommerce-wholesale-pricing' ) . '</label><br>
                            <input type="text" name="bank[postal_code]" class="info-field" value="' . esc_attr( $agent_bank_postal_code ) . '"/>
                        </div>
                        <div class="info-field">
                            <label for="phone_number">' . esc_html__( 'Phone Number', 'woocommerce-wholesale-pricing' ) . '</label><br>
                            <input type="text" name="bank[phone_number]" class="info-field" value="' . esc_attr( $agent_bank_phone_number ) . '"/>
                        </div>
                    </div>';
					/**
					* Filter.
					*
					* @since 1.4
					*/
					$fields = apply_filters( 'wc_agent_payout_fields', $fields );
					echo wp_kses(
						$fields,
						array(
							'div'   => array( 'class' => array() ),
							'label' => array( 'for' => array() ),
							'input' => array(
								'type'  => array(),
								'name'  => array(),
								'class' => array(),
								'value' => array(),
							),
							'br'    => array(),
						)
					);
				}
				?>
			</div>
			<input type="hidden" name='payment_agent_id' class='paymemt_agent_id' value='<?php echo esc_attr( $agent_id ); ?>'/>
			<input type='submit' data-ajax="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" class='payment-info-submit' value="Send"/>
		</form>
	</div>
	</div>
</div>