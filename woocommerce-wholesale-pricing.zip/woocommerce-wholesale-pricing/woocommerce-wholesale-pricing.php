<?php
/**
 * Plugin Name: Wholesale For WooCommerce
 * Plugin URI: https://woocommerce.com/products/wholesale-for-woocommerce/
 * Description: Wholesale for WooCommerce enables store owners to create and manage wholesale prices, multiple wholesale user roles, user registration forms, product and price visibility, tax, payment and shipping methods, and much more.
 * Version: 3.5.0
 * Author: WPExperts
 * Author URI: https://wpexperts.io
 * Developer: WPExperts
 * Developer URI: https://wpexperts.io
 * Text Domain: woocommerce-wholesale-pricing
 * Requires PHP: 5.6
 * Requires at least: 5.6
 * Tested up to: 7.1.3
 * WC requires at least: 5.0
 * WC tested up to: 11.2.1
 * Requires Plugins: woocommerce
 * Copyright: © 2009-2015 WooCommerce.
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * Woo: 4830851:fd98fab857870bb9b375e1e0ca9d003e

 */
namespace WooCommerceWholesalePricing\App;

use WooCommerceWholesalePricing\Bootstrap\Installation;

if (! defined('ABSPATH') ) {
	exit(); // exit if directly access
}

/**
 * ----------------
 * Plugin Constants
 * ----------------
 */
define('WWP_FILE', __FILE__);
define('WWP_PLUGIN_URL', plugin_dir_url(WWP_FILE));
define('WWP_PUBLIC_URL', WWP_PLUGIN_URL . 'public');
define('WWP_PLUGIN_PATH', plugin_dir_path(WWP_FILE));
define('WWP_BASENAME', 'woocommerce-wholesale-pricing');
define('WWP_VERSION', '3.5.0');

if (! defined('WWP_IS_FREEMIUS_BUILD') ) {
	define('WWP_IS_FREEMIUS_BUILD', false);
}

if (file_exists(WWP_PLUGIN_PATH . '/vendor/autoload.php') ) {
	include_once WWP_PLUGIN_PATH . '/vendor/autoload.php';
}

/* FREEMIUS BLOCK REMOVED FOR WOO BUILD */

if (! class_exists('WooCommerceWholesalePricing') ) {
	  
	/**
	 * WooCommerceWholesalePricing
	 */
	class WooCommerceWholesalePricing {
	
	 

		/**
		 * Method __construct
		 *
		 * @return void
		 */
		public function __construct() {
			global $wfw_fs;

			$can_load_app = true;

			if (WWP_IS_FREEMIUS_BUILD && ! empty($wfw_fs) ) {
				$can_load_app = $wfw_fs->can_use_premium_code();
			}

			if ($can_load_app ) {
				( include_once WWP_PLUGIN_PATH . 'bootstrap/app.php' )
				->load();
				/**
				 * 'woocommerce_wholesale_pricing_init' action.
				 *
				 * @since 3.0.0
				 */
				do_action('woocommerce_wholesale_pricing_init');
			} else {
				freemius_license_missing_notice();
			}
		}
	}
	  
	( new WooCommerceWholesalePricing() );
	/**
	 * -----------------------------------------------------------
	 * Require installation file to create database if not exists.
	 * -----------------------------------------------------------
	 */

	register_activation_hook(__FILE__, array( ( new Installation() ), 'init' ));

}
