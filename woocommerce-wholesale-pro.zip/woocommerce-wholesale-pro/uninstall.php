<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$preserve_data = ! filter_var( get_option( 'wcwp_delete_data_on_uninstall', 'no' ), FILTER_VALIDATE_BOOLEAN );

if ( $preserve_data ) {
	return;
}

global $wpdb;

/**
 * 1. DELETE ALL TRANSIENTS
 *
 * Delete named transients and all wcwp_ prefixed transients (price/role caches).
 */
$transients_to_delete = [
	'wcwp_check_uploaded_file_protection',
	'barn2_plugin_review_banner_194346',
	'barn2_plugin_promo_194346',
	'barn2_notice_dismissed_first_activation_194346',
];

foreach ( $transients_to_delete as $transient ) {
	delete_transient( $transient );
}

// Delete all price and role cache transients stored by the plugin.
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options}
		 WHERE option_name LIKE %s
		    OR option_name LIKE %s",
		$wpdb->esc_like( '_transient_wcwp_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_wcwp_' ) . '%'
	)
);

/**
 * 2. DELETE ALL OPTIONS
 */
$setting_options = [
	'wcwp_admin_wholesale_pricing',
	'wcwp_apply_to_sale_price',
	'wcwp_db_version',
	'wcwp_default_role',
	'wcwp_delete_data_on_uninstall',
	'wcwp_disable_coupons',
	'wcwp_disable_tax',
	'wcwp_disable_tax_role',
	'wcwp_enable_registration',
	'wcwp_global_discounts',
	'wcwp_hide_prices',
	'wcwp_hide_prices_text',
	'wcwp_layout_store_page',
	'wcwp_layout_taxonomy_pages',
	'wcwp_login_redirect',
	'wcwp_moderate_registrations',
	'wcwp_payment_roles',
	'wcwp_product_pricing',
	'wcwp_product_sale_pricing',
	'wcwp_registration_fields',
	'wcwp_registration_redirect',
	'wcwp_role_order',
	'wcwp_roles_with_sale_pricing',
	'wcwp_shipping_roles',
	'wcwp_show_original_price',
	'wcwp_tax_display_shop_role',
	'wcwp_wholesale_login_page_id',
	'wcwp_wholesale_store_page_id',
	'widget_wcwp_layered_nav',
	'widget_wcwp_layered_nav_filters',
	'widget_wcwp_price_filter',
	'widget_wcwp_rating_filter',
];

foreach ( $setting_options as $option ) {
	delete_option( $option );
}

delete_option( 'woocommerce_wholesale_pro_version' );
delete_option( 'barn2_plugin_license_194346' );

// Delete WooCommerce shipping method instance settings (stored as woocommerce_{method_id}_{instance_id}_settings).
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options}
		 WHERE option_name LIKE %s
		    OR option_name LIKE %s
		    OR option_name LIKE %s",
		$wpdb->esc_like( 'woocommerce_wcwp_flat_rate_' ) . '%',
		$wpdb->esc_like( 'woocommerce_wcwp_free_shipping_' ) . '%',
		$wpdb->esc_like( 'woocommerce_wcwp_local_pickup_' ) . '%'
	)
);

/**
 * 3. DELETE PRODUCT AND ORDER META
 *
 * - wcwp_*  : per-product wholesale pricing overrides (key = role name, e.g. wcwp_wholesale / wcwp_wholesale_sale)
 * - _wwp_wholesale_visibility : product-level wholesale visibility override
 * - _wholesale : marks orders as wholesale orders
 */

// Product pricing meta (keys match the role name, all prefixed wcwp_).
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE %s",
		$wpdb->esc_like( 'wcwp_' ) . '%'
	)
);

// Product wholesale visibility meta.
$wpdb->delete( $wpdb->postmeta, [ 'meta_key' => '_wwp_wholesale_visibility' ] );

// Wholesale order marker meta (traditional post-based orders).
$wpdb->delete( $wpdb->postmeta, [ 'meta_key' => '_wholesale' ] );

// Wholesale order marker meta (WooCommerce HPOS / custom orders table).
$hpos_orders_meta_table = $wpdb->prefix . 'wc_orders_meta';
if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $hpos_orders_meta_table ) ) === $hpos_orders_meta_table ) {
	$wpdb->delete( $hpos_orders_meta_table, [ 'meta_key' => '_wholesale' ] ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
}

/**
 * 4. DELETE CATEGORY (TERM) META
 *
 * - wcwp_visibility        : category wholesale visibility setting
 * - wcwp_visiblity_control : visibility control mode (note: intentional typo in meta key)
 * - wcwp_hide_prices       : hide prices for this category
 * - wcwp_*                 : per-role discount values stored per category
 */
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->termmeta} WHERE meta_key LIKE %s",
		$wpdb->esc_like( 'wcwp_' ) . '%'
	)
);

/**
 * 5. DELETE USER META
 *
 * - wcwp_moderation_required : flags a user as requiring moderation
 * - wcwp_send_default_mail   : transient flag used during approval flow
 * - wcwp-*                   : custom registration field values (keys generated as uniqid('wcwp-'))
 */
$user_meta_keys = [
	'wcwp_moderation_required',
	'wcwp_send_default_mail',
];

foreach ( $user_meta_keys as $meta_key ) {
	$wpdb->delete( $wpdb->usermeta, [ 'meta_key' => $meta_key ] ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
}

// Custom registration field values stored with keys like 'wcwp-{uniqid}'.
$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
		$wpdb->esc_like( 'wcwp-' ) . '%'
	)
);

/**
 * 6. DELETE WOOCOMMERCE SHIPPING ZONE METHOD INSTANCES
 */
$shipping_zone_methods_table = $wpdb->prefix . 'woocommerce_shipping_zone_methods';

if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $shipping_zone_methods_table ) ) === $shipping_zone_methods_table ) {
	foreach ( [ 'wcwp_flat_rate', 'wcwp_free_shipping', 'wcwp_local_pickup' ] as $method_id ) {
		$wpdb->delete( $shipping_zone_methods_table, [ 'method_id' => $method_id ] );
	}
}

/**
 * 7. REMOVE WHOLESALE USER ROLES
 *
 * Remove all wcwp_ roles (wcwp_pending, wcwp_wholesale, and any custom roles
 * created by the admin). Users retain their other roles if they have any.
 */
global $wp_roles;

if ( ! isset( $wp_roles ) ) {
	$wp_roles = new WP_Roles(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
}

foreach ( array_keys( $wp_roles->roles ) as $role_slug ) {
	if ( strncmp( $role_slug, 'wcwp_', 5 ) === 0 ) {
		remove_role( $role_slug );
	}
}
