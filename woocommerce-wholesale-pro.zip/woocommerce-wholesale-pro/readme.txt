=== WooCommerce Wholesale Pro ===
Contributors: barn2media
Tags: woocommerce, wholesale
Requires at least: 6.1
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 2.5.0
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

The easy way to add a wholesale area to any WooCommerce store.

== Description ==

The easy way to add a wholesale area to any WooCommerce store.

== Installation ==

1. Go to Plugins -> Add New -> Upload and select the plugin ZIP file (see link in Purchase Confirmation Email).
1. Activate the plugin
1. Enter your license key under WooCommerce -> Settings -> Wholesale -> General
1. Follow our setup guide here.

== Frequently Asked Questions ==

Please refer to [our support page](https://barn2.com/our-wordpress-plugins/woocommerce-wholesale-pro-documentation-support/).

== Changelog ==

= 2.5.0 =
Release date 14 May 2026

 * New: Added a customizable registration form for wholesale customers
 * Dev: Tested up to WordPress 7.0 and WooCommerce 10.8

= 2.4.0 =
Release date 6 May 2026

 * New: Added quick and bulk editor support for wholesale visibility
 * Fix: Wholesale visibility settings not working under certain conditions
 * Fix: Prices being displayed for hidden products under certain conditions
 * Fix: The name of certain payment gateways not displaying in the Payment Roles tab
 * Fix: Yoast SEO throwing a fatal error when optimizing the Wholesale Login page
 * Fix: "Hide out-of-stock products" setting not being honored by wholesale visibility setting
 * Tweak: Added database cleanup on uninstall
 * Tweak: Other minor code improvements
 * Dev: Removed use of `wc_enqueue_js()` function
 * Dev: Tested up to WordPress 6.9.4 and WooCommerce 10.7.0

= 2.3.4 =
Release date 16 September 2025

 * New: Added Danish tranlsation
 * New: Added German translation
 * New: Added Spanish translation
 * New: Added Finnish translation
 * New: Added French translation
 * New: Added Italian translation
 * New: Added Japanese translation
 * New: Added Korean translation
 * New: Added Norwegian translation
 * New: Added Dutch translation
 * New: Added Polish translation
 * New: Added Portuguese translation
 * New: Added Russian translation
 * New: Added Swedish translation
 * New: Added Chinese translation
 * Fix: Changes to the product query being made too early
 * Fix: Wholesale pricing being disregarded for variable products
 * Fix: WooCommerce Subscription generating an infinite loop
 * Fix: Moved disappeared Payment roles section to Wholesale settings tab
 * Tweak: Moved Shipping roles section to Wholesale settings tab for consistency
 * Dev: Added filter hook for order custom column
 * Dev: Updated internal dependency libraries
 * Dev: Tested up to WordPress 6.8.2 and WooCommerce 10.1.2

= 2.3.3 =
Release date 13 May 2025

 * Fix: Prices not being hidden under certain conditions
 * Fix: Fatal error when hiding prices in the Elementor editor
 * Fix: Recipients of wholesale admin emails not being saved
 * Dev: Tested up to WordPress 6.8.1 and WooCommerce 9.8.5

= 2.3.2 =
Release date 28 April 2025

 * Fix: Logic that disregards wholesale pricing not working properly
 * Fix: Wholesale/retail order filter appearing on every post type
 * Fix: Regression of i18n in WordPress 6.8.0
 * Dev: Tested up to WordPress 6.8.0 and WooCommerce 9.8.2

= 2.3.1 =
Release date 20 March 2025

 * Fix: Product visibility not working when ACF is active
 * Fix: Critical error being thrown on edit order page under certain conditions
 * Fix: Issue with protected products and custom menus
 * Fix: Error with early loading of text domain in WordPress 6.7
 * Fix: Add-to-cart form not being hidden for guests in Avada and Elementor Pro
 * Fix: Sale badge not showing for variable products
 * Tweak: Improved performance of wholesale price calculation of variations
 * Tweak: Other minor improvements
 * Dev: Added filter to further improve wholesale calculation workflow
 * Dev: Updated internal libraries
 * Dev: Tested up to WordPress 6.7.2 and WooCommerce 9.7.1

= 2.3.0 =
Release date 16 October 2024

 * New: Set the wholesale visibility at the product level.
 * Tweak: Protect cross-sells, up-sells, and related products that are output with core WooCommerce functions.
 * Tweak: Ensure the plugin promo only dislays on the general settings section.
 * Tweak: Improved the display of the wholesale roles table at various viewport widths.
 * Fix: Visiblity settings were not correctly disabled under certain conditions in wp-admin category management.
 * Dev: Removed support for experimental WooCommerce navigation.
 * Dev: Tested up to WordPress 6.6.2 and WooCommerce 9.3.3.

<!--more-->

= 2.2.0 =
Release date 13 August 2024

 * New: Option to set a custom registration redirect URL.
 * New: A `{registration_fields}` email placeholder tag for the 'New wholesale user' email.
 * New: Available email placeholders are now displayed in the email settings.
 * New: Use the default WooCommerce shop page as the wholesale store page.
 * New: Setup a wholesale specific order form layout with WooCommerce Product Table 4.0.0.
 * Fix: Incorrect price in the cart when a discount is applied to the sale price for wholesale users.
 * Dev: Tested up to WordPress 6.6.1 and WooCommerce 9.1.4.

= 2.1.5 =
Release date 26 June 2024

 * New: Translation contribution - Deutsch
 * Fix: "Hide prices until login" not working with block themes
 * Fix: Order edit page - Wholesale sale price is not used
 * Fix: Sale price changes when you quick edit the product
 * Fix: Divi - Fatal error on cart when using theme builder and logged out
 * Fix: Wholesale price being used when customer is created during manual order
 * Fix: Wholesale filter widgets don't work on homepage
 * Fix: Tax is added to tax-exempt roles when entering an order manually
 * Tweak: Divi - Wholesale price is not showing with theme builder
 * Tweak: Changed SEO title of Wholesale Store page
 * Dev: Tested up to WordPress 6.5.4 and WooCommerce 9.0.2

= 2.1.4 =
Release date 13 February 2024

 * Fix: Table layout not working for tag archives
 * Fix: Category discount not being used when product has normal sale price
 * Fix: Fatal error being triggered on settings pages when license key is inactive or invalid
 * Tweak: Improved template overriding for `archive-product.php` template
 * Tweak: Improved integration with themes
 * Dev: Updated internal libraries and dependencies
 * Dev: Tested up to WordPress 6.4.3 and WooCommerce 8.5.2

= 2.1.3 =
Release date 14 December 2023

 * Fix: Warnings and notices are triggered when WC is deactivated
 * Fix: Sort by wholesale user dropdown is not showing in the admin orders page
 * Fix: Script for email templates is broken
 * Fix: The setup Wizard is not working on activation
 * Fix: Price suffix is not showing for variable products
 * Fix: "Hide prices from logged out users" hides the price for logged in users too
 * Fix: Integration with WooCommerce Product Table
 * Tweak: Improved price handling and mini cart output
 * Tweak: Other minor improvements
 * Dev: Tested up to WordPress 6.4.2 and WooCommerce 8.3.1
 * Dev: Updated internal libraries and dependencies

= 2.1.2 =
Release date 27 October 2023

 * Fix: Setup Wizard triggering a critical error upon first activation
 * Dev: Tested up to WordPress 6.4.0 and WooCommerce 8.2.1
 * Dev: Updated internal libraries and dependencies

= 2.1.1 =
Release date 29 August 2023

 * Fix: Wholesale price is not correct when discount is 100%

= 2.1.0 =
Release date 10 August 2023

 * Fix: Cart page shows retail price when the Divi Woo Cart module is used
 * Fix: Wholesale prices not being applied correctly in order edit page
 * Fix: Sale price is disregarded when no wholesale discount is set
 * Fix: Sale price for wholesale customer not being correctly applied to cart
 * Fix: Removed PHP Warning when deleting a role
 * Fix: Improved compatibility with Legacy REST API
 * Fix: Fatal error when manually adding a fee to an order
 * Tweak: Improved style of login/register form in Twenty Twenty-Three
 * Tweak: Completely redesigned price calculation logic
 * Tweak: Improved utility methods for wholesale customer detection
 * Dev: Enabled HPOS compatibility
 * Dev: Updated internal libraries
 * Dev: Tested up to WP 6.3 and WooCommerce 8.0

= 2.0.8 =
Release date 14 June 2023

 * Fix: Empty role discount triggering a PHP error
 * Fix: Increased manual totals reverting to original value in the order editor
 * Fix: Null sale price of wholesale-only variations affecting price calculation
 * Tweak: Improved conditions for on-sale status
 * Tweak: Improved clearance of product variation transients

= 2.0.7 =
Release date 18 May 2023

 * Fix: Totals manually set in the administrative order page are overridden by the wholesale price calculation
 * Fix: Wholesale Sale Price is not showing when no wholesale price is specified
 * Fix: Original price shows as zero for wholesale-only products
 * Tweak: Improved price display in some edge cases
 * Tweak: Added script on product editor to validate sale prices
 * Dev: Tested up to WooCommerce 7.7

= 2.0.6 =
Release date 5 May 2023

 * Fix: Price being 0 for wholesale-only variations with no retail variations
 * Fix: Wholesale Sale Price not showing under certain conditions
 * Fix: Archive template not compatible with FSE Themes
 * Fix: Wrong template for Wholesale Store page when an FSE theme is used
 * Tweak: Improved price calculations and formatting

= 2.0.5 =
Release date 2 May 2023

 * Fix: Wholesale prices are always rounded to 2 decimals, regardless of WooCommerce settings
 * Fix: Wholesale/Retail dropdown mistakenly added to Products page
 * Tweak: Transients of wholesale prices can now be cleared together with the "WooCommerce Transients"
 * Dev: Tested up to WordPress 6.2 and WooCommerce 7.6
 * Dev: Updated internal libraries

= 2.0.4 =
Release date 12 April 2023

 * Fix: Roles using names with non-ASCII characters cannot be edited or deleted
 * Fix: Retail customers see the wrong prices when prices include taxes

= 2.0.3 =
Release date 22 March 2023

 * Fix: Variable products show wrong prices when “Prices entered with tax” and “Display prices in the shop” options do not match
 * Fix: Variation products show wrong prices when on sale

= 2.0.2 =
Release date 1 March 2023

 * Fix: Creating or updating a new order from the admin area results in a blank page
 * Fix: PHP Warning for undefined $user variable when calculating role-based prices
 * Dev: Tested up to WooCommerce 7.4.1

= 2.0.1 =
Release date 28 February 2023

 * Fix: Error triggered when wholesale roles visit the page of a product with no wholesale discounts
 * Tweak: Improved price range styling
 * Tweak: Optimized utility methods that retrieve the wholesale role of the currently logged-in user

= 2.0.0 =
Release date 23 February 2023

 * New: Added column and filters to easily search for orders by customers' role (retail or wholesale)
 * New: Added capability to shop managers who can now handle customers' registration
 * New: Added possibility to input orders in the admin area with prices automatically adjusting to the selected customer's role
 * New: Added sale prices specific to wholesale roles
 * New: Added new Shipping Method classes to improve flexibility of role-based shipping methods
 * New: Added possibility to specify the 'Hide price until login' option by product category
 * Tweak: Optimized visibility of role-based navigation menus
 * Tweak: Improved display of wholesale prices for variable products

= 1.7.7 =
Release date 11 January 2023

 * Dev: Add a cart flag for other plugins to determine if the cart item has a wholesale price.
 * Dev: Updated Barn2 internal libraries.
 * Dev: Tested up to WooCommerce 7.2.3 and WordPress 6.1.1

= 1.7.6 =
Release date 9 August 2022

 * Fix: Wholesale store is empty when permalinks are set as plain.
 * Fix: Redirecting to a custom URL does not work when a subdomain is used.
 * Fix: Submenus being pushed to top level when parent menu is hidden.
 * Fix: Wholesale price not being removed at product level.
 * Fix: Sub-category not inheriting the wholesale discount of the parent category
 * Dev: Added support to auto-updates
 * Dev: Tested up to WooCommerce 6.7.0 and WordPress 6.0.1

= 1.7.5 =
Release date 26 May 2022

 * Fix: Hide prices until login feature did not work with the Flatsome UX builder add to cart module.
 * Dev: Documented all available actions and filters.
 * Dev: Updated Barn2 internal libraries.
 * Dev: Tested up to WooCommerce 6.5.1 and WordPress 6.0.

= 1.7.4 =
Release date 15 April 2022

 * Fix: Two save buttons were visible in the wholesale role editing screen.
 * Fix: Products without wholesale prices would not show dropdowns in WooCommerce Product Table
 * Dev: Tested up to WooCommerce 6.4.0.

= 1.7.3 =
Release date 6 April 2022

 * Tweak: Improved compatibility with wholesale priced variations and WooCommerce Product Table.
 * Dev: Tested up to WordPress 5.9.3.

= 1.7.2 =
Release date 17 March 2022

 * Tweak: Email password reset link instead of password for new wholesale customers. [More Information](https://barn2.com/kb/add-password-reset-link-to-email/)
 * Tweak: When clicking 'Add New' via a wholesale role user list in wp-admin, the wholesale role will now be automatically selected.
 * Fix: The default WordPress email was being sent instead of the 'New wholesale account' email when adding wholesale customers via Users > Add New in wp-admin.
 * Fix: Wholesale prices were not displaying on single products when both the Flatsome theme and WooCommerce Product Addons were active.
 * Fix: The plugin would cause a fatal error if activated without WooCommerce active.
 * Dev: Replace deprecated constants for PHP 8.1 compatibility.
 * Dev: Tested up to WooCommerce 6.3.1 and WordPress 5.9.2.

= 1.7.1 =
Release date 24 February 2022

 * Tweak: Improved compatibility with Divi WooCommerce modules and the Alternate Content feature.
 * Fix: Multiple save buttons were appearing on some settings pages.
 * Dev: Compatibility with upcoming Barn2 plugins.
 * Dev: Tested up to WooCommerce 6.2.1 and WordPress 5.9.1

= 1.7 =
Release date 26 November 2021

 * New: Added support for Barn2 setup wizard.
 * Fix: Added support for products with no wholesale price to WPML WooCommerce Multilingual.
 * Dev: Tested up to WooCommerce 5.9 and WordPress 5.8.2

= 1.6.4 =
Release date 26 August 2021

 * New: Custom WooCommerce filter widgets which can be used across the Shop, Wholesale Store, and WooCommerce Product Table pages.
 * Dev: Tested up to WooCommerce 5.6

= 1.6.3 =
Release date 4 August 2021

 * Fix: Price display suffix would not appear next to certain wholesale prices.
 * Fix: Conflict with All in One SEO plugin causing WooCommerce notices to not display on the Login / Register shortcodes.
 * Dev: Tested up to WooCommerce 5.5.2.

= 1.6.2 =
Release date 1 July 2021

 * Fix: WooCommerce Product Addons would ignore sale price for non-wholesale customers.
 * Fix: Error when trying to register a wholesale user with an existing username.
 * Tweak: Better handling of wholesale roles with no global discounts.
 * Dev: Filter for price transients to assist with third party integrations concerning price handling.
 * Dev: Switched to Composer autoloader.
 * Dev: Tested up to WooCommerce 5.4.1 and WordPress 5.8.

= 1.6.1 =
Release date 27 May 2021

 * Tweak: Ensure alternate content only displays in the main single product area.

= 1.6 =
Release date 26 May 2021

 * New: Alternate content option for when prices are hidden from logged out users.
 * New: Option to hide the striked out regular price for wholesale users.
 * New: Compatibility with WooCommerce Product Add-ons, Aelia Currency Switcher and WPML WooCommerce Multilingual.
 * Fix: Plugin activation via WP CLI.
 * Dev: Added Spanish language translation.
 * Dev: Tested up to WooCommerce 5.3.

= 1.5.2 =
Release date 20 April 2021

 * Fix: Resolved a compatibility issue with Elementor which resulted in the Wholesale Store page not displaying products.
 * Dev: Tested up to WooCommerce 5.2.2

= 1.5.1 =
Release date 2 April 2021

 * Fix: SiteGround Optimizer conflict resolved.

= 1.5 =
Release date 1 April 2021

 * New: Added decimal discount support for the category and global settings.
 * Fix: Immediately clear variable price range cache when a user's role has changed.

= 1.4.6 =
Release date 8 March 2021

 * Fix: Wholesale variation price was not shown on single product when all regular variation prices were the same.
 * New: Added support for upcoming WooCommerce navigation.
 * Dev: Tested up to WooCommerce 5.1.

= 1.4.5 =
Release date 15 February 2021

 * Tweak: Remove product offers from structured data when prices are hidden to logged out users.
 * Tweak: Clear the wholesale pricing cache when a product is updated through WP All Import Pro.
 * Dev: Tested up to WooCommerce 5.0.

= 1.4.4 =
Release date 21 January 2021

 * Tweak: Multisite improvements including network activation and wholesale approvals for normal site administrators.

= 1.4.3 =
Release date 11 January 2021

 * Fix: Fixed priority for Public Only protection.
 * Fix: Added better detection of when shortcodes are used in the Block Editor to prevent invalid JSON errors.
 * Tweak: Support old versions of WooCommerce Product Table.
 * Dev: Tested up to WooCommerce 4.9.

= 1.4.2 =
Release date 18 December 2020

 * Fix: Ensure variation price ranges are always displayed correctly for each role.
 * Tweak: Show search query as page title on the product search results page for wholesale users.
 * Tweak: Ensure original price shows for wholesale users on lazy loaded order forms.
 * Dev: Tested up to WordPress 5.6 and WooCommerce 4.8.

= 1.4.1 =
Release date 18 November 2020

 * Fix: Search results for wholesale users.
 * Fix: Support custom decimal separators specified in WooCommerce settings or core filters.
 * Tweak: Don't show the striked out regular price when it is equal to the wholesale price.
 * Dev: Tested up to WordPress 5.5.3 and WooCommerce 4.7.

= 1.4 =
Release date 12 November 2020

 * New: Option to set a custom login redirect URL.
 * Tweak: Redirect wholesale users to the wholesale store or custom URL when using the core WordPress login.

= 1.3.4 =
Release date 4 November 2020

 * Tweak: Improve compatibility for the WooCommerce products search on the wholesale store page when categories display is being used.
 * Tweak: Adjust WooCommerce notice output structure for wider compatiblity across themes.
 * Tweak: Compatiblity with WooCommerce Product Table 2.7 settings pages.

= 1.3.3 =
Release date 15 October 2020

 * Fix: Compatibility for the WooCommerce products search on the wholesale store page.

= 1.3.2 =
Release date 1 October 2020

 * Fix: Wholesale prices were being used in the manual order page.
 * Tweak: Don't show the registration fields heading on the User edit page when there are no fields set.
 * Tweak: Replace the deprecated jQuery hover event in preparation for future WordPress core updates.

= 1.3.1 =
Release date 9 September 2020

 * Tweak: Allow PHP 5.6 back-compatibility.
 * Tweak: Make Public Only products visible to administrators and store managers.
 * Tweak: Respect the ‘Display prices in the shop’ setting when tax is not disabled for wholesale users.

= 1.3 =
Release date 27 August 2020

 * New: Option to disable coupons for wholesale users.
 * New: Option to disable tax for any or all wholesale roles.
 * New: Option to restrict shipping methods to specific roles.
 * New: Option to restrict payment methods to specific roles.
 * New: Add support for zero wholesale prices and 100% discounts.
 * Tweak: Remove Page Templates dropdown from the Wholesale Store page when editing.
 * Tweak: Always clear role pricing cache when a role is updated.
 * Tweak: Show order form layout to administrators and store managers on category archives.
 * Tweak: Hide the 'Sale' label from administrators and store managers.
 * Fix: Registration shortcode caused a PHP notice related to wc_add_notice when added via Gutenberg.
 * Fix: Empty regular price caused a PHP notice under certain discount conditions.

= 1.2 =
Release date 5 August 2020

 * New: Options to add extra fields to the wholesale registration form.
 * New: [wholesale_registration] shortcode.
 * Tweak: Minor changes to wording and labels on General settings page.
 * Fix: PHP 7.4 deprecation notice.
 * Fix: Deleting unordered roles in the Roles settings tab could cause errors.

= 1.1 =
Release date 21 July 2020

 * New: Added 'Hide Price Until Login' feature.
 * New: Allow administrators and store manager roles to see the wholesale area and pricing.
 * Fix: Ensure output of WooCommerce notices on the wholesale login/register page for certain themes.
 * Fix: PHP error relating to WooCommerce notices on the login/register shortcode when consumed via the REST API.
 * Fix: Blank shop pages on certain configurations of Divi Builder.
 * Fix: Missing string translations.

= 1.0.2 =
Release date 7 July 2020

 * Dev: Tested up to WooCommerce 4.3 and WordPress 5.4.2.

= 1.0.1 =
Release date 25 June 2020

 * Fix: Compatibility with Salient Visual Composer.

= 1.0 =
Release date 22 June 2020

 * New: Initial release.