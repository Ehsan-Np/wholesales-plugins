<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Widgets;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Util;

/**
 * Compatibility
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Compatibility implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'widgets_init', [ $this, 'register_widgets' ] );
		add_filter( 'widget_display_callback', [ $this, 'remove_wc_filter_widgets' ], 99, 2 );
	}

	/**
	 * Register Widgets
	 */
	public function register_widgets() {
		$widget_classes = [
			Price_Filter::class,
			Rating_Filter::class,
			Layered_Nav::class,
			Layered_Nav_Filters::class,
		];

		// Register the custom WC filter widgets
		array_map( 'register_widget', array_filter( $widget_classes, 'class_exists' ) );
	}


	/**
	 * Prevents WooCommerce core widgets from displaying on the Wholesale Store page (prevents notices).
	 *
	 * @param mixed $instance
	 * @param WP_Widget $widget_obj
	 * @return mixed $instance
	 */
	public function remove_wc_filter_widgets( $instance, $widget_obj ) {
		if ( Util::is_wholesale_store_page() && ! Util::site_uses_wc_shop_page() ) {
			if ( is_page() && in_array(
				$widget_obj->id_base,
				[
					'woocommerce_layered_nav_filters',
					'woocommerce_layered_nav',
					'woocommerce_price_filter',
					'woocommerce_rating_filter',
				],
				true
			) ) {
					return false;
			}
		}

		return $instance;
	}
}
