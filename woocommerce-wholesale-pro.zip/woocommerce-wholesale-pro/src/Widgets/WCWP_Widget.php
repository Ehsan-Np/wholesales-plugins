<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Widgets;

use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Util as Lib_Util;
use Barn2\Plugin\WC_Product_Table\Util\Util as WPT_Util;
use WC_Widget;
use WC_Query;

/**
 * Wholesale Store Abstract Widget
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
abstract class WCWP_Widget extends WC_Widget {

	/**
	 * Constructor
	 */
	public function __construct() {
		parent::__construct();

		add_filter( 'body_class', [ $this, 'body_class' ], 99 );
	}

	/**
	 * Adds the 'woocommerce' <body> class if the widgets are visible
	 * and pick up correct styles in certain themes (Genesis, Total, etc).
	 *
	 * @param array $classes
	 * @return array $classes
	 */
	public function body_class( $classes ) {

		if ( ! in_array( 'woocommerce', $classes, true ) && $this->is_visible() ) {
			$classes[] = 'woocommerce';
		}

		return $classes;
	}

	/**
	 * Get current page URL with various filtering props supported by WC.
	 *
	 * @return string
	 */
	protected function get_current_page_url() {
		if ( defined( 'SHOP_IS_ON_FRONT' ) ) {
			$link = home_url();
		} elseif ( Util::is_wholesale_store_page() ) {
			$link = Util::get_wholesale_store_url();
		} elseif ( is_shop() ) {
			$link = get_permalink( wc_get_page_id( 'shop' ) );
		} elseif ( is_product_category() ) {
			$link = get_term_link( get_query_var( 'product_cat' ), 'product_cat' );
		} elseif ( is_product_tag() ) {
			$link = get_term_link( get_query_var( 'product_tag' ), 'product_tag' );
		} elseif ( is_singular() ) {
			$link = get_permalink();
		} else {
			$queried_object = get_queried_object();
			$link           = get_term_link( $queried_object->slug, $queried_object->taxonomy );
		}

		// Min/Max.
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['min_price'] ) ) {
			$link = add_query_arg( 'min_price', wc_clean( wp_unslash( $_GET['min_price'] ) ), $link );
		}

		if ( isset( $_GET['max_price'] ) ) {
			$link = add_query_arg( 'max_price', wc_clean( wp_unslash( $_GET['max_price'] ) ), $link );
		}

		// Order by.
		if ( isset( $_GET['orderby'] ) ) {
			$link = add_query_arg( 'orderby', wc_clean( wp_unslash( $_GET['orderby'] ) ), $link );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		/**
		 * Search Arg.
		 * To support quote characters, first they are decoded from &quot; entities, then URL encoded.
		 */
		if ( get_search_query() ) {
			$link = add_query_arg( 's', rawurlencode( htmlspecialchars_decode( get_search_query() ) ), $link );
		}

		// Post Type Arg.
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_GET['post_type'] ) ) {
			$link = add_query_arg( 'post_type', wc_clean( wp_unslash( $_GET['post_type'] ) ), $link );

			// Prevent post type and page id when pretty permalinks are disabled.
			if ( is_shop() ) {
				$link = remove_query_arg( 'page_id', $link );
			}
		}

		// Min Rating Arg.
		if ( isset( $_GET['rating_filter'] ) ) {
			$link = add_query_arg( 'rating_filter', wc_clean( wp_unslash( $_GET['rating_filter'] ) ), $link );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		// All current filters.
		if ( $_chosen_attributes = WC_Query::get_layered_nav_chosen_attributes() ) {
			foreach ( $_chosen_attributes as $name => $data ) {
				$filter_name = wc_attribute_taxonomy_slug( $name );
				if ( ! empty( $data['terms'] ) ) {
					$link = add_query_arg( 'filter_' . $filter_name, implode( ',', $data['terms'] ), $link );
				}
				if ( 'or' === $data['query_type'] ) {
					$link = add_query_arg( 'query_type_' . $filter_name, 'or', $link );
				}
			}
		}

		/**
		 * Filters the current page url with filtering properties.
		 *
		 * @param string $link The calculated url.
		 * @param \WC_Widget $widget The widget object.
		 */
		return apply_filters( 'wcwp_widget_get_current_page_url', $link, $this );
	}

	/**
	 * Determins whether the widget should display
	 *
	 * @return bool
	 */
	protected function is_visible() {
		if ( self::has_product_table_on_page() || Util::is_wholesale_store_page() || is_shop() || is_product_taxonomy() ) {
			return true;
		}

		return false;
	}

	/**
	 * Determines whether a product table is on the page
	 *
	 * @return bool
	 */
	protected static function has_product_table_on_page() {
		if ( ! Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Product_Table\wpt' ) || ! class_exists( '\Barn2\Plugin\WC_Product_Table\Util\Util' ) ) {
			return false;
		}

		if ( ! WPT_Util::is_table_on_page() || ! is_singular() ) {
			return false;
		}

		return true;
	}

	/**
	 * Generates SQL clause for search string
	 *
	 * @return string
	 */
	protected static function get_main_search_query_sql() {
		global $wpdb, $wp_the_query;

		$args         = $wp_the_query->query_vars;
		$search_terms = isset( $args['search_terms'] ) ? $args['search_terms'] : [];
		$sql          = [];

		foreach ( $search_terms as $term ) {
			// Terms prefixed with '-' should be excluded.
			$include = '-' !== substr( $term, 0, 1 );

			if ( $include ) {
				$like_op  = 'LIKE';
				$andor_op = 'OR';
			} else {
				$like_op  = 'NOT LIKE';
				$andor_op = 'AND';
				$term     = substr( $term, 1 );
			}

			$like = '%' . $wpdb->esc_like( $term ) . '%';
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$sql[] = $wpdb->prepare( "(($wpdb->posts.post_title $like_op %s) $andor_op ($wpdb->posts.post_excerpt $like_op %s) $andor_op ($wpdb->posts.post_content $like_op %s))", $like, $like, $like );
		}

		if ( ! empty( $sql ) && ! is_user_logged_in() ) {
			$sql[] = "($wpdb->posts.post_password = '')";
		}

		return implode( ' AND ', $sql );
	}

	/**
	 * Get the main taxonomy query
	 *
	 * @return mixed
	 */
	protected static function get_main_tax_query() {
		global $wp_the_query;
		return isset( $wp_the_query->tax_query, $wp_the_query->tax_query->queries ) ? $wp_the_query->tax_query->queries : [];
	}

	/**
	 * Get the main meta query
	 *
	 * @return mixed
	 */
	protected static function get_main_meta_query() {
		global $wp_the_query;
		return isset( $wp_the_query->query_vars['meta_query'] ) ? $wp_the_query->query_vars['meta_query'] : [];
	}
}
