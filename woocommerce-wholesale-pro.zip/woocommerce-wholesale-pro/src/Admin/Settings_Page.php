<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Plugin;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Service_Container;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\WooCommerce\Admin\Custom_Settings_Fields;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\WooCommerce\Admin\Plugin_Promo;
use WC_Settings_Page;
use WC_Admin_Settings;

/**
 * This class handles the plugin settings page for WooCommerce Wholesale Pro.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Media <info@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Settings_Page extends WC_Settings_Page implements Registerable, Standard_Service {
	use Service_Container;

	private $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin
	 */
	public function __construct( Plugin $plugin ) {
		$this->id     = 'wholesale-pro';
		$this->plugin = $plugin;
	}

	private function show_legacy_fields_tab(): bool {
		return (bool) get_option( 'wcwp_registration_fields' )
			&& ! get_option( 'wcwp_trade_hide_legacy_tab' );
	}

	/**
	 * {@inheritdoc}
	 */
	public function add_services() {
		$this->add_service( 'plugin_promo', new Plugin_Promo( $this->plugin, $this->get_id() ) );
		$this->add_service( 'general_tab', new Settings_Tab\General( $this->id, $this->plugin ) );
		$this->add_service( 'emails_tab', new Settings_Tab\Emails( $this->id ) );
		$this->add_service( 'roles_tab', new Settings_Tab\Roles( $this->id ) );
		$this->add_service( 'layout_tab', new Settings_Tab\Layout( $this->id ) );
		if ( $this->show_legacy_fields_tab() ) {
			$this->add_service( 'fields_tab', new Settings_Tab\Registration_Fields( $this->id ) );
		}
		$this->add_service( 'payment-roles_tab', new Settings_Tab\Payment_Roles( $this->id ) );
		$this->add_service( 'shipping-roles_tab', new Settings_Tab\Shipping_Roles( $this->id ) );
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		$this->label = __( 'Wholesale', 'woocommerce-wholesale-pro' );

		$this->register_services();
		$this->start_all_services();

		$custom_setting_fields = new Custom_Settings_Fields( $this->plugin );
		$custom_setting_fields->register();

		add_filter( 'woocommerce_settings_tabs_array', [ $this, 'register_settings_tab' ], 99 );
		add_action( 'woocommerce_sections_' . $this->id, [ $this, 'output_sections' ] );

		add_action( 'woocommerce_settings_' . $this->id, [ $this, 'output' ] );
		add_action( 'woocommerce_settings_save_' . $this->id, [ $this, 'save' ] );
	}

	/**
	 * Register the settings tab.
	 *
	 * @param mixed $settings_tabs
	 * @return mixed
	 */
	public function register_settings_tab( $settings_tabs ) {
		$settings_tabs[ $this->id ] = $this->label;

		return $settings_tabs;
	}

	/**
	 * Return the settings for the requested tab
	 *
	 * @param   string  $current_section
	 * @return  array   $settings
	 */
	public function get_settings( $current_section = '' ) {
		$current_section = $current_section ?: 'general';

		if ( $current_section === 'registration-form' ) {
			// Rendered via woocommerce_settings_wholesale-pro action by the Form Builder plugin.
			return [];
		}

		$known_sections = [ 'general', 'roles', 'layout', 'emails', 'payment-roles', 'shipping-roles' ];
		if ( $this->show_legacy_fields_tab() ) {
			$known_sections[] = 'fields';
		}

		if ( in_array( $current_section, $known_sections, true ) ) {
			$settings = $this->get_service( $current_section . '_tab' )->get_settings();
		} else {
			wp_die( esc_html__( 'Settings tab does not exist!', 'woocommerce-wholesale-pro' ) );
		}

		return apply_filters( 'woocommerce_get_settings_' . $this->id, $settings, $current_section );
	}

	/**
	 * Get sections.
	 *
	 * @return array
	 */
	public function get_sections() {
		$sections = [
			''               => __( 'General', 'woocommerce-wholesale-pro' ),
			'roles'          => __( 'Roles', 'woocommerce-wholesale-pro' ),
			'layout'         => __( 'Layout', 'woocommerce-wholesale-pro' ),
			'emails'         => __( 'Emails', 'woocommerce-wholesale-pro' ),
			'payment-roles'  => __( 'Payment roles', 'woocommerce-wholesale-pro' ),
			'shipping-roles' => __( 'Shipping roles', 'woocommerce-wholesale-pro' ),
		];

		if ( $this->show_legacy_fields_tab() ) {
			$sections['fields'] = __( 'Legacy custom registration fields', 'woocommerce-wholesale-pro' );
		}

		return apply_filters( 'woocommerce_get_sections_' . $this->id, $sections );
	}

	/**
	 * Output the settings
	 */
	public function output() {
		global $current_section;

		if ( $current_section === 'registration-form' ) {
			return;
		}

		$settings = $this->get_settings( $current_section );
		WC_Admin_Settings::output_fields( $settings );
	}

	/**
	 * Save settings
	 */
	public function save() {
		global $current_section;

		$settings = $this->get_settings( $current_section );

		$wholesale_login_page_id = filter_input( INPUT_POST, 'wcwp_wholesale_login_page_id', FILTER_SANITIZE_NUMBER_INT );
		$wholesale_store_page_id = filter_input( INPUT_POST, 'wcwp_wholesale_store_page_id', FILTER_SANITIZE_NUMBER_INT );

		// Prevent the Wholesale Login and Store pages from being the same.
		if ( $current_section === '' && $wholesale_login_page_id && $wholesale_store_page_id && $wholesale_store_page_id === $wholesale_login_page_id ) {
			$_POST['wcwp_wholesale_login_page_id'] = '';
			WC_Admin_Settings::add_error( __( 'You have chosen the same page for the Wholesale Login and Wholesale Store page options. Please select different pages.', 'woocommerce-wholesale-pro' ) );
		}

		if ( $current_section === 'fields' ) {
			/**
			 * Triggered when the registration fields are saved.
			 */
			do_action( 'wcwp_update_registration_fields' );
		}

		if ( $current_section === 'payment-roles' ) {
			/**
			 * Triggered when the payment roles are saved.
			 */
			do_action( 'wcwp_update_payment_roles' );
		}

		if ( $current_section === 'shipping-roles' ) {
			/**
			 * Triggered when the shipping roles are saved.
			 */
			do_action( 'wcwp_update_shipping_roles' );
		}

		WC_Admin_Settings::save_fields( $settings );
	}
}
