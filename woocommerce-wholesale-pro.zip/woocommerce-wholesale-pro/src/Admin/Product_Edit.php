<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Role;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Exception;

/**
 * Handles fields and data on the Product Add/Edit screen
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Product_Edit implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		// Simple products
		add_action( 'woocommerce_product_options_pricing', [ $this, 'simple_pricing' ], 1, 0 );
		add_action( 'woocommerce_process_product_meta', [ $this, 'save_simple_pricing' ], 10, 1 );

		// Variable products
		add_action( 'woocommerce_variation_options_pricing', [ $this, 'variable_pricing' ], 10, 3 );
		add_action( 'woocommerce_save_product_variation', [ $this, 'variable_pricing_save' ], 10, 2 );

		// Product level wholesale visibility
		add_action( 'post_submitbox_misc_actions', [ $this, 'wholesale_visibility' ], 20, 1 );
		add_action( 'woocommerce_process_product_meta', [ $this,'save_wholesale_visibility' ], 10, 1 );
	}

	/**
	 * Output the simple pricing fields
	 */
	public function simple_pricing() {
		global $product_object;

		$wholesale_roles = Util::get_wholesale_roles( 'editable' );

		foreach ( $wholesale_roles as $role_name ) {
			try {
				$role = new Wholesale_Role( $role_name );

				if ( $role->get_product_pricing() !== 'yes' ) {
					continue;
				}

				woocommerce_wp_text_input(
					[
						'id'            => $role->get_name(),
						'value'         => $product_object->get_meta( $role->get_name() ),
						'label'         => $role->get_display_name() . ' (' . get_woocommerce_currency_symbol() . ')',
						'data_type'     => 'price',
						'wrapper_class' => 'wcwp_wholesale_field',
					]
				);

				if ( $role->get_product_sale_pricing() === 'yes' ) {
					woocommerce_wp_text_input(
						[
							'id'            => "{$role->get_name()}_sale",
							'value'         => $product_object->get_meta( $role->get_name() . '_sale' ),
							'label'         => $role->get_display_name() . ' ' . __( 'sale price', 'woocommerce-wholesale-pro' ) . ' (' . get_woocommerce_currency_symbol() . ')',
							'data_type'     => 'price',
							'wrapper_class' => 'wcwp_wholesale_sale_field',
						]
					);
				}
			} catch ( Exception $e ) {
				continue;
			}
		}
	}

	/**
	 * Save our simple pricing fields
	 *
	 * @param int $post_id
	 */
	public function save_simple_pricing( $post_id ) {
		$wholesale_roles   = Util::get_wholesale_roles( 'editable' );
		$decimal_separator = wc_get_price_decimal_separator();
		$product           = wc_get_product( $post_id );

		foreach ( $wholesale_roles as $role_name ) {
			foreach ( [ '', '_sale' ] as $price_type ) {
				$meta_name       = "{$role_name}{$price_type}";
				$role_pricing    = filter_input( INPUT_POST, $meta_name, FILTER_SANITIZE_FULL_SPECIAL_CHARS );
				$value           = sanitize_text_field( $role_pricing );
				$formatted_value = str_replace( $decimal_separator, '.', $value );
				$previous_value  = $product->get_meta( $meta_name, true, 'edit' );

				if ( $previous_value === $formatted_value ) {
					continue;
				}

				if ( '' === $formatted_value ) {
					$product->delete_meta_data( $meta_name );
				} else {
					$product->update_meta_data( $meta_name, $formatted_value );
				}

				/**
				 * Triggered after the simple pricing has changed.
				 *
				 * @param string $role_name The name of the role where pricing changed.
				 * @param int $post_id The post_id of the product affected.
				 * @param string $meta_name The meta_key being affected (the role name with or without the suffix `_sale` appended).
				 */
				do_action( 'wcwp_simple_pricing_changed', $role_name, $post_id, $meta_name );
			}
		}

		$product->save();
	}

	/**
	 * Variation options pricing
	 *
	 * @param int      $index          Position in the loop.
	 * @param array    $variation_data Variation data.
	 * @param \WP_Post $variation     Post data.
	 */
	public function variable_pricing( $index, $variation_data, $variation ) {
		$wholesale_roles         = Util::get_wholesale_roles( 'editable' );
		$roles_have_sale_pricing = Util::some_roles_have_sale_pricing();
		$iteration               = 0;

		foreach ( $wholesale_roles as $role_name ) {

			try {
				$role = new Wholesale_Role( $role_name );

				if ( $role->get_product_pricing() !== 'yes' ) {
					continue;
				}

				++$iteration;
				$id            = "{$role->get_name()}[{$index}]";
				$row_class     = $roles_have_sale_pricing || $iteration % 2 > 0 ? 'form-row-first' : 'form-row-last';
				$value         = isset( $variation_data[ $role->get_name() ][0] ) ? $variation_data[ $role->get_name() ][0] : '';
				$regular_label = ( $roles_have_sale_pricing ? $role->get_display_name() . ' ' . __( 'regular price', 'woocommerce-wholesale-pro' ) : $role->get_display_name() ) . ' (' . get_woocommerce_currency_symbol() . ')';

				woocommerce_wp_text_input(
					[
						'id'            => $id,
						'name'          => $id,
						'label'         => $regular_label,
						'value'         => $value,
						'data_type'     => 'price',
						'wrapper_class' => sprintf( 'form-row %s wcwp_wholesale_field', $row_class ),
					]
				);

				if ( $role->get_product_sale_pricing() === 'yes' ) {
					$id    = "{$role->get_name()}_sale[{$index}]";
					$value = isset( $variation_data[ $role->get_name() . '_sale' ][0] ) ? $variation_data[ $role->get_name() . '_sale' ][0] : '';

					woocommerce_wp_text_input(
						[
							'id'            => $id,
							'name'          => $id,
							'label'         => $role->get_display_name() . ' ' . __( 'sale price', 'woocommerce-wholesale-pro' ) . ' (' . get_woocommerce_currency_symbol() . ')',
							'value'         => $value,
							'data_type'     => 'price',
							'wrapper_class' => 'form-row wcwp_wholesale_sale_field form-row-last',
						]
					);
				}
			} catch ( Exception $e ) {
				continue;
			}
		}
	}

	/**
	 * Save the variable pricing fields
	 *
	 * @param int $variation_id
	 * @param mixed $index
	 */
	public function variable_pricing_save( $variation_id, $index ) {
		$wholesale_roles   = Util::get_wholesale_roles( 'editable' );
		$decimal_separator = wc_get_price_decimal_separator();
		$product           = wc_get_product( $variation_id );

		foreach ( $wholesale_roles as $role_name ) {
			foreach ( [ '', '_sale' ] as $price_type ) {
				$meta_name       = "{$role_name}{$price_type}";
				$role_pricing    = $_POST[ $meta_name ][ $index ] ?? ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
				$value           = sanitize_text_field( $role_pricing );
				$formatted_value = str_replace( $decimal_separator, '.', $value );
				$previous_value  = $product->get_meta( $meta_name, true, 'edit' );

				if ( $previous_value === $formatted_value ) {
					continue;
				}

				if ( '' === $formatted_value ) {
					$product->delete_meta_data( $meta_name );
				} else {
					$product->update_meta_data( $meta_name, $formatted_value );
				}

				/**
				 * Triggered after the variation pricing is updated.
				 *
				 * @param string $role_name The name of the role where pricing changed.
				 * @param int $variation_id The post_id of the variation affected.
				 * @param string $meta_name The meta_key being affected (the role name with or without the suffix `_sale` appended).
				 */
				do_action( 'wcwp_variation_pricing_changed', $role_name, $variation_id, $meta_name );
			}
		}

		$product->save();
	}

	/**
	 * Wholesale visibility post submit box HTML
	 */
	public function wholesale_visibility() {
		global $post;

		if ( $post->post_type !== 'product' ) {
			return;
		}

		$product_object     = $post->ID ? wc_get_product( $post->ID ) : new WC_Product();
		$current_visibility = $product_object->get_meta( '_wwp_wholesale_visibility' );

		$visibility_options = [
			''               => __( 'Inherit from category', 'woocommerce-wholesale-pro' ),
			'public'         => __( 'Public and wholesale', 'woocommerce-wholesale-pro' ),
			'wholesale_only' => __( 'Wholesale only', 'woocommerce-wholesale-pro' ),
			'public_only'    => __( 'Public only', 'woocommerce-wholesale-pro' ),
		];

		?>
		<div class="misc-pub-section" id="wholesale-visibility">
			<?php esc_html_e( 'Wholesale visibility:', 'woocommerce-wholesale-pro' ); ?>

			<strong id="wholesale-visibility-display">
				<?php echo isset( $visibility_options[ $current_visibility ] ) ? esc_html( $visibility_options[ $current_visibility ] ) : esc_html( $current_visibility ); ?>
			</strong>

			<a href="#wholesale-visibility" class="edit-wholesale-visibility hide-if-no-js"><?php esc_html_e( 'Edit', 'woocommerce-wholesale-pro' ); ?></a>

			<?php echo wc_help_tip( __( 'This will override the category level visibility.', 'woocommerce-wholesale-pro' ) ); ?>

			<div id="wholesale-visibility-container" class="hide-if-js">
				<input type="hidden" name="current_wholesale_visibility" id="current-wholesale-visibility" value="<?php echo esc_attr( $current_visibility ); ?>" />

				<select name="_wwp_wholesale_visibility" id="wholesale-visibility-select">
					<?php foreach ( $visibility_options as $name => $label ) : ?>
						<option value="<?php echo esc_attr( $name ); ?>" <?php selected( $current_visibility, $name ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>

				<p>
					<a href="#wholesale-visibility" class="save-wholesale-visibility hide-if-no-js button"><?php esc_html_e( 'OK', 'woocommerce-wholesale-pro' ); ?></a>
					<a href="#wholesale-visibility" class="cancel-wholesale-visibility hide-if-no-js"><?php esc_html_e( 'Cancel', 'woocommerce-wholesale-pro' ); ?></a>
				</p>
			</div>
		</div>
		<?php
	}

	/**
	 * Save wholesale visibility
	 *
	 * @param int $post_id
	 */
	public function save_wholesale_visibility( $post_id ) {
		$product = wc_get_product( $post_id );

		$wholesale_visibility = filter_input( INPUT_POST, '_wwp_wholesale_visibility', FILTER_SANITIZE_SPECIAL_CHARS );

		if ( in_array( $wholesale_visibility, [ false, null ], true ) ) {
			return;
		}

		$product->update_meta_data( '_wwp_wholesale_visibility', $wholesale_visibility );
		$product->save();
	}
}
