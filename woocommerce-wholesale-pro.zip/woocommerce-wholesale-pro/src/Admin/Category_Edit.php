<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Role;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Util as Lib_Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Exception;

/**
 * Handles fields and data on the Product Category Add/Edit screen
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Category_Edit implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'product_cat_add_form_fields', [ $this, 'add_role_pricing_field' ], 11 );
		add_action( 'product_cat_edit_form_fields', [ $this, 'edit_role_pricing_field' ], 11 );

		add_action( 'product_cat_add_form_fields', [ $this, 'add_hide_prices_select_field' ], 12 );
		add_action( 'product_cat_edit_form_fields', [ $this, 'edit_hide_prices_select_field' ], 12 );

		add_action( 'product_cat_add_form_fields', [ $this, 'add_wholesale_visibility_field' ], 21 );
		add_action( 'product_cat_edit_form_fields', [ $this, 'edit_wholesale_visiblity_field' ], 21 );

		add_action( 'product_cat_add_form_fields', [ $this, 'add_visiblity_control_field' ], 19 );
		add_action( 'product_cat_edit_form_fields', [ $this, 'edit_visiblity_control_field' ], 19 );

		add_action( 'created_product_cat', [ $this, 'save_visibility_field' ], 10, 2 );
		add_action( 'edit_product_cat', [ $this, 'save_visibility_field' ], 10, 2 );

		add_action( 'created_product_cat', [ $this, 'save_hide_prices_field' ], 10, 2 );
		add_action( 'edit_product_cat', [ $this, 'save_hide_prices_field' ], 10, 2 );

		add_action( 'created_product_cat', [ $this, 'save_role_discounts' ], 10, 2 );
		add_action( 'edit_product_cat', [ $this, 'save_role_discounts' ], 10, 2 );

		add_action( 'created_product_cat', [ $this, 'save_visibility_control_field' ], 10, 2 );
		add_action( 'edit_product_cat', [ $this, 'save_visibility_control_field' ], 10, 2 );

		add_filter( 'manage_edit-product_cat_columns', [ $this, 'cat_table_visibility_column_heading' ] );
		add_filter( 'manage_product_cat_custom_column', [ $this, 'cat_table_visibility_column' ], 10, 3 );
	}

	/**
	 * Add role pricing field to 'add product category' screen
	 */
	public function add_role_pricing_field() {
		?>
		<div class="form-field wholesale-discount-wrap">
			<label for="wcwp_wholesale">
				<?php esc_html_e( 'Wholesale % discount', 'woocommerce-wholesale-pro' ); ?>
				<?php echo wc_help_tip( __( 'Enter a percentage discount which will be deducted from the standard price of all products in this category. You can override this for individual products.', 'woocommerce-wholesale-pro' ) ); ?>
			</label>
			<?php $this->display_role_discount_group(); ?>
		</div>
		<?php
	}

	/**
	 * Add role pricing field to 'edit product category' screen
	 *
	 * @param mixed $term The product category being edited
	 */
	public function edit_role_pricing_field( $term ) {
		?>
		<tr class="form-field wholesale-discount-wrap">
			<th scope="row" valign="top">
				<label for="wcwp_wholesale">
					<?php esc_html_e( 'Wholesale % discount', 'woocommerce-wholesale-pro' ); ?>
					<?php echo wc_help_tip( __( 'Enter a percentage discount which will be deducted from the standard price of all products in this category. You can override this for individual products.', 'woocommerce-wholesale-pro' ) ); ?>
				</label>
			</th>
			<td>
				<?php $this->display_role_discount_group( $term->term_id ); ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Add visibility field to 'add product category' screen
	 */
	public function add_wholesale_visibility_field() {
		$visiblity_label = __( 'Visibility', 'woocommerce-wholesale-pro' );

		if ( Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Protected_Categories\wpc' ) ) {
			$visiblity_label = __( 'Wholesale Visibility', 'woocommerce-wholesale-pro' );
		}

		?>
		<div class="form-field wcwp-term-visibility-wrap">
			<label for="wcwp_cat_visibility"><?php echo esc_html( $visiblity_label ); ?></label>
			<?php $this->display_visibility_group(); ?>
		</div>
		<?php
	}

	/**
	 * Add visibility field to 'edit product category' screen
	 *
	 * @param mixed $term The product category being edited
	 */
	public function edit_wholesale_visiblity_field( $term ) {
		$visiblity_label = __( 'Visibility', 'woocommerce-wholesale-pro' );

		if ( Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Protected_Categories\wpc' ) ) {
			$visiblity_label = __( 'Wholesale Visibility', 'woocommerce-wholesale-pro' );
		}

		?>
		<tr class="form-field wcwp-term-visibility-wrap">
			<th scope="row" valign="top">
				<label for="wcwp_cat_visibility"><?php echo esc_html( $visiblity_label ); ?></label>
			</th>
			<td>
				<?php $this->display_visibility_group( $term->term_id ); ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Add visibility control field (WooCommerce Protected Categories) to 'Add product category' screen.
	 */
	public function add_visiblity_control_field() {
		if ( ! Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Protected_Categories\wpc' ) ) {
			return;
		}

		?>
		<div class="form-field term-visibility-control-wrap">
			<label for="wcwp_visiblity_control">
				<?php esc_html_e( 'Visibility control', 'woocommerce-wholesale-pro' ); ?>
				<?php echo wc_help_tip( __( 'Choose whether to control the category visibility by using the general options in WooCommerce Wholesale Pro, or the more fine-grained options in WooCommerce Protected Categories.', 'woocommerce-wholesale-pro' ) ); ?>
			</label>
			<?php $this->display_visibility_control(); ?>
		</div>
		<?php
	}

	/**
	 * Add visibility control field (WooCommerce Protected Categories) to 'Edit product category' screen.
	 *
	 * @param WP_Term $term
	 */
	public function edit_visiblity_control_field( $term ) {
		if ( ! Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Protected_Categories\wpc' ) ) {
			return;
		}

		?>
		<tr class="form-field term-visibility-control-wrap">
			<th scope="row" valign="top">
				<label for="wcwp_visiblity_control"><?php esc_html_e( 'Visibility control', 'woocommerce-wholesale-pro' ); ?></label>
				<?php echo wc_help_tip( __( 'Choose whether to control the category visibility by using the general options in WooCommerce Wholesale Pro, or the more fine-grained options in WooCommerce Protected Categories.', 'woocommerce-wholesale-pro' ) ); ?>
			</th>
			<td>
				<?php $this->display_visibility_control( $term->term_id ); ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Add hide price control field (WooCommerce Protected Categories) to 'Add product category' screen.
	 */
	public function add_hide_prices_select_field() {
		?>
		<div class="form-field term-visibility-control-wrap">
			<label for="wcwp_visiblity_control">
				<?php esc_html_e( 'Hide price until login', 'woocommerce-wholesale-pro' ); ?>
				<?php echo wc_help_tip( __( 'Choose whether to hide prices and disable purchasing for logged out users.', 'woocommerce-wholesale-pro' ) ); ?>
			</label>
			<?php $this->display_hide_prices_select(); ?>
		</div>
		<?php
	}

	/**
	 * Add hide price control field (WooCommerce Protected Categories) to 'Edit product category' screen.
	 *
	 * @param WP_Term $term
	 */
	public function edit_hide_prices_select_field( $term ) {
		?>
		<tr class="form-field term-visibility-control-wrap">
			<th scope="row" valign="top">
				<label for="wcwp_visiblity_control"><?php esc_html_e( 'Hide price until login', 'woocommerce-wholesale-pro' ); ?></label>
				<?php echo wc_help_tip( __( 'Choose whether to hide prices and disable purchasing for logged out users.', 'woocommerce-wholesale-pro' ) ); ?>
			</th>
			<td>
				<?php $this->display_hide_prices_select( $term->term_id ); ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Save visibility field
	 *
	 * @param mixed $term_id Term ID being saved
	 * @param mixed $tt_id The term taxonomy ID
	 */
	public function save_visibility_field( $term_id, $tt_id = '' ) {
		$visibility = filter_input( INPUT_POST, 'wcwp_cat_visibility', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		// Bail if no visibility to save (e.g. on 'quick edit')
		if ( ! $visibility ) {
			return;
		}

		update_term_meta( $term_id, 'wcwp_visibility', $visibility );
	}

	/**
	 * Save visibility control (WooCommerce Protected Categories) integration
	 *
	 * @param mixed $term_id Term ID being saved
	 * @param mixed $tt_id The term taxonomy ID
	 */
	public function save_visibility_control_field( $term_id, $tt_id = '' ) {
		$visibility_control = filter_input( INPUT_POST, 'wcwp_cat_visibility_control', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		// Bail if no visibility to save (e.g. on 'quick edit')
		if ( ! $visibility_control ) {
			return;
		}

		update_term_meta( $term_id, 'wcwp_visiblity_control', $visibility_control );
	}

	/**
	 * Save wholesale discounts
	 *
	 * @param mixed $term_id Term ID being saved
	 * @param mixed $tt_id The term taxonomy ID
	 */
	public function save_role_discounts( $term_id, $tt_id = '' ) {
		$role_discounts = filter_input( INPUT_POST, 'wcwp_wholesale', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_REQUIRE_ARRAY + FILTER_FLAG_ALLOW_FRACTION );

		// Bail if no role discounts to save (e.g. on 'quick edit')
		if ( ! $role_discounts ) {
			return;
		}

		foreach ( $role_discounts as $role_name => $discount ) {
			if ( $discount !== get_term_meta( $term_id, $role_name, true ) ) {
				/**
				 * Triggered after the category discount is changed.
				 *
				 * @param string $role_name The role where discounts where changed.
				 */
				do_action( 'wcwp_category_discount_changed', $role_name );
			}

			if ( ! $discount ) {
				delete_term_meta( $term_id, $role_name );
			}

			update_term_meta( $term_id, $role_name, $discount );
		}
	}

	/**
	 * Save visibility field
	 *
	 * @param mixed $term_id Term ID being saved
	 * @param mixed $tt_id The term taxonomy ID
	 */
	public function save_hide_prices_field( $term_id, $tt_id = '' ) {
		$hide_prices = filter_input( INPUT_POST, 'wcwp_cat_hide_prices', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		// Bail if no visibility to save (e.g. on 'quick edit')
		if ( is_null( $hide_prices ) ) {
			return;
		}

		update_term_meta( $term_id, 'wcwp_hide_prices', $hide_prices );
	}

	/**
	 * Display Role Discount Inputs
	 *
	 * @param mixed $term_id
	 */
	private function display_role_discount_group( $term_id = false ) {
		$wholesale_roles = Util::get_wholesale_roles( 'editable' );

		foreach ( $wholesale_roles as $role_name ) {

			try {
				$role       = new Wholesale_Role( $role_name );
				$input_name = "wcwp_wholesale[{$role->get_name()}]";
				$value      = get_term_meta( $term_id, $role->get_name(), true ) ? get_term_meta( $term_id, $role->get_name(), true ) : '';

				?>
				<label>
					<span class="wcwp-role-name"><?php echo esc_html( $role->get_display_name() ); ?></span>
					<input
						id="<?php echo esc_attr( $role->get_name() ); ?>"
						name="<?php echo esc_attr( $input_name ); ?>"
						value="<?php echo esc_attr( $value ); ?>"
						type="number"
						max="100"
						min="0"
						step="0.01"
					/>
					<span class="wcwp-percentage"><?php echo '%'; ?></span>
				</label>
				<?php
			} catch ( Exception $e ) {
				continue;
			}
		}
	}

	/**
	 * Display Visiblity Radio Buttons
	 *
	 * @param mixed $term_id
	 */
	private function display_visibility_group( $term_id = false ) {
		$category   = $term_id ? Util::get_category_visibility( $term_id ) : null;
		$visibility = $category ? $category->get_visibility() : 'public';

		?>
		<fieldset id="wcwp_product_cat_visibility" class="wcwp-cat-visibility">
			<legend class="screen-reader-text"><?php esc_html_e( 'Visibility', 'woocommerce-wholesale-pro' ); ?></legend>

			<label class="wcwp-cat-visibility__option">
				<input type="radio" name="wcwp_cat_visibility" id="wcwp_public_wholesale_visibility" value="public" <?php checked( $visibility, 'public' ); ?> />
				<?php esc_html_e( 'Public and wholesale', 'woocommerce-wholesale-pro' ); ?>
			</label>

			<label class="wcwp-cat-visibility__option">
				<input type="radio" name="wcwp_cat_visibility" id="wcwp_wholesale_visibility" value="wholesale_only" <?php checked( $visibility, 'wholesale_only' ); ?> />
				<?php esc_html_e( 'Wholesale only', 'woocommerce-wholesale-pro' ); ?>
				<?php echo wc_help_tip( __( 'Show the category only to logged-in customers with a wholesale role. Its products and sub-categories will inherit the same protection.', 'woocommerce-wholesale-pro' ) ); ?>
			</label>

			<label class="wcwp-cat-visibility__option">
				<input type="radio" name="wcwp_cat_visibility" id="wcwp_public_visibility" value="public_only" <?php checked( $visibility, 'public_only' ); ?> />
				<?php esc_html_e( 'Public only', 'woocommerce-wholesale-pro' ); ?>
				<?php echo wc_help_tip( __( 'Hide the category from logged-in customers with a wholesale role. Its products and sub-categories will inherit the same protection.', 'woocommerce-wholesale-pro' ) ); ?>
			</label>
		</fieldset>
		<?php
	}

	/**
	 * Display Radio Buttons for WooCommerce Protected Categories Integration
	 *
	 * @param mixed $term_id
	 */
	private function display_visibility_control( $term_id = false ) {
		$visibility_control = $term_id && ! empty( get_term_meta( $term_id, 'wcwp_visiblity_control', true ) ) ? get_term_meta( $term_id, 'wcwp_visiblity_control', true ) : 'protected_categories';

		?>
		<fieldset id="wcwp_product_cat_visibility_control" class="wcwp-cat-visibility-control">
			<legend class="screen-reader-text"><?php esc_html_e( 'Visibility Control', 'woocommerce-wholesale-pro' ); ?></legend>

			<label class="wcwp-cat-visibility-control__option">
				<input type="radio" name="wcwp_cat_visibility_control" id="wcwp_visibility_control_protected" value="protected_categories" <?php checked( $visibility_control, 'protected_categories' ); ?> />
				<?php esc_html_e( 'Use WooCommerce Protected Categories', 'woocommerce-wholesale-pro' ); ?>
			</label>

			<label class="wcwp-cat-visibility-control__option">
				<input type="radio" name="wcwp_cat_visibility_control" id="wcwp_visibility_control_wholesale" value="wholesale_pro" <?php checked( $visibility_control, 'wholesale_pro' ); ?> />
				<?php esc_html_e( 'Use WooCommerce Wholesale Pro', 'woocommerce-wholesale-pro' ); ?>
			</label>
		</fieldset>
		<?php
	}

	/**
	 * Display Visiblity Radio Buttons
	 *
	 * @param mixed $term_id
	 */
	private function display_hide_prices_select( $term_id = false ) {
		$category    = $term_id ? Util::get_category_visibility( $term_id ) : null;
		$hide_prices = $category ? $category->get_hide_prices() : '';

		?>
		<fieldset id="wcwp_hide_prices">
			<legend class="screen-reader-text"><?php esc_html_e( 'Hide prices until login', 'woocommerce-wholesale-pro' ); ?></legend>

			<select name="wcwp_cat_hide_prices">
				<option value="" <?php selected( $hide_prices, '' ); ?>><?php esc_html_e( 'Use global or parent category setting', 'woocommerce-wholesale-pro' ); ?></option>
				<option value="hide" <?php selected( $hide_prices, 'hide' ); ?>><?php esc_html_e( 'Hide prices from logged out users', 'woocommerce-wholesale-pro' ); ?></option>
				<option value="show" <?php selected( $hide_prices, 'show' ); ?>><?php esc_html_e( 'Show prices to logged out users', 'woocommerce-wholesale-pro' ); ?></option>
			</select>
		</fieldset>
		<?php
	}

	/**
	 * Adds the visiblity column heading if Protected Categories is not active
	 *
	 * @param   array $columns
	 * @return  array $columns
	 */
	public function cat_table_visibility_column_heading( $columns ) {
		if ( Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Protected_Categories\wpc' ) ) {
			return $columns;
		}

		return $this->list_table_insert_after_column( $columns, 'name', 'visibility', __( 'Visibility', 'woocommerce-wholesale-pro' ) );
	}

	/**
	 * Adds the value to our visiblity column if Protected Categories isn't used.
	 *
	 * @param   string  $output
	 * @param   string  $column
	 * @param   int     $term_id
	 * @return  string  $output
	 */
	public function cat_table_visibility_column( $output, $column, $term_id ) {
		if ( Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Protected_Categories\wpc' ) && get_term_meta( $term_id, 'wcwp_visiblity_control', true ) === 'protected_categories' ) {
			return $output;
		}

		if ( 'visibility' === $column ) {
			$category = Util::get_category_visibility( $term_id );

			if ( 'public' === $category->get_visibility() ) {
				foreach ( $category->ancestors() as $ancestor ) {
					if ( 'public' !== $ancestor->get_visibility() ) {
						$output = sprintf( '<em>(%s)</em>', __( 'inherited', 'woocommerce-wholesale-pro' ) );
						break;
					}
				}
				if ( ! $output ) {
					$output = __( 'Public and wholesale', 'woocommerce-wholesale-pro' );
				}
			} elseif ( 'wholesale_only' === $category->get_visibility() ) {
				$output = __( 'Wholesale only', 'woocommerce-wholesale-pro' );
			} elseif ( 'public_only' === $category->get_visibility() ) {
				$output = __( 'Public only', 'woocommerce-wholesale-pro' );
			}
		}

		return $output;
	}

	/**
	 * Inserts a value into the columns array at a specified position
	 *
	 * @param   array   $columns
	 * @param   string  $after_key
	 * @param   string  $insert_key
	 * @param   string  $insert_value
	 * @return  array   $new_columns
	 */
	private function list_table_insert_after_column( $columns, $after_key, $insert_key, $insert_value ) {
		$new_columns = [];

		foreach ( $columns as $key => $column ) {
			if ( $after_key === $key ) {
				$new_columns[ $key ]        = $column;
				$new_columns[ $insert_key ] = $insert_value;
			} else {
				$new_columns[ $key ] = $column;
			}
		}

		return $new_columns;
	}
}
