<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Role;
use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Price;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use WC_Product;
use Exception;

/**
 * Handles fields and data on the Order Add/Edit screen
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Order_Edit implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'woocommerce_ajax_order_item', [ $this, 'ajax_order_item' ], 10, 4 );
		add_action( 'woocommerce_before_save_order_item', [ $this, 'save_order_item' ] );
	}

	/**
	 * Filter the item being added to an order
	 *
	 * @param WC_Order_Item $item
	 * @param int           $item_id
	 * @param WC_Order      $order
	 * @param WC_Product    $product
	 * @return WC_Order_Item
	 */
	public function ajax_order_item( $item, $item_id, $order, $product ) {
		check_ajax_referer( 'order-item', 'security' );

		return $this->recalculate_order_item( $item, $order );
	}

	/**
	 * 
	 */
	public function save_order_item( $item ) {
		if ( check_ajax_referer( 'order-item', 'security', false ) || check_ajax_referer( 'calc-totals', 'security', false ) ) {
			$item = $this->recalculate_order_item( $item, null );
		}
	}

	public function recalculate_order_item( $item, $order = null ) {
		if ( ! is_a( $item, 'WC_Order_Item_Product' ) ) {
			return $item;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$customer_id      = filter_input( INPUT_POST, 'customer', FILTER_SANITIZE_NUMBER_INT );
		$customer_changed = filter_var( filter_input( INPUT_POST, 'customer_has_changed' ), FILTER_VALIDATE_BOOLEAN );
		$action           = filter_var( filter_input( INPUT_POST, 'action' ) );
		$customer         = get_user_by( 'id', $customer_id );
		$force            = is_null( $order );

		if ( ! $force && ( ! $customer || ! Util::is_wholesale_user( $customer ) ) ) {
			return $item;
		}

		$wholesale_role = false;
		$order          = is_null( $order ) ? $item->get_order() : $order;

		if ( is_a( $customer, 'WP_User' ) ) {
			try {
				$wholesale_role = new Wholesale_Role( Util::get_wholesale_role_for_user( $customer ) );
			} catch ( Exception $e ) {
				$wholesale_role = false;
			}
		}

		if ( $wholesale_role === false && ! $force ) {
			return $item;
		}

		if ( $wholesale_role === false && current_user_can( 'manage_woocommerce' ) ) {
			add_filter( 'wcwp_disregard_wholesale_pricing', '__return_true', 9999 );
		}

		$product             = $item->get_product();
		$price               = $product->get_price();
		$calculation_enabled = false;
		$wholesale_price     = false;

		if ( $wholesale_role ) {
			$wholesale_price = new Wholesale_Price( $product, $wholesale_role );

			if ( $wholesale_price ) {
				/**
				 * Filters whether to allow wholesale price calculation on a product.
				 *
				 * @param bool $enable Whether to allow wholesale price calculation on a product.
				 * @param \WC_Product $product The product which is being calculated.
				 * @param \WP_User $user The user for which the price is being calculated.
				 * @param float $price The wholesale price.
				 * @param array|null $item The cart item if this is calculated in the cart.
				 */
				$calculation_enabled = apply_filters( 'wcwp_enable_wholesale_price_calculation', true, $product, $customer, $wholesale_price->get_price(), $item );

				$price = $wholesale_price->get_final_price();
			}
		}

		if ( ( ! $calculation_enabled || $wholesale_price === false ) && ! $force ) {
			return $item;
		}

		$qty   = $item->get_quantity();
		$total = wc_get_price_excluding_tax(
			$product,
			[
				'qty'   => $qty,
				'price' => $price,
				'order' => $order,
			]
		);

		$changes       = $item->get_changes();
		$item_price    = $qty > 0 ? $item->get_subtotal() / $qty : 0;
		$price_changed = $item_price !== (float) $price && $action !== 'woocommerce_add_order_item';

		if ( ! $customer_changed ) {
			// We can consider returning the original item only if the customer has not changed.
			// Otherwise, we must force the recalculation

			if ( isset( $changes['total'] ) && $changes['total'] !== $item->get_total() || $item->get_subtotal() !== $item->get_total() || $price_changed ) {

				// The price was changed manually and we return the original item in the following cases:
				// - the item price has just been changed manually (with either a discount or an increase);
				// - the subtotal differs from the total (i.e. the item has a discount);
				// - the item price differs from the product price (i.e. the total was increased manually) and we are not adding a new line item.
				return $item;
			}
		}

		$item->set_subtotal( $total );
		$item->set_total( $total );
		$item->set_subtotal_tax( 0 );
		$item->set_total_tax( 0 );
		$item->save();

		remove_filter( 'wcwp_disregard_wholesale_pricing', '__return_true', 9999 );

		// When an order already contains an order item corresponding to $item_id
		// add_item will replace the modified order item instead of adding it to the order.
		// Re-adding (i.e. updating) the item in the order object is necessary
		// because the order is not reloaded after this filter callback returns
		$order->add_item( $item );

		$calculate_tax_args = array(
			'country'  => isset( $_POST['country'] ) ? wc_strtoupper( wc_clean( wp_unslash( $_POST['country'] ) ) ) : '',
			'state'    => isset( $_POST['state'] ) ? wc_strtoupper( wc_clean( wp_unslash( $_POST['state'] ) ) ) : '',
			'postcode' => isset( $_POST['postcode'] ) ? wc_strtoupper( wc_clean( wp_unslash( $_POST['postcode'] ) ) ) : '',
			'city'     => isset( $_POST['city'] ) ? wc_strtoupper( wc_clean( wp_unslash( $_POST['city'] ) ) ) : '',
		);

		if ( $wholesale_role && $wholesale_role->get_disable_tax() === 'disable' ) {
			// if the wholesale role has tax disabled, set `tax exempt` to true
			add_filter( 'woocommerce_order_is_vat_exempt', '__return_true' );
		}

		$order->calculate_taxes( $calculate_tax_args );
		$order->calculate_totals( false );

		// phpcs:enable WordPress.Security.NonceVerification.Missing

		return $item;
	}
}
