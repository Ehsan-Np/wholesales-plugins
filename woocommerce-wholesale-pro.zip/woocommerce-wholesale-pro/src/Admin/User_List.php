<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Customer;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Admin\Notices;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Exception;

/**
 * Handles functionality on the Users list table screen
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class User_List implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'user_row_actions', [ $this, 'approval_links' ], 10, 2 );
		add_action( 'admin_action_wcwp_approve_customer', [ $this, 'approve_customer' ] );
		add_action( 'admin_action_wcwp_reject_customer', [ $this, 'reject_customer' ] );

		add_filter( 'bulk_actions-users', [ $this, 'add_bulk_actions' ], 10, 1 );
		add_filter( 'handle_bulk_actions-users', [ $this, 'handle_bulk_actions' ], 10, 3 );

		add_action( 'load-users.php', [ $this, 'admin_notices' ] );
	}

	/**
	 * Add the Approve | Reject links to the user list
	 *
	 * @param array $actions
	 * @param \WP_User $user
	 * @return array
	 */
	public function approval_links( $actions, $user ) {
		if ( ! Util::is_moderation_required( $user ) ) {
			return $actions;
		}

		$approve_url = wp_nonce_url(
			add_query_arg(
				[
					'action'  => 'wcwp_approve_customer',
					'user_id' => $user->ID,
				],
				'users.php'
			),
			'wcwp-approve-customer'
		);

		$reject_url = wp_nonce_url(
			add_query_arg(
				[
					'action'  => 'wcwp_reject_customer',
					'user_id' => $user->ID,
				],
				'users.php'
			),
			'wcwp-reject-customer'
		);

		$new_actions = [
			'wcwp_approve' => sprintf( '<a href="%s">%s</a>', $approve_url, __( 'Approve', 'woocommerce-wholesale-pro' ) ),
			'wcwp_reject'  => sprintf( '<a href="%s">%s</a>', $reject_url, __( 'Reject', 'woocommerce-wholesale-pro' ) ),
		];

		return array_merge( $new_actions, $actions );
	}

	/**
	 * Approve admin action
	 */
	public function approve_customer() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_safe_redirect( admin_url( 'users.php' ), 303 );
			exit;
		}

		check_admin_referer( 'wcwp-approve-customer' );

		$user_id = filter_var( $_REQUEST['user_id'], FILTER_VALIDATE_INT );

		try {
			$customer = new Wholesale_Customer( $user_id );
			$customer->approve();
			wp_safe_redirect( add_query_arg( [ 'wcwp_approved' => 'true' ], admin_url( 'users.php' ) ), 303 );
		} catch ( Exception $e ) {
			wp_safe_redirect( add_query_arg( [ 'wcwp_error' => $user_id ], admin_url( 'users.php' ) ), 303 );
		}
	}

	/**
	 * Reject admin action
	 */
	public function reject_customer() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_safe_redirect( admin_url( 'users.php' ), 303 );
			exit;
		}

		check_admin_referer( 'wcwp-reject-customer' );

		$user_id = filter_var( $_REQUEST['user_id'], FILTER_VALIDATE_INT );

		try {
			$customer = new Wholesale_Customer( $user_id );
			$customer->reject();

			wp_safe_redirect( add_query_arg( [ 'wcwp_rejected' => 'true' ], admin_url( 'users.php' ) ), 303 );
		} catch ( Exception $e ) {
			wp_safe_redirect( add_query_arg( [ 'wcwp_error' => $user_id ], admin_url( 'users.php' ) ), 303 );
		}
	}

	/**
	 * Adds the Approve / Reject bulk actions to the pending user list
	 *
	 * @param   array $actions
	 * @return  array $actions
	 */
	public function add_bulk_actions( $actions ) {
		$role = filter_input( INPUT_GET, 'role', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		if ( ! $role || $role !== 'wcwp_pending' ) {
			return $actions;
		}

		$actions['wcwp_approve'] = __( 'Approve', 'woocommerce-wholesale-pro' );
		$actions['wcwp_reject']  = __( 'Reject', 'woocommerce-wholesale-pro' );

		return $actions;
	}

	/**
	 * Handles our bulk action operations
	 *
	 * @param   string  $redirect
	 * @param   string  $action
	 * @param   array   $object_ids
	 * @return  string  $redirect
	 */
	public function handle_bulk_actions( $redirect, $action, $object_ids ) {
		if ( $action === 'wcwp_approve' ) {
			foreach ( $object_ids as $user_id ) {
				try {
					$customer = new Wholesale_Customer( $user_id );
					$customer->approve();
				} catch ( Exception $e ) {
					continue;
				}
			}

			$redirect = add_query_arg( [ 'wcwp_bulk' => 'approved' ], $redirect );
		}

		if ( $action === 'wcwp_reject' ) {
			foreach ( $object_ids as $user_id ) {
				try {
					$customer = new Wholesale_Customer( $user_id );
					$customer->reject();
				} catch ( Exception $e ) {
					continue;
				}
			}

			$redirect = add_query_arg( [ 'wcwp_bulk' => 'rejected' ], $redirect );
		}

		return $redirect;
	}

	/**
	 * Display admin notices
	 */
	public function admin_notices() {
		// single approve
		$approved = filter_input( INPUT_GET, 'wcwp_approved', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		if ( $approved === 'true' ) {
			$admin_notice = new Notices();
			$admin_notice->add(
				'wcwp_user_approved',
				'',
				__( '<strong>WooCommerce Wholesale Pro:</strong> User has been approved.', 'woocommerce-wholesale-pro' ),
				[
					'type'       => 'success',
					'capability' => 'manage_woocommerce',
				]
			);
			$admin_notice->boot();
		}

		// single reject
		$rejected = filter_input( INPUT_GET, 'wcwp_rejected', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		if ( $rejected === 'true' ) {
			$admin_notice = new Notices();
			$admin_notice->add(
				'wcwp_user_rejected',
				'',
				__( '<strong>WooCommerce Wholesale Pro:</strong> User has been rejected and deleted.', 'woocommerce-wholesale-pro' ),
				[
					'type'       => 'success',
					'capability' => 'manage_woocommerce',
				]
			);
			$admin_notice->boot();
		}

		// bulk approve
		$bulk = filter_input( INPUT_GET, 'wcwp_bulk', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		if ( $bulk === 'approved' ) {
			$admin_notice = new Notices();
			$admin_notice->add(
				'wcwp_bulk_accepted',
				'',
				__( '<strong>WooCommerce Wholesale Pro:</strong> Selected users have been approved.', 'woocommerce-wholesale-pro' ),
				[
					'type'       => 'success',
					'capability' => 'manage_woocommerce',
				]
			);
			$admin_notice->boot();
		}

		// bulk reject
		if ( $bulk === 'rejected' ) {
			$admin_notice = new Notices();
			$admin_notice->add(
				'wcwp_bulk_rejected',
				'',
				__( '<strong>WooCommerce Wholesale Pro:</strong> Selected users have been rejected and deleted.', 'woocommerce-wholesale-pro' ),
				[
					'type'       => 'success',
					'capability' => 'manage_woocommerce',
				]
			);
			$admin_notice->boot();
		}
	}
}
