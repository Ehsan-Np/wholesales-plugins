<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Settings_Tab;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

/**
 * Roles Setting Tab
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Registration_Fields implements Registerable, Standard_Service {
	private $id;

	/**
	 * Constructor.
	 *
	 * @param string $id
	 */
	public function __construct( $id ) {
		$this->id = $id;
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'woocommerce_admin_field_wcwp_fields', [ $this, 'setting_screen' ] );
		add_action( 'wcwp_update_registration_fields', [ $this, 'process_admin_options' ] );
	}

	/**
	 * Return the ID of the settings tab.
	 *
	 * @return string
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Retrieve the settings.
	 *
	 * @return array
	 */
	public function get_settings() {
		$settings = [
			[
				'id'    => 'wholesale_pro_settings_start',
				'type'  => 'settings_start',
				'class' => 'wholesale-pro-settings registration-fields barn2-plugins-settings'
			],

			[ 'type' => 'wcwp_fields' ],

			[
				'type' => 'sectionend',
				'id'   => $this->id . 'roles_settings',
			],

			[
				'id'   => 'wholesale_pro_settings_end',
				'type' => 'settings_end',
			],
		];

		return $settings;
	}

	/**
	 * Output the setting screen.
	 */
	public function setting_screen() {
		global $hide_save_button;
		$hide_save_button = true;

		$this->registration_fields_table();
	}

	/**
	 * Save our custom table values
	 */
	public function process_admin_options() {
		$all_fields = filter_input( INPUT_POST, 'wcwp_registration_fields', FILTER_SANITIZE_FULL_SPECIAL_CHARS, FILTER_REQUIRE_ARRAY );

		if ( ! $all_fields ) {
			return;
		}

		// discard any fields without a label
		$active_fields = array_filter(
			$all_fields,
			function( $field_entry ) {
				return ! empty( $field_entry['label'] );
			}
		);

		if ( empty( $active_fields ) ) {
			delete_option( 'wcwp_registration_fields' );
			return;
		}

		foreach ( $active_fields as $index => $field ) {
			if ( ! isset( $field['required'] ) ) {
				$active_fields[ $index ]['required'] = '';
			}

			$saved_fields[ $field['id'] ] = $active_fields[ $index ];
		}

		update_option( 'wcwp_registration_fields', $saved_fields, false );
	}

	/**
	 * Registration fields table screen
	 */
	private function registration_fields_table() {
		$fields = get_option( 'wcwp_registration_fields', [] );

		// if empty generate placeholders
		if ( empty( $fields ) || count( $fields ) !== 10 ) {
			$field_count = count( $fields );

			while ( $field_count < 10 ) {
				$fields[ uniqid( 'wcwp-' ) ] = $this->get_empty_field();
				$field_count++;
			}
		}
		?>

		<h2 class="wcwp-registration-fields-heading">
			<?php esc_html_e( 'Legacy Custom Registration Fields', 'woocommerce-wholesale-pro' ); ?>
		</h2>

		<p><?php esc_html_e( 'Use this page to add extra fields to the registration form. These will appear if you enable the registration form on the wholesale login page, or if you use the [wholesale_registration] shortcode.', 'woocommerce-wholesale-pro' ); ?></p>

		<table class="wcwp-registration-fields widefat">
			<thead>
				<tr>
					<th class="wcwp-registration-field-sort"><?php echo wc_help_tip( __( 'Drag and drop to re-order your registration fields.', 'woocommerce-wholesale-pro' ) ); ?></th>
					<th class="wcwp-registration-field-label">
						<?php
						esc_html_e( 'Label', 'woocommerce-wholesale-pro' );
						echo wc_help_tip( __( 'Enter the label of the form field. This appears above the field on the registration form.', 'woocommerce-wholesale-pro' ) );
						?>
					</th>
					<th class="wcwp-registration-field-required">
						<?php
						esc_html_e( 'Required', 'woocommerce-wholesale-pro' );
						echo wc_help_tip( __( 'Select this option to make the form field required. Required fields must be completed before the form can be submitted.', 'woocommerce-wholesale-pro' ) );
						?>
					</th>
				</tr>
			</thead>

			<tbody class="wcwp-registration-field-rows">
				<?php
				foreach ( $fields as $unique_id => $field ) :
					$saved_class = ! empty( $field['label'] ) ? 'saved' : '';
					?>
					<tr id="wcwp-registration-field-<?php echo esc_attr( $unique_id ); ?>">
						<td class="wcwp-registration-field-sort" width="1%"></td>
						<td>
							<p class="wcwp-field-label">
								<input type="text" class="<?php echo esc_attr( $saved_class ); ?>" name="wcwp_registration_fields[<?php echo esc_attr( $unique_id ); ?>][label]" value="<?php echo esc_attr( $field['label'] ); ?>"/>
								<span class="wcwp-fields-error"><?php esc_html_e( 'Warning! Renaming this field will also affect your existing wholesale users. No data will be deleted, but the field label will change.', 'woocommerce-wholesale-pro' ); ?></span>
							</p>

						</td>
						<td width="70px">
							<p><input type="checkbox" name="wcwp_registration_fields[<?php echo esc_attr( $unique_id ); ?>][required]" value="yes" <?php checked( $field['required'], 'yes' ); ?>/></p>
						</td>
						<input type="hidden" name="wcwp_registration_fields[<?php echo esc_attr( $unique_id ); ?>][type]" value="text" />
						<input type="hidden" name="wcwp_registration_fields[<?php echo esc_attr( $unique_id ); ?>][id]" value="<?php echo esc_attr( $unique_id ); ?>" />
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<p class="submit">
			<button type="submit" name="save" class="button button-primary wcwp-registration-fields-save" value="<?php esc_attr_e( 'Save changes', 'woocommerce-wholesale-pro' ); ?>"><?php \esc_html_e( 'Save changes', 'woocommerce-wholesale-pro' ); ?></button>
		</p>
		<?php
	}

	/**
	 * Returns an empty registration field
	 *
	 * @return array
	 */
	private function get_empty_field() {
		return [
			'type'     => 'text',
			'name'     => '',
			'label'    => '',
			'required' => '',
		];
	}
}
