<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Settings_Tab;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Role;
use Barn2\Plugin\WC_Wholesale_Pro\Admin\Settings_Screen\Wholesale_Roles;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use WC_Admin_Settings;
use Exception;

/**
 * Roles Setting Tab
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Roles implements Registerable, Standard_Service {
	private $id;

	/**
	 * Constructor.
	 *
	 * @param string $id
	 */
	public function __construct( $id ) {
		$this->id = $id;
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'woocommerce_admin_field_wcwp_roles', [ $this, 'setting_screen' ] );
		add_filter( 'wcwp_admin_roles_description', [ $this, 'adjust_admin_description' ] );
	}

	/**
	 * Return the ID of the settings tab.
	 *
	 * @return string
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Retrieves the settings.
	 *
	 * @return array
	 */
	public function get_settings() {
		$settings = [
			[
				'id'    => 'wholesale_pro_settings_start',
				'type'  => 'settings_start',
				'class' => 'wholesale-pro-settings wholesale-roles barn2-plugins-settings'
			],

			[ 'type' => 'wcwp_roles' ],

			[
				'type' => 'sectionend',
				'id'   => $this->id . 'roles_settings',
			],

			[
				'id'   => 'wholesale_pro_settings_end',
				'type' => 'settings_end',
			],
		];

		return $settings;
	}

	/**
	 * Output the correct setting screen (Role List or Role Edit)
	 */
	public function setting_screen() {
		global $hide_save_button;
		$hide_save_button = true;

		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		if ( isset( $_REQUEST['role_name'] ) ) {
			$this->role_edit_screen( wp_unslash( $_REQUEST['role_name'] ) );
		} else {
			if ( isset( $_REQUEST['delete_role'] ) ) {
				$this->delete_role( wp_unslash( $_REQUEST['delete_role'] ) );
				WC_Admin_Settings::add_message( __( 'Your role has been succesfully deleted.', 'woocommerce-wholesale-pro' ) );
			}

			if ( isset( $_REQUEST['message'] ) && ( $_REQUEST['message'] === 'saved_role' ) ) {
				WC_Admin_Settings::add_message( __( 'Your role has been succesfully saved.', 'woocommerce-wholesale-pro' ) );
			}

			// phpcs:enable WordPress.Security.NonceVerification.Recommended
			WC_Admin_Settings::show_messages();

			$this->role_manage_screen();
		}
	}

	/**
	 * Wholesale roles list screen
	 */
	private function role_manage_screen() {
		$wholesale_roles = Util::get_wholesale_roles();
		$wholesale_roles = array_diff( $wholesale_roles, [ 'wcwp_pending' ] );

		$default_icon = '<svg class="wcwp-default-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect x="0" fill="none" width="24" height="24"/><g><path d="M9 19.414l-6.707-6.707 1.414-1.414L9 16.586 20.293 5.293l1.414 1.414"/></g></svg>';
		?>
		<h2 class="wc-wholesale-roles-heading">
			<?php esc_html_e( 'Wholesale User Roles', 'woocommerce-wholesale-pro' ); ?>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=wholesale-pro&section=roles&role_name=new' ) ); ?>" class="page-title-action">
				<?php esc_html_e( 'Add new role', 'woocommerce-wholesale-pro' ); ?>
			</a>
		</h2>
		<p>
		<?php
		$description = sprintf(
			'Use this page to manage your wholesale user roles and set global percentage discounts for each role. You can also set <a href="%1$s">category-level discounts</a> or set exact wholesale prices for <a href="%2$s">each individual product</a>.',
			esc_url( admin_url( 'edit-tags.php?taxonomy=product_cat&post_type=product' ) ),
			esc_url( admin_url( 'edit.php?post_type=product' ) )
		);

		/**
		 * Filter the wholesale roles description in the admin panel.
		 *
		 * @param string $description The description text.
		 * @return string The filtered description text.
		 */
		$description = apply_filters( 'wcwp_admin_roles_description', $description );

		echo wp_kses_post( $description );
		?>
		</p>
		<table class="wcwp-wholesale-roles widefat">
			<thead>
				<tr>
					<th class="wcwp-wholesale-role-sort"><?php echo wc_help_tip( __( 'Drag and drop to re-order your wholesale roles. This will only be used for display purposes in the admin.', 'woocommerce-wholesale-pro' ) ); ?></th>
					<th class="wcwp-wholesale-role-role"><?php esc_html_e( 'Role', 'woocommerce-wholesale-pro' ); ?></th>
					<th class="wcwp-wholesale-role-discount">
						<?php
						esc_html_e( 'Global % discount', 'woocommerce-wholesale-pro' );
						echo wc_help_tip( __( 'The percentage discount which will be deducted from the price of all products for this user role. You can override this for individual categories or products.', 'woocommerce-wholesale-pro' ) );
						?>
					</th>
					<th class="wcwp-wholesale-role-product">
						<?php
						esc_html_e( 'Product-specific pricing', 'woocommerce-wholesale-pro' );
						echo wc_help_tip( __( 'Adds an option to set exact wholesale prices for individual products and variations. If set, product-specific prices override the global and category wholesale discounts.', 'woocommerce-wholesale-pro' ) );
						?>
					</th>
					<th class="wcwp-wholesale-role-tax">
						<?php
						esc_html_e( 'Tax status', 'woocommerce-wholesale-pro' );
						echo wc_help_tip( __( 'Tax status for wholesale users with this role. \'Inherited\' will respect the global setting in the General settings section.', 'woocommerce-wholesale-pro' ) );
						?>
					</th>
					<th class="wcwp-wholesale-role-price-display">
						<?php
						esc_html_e( 'Price display', 'woocommerce-wholesale-pro' );
						echo wc_help_tip( __( 'Price display for wholesale users with this role. \'Inherited\' will respect the global setting in the WooCommerce tax options settings.', 'woocommerce-wholesale-pro' ) );
						?>
					</th>
					<th class="wcwp-wholesale-role-default">
						<?php
						esc_html_e( 'Default role', 'woocommerce-wholesale-pro' );
						echo wc_help_tip( __( 'The default role will be assigned to all new users who register via the wholesale registration form. The administrator can then change user roles as required.', 'woocommerce-wholesale-pro' ) );
						?>
					</th>
					<th class="wcwp-wholesale-role-users"><?php esc_html_e( 'Users', 'woocommerce-wholesale-pro' ); ?></th>
				</tr>
			</thead>
			<tbody class="wcwp-wholesale-rows-custom">
				<?php
				foreach ( $wholesale_roles as $role_name ) :
					$role = new Wholesale_Role( $role_name );
					?>
					<tr id="<?php echo esc_attr( $role_name ); ?>">
						<td class="wcwp-wholesale-role-sort" width="1%"></td>
						<td>
							<a href="admin.php?page=wc-settings&amp;tab=wholesale-pro&amp;section=roles&amp;role_name=<?php echo esc_attr( $role->get_name() ); ?>"><?php echo esc_html( $role->get_display_name() ); ?></a>
							<div class="row-actions">
								<a href="admin.php?page=wc-settings&amp;tab=wholesale-pro&amp;section=roles&amp;role_name=<?php echo esc_attr( $role->get_name() ); ?>"><?php esc_html_e( 'Edit', 'woocommerce-wholesale-pro' ); ?></a>
								<?php if ( $role_name !== 'wcwp_wholesale' ) : ?>
									|
									<a href="admin.php?page=wc-settings&amp;tab=wholesale-pro&amp;section=roles&amp;delete_role=<?php echo esc_attr( $role->get_name() ); ?>" class="wcwp-wholesale-role-delete"><?php esc_html_e( 'Delete', 'woocommerce-wholesale-pro' ); ?></a>
								<?php endif; ?>
							</div>
						</td>
						<td>
							<p>
								<?php
								if ( $role->get_global_discount() > 0 ) {
									echo esc_html( sprintf( '%s%%', $role->get_global_discount() ) );
								} else {
									esc_html_e( 'None', 'woocommerce-wholesale-pro' );
								}
								?>
							</p>
						</td>
						<td>
						<p>
							<?php $role->get_product_pricing() === 'yes' ? esc_html_e( 'Active', 'woocommerce-wholesale-pro' ) : esc_html_e( 'Inactive', 'woocommerce-wholesale-pro' ); ?></p>
						</td>
						<td>
						<p>
							<?php
							switch ( $role->get_disable_tax() ) {
								case 'inherit':
									esc_html_e( 'Inherited', 'woocommerce-wholesale-pro' );
									break;
								case 'disable':
									esc_html_e( 'Disabled', 'woocommerce-wholesale-pro' );
									break;
								case 'enable':
									esc_html_e( 'Enabled', 'woocommerce-wholesale-pro' );
									break;
							}
							?>
						</p>
						</td>
						<td>
						<p>
							<?php
							switch ( $role->get_tax_display_shop() ) {
								case 'inherit':
									esc_html_e( 'Inherited', 'woocommerce-wholesale-pro' );
									break;
								case 'incl':
									esc_html_e( 'Including tax', 'woocommerce-wholesale-pro' );
									break;
								case 'excl':
									esc_html_e( 'Excluding tax', 'woocommerce-wholesale-pro' );
									break;
							}
							?>
						</p>
						</td>
						<td>
							<p>
							<?php
							if ( $role->get_default() === 'yes' ) {
								echo $default_icon; // phpcs:ignore
							}
							?>
							</p>
						</td>
						<td class="wcwp-wholesale-role-users-actions">
							<a href="<?php echo esc_url( add_query_arg( 'role', $role->get_name(), admin_url( 'users.php' ) ) ); ?>" class="wcwp-wholesale-user-count"><?php echo esc_html( $role->get_user_count() ); ?></a>
							<a href="<?php echo esc_url( add_query_arg( 'role', $role->get_name(), admin_url( 'users.php' ) ) ); ?>" class="button button-small button-secondary"><?php esc_html_e( 'View', 'woocommerce-wholesale-pro' ); ?></a>
							<a href="<?php echo esc_url( add_query_arg( 'wholesale', $role->get_name(), admin_url( 'user-new.php' ) ) ); ?>" class="button button-small button-secondary"><?php esc_html_e( 'Add', 'woocommerce-wholesale-pro' ); ?></a>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Role Edit Screen
	 *
	 * @param string $role_name
	 */
	private function role_edit_screen( $role_name ) {
		$settings_screen = new Wholesale_Roles( sanitize_title_with_dashes( $role_name ) );

		if ( ! empty( $_POST['submit'] ) ) { // WPCS: input var ok, sanitization ok.
			if ( empty( $_REQUEST['_wpnonce'] ) || ! wp_verify_nonce( wp_unslash( $_REQUEST['_wpnonce'] ), 'woocommerce-settings' ) ) { // WPCS: input var ok, sanitization ok.
				echo '<div class="updated error"><p>' . esc_html__( 'Edit failed. Please try again.', 'woocommerce-wholesale-pro' ) . '</p></div>';
			}

			$settings_screen->process_admin_options();
			$settings_screen->display_errors();
		}

		$settings_screen->admin_options();
	}

	/**
	 * Remove role
	 *
	 * @param string $role_name
	 */
	private function delete_role( $role_name ) {
		try {
			$wholesale_role = new Wholesale_Role( sanitize_title_with_dashes( $role_name ) );
			$wholesale_role->delete();
		} catch ( Exception $e ) {
			wp_safe_redirect( admin_url( 'admin.php?page=wc-settings&tab=wholesale-pro&section=roles' ), 303 );
		}
	}

	/**
	 * Adjust the admin description if the Discount Manager plugin is not installed.
	 *
	 * @param string $description The description text.
	 * @return string The filtered description text.
	 */
	public function adjust_admin_description( $description ): string {
		if ( function_exists( 'Barn2\Plugin\Discount_Manager\wdm' ) ) {
			return $description;
		}

		return $description . ' ' . sprintf(
			__( 'To set bulk or quantity-based discounts, please use WooCommerce Wholesale Pro with our <a href="%s">WooCommerce Discount Manager</a> plugin.', 'woocommerce-wholesale-pro' ),
			esc_url( 'https://barn2.com/wordpress-plugins/woocommerce-discount-manager/?utm_source=settings&utm_medium=settings&utm_campaign=settingsintro&utm_content=wwp-wdm' )
		);
	}
}
