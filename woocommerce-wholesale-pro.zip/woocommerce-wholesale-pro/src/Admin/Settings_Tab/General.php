<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Settings_Tab;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Admin\Settings_Util;
use Barn2\Plugin\WC_Wholesale_Pro\Plugin;
use WC_Admin_Settings;

/**
 * General Setting Tab
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class General implements Registerable, Standard_Service {
	private $id;
	private $plugin;
	private $license_setting;

	/**
	 * Constructor.
	 *
	 * @param string $id
	 * @param Plugin $plugin
	 */
	public function __construct( $id, Plugin $plugin ) {
		$this->id              = $id;
		$this->plugin          = $plugin;
		$this->license_setting = $plugin->get_license_setting();
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'woocommerce_admin_field_tinymce', [ $this, 'tinymce_editor_field' ] );
		add_filter( 'woocommerce_admin_settings_sanitize_option_wcwp_hide_prices_text', [ $this, 'sanitize_tinymce_editor_field' ], 10, 3 );

		add_filter( 'woocommerce_admin_settings_sanitize_' . $this->license_setting->get_license_setting_name(), [ $this, 'handle_license' ], 10, 1 );
		add_filter( 'woocommerce_admin_settings_sanitize_option_wcwp_wholesale_login_page_id', [ $this, 'handle_login_page' ], 10, 1 );
		add_filter( 'woocommerce_admin_settings_sanitize_option_wcwp_enable_registration', [ $this, 'update_login_page' ], 10, 1 );
		add_filter( 'woocommerce_admin_settings_sanitize_option_wcwp_moderate_registrations', [ $this, 'update_login_page' ], 10, 1 );
		add_filter( 'woocommerce_admin_settings_sanitize_option_wcwp_login_redirect', [ $this, 'sanitize_login_redirect' ], 10, 1 );
		add_filter( 'woocommerce_admin_settings_sanitize_option_wcwp_registration_redirect', [ $this, 'sanitize_registration_redirect' ], 10, 1 );

		add_filter( 'wcwp_general_settings', [ $this, 'add_uninstall_section' ], PHP_INT_MAX );
	}

	/**
	 * Return the ID of the settings tab.
	 *
	 * @return string
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Retrieves the setp settings.
	 *
	 * @return array
	 */
	public function get_settings() {

		$settings = [
			[
				'id'    => 'wholesale_pro_settings_start',
				'type'  => 'settings_start',
				'class' => 'wholesale-pro-settings barn2-plugins-settings',
			],

			[
				'name' => __( 'General', 'woocommerce-wholesale-pro' ),
				'type' => 'title',
				'desc' => sprintf(
					'<p>%1$s</p><p>%2$s</p>',
					__( 'The following options control the WooCommerce Wholesale Pro extension.', 'woocommerce-wholesale-pro' ),
					Settings_Util::get_help_links( $this->plugin )
				),
				'id'   => $this->id . 'general_settings',
			],

			$this->license_setting->get_license_key_setting(),
			$this->license_setting->get_license_override_setting(),

			[
				'title'    => __( 'Wholesale login page', 'woocommerce-wholesale-pro' ),

				'desc'     => sprintf(
					/* translators: %s: shortcode tag */
					__( 'This page will be used as your wholesale login page. The shortcode [%s] will be added to the selected page.', 'woocommerce-wholesale-pro' ),
					/**
					 * Filters the login shortcode tag.
					 *
					 * @param string $tag The shortcode tag excluding the brackets.
					 */
					apply_filters( 'wcwp_login_shortcode_tag', 'wholesale_login' )
				),
				'id'       => 'wcwp_wholesale_login_page_id',
				'type'     => 'single_select_page',
				'default'  => '',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
				'args'     => [
					'exclude' =>
						[
							wc_get_page_id( 'cart' ),
							wc_get_page_id( 'checkout' ),
							wc_get_page_id( 'myaccount' ),
						],
				],
				'desc_tip' => true,
				'autoload' => false,
			],

			[
				'title'    => __( 'Wholesale registration', 'woocommerce-wholesale-pro' ),
				'desc'     => __( 'Display registration form on the wholesale login page.', 'woocommerce-wholesale-pro' ),
				'desc_tip' => __( 'If disabled, you can still use the [wholesale_registration] shortcode to display a registration form elsewhere.', 'woocommerce-wholesale-pro' ),
				'id'       => 'wcwp_enable_registration',
				'type'     => 'checkbox',
				'default'  => 'yes',
				'autoload' => false,
			],

			[
				'title'    => __( 'Moderate new registrations', 'woocommerce-wholesale-pro' ),
				'desc'     => __( 'Hold new wholesale registrations for moderation by an administrator.', 'woocommerce-wholesale-pro' ),
				'id'       => 'wcwp_moderate_registrations',
				'type'     => 'checkbox',
				'default'  => 'yes',
				'autoload' => false,
			],

			[
				'title'    => __( 'Wholesale store page', 'woocommerce-wholesale-pro' ),
				'desc'     => __( 'By default wholesale users will be sent to this page after logging in. You can specify a Redirect URL below to change this. If you select the main shop page then the same page will be used for regular and wholesale customers, but each will see the appropriate pricing and layout for their role.', 'woocommerce-wholesale-pro' ),
				'id'       => 'wcwp_wholesale_store_page_id',
				'type'     => 'single_select_page',
				'default'  => '',
				'class'    => 'wc-enhanced-select-nostd',
				'css'      => 'min-width:300px;',
				'args'     => [
					'exclude' =>
						[
							wc_get_page_id( 'cart' ),
							wc_get_page_id( 'checkout' ),
							wc_get_page_id( 'myaccount' ),
						],
				],
				'desc_tip' => true,
				'autoload' => false,
			],

			[
				'title'       => __( 'Login redirect URL', 'woocommerce-wholesale-pro' ),
				'desc_tip'    => __( 'Redirect wholesale users to a specific page after logging in.', 'woocommerce-wholesale-pro' ),
				'id'          => 'wcwp_login_redirect',
				'placeholder' => 'https://',
				'class'       => 'regular-input',
				'type'        => 'text',
			],

			[
				'title'       => __( 'Registration redirect URL', 'woocommerce-wholesale-pro' ),
				'desc_tip'    => __( 'Redirect wholesale users to a specific page after registration.', 'woocommerce-wholesale-pro' ),
				'id'          => 'wcwp_registration_redirect',
				'placeholder' => 'https://',
				'class'       => 'regular-input',
				'type'        => 'text',
			],

			[
				'title'    => __( 'Wholesale price display', 'woocommerce-wholesale-pro' ),
				'id'       => 'wcwp_show_original_price',
				'type'     => 'select',
				'default'  => 'show',
				'css'      => 'min-width:300px;',
				'options'  => [
					'show' => __( 'Show wholesale price with original price crossed out', 'woocommerce-wholesale-pro' ),
					'hide' => __( 'Hide original price and just show wholesale price', 'woocommerce-wholesale-pro' ),
				],
				'autoload' => false,
			],

			[
				'title'    => __( 'Hide prices until login', 'woocommerce-wholesale-pro' ),
				'desc'     => __( 'Hide prices and disable purchasing for logged out users.', 'woocommerce-wholesale-pro' ),
				'desc_tip' => __( 'Show all products without prices for logged out users. You can also hide prices for specific categories only via Products > Categories.', 'woocommerce-wholesale-pro' ),
				'id'       => 'wcwp_hide_prices',
				'type'     => 'checkbox',
				'default'  => 'no',
				'autoload' => false,
			],

			[
				'title'    => __( 'Alternate content', 'woocommerce-wholesale-pro' ),
				'desc_tip' => __( 'When prices are hidden, users will see this text instead of the price.', 'woocommerce-wholesale-pro' ),
				'id'       => 'wcwp_hide_prices_text',
				'type'     => 'tinymce',
				'autoload' => false,
			],

			[
				'title'    => __( 'Disable tax', 'woocommerce-wholesale-pro' ),
				'desc'     => __( 'Do not charge tax to wholesale users.', 'woocommerce-wholesale-pro' ),
				'desc_tip' => __( 'Displays prices without tax and disables tax for logged in wholesale users. You can override this for specific roles.', 'woocommerce-wholesale-pro' ),
				'id'       => 'wcwp_disable_tax',
				'type'     => 'checkbox',
				'default'  => 'no',
				'autoload' => false,
			],

			[
				'title'    => __( 'Disable coupons', 'woocommerce-wholesale-pro' ),
				'desc'     => __( 'Hide the coupon code field from wholesale users.', 'woocommerce-wholesale-pro' ),
				'id'       => 'wcwp_disable_coupons',
				'type'     => 'checkbox',
				'default'  => 'no',
				'autoload' => false,
			],
			[
				'title'    => __( 'Admins see wholesale pricing', 'woocommerce-wholesale-pro' ),
				'desc'     => __( 'Show prices for the default wholesale role to administrators.', 'woocommerce-wholesale-pro' ),
				'id'       => 'wcwp_admin_wholesale_pricing',
				'type'     => 'checkbox',
				'default'  => 'yes',
				'autoload' => false,
			],

			[
				'type' => 'sectionend',
				'id'   => $this->id . 'general_settings',
			],

			[
				'id'   => 'wholesale_pro_settings_end',
				'type' => 'settings_end',
			],
		];

		return apply_filters( 'wcwp_general_settings', $settings );
	}

	/**
	 * Handle license activation
	 *
	 * @param string    $value
	 * @return string   $value
	 */
	public function handle_license( $value ) {
		$value = $this->license_setting->save_license_key( $value );

		return $value;
	}

	/**
	 * Adds shortcode to the login page if it doesn't exist
	 *
	 * @param string    $value
	 * @return string   $value
	 */
	public function handle_login_page( $value ) {
		if ( ! is_numeric( $value ) ) {
			return;
		}

		$page = get_post( absint( $value ) );

		$update_page = [ 'ID' => $page->ID ];

		/**
		 * Filters the login shortcode tag.
		 *
		 * @param string $tag The shortcode tag excluding the brackets.
		 */
		if ( $page && 'publish' === $page->post_status && ! strpos( $page->post_content, sprintf( '[%s]', apply_filters( 'wcwp_login_shortcode_tag', 'wholesale_login' ) ) ) ) {
			/**
			 * Filters the login shortcode tag.
			 *
			 * @param string $tag The shortcode tag excluding the brackets.
			 */
			$update_page['post_content'] = $page->post_content . '<!-- wp:shortcode -->[' . apply_filters( 'wcwp_login_shortcode_tag', 'wholesale_login' ) . ']<!-- /wp:shortcode -->';
		}

		wp_update_post( $update_page );

		return $value;
	}

	/**
	 * Update the login page when settings related to it's display change.
	 * This allows for additional cache clearing with environments not supporting WP DONOTCACHE constants.
	 *
	 * @param string    $value
	 * @return string   $value
	 */
	public function update_login_page( $value ) {
		wp_update_post( [ 'ID' => get_option( 'wcwp_wholesale_login_page_id' ) ] );

		return $value;
	}

	/**
	 * Sanitizes the Login Redirect URL setting.
	 *
	 * @param string $value
	 * @return string
	 */
	public function sanitize_login_redirect( $value ) {
		if ( $value ) {
			$value = $this->sanitize_url( $value );

			if ( ! filter_var( $value, FILTER_VALIDATE_URL ) ) {
				if ( class_exists( '\WC_Admin_Settings' ) ) {
					WC_Admin_Settings::add_error( __( 'The login redirect URL is invalid.', 'woocommerce-wholesale-pro' ) );
				}

				$value = '';
			}
		}

		return $value;
	}

	/**
	 * Sanitizes the Registration Redirect URL setting.
	 *
	 * @param string $value
	 * @return string
	 */
	public function sanitize_registration_redirect( $value ) {
		if ( $value ) {
			$value = $this->sanitize_url( $value );

			if ( ! filter_var( $value, FILTER_VALIDATE_URL ) ) {
				if ( class_exists( '\WC_Admin_Settings' ) ) {
					WC_Admin_Settings::add_error( __( 'The registration redirect URL is invalid.', 'woocommerce-wholesale-pro' ) );
				}

				$value = '';
			}
		}

		return $value;
	}

	/**
	 * Sanitizes TinyMCE settings field.
	 *
	 * @param mixed $value
	 * @param mixed $option
	 * @param mixed $raw_value
	 * @return string
	 */
	public function sanitize_tinymce_editor_field( $value, $option, $raw_value ) {
		return wp_kses_post( $raw_value );
	}

	/**
	 * Outputs a TinyMCE settings field.
	 *
	 * @param mixed $value
	 */
	public function tinymce_editor_field( $value ) {
		$option_value      = WC_Admin_Settings::get_option( $value['id'], $value['default'] );
		$field_description = WC_Admin_Settings::get_field_description( $value );

		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<label for="<?php echo esc_attr( $value['id'] ); ?>">
					<?php echo esc_html( $value['title'] ); ?>
					<?php echo $field_description['tooltip_html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</label>

			</th>
			<td class="forminp forminp-<?php echo esc_attr( sanitize_title( $value['type'] ) ); ?> <?php echo esc_attr( $value['class'] ); ?>">
				<?php wp_editor( $option_value, $value['id'], [ 'textarea_rows' => 10 ] ); ?>
				<?php echo $field_description['description']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Sanitize and ensure a valid URL.
	 *
	 * @param string $url
	 * @return string
	 */
	private function sanitize_url( $url ) {
		$parsed_url = wp_parse_url( $url );

		$scheme = $parsed_url['scheme'] ?? 'https';
		$host   = $parsed_url['host'] ?? '';
		$path   = $parsed_url['path'] ?? '/';

		if ( empty( $host ) ) {
			if ( strpos( $path, '.' ) > 0 ) {
				preg_match( '/^([a-z0-9\-\.]*)(\/)(.*)?$/i', $path, $matches );
				if ( ! isset( $matches[3] ) ) {
					$host = wp_parse_url( home_url(), PHP_URL_HOST );

					if ( isset( $matches[1] ) ) {
						$path = $matches[1];
					}
				} else {
					$host = $matches[1] ?: wp_parse_url( home_url(), PHP_URL_HOST );
					$path = $matches[3];
				}
			} else {
				$host = wp_parse_url( home_url(), PHP_URL_HOST );
			}
		}

		$output_url = wp_normalize_path( "$scheme://$host/$path" );

		return $output_url;
	}

	/**
	 * Add the Uninstall section to the settings.
	 *
	 * @param array $settings The current settings.
	 * @return array The updated settings.
	 */
	public function add_uninstall_section( $settings ) {
		$uninstall_section = [
			[
				'title' => __( 'Uninstall', 'woocommerce-wholesale-pro' ),
				'type'  => 'title',
				'id'    => 'wcwp_uninstall_section',
				'desc'  => __( 'The following options control the uninstallation of the WooCommerce Wholesale Pro extension.', 'woocommerce-wholesale-pro' ),
			],
			[
				'type'    => 'checkbox',
				'id'      => 'wcwp_delete_data_on_uninstall',
				'title'   => __( 'Delete data', 'woocommerce-wholesale-pro' ),
				'name'    => 'wcwp_delete_data_on_uninstall',
				'default' => false,
				'desc'    => sprintf(
					// translators: %s is the plugin name.
					__( 'Permanently delete all %s settings and data when uninstalling the plugin.', 'woocommerce-wholesale-pro' ),
					$this->plugin->get_name()
				),
			],
			[
				'type' => 'sectionend',
				'id'   => 'wcwp_uninstall_section',
			],
		];

		return array_merge( $settings, $uninstall_section );
	}
}
