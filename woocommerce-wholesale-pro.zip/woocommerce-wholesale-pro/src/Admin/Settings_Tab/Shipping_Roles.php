<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Settings_Tab;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use WC_Shipping;

/**
 * Emails Setting Tab
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Shipping_Roles implements Registerable, Standard_Service {
	private $id;
	private $section;

	/**
	 * Constructor.
	 *
	 * @param string $id
	 */
	public function __construct( $id ) {
		$this->id      = $id;
		$this->section = 'shipping-roles';
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'woocommerce_admin_field_wcwp_shipping_roles', [ $this, 'setting_screen' ] );
		add_action( 'wcwp_update_shipping_roles', [ $this, 'save' ] );
	}

	/**
	 * Return the ID of the settings tab.
	 *
	 * @return string
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Add the section
	 *
	 * @param   array   $sections
	 * @return  array   $sections
	 */
	public function add_section( $sections ) {
		$sections[ $this->section ] = __( 'Shipping roles', 'woocommerce-wholesale-pro' );
		return $sections;
	}

	/**
	 * Add the settings
	 *
	 * @param   array   $settings
	 * @param   string  $current_section
	 * @return  string  $settings
	 */
	public function get_settings() {
		return [
			[
				'id'    => 'wholesale_pro_settings_start',
				'type'  => 'settings_start',
				'class' => 'wholesale-pro-settings barn2-plugins-settings'
			],

			[
				'name' => __( 'Shipping roles', 'woocommerce-wholesale-pro' ),
				'desc' => __( 'Select which roles can use each shipping method.', 'woocommerce-wholesale-pro' ),
				'type' => 'title',
				'id'   => $this->id . 'shipping_role_settings',
			],

			[ 'type' => 'wcwp_shipping_roles' ],

			[
				'type' => 'sectionend',
				'id'   => $this->id . 'payment_role_settings',
			],

			[
				'id'   => 'wholesale_pro_settings_end',
				'type' => 'settings_end'
			],
		];
	}

	/**
	 * Save the data
	 */
	public function save() {
		global $current_section;

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		if ( $current_section === $this->section && isset( $_POST['wcwp_shipping_roles'] ) ) {
			update_option( 'wcwp_shipping_roles', wc_clean( $_POST['wcwp_shipping_roles'] ), false );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}

	/**
	 * Output custom setting screen
	 */
	public function setting_screen() {
		$shipping_object = new WC_Shipping();
		$shipping_roles  = get_option( 'wcwp_shipping_roles', [] );
		$filtered_roles  = array_filter(
			wp_roles()->roles,
			function ( $role ) {
				return $role !== 'wcwp_pending';
			},
			ARRAY_FILTER_USE_KEY
		);

		$filtered_roles['guest_wcwp'] = [ 'name' => 'Guest' ];
		?>

		<table class="wcwp-shipping-roles widefat">
			<thead>
				<tr>
					<th class="wcwp-shipping-role-method">
						<?php esc_html_e( 'Shipping method', 'woocommerce-wholesale-pro' ); ?>
					</th>
					<th class="wcwp-shipping-role-roles">
						<?php
						esc_html_e( 'Roles', 'woocommerce-wholesale-pro' );
						echo wc_help_tip( __( 'The shipping method is only available to users with the selected roles.', 'woocommerce-wholesale-pro' ) );
						?>
					</th>
				</tr>
			</thead>

			<tbody class="wcwp-shipping-role-rows">
				<?php
				foreach ( $shipping_object->get_shipping_methods() as $shipping_method ) :
					$has_settings = ! empty( $shipping_roles ) && isset( $shipping_roles[ $shipping_method->id ] ) && ! empty( $shipping_roles[ $shipping_method->id ] );
					?>
					<tr id="wcwp-shipping-role-<?php echo esc_attr( $shipping_method->id ); ?>">
						<td width="20%">
							<p class="wcwp-field-label">
								<strong><?php echo esc_html( $shipping_method->method_title ); ?></strong>
							</p>
						</td>
						<td>
							<p>
								<select
									name="wcwp_shipping_roles[<?php echo esc_attr( $shipping_method->id ); ?>][]"
									id="wcwp_shipping_select_<?php echo esc_attr( $shipping_method->id ); ?>"
									class="wcwp-role-multiselect"
									multiple="multiple"
									data-placeholder="<?php esc_attr_e( 'Select or search shipping methods&hellip;', 'woocommerce-wholesale-pro' ); ?>"
								>
									<?php
									foreach ( $filtered_roles as $role => $details ) :
										$name     = translate_user_role( $details['name'] );
										$selected = $has_settings ? in_array( $role, $shipping_roles[ $shipping_method->id ], true ) : true;
										?>
										<option value="<?php echo esc_attr( $role ); ?>"<?php selected( $selected ); ?>><?php echo esc_html( $name ); ?></option>
										<?php
									endforeach
									?>
								</select>
							</p>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}
}
