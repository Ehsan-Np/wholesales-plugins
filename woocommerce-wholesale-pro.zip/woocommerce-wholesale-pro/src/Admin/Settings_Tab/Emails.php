<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Settings_Tab;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

/**
 * Emails Setting Tab
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Emails implements Registerable, Standard_Service {
	private $id;

	/**
	 * Constructor.
	 *
	 * @param string $id
	 */
	public function __construct( $id ) {
		$this->id = $id;
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'woocommerce_admin_field_wcwp_email_notification', [ $this, 'setting_screen' ] );
	}

	/**
	 * Return the ID of the settings tab.
	 *
	 * @return string
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Retrieve the settings.
	 */
	public function get_settings() {
		$settings = [
			[
				'id'    => 'wholesale_pro_settings_start',
				'type'  => 'settings_start',
				'class' => 'wholesale-pro-settings email-settings barn2-plugins-settings'
			],

			[
				'name' => __( 'Email notifications', 'woocommerce-wholesale-pro' ),
				'desc' => __( 'Email notifications sent from WooCommerce Wholesale Pro are listed below. Click on an email to configure it.', 'woocommerce-wholesale-pro' ),
				'type' => 'title',
				'id'   => $this->id . 'email_settings',
			],

			[ 'type' => 'wcwp_email_notification' ],

			[
				'type' => 'sectionend',
				'id'   => $this->id . 'email_settings',
			],

			[
				'id'   => 'wholesale_pro_settings_end',
				'type' => 'settings_end'
			],
		];

		return $settings;
	}

	/**
	 * Output email notification settings.
	 */
	public function setting_screen() {
		global $hide_save_button;

		$hide_save_button = true;
		// Define emails that can be customised here.
		$mailer                    = WC()->mailer();
		$email_templates           = $mailer->get_emails();
		$wholesale_email_templates = array_filter(
			$email_templates,
			function ( $key ) {
				return \substr( $key, 0, 4 ) === 'WCWP';
			},
			ARRAY_FILTER_USE_KEY
		);

		?>
		<tr valign="top">
		<td class="wc_emails_wrapper" colspan="2">
			<table class="wc_emails widefat" cellspacing="0">
				<thead>
					<tr>
						<?php
						$columns = apply_filters(
							'woocommerce_email_setting_columns',
							[
								'status'     => '',
								'name'       => __( 'Email', 'woocommerce-wholesale-pro' ),
								'email_type' => __( 'Content type', 'woocommerce-wholesale-pro' ),
								'recipient'  => __( 'Recipient(s)', 'woocommerce-wholesale-pro' ),
								'actions'    => '',
							]
						);
						foreach ( $columns as $key => $column ) {
							echo '<th class="wc-email-settings-table-' . esc_attr( $key ) . '">' . esc_html( $column ) . '</th>';
						}
						?>
						</tr>
					</thead>
					<tbody>
						<?php

						foreach ( $wholesale_email_templates as $email_key => $email ) {
							echo '<tr>';

							$manage_url = add_query_arg(
								[
									'section'   => strtolower( $email_key ),
									'wholesale' => 'true'
								],
								admin_url( 'admin.php?page=wc-settings&tab=email' )
							);

							foreach ( $columns as $key => $column ) {

								switch ( $key ) {
									case 'name':
										echo '<td class="wc-email-settings-table-' . esc_attr( $key ) . '">
										<a href="' . esc_url( $manage_url ) . '">' . esc_html( $email->get_title() ) . '</a>
										' . wc_help_tip( $email->get_description() ) . '
									</td>';
										break;
									case 'recipient':
										echo '<td class="wc-email-settings-table-' . esc_attr( $key ) . '">
										' . esc_html( $email->is_customer_email() ? __( 'Customer', 'woocommerce-wholesale-pro' ) : $email->get_recipient() ) . '
									</td>';
										break;
									case 'status':
										echo '<td class="wc-email-settings-table-' . esc_attr( $key ) . '">';

										if ( $email->is_manual() ) {
											echo '<span class="status-manual tips" data-tip="' . esc_attr__( 'Manually sent', 'woocommerce-wholesale-pro' ) . '">' . esc_html__( 'Manual', 'woocommerce-wholesale-pro' ) . '</span>';
										} elseif ( $email->is_enabled() ) {
											echo '<span class="status-enabled tips" data-tip="' . esc_attr__( 'Enabled', 'woocommerce-wholesale-pro' ) . '">' . esc_html__( 'Yes', 'woocommerce-wholesale-pro' ) . '</span>';
										} else {
											echo '<span class="status-disabled tips" data-tip="' . esc_attr__( 'Disabled', 'woocommerce-wholesale-pro' ) . '">-</span>';
										}

										echo '</td>';
										break;
									case 'email_type':
										echo '<td class="wc-email-settings-table-' . esc_attr( $key ) . '">
											' . esc_html( $email->get_content_type() ) . '
										</td>';
										break;
									case 'actions':
										echo '<td class="wc-email-settings-table-' . esc_attr( $key ) . '">
											<a class="button alignright" href="' . esc_url( $manage_url ) . '">' . esc_html__( 'Manage', 'woocommerce-wholesale-pro' ) . '</a>
										</td>';
										break;
									default:
										do_action( 'woocommerce_email_setting_column_' . $key, $email );
										break;
								}
							}

							echo '</tr>';
						}
						?>
					</tbody>
				</table>
			</td>
		</tr>
		<?php
	}
}
