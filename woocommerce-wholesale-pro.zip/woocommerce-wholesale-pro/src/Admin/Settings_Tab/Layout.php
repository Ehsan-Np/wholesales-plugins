<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Settings_Tab;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Util as Lib_Util;
use Barn2\Plugin\WC_Product_Table\Util\Util as WPT_Util;

use function Barn2\Plugin\WC_Wholesale_Pro\woocommerce_wholesale_pro as wwp;

/**
 * Layout Setting Tab
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Layout implements Registerable, Standard_Service {
	private $id;

	/**
	 * Whether the WooCommerce Product Table plugin is installed.
	 *
	 * @var bool
	 */
	private $is_wpt_installed;

	/**
	 * Whether the WooCommerce Product Table plugin is active.
	 *
	 * @var bool
	 */
	private $is_wpt_active;

	/**
	 * Constructor.
	 *
	 * @param string $id
	 */
	public function __construct( $id ) {
		$this->id = $id;

		$this->is_wpt_installed = Lib_Util::is_plugin_installed( 'woocommerce-product-table.php' );
		$this->is_wpt_active    = Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Product_Table\wpt' );

		if ( $this->is_wpt_installed && ! $this->is_wpt_active ) {
			$action  = filter_input( INPUT_GET, 'action' );
			$wpnonce = filter_input( INPUT_GET, '_wpnonce' );

			if ( $action === 'activate-wpt' && wp_verify_nonce( $wpnonce, 'activate-wpt' ) ) {
				activate_plugin( 'woocommerce-product-table/woocommerce-product-table.php' );
				wp_safe_redirect( admin_url( 'admin.php?page=wc-settings&tab=wholesale-pro&section=layout' ) );
			}
		}
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'woocommerce_admin_field_wcwp_product_table_promotion', [ $this, 'custom_product_table_promotion' ] );
		add_action( 'woocommerce_admin_field_wcwp_product_table_activation_button', [ $this, 'custom_product_table_activation_button' ] );
	}

	/**
	 * Return the ID of the settings tab.
	 *
	 * @return string
	 */
	public function get_id() {
		return $this->id;
	}

	/**
	 * Retrieves the settings.
	 *
	 * @return array
	 */
	public function get_settings() {
		$disabled_dropdowns = null;

		if ( ! $this->is_wpt_active ) {
			global $hide_save_button;
			$hide_save_button        = true;
			$disabled_dropdowns      = [ 'disabled' => 'disabled' ];
			$conditional_description = '';
		}

		if ( $this->is_wpt_installed ) {
			if ( $this->is_wpt_active ) {
				if ( class_exists( 'Barn2\Plugin\WC_Product_Table\Admin\Settings_Tab\Tables' ) ) {
					$product_table_settings_url = get_admin_url( null, 'edit.php?post_type=product&page=tables' );
				} else {
					$product_table_settings_url = get_admin_url( null, 'admin.php?page=wc-settings&tab=products&section=product-table' );
				}
				$conditional_description    = sprintf(
					// translators: %s: WooCommerce Product Table settings page URL.
					__( 'You can configure your order forms on the <a href="%s">WooCommerce Product Table settings page</a>.','woocommerce-wholesale-pro' ),
					$product_table_settings_url
				);
			} else {
				$conditional_description = __( 'Click the button below to activate the plugin and use the order form layout.','woocommerce-wholesale-pro' );
			}

			$settings = [
				[
					'id'    => 'wholesale_pro_settings_start',
					'type'  => 'settings_start',
					'class' => 'wholesale-pro-settings barn2-plugins-settings'
				],
				[
					'name' => __( 'Wholesale layout', 'woocommerce-wholesale-pro' ),
					'type' => 'title',
					'desc' => sprintf(
						/* translators: %s: WooCommerce Product Table settings page URL. */
						__( 'The wholesale area can list products using the default layout provided by your theme, or the order form layout provided by the WooCommerce Product Table plugin. %s', 'woocommerce-wholesale-pro' ),
						$conditional_description
					),
					'id'   => $this->id . 'layout_settings',
				],
				[ 'type' => 'wcwp_product_table_activation_button' ],
				[
					'title'             => __( 'Wholesale store page', 'woocommerce-wholesale-pro' ),
					'id'                => 'wcwp_layout_store_page',
					'type'              => 'select',
					'default'           => 'default',
					'css'               => 'min-width:300px;',
					'options'           => [
						'default'       => __( 'Default layout', 'woocommerce-wholesale-pro' ),
						'product_table' => __( 'Order form layout', 'woocommerce-wholesale-pro' ),
					],
					'autoload'          => true,
					'custom_attributes' => $disabled_dropdowns,
				],
				[
					'title'             => __( 'Wholesale product category and tag pages', 'woocommerce-wholesale-pro' ),
					'id'                => 'wcwp_layout_taxonomy_pages',
					'type'              => 'select',
					'default'           => 'default',
					'css'               => 'min-width:300px;',
					'options'           => [
						'default'       => __( 'Default layout', 'woocommerce-wholesale-pro' ),
						'product_table' => __( 'Order form layout', 'woocommerce-wholesale-pro' ),
					],
					'autoload'          => true,
					'custom_attributes' => $disabled_dropdowns,
				],
				[
					'type' => 'sectionend',
					'id'   => $this->id . 'layout_settings',
				],
			];

			if ( method_exists( 'Barn2\Plugin\WC_Product_Table\Util\Util', 'get_shop_templates_tables' ) ) {
				$tables = WPT_Util::get_shop_templates_tables();
				$settings[3]['desc'] = isset( $tables[ 'wholesale_store_override' ] ) && $tables[ 'wholesale_store_override' ]['id'] && get_option( 'wcwp_layout_store_page', 'default' ) === 'product_table' ? __( 'Configure your <a href="' . $product_table_settings_url . '#/edit/' . $tables[ 'wholesale_store_override' ]['id']  . '">order form layout</a>.', 'woocommerce-wholesale-pro' ) : '';
				$settings[4]['desc'] = isset( $tables[ 'wholesale_store_override' ] ) && $tables[ 'wholesale_store_override' ]['id'] && get_option( 'wcwp_layout_taxonomy_pages', 'default' ) === 'product_table' ? __( 'Configure your <a href="' . $product_table_settings_url . '#/edit/' . $tables[ 'wholesale_store_override' ]['id']  . '">order form layout</a>.', 'woocommerce-wholesale-pro' ) : '';
			}

		} else {
			$product_table_barn2_link = Lib_Util::barn2_link(
				'wordpress-plugins/woocommerce-product-table/?utm_source=plugin&utm_medium=settings&utm_campaign=wholesale&utm_content=wholesalelayout',
				__( 'WooCommerce Product Table', 'woocommerce-wholesale-pro' ),
				true
			);

			$description = sprintf(
				/* translators: %s: WooCommerce Product Table site link */
				__( 'Your wholesale area will use the same layout as the rest of your store. This is provided by your theme. We recommend installing the %s plugin, which replaces the default layout with quick order forms to speed up shopping for your wholesale users.', 'woocommerce-wholesale-pro' ),
				$product_table_barn2_link
			);

			$settings = [
				[
					'id'    => 'wholesale_pro_settings_start',
					'type'  => 'settings_start',
					'class' => 'wholesale-pro-settings wpt-promo barn2-plugins-settings'
				],
				[
					'name' => __( 'Wholesale layout', 'woocommerce-wholesale-pro' ),
					'type' => 'title',
					'desc' => $description,
					'id'   => $this->id . 'layout_settings',
				],
				[ 'type' => 'wcwp_product_table_promotion' ],
				[
					'type' => 'sectionend',
					'id'   => $this->id . 'layout_settings',
				],
			];
		}

		$settings[] = [
			'id'   => 'wholesale_pro_settings_end',
			'type' => 'settings_end',
		];

		return $settings;
	}

	/**
	 * Renders a custom button to promote the Product Table plugin
	 */
	public function custom_product_table_promotion() {
		if ( ! $this->is_wpt_active && ! $this->is_wpt_installed ) {
			$promo_link   = Lib_Util::barn2_url( 'wordpress-plugins/woocommerce-product-table/?utm_source=plugin&utm_medium=settings&utm_campaign=wholesale&utm_content=wholesalelayout' );
			$button_label = esc_html__( 'Get WooCommerce Product Table', 'woocommerce-wholesale-pro' );
			$image        = '<img width="488" src="' . esc_url( plugin_dir_url( wwp()->get_file() ) . 'assets/images/wpt_promo.png' ) . '" alt="' . esc_attr__( 'WooCommerce Product Table', 'woocommerce-wholesale-pro' ) . '">';

			// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped
			printf( '<p><a class="button secondary" href="%s" target="_blank">%s</a></p>', $promo_link, $button_label );
			printf( '<p><a href="%s" target="_blank">%s</a></p>', $promo_link, $image );
			// phpcs:enable
		}
	}

	/**
	 * Renders a custom button to activate the Product Table plugin
	 */
	public function custom_product_table_activation_button() {
		if ( ! $this->is_wpt_active && $this->is_wpt_installed ) {
			$button_link  = wp_nonce_url( admin_url( 'admin.php?page=wc-settings&tab=wholesale-pro&section=layout&action=activate-wpt' ), 'activate-wpt' );
			$button_label = esc_html__( 'Activate WooCommerce Product Table', 'woocommerce-wholesale-pro' );

			?>
					<tr valign="top">
						<th colspan="2" class="titledesc" style="font-size: 13px; font-weight:normal;">
							<a class="button secondary" href="<?php echo esc_url( $button_link ); ?>">
								<?php echo esc_html( $button_label ); ?>
							</a>
						</th>
					</tr>
				<tbody>
			</table>
			<table class="form-table">
				<tbody>
			<?php
		}
	}
}
