<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Wizard;

use Barn2\Plugin\WC_Wholesale_Pro\Admin\Wizard\Steps;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Setup_Wizard\Setup_Wizard as Wizard;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Setup_Wizard\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Plugin\License\EDD_Licensing;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Plugin\License\Plugin_License;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Plugin\Licensed_Plugin;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Util as Lib_Util;

/**
 * Main Setup Wizard Loader
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Setup_Wizard implements Registerable, Standard_Service {

	private $plugin;
	private $wizard;

	/**
	 * Constructor.
	 *
	 * @param Licensed_Plugin $plugin
	 */
	public function __construct( Licensed_Plugin $plugin ) {

		$this->plugin = $plugin;

		$steps = [
			new Steps\License_Verification(),
			new Steps\General(),
			new Steps\Roles(),
			new Steps\Layout(),
			new Steps\Upsell(),
			new Steps\Completed(),
		];

		$this->wizard = new Wizard( $this->plugin, $steps );
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		$this->wizard->configure(
			[
				'skip_url'        => admin_url( 'admin.php?page=wc-settings&tab=wholesale-pro' ),
				'admin_url'       => admin_url(),
				'license_tooltip' => esc_html__( 'The licence key is contained in your order confirmation email.', 'woocommerce-wholesale-pro' ),
				'wpt_active'      => Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Product_Table\wpt' ),
				'utm_id'          => 'wwp',
				'signpost'        => [
					[
						'title' => __( 'Manage wholesale users and roles', 'woocommerce-wholesale-pro' ),
						'href'  => admin_url( 'admin.php?page=wc-settings&tab=wholesale-pro&section=roles' ),
					],
					[
						'title' => __( 'Manage category visibility and pricing', 'woocommerce-wholesale-pro' ),
						'href'  => admin_url( 'edit-tags.php?taxonomy=product_cat&post_type=product' ),
					],
					[
						'title' => __( 'Set wholesale prices per product', 'woocommerce-wholesale-pro' ),
						'href'  => admin_url( 'edit.php?post_type=product' ),
					],
					[
						'title' => __( 'Go to settings page', 'woocommerce-wholesale-pro' ),
						'href'  => admin_url( 'admin.php?page=wc-settings&tab=wholesale-pro' ),
					],
				],
			]
		);

		$this->wizard->add_edd_api( EDD_Licensing::class );
		$this->wizard->add_license_class( Plugin_License::class );
		$this->wizard->add_restart_link( 'wholesale-pro', 'wholesale-progeneral_settings' );

		$this->wizard->add_custom_asset(
			$this->plugin->get_dir_url() . 'assets/js/admin/wizard.js',
			Util::get_script_dependencies( $this->plugin, './assets/js/admin/wizard.js' )
		);

		$this->wizard->boot();
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_additional_scripts' ], 21 );
	}

	/**
	 * Enqueue additional scripts for the setup wizard.
	 *
	 * @param string $hook_suffix The current admin page hook suffix.
	 * @return void
	 */
	public function enqueue_additional_scripts( $hook_suffix ) {
		if ( 'toplevel_page_' . $this->wizard->get_slug() !== $hook_suffix ) {
			return;
		}

		wp_enqueue_style( 'wcwp-setup-wizard-addons', $this->plugin->get_dir_url() . 'assets/css/admin/wcwp-wizard.css', [ $this->wizard->get_slug() ], $this->plugin->get_version() );
	}
}
