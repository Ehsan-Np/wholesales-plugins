<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Wizard\Steps;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Setup_Wizard\Steps\Welcome;

/**
 * Welcome / License Step.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class License_Verification extends Welcome {

	/**
	 * {@inheritdoc}
	 */
	public function init() {
		parent::init();
		$this->set_title( 'Welcome to WooCommerce Wholesale Pro' );
		$this->set_name( esc_html__( 'Welcome', 'woocommerce-wholesale-pro' ) );
		$this->set_description( esc_html__( 'Start selling to wholesale customers in no time.', 'woocommerce-wholesale-pro' ) );
		$this->set_tooltip( esc_html__( 'Use this setup wizard to quickly configure the most popular options for your wholesale area. You can change these options later on the plugin settings page or by relaunching the setup wizard.', 'woocommerce-wholesale-pro' ) );
	}
}
