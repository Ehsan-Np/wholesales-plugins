<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Wizard\Steps;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Setup_Wizard\Api;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Setup_Wizard\Step;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Util as Lib_Util;
use Barn2\Plugin\WC_Product_Table\Integration\WooCommerce_Wholesale_Pro as WPT_WooCommerce_Wholesale_Pro;

/**
 * Layout Step.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Layout extends Step {

	/**
	 * {@inheritdoc}
	 */
	public function init() {
		$this->set_id( 'layout' );
		$this->set_name( esc_html__( 'Wholesale store layout', 'woocommerce-wholesale-pro' ) );
		$this->set_description( esc_html__( 'Choose the layout for your wholesale store.', 'woocommerce-wholesale-pro' ) );
		$this->set_title( esc_html__( 'Wholesale store layout', 'woocommerce-wholesale-pro' ) );
	}

	/**
	 * {@inheritdoc}
	 */
	public function setup_fields() {
		if ( Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Product_Table\wpt' ) ) {
			$fields = [
				'wpt_layout_intro'           => [
					'type'  => 'heading',
					'size'  => 'div',
					'label' => __( 'The wholesale area can list products using the default layout provided by your theme, or the order form layout provided by the WooCommerce Product Table plugin. You can configure your order forms in the WooCommerce Product Table setup wizard.', 'woocommerce-wholesale-pro' ),
					'style' => [
						'textAlign'  => 'center',
						'paddingTop' => '15px',
					],
				],
				'wcwp_layout_store_page'     => [
					'label'   => __( 'Wholesale store page', 'woocommerce-wholesale-pro' ),
					'type'    => 'select',
					'options' => [
						[
							'value' => 'default',
							'label' => __( 'Default layout', 'woocommerce-wholesale-pro' ),
						],
						[
							'value' => 'product_table',
							'label' => __( 'Order form layout', 'woocommerce-wholesale-pro' ),
						],
					],
					'value'   => get_option( 'wcwp_layout_store_page', 'default' ),
				],
				'wcwp_layout_taxonomy_pages' => [
					'label'   => __( 'Wholesale product category and tag pages', 'woocommerce-wholesale-pro' ),
					'type'    => 'select',
					'options' => [
						[
							'value' => 'default',
							'label' => __( 'Default layout', 'woocommerce-wholesale-pro' ),
						],
						[
							'value' => 'product_table',
							'label' => __( 'Order form layout', 'woocommerce-wholesale-pro' ),
						],
					],
					'value'   => get_option( 'wcwp_layout_taxonomy_pages', 'default' ),
				],

			];
		} else {
			$fields = [
				'wpt_promo_text'  => [
					'type'  => 'heading',
					'size'  => 'div',
					'label' => sprintf(
						/* translators: %s: WooCommerce Product Table store link */
						__( 'The products in the wholesale area will be displayed using the default layout from your theme. For an optimized wholesale order form, we recommend installing the %s plugin.', 'woocommerce-wholesale-pro' ),
						Lib_Util::barn2_link( 'wordpress-plugins/woocommerce-product-table/', __( 'WooCommerce Product Table', 'woocommerce-wholesale-pro' ), true )
					),
					'style' => [
						'textAlign'  => 'center',
						'paddingTop' => '15px',
					],
				],

				'wpt_promo_image' => [
					'type' => 'image',
					'src'  => $this->get_plugin()->get_dir_url() . 'assets/images/wpt_promo.png',
					'alt'  => __( 'WooCommerce Product Table Image', 'woocommerce-wholesale-pro' ),
				],

			];
		}

		return $fields;
	}

	/**
	 * {@inheritdoc}
	 */
	public function submit( array $values ) {

		$store_layout = isset( $values['wcwp_layout_store_page'] ) && ! empty( $values['wcwp_layout_store_page'] ) ? $values['wcwp_layout_store_page'] : false;
		$tax_layout   = isset( $values['wcwp_layout_taxonomy_pages'] ) && ! empty( $values['wcwp_layout_taxonomy_pages'] ) ? $values['wcwp_layout_taxonomy_pages'] : false;

		if ( $store_layout ) {
			update_option( 'wcwp_layout_store_page', $store_layout );
		}

		if ( $tax_layout ) {
			update_option( 'wcwp_layout_taxonomy_pages', $tax_layout );
		}

		if ( Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Product_Table\wpt' ) ) {
			if ( $store_layout === 'default' && $tax_layout === 'default' ) {
				WPT_WooCommerce_Wholesale_Pro::maybe_remove_wholesale_table();
			} elseif ( $store_layout === 'product_table' || $tax_layout === 'product_table' ) {
				WPT_WooCommerce_Wholesale_Pro::maybe_create_wholesale_table();
			}
		}

		return Api::send_success_response();
	}
}
