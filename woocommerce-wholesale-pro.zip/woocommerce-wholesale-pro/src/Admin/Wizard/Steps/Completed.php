<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Wizard\Steps;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Setup_Wizard\Steps\Ready;

/**
 * Completed Step.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Completed extends Ready {
	/**
	 * {@inheritdoc}
	 */
	public function init() {
		parent::init();
		$this->set_description( esc_html__( 'Congratulations, your wholesale store is now set up! As soon as you start adding users to the wholesale role, they will be directed to the wholesale area and given the global wholesale discount, if you set one.', 'woocommerce-wholesale-pro' ) );
	}
}
