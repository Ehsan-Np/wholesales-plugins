<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Wizard\Steps;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Setup_Wizard\Api;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Setup_Wizard\Step;

/**
 * General Step.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class General extends Step {

	/**
	 * {@inheritdoc}
	 */
	public function init() {
		$this->set_id( 'store-settings' );
		$this->set_name( esc_html__( 'Settings', 'woocommerce-wholesale-pro' ) );
		$this->set_description( esc_html__( 'First, choose the overall settings for the wholesale store.', 'woocommerce-wholesale-pro' ) );
		$this->set_title( esc_html__( 'Wholesale store settings', 'woocommerce-wholesale-pro' ) );
	}

	/**
	 * {@inheritdoc}
	 */
	public function setup_fields() {

		$fields = [
			'wcwp_enable_registration'    => [
				'title'       => __( 'Wholesale registration', 'woocommerce-wholesale-pro' ),
				'label'       => __( 'Display registration form on the wholesale login page.', 'woocommerce-wholesale-pro' ),
				'description' => __( 'If disabled, you can still use the [wholesale_registration] shortcode to display a registration form elsewhere.', 'woocommerce-wholesale-pro' ),
				'value'       => get_option( 'wcwp_enable_registration' ) === 'yes',
				'type'        => 'checkbox',
			],
			'wcwp_moderate_registrations' => [
				'title' => __( 'Moderate new registrations', 'woocommerce-wholesale-pro' ),
				'label' => __( 'Hold new wholesale registrations for moderation by an administrator.', 'woocommerce-wholesale-pro' ),
				'value' => get_option( 'wcwp_moderate_registrations' ) === 'yes',
				'type'  => 'checkbox',
			],
			'wcwp_disable_tax'            => [
				'title'       => __( 'Disable tax', 'woocommerce-wholesale-pro' ),
				'label'       => __( 'Do not charge tax to wholesale users.', 'woocommerce-wholesale-pro' ),
				'description' => __( 'Displays prices without tax and disables tax for logged in wholesale users. You can override this for specific roles.', 'woocommerce-wholesale-pro' ),
				'value'       => get_option( 'wcwp_disable_tax' ) === 'yes',
				'type'        => 'checkbox',
			],
		];

		return $fields;
	}

	/**
	 * {@inheritdoc}
	 */
	public function submit( array $values ) {

		$enable_registration = isset( $values['wcwp_enable_registration'] ) && ! empty( $values['wcwp_enable_registration'] )
			? $this->bool_to_wc_checkbox_string( $values['wcwp_enable_registration'] ) : 'no';

		$moderate_registrations = isset( $values['wcwp_moderate_registrations'] ) && ! empty( $values['wcwp_moderate_registrations'] )
			? $this->bool_to_wc_checkbox_string( $values['wcwp_moderate_registrations'] ) : 'no';

		$disable_tax = isset( $values['wcwp_disable_tax'] ) && ! empty( $values['wcwp_disable_tax'] )
			? $this->bool_to_wc_checkbox_string( $values['wcwp_disable_tax'] ) : 'no';

		if ( $enable_registration ) {
			update_option( 'wcwp_enable_registration', $enable_registration );
		}

		if ( $moderate_registrations ) {
			update_option( 'wcwp_moderate_registrations', $moderate_registrations );
		}

		if ( $disable_tax ) {
			update_option( 'wcwp_disable_tax', $disable_tax );
		}

		return Api::send_success_response();

	}

	/**
	 * Converts bool to 'yes' or 'no'
	 *
	 * @param mixed $value
	 * @return string
	 */
	private function bool_to_wc_checkbox_string( $value ) {
		return empty( $value ) || $value === 'false' || $value === false ? 'no' : 'yes';
	}
}
