<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Wizard\Steps;

use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Role;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Setup_Wizard\Api;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Setup_Wizard\Step;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Exception;

/**
 * Roles Step.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Roles extends Step {

	/**
	 * {@inheritdoc}
	 */
	public function init() {
		$this->set_id( 'role-settings' );
		$this->set_name( esc_html__( 'Roles', 'woocommerce-wholesale-pro' ) );
		$this->set_description( esc_html__( 'We’ve already created a wholesale user role for you. If you like, then you can set a global discount for your wholesale users here. You can add users to this role and create additional wholesale roles later.', 'woocommerce-wholesale-pro' ) );
		$this->set_title( esc_html__( 'Roles', 'woocommerce-wholesale-pro' ) );
	}

	/**
	 * {@inheritdoc}
	 */
	public function setup_fields() {

		$fields = [
			'wholesale_role_global_discount' => [
				'label'       => __( 'Global discount', 'woocommerce-wholesale-pro' ),
				'description' => __( 'The percentage discount for all your wholesale products. (You can override this for individual products or categories later.)', 'woocommerce-wholesale-pro' ),
				'value'       => $this->get_default_role_global_discount(),
				'type'        => 'number',
				'min'         => 0,
				'max'         => 100,
				'step'        => 0.01,
			],
		];

		return $fields;
	}

	/**
	 * {@inheritdoc}
	 */
	public function submit( array $values ) {

		$global_discount = isset( $values['wholesale_role_global_discount'] ) && ! empty( $values['wholesale_role_global_discount'] ) ? $values['wholesale_role_global_discount'] : false;

		if ( ! $global_discount ) {
			return Api::send_success_response();
		}

		if ( ! is_numeric( $global_discount ) || (float) $global_discount > 100 || (float) $global_discount <= 0 ) {
			return Api::send_error_response(
				[
					'message' => esc_html__( 'Please enter a global discount value from 0.01 to 100.', 'woocommerce-wholesale-pro' )
				]
			);
		}

		try {
			$role = new Wholesale_Role( Util::get_default_role() );
			$role->update( [ 'global_discount' => $global_discount ] );
		} catch ( Exception $e ) {
			return Api::send_error_response(
				[
					'message' => esc_html__( 'Could not update global discount.', 'woocommerce-wholesale-pro' )
				]
			);
		}

		return Api::send_success_response();
	}

	/**
	 * Retrieves the current global discount for the default role.
	 *
	 * @return int|string
	 */
	private function get_default_role_global_discount() {
		try {
			$role = new Wholesale_Role( Util::get_default_role() );
			return $role->get_global_discount();
		} catch ( Exception $e ) {
			return '';
		}
	}
}
