<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Plugin;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Util as Lib_Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Plugin\Admin\Admin_Links;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Service_Container;

use Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController;

/**
 * General Admin Functions
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Admin implements Registerable, Standard_Service {
	use Service_Container;

	private $plugin;

	/**
	 * Constructor.
	 *
	 * @param Plugin $plugin
	 */
	public function __construct( Plugin $plugin ) {
		$this->plugin = $plugin;
	}

	/**
	 * Add services.
	 */
	public function add_services() {
		$this->add_service( 'admin_links', new Admin_Links( $this->plugin ) );
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		$this->register_services();
		$this->start_all_services();

		// Add settings page.
		add_filter( 'woocommerce_get_settings_pages', [ $this, 'add_settings_page' ], 20 );

		// Load admin scripts.
		add_action( 'admin_enqueue_scripts', [ $this, 'register_scripts' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );

		add_filter( 'wp_redirect', [ $this, 'redirect_after_user_new' ] );
	}

	/**
	 * Add the settings page to EDD.
	 *
	 * @param array $settings
	 * @return array $settings
	 */
	public function add_settings_page( $settings ) {
		$settings_page = new Settings_Page( $this->plugin );
		$settings_page->register();

		$settings[] = $settings_page;

		return $settings;
	}

	/**
	 * Register the admin assets.
	 *
	 * @param string $hook
	 */
	public function register_scripts( $hook ) {
		wp_register_style( 'wcwp-admin-wc-settings', $this->plugin->get_dir_url( 'assets/css/admin/wcwp-admin-wc-settings.css' ), [], $this->plugin->get_version() );
		$this->plugin->register_script( 'wcwp-admin-wc-settings', 'assets/js/admin/wcwp-admin-wc-settings.js', [ 'jquery' ] );
		$this->plugin->register_script( 'wcwp-admin-role-edit', 'assets/js/admin/wcwp-admin-role-edit.js', [ 'jquery' ] );
		$this->plugin->register_script( 'wcwp-admin-role-sorting', 'assets/js/admin/wcwp-admin-role-sorting.js', [ 'jquery-ui-sortable' ] );
		$this->plugin->register_script( 'wcwp-admin-field-sorting', 'assets/js/admin/wcwp-admin-registration-fields.js', [ 'jquery-ui-sortable' ] );

		wp_register_style( 'wcwp-admin-shipping-payment-css', plugins_url( 'assets/css/admin/wcwp-admin-wc-settings-shipping-payment.css', $this->plugin->get_file() ), [], $this->plugin->get_version() );
		$this->plugin->register_script( 'wcwp-admin-shipping-payment', 'assets/js/admin/wcwp-admin-shipping-payment-roles.js', [ 'selectWoo' ] );

		$this->plugin->register_script( 'wcwp-admin-new-user', 'assets/js/admin/wcwp-admin-new-user.js', [ 'jquery' ] );

		wp_register_style( 'wcwp-admin-edit-user', plugins_url( 'assets/css/admin/wcwp-admin-edit-user.css', $this->plugin->get_file() ), [], $this->plugin->get_version() );
		$this->plugin->register_script( 'wcwp-admin-edit-user', 'assets/js/admin/wcwp-admin-edit-user.js', [ 'jquery' ] );

		wp_register_style( 'wcwp-admin-user-list', plugins_url( 'assets/css/admin/wcwp-admin-user-list.css', $this->plugin->get_file() ), [], $this->plugin->get_version() );

		wp_register_style( 'wcwp-admin-product-list', plugins_url( 'assets/css/admin/wcwp-admin-product-list.css', $this->plugin->get_file() ), [], $this->plugin->get_version() );

		wp_register_style( 'wcwp-admin-product-category', plugins_url( 'assets/css/admin/wcwp-admin-product-category.css', $this->plugin->get_file() ), [], $this->plugin->get_version() );
		$this->plugin->register_script( 'wcwp-admin-product-category', 'assets/js/admin/wcwp-admin-product-category.js', [ 'jquery' ] );

		wp_register_style( 'wcwp-admin-order', plugins_url( 'assets/css/admin/wcwp-admin-orders.css', $this->plugin->get_file() ), [], $this->plugin->get_version() );
		$this->plugin->register_script( 'wcwp-meta-boxes-order', 'assets/js/admin/wcwp-meta-boxes-order.js', [ 'jquery' ] );

		$this->plugin->register_script( 'wcwp-admin-edit-product', 'assets/js/admin/wcwp-admin-edit-product.js', [ 'jquery', 'wp-i18n', 'woocommerce_admin' ] );
		$this->plugin->register_script( 'wcwp-admin-product-list', 'assets/js/admin/wcwp-admin-product-list.js', [ 'jquery' ] );
	}

	/**
	 * Enqueue the admin assets.
	 *
	 * @param string $hook
	 */
	public function enqueue_scripts( $hook ) {
		$tab     = filter_input( INPUT_GET, 'tab', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
		$section = filter_input( INPUT_GET, 'section', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		// WooCommerce Settings
		if ( 'woocommerce_page_wc-settings' === $hook && $tab === 'wholesale-pro' ) {
			wp_enqueue_style( 'wcwp-admin-wc-settings' );
			wp_enqueue_script( 'wcwp-admin-wc-settings' );

			// role sorting
			if ( $section === 'roles' ) {
				$role_name = filter_input( INPUT_GET, 'role_name', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

				if ( $role_name ) {
					wp_enqueue_script( 'wcwp-admin-role-edit' );
				} else {
					wp_enqueue_script( 'wcwp-admin-role-sorting' );

					Util::add_inline_script_params(
						'wcwp-admin-role-sorting',
						'wcwp_role_sorting_object',
						[
							'ajax_url' => admin_url( 'admin-ajax.php' ),
							'security' => wp_create_nonce( 'wcwp-role-sorting' ),
						]
					);
				}
			}

			// registration fields
			if ( $section === 'fields' ) {
				wp_enqueue_script( 'wcwp-admin-field-sorting' );

				Util::add_inline_script_params(
					'wcwp-admin-field-sorting',
					'wcwp_field_sorting_object',
					[
						'ajax_url' => admin_url( 'admin-ajax.php' ),
						'security' => wp_create_nonce( 'wcwp-field-sorting' ),
					]
				);
			}
		}

		// shipping restriction
		if ( 'woocommerce_page_wc-settings' === $hook && $tab === 'wholesale-pro' && $section === 'shipping-roles' ) {
			wp_enqueue_style( 'wcwp-admin-shipping-payment-css' );
			wp_enqueue_script( 'wcwp-admin-shipping-payment' );
		}

		// shipping restriction
		if ( 'woocommerce_page_wc-settings' === $hook && $tab === 'wholesale-pro' && $section === 'payment-roles' ) {
			wp_enqueue_style( 'wcwp-admin-shipping-payment-css' );
			wp_enqueue_script( 'wcwp-admin-shipping-payment' );
		}

		// Add New User
		if ( 'user-new.php' === $hook ) {
			wp_enqueue_script( 'wcwp-admin-new-user' );

			$wholesale_roles   = Util::get_wholesale_roles();
			$wholesale_role    = filter_input( INPUT_GET, 'wholesale', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
			$wholesale_add_new = in_array( $wholesale_role, $wholesale_roles, true ) ? $wholesale_role : 'no';

			wp_localize_script(
				'wcwp-admin-new-user',
				'wcwp_admin_object',
				[
					'wholesale_roles'   => $wholesale_roles,
					'wholesale_add_new' => $wholesale_add_new,
					'password_notice'   => __( 'A link to set a new password will be included in the email to the new user.', 'woocommerce-wholesale-pro' ),
				]
			);
		}

		// Edit User
		$user_id = filter_input( INPUT_GET, 'wholesale', FILTER_SANITIZE_NUMBER_INT );

		if ( 'user-edit.php' === $hook && $user_id && Util::is_moderation_required( $user_id ) ) {
			wp_enqueue_style( 'wcwp-admin-edit-user' );
			wp_enqueue_script( 'wcwp-admin-edit-user' );

			wp_localize_script(
				'wcwp-admin-edit-user',
				'wcwp_admin_object',
				[
					'wholesale_roles' => Util::get_wholesale_roles(),
					'role_notice'     => __( '<span class="wcwp-warning">Warning!</span> This role does not have access to the wholesale store. Do you wish to <span class="wcwp-continue">Continue</span> or <span class="wcwp-cancel">Cancel</span>?', 'woocommerce-wholesale-pro' ),
				]
			);
		}

		// Users List
		if ( 'users.php' === $hook ) {
			wp_enqueue_style( 'wcwp-admin-user-list' );
		}

		// Add / Edit Product Category
		$screen = get_current_screen();
		if ( $screen && 'product_cat' === $screen->taxonomy ) {
			wp_enqueue_style( 'wcwp-admin-product-category' );

			if ( Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Protected_Categories\wpc' ) ) {
				wp_enqueue_script( 'wcwp-admin-product-category' );
			}
		}

		// Products List
		$screen = get_current_screen();
		if ( $screen && 'edit' === $screen->base && 'product' === $screen->post_type ) {
			wp_enqueue_style( 'wcwp-admin-product-list' );
			wp_enqueue_script( 'wcwp-admin-product-list' );
		}

		// Orders list
		$screen    = get_current_screen();
		$screen_id = $screen->post_type;

		if ( class_exists( '\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController' ) ) {
			if ( wc_get_container()->get( CustomOrdersTableController::class )->custom_orders_table_usage_is_enabled() ) {
				$screen_id = wc_get_page_screen_id( 'shop-order' );
			}
		}

		if ( $screen_id === 'woocommerce_page_wc-orders' || ( $screen->base === 'edit' && $screen_id === 'shop_order' ) ) {
			wp_enqueue_style( 'wcwp-admin-order' );
		}

		// Add orders
		if ( $screen_id === 'woocommerce_page_wc-orders' || ( $screen->base === 'post' && $screen_id === 'shop_order' ) ) {
			wp_enqueue_script( 'wcwp-meta-boxes-order' );
		}

		// Edit products
		if ( 'post' === $screen->base && $screen->post_type === 'product' ) {
			wp_enqueue_script( 'wcwp-admin-edit-product' );
		}
	}

	/**
	 * Filter the URL for the redirection after a new user is added.
	 *
	 * This filter works only in the contest of a new user
	 * being added from the Roles section of the Wholesale Pro settings page.
	 *
	 * @param string $location
	 * @return string
	 */
	public function redirect_after_user_new( $location ) {
		global $pagenow;

		if ( is_admin() && 'user-new.php' === $pagenow ) {
			parse_str( wp_parse_url( $location, PHP_URL_QUERY ), $query );

			if ( Util::is_wholesale_user( $query['id'] ?? 0 ) ) {
				return add_query_arg( [ 'section' => 'roles' ], $this->plugin->get_settings_page_url() );
			}
		}

		return $location;
	}
}
