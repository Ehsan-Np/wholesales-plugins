<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use WC_Order;

/**
 * Handles functionality on the Orders list table screen
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Order_List implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		// Add wholesale column to the HPOS orders list table.
		add_filter( 'manage_woocommerce_page_wc-orders_columns', [ $this, 'add_wholesale_column' ], 11 );
		add_action( 'manage_woocommerce_page_wc-orders_custom_column', [ $this, 'render_wholesale_column' ], 10, 2 );

		// Add wholesale column to the WC orders list table.
		add_filter( 'manage_shop_order_posts_columns', [ $this, 'add_wholesale_column' ], 11 );
		add_action( 'manage_shop_order_posts_custom_column', [ $this, 'render_wholesale_column' ], 10, 2 );

		add_action( 'restrict_manage_posts', [ $this, 'render_wholesale_filter' ], 11 );
		add_action( 'woocommerce_order_list_table_restrict_manage_orders', [ $this, 'render_wholesale_filter' ], 9 );
		add_filter( 'request', [ $this, 'order_query' ] );
		add_filter( 'woocommerce_order_list_table_prepare_items_query_args', [ $this, 'order_query' ] );
	}

	/**
	 * Add the Wholesale/Retail column to the Orders list table
	 *
	 * @param  array $columns An array of columns
	 * @return array          The modified array
	 */
	public function add_wholesale_column( $columns ) {
		$order_status_index = array_search( 'order_status', array_keys( $columns ), true );

		$head = array_splice( $columns, 0, $order_status_index + 1 );
		$tail = $columns;

		$columns = array_merge(
			$head,
			[
				'wholesale' => __( 'Customer Type', 'woocommerce-wholesale-pro' ),
			],
			$tail
		);

		return $columns;
	}

	public function render_wholesale_column( $column, $post_id ) {
		if ( 'wholesale' === $column ) {
			$order = wc_get_order( $post_id );

			/**
			 * Filter the label used in the wholesale/retail column of the orders list table.
			 *
			 * This filter allows third-party developers to change the label
			 * displayed in the Wholesale/Retail column of the orders list table
			 * based on any properties of the order object.
			 *
			 * @param string $wholesale The label for the order type.
			 *                          Defaults to 'Retail' or 'Wholesale' depending
			 *                          on the `_wholesale` meta value.
			 * @param WC_Order $order   The order object.
			 */
			$wholesale = apply_filters(
				'wcwp_orders_list_wholesale_column_label',
				$order->get_meta( '_wholesale' ) ? __( 'Wholesale', 'woocommerce-wholesale-pro' ) : __( 'Retail', 'woocommerce-wholesale-pro' ),
				$order
			);

			printf( '<mark class="order-type %s"><span>%s</span></mark>', esc_attr( 'type-' . sanitize_title( $wholesale ) ), esc_html( $wholesale ) );
		}
	}

	/**
	 * Render the wholesale selectbox to filter orders
	 *
	 * @param $post_type The post_type of the current page.
	 * @return void
	 */
	public function render_wholesale_filter() {
		$screen = get_current_screen();

		if ( $screen->post_type !== 'shop_order' ) {
			return;
		}

		$wholesale = false;

		if ( ! empty( $_GET['_wholesale'] ) ) { // phpcs:disable WordPress.Security.NonceVerification.Recommended
			$wholesale = $_GET['_wholesale'];
		}

		?>
		<select class="wcwp-customer-search" name="_wholesale">
			<option value="" <?php selected( ! $wholesale ); ?>><?php esc_html_e( 'Wholesale and Retail', 'woocommerce-wholesale-pro' ); ?></option>
			<option value="no" <?php selected( $wholesale, 'no' ); ?>><?php esc_html_e( 'Retail only', 'woocommerce-wholesale-pro' ); ?></option>
			<option value="yes" <?php selected( $wholesale, 'yes' ); ?>><?php esc_html_e( 'Wholesale only', 'woocommerce-wholesale-pro' ); ?></option>
		</select>
		<?php
	}

	public function order_query( $query_args ) {
		global $typenow;

		if ( isset( $query_args['type'] ) && $query_args['type'] === 'shop_order' || in_array( $typenow, wc_get_order_types( 'order-meta-boxes' ), true ) ) {
			if ( ! empty( $_GET['_wholesale'] ) ) { // WPCS: input var ok.
				$query_args['meta_query'][] = [
					'key'     => '_wholesale',
					'compare' => 'yes' === $_GET['_wholesale'] ? 'EXISTS' : 'NOT EXISTS',
				];
			}
		}

		return $query_args;
	}
}
