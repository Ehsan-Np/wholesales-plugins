<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

/**
 * Handles functionality on the Pages list table screen
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Page_List implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'display_post_states', [ $this, 'display_post_states' ], 10, 2 );
	}

	/**
	 * Add a post display state for our login and store pages
	 *
	 * @param array     $post_states An array of post display states.
	 * @param \WP_Post  $post        The current post object.
	 */
	public function display_post_states( $post_states, $post ) {
		if ( $this->get_page_id( 'wholesale_login' ) === $post->ID ) {
			$post_states['wcwp_page_for_login'] = __( 'Wholesale Login Page', 'woocommerce-wholesale-pro' );
		}

		if ( $this->get_page_id( 'wholesale_store' ) === $post->ID ) {
			$post_states['wcwp_page_for_store'] = __( 'Wholesale Store Page', 'woocommerce-wholesale-pro' );
		}

		return $post_states;
	}

	/**
	 * Returns the wholesale page ID based on page key
	 *
	 * @param string $page_key
	 * @return int $page_id
	 */
	private function get_page_id( $page_key ) {
		$page_id = get_option( 'wcwp_' . $page_key . '_page_id' );

		return $page_id ? \absint( $page_id ) : -1;
	}
}
