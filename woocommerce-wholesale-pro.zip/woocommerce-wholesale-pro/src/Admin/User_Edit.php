<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Customer;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Exception;

/**
 * Handles functionality on the User Edit screen
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class User_Edit implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'edit_user_profile', [ $this, 'approval_field' ], 999, 1 );
		add_action( 'edit_user_profile_update', [ $this, 'save_approval_status' ], 999, 1 );
		add_action( 'user_profile_update_errors', [ $this, 'handle_default_email' ], \PHP_INT_MAX, 3 );

		add_action( 'edit_user_profile', [ $this, 'registration_fields' ], 998, 1 );
		add_action( 'edit_user_profile_update', [ $this, 'save_registration_fields' ], 998, 1 );
	}

	/**
	 * Adds our approval field to the page
	 *
	 * @param \WP_User $user
	 */
	public function approval_field( $user ) {
		if ( ! Util::is_moderation_required( $user ) ) {
			return;
		}

		?>
		<div id="wcwp-approval-section">
		<h2><?php esc_html_e( 'Approve wholesale registration', 'woocommerce-wholesale-pro' ); ?></h2>
		<table class="form-table">
			<tr>
				<th><label for="wcwp_status"><?php esc_html_e( 'Approve / Reject', 'woocommerce-wholesale-pro' ); ?></label></th>
				<td>
					<select name="wcwp_status">
						<option value="approve" selected><?php esc_html_e( 'Approve Account', 'woocommerce-wholesale-pro' ); ?></option>
						<option value="reject"><?php esc_html_e( 'Reject Account', 'woocommerce-wholesale-pro' ); ?></option>
					</select>
				</td>
			</tr>
		</table>
		</div>
		<?php
	}

	/**
	 * Processes the approval / rejection, or change to non-wholesale
	 *
	 * @param int $user_id
	 */
	public function save_approval_status( $user_id ) {
		if ( ! current_user_can( 'manage_woocommerce', get_current_user_id() ) ) {
			return false;
		}

		$approval_status = filter_input( INPUT_POST, 'wcwp_status', FILTER_SANITIZE_FULL_SPECIAL_CHARS );
		$role            = filter_input( INPUT_POST, 'role', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		// bail if we are not in a moderation process
		if ( ! $approval_status ) {
			return false;
		}

		// validate status values
		if ( ! in_array( $approval_status, [ 'approve', 'reject' ], true ) ) {
			return false;
		}

		// check if switched to non-wholesale
		if ( $role && ! in_array( $role, Util::get_wholesale_roles(), true ) ) {
			$_POST['wcwp_send_default'] = 'true';
			return false;
		}

		// Set to default role if none selected
		if ( $role === 'wcwp_pending' ) {
			$_POST['role'] = Util::get_default_role();
		}

		try {
			$customer = new Wholesale_Customer( $user_id );

			switch ( $approval_status ) {
				case 'approve':
					$customer->approve();
					break;
				case 'reject':
					$customer->reject();
					wp_safe_redirect( add_query_arg( [ 'wcwp_rejected' => 'true' ], admin_url( 'users.php' ) ), 303 );
					break;
			}
		} catch ( Exception $e ) {
			wp_safe_redirect( add_query_arg( [ 'wcwp_error' => $e->getCode() ], get_edit_user_link( $user_id ) ), 303 );
		}
	}

	/**
	 * We hook in here as late as possible and if there are no errors then send the default mail
	 *
	 * @param   \WP_Errors  $errors
	 * @param   bool        $update
	 * @param   \WP_User    $user
	 * @return  \WP_Errors  $errors
	 */
	public function handle_default_email( &$errors, $update, &$user ) {
		if ( ! $update ) {
			return $errors;
		}

		$send_default_mail = filter_input( INPUT_POST, 'wcwp_send_default', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		if ( ! $send_default_mail ) {
			return $errors;
		}

		if ( $errors->has_errors() ) {
			return $errors;
		}

		/**
		 * We fire off the standard new user notification as the user will be removed from the approval process
		 * and so still needs to receive login credentials.
		 *
		 * Because the rest of the edited user data still needs to save at this point,
		 * the `wcwp_block_password_reset` filter allows us to remove our password reset block on the pending role before it is changed.
		 */
		add_filter( 'wcwp_block_password_reset', '__return_false' );
		add_user_meta( $user->ID, 'wcwp_send_default_mail', true );
		wp_send_new_user_notifications( $user->ID, 'user' );
		remove_filter( 'wcwp_block_password_reset', '__return_false' );

		return $errors;
	}

	/**
	 * Adds the registration fields
	 *
	 * @param \WP_User $user
	 */
	public function registration_fields( $user ) {
		if ( get_option( 'wcwp_trade_migrated_legacy_fields_v2' ) ) {
			return;
		}

		$fields = get_option( 'wcwp_registration_fields', [] );

		if ( empty( $fields ) ) {
			return;
		}

		?>
		<div id="wcwp-registration fields-section">
			<h2><?php esc_html_e( 'Wholesale user information', 'woocommerce-wholesale-pro' ); ?></h2>

			<table class="form-table">
				<?php
				foreach ( $fields as $unique_id => $field ) :
					$field_value = get_user_meta( $user->ID, $unique_id, true );
					?>
				<tr>
					<th><label for="<?php echo esc_attr( $unique_id ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
					<td>
						<input type="text" name="<?php echo esc_attr( $unique_id ); ?>" class="regular-text" value="<?php echo esc_attr( $field_value ); ?>" />
					</td>
				</tr>
				<?php endforeach; ?>
			</table>
		</div>
		<?php
	}

	/**
	 * Processes the editing of the users provided registration fields
	 *
	 * @param int $user_id
	 */
	public function save_registration_fields( $user_id ) {
		if ( get_option( 'wcwp_trade_migrated_legacy_fields_v2' ) ) {
			return false;
		}

		if ( ! current_user_can( 'manage_woocommerce', get_current_user_id() ) ) {
			return false;
		}

		$fields = get_option( 'wcwp_registration_fields', [] );

		foreach ( $fields as $unique_id => $field ) {
			$field_value = filter_input( INPUT_POST, $unique_id, FILTER_SANITIZE_FULL_SPECIAL_CHARS );

			if ( $field_value ) {
				update_user_meta( $user_id, $unique_id, sanitize_text_field( $field_value ) );
			}
		}
	}
}
