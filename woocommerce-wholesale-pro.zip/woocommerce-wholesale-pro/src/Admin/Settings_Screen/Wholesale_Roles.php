<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Admin\Settings_Screen;

use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Role;
use WC_Settings_API;
use Exception;

/**
 * Edit role settings screen
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Wholesale_Roles extends WC_Settings_API {
	/**
	 * Plugin ID
	 *
	 * @var string
	 */
	public $plugin_id = 'wcwp_';

	/**
	 * Unique ID for settings screen
	 *
	 * @var string
	 */
	public $id = 'wholesale_role';

	/**
	 * Wholesale_Role object
	 *
	 * @var Wholesale_Role
	 */
	public $wholesale_role;

	/**
	 * Role name if edit
	 *
	 * @var string
	 */
	public $name = '';

	/**
	 * Instance form fields.
	 *
	 * @var array
	 */
	public $instance_form_fields = [];

	/**
	 * Instance settings.
	 *
	 * @var array
	 */
	public $instance_settings = [];


	/**
	 * Constructor.
	 *
	 * @param string $name The wp_role name
	 */
	public function __construct( $name = 'new' ) {
		$this->name = $name;
		$this->init();
	}

	/**
	 * Init handler.
	 */
	public function init() {
		try {
			$this->wholesale_role = new Wholesale_Role( $this->name );
		} catch ( Exception $e ) {
			$this->add_error( $e->getMessage() );
			$this->display_errors();
			exit;
		}

		$this->instance_form_fields = $this->get_instance_form_fields();
		$this->init_instance_settings();
	}

	/**
	 * Output the shipping settings screen.
	 */
	public function admin_options() {
		$button_value = $this->name === 'new' ? __( 'Add role', 'woocommerce-wholesale-pro' ) : __( 'Save changes', 'woocommerce-wholesale-pro' );

		?>
		<h2>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=wholesale-pro&section=roles' ) ); ?>"><?php esc_html_e( 'Wholesale User Roles', 'woocommerce-wholesale-pro' ); ?></a> &gt;
			<span class="wc-wholesale-role-name"><?php echo esc_html( $this->get_option( 'display_name' ) ? $this->get_option( 'display_name' ) : __( 'Role', 'woocommerce-wholesale-pro' ) ); ?></span>
		</h2>

		<table class="form-table">

			<?php
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo $this->generate_settings_html( $this->get_instance_form_fields(), false );
			?>
		</table>

		<p class="submit">
			<button type="submit" name="submit" id="submit" class="button button-primary button-large wc-wholesale-role-save" value="save"><?php echo esc_html( $button_value ); ?></button>
		</p>
		<?php
	}

	/**
	 * Processes and saves wholesale roles
	 */
	public function process_admin_options() {
		// Check we are processing the correct form for this instance.
		$role_name = filter_input( INPUT_GET, 'role_name', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		if ( ! $role_name || ( $role_name !== 'new' && $role_name !== $this->name ) ) {
			return false;
		}

		$this->init_instance_settings();

		$post_data = $this->get_post_data();

		foreach ( $this->get_instance_form_fields() as $key => $field ) {
			if ( 'title' !== $this->get_field_type( $field ) ) {
				try {
					$this->instance_settings[ $key ] = $this->get_field_value( $key, $field, $post_data );
				} catch ( Exception $e ) {
					$this->add_error( $e->getMessage() );
				}
			}
		}

		$this->wholesale_role->update( $this->instance_settings );
		wp_safe_redirect( admin_url( 'admin.php?page=wc-settings&tab=wholesale-pro&section=roles&message=saved_role' ), 303 );
	}

	/**
	 * Initialise Settings for instances.
	 */
	public function init_instance_settings() {
		$this->instance_settings = $this->wholesale_role->get_data();

		// If there are no settings defined, use defaults.
		if ( ! is_array( $this->instance_settings ) ) {
			$form_fields             = $this->get_instance_form_fields();
			$this->instance_settings = array_merge( array_fill_keys( array_keys( $form_fields ), '' ), wp_list_pluck( $form_fields, 'default' ) );
		}
	}

	/**
	 * Get settings fields for instances of the wholesale role
	 *
	 * @return array
	 */
	public function get_instance_form_fields() {

		$settings = [
			'display_name'         => [
				'title'             => __( 'Display name', 'woocommerce-wholesale-pro' ),
				'type'              => 'text',
				'description'       => __( 'This is the name of the role.', 'woocommerce-wholesale-pro' ),
				'default'           => '',
				'custom_attributes' => [
					'maxlength' => 39,
					'required'  => true,
				],
				'desc_tip'          => true,
			],

			'global_discount'      => [
				'title'             => __( 'Discount', 'woocommerce-wholesale-pro' ),
				'type'              => 'number',
				'description'       => __( 'Enter a percentage discount which will be deducted from the price of all products for this user role. You can override this for individual categories or products.', 'woocommerce-wholesale-pro' ),
				'default'           => '',
				'desc_tip'          => true,
				'custom_attributes' => [
					'min'  => 0,
					'max'  => 100,
					'step' => 0.01,
				],
			],

			'default'              => [
				'title'       => __( 'Default role', 'woocommerce-wholesale-pro' ),
				'description' => __( 'This role will be assigned to all new users who register via the wholesale registration form. The administrator can then change user roles as required.', 'woocommerce-wholesale-pro' ),
				'label'       => __( 'Add new wholesale registrations to this role', 'woocommerce-wholesale-pro' ),
				'type'        => 'checkbox',
				'default'     => 'no',
				'desc_tip'    => true,
			],

			'product_pricing'      => [
				'title'             => __( 'Product specific pricing', 'woocommerce-wholesale-pro' ),
				'description'       => __( 'Adds an option to set exact wholesale prices for individual products and variations. If set, product-specific prices override the global and category wholesale discounts.', 'woocommerce-wholesale-pro' ),
				'label'             => __( 'Allow exact wholesale prices to be set for individual products', 'woocommerce-wholesale-pro' ),
				'type'              => 'checkbox',
				'default'           => 'no',
				'desc_tip'          => true,
				'class'             => 'wcwp-toggle-parent',
				'custom_attributes' => [
					'data-child-class' => 'conditional-child',
				],
			],

			'product_sale_pricing' => [
				'title'       => __( 'Product specific sale pricing', 'woocommerce-wholesale-pro' ),
				'description' => __( 'Adds an option to set exact wholesale sale prices for individual products and variations. If set, product-specific sale prices override the global and category wholesale discounts.', 'woocommerce-wholesale-pro' ),
				'label'       => __( 'Allow exact wholesale sale prices to be set for individual products', 'woocommerce-wholesale-pro' ),
				'type'        => 'checkbox',
				'default'     => 'no',
				'desc_tip'    => true,
				'class'       => 'conditional-child'
			],
			'apply_to_sale_price'  => [
				'title'       => __( 'Apply wholesale discounts to sale prices', 'woocommerce-wholesale-pro' ),
				'description' => __( 'Enable this to calculate the % wholesale discount on the product sale price (if set) instead of the regular price. This will be ignored for any products which have an exact wholesale price set.', 'woocommerce-wholesale-pro' ),
				'label'       => __( 'Allow the discount to be applied to sale prices when products are on sale', 'woocommerce-wholesale-pro' ),
				'type'        => 'checkbox',
				'default'     => 'no',
				'desc_tip'    => true,
			],

			'disable_tax'          => [
				'title'       => __( 'Tax status', 'woocommerce-wholesale-pro' ),
				'description' => __( 'The tax status of users with this role. \'Inherited\' uses the tax setting from the General tab, or you can enable/disable tax for this specific role. ', 'woocommerce-wholesale-pro' ),
				'label'       => __( 'Do not charge tax to wholesale users with this role', 'woocommerce-wholesale-pro' ),
				'type'        => 'select',
				'default'     => 'inherit',
				'options'     => [
					'inherit' => __( 'Inherited', 'woocommerce-wholesale-pro' ),
					'disable' => __( 'Disabled', 'woocommerce-wholesale-pro' ),
					'enable'  => __( 'Enabled', 'woocommerce-wholesale-pro' ),
				],
				'desc_tip'    => true,
			],

			'tax_display_shop'     => [
				'title'       => __( 'Display prices in the shop', 'woocommerce-wholesale-pro' ),
				'description' => __( 'Shop price display for users with this role. \'Inherited\' uses the \'Display prices in shop\' setting from WooCommerce > Tax > Tax options or you can choose a different option for this specific role. ', 'woocommerce-wholesale-pro' ),
				'type'        => 'select',
				'default'     => 'inherit',
				'options'     => [
					'inherit' => __( 'Inherit from the storewide tax settings [the default]', 'woocommerce-wholesale-pro' ),
					'incl'    => __( 'Including tax', 'woocommerce-wholesale-pro' ),
					'excl'    => __( 'Excluding tax', 'woocommerce-wholesale-pro' ),
				],
				'desc_tip'    => true,
			],
		];

		if ( ! empty( $this->instance_settings ) && isset( $this->instance_settings['default'] ) && $this->instance_settings['default'] === 'yes' ) {
			$settings['default']['custom_attributes'] = [
				'disabled' => 'disabled'
			];
		}

		return $settings;
	}

	/**
	 * Get_option function.
	 *
	 * Gets and option from the settings API, using defaults if necessary to prevent undefined notices.
	 *
	 * @param  string $key Key.
	 * @param  mixed  $empty_value Empty value.
	 * @return mixed  The value specified for the option or a default value for the option.
	 */
	public function get_option( $key, $empty_value = null ) {
		// Instance options take priority over global options.
		return $this->get_instance_option( $key, $empty_value );
	}

	/**
	 * Gets an option from the settings API, using defaults if necessary to prevent undefined notices.
	 *
	 * @param  string $key Key.
	 * @param  mixed  $empty_value Empty value.
	 * @return mixed  The value specified for the option or a default value for the option.
	 */
	public function get_instance_option( $key, $empty_value = null ) {
		if ( empty( $this->instance_settings ) ) {
			$this->init_instance_settings();
		}

		// Get option default if unset.
		if ( ! isset( $this->instance_settings[ $key ] ) ) {
			$form_fields                     = $this->get_instance_form_fields();
			$this->instance_settings[ $key ] = $this->get_field_default( $form_fields[ $key ] );
		}

		if ( ! is_null( $empty_value ) && '' === $this->instance_settings[ $key ] ) {
			$this->instance_settings[ $key ] = $empty_value;
		}

		$instance_option = $this->instance_settings[ $key ];
		return $instance_option;
	}
}
