<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

/**
 * Handles admin facing AJAX actions
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Ajax_Actions implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'wp_ajax_wcwp_role_sorting', [ $this, 'role_sorting' ] );
	}

	/**
	 * Handle role drag and drop sorting
	 */
	public function role_sorting() {
		check_ajax_referer( 'wcwp-role-sorting', 'security' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( -1 );
		}

		$ordered_roles = filter_input( INPUT_POST, 'ordered_roles', FILTER_SANITIZE_FULL_SPECIAL_CHARS, FILTER_REQUIRE_ARRAY );

		$updated = update_option( 'wcwp_role_order', $ordered_roles, false );

		wp_send_json( [ 'success' => $updated ], 200 );
	}
}
