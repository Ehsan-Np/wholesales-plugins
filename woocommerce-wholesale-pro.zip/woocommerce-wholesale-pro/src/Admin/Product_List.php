<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

/**
 * Handles functionality on the Product list table screen
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Product_List implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		// Add the wholesale visibility column
		add_filter( 'manage_product_posts_columns', [ $this, 'add_wholesale_visibility_column' ], 10, 1 );
		add_action( 'manage_product_posts_custom_column', [ $this, 'render_wholesale_visibility_column' ], 10, 2 );

		// Quick edit support
		add_action( 'woocommerce_product_quick_edit_end', [ $this, 'quick_edit_field' ] );
		add_action( 'woocommerce_product_quick_edit_save', [ $this, 'save_quick_edit_field' ] );

		// Bulk edit support
		add_action( 'woocommerce_product_bulk_edit_end', [ $this, 'bulk_edit_field' ] );
		add_action( 'woocommerce_product_bulk_edit_save', [ $this, 'save_bulk_edit_field' ] );
	}

	/**
	 * Add the wholesale visibility column
	 *
	 * @param array $columns
	 *
	 * @return array
	 */
	public function add_wholesale_visibility_column( $columns ) {

		return array_merge(
			$columns,
			[
				'wholesale_visibility' => __( 'Visibility', 'woocommerce-wholesale-pro' ),
			]
		);
	}

	/**
	 * Render the wholesale visibility column
	 *
	 * @param string $column
	 * @param int $post_id
	 */
	public function render_wholesale_visibility_column( $column, $post_id ) {
		if ( 'wholesale_visibility' !== $column ) {
			return;
		}

		$product_object       = $post_id ? wc_get_product( $post_id ) : new WC_Product();
		$wholesale_visibility = $product_object->get_meta( '_wwp_wholesale_visibility' );

		$visibility_options = [
			''               => __( 'Inherited from category', 'woocommerce-wholesale-pro' ),
			'public'         => __( 'Public and wholesale', 'woocommerce-wholesale-pro' ),
			'wholesale_only' => __( 'Wholesale only', 'woocommerce-wholesale-pro' ),
			'public_only'    => __( 'Public only', 'woocommerce-wholesale-pro' ),
		];

		echo isset( $visibility_options[ $wholesale_visibility ] ) ? esc_html( $visibility_options[ $wholesale_visibility ] ) : esc_html( $wholesale_visibility );
		echo '<span class="wcwp-wholesale-visibility-data" style="display:none">' . esc_html( $wholesale_visibility ) . '</span>';
	}

	/**
	 * Render the wholesale visibility select field in the quick edit form.
	 */
	public function quick_edit_field() {
		$visibility_options = [
			''               => __( 'Inherit from category', 'woocommerce-wholesale-pro' ),
			'public'         => __( 'Public and wholesale', 'woocommerce-wholesale-pro' ),
			'wholesale_only' => __( 'Wholesale only', 'woocommerce-wholesale-pro' ),
			'public_only'    => __( 'Public only', 'woocommerce-wholesale-pro' ),
		];
		?>
		<div class="inline-edit-group wcwp-wholesale-visibility-field">
			<span class="title"><?php esc_html_e( 'Wholesale visibility', 'woocommerce-wholesale-pro' ); ?></span>
			<span class="input-text-wrap">
				<select name="_wwp_wholesale_visibility" class="wcwp_wholesale_visibility">
					<?php foreach ( $visibility_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</span>
		</div>
		<?php
	}

	/**
	 * Save the wholesale visibility field from the quick edit form.
	 *
	 * @param \WC_Product $product
	 */
	public function save_quick_edit_field( \WC_Product $product ) {
		$wholesale_visibility = filter_input( INPUT_POST, '_wwp_wholesale_visibility', FILTER_SANITIZE_SPECIAL_CHARS );

		if ( in_array( $wholesale_visibility, [ false, null ], true ) ) {
			return;
		}

		$product->update_meta_data( '_wwp_wholesale_visibility', $wholesale_visibility );
		$product->save();
	}

	/**
	 * Render the wholesale visibility select field in the bulk edit form.
	 */
	public function bulk_edit_field() {
		$visibility_options = [
			'_no_change'     => __( '— No change —', 'woocommerce-wholesale-pro' ),
			''               => __( 'Inherit from category', 'woocommerce-wholesale-pro' ),
			'public'         => __( 'Public and wholesale', 'woocommerce-wholesale-pro' ),
			'wholesale_only' => __( 'Wholesale only', 'woocommerce-wholesale-pro' ),
			'public_only'    => __( 'Public only', 'woocommerce-wholesale-pro' ),
		];
		?>
		<label class="wcwp-wholesale-visibility-field">
			<span class="title"><?php esc_html_e( 'Wholesale visibility', 'woocommerce-wholesale-pro' ); ?></span>
			<span class="input-text-wrap">
				<select name="_wwp_wholesale_visibility" class="wcwp_wholesale_visibility">
					<?php foreach ( $visibility_options as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</span>
		</label>
		<?php
	}

	/**
	 * Save the wholesale visibility field from the bulk edit form.
	 *
	 * @param \WC_Product $product
	 */
	public function save_bulk_edit_field( \WC_Product $product ) {
		// The bulk edit form is submitted via the posts-filter form which uses method="get",
		// so the field arrives in $_GET (and $_REQUEST), not $_POST.
		// WooCommerce's nonce has already been verified upstream before this hook fires.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $_REQUEST['_wwp_wholesale_visibility'] ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$wholesale_visibility = wc_clean( wp_unslash( $_REQUEST['_wwp_wholesale_visibility'] ) );

		if ( '_no_change' === $wholesale_visibility ) {
			return;
		}

		$product->update_meta_data( '_wwp_wholesale_visibility', $wholesale_visibility );
		$product->save();
	}
}
