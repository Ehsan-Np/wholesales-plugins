<?php

namespace Barn2\Plugin\WC_Wholesale_Pro;

use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use WP_User;
use WP_Error;

/**
 * Authenticate Handler
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Authenticate implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'wp_authenticate_user', [ $this, 'authenticate_customer' ], 10, 1 );
		add_filter( 'allow_password_reset', [ $this, 'block_password_reset' ], 10, 2 );
	}

	/**
	 * Block password reset for pending users
	 *
	 * @param bool  $allow
	 * @param int   $user_id
	 * @return bool $allow
	 */
	public function block_password_reset( $allow, $user_id ) {
		/**
		 * Filters whether password resets should be blocked when a user is in moderation.
		 *
		 * @param bool $block Whether to block the password reset. (default: true)
		 */
		$block_reset = apply_filters( 'wcwp_block_password_reset', true );

		if ( Util::is_moderation_required( $user_id ) && $block_reset ) {
			$allow = false;
		}

		return $allow;
	}

	/**
	 * Deny login for pending customers.
	 * Just in case.
	 *
	 * @param  WP_User|WP_Error $user
	 * @return WP_User|WP_Error $user
	 */
	public function authenticate_customer( $user ) {
		if ( ! is_wp_error( $user ) && Util::is_moderation_required( $user ) ) {
			$user = new WP_Error(
				'wcwp_approval_pending',
				wp_kses_post( __( '<strong>Error:</strong> Your account has to be approved before you can login.', 'woocommerce-wholesale-pro' ) )
			);
		}

		return $user;
	}
}
