<?php
/**
 * Class Free_Shipping file.
 *
 * @package Barn2\Plugin\WC_Wholesale_Pro
 */

namespace Barn2\Plugin\WC_Wholesale_Pro\Shipping;

use WC_Shipping_Free_Shipping;

/**
 * Free Shipping Method for Wholesale Customers.
 *
 * A simple shipping method for free shipping.
 *
 * @version 1.0.0
 * @since   2.0.0
 * @package Barn2/woocommerce-wholesale-pro
 */
class Free_Shipping extends WC_Shipping_Free_Shipping {

	/**
	 * Constructor.
	 *
	 * @param int $instance_id Shipping method instance.
	 */
	public function __construct( $instance_id = 0 ) {
		$this->id                 = 'wcwp_free_shipping';
		$this->instance_id        = absint( $instance_id );
		$this->method_title       = __( 'Wholesale free shipping', 'woocommerce-wholesale-pro' );
		$this->method_description = __( 'This is a special method reserved to wholesale customers which can be triggered with coupons and minimum spends.', 'woocommerce-wholesale-pro' );
		$this->supports           = [
			'shipping-zones',
			'instance-settings',
			'instance-settings-modal',
		];

		$this->init();
	}

	public function init() {
		parent::init();

		$this->instance_form_fields['title']['default'] = __( 'Wholesale free shipping', 'woocommerce-wholesale-pro' );

		$this->init_instance_settings();

		$this->title = $this->get_option( 'title' );
	}
}
