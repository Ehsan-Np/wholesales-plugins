<?php
/**
 * Class Local_Pickup file.
 *
 * @package Barn2/woocommerce-wholesale-pro
 */

namespace Barn2\Plugin\WC_Wholesale_Pro\Shipping;

use WC_Shipping_Local_Pickup;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Local Pickup Shipping Method for Wholesale Customers.
 *
 * A simple shipping method allowing free pickup as a shipping method.
 *
 * @class   Local_Pickup
 * @since   1.0.0
 * @version 2.0.0
 * @package Barn2/woocommerce-wholesale-pro
 */
class Local_Pickup extends WC_Shipping_Local_Pickup {

	/**
	 * Constructor.
	 *
	 * @param int $instance_id Instance ID.
	 */
	public function __construct( $instance_id = 0 ) {
		$this->id                 = 'wcwp_local_pickup';
		$this->instance_id        = absint( $instance_id );
		$this->method_title       = __( 'Wholesale local pickup', 'woocommerce-wholesale-pro' );
		$this->method_description = __( 'Allow wholesale customers to pick up orders themselves. By default, when using local pickup store base taxes will apply regardless of customer address.', 'woocommerce-wholesale-pro' );
		$this->supports           = [
			'shipping-zones',
			'instance-settings',
			'instance-settings-modal',
		];
		$this->init();
	}

	public function init() {
		parent::init();

		$this->instance_form_fields['title']['default'] = __( 'Wholesale local pickup', 'woocommerce-wholesale-pro' );

		$this->init_instance_settings();

		$this->title = $this->get_option( 'title' );
	}
}
