<?php
/**
 * Flat Rate Shipping Method for Wholesale customers.
 *
 * @package Barn2/woocommerce-wholesale-pro
 */

namespace Barn2\Plugin\WC_Wholesale_Pro\Shipping;

use WC_Shipping_Flat_Rate;

/**
 * Flat Rate Shipping Method for Wholesale Customers.
 *
 * @version 1.0.0
 * @since   2.0.0
 * @package Barn2/woocommerce-wholesale-pro
 */
class Flat_Rate extends WC_Shipping_Flat_Rate {

	/**
	 * Whether the method is hidden or not.
	 *
	 * @var bool
	 */
	protected $hide = false;

	/**
	 * Constructor.
	 *
	 * @param int $instance_id Shipping method instance ID.
	 */
	public function __construct( $instance_id = 0 ) {
		$this->id                 = 'wcwp_flat_rate';
		$this->instance_id        = absint( $instance_id );
		$this->method_title       = __( 'Wholesale flat rate', 'woocommerce-wholesale-pro' );
		$this->method_description = __( 'Lets you charge a fixed rate for shipping to wholesale customers.', 'woocommerce-wholesale-pro' );
		$this->supports           = [
			'shipping-zones',
			'instance-settings',
			'instance-settings-modal',
		];
		$this->init();

		add_action( 'woocommerce_update_options_shipping_' . $this->id, [ $this, 'process_admin_options' ] );
	}

	/**
	 * Initialize the shipping method
	 *
	 * @return void
	 */
	public function init() {
		parent::init();

		$this->instance_form_fields                     = include WC()->plugin_path() . '/includes/shipping/flat-rate/includes/settings-flat-rate.php';
		$this->instance_form_fields['title']['default'] = $this->method_title;

		$head              = $this->instance_form_fields;
		$tail              = [];
		$class_costs_index = array_search( 'class_costs', array_keys( $this->instance_form_fields ), true );

		if ( false !== $class_costs_index ) {
			$head = array_slice( $this->instance_form_fields, 0, $class_costs_index );
			$tail = array_slice( $this->instance_form_fields, $class_costs_index );
		}

		$hide_option = [
			'title'       => __( 'Hide if free shipping is available', 'woocommerce-wholesale-pro' ),
			'type'        => 'checkbox',
			'description' => __( 'When free shipping is available for the same customer role, there might be cases when showing both a free shipping and a flat rate method could be confusing. When this option is checked, the shipping method gets hidden if a free shipping method is available for the current customer.', 'woocommerce-wholesale-pro' ),
			'default'     => 'no',
			'desc_tip'    => true,
		];

		$this->instance_form_fields = array_merge( $head, [ 'hide' => $hide_option ], $tail );

		$this->init_instance_settings();

		$this->title = $this->get_option( 'title' );
		$this->hide  = wc_string_to_bool( $this->get_option( 'hide' ) );
	}

	public function get_hide() {
		return $this->hide;
	}
}
