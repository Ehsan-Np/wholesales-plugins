<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Emails;

use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Role;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use WP_User;
use Exception;

/**
 * New account email for the adminstrator
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Admin_New_User extends WCWP_Email implements Registerable {

	/**
	 * Constructor.
	 *
	 * @param string $template_directory
	 */
	public function __construct( $template_directory ) {
		$this->id                 = 'wcwp_new_wholesale_user';
		$this->title             = __( 'New wholesale user', 'woocommerce-wholesale-pro' );
		$this->description       = __( '“New wholesale user” emails are sent to chosen recipient(s) when a new wholesale user account is held for moderation.', 'woocommerce-wholesale-pro' );
		$this->template_html      = 'emails/admin-wholesale-new-user.php';
		$this->template_plain     = 'emails/plain/admin-wholesale-new-user.php';
		$this->recipient          = $this->get_option( 'recipient', get_option( 'admin_email' ) );
		$this->placeholders      = [
			'{registration_fields}' => '',
			'{default_role}'        => '',
			'{edit_user_url}'       => '',
		];
		$this->placeholders_desc = [
			'{registration_fields}' => __( 'The information which the customer entered on the wholesale registration form.', 'woocommerce-wholesale-pro' ),
			'{default_role}'        => __( 'The default wholesale role, which the new user will be added to unless you select a different role.', 'woocommerce-wholesale-pro' ),
			'{edit_user_url}'       => __( 'The link to approve or reject the wholesale user application.', 'woocommerce-wholesale-pro' ),
		];
		$this->template_base      = plugin_basename( $template_directory );
		$this->template_directory = $template_directory;

		parent::__construct();

		$this->register();
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'woocommerce_locate_core_template', [ $this, 'handle_locate_core_template' ], 10, 4 );
		add_filter( 'woocommerce_locate_template', [ $this, 'handle_locate_template' ], 10, 3 );
		add_action( 'wcwp_new_user_moderation_notification', [ $this, 'trigger' ], 10, 1 );
	}

	/**
	 * Trigger.
	 *
	 * @param int    $user_id User ID.
	 */
	public function trigger( $user_id ) {
		$this->setup_locale();

		if ( $user_id ) {
			$this->object                          = new WP_User( $user_id );
			$this->placeholders['{edit_user_url}'] = add_query_arg( 'user_id', $user_id, admin_url( 'user-edit.php' ) );

			try {
				$default_role = new Wholesale_Role( Util::get_default_role() );
			} catch ( Exception $e ) {
				$default_role = new Wholesale_Role( 'wcwp_wholesale' );
			}

			$this->placeholders['{default_role}']        = $default_role->get_display_name();
			$this->placeholders['{registration_fields}'] = $this->get_registration_fields( $user_id );
		}

		if ( $this->is_enabled() && $this->get_recipient() ) {
			$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		}

		$this->restore_locale();
	}

	/**
	 * Get email subject.
	 *
	 * @return string
	 */
	public function get_default_subject() {
		return __( 'New wholesale user', 'woocommerce-wholesale-pro' );
	}

	/**
	 * Get email heading.
	 *
	 * @return string
	 */
	public function get_default_heading() {
		return __( 'New wholesale user - please approve', 'woocommerce-wholesale-pro' );
	}

	/**
	 * Default email body content
	 *
	 * @return string
	 */
	public function get_default_body_content() {
		$content  = __( 'A new wholesale user has registered and is being held for moderation.', 'woocommerce-wholesale-pro' );
		$content .= "\n\n";
		$content  = __( 'To approve or deny their request, click on the following link and use the dropdown to Approve or Reject their account - {edit_user_url}.', 'woocommerce-wholesale-pro' );
		$content .= "\n\n";
		$content .= __( 'If you approve their request, then they will be sent the ‘Wholesale user approved’ email containing their login details so that they can access the wholesale store for the first time.', 'woocommerce-wholesale-pro' );
		$content .= "\n\n";
		$content .= __( 'If you reject their request, then they will be sent the ‘Wholesale user declined’ email and their account will be deleted.', 'woocommerce-wholesale-pro' );

		if ( Util::has_multiple_wholesale_roles() ) {
			$content .= "\n\n";
			$content .= __( 'By default, the new wholesale user will be given the {default_role} role. Use the ‘Role’ dropdown to assign a different wholesale role before approving their account.', 'woocommerce-wholesale-pro' );
		}

		return $content;
	}

	/**
	 * Get content html.
	 *
	 * @return string
	 */
	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			[
				'email_heading' => $this->get_heading(),
				'body_content'  => $this->get_body_content(),
				'blogname'      => $this->get_blogname(),
				'sent_to_admin' => true,
				'plain_text'    => false,
				'email'         => $this,
			]
		);
	}

	/**
	 * Get content plain.
	 *
	 * @return string
	 */
	public function get_content_plain() {
		return wc_get_template_html(
			$this->template_plain,
			[
				'email_heading' => $this->get_heading(),
				'body_content'  => $this->get_body_content(),
				'blogname'      => $this->get_blogname(),
				'sent_to_admin' => true,
				'plain_text'    => true,
				'email'         => $this,
			]
		);
	}

	/**
	 * Initialise settings form fields.
	 */
	public function init_form_fields() {
		/* translators: %s: list of placeholders */
		$placeholder_text  = sprintf( __( 'Available placeholders: %s', 'woocommerce-wholesale-pro' ), '<code>' . implode( '</code>, <code>', array_keys( $this->placeholders ) ) . '</code>' );
		$this->form_fields = [
			'enabled'      => [
				'title'   => __( 'Enable/Disable', 'woocommerce-wholesale-pro' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable this email notification', 'woocommerce-wholesale-pro' ),
				'default' => 'yes',
			],
			'recipient'    => [
				'title'       => __( 'Recipient(s)', 'woocommerce-wholesale-pro' ),
				'type'        => 'text',
				/* translators: %s: WP admin email */
				'description' => sprintf( __( 'Enter recipients (comma separated) for this email. Defaults to %s.', 'woocommerce-wholesale-pro' ), '<code>' . esc_attr( get_option( 'admin_email' ) ) . '</code>' ),
				'placeholder' => '',
				'default'     => '',
				'desc_tip'    => true,
			],
			'subject'      => [
				'title'       => __( 'Subject', 'woocommerce-wholesale-pro' ),
				'type'        => 'text',
				'desc_tip'    => true,
				'description' => $placeholder_text,
				'placeholder' => $this->get_default_subject(),
				'default'     => '',
			],
			'heading'      => [
				'title'       => __( 'Email heading', 'woocommerce-wholesale-pro' ),
				'type'        => 'text',
				'desc_tip'    => true,
				'description' => $placeholder_text,
				'placeholder' => $this->get_default_heading(),
				'default'     => '',
			],
			'body_content' => [
				'title'       => __( 'Email content', 'woocommerce-wholesale-pro' ),
				'description' => __( 'Text to appear as the main email content.', 'woocommerce-wholesale-pro' ) . ' ' . $placeholder_text,
				'css'         => 'width:400px; height: 200px;',
				'placeholder' => __( 'N/A', 'woocommerce-wholesale-pro' ),
				'type'        => 'textarea',
				'default'     => $this->get_default_body_content(),
				'desc_tip'    => true,
			],
			'email_type'   => [
				'title'       => __( 'Email type', 'woocommerce-wholesale-pro' ),
				'type'        => 'select',
				'description' => __( 'Choose which format of email to send.', 'woocommerce-wholesale-pro' ),
				'default'     => 'html',
				'class'       => 'email_type wc-enhanced-select',
				'options'     => $this->get_email_type_options(),
				'desc_tip'    => true,
			],
		];
	}

	/**
	 * Retrieve formatted registration fields.
	 *
	 * @param mixed $user_id
	 * @return string
	 */
	private function get_registration_fields( $user_id ) {
		$output              = '';
		$registration_fields = Util::get_user_registration_fields( $user_id );

		if ( empty( $registration_fields ) ) {
			return $output;
		}

		foreach ( $registration_fields as $field ) {
			// skip empty val
			if ( $field['value'] === '' ) {
				continue;
			}

			$output .= $field['label'] . ': ' . $field['value'] . "\n\n";
		}

		return $output;
	}
}
