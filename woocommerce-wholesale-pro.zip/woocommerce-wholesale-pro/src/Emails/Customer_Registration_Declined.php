<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Emails;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use WP_User;

/**
 * Registration declined email for the customer
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Customer_Registration_Declined extends WCWP_Email implements Registerable {

	/**
	 * Constructor.
	 *
	 * @param string $template_directory
	 */
	public function __construct( $template_directory ) {
		$this->id             = 'wcwp_customer_registration_declined';
		$this->customer_email = true;

		$this->title              = __( 'Wholesale registration declined', 'woocommerce-wholesale-pro' );
		$this->description        = __( 'Customer "Wholesale user declined" emails are sent to the customer when the administrator or store manager rejects their wholesale registration.', 'woocommerce-wholesale-pro' );
		$this->template_html      = 'emails/wholesale-registration-declined.php';
		$this->template_plain     = 'emails/plain/wholesale-registration-declined.php';
		$this->template_directory = $template_directory;

		parent::__construct();

		$this->register();
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'woocommerce_locate_core_template', [ $this, 'handle_locate_core_template' ], 10, 4 );
		add_filter( 'woocommerce_locate_template', [ $this, 'handle_locate_template' ], 10, 3 );
		add_action( 'wcwp_user_before_reject_notification', [ $this, 'trigger' ], 10, 2 );
	}

	/**
	 * Trigger.
	 *
	 * @param int    $user_id User ID.
	 */
	public function trigger( $user_id ) {
		$this->setup_locale();

		if ( $user_id ) {
			$this->object     = new WP_User( $user_id );
			$this->user_email = stripslashes( $this->object->user_email );
			$this->recipient  = $this->user_email;
		}

		if ( $this->is_enabled() && $this->get_recipient() ) {
			$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		}

		$this->restore_locale();
	}

	/**
	 * Get email subject.
	 *
	 * @return string
	 */
	public function get_default_subject() {
		return __( 'Your wholesale user registration has been declined', 'woocommerce-wholesale-pro' );
	}

	/**
	 * Get email heading.
	 *
	 * @return string
	 */
	public function get_default_heading() {
		return __( 'Your wholesale user registration has been declined', 'woocommerce-wholesale-pro' );
	}

	/**
	 * Default email body content
	 *
	 * @return string
	 */
	public function get_default_body_content() {
		return __( 'Thanks for applying for the wholesale store. Unfortunately your request has not been accepted. Please contact us for further details.', 'woocommerce-wholesale-pro' );
	}

	/**
	 * Get content html.
	 *
	 * @return string
	 */
	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			[
				'user'          => $this->object,
				'email_heading' => $this->get_heading(),
				'body_content'  => $this->get_body_content(),
				'sent_to_admin' => false,
				'plain_text'    => false,
				'email'         => $this,
			],
			'',
			$this->template_directory
		);
	}

	/**
	 * Get content plain.
	 *
	 * @return string
	 */
	public function get_content_plain() {
		return wc_get_template_html(
			$this->template_plain,
			[
				'user'          => $this->object,
				'email_heading' => $this->get_heading(),
				'body_content'  => $this->get_body_content(),
				'sent_to_admin' => false,
				'plain_text'    => true,
				'email'         => $this,
			],
			'',
			$this->template_directory
		);
	}
}
