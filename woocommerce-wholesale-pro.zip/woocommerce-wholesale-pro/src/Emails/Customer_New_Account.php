<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Emails;

use Barn2\Plugin\WC_Wholesale_Pro\Util;
use WP_User;

/**
 * New account email for the customer added via User > Add New
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Customer_New_Account extends WCWP_Email {

	/**
	 * User login name.
	 *
	 * @var string
	 */
	public $user_login;

	/**
	 * User email.
	 *
	 * @var string
	 */
	public $user_email;

	/**
	 * User password.
	 *
	 * @var string
	 */
	public $user_pass;

	/**
	 * User ID
	 *
	 * @var int
	 */
	public $user_id;

	/**
	 * Set password URL
	 *
	 * @var string
	 */
	public $set_password_url;

	/**
	 * Is the password generated?
	 *
	 * @var bool
	 */
	public $password_generated;

	/**
	 * Constructor.
	 *
	 * @param string $template_directory
	 */
	public function __construct( $template_directory ) {
		$this->id                 = 'wcwp_customer_new_account';
		$this->customer_email     = true;
		$this->title              = __( 'New wholesale account', 'woocommerce-wholesale-pro' );
		$this->description        = __( 'Customer "New wholesale account" emails are sent to the customer when a wholesale account is created manually by an administrator or store manager; or when they use the wholesale registration form and moderation is disabled.', 'woocommerce-wholesale-pro' );
		$this->template_html      = 'emails/wholesale-new-account.php';
		$this->template_plain     = 'emails/plain/wholesale-new-account.php';
		$this->placeholders       = [
			'{user_pass}'        => '',
			'{user_login}'       => '',
			'{login_url}'        => Util::get_wholesale_login_url(),
			'{set_password_url}' => '',
		];
		$this->placeholders_desc  = [
			'{user_pass}'        => __( 'The password for the new account.', 'woocommerce-wholesale-pro' ),
			'{user_login}'       => __( 'The username for the new account.', 'woocommerce-wholesale-pro' ),
			'{login_url}'        => __( 'The URL to the login page.', 'woocommerce-wholesale-pro' ),
			'{set_password_url}' => __( 'The URL to the set password page.', 'woocommerce-wholesale-pro' ),
		];
		$this->template_base      = plugin_basename( $template_directory );
		$this->template_directory = $template_directory;

		parent::__construct();

		$this->register();
	}


	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'woocommerce_locate_core_template', [ $this, 'handle_locate_core_template' ], 10, 4 );
		add_filter( 'woocommerce_locate_template', [ $this, 'handle_locate_template' ], 10, 3 );
		add_filter( 'wp_new_user_notification_email', [ $this, 'override_new_user_notification_email' ], 999, 3 );
		add_filter( 'wcwp_new_user_auto_approved_notification', [ $this, 'trigger' ], 10, 2 );
	}

	/**
	 * Override the default new user email.
	 *
	 * @param array $email
	 * @param WP_User $user
	 * @param string $blogname
	 * @return array
	 */
	public function override_new_user_notification_email( $email, $user, $blogname ) {
		if ( ! Util::is_wholesale_user( $user ) ) {
			return $email;
		}

		// if the admin switched to a non wholesale role send the default mail as well
		if ( get_user_meta( $user->ID, 'wcwp_send_default_mail', true ) ) {
			delete_user_meta( $user->ID, 'wcwp_send_default_mail' );
			return $email;
		}

		$this->object    = $user;
		$this->user_id   = $this->object->ID;
		$this->recipient = $this->object->user_email;

		/**
		 * Previous to v1.7.2,the password was regenerated here
		 * so it can be sent in the email without being stored.
		 *
		 * Since WooCommerce switched to providing a set password link,
		 * we have also adopted to this methodology in v1.7.2.
		 *
		 * This remains here for backwards-compatibility
		 * where users might have custom templates using the user_pass merge tag or property.
		 */
		$password = wp_generate_password();
		wp_set_password( $password, $this->user_id );
		$this->user_pass = $password;

		/**
		 * This is the new set_password method.
		 */
		$this->set_password_url = $this->generate_set_password_url();

		$this->placeholders['{user_pass}']        = $password;
		$this->placeholders['{user_login}']       = $this->object->user_email;
		$this->placeholders['{set_password_url}'] = $this->set_password_url;

		$email = [
			'to'          => $this->recipient,
			'subject'     => $this->get_subject(),
			'message'     => $this->style_inline( $this->get_content() ),
			'headers'     => $this->get_headers(),
			'attachments' => $this->get_attachments(),
		];

		return $email;
	}

	/**
	 * Trigger.
	 *
	 * @param int    $user_id User ID.
	 * @param string $user_pass User Password.
	 */
	public function trigger( $user_id, $user_pass = '' ) {
		$this->setup_locale();

		if ( $user_id ) {
			$this->object           = new WP_User( $user_id );
			$this->user_pass        = $user_pass;
			$this->set_password_url = $this->generate_set_password_url();
			$this->user_login       = stripslashes( $this->object->user_login );
			$this->user_email       = stripslashes( $this->object->user_email );
			$this->recipient        = $this->user_email;

			$this->placeholders['{user_pass}']        = $this->user_pass;
			$this->placeholders['{user_login}']       = $this->user_email;
			$this->placeholders['{set_password_url}'] = $this->set_password_url;
		}

		if ( $this->is_enabled() && $this->get_recipient() ) {
			$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		}

		$this->restore_locale();
	}

	/**
	 * Get email subject.
	 *
	 * @return string
	 */
	public function get_default_subject() {
		return __( 'Your wholesale user account', 'woocommerce-wholesale-pro' );
	}

	/**
	 * Get email heading.
	 *
	 * @return string
	 */
	public function get_default_heading() {
		return __( 'Welcome to the wholesale store!', 'woocommerce-wholesale-pro' );
	}

	/**
	 * Default email body content
	 *
	 * @return string
	 */
	public function get_default_body_content() {
		$content  = __( 'Thanks for registering for the wholesale store. You can login as follows:', 'woocommerce-wholesale-pro' );
		$content .= "\n\n";
		$content .= sprintf( '%s {user_login}', __( 'Username:', 'woocommerce-wholesale-pro' ) );
		$content .= "\n\n";
		$content .= sprintf( '<a href="{set_password_url}">%s</a>', __( 'Click here to set your password.', 'woocommerce-wholesale-pro' ) );

		return $content;
	}

	/**
	 * Get content html.
	 *
	 * @return string
	 */
	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			[
				'email_heading'    => $this->get_heading(),
				'body_content'     => $this->get_body_content(),
				'user_login'       => $this->user_login,
				'user_pass'        => $this->user_pass,
				'set_password_url' => $this->set_password_url,
				'blogname'         => $this->get_blogname(),
				'sent_to_admin'    => false,
				'plain_text'       => false,
				'email'            => $this,
			]
		);
	}

	/**
	 * Get content plain.
	 *
	 * @return string
	 */
	public function get_content_plain() {
		return wc_get_template_html(
			$this->template_plain,
			[
				'email_heading'    => $this->get_heading(),
				'body_content'     => $this->get_body_content(),
				'user_login'       => $this->user_login,
				'user_pass'        => $this->user_pass,
				'set_password_url' => $this->set_password_url,
				'blogname'         => $this->get_blogname(),
				'sent_to_admin'    => false,

				'plain_text'       => true,
				'email'            => $this,
			]
		);
	}

	/**
	 * Generate set password URL link for a new user.
	 *
	 * @return string
	 */
	protected function generate_set_password_url() {
		// Generate a magic link so user can set initial password.
		$key = get_password_reset_key( $this->object );
		if ( ! is_wp_error( $key ) ) {
			$action = 'newaccount';
			return wc_get_account_endpoint_url( 'lost-password' ) . "?action=$action&key=$key&login=" . rawurlencode( $this->object->user_login );
		} else {
			// Something went wrong while getting the key for new password URL, send customer to the generic password reset.
			return wc_get_account_endpoint_url( 'lost-password' );
		}
	}
}
