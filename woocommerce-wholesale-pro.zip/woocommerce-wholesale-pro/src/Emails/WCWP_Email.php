<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Emails;

use WC_Email;

/**
 * Extend WC_Emails to add our general requirements for customisation across all emails
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class WCWP_Email extends WC_Email {

	/**
	 * The template directory.
	 *
	 * @var string
	 */
	protected $template_directory;

	/**
	 * Placeholder descriptions
	 *
	 * @var array
	 */
	protected $placeholders_desc;

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Locate our template for sending the mails
	 *
	 * @param string $template
	 * @param string $template_name
	 * @param string $template_path
	 * @return string $template
	 */
	public function handle_locate_template( $template, $template_name, $template_path ) {
		if ( in_array( $template_name, [ $this->template_html, $this->template_plain ], true ) ) {
			return $this->template_directory . $template_name;
		}

		return $template;
	}

	/**
	 * Load our custom template as the core template for settings page
	 *
	 * @param string $file
	 * @param string $template
	 * @param string $template_base
	 * @param string $template_id
	 * @return string $file
	 */
	public function handle_locate_core_template( $file, $template, $template_base, $template_id ) {
		if ( $template_id === $this->id ) {
			return $this->template_directory . $template;
		}

		return $file;
	}

	/**
	 * Return content from the body_content field.
	 *
	 * @return string
	 */
	public function get_body_content() {
		$content = $this->get_option( 'body_content', '' );

		/**
		 * Filters the body content of a wholesale email.
		 *
		 * @param string $content The body content.
		 * @param object|bool $object The object the email is for (e.g customer).
		 * @param \WC_Email $email The email object.
		 */
		return apply_filters( 'wcwp_email_body_content_' . $this->id, $this->format_string( $content ), $this->object, $this );
	}

	/**
	 * Default email content
	 *
	 * @return string
	 */
	public function get_default_body_content() {
		return '';
	}

	/**
	 * Initialise settings form fields.
	 */
	public function init_form_fields() {
		/* translators: %s: list of placeholders */
		$placeholder_text  = sprintf( __( 'Available placeholders: %s', 'woocommerce-wholesale-pro' ), '<code>' . \implode( '</code>, <code>', \array_keys( $this->placeholders ) ) . '</code>' );
		$this->form_fields = [
			'enabled'      => [
				'title'   => __( 'Enable/Disable', 'woocommerce-wholesale-pro' ),
				'type'    => 'checkbox',
				'label'   => __( 'Enable this email notification', 'woocommerce-wholesale-pro' ),
				'default' => 'yes',
			],
			'subject'      => [
				'title'       => __( 'Subject', 'woocommerce-wholesale-pro' ),
				'type'        => 'text',
				'desc_tip'    => true,
				'description' => $placeholder_text,
				'placeholder' => $this->get_default_subject(),
				'default'     => '',
			],
			'heading'      => [
				'title'       => __( 'Email heading', 'woocommerce-wholesale-pro' ),
				'type'        => 'text',
				'desc_tip'    => true,
				'description' => $placeholder_text,
				'placeholder' => $this->get_default_heading(),
				'default'     => '',
			],
			'body_content' => [
				'title'       => __( 'Email content', 'woocommerce-wholesale-pro' ),
				'description' => __( 'Text to appear as the main email content.', 'woocommerce-wholesale-pro' ) . ' ' . $placeholder_text,
				'css'         => 'width:400px; height: 200px;',
				'placeholder' => __( 'N/A', 'woocommerce-wholesale-pro' ),
				'type'        => 'textarea',
				'default'     => $this->get_default_body_content(),
				'desc_tip'    => true,
			],
			'email_type'   => [
				'title'       => __( 'Email type', 'woocommerce-wholesale-pro' ),
				'type'        => 'select',
				'description' => __( 'Choose which format of email to send.', 'woocommerce-wholesale-pro' ),
				'default'     => 'html',
				'class'       => 'email_type wc-enhanced-select',
				'options'     => $this->get_email_type_options(),
				'desc_tip'    => true,
			],
		];
	}

	/**
	 * Admin Options.
	 *
	 * We make a slight modification to the core admin options, so that the back link goes to our custom emails list
	 */
	public function admin_options() {
		// Do admin actions.
		$this->admin_actions();

		$return_url = admin_url( 'admin.php?page=wc-settings&tab=email' );
		$wholesale  = filter_input( INPUT_GET, 'wholesale', FILTER_SANITIZE_FULL_SPECIAL_CHARS );

		if ( $wholesale ) {
			$return_url = admin_url( 'admin.php?page=wc-settings&tab=wholesale-pro&section=emails' );
		}
		?>
		<h2><?php echo esc_html( $this->get_title() ); ?> <?php wc_back_link( __( 'Return to emails', 'woocommerce-wholesale-pro' ), $return_url ); ?></h2>

		<?php echo wpautop( wp_kses_post( $this->get_description() ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

		<?php
		do_action( 'woocommerce_email_settings_before', $this );
		?>

		<table class="form-table">
			<?php $this->generate_settings_html(); ?>
		</table>

		<div id="merge-tags-list">
			<?php $this->generate_merge_tags_list(); ?>
		</div>

		<?php
		do_action( 'woocommerce_email_settings_after', $this );
		?>

		<?php

		if ( current_user_can( 'edit_themes' ) && ( ! empty( $this->template_html ) || ! empty( $this->template_plain ) ) ) {
			?>
			<div id="template">
				<?php
				$templates = [
					'template_html'  => __( 'HTML template', 'woocommerce-wholesale-pro' ),
					'template_plain' => __( 'Plain text template', 'woocommerce-wholesale-pro' ),
				];

				foreach ( $templates as $template_type => $title ) :
					$template = $this->get_template( $template_type );

					if ( empty( $template ) ) {
						continue;
					}

					$local_file    = $this->get_theme_template_file( $template );
					$core_file     = $this->template_base . $template;
					$template_file = apply_filters( 'woocommerce_locate_core_template', $core_file, $template, $this->template_base, $this->id );
					$template_dir  = apply_filters( 'woocommerce_template_directory', 'woocommerce', $template );

					?>
					<div class="template <?php echo esc_attr( $template_type ); ?>">
						<h4><?php echo wp_kses_post( $title ); ?></h4>

						<?php if ( file_exists( $local_file ) ) : ?>
							<p>
								<a href="#" class="button toggle_editor"></a>

								<?php if ( is_writable( $local_file ) ) : // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable ?>
									<a href="<?php echo esc_url( wp_nonce_url( remove_query_arg( [ 'move_template', 'saved' ], add_query_arg( 'delete_template', $template_type ) ), 'woocommerce_email_template_nonce', '_wc_email_nonce' ) ); ?>" class="delete_template button">
										<?php esc_html_e( 'Delete template file', 'woocommerce-wholesale-pro' ); ?>
									</a>
								<?php endif; ?>

								<?php
								/* translators: %s: Path to template file */
								printf( esc_html__( 'This template has been overridden by your theme and can be found in: %s.', 'woocommerce-wholesale-pro' ), '<code>' . esc_html( trailingslashit( basename( get_stylesheet_directory() ) ) . $template_dir . '/' . $template ) . '</code>' );
								?>
							</p>

							<div class="editor" style="display:none">
								<textarea class="code" cols="25" rows="20"
								<?php
								if ( ! is_writable( $local_file ) ) : // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
									?>
									readonly="readonly" disabled="disabled"
								<?php else : ?>
									data-name="<?php echo esc_attr( $template_type ) . '_code'; ?>"<?php endif; ?>><?php echo esc_html( file_get_contents( $local_file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents ?></textarea>
							</div>
						<?php elseif ( file_exists( $template_file ) ) : ?>
							<p>
								<a href="#" class="button toggle_editor"></a>

								<?php
								$emails_dir    = get_stylesheet_directory() . '/' . $template_dir . '/emails';
								$templates_dir = get_stylesheet_directory() . '/' . $template_dir;
								$theme_dir     = get_stylesheet_directory();

								if ( is_dir( $emails_dir ) ) {
									$target_dir = $emails_dir;
								} elseif ( is_dir( $templates_dir ) ) {
									$target_dir = $templates_dir;
								} else {
									$target_dir = $theme_dir;
								}

								if ( is_writable( $target_dir ) ) : // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_is_writable
									?>
									<a href="<?php echo esc_url( wp_nonce_url( remove_query_arg( [ 'delete_template', 'saved' ], add_query_arg( 'move_template', $template_type ) ), 'woocommerce_email_template_nonce', '_wc_email_nonce' ) ); ?>" class="button">
										<?php esc_html_e( 'Copy file to theme', 'woocommerce-wholesale-pro' ); ?>
									</a>
								<?php endif; ?>

								<?php
								/* translators: 1: Path to template file 2: Path to theme folder */
								printf( esc_html__( 'To override and edit this email template copy %1$s to your theme folder: %2$s.', 'woocommerce-wholesale-pro' ), '<code>' . esc_html( plugin_basename( $template_file ) ) . '</code>', '<code>' . esc_html( trailingslashit( basename( get_stylesheet_directory() ) ) . $template_dir . '/' . $template ) . '</code>' );
								?>
							</p>

							<div class="editor" style="display:none">
								<textarea class="code" readonly="readonly" disabled="disabled" cols="25" rows="20"><?php echo esc_html( file_get_contents( $template_file ) );  // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents ?></textarea>
							</div>
						<?php else : ?>
							<p><?php esc_html_e( 'File was not found.', 'woocommerce-wholesale-pro' ); ?></p>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>

			<?php
			$script_handle = 'wcwp-email-template';
			wp_register_script( $script_handle, '', [ 'jquery' ], false, true );
			wp_enqueue_script( $script_handle );
			wp_add_inline_script(
				$script_handle,
				"( ($) => {
					jQuery( 'select.email_type' ).on( 'change', function() {

						var val = jQuery( this ).val();

						jQuery( '.template_plain, .template_html' ).show();

						if ( val != 'multipart' && val != 'html' ) {
							jQuery('.template_html').hide();
						}

						if ( val != 'multipart' && val != 'plain' ) {
							jQuery('.template_plain').hide();
						}

					}).trigger( 'change' );

					var view = '" . esc_js( __( 'View template', 'woocommerce-wholesale-pro' ) ) . "';
					var hide = '" . esc_js( __( 'Hide template', 'woocommerce-wholesale-pro' ) ) . "';

					jQuery( 'a.toggle_editor' ).text( view ).on( 'click', function() {
						var label = hide;

						if ( jQuery( this ).closest(' .template' ).find( '.editor' ).is(':visible') ) {
							var label = view;
						}

						jQuery( this ).text( label ).closest(' .template' ).find( '.editor' ).slideToggle();
						return false;
					} );

					jQuery( 'a.delete_template' ).on( 'click', function() {
						if ( window.confirm('" . esc_js( __( 'Are you sure you want to delete this template file?', 'woocommerce-wholesale-pro' ) ) . "') ) {
							return true;
						}

						return false;
					});

					jQuery( '.editor textarea' ).on( 'change', function() {
						var name = jQuery( this ).attr( 'data-name' );

						if ( name ) {
							jQuery( this ).attr( 'name', name );
						}
					});
				})( jQuery );
				"
			);
		}
	}

	/**
	 * Outputs a list of available merge tags.
	 */
	protected function generate_merge_tags_list() {
		if ( ! isset( $this->placeholders ) && ! isset( $this->placeholders_desc ) ) {
			return;
		}

		if ( empty( $this->placeholders ) ) {
			return;
		}

		$output = sprintf( '<h4>%1$s</h4><p>%2$s</p>', __( 'Available placeholders', 'woocommerce-wholesale-pro' ), __( 'Personalize the email subject, header and content with the following placeholders:', 'woocommerce-wholesale-pro' ) );

		foreach ( $this->placeholders as $tag => $value ) {
			if ( ! isset( $this->placeholders_desc[ $tag ] ) ) {
				continue;
			}

			$output .= sprintf( '<code>%1$s</code> - %2$s<br>', $tag, $this->placeholders_desc[ $tag ] );
		}

		print( wp_kses(
			$output,
			[
				'h4'   => [],
				'code' => [],
				'p'    => [],
				'br'   => [],
			]
		) );
	}
}
