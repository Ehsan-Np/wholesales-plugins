<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Emails;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

/**
 * General Email Functions
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Emails implements Registerable, Standard_Service {

	/**
	 * The template directory.
	 *
	 * @var string
	 */
	private $template_directory;

	/**
	 * Constructor.
	 *
	 * @param string $template_directory
	 */
	public function __construct( $template_directory ) {
		$this->template_directory = $template_directory;
		add_filter( 'woocommerce_email_classes', [ $this, 'register_email_classes' ] );
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {

		add_filter( 'woocommerce_email_actions', [ $this, 'register_email_actions' ] );
		add_action( 'current_screen', [ $this, 'init_wc_emails' ] );
	}

	/**
	 * Registers the wholesale emails with WooCommercer
	 *
	 * @param   WC_Email[] $email_classes
	 * @return  WC_Email[] $email_classes
	 */
	public function register_email_classes( $email_classes ) {
		$email_classes['WCWP_Admin_New_User']                 = new Admin_New_User( $this->template_directory );
		$email_classes['WCWP_Customer_New_Account']           = new Customer_New_Account( $this->template_directory );
		$email_classes['WCWP_Customer_Registration_Approved'] = new Customer_Registration_Approved( $this->template_directory );
		$email_classes['WCWP_Customer_Registration_Declined'] = new Customer_Registration_Declined( $this->template_directory );
		$email_classes['WCWP_Customer_Registration_Pending']  = new Customer_Registration_Pending( $this->template_directory );

		return $email_classes;
	}

	/**
	 * Register the actions which trigger the mails
	 *
	 * @param array $actions
	 * @return array $new_actions
	 */
	public function register_email_actions( $actions ) {
		$new_actions = array_merge(
			$actions,
			[
				'wcwp_new_user_moderation',
				'wcwp_new_user_auto_approved',
				'wcwp_user_after_approved',
				'wcwp_user_before_reject',
			]
		);

		return $new_actions;
	}

	/**
	 * We need to initialise this seperately in order to over the wp_new_user_notification email (load order!).
	 *
	 * @param WP_Screen $current_screen
	 */
	public function init_wc_emails( $current_screen ) {
		if ( $current_screen->base !== 'user' ) {
			return;
		}

		\WC_Emails::instance();
	}
}
