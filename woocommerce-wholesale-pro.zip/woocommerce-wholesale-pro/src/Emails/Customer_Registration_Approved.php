<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Emails;

use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use WP_User;

/**
 * Registration approved email for customer.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Customer_Registration_Approved extends WCWP_Email implements Registerable {

	/**
	 * User login name.
	 *
	 * @var string
	 */
	public $user_login;

	/**
	 * User email.
	 *
	 * @var string
	 */
	public $user_email;

	/**
	 * User password.
	 *
	 * @var string
	 */
	public $user_pass;

	/**
	 * Set password URL
	 *
	 * @var string
	 */
	public $set_password_url;


	/**
	 * Constructor.
	 *
	 * @param string $template_directory
	 */
	public function __construct( $template_directory ) {
		$this->id                 = 'wcwp_customer_registration_approved';
		$this->customer_email     = true;
		$this->title              = __( 'Wholesale registration approved', 'woocommerce-wholesale-pro' );
		$this->description        = __( 'Customer "Wholesale user approved" emails are sent to the customer when an administrator or store manager approves their wholesale registration.', 'woocommerce-wholesale-pro' );
		$this->template_html      = 'emails/wholesale-registration-approved.php';
		$this->template_plain     = 'emails/plain/wholesale-registration-approved.php';
		$this->template_directory = $template_directory;
		$this->placeholders       = [
			'{user_pass}'        => '',
			'{user_login}'       => '',
			'{login_url}'        => Util::get_wholesale_login_url(),
			'{set_password_url}' => '',
		];
		$this->placeholders_desc  = [
			'{user_pass}'        => __( 'The password for the new account.', 'woocommerce-wholesale-pro' ),
			'{user_login}'       => __( 'The username for the new account.', 'woocommerce-wholesale-pro' ),
			'{login_url}'        => __( 'The URL to the login page.', 'woocommerce-wholesale-pro' ),
			'{set_password_url}' => __( 'The URL to the set password page.', 'woocommerce-wholesale-pro' ),
		];
		parent::__construct();

		$this->register();
	}

	/**
	 * Register hooks.
	 */
	public function register() {
		add_filter( 'woocommerce_locate_core_template', [ $this, 'handle_locate_core_template' ], 10, 4 );
		add_filter( 'woocommerce_locate_template', [ $this, 'handle_locate_template' ], 10, 3 );
		add_action( 'wcwp_user_after_approved_notification', [ $this, 'trigger' ], 10, 2 );
	}

	/**
	 * Trigger.
	 *
	 * @param int    $user_id User ID.
	 * @param string $user_pass User Password.
	 */
	public function trigger( $user_id, $user_pass = '' ) {
		$this->setup_locale();

		if ( $user_id ) {
			$this->object           = new WP_User( $user_id );
			$this->user_pass        = $user_pass;
			$this->set_password_url = $this->generate_set_password_url();
			$this->user_login       = stripslashes( $this->object->user_login );
			$this->user_email       = stripslashes( $this->object->user_email );
			$this->recipient        = $this->user_email;

			$this->placeholders['{user_pass}']        = $this->user_pass;
			$this->placeholders['{user_login}']       = $this->user_email;
			$this->placeholders['{set_password_url}'] = $this->set_password_url;
		}

		if ( $this->is_enabled() && $this->get_recipient() ) {
			$this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		}

		$this->restore_locale();
	}

	/**
	 * Get email subject.
	 *
	 * @return string
	 */
	public function get_default_subject() {
		return __( 'Your wholesale user account has been approved', 'woocommerce-wholesale-pro' );
	}

	/**
	 * Get email heading.
	 *
	 * @return string
	 */
	public function get_default_heading() {
		return __( 'Welcome to the wholesale store!', 'woocommerce-wholesale-pro' );
	}

	/**
	 * Default email body content
	 *
	 * @return string
	 */
	public function get_default_body_content() {
		$content  = __( 'Thanks for registering for the wholesale store. Your account has now been approved and you can login as follows:', 'woocommerce-wholesale-pro' );
		$content .= "\n\n";
		$content .= sprintf( '%s {user_login}', __( 'Username:', 'woocommerce-wholesale-pro' ) );
		$content .= "\n\n";
		$content .= sprintf( '<a href="{set_password_url}">%s</a>', __( 'Click here to set your password.', 'woocommerce-wholesale-pro' ) );

		return $content;
	}

	/**
	 * Get content html.
	 *
	 * @return string
	 */
	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			[
				'email_heading'    => $this->get_heading(),
				'body_content'     => $this->get_body_content(),
				'user_login'       => $this->user_login,
				'user_pass'        => $this->user_pass,
				'set_password_url' => $this->set_password_url,
				'blogname'         => $this->get_blogname(),
				'sent_to_admin'    => false,
				'plain_text'       => false,
				'email'            => $this,
			]
		);
	}

	/**
	 * Get content plain.
	 *
	 * @return string
	 */
	public function get_content_plain() {
		return wc_get_template_html(
			$this->template_plain,
			[
				'email_heading'    => $this->get_heading(),
				'body_content'     => $this->get_body_content(),
				'user_login'       => $this->user_login,
				'user_pass'        => $this->user_pass,
				'set_password_url' => $this->set_password_url,
				'blogname'         => $this->get_blogname(),
				'sent_to_admin'    => false,
				'plain_text'       => true,
				'email'            => $this,
			]
		);
	}

	/**
	 * Generate set password URL link for a new user.
	 *
	 * @return string
	 */
	protected function generate_set_password_url() {
		// Generate a magic link so user can set initial password.
		$key = get_password_reset_key( $this->object );
		if ( ! is_wp_error( $key ) ) {
			$action = 'newaccount';
			return wc_get_account_endpoint_url( 'lost-password' ) . "?action=$action&key=$key&login=" . rawurlencode( $this->object->user_login );
		} else {
			// Something went wrong while getting the key for new password URL, send customer to the generic password reset.
			return wc_get_account_endpoint_url( 'lost-password' );
		}
	}
}
