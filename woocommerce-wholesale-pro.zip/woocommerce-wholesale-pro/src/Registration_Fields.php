<?php

namespace Barn2\Plugin\WC_Wholesale_Pro;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin\Tools_Tab;

/**
 * Handles the frontend display and saving of custom registration fields
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Registration_Fields implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'wcwp_register_form', [ $this, 'output_fields' ], 1 );
		add_action( 'wcwp_register_post', [ $this, 'validate_fields' ], 10, 3 );
		add_action( 'wcwp_created_customer', [ $this, 'save_fields' ], 10, 2 );
	}

	/**
	 * Output the fields on the registration form
	 */
	public function output_fields() {
		if ( Tools_Tab::is_form_visible() ) {
			return;
		}

		$fields = get_option( 'wcwp_registration_fields', [] );

		if ( empty( $fields ) ) {
			return;
		}

		foreach ( $fields as $unique_id => $field ) {
			woocommerce_form_field(
				$unique_id,
				[
					'type'     => 'text',
					'required' => $field['required'] === 'yes',
					'label'    => $field['label'],
				],
				isset( $_POST[ $unique_id ] ) ? $_POST[ $unique_id ] : ''
			);
		}
	}

	/**
	 * Validate the fields
	 *
	 * @param   string        $username
	 * @param   string        $email
	 * @param   \WP_Error     $errors
	 */
	public function validate_fields( $username, $email, $errors ) {
		if ( Tools_Tab::is_form_visible() ) {
			return;
		}

		$fields = get_option( 'wcwp_registration_fields', [] );

		foreach ( $fields as $unique_id => $field ) {
			if ( $field['required'] === 'yes' && empty( $_POST[ $unique_id ] ) ) {
				$errors->add( 'wcwp_required_field', 'Please provide values for the required fields.' );
			}
		}
	}

	/**
	 * Save the field data
	 *
	 * @param   int     $customer_id
	 * @param   array   $new_customer_data
	 */
	public function save_fields( $customer_id, $new_customer_data ) {
		if ( Tools_Tab::is_form_visible() ) {
			return;
		}

		$fields = get_option( 'wcwp_registration_fields', [] );

		foreach ( $fields as $unique_id => $field ) {
			if ( isset( $_POST[ $unique_id ] ) ) {
				update_user_meta( $customer_id, $unique_id, \wc_clean( $_POST[ $unique_id ] ) );
			}
		}
	}
}
