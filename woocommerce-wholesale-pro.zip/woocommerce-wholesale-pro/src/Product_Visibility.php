<?php

namespace Barn2\Plugin\WC_Wholesale_Pro;

use Barn2\Plugin\WC_Wholesale_Pro\Util;

/**
 * This class represents a WooCommerce product with various functions to test its visibility.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Product_Visibility {

	private $product;
	private $visibility = 'public';
	private $roles      = [];

	/**
	 * Constructor.
	 *
	 * @param \WC_Product $product
	 */
	public function __construct( \WC_Product $product ) {
		$this->product    = $product;
		$this->visibility = $product->get_meta( '_wwp_wholesale_visibility' );

		// Default to "Inherit/None" if visibility is not set.
		if ( empty( $this->visibility ) ) {
			$this->visibility = false;
		}

		$roles = [];

		if ( in_array( $this->visibility, [ 'wholesale_only', 'public_only' ], true ) ) {
			$roles = Util::get_wholesale_roles( 'editable' );
		}

		if ( $this->visibility === 'wholesale_only' ) {
			$roles = array_merge( [ 'shop_manager', 'administrator' ], $roles );
		}

		$this->roles = $roles ? (array) $roles : [];
	}

	/**
	 * Does this product have protection?
	 *
	 * @return boolean true if protected
	 */
	public function has_protection() {
		return $this->has_wholesale_protection() || $this->has_wholesale_exclusion() || $this->is_public();
	}

	/**
	 * Does this product have wholesale protection?
	 *
	 * @return boolean true if role protected
	 */
	public function has_wholesale_protection() {
		return 'wholesale_only' === $this->visibility && ! empty( $this->roles );
	}

	/**
	 * Does this product have wholesale exclusion?
	 *
	 * @return boolean true if role protected
	 */
	public function has_wholesale_exclusion() {
		return 'public_only' === $this->visibility && ! empty( $this->roles );
	}

	/**
	 * Is this product unlocked by password, role, user, or for private access?
	 *
	 * @return boolean true if unlocked.
	 */
	public function is_unlocked() {
		return $this->is_protection_unlocked() || $this->is_exclusion_unlocked() || $this->is_public_unlocked();
	}


	/**
	 * Is this product unlocked by role?
	 *
	 * @return boolean true if role protected and the current user has one of the required roles.
	 */
	public function is_protection_unlocked() {
		return $this->has_wholesale_protection() && $this->current_user_allowed_by_role();
	}

	/**
	 * Is this product unlocked by role?
	 *
	 * @return boolean true if role protected and the current user has one of the required roles.
	 */
	public function is_exclusion_unlocked() {
		return $this->has_wholesale_exclusion() && ! $this->current_user_allowed_by_role();
	}

	/**
	 * Is this public unlocked.
	 *
	 * @return bool
	 */
	public function is_public_unlocked() {
		return $this->is_public();
	}

	/**
	 * Is this product public?
	 *
	 * @return boolean true if public.
	 */
	public function is_public() {
		$public = ( 'public' === $this->visibility );

		return $public;
	}

	/**
	 * Is this product protected?
	 *
	 * @return boolean true if this product is protected.
	 */
	public function is_protected() {
		$protected = $this->has_protection();

		// If this product itself is unlocked, then it's not protected (regardless of parent protection level).
		if ( $protected && $this->is_unlocked() ) {
			return false;
		}

		return $protected;
	}

	/**
	 * Get product
	 *
	 * @return \WC_Product
	 */
	public function get_product() {
		return $this->product;
	}

	/**
	 * Get visibility.
	 *
	 * @return string
	 */
	public function get_visibility() {
		return $this->visibility;
	}

	/**
	 * Get roles.
	 *
	 * @return array
	 */
	public function get_roles() {
		return $this->roles;
	}

	/**
	 * Determine if the current user is allowed by role.
	 *
	 * @return boolean
	 */
	private function current_user_allowed_by_role() {
		// If there are no roles, then it can't be unlocked by role.
		if ( ! $this->roles ) {
			return false;
		}

		$allowed = false;

		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();

			// If there's a role overlap, then the current user has at least one of the required roles,
			// so product is unlocked or locked if wholesale exclusion (public_only).
			$allowed = count( array_intersect( $user->roles, $this->roles ) ) > 0;
		}

		/**
		 * Filters whether the wholesale user can view the product.
		 *
		 * @param bool $allowed Whether the user is allowed to view. Default is true.
		 * @param string $visibility The visibility type.
		 * @param int $term_id The term_id of the product.
		 */
		return apply_filters( 'wcwp_product_current_user_allowed_by_role', $allowed, $this->visibility, $this->product );
	}
}
