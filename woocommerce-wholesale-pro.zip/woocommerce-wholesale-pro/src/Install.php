<?php
namespace Barn2\Plugin\WC_Wholesale_Pro;

use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Role;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Schema\Field_Schema;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Upload\File_Handler;

use WP_User_Query;
use Automattic\WooCommerce\Utilities\OrderUtil;

/**
 * Handles install routines
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
final class Install {

	private static $db_updates = [
		'1.8.0' => [
			'update_180_wholesale_order_meta',
		],
	];

	/**
	 * Activation hook
	 *
	 * @param bool $network_wide
	 */
	public static function install( $network_wide ) {
		if ( function_exists( 'is_multisite' ) && is_multisite() && $network_wide && is_super_admin() ) {
			$sites = get_sites();
			foreach ( $sites as $site ) {
				switch_to_blog( $site->blog_id );

				self::create_roles();
				self::create_pages();
				self::update_db();
				Field_Schema::seed_defaults();
				File_Handler::ensure_private_dir();
				update_option( 'wcwp_trade_form_active', 'yes', false );

				restore_current_blog();
			}
		} else {
			self::create_roles();
			self::create_pages();
			self::update_db();
			Field_Schema::seed_defaults();
			File_Handler::ensure_private_dir();
			update_option( 'wcwp_trade_form_active', 'yes', false );
		}
	}

	/**
	 * Creates the wholesale roles.
	 */
	public static function create_roles() {
		// Add Pending Role
		add_role(
			'wcwp_pending',
			'Pending',
			[]
		);

		// Core wholesale role.
		add_role(
			'wcwp_wholesale',
			'Wholesale',
			[
				'read' => true,
			]
		);

		$wholesale_role = new Wholesale_Role( 'wcwp_wholesale' );

		$wholesale_role->update(
			[
				'default'         => 'yes',
				'product_pricing' => 'yes',
			]
		);
	}

	/**
	 * Create pages that the plugin relies on, storing page IDs in variables.
	 */
	public static function create_pages() {
		$pages = [
			'wholesale_login' => [
				'name'    => _x( 'wholesale-login', 'Page slug', 'woocommerce-wholesale-pro' ),
				'title'   => _x( 'Wholesale Login', 'Page title', 'woocommerce-wholesale-pro' ),
				/**
				 * Filters the login shortcode tag.
				 *
				 * @param string $tag The shortcode tag excluding the brackets.
				 */
				'content' => '<!-- wp:shortcode -->[' . apply_filters( 'wcwp_login_shortcode_tag', 'wholesale_login' ) . ']<!-- /wp:shortcode -->',
			],
			'wholesale_store' => [
				'name'    => _x( 'wholesale-store', 'Page slug', 'woocommerce-wholesale-pro' ),
				'title'   => _x( 'Wholesale Store', 'Page title', 'woocommerce-wholesale-pro' ),
				'content' => '',
			],
		];

		foreach ( $pages as $key => $page ) {
			Util::create_page( esc_sql( $page['name'] ), 'wcwp_' . $key . '_page_id', $page['title'], $page['content'], '' );
		}
	}

	public static function update_db() {
		$wcwp_db_version = get_option( 'wcwp_db_version', '' );

		foreach ( self::$db_updates as $version => $callbacks ) {
			if ( version_compare( $wcwp_db_version, $version, '<' ) ) {
				foreach ( $callbacks as $callback ) {
					WC()->queue()->add(
						'woocommerce_run_update_callback',
						[
							'update_callback' => [ __CLASS__, $callback ],
						],
						'wcwp-db-updates'
					);
				}
			}
		}

		// store the last key of $db_updates as the current db version
		get_option( 'wcwp_db_version', $version );
	}

	public static function update_180_wholesale_order_meta() {
		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && OrderUtil::custom_orders_table_usage_is_enabled() ) {
			return;
		}

		global $wpdb;

		$max_users = 50;
		$user_page = 0;

		do {
			$user_query = new WP_User_Query(
				[
					'role__in' => Util::get_wholesale_roles(),
					'number'   => $max_users,
					'offset'   => $max_users * $user_page,
					'fields'   => 'ID',
				]
			);

			$users      = $user_query->results;
			$user_count = count( $users );

			foreach ( $users as $user_id ) {
				$wpdb->query(
					$wpdb->prepare(
						"
						INSERT INTO $wpdb->postmeta ( post_id, meta_key, meta_value )
						SELECT ID, '_wholesale', 1 FROM $wpdb->posts as posts
						INNER JOIN $wpdb->postmeta as meta1 ON meta1.post_id = posts.ID
						LEFT JOIN $wpdb->postmeta as meta2 ON meta2.post_id = posts.ID AND meta2.meta_key = '_wholesale'
						WHERE meta1.meta_key = '_customer_user' AND meta1.meta_value = %d AND ( meta2.meta_key IS NULL OR meta2.meta_value = '' )
						",
						$user_id
					)
				);
			}

			$user_page++;
		} while ( $user_count === $max_users );
	}
}
