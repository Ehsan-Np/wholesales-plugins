<?php

namespace Barn2\Plugin\WC_Wholesale_Pro;

use Barn2\Plugin\WC_Wholesale_Pro\Util;

/**
 * This class represents a WooCommerce category with various functions to test its visibility.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Category_Visibility {

	private $term_id;
	private $visibility  = 'public';
	private $roles       = [];
	private $ancestors   = null;
	private $hide_prices = '';

	/**
	 * Constructor.
	 *
	 * @param string|int $term_id
	 */
	public function __construct( $term_id ) {
		$this->term_id     = absint( $term_id );
		$this->visibility  = get_term_meta( $this->term_id, 'wcwp_visibility', true );
		$this->hide_prices = get_term_meta( $this->term_id, 'wcwp_hide_prices', true );

		// Default to public and wholesale (essentially public) if visibility not set.
		if ( ! $this->visibility ) {
			$this->visibility = 'public';
		}

		$roles = [];

		if ( in_array( $this->visibility, [ 'wholesale_only', 'public_only' ], true ) ) {
			$roles = Util::get_wholesale_roles( 'editable' );
		}

		if ( $this->visibility === 'wholesale_only' ) {
			$roles = array_merge( [ 'shop_manager', 'administrator' ], $roles );
		}

		$this->roles = $roles ? (array) $roles : [];
	}

	/**
	 * Get the ancestors for this category as an array of Category_Visibility objects.
	 *
	 * @return array An array of Category_Visibility objects or an empty array if no ancestors.
	 */
	public function ancestors() {
		// Lazy loaded so we only do this once
		if ( null === $this->ancestors ) {
			$this->ancestors = Util::to_category_visibilities( get_ancestors( $this->term_id, 'product_cat', 'taxonomy' ) );
		}

		return $this->ancestors;
	}

	/**
	 * Does this category have protection?
	 *
	 * @return boolean true if protected
	 */
	public function has_protection() {
		return $this->has_wholesale_protection() || $this->has_wholesale_exclusion();
	}

	/**
	 * Does this category have role protection?
	 *
	 * @return boolean true if role protected
	 */
	public function has_wholesale_protection() {
		return 'wholesale_only' === $this->visibility && ! empty( $this->roles );
	}

	/**
	 * Does this category have role protection?
	 *
	 * @return boolean true if role protected
	 */
	public function has_wholesale_exclusion() {
		return 'public_only' === $this->visibility && ! empty( $this->roles );
	}

	/**
	 * Is this category unlocked by password, role, user, or for private access?
	 *
	 * @return boolean true if unlocked.
	 */
	public function is_unlocked() {
		return $this->is_protection_unlocked() || $this->is_exclusion_unlocked();
	}


	/**
	 * Is this category unlocked by role?
	 *
	 * @return boolean true if role protected and the current user has one of the required roles.
	 */
	public function is_protection_unlocked() {
		return $this->has_wholesale_protection() && $this->current_user_allowed_by_role();
	}

	/**
	 * Is this category unlocked by role?
	 *
	 * @return boolean true if role protected and the current user has one of the required roles.
	 */
	public function is_exclusion_unlocked() {
		return $this->has_wholesale_exclusion() && ! $this->current_user_allowed_by_role();
	}

	/**
	 * Is this category public?
	 *
	 * If $check_ancestors is true, and this category is public, all ancestor categories will also be
	 * checked. If any are not public, then this function returns false.
	 *
	 * @param boolean $check_ancestors Whether the check the ancestors as well.
	 * @return boolean true if public.
	 */
	public function is_public( $check_ancestors = false ) {
		$public = ( 'public' === $this->visibility );

		// Only check ancestors if flag set and this category is public
		if ( $public && $check_ancestors ) {
			foreach ( $this->ancestors() as $ancestor ) {
				if ( ! $ancestor->is_public( false ) ) {
					return false;
				}
			}
		}

		return $public;
	}

	/**
	 * Is the price of products belonging to this category hidden?
	 *
	 * If $check_ancestors is true, and this category is set to global (i.e. empty string), all ancestor categories will also be
	 * checked. If any are set to 'hide', then this function returns true.
	 *
	 * @param boolean $check_ancestors Whether the check the ancestors as well.
	 * @return boolean true if price is hidden.
	 */
	public function is_price_hidden( $check_ancestors = false ) {
		$hide_prices = null;

		if ( '' !== $this->hide_prices ) {
			$hide_prices = ( 'hide' === $this->hide_prices );
		} elseif ( $check_ancestors ) {
			foreach ( $this->ancestors() as $ancestor ) {
				$hide_prices = $ancestor->is_price_hidden( false );
				if ( ! is_null( $hide_prices ) ) {
					return $hide_prices;
				}
			}
		}

		return $hide_prices;
	}

	/**
	 * Is this category protected?
	 *
	 * If $check_ancestors is true, and this category is not protected, its ancestor categories will
	 * also be checked. The function halts once the first protected ancestor is found.
	 *
	 * @param boolean $check_ancestors Whether to check the ancestor categories as well (if any).
	 * @return boolean true if this category is protected.
	 */
	public function is_protected( $check_ancestors = false ) {
		$protected = $this->has_protection();

		// If this category itself is unlocked, then it's not protected (regardless of parent protection level).
		if ( $protected && $this->is_unlocked() ) {
			return false;
		}

		// Only check ancestors if flag set and this category itself is not protected.
		if ( ! $protected && $check_ancestors ) {
			foreach ( $this->ancestors() as $ancestor ) {
				if ( $ancestor->is_protected( false ) ) {
					return true;
				}
			}
		}

		return $protected;
	}

	/**
	 * Is this category protected by user role?
	 *
	 * @param boolean $check_ancestors Whether to check the ancestor categories as well (if any).
	 * @return boolean true if this category is role protected.
	 */
	public function is_role_protected( $check_ancestors = false ) {
		$role_protected = $this->has_wholesale_protection();

		if ( $role_protected && $this->current_user_allowed_by_role() ) {
			return false;
		}

		// Only check ancestors if flag set and this category itself is not role protected
		if ( ! $role_protected && $check_ancestors ) {
			foreach ( $this->ancestors() as $ancestor ) {
				if ( $ancestor->is_role_protected( false ) ) {
					return true;
				}
			}
		}

		return $role_protected;
	}

	/**
	 * Get term ID.
	 *
	 * @return int
	 */
	public function get_term_id() {
		return $this->term_id;
	}

	/**
	 * Get visibility.
	 *
	 * @return string
	 */
	public function get_visibility() {
		return $this->visibility;
	}

	/**
	 * Get hide price until login option.
	 *
	 * @return string
	 */
	public function get_hide_prices() {
		return $this->hide_prices;
	}

	/**
	 * Get roles.
	 *
	 * @return array
	 */
	public function get_roles() {
		return $this->roles;
	}

	/**
	 * Determine if the current user is allowed by orle.
	 *
	 * @return boolean
	 */
	private function current_user_allowed_by_role() {
		// If there are no roles, then it can't be unlocked by role.
		if ( ! $this->roles ) {
			return false;
		}

		$allowed = false;

		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();

			// If there's a role overlap, then the current user has at least one of the required roles,
			// so category is unlocked or locked if wholesale exclusion (public_only).
			$allowed = count( array_intersect( $user->roles, $this->roles ) ) > 0;
		}

		/**
		 * Filters whether the wholesale user can view the category.
		 *
		 * @param bool $allowed Whether the user is allowed to view. Default is true.
		 * @param string $visibility The visibility type.
		 * @param int $term_id The term_id of the category.
		 */
		return apply_filters( 'wcwp_category_current_user_allowed_by_role', $allowed, $this->visibility, $this->term_id );
	}
}
