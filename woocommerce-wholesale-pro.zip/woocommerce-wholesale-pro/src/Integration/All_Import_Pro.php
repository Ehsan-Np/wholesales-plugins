<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Integration;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

/**
 * Handles integration with WP All Import Pro
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class All_Import_Pro implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'pmxi_saved_post', [ $this, 'clear_pricing_cache' ], 10, 3 );
	}

	/**
	 * Clear the pricing cache after import.
	 *
	 * @param int $post_id
	 * @param mixed $xml_node
	 * @param bool $is_update
	 */
	public function clear_pricing_cache( $post_id, $xml_node, $is_update ) {
		if ( ! $is_update ) {
			return;
		}

		$product = wc_get_product( $post_id );

		if ( ! $product ) {
			return;
		}

		/**
		 * Triggered after WP All Import updates a product.
		 *
		 * @param int $post_id The post_id of the product imported.
		 */
		do_action( 'wcwp_all_import_update_product', $post_id );
	}
}
