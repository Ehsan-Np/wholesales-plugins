<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Integration;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

/**
 * Handles integration with WooCommerce Multilingual
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class WooCommerce_Multilingual implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'wcwp_calculated_wholesale_price', [ $this, 'convert_price' ], 10, 1 );
	}

	/**
	 * Convert the price for WC ML
	 *
	 * @param mixed $price
	 * @return mixed
	 */
	public function convert_price( $price ) {
		if ( $price === false ) {
			return $price;
		}

		return apply_filters( 'wcml_raw_price_amount', $price );
	}
}
