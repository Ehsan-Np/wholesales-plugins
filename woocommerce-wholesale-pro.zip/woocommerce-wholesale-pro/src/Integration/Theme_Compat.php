<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Integration;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Util as Lib_Util;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Product_Table\Template_Handler as WPT_Template_Handler;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

use function Barn2\Plugin\WC_Wholesale_Pro\woocommerce_wholesale_pro;

/**
 * Theme-specific overrides for WooCommerce Wholesale Pro
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Theme_Compat implements Registerable, Standard_Service {

	/**
	 * The template name of the current theme.
	 *
	 * @var string
	 */
	private $template = '';

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		$this->template = strtolower( get_template() );

		if ( Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Product_Table\wpt' ) ) {
			add_action( 'wcwp_enable_wholesale_store_table_layout', [ $this, 'enable_table_layout' ] );
			add_action( 'wcwp_disable_wholesale_store_table_layout', [ $this, 'disable_table_layout' ] );
		}

		switch ( $this->template ) {
			case 'flatsome':
				add_filter( 'wcwp_login_register_columns_wrap_class', [ $this, 'flatsome_login_register_columns_wrap_class' ] );
				add_filter( 'wcwp_login_column_class', [ $this, 'flatsome_login_column_class' ] );
				add_filter( 'wcwp_register_column_class', [ $this, 'flatsome_register_column_class' ] );

				add_filter( 'do_shortcode_tag', [ $this, 'flatsome_hide_price_ux_add_to_cart' ], 10, 2 );
				break;

			case 'woodmart':
				add_filter( 'wcwp_login_register_columns_wrap_class', [ $this, 'bootstrap_login_register_columns_wrap_class' ] );
				add_filter( 'wcwp_login_column_class', [ $this, 'bootstrap_login_column_class' ] );
				add_filter( 'wcwp_register_column_class', [ $this, 'bootstrap_register_column_class' ] );
				add_action( 'wp_head', [ $this, 'bootstrap_login_register_css' ] );
				break;

			case 'divi':
				add_filter( 'wcwp_disregard_wholesale_pricing', [ $this, 'divi_disregard_wholesale_price' ], 10, 2 );
				break;

			case 'avada':
				add_action( 'awb_before_woo_add_to_cart_content', [ $this, 'hide_price' ] );
				break;
		}

		add_action(
			'elementor/widget/before_render_content',
			function ( $widget ) {
				if ( $widget->get_name() === 'woocommerce-product-add-to-cart' ) {
					$this->hide_price();
				}
			}
		);
	}

	public function enable_table_layout() {
		switch ( $this->template ) {
			case 'genesis':
				// Replace Genesis loop with product table
				remove_action( 'genesis_loop', 'genesis_do_loop' );
				add_action( 'genesis_loop', [ WPT_Template_Handler::class, 'add_product_table_after_shop_loop' ] );
				break;

			case 'storefront':
				remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 10 );
				remove_action( 'woocommerce_after_shop_loop', 'woocommerce_catalog_ordering', 10 );
				remove_action( 'woocommerce_before_shop_loop', 'storefront_sorting_wrapper', 9 );
				remove_action( 'woocommerce_before_shop_loop', 'storefront_sorting_wrapper_close', 31 );
				remove_action( 'woocommerce_after_shop_loop', 'storefront_sorting_wrapper', 9 );
				remove_action( 'woocommerce_after_shop_loop', 'storefront_sorting_wrapper_close', 31 );
				break;

			case 'avada':
				global $avada_woocommerce;

				if ( ! empty( $avada_woocommerce ) ) {
					remove_action( 'woocommerce_before_shop_loop', [ $avada_woocommerce, 'catalog_ordering' ], 30 );
				}
				break;

			case 'xstore':
				remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
				remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
				remove_action( 'woocommerce_before_shop_loop', 'etheme_grid_list_switcher', 35 );
				remove_action( 'woocommerce_before_shop_loop', 'etheme_products_per_page_select', 37 );
				break;

			default:
				remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
		}
	}

	public function disable_table_layout() {
		switch ( $this->template ) {
			case 'genesis':
				// Replace Genesis loop with product table
				add_action( 'genesis_loop', 'genesis_do_loop' );
				remove_action( 'genesis_loop', [ WPT_Template_Handler::class, 'add_product_table_after_shop_loop' ] );
				break;

			case 'storefront':
				add_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 10 );
				add_action( 'woocommerce_after_shop_loop', 'woocommerce_catalog_ordering', 10 );
				add_action( 'woocommerce_before_shop_loop', 'storefront_sorting_wrapper', 9 );
				add_action( 'woocommerce_before_shop_loop', 'storefront_sorting_wrapper_close', 31 );
				add_action( 'woocommerce_after_shop_loop', 'storefront_sorting_wrapper', 9 );
				add_action( 'woocommerce_after_shop_loop', 'storefront_sorting_wrapper_close', 31 );
				break;

			case 'avada':
				global $avada_woocommerce;

				if ( ! empty( $avada_woocommerce ) ) {
					add_action( 'woocommerce_before_shop_loop', [ $avada_woocommerce, 'catalog_ordering' ], 30 );
				}
				break;

			case 'xstore':
				add_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
				add_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
				add_action( 'woocommerce_before_shop_loop', 'etheme_grid_list_switcher', 35 );
				add_action( 'woocommerce_before_shop_loop', 'etheme_products_per_page_select', 37 );
				break;

			default:
				add_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
		}
	}

	/**
	 * Add classes for login register form.
	 *
	 * @param string $class
	 * @return string
	 */
	public function flatsome_login_register_columns_wrap_class( $class ) {
		return 'col2-set row row-divided row-large';
	}

	/**
	 * Add classes for login register form.
	 *
	 * @param string $class
	 * @return string
	 */
	public function flatsome_login_column_class( $class ) {
		return 'col-1 large-6 col pb-0';
	}

	/**
	 * Add classes for login register form.
	 *
	 * @param string $class
	 * @return string
	 */
	public function flatsome_register_column_class( $class ) {
		return 'col-2 large-6 col pb-0';
	}

	/**
	 * Add classes for login register form.
	 *
	 * @param string $class
	 * @return string
	 */
	public function bootstrap_login_register_columns_wrap_class( $class ) {
		return 'row row-divided row-large';
	}

	/**
	 * Add classes for login register form.
	 *
	 * @param string $class
	 * @return string
	 */
	public function bootstrap_login_column_class( $class ) {
		return 'col col-12 col-sm-6';
	}

	/**
	 * Add classes for login register form.
	 *
	 * @param string $class
	 * @return string
	 */
	public function bootstrap_register_column_class( $class ) {
		return 'col col-12 col-sm-6 mt-2 mt-sm-0';
	}

	public function bootstrap_login_register_css() {
		if ( Util::is_wholesale_login_page() ) {
			?>
			<style>
				.mt-2 {
					margin-top: 50px;
				}

				@media screen and (min-width: 576px) {
					.mt-sm-0 {
						margin-top: 0;
					}
				}
			</style>
			<?php
		}
	}

	/**
	 * The hide price till login feature relies on the 'woocommerce_single_product_summary' hook.
	 *
	 * In some cases the user might use the Flatsome UX Builder shortcodes in which case we need
	 * to filter the [ux_product_add_to_cart] shortcode directly.
	 *
	 * @param string $output
	 * @param string $tag
	 */
	public function flatsome_hide_price_ux_add_to_cart( $output, $tag ) {
		if ( 'ux_product_add_to_cart' !== $tag ) {
			return $output;
		}

		global $product;

		if ( Util::is_price_hidden( $product ) ) {
			ob_start();

			?>
			<style>
				.wcwp-alternate-content {
					display: block;
					overflow: auto;
				}
			</style>
			<?php

			printf( '<div class="wcwp-alternate-content">%s</div>', wp_kses_post( get_option( 'wcwp_hide_prices_text', '' ) ) );

			return ob_get_clean();
		}

		return $output;
	}

	public function divi_disregard_wholesale_price( $disregard, $product ) {
		if (
			is_user_logged_in() &&
			Util::is_wholesale_user() &&
			is_cart() &&
			did_action( 'et_theme_builder_template_before_body' ) > did_action( 'et_theme_builder_template_after_body' )
		) {
			$disregard = did_action( 'woocommerce_before_cart' ) === did_action( 'woocommerce_after_cart' );
		}

		return $disregard;
	}

	public function hide_price() {
		$hide_prices_service = woocommerce_wholesale_pro()->get_service( 'hide_prices' );
		$hide_prices_service->hide_price();

		if ( Util::is_price_hidden() ) {
			$hide_prices_service->render_alternate_content();
		}
	}
}
