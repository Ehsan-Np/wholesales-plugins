<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Integration;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

/**
 * Handles integration with All in One SEO
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class AIO_SEO implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'aioseo_conflicting_shortcodes', [ $this, 'add_wcwp_shortcodes' ], 10, 1 );
	}

	/**
	 * Add WCWP shortcodes to no conflict.
	 *
	 * @param array $shortcodes
	 * @return array
	 */
	public function add_wcwp_shortcodes( $shortcodes ) {
		return array_merge(
			$shortcodes,
			[
				apply_filters( 'wcwp_login_shortcode_tag', 'wholesale_login' ),
				apply_filters( 'wcwp_register_shortcode_tag', 'wholesale_registration' )
			]
		);
	}
}
