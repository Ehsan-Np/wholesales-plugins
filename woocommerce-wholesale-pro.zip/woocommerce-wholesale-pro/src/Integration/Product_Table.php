<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Integration;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Util as Lib_Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Product_Table\Util\Settings as WPT_Settings;
use Barn2\Plugin\WC_Product_Table\Util\Util as WPT_Util;
use Barn2\Plugin\WC_Product_Table\Template_Handler as WPT_Template_Handler;
use Barn2\Plugin\WC_Product_Table\Integration\WooCommerce_Wholesale_Pro as WPT_WooCommerce_Wholesale_Pro;

use function Barn2\Plugin\WC_Wholesale_Pro\woocommerce_wholesale_pro;

/**
 * Handles integration with WooCommerce Product Table
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Product_Table implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		if ( ! Lib_Util::is_barn2_plugin_active( '\Barn2\Plugin\WC_Product_Table\wpt' ) ) {
			return;
		}

		add_action( 'template_redirect', [ $this, 'maybe_load_product_table_page' ], 11, 0 );

		add_filter( 'wc_product_table_display_admin_description', [ $this, 'custom_table_display_description' ], 10, 1 );
		add_filter( 'wc_product_table_product_purchasable_from_table', [ $this, 'maybe_allow_wholesale_only_variation' ], 10, 2 );
		add_filter( 'wc_product_table_args_id', [ $this, 'set_wholesale_store_table_id' ], 10 );

		add_action( 'woocommerce_settings_save_wholesale-pro', [ $this, 'save' ] );
	}

	/**
	 * Maybe load the Product Table.
	 *
	 * @return void
	 */
	public function maybe_load_product_table_page() {
		$layout = '';

		// check if we are viewing as wholesale type user
		if ( ! Util::shall_apply_wholesale_pricing() ) {
			return;
		}

		if ( Util::is_wholesale_store_page() ) {
			$layout = get_option( 'wcwp_layout_store_page', 'default' );
			if ( method_exists( 'Barn2\Plugin\WC_Product_Table\Util\Util', 'get_shop_templates_tables' ) ) {
				$tables   = WPT_Util::get_shop_templates_tables();
				$override = $layout === 'product_table' && ! isset( $tables['shop_override'] ) && isset( $tables['wholesale_store_override'] ) ? true : ( ( $layout === 'default' || ! isset( $tables['wholesale_store_override'] ) ) && isset( $tables['shop_override'] ) ? false : '' );
			} else {
				$wcpt_misc_settings = WPT_Settings::get_setting_misc();
				$override           = $layout === 'product_table' && empty( $wcpt_misc_settings['shop_override'] ) ? true : ( $layout === 'default' && ! empty( $wcpt_misc_settings['shop_override'] ) ? false : '' );
			}
		} elseif ( is_product_category() && ! is_shop() ) {
			$layout = get_option( 'wcwp_layout_taxonomy_pages', 'default' );
			if ( method_exists( 'Barn2\Plugin\WC_Product_Table\Util\Util', 'get_shop_templates_tables' ) ) {
				$tables   = WPT_Util::get_shop_templates_tables();
				$override = $layout === 'product_table' && ! isset( $tables['archive_override'] ) && isset( $tables['wholesale_store_override'] ) ? true : ( ( $layout === 'default' || ! isset( $tables['wholesale_store_override'] ) ) && isset( $tables['archive_override'] ) ? false : '' );
			} else {
				$wcpt_misc_settings = WPT_Settings::get_setting_misc();
				$override           = $layout === 'product_table' && empty( $wcpt_misc_settings['archive_override'] ) ? true : ( $layout === 'default' && ! empty( $wcpt_misc_settings['archive_override'] ) ? false : '' );
			}
		} else {
			return;
		}

		if ( $override === true ) {
			add_action( 'woocommerce_before_shop_loop', [ WPT_Template_Handler::class, 'disable_default_woocommerce_loop' ] );
			add_action( 'woocommerce_after_shop_loop', [ WPT_Template_Handler::class, 'add_product_table_after_shop_loop' ] );

			/**
			 * Fires when the wholesale store layout is enabled.
			 *
			 * This action is fired so that other adjustments can be made
			 * when a theme requires them.
			 */
			do_action( 'wcwp_enable_wholesale_store_table_layout' );
		}

		// If product table is active, then make sure to remove the changes for our page.
		if ( $override === false ) {
			remove_action( 'woocommerce_before_shop_loop', [ WPT_Template_Handler::class, 'disable_default_woocommerce_loop' ] );
			remove_action( 'woocommerce_after_shop_loop', [ WPT_Template_Handler::class, 'add_product_table_after_shop_loop' ] );

			/**
			 * Fires when the wholesale store layout is disabled.
			 *
			 * This action is fired so that other adjustments can be made
			 * when a theme requires them.
			 */
			do_action( 'wcwp_disable_wholesale_store_table_layout' );
		}
	}


	/**
	 * Modifies the table display setting description to include details about wholesale layout.
	 *
	 * @param   string $description
	 * @return  string $description
	 */
	public function custom_table_display_description( $description ) {
		$description .= '<p>' . sprintf(
		/* translators: %1: Settings page link open %2: Settings page link close </a> */
			__( 'This will only affect your retail customers, as the wholesale layouts are controlled on the %1$swholesale layout%2$s settings page.', 'woocommerce-wholesale-pro' ),
			Lib_Util::format_link_open( add_query_arg( 'section', 'layout', woocommerce_wholesale_pro()->get_settings_page_url() ) ),
			'</a>'
		) . '</p>';

		return $description;
	}

	/**
	 * Allow variations with only wholesale prices to be purchased on product tables.
	 *
	 * @param bool $purchasable_from_table
	 * @param \WC_Product $product
	 */
	public function maybe_allow_wholesale_only_variation( $purchasable_from_table, $product ) {
		global $wpdb;

		if ( $purchasable_from_table ) {
			return $purchasable_from_table;
		}

		if ( ! $product->is_type( 'variable' ) ) {
			return $purchasable_from_table;
		}

		$wholesale_role = Util::get_current_user_wholesale_role_object();

		if ( ! $wholesale_role ) {
			return false;
		}

		$variation_ids = $product ? $product->get_children() : [];

		if ( empty( $variation_ids ) ) {
			return false;
		}

		$valid_variation_count = $wpdb->get_var(
			"
			SELECT count(post_id) FROM {$wpdb->postmeta}
			WHERE post_id IN (" . esc_sql( implode( ',', array_map( 'absint', $variation_ids ) ) ) . ")
			AND meta_key='" . esc_sql( $wholesale_role->get_name() ) . "'
			AND meta_value >= 0
			AND meta_value != ''
		"
		);

		if ( $valid_variation_count > 0 ) {
			return true;
		}

		return $purchasable_from_table;
	}



	/**
	 * Set the table builder id.
	 *
	 * @param int $table_id
	 * @return int
	 */
	public function set_wholesale_store_table_id( $table_id ) {
		if ( method_exists( 'Barn2\Plugin\WC_Product_Table\Util\Util', 'get_shop_templates_tables' ) ) {
			$shop_templates_tables = WPT_Util::get_shop_templates_tables();
			if ( Util::is_wholesale_store_page() && get_option( 'wcwp_layout_store_page', 'default' ) === 'product_table' ) {
				return $shop_templates_tables['wholesale_store_override']['id'];
			} elseif ( is_product_category() && ! is_shop() && Util::shall_apply_wholesale_pricing() && get_option( 'wcwp_layout_taxonomy_pages', 'default' ) === 'product_table' ) {
				return $shop_templates_tables['wholesale_store_override']['id'];
			}
		}
		return $table_id;
	}

	/**
	 * Save settings
	 */
	public function save() {
		global $current_section;

		if ( $current_section === 'layout' && method_exists( 'Barn2\Plugin\WC_Product_Table\Integration\WooCommerce_Wholesale_Pro', 'maybe_remove_wholesale_table' ) ) {
			if ( $_POST['wcwp_layout_store_page'] === 'default' && $_POST['wcwp_layout_taxonomy_pages'] === 'default' ) {
				WPT_WooCommerce_Wholesale_Pro::maybe_remove_wholesale_table();
			} elseif ( $_POST['wcwp_layout_store_page'] === 'product_table' || $_POST['wcwp_layout_taxonomy_pages'] === 'product_table' ) {
				WPT_WooCommerce_Wholesale_Pro::maybe_create_wholesale_table();
			}
		}
	}
}
