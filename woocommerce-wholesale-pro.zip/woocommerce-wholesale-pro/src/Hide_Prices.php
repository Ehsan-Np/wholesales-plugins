<?php

namespace Barn2\Plugin\WC_Wholesale_Pro;

use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use WC_Product;

/**
 * Alternate Content Handler
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Hide_Prices implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		// Hide Prices
		add_filter( 'woocommerce_is_purchasable', [ $this, 'is_purchasable' ], 999, 2 );
		add_action( 'woocommerce_single_product_summary', [ $this, 'hide_price' ], 0 );
		add_action( 'wc_quick_view_pro_before_quick_view', [ $this, 'hide_price' ], 0 );
		add_filter( 'woocommerce_structured_data_product_offer', [ $this, 'remove_price_in_structured_data_product_offer' ], 999, 2 );
	}

	/**
	 * Controls whether products should be purchasable
	 *
	 * @param   boolean $is_purchasable
	 * @return  boolean
	 */
	public function is_purchasable( $is_purchasable, $product ) {
		if ( Util::is_price_hidden( $product ) ) {
			return false;
		}

		return $is_purchasable;
	}

	/**
	 * Removes the variable add to cart template when prices are hidden
	 */
	public function hide_price() {
		global $product;

		if ( is_a( $product, 'WC_Product' ) && Util::is_price_hidden( $product ) ) {
			$product_type = $product->get_type();

			remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
			add_action( 'woocommerce_single_product_summary', [ $this, 'render_alternate_content' ], 10 );

			remove_action( 'wc_quick_view_pro_quick_view_product_details', [ $this, 'woocommerce_template_single_price' ], 10 );
			add_action( 'wc_quick_view_pro_quick_view_product_details', [ $this, 'render_alternate_content' ], 10 );

			if ( $product_type === 'variable' ) {
				remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
				remove_action( 'woocommerce_variable_add_to_cart', 'woocommerce_variable_add_to_cart', 30 );
			}
		}
	}

	/**
	 * Remove the price from the structured data.
	 *
	 * @param mixed $markup_offer
	 * @param mixed $product
	 * @return mixed
	 */
	public function remove_price_in_structured_data_product_offer( $markup_offer, $product ) {
		if ( ! Util::is_price_hidden( $product ) ) {
			return $markup_offer;
		}

		return [];
	}

	/**
	 * Replace the price with the alternate content (hide prices text).
	 *
	 * @param string $price_html
	 * @param WC_Product $product
	 * @return string
	 */
	public function price_content_filter( $price_html, WC_Product $product ) {
		if ( Util::is_price_hidden( $product ) ) {
			return $this->get_alternate_content_html();
		}

		return $price_html;
	}

	public function get_alternate_content_html() {
		ob_start();
		$this->render_alternate_content();
		return ob_get_clean();
	}

	public function render_alternate_content() {
		printf( '<div class="wcwp-alternate-content">%s</div>', wp_kses_post( get_option( 'wcwp_hide_prices_text', '' ) ) );
	}
}
