<?php
namespace Barn2\Plugin\WC_Wholesale_Pro;

use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin\Tools_Tab;
use WP_Error;
use Exception;

/**
 * Shortcode and handlers for the wholesale Login / Register form
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Login_Register implements Registerable, Standard_Service {
	private $login_shortcode_tag;
	private $register_shortcode_tag;
	private $template_html;
	private $template_directory;

	/**
	 * Constructor.
	 *
	 * @param string $template_directory
	 */
	public function __construct( $template_directory ) {
		/**
		 * Filters the login shortcode tag.
		 *
		 * @param string $tag The shortcode tag excluding the brackets.
		 */
		$this->login_shortcode_tag = apply_filters( 'wcwp_login_shortcode_tag', 'wholesale_login' );
		/**
		 * Filters the register shortcode tag.
		 *
		 * @param string $tag The shortcode tag excluding the brackets.
		 */
		$this->register_shortcode_tag = apply_filters( 'wcwp_register_shortcode_tag', 'wholesale_registration' );
		$this->template_html          = 'myaccount/wholesale-login-register-form.php';
		$this->template_directory     = $template_directory;
	}

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		// Register the shortcode
		add_shortcode( $this->login_shortcode_tag, [ $this, 'do_shortcode_login' ] );
		add_shortcode( $this->register_shortcode_tag, [ $this, 'do_shortcode_register' ] );

		// Prevent caching
		add_action( 'wp', [ $this, 'prevent_caching' ], 20 );

		// Add `woocommerce-page` to body class
		add_filter( 'body_class', [ $this, 'body_class' ] );

		// Register our login and registration handlers
		add_action( 'wp_loaded', [ $this, 'process_login' ], 20 );
		add_action( 'wp_loaded', [ $this, 'process_registration' ], 20 );
		add_filter( 'allowed_redirect_hosts', [ $this, 'allowed_redirect_hosts' ] );

		// Redirects
		add_action( 'template_redirect', [ $this, 'handle_redirects' ] );
		add_filter( 'login_redirect', [ $this, 'wp_login_redirect' ], 10, 3 );

		// Inject WC notices into login and registration redirect pages
		add_action( 'the_content', [ $this, 'inject_registration_success_notices' ] );
	}

	/**
	 * Render login shortcode
	 */
	public function do_shortcode_login() {
		if ( is_admin() || Util::is_rest_json_request() ) {
			return;
		}

		$user_id = get_current_user_id();
		ob_start();

		if ( $user_id && ! Util::is_wholesale_user() ) {
			if ( function_exists( 'WC' ) && WC()->session ) {
				wc_add_notice(
					sprintf(
						/* translators: %s: WP logout url */
						__( 'You are currently logged in as a non-wholesale user. Please <a href="%s">logout</a> to access the wholesale login page.', 'woocommerce-wholesale-pro' ),
						wp_logout_url( Util::get_wholesale_login_url() )
					),
					'notice'
				);
				wc_print_notices();
			} else {
				printf(
					'<div class="woocommerce-error" role="alert"><strong class="screen-reader-text">%s</strong>%s</div>',
					__( 'Error:', 'woocommerce-wholesale-pro' ),
					sprintf(
						/* translators: %s: WP logout url */
						__( 'You are currently logged in as a non-wholesale user. Please <a href="%s">logout</a> to access the wholesale login page.', 'woocommerce-wholesale-pro' ),
						wp_logout_url( Util::get_wholesale_login_url() )
					)
				);
			}
		} else {
			wc_get_template(
				$this->template_html,
				[],
				'',
				$this->template_directory
			);
		}

		return ob_get_clean();
	}

	/**
	 * Render register shortcode
	 */
	public function do_shortcode_register() {
		if ( is_admin() || Util::is_rest_json_request() ) {
			return;
		}

		$user_id = get_current_user_id();
		ob_start();

		$preview_token   = sanitize_text_field( wp_unslash( $_GET['wcwp_preview'] ?? '' ) );
		$is_admin_preview = $preview_token !== ''
			&& wp_verify_nonce( $preview_token, Tools_Tab::PREVIEW_NONCE_ACTION )
			&& current_user_can( 'manage_options' );

		if ( $user_id && ! Util::is_wholesale_user() && ! $is_admin_preview ) {
			wc_add_notice(
				sprintf(
					/* translators: %s: WP logout url */
					__( 'You are currently logged in as a non-wholesale user. Please <a href="%s">logout</a> to access the wholesale registration page.', 'woocommerce-wholesale-pro' ),
					wp_logout_url( Util::get_wholesale_login_url() )
				),
				'notice'
			);
			wc_print_notices();
		} else {
			wc_get_template(
				'myaccount/wholesale-register-form.php',
				[],
				'',
				$this->template_directory
			);
		}

		return ob_get_clean();
	}

	/**
	 * Prevent caching on our login page
	 */
	public function prevent_caching() {
		if ( ! Util::is_wholesale_login_page() && ! $this->is_registration_shortcode_page() ) {
			return;
		}

		// Set headers to prevent caching
		nocache_headers();

		// Set constants to prevent caching in certain caching plugins
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		if ( ! \defined( 'DONOTCACHEOBJECT' ) ) {
			define( 'DONOTCACHEOBJECT', true );
		}
		if ( ! \defined( 'DONOTCACHEDB' ) ) {
			define( 'DONOTCACHEDB', true );
		}

		/**
		 * Triggered after cache prevention on wholesale login page.
		 */
		do_action( 'wcwp_prevent_caching_login_page' );
	}

	private function is_registration_shortcode_page(): bool {
		if ( ! is_page() ) {
			return false;
		}
		$post = get_post();
		return $post && has_shortcode( $post->post_content, $this->register_shortcode_tag );
	}

	/**
	 * Add body class to login page.
	 * Add `woocommerce-page` to body class
	 *
	 * @param array $classes
	 * @return array
	 */
	public function body_class( $classes ) {
		if ( Util::is_wholesale_login_page() ) {
			$classes[] = 'woocommerce-page';
		}

		return $classes;
	}

	/**
	 * Process the login form.
	 *
	 * @throws Exception On login error.
	 */
	public static function process_login() {
		$nonce_value = wc_get_var( $_REQUEST['wcwp-login-nonce'], '' ); // @codingStandardsIgnoreLine.

		if ( isset( $_POST['login'], $_POST['username'], $_POST['password'] ) && wp_verify_nonce( $nonce_value, 'wcwp-login' ) ) {
			try {
				$creds = [
					'user_login'    => trim( wp_unslash( $_POST['username'] ) ), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
					'user_password' => $_POST['password'], // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
					'remember'      => isset( $_POST['rememberme'] ), // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
				];

				$validation_error = new WP_Error();
				$validation_error = apply_filters( 'woocommerce_process_login_errors', $validation_error, $creds['user_login'], $creds['user_password'] );

				if ( $validation_error->get_error_code() ) {
					throw new Exception( '<strong>' . __( 'Error:', 'woocommerce-wholesale-pro' ) . '</strong> ' . $validation_error->get_error_message() );
				}

				if ( empty( $creds['user_login'] ) ) {
					throw new Exception( '<strong>' . __( 'Error:', 'woocommerce-wholesale-pro' ) . '</strong> ' . __( 'Username is required.', 'woocommerce-wholesale-pro' ) );
				}

				$user_data = get_user_by( is_email( $creds['user_login'] ) ? 'email' : 'login', $creds['user_login'] );

				// Only allow wholesale roles to login here
				if ( $user_data && ! Util::is_wholesale_user( $user_data ) ) {
					throw new Exception( '<strong>' . __( 'Error:', 'woocommerce-wholesale-pro' ) . '</strong> ' . __( 'This login page is for wholesale users only.', 'woocommerce-wholesale-pro' ) );
				}

				// Perform the login.
				$user = wp_signon( apply_filters( 'woocommerce_login_credentials', $creds ), is_ssl() );

				if ( is_wp_error( $user ) ) {
					throw new Exception( $user->get_error_message() );
				} else {
					$redirect = Util::get_login_redirect_url();

					/**
					 * Filters the login redirect URL.
					 *
					 * @param string $url The URL to redirect to.
					 * @param \WP_User $user The user being redirected.
					 */
					$clean_redirect_url = apply_filters( 'wcwp_login_redirect', remove_query_arg( 'wc_error', $redirect ), $user );

					wp_redirect( wp_validate_redirect( $clean_redirect_url, wc_get_page_permalink( 'wholesale_store' ) ) ); // phpcs:ignore
					exit;
				}
			} catch ( Exception $e ) {
				wc_add_notice( apply_filters( 'login_errors', $e->getMessage() ), 'error' );

				/**
				 * Triggered after a failed wholesale login.
				 */
				do_action( 'woocommerce_login_failed' );
			}
		}
	}

	/**
	 * Add the host of the custom redirect URL to the allowed redirect hosts
	 *
	 * @since  1.7.6
	 * @param  array $allowed_hosts The array of hosts allowed to redirect to
	 * @return array                The resulting array
	 */
	public function allowed_redirect_hosts( $allowed_hosts ) {
		$custom_urls = [
			get_option( 'wcwp_login_redirect', '' ),
			get_option( 'wcwp_registration_redirect', '' ),
		];

		foreach ( $custom_urls as $custom_url ) {
			if ( ! empty( $custom_url ) ) {
				$redirect_host = wp_parse_url( $custom_url, PHP_URL_HOST );

				if ( ! empty( $redirect_host ) ) {
					$allowed_hosts[] = $redirect_host;
					$allowed_hosts   = array_unique( $allowed_hosts );
				}
			}
		}

		return $allowed_hosts;
	}

	/**
	 * Process the registration form.
	 *
	 * @throws Exception On registration error.
	 */
	public static function process_registration() {
		$nonce_value = wc_get_var( $_REQUEST['wcwp-register-nonce'], '' ); // @codingStandardsIgnoreLine.

		if ( isset( $_POST['register'], $_POST['email'] ) && wp_verify_nonce( $nonce_value, 'wcwp-register' ) ) {
			$username = 'no' === get_option( 'woocommerce_registration_generate_username' ) && isset( $_POST['username'] ) ? wp_unslash( $_POST['username'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$email    = wp_unslash( $_POST['email'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

			try {
				$validation_error  = new WP_Error();
				$validation_error  = apply_filters( 'woocommerce_process_registration_errors', $validation_error, $username, '', $email );
				$validation_errors = $validation_error->get_error_messages();

				if ( 1 === count( $validation_errors ) ) {
					throw new Exception( $validation_error->get_error_message() );
				} elseif ( $validation_errors ) {
					foreach ( $validation_errors as $message ) {
						wc_add_notice( '<strong>' . __( 'Error:', 'woocommerce-wholesale-pro' ) . '</strong> ' . $message, 'error' );
					}
					throw new Exception();
				}

				if ( empty( $email ) || ! is_email( $email ) ) {
					throw new Exception( __( 'Please provide a valid email address.', 'woocommerce-wholesale-pro' ) );
				}

				if ( email_exists( $email ) ) {
					$user = get_user_by( 'email', $email );

					if ( Util::is_wholesale_user( $user ) ) {
						throw new Exception( __( 'An account is already registered with your email address. Please log in.', 'woocommerce-wholesale-pro' ) );
					} else {
						throw new Exception( __( 'This email address is already used for a non-wholesale account. Please enter a different email address to use for your wholesale account.', 'woocommerce-wholesale-pro' ) );
					}
				}

				if ( 'yes' === get_option( 'woocommerce_registration_generate_username', 'yes' ) && empty( $username ) ) {
					$username = wc_create_new_customer_username( $email );
				}

				$username = sanitize_user( $username );

				if ( empty( $username ) || ! validate_username( $username ) ) {
					throw new Exception(
						__( 'Please enter a valid account username.', 'woocommerce-wholesale-pro' )
					);
				}

				if ( username_exists( $username ) ) {
					$user = get_user_by( 'login', $username );

					if ( Util::is_wholesale_user( $user ) ) {
						throw new Exception(
							__( 'A wholesale account is already registered with that username. Please choose another or log in first.', 'woocommerce-wholesale-pro' )
						);
					} else {
						throw new Exception(
							__( 'An account is already registered with that username. Please choose another or log in first.', 'woocommerce-wholesale-pro' )
						);
					}
				}
				// Use WP_Error to handle registration errors.
				$errors = new WP_Error();

				do_action( 'woocommerce_register_post', $username, $email, $errors );

				/**
				 * Triggered before a registration is processed or failed.
				 *
				 * @param string $username The username, generated from the email or provided by the user.
				 * @param string $email The email address of the user.
				 * @param WP_Error $errors The error collector, if any externally hooked registration processes caused an error.
				 */
				do_action( 'wcwp_register_post', $username, $email, $errors );

				$errors = apply_filters( 'woocommerce_registration_errors', $errors, $username, $email );

				if ( $errors->get_error_code() ) {
					throw new Exception( $errors->get_error_message() );
				}

				// Always auto-generate password
				$password = wp_generate_password();

				// Insert our customer
				// Merge the role in to make sure plugins adding additional fields don't overwrite
				$role = 'yes' === get_option( 'wcwp_moderate_registrations', 'yes' ) ? 'wcwp_pending' : Util::get_default_role();

				$new_customer_data = array_merge(
					apply_filters(
						'woocommerce_new_customer_data',
						[
							'user_login' => $username,
							'user_pass'  => $password,
							'user_email' => $email,
						]
					),
					[
						'role' => $role,
					]
				);

				$customer_id = wp_insert_user( $new_customer_data );

				if ( is_wp_error( $customer_id ) ) {
					throw new Exception( $customer_id->get_error_message() );
				}

				/**
				 * Triggered after a customer is created following a successful registration.
				 *
				 * @param int $customer_id The user_id of the created customer.
				 * @param array $new_customer_data The customer data used to create the customer.
				 */
				do_action( 'wcwp_created_customer', $customer_id, $new_customer_data );

				// Handle moderation
				$moderation = false;

				if ( 'yes' === get_option( 'wcwp_moderate_registrations', 'yes' ) ) {
					$moderation = true;
					update_user_meta( $customer_id, 'wcwp_moderation_required', true );

					/**
					 * Triggered if a new customer is created and sent to moderation.
					 *
					 * @param int $customer_id The user_id of the customer.
					 */
					do_action( 'wcwp_new_user_moderation', $customer_id );

					wc_add_notice( __( 'Your registration has been submitted successfully.', 'woocommerce-wholesale-pro' ) );
				} else {

					/**
					 * Triggered if a new customer is created and auto approved.
					 *
					 * @param int $customer_id The user_id of the customer.
					 */
					do_action( 'wcwp_new_user_auto_approved', $customer_id, $password );

					wc_add_notice( __( 'Your registration was processed successfully and a password has been sent to your email address.', 'woocommerce-wholesale-pro' ) );
				}

				self::maybe_handle_registration_redirect( $moderation );
			} catch ( Exception $e ) {
				if ( $e->getMessage() ) {
					wc_add_notice( '<strong>' . __( 'Error:', 'woocommerce-wholesale-pro' ) . '</strong> ' . $e->getMessage(), 'error' );
				}
			}
		}
	}

	/**
	 * Add success notices to custom registration redirect.
	 *
	 * @param string $content
	 * @return string
	 */
	public function inject_registration_success_notices( $content ) {
		if ( ! filter_input( INPUT_GET, 'wcwp_registration', FILTER_SANITIZE_NUMBER_INT ) ) {
			return $content;
		}

		if ( Util::is_wc_frontend_page() ) {
			return $content;
		}

		$moderation = filter_input( INPUT_GET, 'wcwp_moderation', FILTER_SANITIZE_NUMBER_INT );

		if ( $moderation === '1' ) {
			wc_add_notice( __( 'Your registration has been submitted successfully.', 'woocommerce-wholesale-pro' ) );
		} else {
			wc_add_notice( __( 'Your registration was processed successfully and a password has been sent to your email address.', 'woocommerce-wholesale-pro' ) );
		}

		return wc_print_notices() . $content;
	}

	/**
	 * Handle redirects based on wholesale status.
	 */
	public function handle_redirects() {
		// Redirect wholesale store to login if logged out
		if ( ! is_user_logged_in() && Util::is_wholesale_store_page() && ! Util::site_uses_wc_shop_page() ) {
			wp_safe_redirect( Util::get_wholesale_login_url() );
			exit;
		}

		// Redirect wholesale store to login if not wholesale user or shop admin
		if ( Util::is_wholesale_store_page() && ! Util::shall_apply_wholesale_pricing() && ! Util::site_uses_wc_shop_page() ) {
			wp_safe_redirect( Util::get_wholesale_login_url() );
			exit;
		}

		// Redirect login to store for wholesale users
		if ( Util::is_wholesale_login_page() && Util::is_wholesale_user() ) {
			wp_safe_redirect( Util::get_wholesale_store_url() );
			exit;
		}
	}

	/**
	 * Redirect standard WP logins for wholesale users
	 *
	 * @param string           $redirect_to           The redirect destination URL.
	 * @param string           $requested_redirect_to The requested redirect destination URL passed as a parameter.
	 * @param WP_User|WP_Error $user                  WP_User object if login was successful, WP_Error object otherwise.
	 * @return string
	 */
	public function wp_login_redirect( $redirect_to, $requested_redirect_to, $user ) {
		if ( $user instanceof \WP_User && Util::is_wholesale_user( $user ) ) {
			$redirect_to = Util::get_login_redirect_url();
		}

		return $redirect_to;
	}

	/**
	 * Redirect standard WP logouts for wholesale users
	 *
	 * @param bool $moderation Used to determine the correct success notice after redirect.
	 */
	private static function maybe_handle_registration_redirect( $moderation ) {
		// check if we have a URL from the site itself
		$redirect_url = Util::get_registration_redirect_url();

		if ( ! $redirect_url ) {
			return;
		}

		$post_id = url_to_postid( $redirect_url );

		if ( $post_id === 0 ) {
			wp_safe_redirect( $redirect_url );
			exit;
		}

		$redirect_url = add_query_arg(
			[
				'wcwp_registration' => true,
				'wcwp_moderation'   => $moderation,
			],
			$redirect_url
		);

		wp_safe_redirect( $redirect_url );
		exit;
	}
}
