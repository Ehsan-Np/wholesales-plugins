<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Registration_Form;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Plugin;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin\Form_Builder_Page;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin\Form_Builder_Tab;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin\Import_Export_Tab;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin\Tools_Tab;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Frontend\Form_Renderer;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Frontend\Form_Validator;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Frontend\Form_Processor;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Email\Email_Notifier;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Upload\File_Handler;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Schema\Field_Schema;

/**
 * Central hook registry for the registration form feature.
 *
 * Registered as a service in Plugin::add_services(). Wires all frontend,
 * admin, email, and file-download hooks for the custom registration form.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Registration_Form implements Registerable, Standard_Service {

	private Plugin           $plugin;
	private Form_Builder_Page $admin_page;
	private Form_Renderer    $renderer;
	private Form_Validator   $validator;
	private Form_Processor   $processor;
	private Email_Notifier   $notifier;

	public function __construct( Plugin $plugin ) {
		$this->plugin     = $plugin;
		$this->admin_page = new Form_Builder_Page();
		$this->renderer   = new Form_Renderer();
		$this->validator  = new Form_Validator();
		$this->processor  = new Form_Processor();
		$this->notifier   = new Email_Notifier();
	}

	/**
	 * {@inheritdoc}
	 */
	public function register(): void {
		// Assets.
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend_assets' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );

		// Inject Registration form section into Wholesale Pro WC settings.
		add_filter( 'woocommerce_get_sections_wholesale-pro', [ $this->admin_page, 'add_wc_section' ] );
		add_action( 'woocommerce_settings_wholesale-pro', [ $this->admin_page, 'maybe_render_section' ], 1 );
		add_action( 'admin_init', [ $this->admin_page, 'handle_requests' ] );
		add_action( 'admin_post_wcwp_field_action',  [ new Form_Builder_Tab(), 'handle_post' ] );
		add_action( 'wp_ajax_wcwp_reorder_fields',   [ new Form_Builder_Tab(), 'handle_reorder_ajax' ] );
		add_action( 'admin_post_wcwp_export_schema', [ new Import_Export_Tab(), 'handle_post' ] );
		add_action( 'admin_post_wcwp_import_schema', [ new Import_Export_Tab(), 'handle_post' ] );
		add_action( 'admin_post_wcwp_tools_action',  [ new Tools_Tab(), 'handle_post' ] );

		// WCWP form hooks.
		add_action( 'wcwp_register_form', [ $this->renderer, 'render' ], 1 );
		add_action( 'wcwp_register_post', [ $this->validator, 'validate' ], 10, 3 );
		add_action( 'wcwp_created_customer', [ $this->processor, 'save' ], 10, 2 );

		// Admin user profile panel.
		add_action( 'edit_user_profile', [ $this, 'render_user_profile_panel' ] );
		add_action( 'show_user_profile', [ $this, 'render_user_profile_panel' ] );
		add_action( 'edit_user_profile_update', [ $this, 'save_user_profile_fields' ] );
		add_action( 'personal_options_update', [ $this, 'save_user_profile_fields' ] );

		// Migration ready notice.
		add_action( 'admin_init', [ $this, 'handle_activate_form' ] );
		add_action( 'admin_notices', [ $this, 'migration_ready_notice' ] );
		add_action( 'wp_ajax_wcwp_dismiss_migration_notice', [ $this, 'dismiss_migration_notice' ] );

		// Schema migrations (run once per install via option flag).
		add_action( 'init', [ Field_Schema::class, 'migrate_legacy_fields' ] );
		add_action( 'init', [ Field_Schema::class, 'migrate_v1_shipping' ] );
		add_action( 'init', [ Field_Schema::class, 'migrate_v2_sentence_case' ] );
		add_action( 'init', [ Field_Schema::class, 'migrate_v3_multi_conditions' ] );

		// Background user meta migration via Action Scheduler.
		add_action( 'wcwp_migrate_legacy_user_meta', [ Field_Schema::class, 'batch_migrate_legacy_user_meta' ], 10, 2 );

		// Secure file download AJAX.
		add_action( 'wp_ajax_wcwp_trade_download_file', [ File_Handler::class, 'handle_download' ] );
		add_action( 'wp_ajax_nopriv_wcwp_trade_download_file', [ File_Handler::class, 'handle_download_nopriv' ] );

		// Inject submitted field table into WCWP's emails that fire on registration.
		// wcwp_new_wholesale_user                  → admin "New wholesale user" notification.
		// wcwp_customer_registration_pending        → customer "Registration pending" confirmation.
		add_filter( 'wcwp_email_body_content_wcwp_new_wholesale_user', [ $this->notifier, 'inject_field_table_admin' ], 10, 3 );
		add_filter( 'wcwp_email_body_content_wcwp_customer_registration_pending', [ $this->notifier, 'inject_field_table_customer' ], 10, 3 );
	}

	public function migration_ready_notice(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		// Only show when legacy fields were migrated but the new form isn't active yet.
		if ( ! get_option( 'wcwp_trade_hide_legacy_tab' ) || get_option( 'wcwp_trade_form_active' ) === 'yes' ) {
			return;
		}

		if ( get_option( 'wcwp_migration_notice_dismissed' ) ) {
			return;
		}

		$form_builder_url = Form_Builder_Page::section_url();
		$activate_url     = wp_nonce_url( add_query_arg( 'wcwp_activate_form', '1' ), 'wcwp_activate_form' );

		echo '<div class="notice notice-warning is-dismissible" id="wcwp-migration-notice" data-nonce="' . esc_attr( wp_create_nonce( 'wcwp_dismiss_migration_notice' ) ) . '">';
		echo '<p><strong>' . esc_html__( 'WooCommerce Wholesale Pro: Review your upgraded registration form.', 'woocommerce-wholesale-pro' ) . '</strong></p>';
		echo '<p>' . wp_kses(
			sprintf(
				/* translators: 1: form builder link open, 2: form builder link close */
				__( 'Your existing registration fields have been imported into the new form builder. Before switching over, we recommend %1$sreviewing the fields%2$s - you can rename them, change the order, or add new ones. When you\'re happy with the form, click <strong>Activate registration form</strong> below to make it live. Until then, your current registration form continues to work as normal.', 'woocommerce-wholesale-pro' ),
				'<a href="' . esc_url( $form_builder_url ) . '">',
				'</a>'
			),
			[ 'a' => [ 'href' => [] ], 'strong' => [] ]
		) . '</p>';
		echo '<p><a href="' . esc_url( $activate_url ) . '" class="button button-primary">' . esc_html__( 'Activate registration form', 'woocommerce-wholesale-pro' ) . '</a></p>';
		echo '</div>';
		echo '<script>
		(function(){
			var notice = document.getElementById("wcwp-migration-notice");
			if ( ! notice ) return;
			notice.addEventListener("click", function(e){
				if ( ! e.target.classList.contains("notice-dismiss") ) return;
				var xhr = new XMLHttpRequest();
				xhr.open("POST", ajaxurl, true);
				xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
				xhr.send("action=wcwp_dismiss_migration_notice&nonce=" + encodeURIComponent(notice.dataset.nonce));
			});
		})();
		</script>';
	}

	public function handle_activate_form(): void {
		if ( empty( $_GET['wcwp_activate_form'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		check_admin_referer( 'wcwp_activate_form' );

		update_option( 'wcwp_trade_form_active', 'yes', false );
		update_option( 'wcwp_migration_notice_dismissed', true, false );

		wp_safe_redirect( remove_query_arg( [ 'wcwp_activate_form', '_wpnonce' ] ) );
		exit;
	}

	public function dismiss_migration_notice(): void {
		check_ajax_referer( 'wcwp_dismiss_migration_notice', 'nonce' );

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( -1, 403 );
		}

		update_option( 'wcwp_migration_notice_dismissed', true, false );
		wp_die();
	}

	public function enqueue_frontend_assets(): void {
		wp_enqueue_style( 'select2' );
		wp_enqueue_style(
			'wcwp-registration-form-frontend',
			$this->plugin->get_dir_url( 'assets/css/frontend/wcwp-registration-form.css' ),
			[ 'select2' ],
			$this->plugin->get_version()
		);
		wp_enqueue_script( 'selectWoo' );
		wp_enqueue_script(
			'wcwp-registration-form-frontend',
			$this->plugin->get_dir_url( 'assets/js/frontend/wcwp-registration-form.js' ),
			[ 'jquery', 'selectWoo' ],
			$this->plugin->get_version(),
			true
		);
	}

	public function enqueue_admin_assets( string $hook ): void {
		$is_wc_section = $hook === 'woocommerce_page_wc-settings'
			&& ( $_GET['tab'] ?? '' ) === 'wholesale-pro'
			&& ( $_GET['section'] ?? '' ) === 'registration-form';

		if ( ! $is_wc_section ) {
			return;
		}

		wp_enqueue_style( 'wp-jquery-ui-dialog' );
		wp_enqueue_style(
			'wcwp-registration-form-admin',
			$this->plugin->get_dir_url( 'assets/css/admin/wcwp-registration-form.css' ),
			[],
			$this->plugin->get_version()
		);
		wp_enqueue_script( 'jquery-ui-sortable' );
		wp_enqueue_script(
			'wcwp-registration-form-admin',
			$this->plugin->get_dir_url( 'assets/js/admin/wcwp-registration-form.js' ),
			[ 'jquery', 'jquery-ui-sortable', 'selectWoo' ],
			$this->plugin->get_version(),
			true
		);
		wp_localize_script( 'wcwp-registration-form-admin', 'wcwpTradeAdmin', [
			'nonce'        => wp_create_nonce( 'wcwp_trade_admin' ),
			'keyPrefix'    => 'wwp_trade_',
			'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
			'reorderNonce' => wp_create_nonce( Form_Builder_Tab::NONCE_ACTION ),
			'roles'        => wp_roles()->get_names(),
		] );
	}

	// -------------------------------------------------------------------------
	// Admin user profile panel
	// -------------------------------------------------------------------------

	public function render_user_profile_panel( \WP_User $user ): void {
		if ( ! current_user_can( 'edit_user', $user->ID ) ) {
			return;
		}

		$fields    = Field_Schema::get_enabled_fields();
		$wc_mapped = array_flip( Field_Schema::get_wc_mapped_keys() );

		// Filter out WC-mapped fields and non-data field types.
		$non_data_types = [ 'honeypot', 'display_text', 'textarea' ];
		$renderable     = array_values( array_filter(
			$fields,
			fn( $f ) => ! isset( $wc_mapped[ $f['key'] ] ) && ! in_array( $f['type'], $non_data_types, true )
		) );

		// Also collect any legacy fields that have stored data for this user but are not already
		// represented in the new schema (e.g. migration hasn't run, or schema is empty).
		$legacy_option = get_option( 'wcwp_registration_fields', [] );
		$schema_keys   = array_column( $fields, 'legacy_key' );
		$orphan_rows   = [];
		foreach ( $legacy_option as $unique_id => $legacy_field ) {
			$label = $legacy_field['label'] ?? '';
			if ( $label === '' ) {
				continue;
			}
			// Skip if this legacy field is already represented via legacy_key in the schema.
			if ( in_array( sanitize_key( $unique_id ), $schema_keys, true ) ) {
				continue;
			}
			$val = get_user_meta( $user->ID, $unique_id, true );
			if ( $val === '' || $val === false ) {
				continue;
			}
			$orphan_rows[] = [ 'id' => $unique_id, 'label' => $label, 'value' => $val ];
		}

		if ( empty( $renderable ) && empty( $orphan_rows ) ) {
			return;
		}

		echo '<h2>' . esc_html__( 'Wholesale Account Registration', 'woocommerce-wholesale-pro' ) . '</h2>';
		echo '<table class="form-table">';

		$current_section = null;
		foreach ( $renderable as $field ) {
			if ( $field['section'] !== $current_section ) {
				$current_section = $field['section'];
				if ( $current_section !== '' ) {
					echo '<tr><th colspan="2"><h3 style="margin:0;">' . esc_html( $current_section ) . '</h3></th></tr>';
				}
			}

			$value = get_user_meta( $user->ID, $field['key'], true );
			if ( ( $value === '' || $value === false ) && ! empty( $field['legacy_key'] ) ) {
				$value = get_user_meta( $user->ID, $field['legacy_key'], true );
			}

			if ( $field['type'] === 'file' ) {
				$files = (array) get_user_meta( $user->ID, 'wwp_trade_files_' . $field['key'], true );
				$files = array_filter( $files );
				if ( ! empty( $files ) ) {
					echo '<tr><th>' . esc_html( $field['label'] ) . '</th><td>';
					foreach ( $files as $rel_path ) {
						$filename = basename( $rel_path );
						$url      = File_Handler::get_download_url( $rel_path );
						echo '<a href="' . esc_url( $url ) . '" target="_blank">' . esc_html( $filename ) . '</a><br>';
					}
					echo '</td></tr>';
				}
				continue;
			}

			$display_value = $value;
			if ( $field['type'] === 'checkbox' ) {
				$display_value = $value ? __( 'Yes', 'woocommerce-wholesale-pro' ) : __( 'No', 'woocommerce-wholesale-pro' );
			} elseif ( is_array( $value ) ) {
				$display_value = implode( ', ', $value );
			}

			echo '<tr>';
			echo '<th><label for="' . esc_attr( $field['key'] ) . '">' . esc_html( $field['label'] ) . '</label></th>';
			echo '<td><input type="text" class="regular-text" id="' . esc_attr( $field['key'] ) . '" name="' . esc_attr( $field['key'] ) . '" value="' . esc_attr( (string) $display_value ) . '"></td>';
			echo '</tr>';
		}

		// Render any legacy fields whose data exists but isn't covered by the new schema.
		foreach ( $orphan_rows as $row ) {
			echo '<tr>';
			echo '<th><label for="' . esc_attr( $row['id'] ) . '">' . esc_html( $row['label'] ) . '</label></th>';
			echo '<td><input type="text" class="regular-text" id="' . esc_attr( $row['id'] ) . '" name="' . esc_attr( $row['id'] ) . '" value="' . esc_attr( $row['value'] ) . '"></td>';
			echo '</tr>';
		}

		echo '</table>';
		wp_nonce_field( 'wcwp_trade_save_user_fields', 'wcwp_trade_user_nonce' );
	}

	public function save_user_profile_fields( int $user_id ): void {
		if ( ! isset( $_POST['wcwp_trade_user_nonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_key( $_POST['wcwp_trade_user_nonce'] ), 'wcwp_trade_save_user_fields' ) ) {
			return;
		}
		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return;
		}

		$wc_mapped = array_flip( Field_Schema::get_wc_mapped_keys() );

		foreach ( Field_Schema::get_enabled_fields() as $field ) {
			if ( $field['type'] === 'file' ) {
				continue;
			}
			if ( isset( $wc_mapped[ $field['key'] ] ) ) {
				continue;
			}
			if ( isset( $_POST[ $field['key'] ] ) ) {
				$val = sanitize_text_field( wp_unslash( $_POST[ $field['key'] ] ) );
				update_user_meta( $user_id, $field['key'], $val );
				if ( ! empty( $field['legacy_key'] ) ) {
					update_user_meta( $user_id, $field['legacy_key'], $val );
				}
			}
		}

		// Save any orphan legacy fields rendered directly (not yet in new schema).
		$legacy_option = get_option( 'wcwp_registration_fields', [] );
		$schema_keys   = array_column( Field_Schema::get_enabled_fields(), 'legacy_key' );
		foreach ( $legacy_option as $unique_id => $legacy_field ) {
			if ( $legacy_field['label'] ?? '' === '' ) {
				continue;
			}
			if ( in_array( sanitize_key( $unique_id ), $schema_keys, true ) ) {
				continue;
			}
			if ( isset( $_POST[ $unique_id ] ) ) {
				update_user_meta( $user_id, $unique_id, sanitize_text_field( wp_unslash( $_POST[ $unique_id ] ) ) );
			}
		}
	}
}
