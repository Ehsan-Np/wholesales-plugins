<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Upload;

/**
 * Private file upload management.
 *
 * Files are stored in wp-content/uploads/wcwp-trade-docs/{user_id}/{field_key}/
 * with Apache/Nginx protection to prevent direct public URL access.
 * Admin downloads are served via a signed AJAX endpoint.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class File_Handler {

	const SUBDIR = 'wcwp-trade-docs';

	// -----------------------------------------------------------------------
	// Setup
	// -----------------------------------------------------------------------

	public static function ensure_private_dir(): void {
		$dir = self::base_dir();
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		// Block direct HTTP access.
		$htaccess = $dir . '/.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			file_put_contents( $htaccess, "deny from all\n" );
		}

		// Prevent directory listing.
		$index = $dir . '/index.php';
		if ( ! file_exists( $index ) ) {
			file_put_contents( $index, "<?php // Silence is golden.\n" );
		}
	}

	// -----------------------------------------------------------------------
	// Upload
	// -----------------------------------------------------------------------

	/**
	 * Process uploaded files for a given field key and user ID.
	 *
	 * @return string[] Array of paths relative to the base upload dir.
	 */
	public static function upload( string $field_key, int $user_id, bool $multiple ): array {
		if ( ! isset( $_FILES[ $field_key ] ) ) {
			return [];
		}

		self::ensure_private_dir();

		// Normalise single/multiple file structures.
		$files  = self::normalise_files( $_FILES[ $field_key ], $multiple );
		$stored = [];

		foreach ( $files as $file ) {
			if ( $file['error'] !== UPLOAD_ERR_OK || empty( $file['tmp_name'] ) ) {
				continue;
			}

			$dest_dir = self::field_dir( $user_id, $field_key );
			if ( ! is_dir( $dest_dir ) ) {
				wp_mkdir_p( $dest_dir );
			}

			$filename  = self::safe_filename( $file['name'] );
			$dest_path = $dest_dir . '/' . $filename;

			// Validate MIME type (no PHP/HTML executables).
			if ( ! self::is_allowed_mime( $file['tmp_name'], $file['name'] ) ) {
				continue;
			}

			if ( move_uploaded_file( $file['tmp_name'], $dest_path ) ) {
				// Store path relative to base dir.
				$stored[] = $user_id . '/' . $field_key . '/' . $filename;
			}
		}

		return $stored;
	}

	// -----------------------------------------------------------------------
	// Secure download
	// -----------------------------------------------------------------------

	public static function get_download_url( string $rel_path ): string {
		return add_query_arg( [
			'action' => 'wcwp_trade_download_file',
			'file'   => rawurlencode( $rel_path ),
			'sig'    => hash_hmac( 'sha256', $rel_path, AUTH_KEY ),
		], admin_url( 'admin-ajax.php' ) );
	}

	public static function handle_download_nopriv(): void {
		wp_die(
			esc_html__( 'You do not have permission to view this file. Please log in as an administrator.', 'woocommerce-wholesale-pro' ),
			esc_html__( 'Access denied', 'woocommerce-wholesale-pro' ),
			[ 'response' => 403 ]
		);
	}

	public static function handle_download(): void {
		if ( ! current_user_can( 'edit_users' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'woocommerce-wholesale-pro' ), esc_html__( 'Access denied', 'woocommerce-wholesale-pro' ), [ 'response' => 403 ] );
		}

		$rel_path = sanitize_text_field( urldecode( $_GET['file'] ?? '' ) );
		$sig      = sanitize_text_field( $_GET['sig'] ?? '' );
		$expected = hash_hmac( 'sha256', $rel_path, AUTH_KEY );

		if ( ! hash_equals( $expected, $sig ) ) {
			wp_die( esc_html__( 'Invalid or expired link.', 'woocommerce-wholesale-pro' ), 403 );
		}

		// Prevent path traversal.
		$rel_path  = ltrim( str_replace( '..', '', $rel_path ), '/\\' );
		$full_path = self::base_dir() . '/' . $rel_path;

		if ( ! file_exists( $full_path ) ) {
			wp_die( esc_html__( 'File not found.', 'woocommerce-wholesale-pro' ), 404 );
		}

		$filename  = basename( $full_path );
		$mime_type = mime_content_type( $full_path ) ?: 'application/octet-stream';

		nocache_headers();
		header( 'Content-Type: ' . $mime_type );
		header( 'Content-Disposition: attachment; filename="' . rawurlencode( $filename ) . '"' );
		header( 'Content-Length: ' . filesize( $full_path ) );
		readfile( $full_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		exit;
	}

	// -----------------------------------------------------------------------
	// Helpers
	// -----------------------------------------------------------------------

	private static function base_dir(): string {
		$uploads = wp_upload_dir();
		return $uploads['basedir'] . '/' . self::SUBDIR;
	}

	private static function field_dir( int $user_id, string $field_key ): string {
		return self::base_dir() . '/' . $user_id . '/' . sanitize_key( $field_key );
	}

	private static function safe_filename( string $original ): string {
		$ext  = strtolower( pathinfo( $original, PATHINFO_EXTENSION ) );
		$name = sanitize_file_name( pathinfo( $original, PATHINFO_FILENAME ) );
		return time() . '-' . $name . ( $ext ? '.' . $ext : '' );
	}

	private static function is_allowed_mime( string $tmp_path, string $filename ): bool {
		$blocked_exts = [ 'php', 'phtml', 'php3', 'php4', 'php5', 'php7', 'phps', 'phar', 'html', 'htm', 'js', 'exe', 'sh', 'bat' ];
		$ext          = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
		return ! in_array( $ext, $blocked_exts, true );
	}

	/**
	 * Normalise PHP $_FILES array into array of individual file entries,
	 * whether the input name was scalar (single) or array (multiple).
	 */
	private static function normalise_files( array $file_data, bool $multiple ): array {
		if ( ! $multiple || ! is_array( $file_data['name'] ) ) {
			return [ $file_data ];
		}
		$files = [];
		foreach ( $file_data['name'] as $i => $name ) {
			$files[] = [
				'name'     => $name,
				'type'     => $file_data['type'][ $i ],
				'tmp_name' => $file_data['tmp_name'][ $i ],
				'error'    => $file_data['error'][ $i ],
				'size'     => $file_data['size'][ $i ],
			];
		}
		return $files;
	}
}
