<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Schema;

/**
 * Field schema CRUD.
 *
 * Field definitions are stored as a JSON array in the options table under
 * the key OPTION_KEY. Each entry is an associative array:
 *
 *   key          string   Unique meta key, e.g. wcwp_trade_company_name
 *   label        string   Human-readable label
 *   type         string   text|email|tel|number|textarea|select|multiselect|radio|checkbox|file
 *   section      string   Group heading shown on the form
 *   required     bool
 *   options      string   CSV of choices (select/multiselect/radio)
 *   multiple     bool     Allow multiple file uploads (file type only)
 *   assign_role  bool     Selecting this field's value sets the user role
 *   role_map     array    { "Option Label" => ["wp_role_slug", ...] }
 *   conditional  array    { enabled, action, match, conditions: [{when_field, operator, has_value}] }
 *   order        int      Display order (0-based)
 *   enabled      bool     Hidden from form when false
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Field_Schema {

	const OPTION_KEY = 'wcwp_trade_form_schema';

	// -------------------------------------------------------------------------
	// Read
	// -------------------------------------------------------------------------

	public static function get_fields(): array {
		$raw = get_option( self::OPTION_KEY, null );
		if ( null === $raw ) {
			return [];
		}
		$fields = is_array( $raw ) ? $raw : json_decode( $raw, true );
		if ( ! is_array( $fields ) ) {
			return [];
		}
		usort( $fields, fn( $a, $b ) => ( $a['order'] ?? 0 ) - ( $b['order'] ?? 0 ) );
		return $fields;
	}

	public static function get_field( string $key ): ?array {
		foreach ( self::get_fields() as $field ) {
			if ( $field['key'] === $key ) {
				return $field;
			}
		}
		return null;
	}

	public static function get_enabled_fields(): array {
		return array_values( array_filter( self::get_fields(), fn( $f ) => ! empty( $f['enabled'] ) ) );
	}

	/** Returns the field keys (not WC keys) of all enabled fields that have a wc_map set. */
	public static function get_wc_mapped_keys(): array {
		return array_column(
			array_filter( self::get_enabled_fields(), fn( $f ) => ! empty( $f['wc_map'] ) ),
			'key'
		);
	}

	// -------------------------------------------------------------------------
	// Write
	// -------------------------------------------------------------------------

	public static function add_field( array $data ): bool {
		$fields      = self::get_fields();
		$data        = self::sanitize_definition( $data );
		$data['key'] = self::ensure_unique_key( $data['key'], $fields );
		$data['order'] = count( $fields );
		$fields[]    = $data;
		return self::save( $fields );
	}

	public static function update_field( string $key, array $data ): bool {
		$fields = self::get_fields();
		foreach ( $fields as &$field ) {
			if ( $field['key'] === $key ) {
				$data['key']   = $field['key'];
				$data['order'] = $field['order'];
				if ( ! empty( $field['legacy_key'] ) && empty( $data['legacy_key'] ) ) {
					$data['legacy_key'] = $field['legacy_key'];
				}
				$field = array_merge( $field, self::sanitize_definition( $data ) );
				return self::save( $fields );
			}
		}
		return false;
	}

	public static function delete_field( string $key ): bool {
		$fields = array_values( array_filter(
			self::get_fields(),
			fn( $f ) => $f['key'] !== $key
		) );
		foreach ( $fields as $i => &$f ) {
			$f['order'] = $i;
		}
		return self::save( $fields );
	}

	/** $ordered_keys = field keys in new display order. */
	public static function reorder( array $ordered_keys ): bool {
		$fields  = self::get_fields();
		$indexed = [];
		foreach ( $fields as $f ) {
			$indexed[ $f['key'] ] = $f;
		}
		$reordered = [];
		foreach ( $ordered_keys as $i => $k ) {
			if ( isset( $indexed[ $k ] ) ) {
				$indexed[ $k ]['order'] = (int) $i;
				$reordered[]           = $indexed[ $k ];
			}
		}
		foreach ( $fields as $f ) {
			if ( ! in_array( $f['key'], $ordered_keys, true ) ) {
				$f['order']  = count( $reordered );
				$reordered[] = $f;
			}
		}
		return self::save( $reordered );
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	public static function generate_key( string $label ): string {
		return 'wwp_trade_' . sanitize_title( $label );
	}

	private static function ensure_unique_key( string $key, array $fields ): string {
		$existing = array_column( $fields, 'key' );
		$base     = $key;
		$i        = 2;
		while ( in_array( $key, $existing, true ) ) {
			$key = $base . '_' . $i++;
		}
		return $key;
	}

	private static function sanitize_definition( array $d ): array {
		$valid_types = [ 'text', 'email', 'tel', 'number', 'textarea', 'select', 'multiselect', 'radio', 'checkbox', 'file', 'display_text', 'honeypot' ];
		$type        = in_array( $d['type'] ?? 'text', $valid_types, true ) ? $d['type'] : 'text';
		$result = [
			'key'         => sanitize_key( $d['key'] ?? '' ),
			'label'       => sanitize_text_field( $d['label'] ?? '' ),
			'type'        => $type,
			'section'     => sanitize_text_field( $d['section'] ?? '' ),
			'required'    => ! empty( $d['required'] ),
			'options'     => in_array( $type, [ 'textarea', 'display_text' ], true )
							? wp_kses_post( $d['options'] ?? '' )
							: sanitize_textarea_field( $d['options'] ?? '' ),
			'multiple'    => ! empty( $d['multiple'] ),
			'assign_role' => ! empty( $d['assign_role'] ),
			'role_map'    => self::sanitize_role_map( $d['role_map'] ?? [] ),
			'wc_map'      => sanitize_key( $d['wc_map'] ?? '' ),
			'conditional' => self::sanitize_conditional( $d['conditional'] ?? [] ),
			'order'       => (int) ( $d['order'] ?? 0 ),
			'enabled'     => isset( $d['enabled'] ) ? (bool) $d['enabled'] : true,
		];

		if ( ! empty( $d['legacy_key'] ) ) {
			$result['legacy_key'] = sanitize_key( $d['legacy_key'] );
		}

		return $result;
	}

	private static function sanitize_conditional( $cond ): array {
		$valid_operators = [ 'equals', 'not_equals', 'is_empty', 'is_not_empty', 'greater_than', 'less_than' ];
		$conditions      = [];
		foreach ( (array) ( $cond['conditions'] ?? [] ) as $c ) {
			$wf = sanitize_key( $c['when_field'] ?? '' );
			if ( $wf === '' ) {
				continue;
			}
			$op           = $c['operator'] ?? 'equals';
			$conditions[] = [
				'when_field' => $wf,
				'operator'   => in_array( $op, $valid_operators, true ) ? $op : 'equals',
				'has_value'  => sanitize_text_field( $c['has_value'] ?? '' ),
			];
			if ( count( $conditions ) >= 5 ) {
				break;
			}
		}
		return [
			'enabled'    => ! empty( $cond['enabled'] ),
			'action'     => in_array( $cond['action'] ?? 'show', [ 'show', 'hide' ], true ) ? $cond['action'] : 'show',
			'match'      => ( ( $cond['match'] ?? 'all' ) === 'any' ) ? 'any' : 'all',
			'conditions' => $conditions,
		];
	}

	private static function sanitize_role_map( $map ): array {
		if ( ! is_array( $map ) ) {
			return [];
		}
		$clean = [];
		foreach ( $map as $option => $roles ) {
			$roles = array_values( array_filter( array_map( 'sanitize_key', (array) $roles ) ) );
			if ( $roles !== [] ) {
				$clean[ sanitize_text_field( $option ) ] = $roles;
			}
		}
		return $clean;
	}

	private static function save( array $fields ): bool {
		return update_option( self::OPTION_KEY, wp_json_encode( $fields ), false );
	}

	// -------------------------------------------------------------------------
	// Migrations
	// -------------------------------------------------------------------------

	/**
	 * One-time migration: import field definitions from the old 10-field legacy
	 * system (wcwp_registration_fields) into the new schema with legacy_key set,
	 * hide the legacy admin tab, and queue a background job to copy all user meta
	 * from old uniqid keys to new wcwp_trade_* keys.
	 *
	 * Does NOT activate the new form — the admin does that manually once they have
	 * reviewed and reordered the migrated fields in the form builder.
	 *
	 * Fresh installs (no wcwp_registration_fields option) are a no-op.
	 */
	public static function migrate_legacy_fields(): void {
		if ( get_option( 'wcwp_trade_migrated_legacy_fields' ) ) {
			return;
		}

		$legacy = get_option( 'wcwp_registration_fields', [] );

		if ( ! empty( $legacy ) && is_array( $legacy ) ) {
			$existing_fields = self::get_fields();
			$next_order      = count( $existing_fields );
			$key_map         = [];

			foreach ( $legacy as $unique_id => $legacy_field ) {
				$label = sanitize_text_field( $legacy_field['label'] ?? '' );
				if ( $label === '' ) {
					continue;
				}

				$legacy_key_val = sanitize_key( $unique_id );
				$new_key        = self::ensure_unique_key( self::generate_key( $label ), $existing_fields );

				$existing_fields[] = [
					'key'         => $new_key,
					'label'       => $label,
					'type'        => 'text',
					'section'     => '',
					'required'    => ( ( $legacy_field['required'] ?? '' ) === 'yes' ),
					'options'     => '',
					'multiple'    => false,
					'assign_role' => false,
					'role_map'    => [],
					'wc_map'      => '',
					'conditional' => [ 'enabled' => false, 'action' => 'show', 'match' => 'all', 'conditions' => [] ],
					'order'       => $next_order++,
					'enabled'     => true,
					'legacy_key'  => $legacy_key_val,
				];

				$key_map[ $legacy_key_val ] = $new_key;
			}

			if ( ! empty( $key_map ) ) {
				self::save( $existing_fields );
				update_option( 'wcwp_trade_hide_legacy_tab', '1', false );

				if ( function_exists( 'as_schedule_single_action' ) ) {
					as_schedule_single_action(
						time(),
						'wcwp_migrate_legacy_user_meta',
						[ 'key_map' => $key_map, 'offset' => 0 ],
						'wcwp-migration'
					);
				} else {
					self::batch_migrate_legacy_user_meta( $key_map, 0 );
				}
			}
		}

		update_option( 'wcwp_trade_migrated_legacy_fields', '1' );
	}

	/**
	 * Action Scheduler callback: copy legacy user meta to new keys in batches of 50.
	 * Re-queues itself until all users are processed.
	 */
	public static function batch_migrate_legacy_user_meta( array $key_map, int $offset ): void {
		$batch_size = 50;

		$users = get_users( [
			'fields' => 'ID',
			'number' => $batch_size,
			'offset' => $offset,
		] );

		foreach ( $users as $user_id ) {
			foreach ( $key_map as $legacy_key => $new_key ) {
				$old_value = get_user_meta( (int) $user_id, $legacy_key, true );
				if ( $old_value !== '' && $old_value !== false ) {
					update_user_meta( (int) $user_id, $new_key, $old_value );
				}
			}
		}

		if ( count( $users ) === $batch_size && function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action(
				time(),
				'wcwp_migrate_legacy_user_meta',
				[ 'key_map' => $key_map, 'offset' => $offset + $batch_size ],
				'wcwp-migration'
			);
		}
	}

	/**
	 * Fix v1.0.0 shipping conditional bug: has_value was '' (unchecked)
	 * but should be '1' (checked) so fields hide when the checkbox IS ticked.
	 */
	public static function migrate_v1_shipping(): void {
		if ( get_option( 'wcwp_trade_migration_v1_shipping' ) ) {
			return;
		}

		$fields  = self::get_fields();
		$changed = false;

		foreach ( $fields as &$field ) {
			if (
				! empty( $field['conditional']['enabled'] ) &&
				( $field['conditional']['conditions'][0]['when_field'] ?? '' ) === 'wwp_trade_shipping_same' &&
				( $field['conditional']['conditions'][0]['has_value'] ?? null ) === '' &&
				( $field['conditional']['action'] ?? '' ) === 'hide'
			) {
				$field['conditional']['conditions'][0]['has_value'] = '1';
				$changed                                            = true;
			}
		}
		unset( $field );

		if ( $changed ) {
			self::save( $fields );
		}

		update_option( 'wcwp_trade_migration_v1_shipping', '1' );
	}

	/**
	 * One-time migration: convert known Title Case default labels to sentence case.
	 */
	public static function migrate_v2_sentence_case(): void {
		if ( get_option( 'wcwp_trade_migrated_v2_labels' ) ) {
			return;
		}

		$known_map = [
			'Company / Business Name'   => 'Company / business name',
			'Contact First Name'        => 'Contact first name',
			'Contact Last Name'         => 'Contact last name',
			'Phone Number'              => 'Phone number',
			'Contact Email Address'     => 'Contact email address',
			'Business Type'             => 'Business type',
			'Website URL'               => 'Website URL',
			'VAT / Tax Number'          => 'VAT / tax number',
			'How Did You Hear About Us' => 'How did you hear about us',
			'Additional Notes'          => 'Additional notes',
			'Billing Address Line 1'    => 'Billing address line 1',
			'Billing Address Line 2'    => 'Billing address line 2',
			'Billing City'              => 'Billing city',
			'Billing County / State'    => 'Billing county / state',
			'Billing Postcode'          => 'Billing postcode',
			'Billing Country'           => 'Billing country',
			'Shipping Address Line 1'   => 'Shipping address line 1',
			'Shipping Address Line 2'   => 'Shipping address line 2',
			'Shipping City'             => 'Shipping city',
			'Shipping County / State'   => 'Shipping county / state',
			'Shipping Postcode'         => 'Shipping postcode',
			'Shipping Country'          => 'Shipping country',
			'Same As Billing Address'   => 'Same as billing address',
			'I Agree To The Terms'      => 'I agree to the terms',
		];

		$fields  = self::get_fields();
		$changed = false;

		foreach ( $fields as &$field ) {
			if ( isset( $known_map[ $field['label'] ] ) ) {
				$field['label'] = $known_map[ $field['label'] ];
				$changed        = true;
			}
		}
		unset( $field );

		if ( $changed ) {
			self::save( $fields );
		}

		update_option( 'wcwp_trade_migrated_v2_labels', '1' );
	}

	/**
	 * One-time migration: convert the old flat conditional structure
	 * { enabled, when_field, has_value, action } to the new multi-condition
	 * structure { enabled, action, match, conditions: [{when_field, has_value}] }.
	 */
	public static function migrate_v3_multi_conditions(): void {
		if ( get_option( 'wcwp_trade_migration_v3_conditions' ) ) {
			return;
		}

		$fields  = self::get_fields();
		$changed = false;

		foreach ( $fields as &$field ) {
			$cond = $field['conditional'] ?? [];
			if ( isset( $cond['when_field'] ) && ! isset( $cond['conditions'] ) ) {
				$field['conditional'] = [
					'enabled'    => ! empty( $cond['enabled'] ),
					'action'     => in_array( $cond['action'] ?? 'show', [ 'show', 'hide' ], true ) ? $cond['action'] : 'show',
					'match'      => 'all',
					'conditions' => [
						[
							'when_field' => sanitize_key( $cond['when_field'] ),
							'has_value'  => sanitize_text_field( $cond['has_value'] ?? '' ),
						],
					],
				];
				$changed = true;
			}
		}
		unset( $field );

		if ( $changed ) {
			self::save( $fields );
		}

		update_option( 'wcwp_trade_migration_v3_conditions', '1' );
	}

	// -------------------------------------------------------------------------
	// Default seed (activation)
	// -------------------------------------------------------------------------

	/**
	 * Seeds the schema with the default field set on first activation.
	 * If a schema already exists this is a no-op.
	 */
	public static function seed_defaults(): void {
		if ( get_option( self::OPTION_KEY ) ) {
			return;
		}

		$defaults = self::get_default_field_definitions();
		$fields   = [];

		foreach ( $defaults as $i => $def ) {
			$fields[] = array_merge( $def, [ 'order' => $i, 'enabled' => true ] );
		}

		self::save( $fields );
	}

	private static function get_default_field_definitions(): array {
		return [
			[
				'key'         => 'wwp_trade_company_name',
				'label'       => 'Company / Business Name',
				'type'        => 'text',
				'section'     => 'Business Information',
				'required'    => true,
				'options'     => '',
				'multiple'    => false,
				'assign_role' => false,
				'role_map'    => [],
				'conditional' => [ 'enabled' => false, 'action' => 'show', 'match' => 'all', 'conditions' => [] ],
				'wc_map'      => '',
			],
			[
				'key'         => 'wwp_trade_contact_first',
				'label'       => 'Contact First Name',
				'type'        => 'text',
				'section'     => 'Business Information',
				'required'    => true,
				'options'     => '',
				'multiple'    => false,
				'assign_role' => false,
				'role_map'    => [],
				'conditional' => [ 'enabled' => false, 'action' => 'show', 'match' => 'all', 'conditions' => [] ],
				'wc_map'      => '',
			],
			[
				'key'         => 'wwp_trade_contact_last',
				'label'       => 'Contact Last Name',
				'type'        => 'text',
				'section'     => 'Business Information',
				'required'    => true,
				'options'     => '',
				'multiple'    => false,
				'assign_role' => false,
				'role_map'    => [],
				'conditional' => [ 'enabled' => false, 'action' => 'show', 'match' => 'all', 'conditions' => [] ],
				'wc_map'      => '',
			],
			[
				'key'         => 'wwp_trade_phone',
				'label'       => 'Phone Number',
				'type'        => 'tel',
				'section'     => 'Business Information',
				'required'    => true,
				'options'     => '',
				'multiple'    => false,
				'assign_role' => false,
				'role_map'    => [],
				'conditional' => [ 'enabled' => false, 'action' => 'show', 'match' => 'all', 'conditions' => [] ],
				'wc_map'      => '',
			],
			[
				'key'         => 'wwp_trade_contact_email',
				'label'       => 'Contact Email Address',
				'type'        => 'email',
				'section'     => 'Business Information',
				'required'    => true,
				'options'     => '',
				'multiple'    => false,
				'assign_role' => false,
				'role_map'    => [],
				'conditional' => [ 'enabled' => false, 'action' => 'show', 'match' => 'all', 'conditions' => [] ],
				'wc_map'      => '',
			],
		];
	}
}
