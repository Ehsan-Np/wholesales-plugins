<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Frontend;

use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin\Tools_Tab;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Schema\Field_Schema;

/**
 * Validates form submission on the wcwp_register_post hook.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Form_Validator {

	public function validate( $username, $email, \WP_Error $errors ): \WP_Error {
		if ( ! Tools_Tab::is_form_visible() ) {
			return $errors;
		}

		// ---- Anti-spam: minimum form completion time (20 s) ----
		$raw_token = wp_unslash( $_POST['wwp_trade_loaded_at'] ?? '' );
		if ( $raw_token !== '' ) {
			$decoded = base64_decode( $raw_token, true );
			if ( $decoded !== false ) {
				$parts = explode( '|', $decoded, 2 );
				if ( count( $parts ) === 2 ) {
					[ $ts_str, $sig ] = $parts;
					$expected = hash_hmac( 'sha256', $ts_str, AUTH_KEY );
					if ( hash_equals( $expected, $sig ) && ( time() - (int) $ts_str ) < 20 ) {
						$errors->add(
							'wcwp_trade_spam',
							__( 'Your submission was received too quickly. Please take a moment to review your details and try again.', 'woocommerce-wholesale-pro' )
						);
						return $errors;
					}
				}
			}
		}

		$fields = Field_Schema::get_enabled_fields();

		foreach ( $fields as $field ) {
			if ( $field['type'] === 'display_text' || $field['type'] === 'textarea' ) {
				continue;
			}

			// ---- Anti-spam: honeypot must remain empty ----
			if ( $field['type'] === 'honeypot' ) {
				$hp = sanitize_text_field( wp_unslash( $_POST[ $field['key'] ] ?? '' ) );
				if ( $hp !== '' ) {
					$errors->add(
						'wcwp_trade_spam',
						__( 'Your submission could not be processed.', 'woocommerce-wholesale-pro' )
					);
					return $errors;
				}
				continue;
			}

			// Skip if this field is conditionally hidden.
			if ( $this->is_field_hidden( $field ) ) {
				continue;
			}

			$key      = $field['key'];
			$required = $field['required'];
			$type     = $field['type'];

			if ( $type === 'file' ) {
				if ( $required && ! $this->has_file_upload( $key ) ) {
					$errors->add(
						'wcwp_trade_' . $key,
						sprintf(
							/* translators: %s: field label */
							__( '"%s" is required.', 'woocommerce-wholesale-pro' ),
							$field['label']
						)
					);
				}
				continue;
			}

			if ( $type === 'checkbox' ) {
				if ( $required && empty( $_POST[ $key ] ) ) {
					$errors->add(
						'wcwp_trade_' . $key,
						sprintf(
							/* translators: %s: field label */
							__( 'You must check "%s".', 'woocommerce-wholesale-pro' ),
							$field['label']
						)
					);
				}
				continue;
			}

			if ( $type === 'multiselect' ) {
				$val = isset( $_POST[ $key ] ) ? (array) $_POST[ $key ] : [];
				if ( $required && empty( $val ) ) {
					$errors->add(
						'wcwp_trade_' . $key,
						sprintf(
							/* translators: %s: field label */
							__( '"%s" is required.', 'woocommerce-wholesale-pro' ),
							$field['label']
						)
					);
				}
				continue;
			}

			$value = sanitize_text_field( wp_unslash( $_POST[ $key ] ?? '' ) );

			if ( $required && $value === '' ) {
				$errors->add(
					'wcwp_trade_' . $key,
					sprintf(
						/* translators: %s: field label */
						__( '"%s" is required.', 'woocommerce-wholesale-pro' ),
						$field['label']
					)
				);
				continue;
			}

			// Type-specific validation.
			if ( $value !== '' && $type === 'email' && ! is_email( $value ) ) {
				$errors->add(
					'wcwp_trade_' . $key,
					sprintf(
						/* translators: %s: field label */
						__( '"%s" must be a valid email address.', 'woocommerce-wholesale-pro' ),
						$field['label']
					)
				);
			}
		}

		return $errors;
	}

	/**
	 * Determines if a field is currently hidden by conditional logic
	 * (server-side evaluation matching the JS engine).
	 */
	private function is_field_hidden( array $field ): bool {
		$cond = $field['conditional'] ?? [];
		if ( empty( $cond['enabled'] ) || empty( $cond['conditions'] ) ) {
			return false;
		}

		$match   = ( $cond['match'] ?? 'all' ) === 'any' ? 'any' : 'all';
		$action  = $cond['action'] ?? 'show';
		$results = [];

		foreach ( $cond['conditions'] as $c ) {
			$trigger_key = $c['when_field'] ?? '';
			if ( $trigger_key === '' ) {
				continue;
			}
			$trigger_field = Field_Schema::get_field( $trigger_key );
			if ( ! $trigger_field ) {
				$results[] = false;
				continue;
			}

			$posted_value = $trigger_field['type'] === 'checkbox'
				? ( ! empty( $_POST[ $trigger_key ] ) ? '1' : '' )
				: sanitize_text_field( wp_unslash( $_POST[ $trigger_key ] ?? '' ) );

			$op        = $c['operator'] ?? 'equals';
			$has_value = $c['has_value'] ?? '';
			switch ( $op ) {
				case 'is_empty':
					$results[] = $posted_value === '';
					break;
				case 'is_not_empty':
					$results[] = $posted_value !== '';
					break;
				case 'not_equals':
					$results[] = $posted_value !== $has_value;
					break;
				case 'greater_than':
					$results[] = is_numeric( $posted_value ) && is_numeric( $has_value ) && (float) $posted_value > (float) $has_value;
					break;
				case 'less_than':
					$results[] = is_numeric( $posted_value ) && is_numeric( $has_value ) && (float) $posted_value < (float) $has_value;
					break;
				default:
					$results[] = $posted_value === $has_value;
					break;
			}
		}

		if ( empty( $results ) ) {
			return false;
		}

		$condition_met = $match === 'any'
			? in_array( true, $results, true )
			: ! in_array( false, $results, true );

		return $action === 'show' ? ! $condition_met : $condition_met;
	}

	private function has_file_upload( string $key ): bool {
		// Support single or multiple file inputs (name=key or name=key[]).
		if ( isset( $_FILES[ $key ] ) ) {
			$error = $_FILES[ $key ]['error'];
			if ( is_array( $error ) ) {
				foreach ( $error as $e ) {
					if ( $e === UPLOAD_ERR_OK ) {
						return true;
					}
				}
				return false;
			}
			return $error === UPLOAD_ERR_OK;
		}
		return false;
	}
}
