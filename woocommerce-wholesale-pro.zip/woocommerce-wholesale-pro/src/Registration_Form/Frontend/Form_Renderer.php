<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Frontend;

use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin\Tools_Tab;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Schema\Field_Schema;

/**
 * Renders enabled form fields on the WCWP registration page.
 *
 * Layout: single-column stack (<label> above <input>) per section.
 * Checkboxes keep their inline label intact.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Form_Renderer {

	public function render(): void {
		if ( ! Tools_Tab::is_form_visible() ) {
			return;
		}

		$fields = Field_Schema::get_enabled_fields();
		if ( empty( $fields ) ) {
			return;
		}

		// When shown via admin preview link, carry the nonce into POST so
		// validation/processing also pass the is_form_visible() check.
		$preview_token = sanitize_text_field( wp_unslash( $_GET['wcwp_preview'] ?? '' ) );
		if ( $preview_token !== '' && get_option( 'wcwp_trade_form_active' ) !== 'yes' ) {
			echo '<input type="hidden" name="wcwp_preview" value="' . esc_attr( $preview_token ) . '">';
		}

		wp_nonce_field( 'wcwp_trade_upload', 'wcwp_trade_upload_nonce' );

		// Anti-spam: HMAC-signed load timestamp. Validated in Form_Validator.
		$ts    = time();
		$token = base64_encode( $ts . '|' . hash_hmac( 'sha256', (string) $ts, AUTH_KEY ) );
		echo '<input type="hidden" name="wcwp_trade_loaded_at" value="' . esc_attr( $token ) . '">';

		$current_section  = null; // null = no section opened yet
		$section_open     = false;
		$seen_sections    = []; // named sections already opened

		foreach ( $fields as $field ) {
			$field_section = $field['section'];

			// Decide whether to open a new section block.
			// A blank section between two fields that share a named section is
			// treated as part of the already-open block (graceful gap handling).
			$needs_new_block = false;
			if ( ! $section_open ) {
				$needs_new_block = true;
			} elseif ( $field_section !== '' && ! isset( $seen_sections[ $field_section ] ) ) {
				// A genuinely new named section we haven't seen before.
				$needs_new_block = true;
			}
			// If $field_section === '' we stay inside the current open block.
			// If $field_section is a name we've already opened, same — no new block.

			if ( $needs_new_block ) {
				if ( $section_open ) {
					echo '</div></div>';
				}
				$current_section = $field_section;
				echo '<div class="wcwp-form-section">';
				if ( $current_section !== '' ) {
					$seen_sections[ $current_section ] = true;
					echo '<h3 class="wcwp-section-title">' . esc_html( $current_section ) . '</h3>';
				}
				echo '<div class="wcwp-form-fields">';
				$section_open = true;
			}

			$this->render_row( $field );
		}

		if ( $section_open ) {
			echo '</div></div>';
		}
	}

	// -----------------------------------------------------------------------
	// Row dispatcher
	// -----------------------------------------------------------------------

	private function render_row( array $field ): void {
		$type       = $field['type'];
		$value      = $this->get_posted_value( $field['key'], $type );
		$cond_attrs = $this->cond_attrs( $field );
		$row_class  = 'wcwp-field-wrap wcwp-field-type-' . esc_attr( $type );

		if ( $type === 'display_text' ) {
			$content = ! empty( $field['options'] ) ? $field['options'] : '';
			echo '<div class="wcwp-field-wrap wcwp-field-type-display-text"' . $cond_attrs . '>';
			echo '<p class="wcwp-display-text">' . wp_kses_post( $content ) . '</p>';
			echo '</div>';
			return;
		}

		if ( $type === 'textarea' ) {
			$content = $field['options'] ?? '';
			if ( $content !== '' ) {
				echo '<div class="wcwp-field-wrap wcwp-field-type-paragraph"' . $cond_attrs . '>';
				echo '<div class="wcwp-paragraph-content">' . wp_kses_post( $content ) . '</div>';
				echo '</div>';
			}
			return;
		}

		if ( $type === 'honeypot' ) {
			// Off-screen hidden trap field — never seen by real users, bots fill it.
			echo '<div class="wcwp-field-type-honeypot" aria-hidden="true" style="position:absolute;left:-9999px;height:0;overflow:hidden;">';
			echo '<label for="' . esc_attr( $field['key'] ) . '">' . esc_html( $field['label'] ) . '</label>';
			echo '<input type="text"'
				. ' id="' . esc_attr( $field['key'] ) . '"'
				. ' name="' . esc_attr( $field['key'] ) . '"'
				. ' value="" tabindex="-1" autocomplete="off">';
			echo '</div>';
		} elseif ( $type === 'checkbox' ) {
			echo '<div class="' . esc_attr( $row_class ) . '"' . $cond_attrs . '>';
			$this->render_checkbox_content( $field, (bool) $value );
			echo '</div>';
		} else {
			echo '<div class="' . esc_attr( $row_class ) . '"' . $cond_attrs . '>';
			echo $this->label_el( $field );
			switch ( $type ) {
				case 'text':
				case 'email':
				case 'tel':
				case 'number':
					$this->render_input_content( $field, (string) $value );
					break;
				case 'textarea':
					$this->render_textarea_content( $field, (string) $value );
					break;
				case 'select':
					$this->render_select_content( $field, (string) $value, false );
					break;
				case 'multiselect':
					$this->render_select_content( $field, (array) $value, true );
					break;
				case 'radio':
					$this->render_radio_content( $field, (string) $value );
					break;
				case 'file':
					$this->render_file_content( $field );
					break;
			}
			echo '</div>';
		}
	}

	// -----------------------------------------------------------------------
	// Field content renderers (no wrapper, no label — those are in the row)
	// -----------------------------------------------------------------------

	private function render_input_content( array $field, string $value ): void {
		$key      = $field['key'];
		$type     = $field['type'];
		$required = $field['required'];
		echo '<input type="' . esc_attr( $type ) . '"'
			. ' id="' . esc_attr( $key ) . '"'
			. ' name="' . esc_attr( $key ) . '"'
			. ' class="woocommerce-Input woocommerce-Input--text input-text wcwp-input"'
			. ' value="' . esc_attr( $value ) . '"'
			. ( $required ? ' required' : '' ) . '>';
	}

	private function render_textarea_content( array $field, string $value ): void {
		$key      = $field['key'];
		$required = $field['required'];
		echo '<textarea'
			. ' id="' . esc_attr( $key ) . '"'
			. ' name="' . esc_attr( $key ) . '"'
			. ' class="woocommerce-Input input-text wcwp-input"'
			. ' rows="4"'
			. ( $required ? ' required' : '' ) . '>'
			. esc_textarea( $value )
			. '</textarea>';
	}

	private function render_select_content( array $field, $value, bool $multiple ): void {
		$key      = $field['key'];
		$required = $field['required'];
		$options  = $this->parse_options( $field );
		$multi    = $multiple ? ' multiple' : '';
		$name     = $multiple ? $key . '[]' : $key;
		$selected = (array) $value;

		if ( in_array( $key, [ 'wwp_trade_billing_country', 'wwp_trade_shipping_country' ], true ) ) {
			$options = $this->get_wc_countries();
		}

		echo '<select'
			. ' id="' . esc_attr( $key ) . '"'
			. ' name="' . esc_attr( $name ) . '"'
			. ' class="woocommerce-Input wcwp-select"'
			. $multi
			. ( $required && ! $multiple ? ' required' : '' ) . '>';

		if ( ! $multiple ) {
			echo '<option value="">' . esc_html__( '— Please select —', 'woocommerce-wholesale-pro' ) . '</option>';
		}
		foreach ( $options as $opt_value => $opt_label ) {
			echo '<option value="' . esc_attr( $opt_value ) . '"'
				. ( in_array( $opt_value, $selected, true ) ? ' selected' : '' ) . '>'
				. esc_html( $opt_label )
				. '</option>';
		}
		echo '</select>';
	}

	private function render_radio_content( array $field, string $value ): void {
		$key      = $field['key'];
		$required = $field['required'];
		$options  = $this->parse_options( $field );

		echo '<div class="wcwp-radio-group">';
		foreach ( $options as $opt ) {
			$checked = $value === $opt ? ' checked' : '';
			echo '<label class="wcwp-radio-label">'
				. '<input type="radio" name="' . esc_attr( $key ) . '" value="' . esc_attr( $opt ) . '"'
				. $checked
				. ( $required ? ' required' : '' ) . '> '
				. esc_html( $opt )
				. '</label>';
		}
		echo '</div>';
	}

	private function render_file_content( array $field ): void {
		$key      = $field['key'];
		$required = $field['required'];
		$multiple = ! empty( $field['multiple'] );
		$name     = $multiple ? $key . '[]' : $key;

		if ( $multiple ) {
			echo '<span class="wcwp-file-hint">'
				. esc_html__( 'You can select multiple files at once.', 'woocommerce-wholesale-pro' )
				. '</span>';
		}
		echo '<input type="file"'
			. ' id="' . esc_attr( $key ) . '"'
			. ' name="' . esc_attr( $name ) . '"'
			. ' class="wcwp-file-input"'
			. ( $multiple ? ' multiple' : '' )
			. ( $required ? ' required' : '' ) . '>';
	}

	private function render_checkbox_content( array $field, bool $checked ): void {
		$key      = $field['key'];
		$required = $field['required'];
		echo '<label class="wcwp-checkbox-label">'
			. '<input type="checkbox"'
			. ' id="' . esc_attr( $key ) . '"'
			. ' name="' . esc_attr( $key ) . '"'
			. ' value="1"'
			. ( $checked ? ' checked' : '' )
			. ( $required ? ' required' : '' )
			. ' class="input-checkbox woocommerce-form__input-checkbox">'
			. ' <span>' . esc_html( $field['label'] ) . ( $required ? ' <span class="required">*</span>' : '' ) . '</span>'
			. '</label>';
	}

	// -----------------------------------------------------------------------
	// Helpers
	// -----------------------------------------------------------------------

	private function label_el( array $field ): string {
		return '<label for="' . esc_attr( $field['key'] ) . '">'
			. esc_html( $field['label'] )
			. ( $field['required'] ? ' <span class="required">*</span>' : '' )
			. '</label>';
	}

	private function cond_attrs( array $field ): string {
		$cond = $field['conditional'] ?? [];
		if ( empty( $cond['enabled'] ) || empty( $cond['conditions'] ) ) {
			return '';
		}
		return ' data-conditions="' . esc_attr( wp_json_encode( [
			'action'     => $cond['action'] ?? 'show',
			'match'      => $cond['match'] ?? 'all',
			'conditions' => $cond['conditions'],
		] ) ) . '"';
	}

	private function parse_options( array $field ): array {
		$raw   = $field['options'] ?? '';
		$lines = preg_split( '/[\r\n,]+/', $raw );
		$opts  = [];
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( $line !== '' ) {
				$opts[ $line ] = $line;
			}
		}
		return $opts;
	}

	private function get_wc_countries(): array {
		if ( function_exists( 'WC' ) && WC()->countries ) {
			return WC()->countries->get_countries();
		}
		return [];
	}

	private function get_posted_value( string $key, string $type ) {
		if ( $type === 'checkbox' ) {
			return ! empty( $_POST[ $key ] );
		}
		if ( $type === 'multiselect' ) {
			return isset( $_POST[ $key ] ) ? array_map( 'sanitize_text_field', (array) $_POST[ $key ] ) : [];
		}
		return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
	}
}
