<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Frontend;

use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin\Tools_Tab;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Schema\Field_Schema;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Upload\File_Handler;

/**
 * Saves submitted registration data to user meta on wcwp_created_customer.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Form_Processor {

	public function save( int $customer_id, array $new_customer_data ): void {
		if ( ! Tools_Tab::is_form_visible() ) {
			return;
		}

		$fields = Field_Schema::get_enabled_fields();

		foreach ( $fields as $field ) {
			$key  = $field['key'];
			$type = $field['type'];

			if ( $type === 'honeypot' || $type === 'display_text' || $type === 'textarea' ) {
				continue;
			}

			if ( $this->is_field_hidden( $field ) ) {
				delete_user_meta( $customer_id, $key );
				if ( ! empty( $field['legacy_key'] ) ) {
					delete_user_meta( $customer_id, $field['legacy_key'] );
				}
				continue;
			}

			if ( $type === 'file' ) {
				$stored = File_Handler::upload( $key, $customer_id, ! empty( $field['multiple'] ) );
				if ( ! empty( $stored ) ) {
					update_user_meta( $customer_id, 'wwp_trade_files_' . $key, $stored );
				}
				continue;
			}

			$value = $this->get_sanitized_value( $key, $type );
			update_user_meta( $customer_id, $key, $value );

			// Keep legacy meta key in sync so profile panels reading old keys stay current.
			if ( ! empty( $field['legacy_key'] ) ) {
				update_user_meta( $customer_id, $field['legacy_key'], $value );
			}

			// Auto-assign user roles if configured.
			if ( ! empty( $field['assign_role'] ) && ! empty( $field['role_map'] ) ) {
				$selected = is_array( $value ) ? ( $value[0] ?? '' ) : (string) $value;
				$raw_role = $field['role_map'][ $selected ] ?? '';
				// role_map values may be a legacy array or the new scalar string.
				$role = is_array( $raw_role ) ? ( $raw_role[0] ?? '' ) : (string) $raw_role;
				if ( $role && get_role( $role ) ) {
					( new \WP_User( $customer_id ) )->set_role( $role );
				}
			}
		}

		// Populate standard WooCommerce billing/shipping meta.
		$this->map_to_wc_meta( $customer_id );
		$this->maybe_copy_billing_to_shipping( $customer_id );
	}

	private function get_sanitized_value( string $key, string $type ) {
		switch ( $type ) {
			case 'checkbox':
				return ! empty( $_POST[ $key ] ) ? '1' : '0';
			case 'multiselect':
				return isset( $_POST[ $key ] ) ? array_map( 'sanitize_text_field', (array) $_POST[ $key ] ) : [];
			case 'number':
				return isset( $_POST[ $key ] ) ? (string) floatval( $_POST[ $key ] ) : '';
			case 'email':
				return isset( $_POST[ $key ] ) ? sanitize_email( wp_unslash( $_POST[ $key ] ) ) : '';
			case 'textarea':
				return isset( $_POST[ $key ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) ) : '';
			default:
				return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
		}
	}

	private function is_field_hidden( array $field ): bool {
		$cond = $field['conditional'] ?? [];
		if ( empty( $cond['enabled'] ) || empty( $cond['conditions'] ) ) {
			return false;
		}

		$match   = ( $cond['match'] ?? 'all' ) === 'any' ? 'any' : 'all';
		$action  = $cond['action'] ?? 'show';
		$results = [];

		foreach ( $cond['conditions'] as $c ) {
			$trigger_key = $c['when_field'] ?? '';
			if ( $trigger_key === '' ) {
				continue;
			}
			$trigger_field = Field_Schema::get_field( $trigger_key );
			if ( ! $trigger_field ) {
				$results[] = false;
				continue;
			}

			$posted_value = $trigger_field['type'] === 'checkbox'
				? ( ! empty( $_POST[ $trigger_key ] ) ? '1' : '' )
				: sanitize_text_field( wp_unslash( $_POST[ $trigger_key ] ?? '' ) );

			$op        = $c['operator'] ?? 'equals';
			$has_value = $c['has_value'] ?? '';
			switch ( $op ) {
				case 'is_empty':
					$results[] = $posted_value === '';
					break;
				case 'is_not_empty':
					$results[] = $posted_value !== '';
					break;
				case 'not_equals':
					$results[] = $posted_value !== $has_value;
					break;
				case 'greater_than':
					$results[] = is_numeric( $posted_value ) && is_numeric( $has_value ) && (float) $posted_value > (float) $has_value;
					break;
				case 'less_than':
					$results[] = is_numeric( $posted_value ) && is_numeric( $has_value ) && (float) $posted_value < (float) $has_value;
					break;
				default:
					$results[] = $posted_value === $has_value;
					break;
			}
		}

		if ( empty( $results ) ) {
			return false;
		}

		$condition_met = $match === 'any'
			? in_array( true, $results, true )
			: ! in_array( false, $results, true );

		return $action === 'show' ? ! $condition_met : $condition_met;
	}

	/**
	 * Mirror trade form fields to WooCommerce user meta based on each field's wc_map setting.
	 */
	private function map_to_wc_meta( int $customer_id ): void {
		foreach ( Field_Schema::get_enabled_fields() as $field ) {
			if ( empty( $field['wc_map'] ) ) {
				continue;
			}
			$val = get_user_meta( $customer_id, $field['key'], true );
			if ( $val !== '' && $val !== false ) {
				update_user_meta( $customer_id, $field['wc_map'], $val );
			}
		}
	}

	/**
	 * When "shipping same as billing" is checked, copy the mapped WC billing keys to shipping.
	 */
	private function maybe_copy_billing_to_shipping( int $customer_id ): void {
		if ( get_user_meta( $customer_id, 'wwp_trade_shipping_same', true ) !== '1' ) {
			return;
		}
		$copy = [
			'shipping_first_name' => 'billing_first_name',
			'shipping_last_name'  => 'billing_last_name',
			'shipping_address_1'  => 'billing_address_1',
			'shipping_address_2'  => 'billing_address_2',
			'shipping_city'       => 'billing_city',
			'shipping_state'      => 'billing_state',
			'shipping_postcode'   => 'billing_postcode',
			'shipping_country'    => 'billing_country',
		];
		foreach ( $copy as $dest => $src ) {
			$val = get_user_meta( $customer_id, $src, true );
			if ( $val !== '' && $val !== false ) {
				update_user_meta( $customer_id, $dest, $val );
			}
		}
	}
}
