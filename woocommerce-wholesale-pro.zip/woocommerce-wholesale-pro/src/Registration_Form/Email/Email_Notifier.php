<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Email;

use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Schema\Field_Schema;
use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Upload\File_Handler;

/**
 * Injects submitted field data into WCWP's built-in admin notification email.
 * All other email notifications (applicant confirmation, redirect) are
 * managed directly within WooCommerce Wholesale Pro.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Email_Notifier {

	// -----------------------------------------------------------------------
	// WCWP admin email injection
	// -----------------------------------------------------------------------

	/**
	 * Appends submitted field data to the admin "New wholesale user" email (with download links).
	 */
	public function inject_field_table_admin( string $content, $object, $email ): string {
		return $this->inject_field_table( $content, $object, true );
	}

	/**
	 * Appends submitted field data to the customer "Registration pending" email (filenames only, no links).
	 */
	public function inject_field_table_customer( string $content, $object, $email ): string {
		return $this->inject_field_table( $content, $object, false );
	}

	private function inject_field_table( string $content, $object, bool $admin_links ): string {
		if ( ! $object instanceof \WP_User ) {
			return $content;
		}

		$fields  = Field_Schema::get_enabled_fields();
		$summary = $this->build_summary( $object->ID, $fields );

		if ( empty( $summary ) ) {
			return $content;
		}

		$heading = '<h3 style="font-size:14px;font-weight:700;color:#333;margin:24px 0 8px;">'
			. esc_html__( 'Registration Details', 'woocommerce-wholesale-pro' )
			. '</h3>';

		return $content . "\n\n" . $heading . $this->build_field_table_html( $summary, $admin_links );
	}

	// -----------------------------------------------------------------------
	// Shared field table HTML builder
	// -----------------------------------------------------------------------

	/**
	 * Renders all summary rows as a sectioned 2-column HTML table string.
	 *
	 * @param bool $admin_links Whether to render file download links (true) or filenames only (false).
	 */
	public function build_field_table_html( array $summary, bool $admin_links = true ): string {
		if ( empty( $summary ) ) {
			return '';
		}

		// Build section map from the live schema.
		$section_map = [];
		foreach ( Field_Schema::get_enabled_fields() as $f ) {
			$section_map[ $f['key'] ] = $f['section'] ?? '';
		}

		$html            = '';
		$current_section = null;
		$table_open      = false;

		foreach ( $summary as $row ) {
			$section = $section_map[ $row['key'] ] ?? '';

			// New section heading.
			if ( $section !== $current_section ) {
				if ( $table_open ) {
					$html .= '</table>';
					$table_open = false;
				}
				$current_section = $section;
				if ( $section !== '' ) {
					$accent = get_option( 'woocommerce_email_base_color', '#7f54b3' );
					$html  .= '<h3 style="font-size:14px;font-weight:700;color:' . esc_attr( $accent ) . ';margin:20px 0 6px;border-bottom:1px solid #e1e1e1;padding-bottom:5px;">'
						. esc_html( $section ) . '</h3>';
				}
			}

			if ( ! $table_open ) {
				$html .= '<table width="100%" cellpadding="0" cellspacing="0" border="0" '
					. 'style="border-collapse:collapse;font-size:14px;">';
				$table_open = true;
			}

			if ( $row['type'] === 'file' ) {
				$files_html = '';
				foreach ( $row['files'] as $rel_path ) {
					$filename = basename( $rel_path );
					if ( $admin_links ) {
						$dl_url      = File_Handler::get_download_url( $rel_path );
						$accent      = get_option( 'woocommerce_email_base_color', '#7f54b3' );
						$files_html .= '<a href="' . esc_url( $dl_url ) . '" '
							. 'style="display:inline-block;margin-bottom:3px;color:' . esc_attr( $accent ) . ';text-decoration:none;">'
							. esc_html( $filename ) . '</a><br>';
					} else {
						$files_html .= esc_html( $filename ) . '<br>';
					}
				}
				$html .= '<tr>'
					. '<td width="38%" style="padding:7px 12px 7px 0;color:#555;font-weight:700;vertical-align:top;border-bottom:1px solid #f0f0f0;">'
					. esc_html( $row['label'] ) . '</td>'
					. '<td style="padding:7px 0;vertical-align:top;border-bottom:1px solid #f0f0f0;">'
					. $files_html . '</td>'
					. '</tr>';
			} else {
				$html .= '<tr>'
					. '<td width="38%" style="padding:7px 12px 7px 0;color:#555;font-weight:700;vertical-align:top;border-bottom:1px solid #f0f0f0;">'
					. esc_html( $row['label'] ) . '</td>'
					. '<td style="padding:7px 0;color:#222;vertical-align:top;border-bottom:1px solid #f0f0f0;">'
					. esc_html( $row['value'] ) . '</td>'
					. '</tr>';
			}
		}

		if ( $table_open ) {
			$html .= '</table>';
		}

		return $html;
	}

	// -----------------------------------------------------------------------
	// Summary builder
	// -----------------------------------------------------------------------

	/**
	 * Build flat array of { key, label, type, value, files } rows from user meta.
	 */
	public function build_summary( int $customer_id, array $fields ): array {
		$rows = [];
		foreach ( $fields as $field ) {
			$key  = $field['key'];
			$type = $field['type'];

			if ( $type === 'honeypot' ) {
				continue;
			}

			if ( $type === 'file' ) {
				$files = (array) get_user_meta( $customer_id, 'wwp_trade_files_' . $key, true );
				if ( ! empty( $files ) ) {
					$rows[] = [
						'key'   => $key,
						'label' => $field['label'],
						'type'  => 'file',
						'value' => '',
						'files' => $files,
					];
				}
				continue;
			}

			$meta  = get_user_meta( $customer_id, $key, true );
			$value = '';

			if ( $type === 'checkbox' ) {
				$value = $meta === '1' ? 'Yes' : 'No';
			} elseif ( is_array( $meta ) ) {
				$value = implode( ', ', $meta );
			} else {
				$value = (string) $meta;
			}

			if ( $value === '' || $value === '0' ) {
				continue; // Skip empty optional fields.
			}

			$rows[] = [
				'key'   => $key,
				'label' => $field['label'],
				'type'  => $type,
				'value' => $value,
				'files' => [],
			];
		}
		return $rows;
	}
}
