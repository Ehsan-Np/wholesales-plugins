<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin;

/**
 * Integrates the Form Builder into the Wholesale Pro WC settings tab
 * as a "Registration fields" section.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Form_Builder_Page {

	const WC_SECTION_URL_ARGS = [ 'page' => 'wc-settings', 'tab' => 'wholesale-pro', 'section' => 'registration-form' ];

	public static function section_url( array $extra = [] ): string {
		return add_query_arg( array_merge( self::WC_SECTION_URL_ARGS, $extra ), admin_url( 'admin.php' ) );
	}

	public function add_wc_section( array $sections ): array {
		$insert_before = 'payment-roles';
		$position      = array_search( $insert_before, array_keys( $sections ), true );

		if ( $position === false ) {
			$sections['registration-form'] = __( 'Registration fields', 'woocommerce-wholesale-pro' );
		} else {
			$sections = array_slice( $sections, 0, $position, true )
				+ [ 'registration-form' => __( 'Registration fields', 'woocommerce-wholesale-pro' ) ]
				+ array_slice( $sections, $position, null, true );
		}

		return $sections;
	}

	public function maybe_render_section(): void {
		static $rendered = false;
		if ( $rendered ) {
			return;
		}
		$section = isset( $_GET['section'] ) ? sanitize_key( $_GET['section'] ) : '';
		if ( $section !== 'registration-form' ) {
			return;
		}
		$rendered = true;
		( new Form_Builder_Tab() )->render();
		// Suppress WC's save button row and the empty submit <p> it leaves behind.
		$GLOBALS['hide_save_button'] = true;
		echo '<style>.woocommerce-save-button,#mainform p.submit:not(.wcwp-submit){display:none!important;height:0!important;margin:0!important;padding:0!important}</style>';
	}

	/**
	 * Finds the first published page containing [wholesale_registration] and
	 * returns its permalink, or null if none found.
	 * Result is cached for 5 minutes so the DB query only runs occasionally.
	 */
	public static function get_preview_url(): ?string {
		$transient_key = 'wcwp_trade_preview_url';
		$cached        = get_transient( $transient_key );
		if ( $cached !== false ) {
			return $cached ?: null;
		}

		global $wpdb;
		$post_id = $wpdb->get_var(
			"SELECT ID FROM {$wpdb->posts}
			 WHERE post_status = 'publish'
			 AND post_type = 'page'
			 AND post_content LIKE '%[wholesale_registration]%'
			 LIMIT 1"
		);

		$url = $post_id ? get_permalink( (int) $post_id ) : '';
		// Only cache positive results — a missing page may be created at any time.
		if ( $url ) {
			set_transient( $transient_key, $url, 5 * MINUTE_IN_SECONDS );
		}
		return $url ?: null;
	}

	public function handle_requests(): void {
		( new Form_Builder_Tab() )->handle_post();
		( new Import_Export_Tab() )->handle_post();
		( new Tools_Tab() )->handle_post();
	}
}
