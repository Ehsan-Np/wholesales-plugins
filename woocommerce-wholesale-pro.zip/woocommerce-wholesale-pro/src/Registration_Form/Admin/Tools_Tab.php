<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Schema\Field_Schema;

/**
 * Tools tab: schema resets.
 *
 * Form visibility is controlled via the wcwp_trade_form_active option
 * saved by Wholesale Pro's General settings tab.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Tools_Tab {

	const PREVIEW_NONCE_ACTION = 'wcwp_preview_form';

	/**
	 * Returns true when the trade form should be rendered/validated/processed.
	 *
	 * True when:
	 *  - wcwp_trade_form_active option is 'yes' (set via Wholesale > General), OR
	 *  - a valid wcwp_preview nonce is present in GET or POST (admin preview link).
	 */
	public static function is_form_visible(): bool {
		if ( get_option( 'wcwp_trade_form_active' ) === 'yes' ) {
			return true;
		}

		$token = sanitize_text_field( wp_unslash(
			$_GET['wcwp_preview'] ?? $_POST['wcwp_preview'] ?? ''
		) );
		if ( $token !== '' && wp_verify_nonce( $token, self::PREVIEW_NONCE_ACTION ) ) {
			return true;
		}

		return false;
	}

	// -------------------------------------------------------------------------
	// Request handler (admin_init)
	// -------------------------------------------------------------------------

	public function handle_post(): void {
		if ( empty( $_POST['wcwp_tools_action'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		switch ( sanitize_key( $_POST['wcwp_tools_action'] ) ) {
			case 'reset_empty':
				check_admin_referer( 'wcwp_tools_reset_empty' );
				update_option( Field_Schema::OPTION_KEY, wp_json_encode( [] ), false );
				wp_safe_redirect( Form_Builder_Page::section_url( [ 'reset' => 'empty' ] ) );
				exit;

			case 'reset_default':
				check_admin_referer( 'wcwp_tools_reset_default' );
				delete_option( Field_Schema::OPTION_KEY );
				Field_Schema::seed_defaults();
				wp_safe_redirect( Form_Builder_Page::section_url( [ 'reset' => 'default' ] ) );
				exit;
		}
	}

	// -------------------------------------------------------------------------
	// Renderer
	// -------------------------------------------------------------------------

	/** Renders only the reset success notice (used by Form_Builder_Tab). */
	public function render_notice(): void {
		if ( isset( $_GET['reset'] ) ) {
			$msg = ( $_GET['reset'] === 'empty' )
				? __( 'Form reset to empty. You can now build your form from scratch.', 'woocommerce-wholesale-pro' )
				: __( 'Form reset to the default fields.', 'woocommerce-wholesale-pro' );
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $msg ) . '</p></div>';
		}
	}

	public function render(): void {
		?>
		<div class="wcwp-ie-row" style="margin-top:12px;">
			<p class="description" style="width:100%;margin:0 0 8px;">
				<?php esc_html_e( 'These actions permanently alter the form schema and cannot be undone. Export your schema first if you need a backup.', 'woocommerce-wholesale-pro' ); ?>
			</p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wcwp-ie-block"
				onsubmit="return confirm('<?php echo esc_js( __( 'This will delete ALL form fields. This cannot be undone. Continue?', 'woocommerce-wholesale-pro' ) ); ?>')">
				<?php wp_nonce_field( 'wcwp_tools_reset_empty' ); ?>
				<input type="hidden" name="action" value="wcwp_tools_action">
				<input type="hidden" name="wcwp_tools_action" value="reset_empty">
				<button type="submit" class="button button-secondary">
					<?php esc_html_e( 'Reset to Empty', 'woocommerce-wholesale-pro' ); ?>
				</button>
				<span class="wcwp-ie-desc"><?php esc_html_e( 'Removes all fields for a blank form.', 'woocommerce-wholesale-pro' ); ?></span>
			</form>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wcwp-ie-block"
				onsubmit="return confirm('<?php echo esc_js( __( 'This will delete all current fields and restore the default form. This cannot be undone. Continue?', 'woocommerce-wholesale-pro' ) ); ?>')">
				<?php wp_nonce_field( 'wcwp_tools_reset_default' ); ?>
				<input type="hidden" name="action" value="wcwp_tools_action">
				<input type="hidden" name="wcwp_tools_action" value="reset_default">
				<button type="submit" class="button button-secondary">
					<?php esc_html_e( 'Reset to Default', 'woocommerce-wholesale-pro' ); ?>
				</button>
				<span class="wcwp-ie-desc"><?php esc_html_e( 'Restores the default business information form.', 'woocommerce-wholesale-pro' ); ?></span>
			</form>
		</div>
		<?php
	}
}
