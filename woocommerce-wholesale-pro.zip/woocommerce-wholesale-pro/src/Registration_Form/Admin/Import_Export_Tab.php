<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Schema\Field_Schema;

use const Barn2\Plugin\WC_Wholesale_Pro\PLUGIN_VERSION;

/**
 * Import / Export tab: download or upload form schema as JSON.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Import_Export_Tab {

	const NONCE_EXPORT = 'wcwp_trade_export';
	const NONCE_IMPORT = 'wcwp_trade_import';

	public function handle_post(): void {
		$this->maybe_handle_export();
		$this->maybe_handle_import();
	}

	// -------------------------------------------------------------------------
	// Export
	// -------------------------------------------------------------------------

	private function maybe_handle_export(): void {
		if ( ! isset( $_POST['wcwp_export_schema'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		check_admin_referer( self::NONCE_EXPORT );

		$payload = [
			'plugin'   => 'woocommerce-wholesale-pro',
			'version'  => defined( 'Barn2\Plugin\WC_Wholesale_Pro\PLUGIN_VERSION' ) ? PLUGIN_VERSION : '',
			'exported' => gmdate( 'c' ),
			'schema'   => Field_Schema::get_fields(),
		];

		$json     = wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
		$sitename = sanitize_file_name( get_bloginfo( 'name' ) );
		$filename = 'wwp-form-' . $sitename . '-' . gmdate( 'Y-m-d' ) . '.json';

		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . strlen( $json ) );
		header( 'Cache-Control: no-cache' );
		echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	// -------------------------------------------------------------------------
	// Import
	// -------------------------------------------------------------------------

	private function maybe_handle_import(): void {
		if ( ! isset( $_POST['wcwp_import_schema'] ) ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		check_admin_referer( self::NONCE_IMPORT );

		if ( empty( $_FILES['import_file']['tmp_name'] ) || (int) $_FILES['import_file']['error'] !== UPLOAD_ERR_OK ) {
			$this->redirect_with_notice( 'No file uploaded or upload error.', 'error' );
			return;
		}

		$raw     = file_get_contents( $_FILES['import_file']['tmp_name'] ); // phpcs:ignore
		$payload = json_decode( $raw, true );

		if ( ! is_array( $payload ) || empty( $payload['schema'] ) || ! is_array( $payload['schema'] ) ) {
			$this->redirect_with_notice( 'Invalid import file: missing or malformed schema.', 'error' );
			return;
		}

		$imported = array_filter( array_map( [ $this, 'sanitize_imported_field' ], $payload['schema'] ) );
		$imported = array_values( $imported );

		if ( empty( $imported ) ) {
			$this->redirect_with_notice( 'No valid fields found in import file.', 'error' );
			return;
		}

		$mode  = ( isset( $_POST['import_mode'] ) && $_POST['import_mode'] === 'merge' ) ? 'merge' : 'replace';
		$added = 0;

		if ( $mode === 'replace' ) {
			update_option( Field_Schema::OPTION_KEY, $imported, false );
		} else {
			$existing      = Field_Schema::get_fields();
			$existing_keys = array_column( $existing, 'key' );
			foreach ( $imported as $field ) {
				if ( ! in_array( $field['key'], $existing_keys, true ) ) {
					$existing[] = $field;
					$added++;
				}
			}
			update_option( Field_Schema::OPTION_KEY, $existing, false );
		}

		$count = count( $imported );
		$msg   = $mode === 'replace'
			? sprintf( 'Import complete. %d field(s) loaded.', $count )
			: sprintf( 'Import complete. %d new field(s) added.', $added );

		$this->redirect_with_notice( $msg );
	}

	private function sanitize_imported_field( array $field ): ?array {
		if ( empty( $field['key'] ) || empty( $field['label'] ) || empty( $field['type'] ) ) {
			return null;
		}

		$valid_types = [ 'text', 'email', 'tel', 'number', 'textarea', 'select', 'multiselect', 'radio', 'checkbox', 'file', 'display_text', 'honeypot' ];
		$cond        = $field['conditional'] ?? [];

		$result = [
			'key'         => sanitize_key( $field['key'] ),
			'label'       => sanitize_text_field( $field['label'] ),
			'type'        => in_array( $field['type'], $valid_types, true ) ? $field['type'] : 'text',
			'section'     => sanitize_text_field( $field['section'] ?? '' ),
			'required'    => ! empty( $field['required'] ),
			'enabled'     => isset( $field['enabled'] ) ? (bool) $field['enabled'] : true,
			'options'     => in_array( $field['type'], [ 'textarea', 'display_text' ], true )
								? wp_kses_post( $field['options'] ?? '' )
								: sanitize_textarea_field( $field['options'] ?? '' ),
			'multiple'    => ! empty( $field['multiple'] ),
			'assign_role' => ! empty( $field['assign_role'] ),
			'role_map'    => is_array( $field['role_map'] ?? null )
								? array_map(
									static function ( $v ) {
										$v = is_array( $v ) ? ( $v[0] ?? '' ) : $v;
										return sanitize_key( (string) $v );
									},
									$field['role_map']
								)
								: [],
			'wc_map'      => sanitize_key( $field['wc_map'] ?? '' ),
			'order'       => absint( $field['order'] ?? 0 ),
			'conditional' => [
				'enabled'    => ! empty( $cond['enabled'] ),
				'when_field' => sanitize_key( $cond['when_field'] ?? '' ),
				'has_value'  => sanitize_text_field( $cond['has_value'] ?? '' ),
				'action'     => in_array( $cond['action'] ?? 'show', [ 'show', 'hide' ], true )
								? $cond['action'] : 'show',
			],
		];

		if ( ! empty( $field['legacy_key'] ) ) {
			$result['legacy_key'] = sanitize_key( $field['legacy_key'] );
		}

		return $result;
	}

	private function redirect_with_notice( string $message, string $type = 'success' ): void {
		wp_safe_redirect( Form_Builder_Page::section_url( [
			'wcwp_notice'      => rawurlencode( $message ),
			'wcwp_notice_type' => $type,
		] ) );
		exit;
	}

	// -------------------------------------------------------------------------
	// Render
	// -------------------------------------------------------------------------

	public function render(): void {
		$notice_type = isset( $_GET['wcwp_notice_type'] ) ? sanitize_key( $_GET['wcwp_notice_type'] ) : '';
		$notice      = ( $notice_type !== '' && isset( $_GET['wcwp_notice'] ) )
			? sanitize_text_field( urldecode( $_GET['wcwp_notice'] ) )
			: '';

		if ( $notice ) {
			$cls = $notice_type === 'error' ? 'notice-error' : 'notice-success';
			echo '<div class="notice ' . esc_attr( $cls ) . ' is-dismissible"><p>' . esc_html( $notice ) . '</p></div>';
		}

		$field_count = count( Field_Schema::get_fields() );
		?>
		<div class="wcwp-ie-row">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data" class="wcwp-ie-block">
				<?php wp_nonce_field( self::NONCE_IMPORT ); ?>
				<input type="hidden" name="action" value="wcwp_import_schema">
				<strong><?php esc_html_e( 'Import', 'woocommerce-wholesale-pro' ); ?></strong>
				<input type="file" name="import_file" accept=".json,application/json" style="vertical-align:middle;">
				<label>
					<input type="radio" name="import_mode" value="replace" checked>
					<?php esc_html_e( 'Replace', 'woocommerce-wholesale-pro' ); ?>
				</label>
				<label>
					<input type="radio" name="import_mode" value="merge">
					<?php esc_html_e( 'Merge', 'woocommerce-wholesale-pro' ); ?>
				</label>
				<button type="submit" name="wcwp_import_schema" value="1" class="button"
				        onclick="return confirm('<?php esc_attr_e( 'Are you sure? This will modify your current form fields.', 'woocommerce-wholesale-pro' ); ?>')">
					<?php esc_html_e( 'Import', 'woocommerce-wholesale-pro' ); ?>
				</button>
			</form>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wcwp-ie-block">
				<?php wp_nonce_field( self::NONCE_EXPORT ); ?>
				<input type="hidden" name="action" value="wcwp_export_schema">
				<strong><?php esc_html_e( 'Export', 'woocommerce-wholesale-pro' ); ?></strong>
				<span class="wcwp-ie-desc">
					<?php printf(
						/* translators: %d = number of fields */
						esc_html__( '%d field(s) will be included.', 'woocommerce-wholesale-pro' ),
						$field_count
					); ?>
				</span>
				<button type="submit" name="wcwp_export_schema" value="1" class="button">
					<?php esc_html_e( 'Download JSON', 'woocommerce-wholesale-pro' ); ?>
				</button>
			</form>
		</div>
		<?php
	}
}
