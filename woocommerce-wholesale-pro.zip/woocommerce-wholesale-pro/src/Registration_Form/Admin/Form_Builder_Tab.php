<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Admin;

use Barn2\Plugin\WC_Wholesale_Pro\Registration_Form\Schema\Field_Schema;

/**
 * Drag-and-drop field builder admin UI with full CRUD.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Form_Builder_Tab {

	const NONCE_ACTION = 'wcwp_trade_fields';

	// -------------------------------------------------------------------------
	// POST handlers (called from Form_Builder_Page::handle_requests on admin_init)
	// -------------------------------------------------------------------------

	public function handle_post(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( isset( $_POST['wcwp_add_field'] ) ) {
			$this->handle_add();
		} elseif ( isset( $_POST['wcwp_edit_field'] ) ) {
			$this->handle_edit();
		} elseif ( isset( $_POST['wcwp_delete_field'] ) ) {
			$this->handle_delete();
		} elseif ( isset( $_POST['wcwp_reorder_fields'] ) ) {
			$this->handle_reorder();
		}
	}

	private function handle_add(): void {
		check_admin_referer( self::NONCE_ACTION );

		$label = sanitize_text_field( wp_unslash( $_POST['field_label'] ?? '' ) );
		if ( empty( $label ) ) {
			$this->redirect_with_error( 'Field label is required.' );
			return;
		}

		$key          = Field_Schema::generate_key( $label );
		$raw_role_map = is_array( $_POST['role_map'] ?? null ) ? $_POST['role_map'] : [];
		$role_map     = [];
		foreach ( $raw_role_map as $option => $role ) {
			$option = sanitize_text_field( wp_unslash( $option ) );
			$role   = sanitize_key( is_array( $role ) ? ( $role[0] ?? '' ) : $role );
			if ( $option !== '' ) {
				$role_map[ $option ] = $role;
			}
		}

		$field_type = sanitize_key( $_POST['field_type'] ?? 'text' );
		$is_content = in_array( $field_type, [ 'textarea', 'display_text' ], true );

		Field_Schema::add_field( [
			'key'         => $key,
			'label'       => $label,
			'type'        => $field_type,
			'section'     => sanitize_text_field( wp_unslash( $_POST['field_section'] ?? '' ) ),
			'required'    => ! empty( $_POST['field_required'] ),
			'options'     => $is_content ? wp_kses_post( wp_unslash( $_POST['field_options'] ?? '' ) ) : sanitize_textarea_field( wp_unslash( $_POST['field_options'] ?? '' ) ),
			'multiple'    => ! empty( $_POST['field_multiple'] ),
			'assign_role' => ! empty( $_POST['field_assign_role'] ),
			'role_map'    => $role_map,
			'wc_map'      => sanitize_key( $_POST['field_wc_map'] ?? '' ),
			'conditional' => [
				'enabled'    => ! empty( $_POST['cond_enabled'] ),
				'action'     => in_array( $_POST['cond_action'] ?? 'show', [ 'show', 'hide' ], true ) ? $_POST['cond_action'] : 'show',
				'match'      => ( ( $_POST['cond_match'] ?? 'all' ) === 'any' ) ? 'any' : 'all',
				'conditions' => self::parse_posted_conditions(),
			],
			'enabled'     => true,
		] );

		$this->redirect_with_notice( 'Field added.' );
	}

	private function handle_edit(): void {
		check_admin_referer( self::NONCE_ACTION );

		$key = sanitize_key( $_POST['field_key'] ?? '' );
		if ( empty( $key ) ) {
			return;
		}

		$raw_role_map = is_array( $_POST['role_map'] ?? null ) ? $_POST['role_map'] : [];
		$role_map     = [];
		foreach ( $raw_role_map as $option => $role ) {
			$option = sanitize_text_field( wp_unslash( $option ) );
			$role   = sanitize_key( is_array( $role ) ? ( $role[0] ?? '' ) : $role );
			if ( $option !== '' ) {
				$role_map[ $option ] = $role;
			}
		}

		$field_type = sanitize_key( $_POST['field_type'] ?? 'text' );
		$is_content = in_array( $field_type, [ 'textarea', 'display_text' ], true );

		Field_Schema::update_field( $key, [
			'label'       => sanitize_text_field( wp_unslash( $_POST['field_label'] ?? '' ) ),
			'type'        => $field_type,
			'section'     => sanitize_text_field( wp_unslash( $_POST['field_section'] ?? '' ) ),
			'required'    => ! empty( $_POST['field_required'] ),
			'options'     => $is_content ? wp_kses_post( wp_unslash( $_POST['field_options'] ?? '' ) ) : sanitize_textarea_field( wp_unslash( $_POST['field_options'] ?? '' ) ),
			'multiple'    => ! empty( $_POST['field_multiple'] ),
			'assign_role' => ! empty( $_POST['field_assign_role'] ),
			'role_map'    => $role_map,
			'wc_map'      => sanitize_key( $_POST['field_wc_map'] ?? '' ),
			'conditional' => [
				'enabled'    => ! empty( $_POST['cond_enabled'] ),
				'action'     => in_array( $_POST['cond_action'] ?? 'show', [ 'show', 'hide' ], true ) ? $_POST['cond_action'] : 'show',
				'match'      => ( ( $_POST['cond_match'] ?? 'all' ) === 'any' ) ? 'any' : 'all',
				'conditions' => self::parse_posted_conditions(),
			],
			'enabled'     => ! empty( $_POST['field_enabled'] ),
		] );

		$this->redirect_with_notice( 'Field updated.' );
	}

	private function handle_delete(): void {
		check_admin_referer( self::NONCE_ACTION );
		$key = sanitize_key( $_POST['field_key'] ?? '' );
		if ( $key ) {
			Field_Schema::delete_field( $key );
		}
		$this->redirect_with_notice( 'Field deleted.' );
	}

	private function handle_reorder(): void {
		check_admin_referer( self::NONCE_ACTION );
		$ordered = array_map( 'sanitize_key', (array) ( $_POST['field_order'] ?? [] ) );
		Field_Schema::reorder( $ordered );
		wp_send_json_success();
	}

	public function handle_reorder_ajax(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized', 403 );
		}
		check_ajax_referer( self::NONCE_ACTION, '_wpnonce' );
		$ordered = array_map( 'sanitize_key', (array) ( $_POST['field_order'] ?? [] ) );
		Field_Schema::reorder( $ordered );
		wp_send_json_success();
	}

	// -------------------------------------------------------------------------
	// Render
	// -------------------------------------------------------------------------

	public function render(): void {
		$fields      = Field_Schema::get_fields();
		$all_keys    = array_column( $fields, 'key' );
		$editing_key = isset( $_GET['edit_field'] ) ? sanitize_key( $_GET['edit_field'] ) : '';
		$editing     = $editing_key ? Field_Schema::get_field( $editing_key ) : null;
		// Only show field-CRUD notices here; import/export notices carry wcwp_notice_type
		// and are rendered by Import_Export_Tab::render() inside its own panel.
		$notice      = ( isset( $_GET['wcwp_notice'] ) && ! isset( $_GET['wcwp_notice_type'] ) )
			? sanitize_text_field( urldecode( $_GET['wcwp_notice'] ) )
			: '';
		$error       = isset( $_GET['wcwp_error'] ) ? sanitize_text_field( urldecode( $_GET['wcwp_error'] ) ) : '';

		if ( $notice ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $notice ) . '</p></div>';
		}
		if ( $error ) {
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $error ) . '</p></div>';
		}

		// Show reset success notice when redirected back after a Tools_Tab reset.
		( new Tools_Tab() )->render_notice();

		echo '<h2>' . esc_html__( 'Registration form', 'woocommerce-wholesale-pro' ) . '</h2>';

		$kb_text           = __( 'Optionally add extra fields which will appear on the wholesale registration page. <a href="%s" target="_blank" rel="noopener">Read more</a>.', 'woocommerce-wholesale-pro' );
			
		echo '<p class="description" style="margin: 8px 0 16px;">'
			. sprintf(
				wp_kses(
					$kb_text,
					[ 'a' => [ 'href' => [], 'target' => [], 'rel' => [] ], 'span' => [ 'class' => [], 'style' => [] ] ]
				),
				'https://barn2.com/kb/wholesale-registration-fields'
			)
			. '</p>';

		$preview_base = Form_Builder_Page::get_preview_url();
		echo '<div class="wcwp-toolbar">';
		if ( $preview_base ) {
			$preview_url = add_query_arg( [ 'wcwp_preview' => wp_create_nonce( Tools_Tab::PREVIEW_NONCE_ACTION ), 'wcwp_v' => time() ], $preview_base );
			echo '<a href="' . esc_url( $preview_url ) . '" target="_blank" class="button" title="'
				. esc_attr__( 'Preview registration form', 'woocommerce-wholesale-pro' ) . '">'
				. esc_html__( 'Preview form', 'woocommerce-wholesale-pro' )
				. '</a>';
		} else {
			echo '<span class="button button-disabled" title="'
				. esc_attr__( 'No page found containing the [wholesale_registration] shortcode.', 'woocommerce-wholesale-pro' ) . '">'
				. esc_html__( 'Preview form', 'woocommerce-wholesale-pro' )
				. '</span>';
		}
		echo '</div>';

		$this->render_field_table( $fields, $editing_key );

		echo '<div class="wcwp-field-form-wrap">';
		if ( $editing ) {
			$this->render_edit_form( $editing, $all_keys );
		} else {
			$this->render_add_form( $all_keys );
		}
		echo '</div>';

		echo '<details class="wcwp-import-export-panel"><summary>'
			. esc_html__( 'Import / Export', 'woocommerce-wholesale-pro' )
			. '</summary>';
		( new Import_Export_Tab() )->render();
		echo '</details>';

		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			echo '<details class="wcwp-import-export-panel"><summary>'
				. esc_html__( 'Reset Form', 'woocommerce-wholesale-pro' )
				. '</summary>';
			( new Tools_Tab() )->render();
			echo '</details>';
		}
	}

	private function render_field_table( array $fields, string $editing_key ): void {
		?>
		<div id="wcwp-field-order-container" style="display:none"></div>

		<table class="wcwp-field-table widefat">
					<thead>
						<tr>
							<th class="wcwp-col-drag"><?php echo wc_help_tip( __( 'Drag and drop to re-order your registration fields.', 'woocommerce-wholesale-pro' ) ); ?></th>
							<th>
								<span style="white-space:nowrap"><?php esc_html_e( 'Field', 'woocommerce-wholesale-pro' ); echo wc_help_tip( __( 'The field label shown to users on the registration form, and the internal meta key used to store the value.', 'woocommerce-wholesale-pro' ) ); ?></span>
							</th>
							<th>
								<span style="white-space:nowrap"><?php esc_html_e( 'Type', 'woocommerce-wholesale-pro' ); echo wc_help_tip( __( 'The type of input shown to users, e.g. text input, dropdown, file upload.', 'woocommerce-wholesale-pro' ) ); ?></span>
							</th>
							<th>
								<span style="white-space:nowrap"><?php esc_html_e( 'Section', 'woocommerce-wholesale-pro' ); echo wc_help_tip( __( 'Optional heading used to group related fields together on the registration form.', 'woocommerce-wholesale-pro' ) ); ?></span>
							</th>
							<th>
								<span style="white-space:nowrap"><?php esc_html_e( 'Required', 'woocommerce-wholesale-pro' ); echo wc_help_tip( __( 'Required fields must be completed before the registration form can be submitted.', 'woocommerce-wholesale-pro' ) ); ?></span>
							</th>
							<th>
								<span style="white-space:nowrap"><?php esc_html_e( 'Enabled', 'woocommerce-wholesale-pro' ); echo wc_help_tip( __( 'Disabled fields are hidden from the registration form but their data is retained.', 'woocommerce-wholesale-pro' ) ); ?></span>
							</th>
							<th>
								<span style="white-space:nowrap"><?php esc_html_e( 'Mapped to', 'woocommerce-wholesale-pro' ); echo wc_help_tip( __( 'When set, the field value is also saved to the selected WooCommerce billing or shipping address field.', 'woocommerce-wholesale-pro' ) ); ?></span>
							</th>
							<th>
								<span style="white-space:nowrap"><?php esc_html_e( 'Conditional', 'woocommerce-wholesale-pro' ); echo wc_help_tip( __( 'Conditional logic controls whether this field is shown or hidden based on the value of another field.', 'woocommerce-wholesale-pro' ) ); ?></span>
							</th>
							<th><?php esc_html_e( 'Actions', 'woocommerce-wholesale-pro' ); ?></th>
						</tr>
					</thead>
					<tbody id="wcwp-field-sortable">
					<?php if ( empty( $fields ) ) : ?>
						<tr><td colspan="9"><?php esc_html_e( 'No fields defined yet. Add your first field below.', 'woocommerce-wholesale-pro' ); ?></td></tr>
					<?php endif; ?>
					<?php
					$section_colors = [];
					$color_index    = 0;
					foreach ( $fields as $f ) {
						if ( $f['section'] !== '' && ! isset( $section_colors[ $f['section'] ] ) ) {
							$section_colors[ $f['section'] ] = ( $color_index++ % 6 ) + 1;
						}
					}
					?>
					<?php foreach ( $fields as $field ) : ?>
						<?php $section_color_class = $field['section'] !== '' ? ' wcwp-section-color-' . $section_colors[ $field['section'] ] : ''; ?>
						<tr data-field-key="<?php echo esc_attr( $field['key'] ); ?>" class="<?php echo $editing_key === $field['key'] ? 'wcwp-editing-row' : esc_attr( trim( $section_color_class ) ); ?>">
							<td class="wcwp-drag-handle"></td>
							<td>
								<?php echo esc_html( $field['label'] ); ?>
								<?php echo wc_help_tip( esc_html( $field['key'] ), false ); ?>
							</td>
							<td><span class="wcwp-type-badge wcwp-type-<?php echo esc_attr( $field['type'] ); ?>"><?php echo esc_html( self::type_labels()[ $field['type'] ] ?? $field['type'] ); ?></span></td>
							<td><?php echo esc_html( $field['section'] ); ?></td>
							<td><?php echo $field['required'] ? '<span class="wcwp-badge-yes">Yes</span>' : '<span class="wcwp-badge-no">No</span>'; ?></td>
							<td><?php echo $field['enabled'] ? '<span class="wcwp-badge-yes">Yes</span>' : '<span class="wcwp-badge-no">No</span>'; ?></td>
							<td><?php
								if ( ! empty( $field['wc_map'] ) ) {
									echo esc_html( self::wc_map_label( $field['wc_map'] ) );
									echo wc_help_tip( esc_html( $field['wc_map'] ), false );
								} else {
									echo '—';
								}
							?></td>
							<td>
								<?php
								$cond_data   = $field['conditional'] ?? [];
								$cond_active = ! empty( $cond_data['enabled'] ) && ! empty( $cond_data['conditions'] );
								if ( $cond_active ) :
									$conditions_count = count( $cond_data['conditions'] );
									$action_label     = ucfirst( $cond_data['action'] ?? 'show' );
									$op_labels        = [
										'equals'       => 'equals',
										'not_equals'   => 'does not equal',
										'is_empty'     => 'is empty',
										'is_not_empty' => 'is not empty',
										'greater_than' => 'is greater than',
										'less_than'    => 'is less than',
									];
									if ( $conditions_count === 1 ) {
										$c          = $cond_data['conditions'][0];
										$wf_obj     = Field_Schema::get_field( $c['when_field'] );
										$when_label = $wf_obj ? $wf_obj['label'] : $c['when_field'];
										$op         = $op_labels[ $c['operator'] ?? 'equals' ] ?? 'equals';
										$no_value   = in_array( $c['operator'] ?? 'equals', [ 'is_empty', 'is_not_empty' ], true );
										$summary    = $action_label . ' when <em>' . esc_html( $when_label ) . '</em> ' . esc_html( $op );
										if ( ! $no_value ) {
											$summary .= ' <strong>' . esc_html( $c['has_value'] ) . '</strong>';
										}
										echo '<small>' . wp_kses( $summary, [ 'em' => [], 'strong' => [] ] ) . '</small>';
									} else {
										$match_label = ( ( $cond_data['match'] ?? 'all' ) === 'any' ) ? 'Any' : 'All';
										echo '<small>' . esc_html( $action_label ) . ' if ' . esc_html( $match_label ) . ' match (' . esc_html( $conditions_count ) . ' conditions)</small>';
									}
								else :
									echo '—';
								endif;
								?>
							</td>
							<td>
								<?php $edit_url = Form_Builder_Page::section_url( [ 'edit_field' => $field['key'] ] ); ?>
								<a href="<?php echo esc_url( $edit_url ); ?>" class="button button-small"><?php esc_html_e( 'Edit', 'woocommerce-wholesale-pro' ); ?></a>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline" onsubmit="return confirm('Delete this field?')">
									<?php wp_nonce_field( self::NONCE_ACTION ); ?>
									<input type="hidden" name="action" value="wcwp_field_action">
									<input type="hidden" name="field_key" value="<?php echo esc_attr( $field['key'] ); ?>">
									<button type="submit" name="wcwp_delete_field" value="1" class="button button-small button-link-delete"><?php esc_html_e( 'Delete', 'woocommerce-wholesale-pro' ); ?></button>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
		</table>
		<?php
	}

	private function render_add_form( array $all_keys ): void {
		echo '<h2>' . esc_html__( 'Add new field', 'woocommerce-wholesale-pro' ) . '</h2>';
		$this->render_field_form( [], $all_keys, 'add' );
	}

	private function render_edit_form( array $field, array $all_keys ): void {
		echo '<div id="wcwp-edit-form-anchor"></div>';
		echo '<h2>' . esc_html__( 'Edit field', 'woocommerce-wholesale-pro' ) . '</h2>';
		echo '<p><a href="' . esc_url( Form_Builder_Page::section_url() ) . '">&larr; ' . esc_html__( 'Cancel editing', 'woocommerce-wholesale-pro' ) . '</a></p>';
		$this->render_field_form( $field, $all_keys, 'edit' );
	}

	private function render_field_form( array $field, array $all_keys, string $mode ): void {
		$is_edit   = $mode === 'edit';
		$type      = $field['type'] ?? 'text';
		$cond      = $field['conditional'] ?? [ 'enabled' => false, 'action' => 'show', 'match' => 'all', 'conditions' => [] ];
		$role_map  = $field['role_map'] ?? [];
		$sections  = $this->get_existing_sections();
		$all_types = self::type_labels();
		$all_roles = wp_roles()->get_names();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="wcwp-field-form">
			<?php wp_nonce_field( self::NONCE_ACTION ); ?>
			<input type="hidden" name="action" value="wcwp_field_action">
			<?php if ( $is_edit ) : ?>
				<input type="hidden" name="field_key" value="<?php echo esc_attr( $field['key'] ); ?>">
			<?php endif; ?>

			<table class="form-table">
				<tr>
					<th><label for="field_label"><?php esc_html_e( 'Field label', 'woocommerce-wholesale-pro' ); ?> <span class="required">*</span></label></th>
					<td>
						<input type="text" id="field_label" name="field_label" class="regular-text" value="<?php echo esc_attr( $field['label'] ?? '' ); ?>" required>
						<?php if ( ! $is_edit ) : ?>
							<p class="description"><?php esc_html_e( 'Meta key preview:', 'woocommerce-wholesale-pro' ); ?> <code id="wcwp-key-preview">wwp_trade_</code></p>
						<?php else : ?>
							<p class="description"><?php esc_html_e( 'Meta key:', 'woocommerce-wholesale-pro' ); ?> <code><?php echo esc_html( $field['key'] ); ?></code></p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th><label for="field_section"><?php esc_html_e( 'Section', 'woocommerce-wholesale-pro' ); ?></label></th>
					<td>
						<?php $current_section = $field['section'] ?? ''; ?>
						<select id="field_section" name="field_section" class="wcwp-section-select" data-placeholder="<?php esc_attr_e( 'Choose existing, or enter a new name..', 'woocommerce-wholesale-pro' ); ?>">
							<option value=""></option>
							<?php if ( $current_section !== '' && ! in_array( $current_section, $sections, true ) ) : ?>
								<option value="<?php echo esc_attr( $current_section ); ?>" selected><?php echo esc_html( $current_section ); ?></option>
							<?php endif; ?>
							<?php foreach ( $sections as $s ) : ?>
								<option value="<?php echo esc_attr( $s ); ?>" <?php selected( $current_section, $s ); ?>><?php echo esc_html( $s ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Optional. Fields with the same section name are grouped together under a heading on the registration form.', 'woocommerce-wholesale-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><label for="field_type"><?php esc_html_e( 'Field type', 'woocommerce-wholesale-pro' ); ?></label></th>
					<td>
						<select id="field_type" name="field_type">
							<?php foreach ( $all_types as $t => $t_label ) : ?>
								<?php if ( $t === 'display_text' ) : continue; endif; ?>
								<option value="<?php echo esc_attr( $t ); ?>" <?php selected( $type, $t ); ?>><?php echo esc_html( $t_label ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<tr id="wcwp-options-row" <?php echo ! in_array( $type, [ 'select', 'multiselect', 'radio', 'textarea', 'display_text' ], true ) ? 'style="display:none"' : ''; ?>>
					<th><label for="field_options" id="wcwp-options-label"><?php echo esc_html( in_array( $type, [ 'textarea', 'display_text' ], true ) ? __( 'Content', 'woocommerce-wholesale-pro' ) : __( 'Options', 'woocommerce-wholesale-pro' ) ); ?></label></th>
					<td>
						<textarea id="field_options" name="field_options" rows="5" class="large-text"><?php echo esc_textarea( $field['options'] ?? '' ); ?></textarea>
						<p class="description" id="wcwp-options-desc"><?php
							if ( in_array( $type, [ 'display_text', 'textarea' ], true ) ) {
								echo wp_kses_post( __( 'This text will be displayed on the registration form. Allowed HTML: <code>&lt;strong&gt;</code>, <code>&lt;em&gt;</code>, <code>&lt;u&gt;</code>, <code>&lt;a href&gt;</code>, <code>&lt;img&gt;</code>, <code>&lt;p&gt;</code>, <code>&lt;br&gt;</code>.', 'woocommerce-wholesale-pro' ) );
							} else {
								echo esc_html( __( 'One option per line, or comma-separated.', 'woocommerce-wholesale-pro' ) );
							}
						?></p>
					</td>
				</tr>
				<tr id="wcwp-multiple-row" <?php echo $type !== 'file' ? 'style="display:none"' : ''; ?>>
					<th><?php esc_html_e( 'Allow Multiple Files', 'woocommerce-wholesale-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="field_multiple" value="1" <?php checked( ! empty( $field['multiple'] ) ); ?>>
							<?php esc_html_e( 'Allow uploading multiple files for this field', 'woocommerce-wholesale-pro' ); ?>
						</label>
					</td>
				</tr>
				<tr id="wcwp-assign-role-row" <?php echo ! in_array( $type, [ 'select', 'radio' ], true ) ? 'style="display:none"' : ''; ?>>
					<th><?php esc_html_e( 'Assign User Role', 'woocommerce-wholesale-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" id="wcwp-assign-role-toggle" name="field_assign_role" value="1" <?php checked( ! empty( $field['assign_role'] ) ); ?>>
							<?php esc_html_e( 'Auto-assign user role based on selected value', 'woocommerce-wholesale-pro' ); ?>
						</label>
						<div id="wcwp-role-map-container" <?php echo empty( $field['assign_role'] ) ? 'style="display:none"' : ''; ?>>
							<p class="description"><?php esc_html_e( 'Choose which user role to assign for each option value.', 'woocommerce-wholesale-pro' ); ?></p>
							<table class="wcwp-role-map-table widefat">
								<thead>
									<tr>
										<th><?php esc_html_e( 'Option', 'woocommerce-wholesale-pro' ); ?></th>
										<th><?php esc_html_e( 'Assign Role', 'woocommerce-wholesale-pro' ); ?></th>
									</tr>
								</thead>
								<tbody id="wcwp-role-map-tbody">
									<?php
									$options_raw  = $field['options'] ?? '';
									$option_lines = [];
									foreach ( preg_split( '/[\r\n,]+/', $options_raw ) as $line ) {
										$line = trim( $line );
										if ( $line !== '' ) {
											$option_lines[] = $line;
										}
									}
									if ( empty( $option_lines ) ) :
									?>
										<tr id="wcwp-role-map-empty-row">
											<td colspan="2"><em><?php esc_html_e( 'Add options above to configure role mapping.', 'woocommerce-wholesale-pro' ); ?></em></td>
										</tr>
									<?php else :
										foreach ( $option_lines as $opt_value ) :
											$raw_role      = $role_map[ $opt_value ] ?? '';
										$selected_role = is_array( $raw_role ) ? ( $raw_role[0] ?? '' ) : $raw_role;
									?>
										<tr data-option-value="<?php echo esc_attr( $opt_value ); ?>">
											<td><?php echo esc_html( $opt_value ); ?></td>
											<td>
												<select
													name="role_map[<?php echo esc_attr( $opt_value ); ?>]"
													class="wcwp-role-select"
												>
													<option value=""><?php esc_html_e( '— No role —', 'woocommerce-wholesale-pro' ); ?></option>
													<?php foreach ( $all_roles as $slug => $name ) : ?>
														<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $selected_role, $slug ); ?>><?php echo esc_html( $name ); ?></option>
													<?php endforeach; ?>
												</select>
											</td>
										</tr>
									<?php
										endforeach;
									endif;
									?>
								</tbody>
							</table>
						</div>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Required', 'woocommerce-wholesale-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="field_required" value="1" <?php checked( ! empty( $field['required'] ) ); ?>>
							<?php esc_html_e( 'This field must be filled in', 'woocommerce-wholesale-pro' ); ?>
						</label>
					</td>
				</tr>
				<?php if ( $is_edit ) : ?>
				<tr>
					<th><?php esc_html_e( 'Enabled', 'woocommerce-wholesale-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="field_enabled" value="1" <?php checked( ! empty( $field['enabled'] ) ); ?>>
							<?php esc_html_e( 'Show this field on the registration form', 'woocommerce-wholesale-pro' ); ?>
						</label>
					</td>
				</tr>
				<?php endif; ?>
				<tr>
					<th><label for="field_wc_map"><?php esc_html_e( 'Map to existing field', 'woocommerce-wholesale-pro' ); ?></label></th>
					<td>
						<?php
						// All candidate groups. Keys mapped by another field are filtered out of
						// their group and collected in a single "Mapped" group at the bottom,
						// keeping the active list short as fields are configured.
						$all_groups = [
							'Billing'  => [
								'billing_first_name' => 'Billing First Name',
								'billing_last_name'  => 'Billing Last Name',
								'billing_email'      => 'Billing Email',
								'billing_phone'      => 'Billing Phone',
								'billing_company'    => 'Billing Company',
								'billing_address_1'  => 'Billing Address Line 1',
								'billing_address_2'  => 'Billing Address Line 2',
								'billing_city'       => 'Billing City / Town',
								'billing_state'      => 'Billing County / State',
								'billing_postcode'   => 'Billing Postcode',
								'billing_country'    => 'Billing Country',
							],
							'Shipping' => [
								'shipping_first_name' => 'Shipping First Name',
								'shipping_last_name'  => 'Shipping Last Name',
								'shipping_company'    => 'Shipping Company',
								'shipping_address_1'  => 'Shipping Address Line 1',
								'shipping_address_2'  => 'Shipping Address Line 2',
								'shipping_city'       => 'Shipping City / Town',
								'shipping_state'      => 'Shipping County / State',
								'shipping_postcode'   => 'Shipping Postcode',
								'shipping_country'    => 'Shipping Country',
							],
						];

						// Keys already used as wc_map by another field (not the one being edited).
						$current_wc_map       = $field['wc_map'] ?? '';
						$other_fields_wc_maps = array_filter(
							array_column( Field_Schema::get_fields(), 'wc_map', 'key' ),
							fn( $mapped_to, $k ) => $mapped_to !== '' && $k !== ( $field['key'] ?? '' ),
							ARRAY_FILTER_USE_BOTH
						);
						$used_keys = array_values( $other_fields_wc_maps );

						$wc_map_options = [ '' => '— None —' ];
						$mapped_group   = [];
						foreach ( $all_groups as $group_label => $options ) {
							$active = [];
							foreach ( $options as $opt_key => $opt_label ) {
								if ( in_array( $opt_key, $used_keys, true ) ) {
									$mapped_group[ $opt_key ] = $opt_label;
								} else {
									$active[ $opt_key ] = $opt_label;
								}
							}
							if ( ! empty( $active ) ) {
								$wc_map_options[ $group_label ] = $active;
							}
						}
						if ( ! empty( $mapped_group ) ) {
							$wc_map_options[ __( 'Mapped', 'woocommerce-wholesale-pro' ) ] = $mapped_group;
						}

						$mapped_group_label = __( 'Mapped', 'woocommerce-wholesale-pro' );
						echo '<select id="field_wc_map" name="field_wc_map">';
						foreach ( $wc_map_options as $group_or_key => $label_or_group ) {
							if ( is_array( $label_or_group ) ) {
								$is_mapped_group = ( $group_or_key === $mapped_group_label );
								echo '<optgroup label="' . esc_attr( $group_or_key ) . '">';
								foreach ( $label_or_group as $wc_key => $wc_label ) {
									echo '<option value="' . esc_attr( $wc_key ) . '"'
										. selected( $current_wc_map, $wc_key, false )
										. ( $is_mapped_group ? ' disabled' : '' )
										. '>' . esc_html( $wc_label ) . '</option>';
								}
								echo '</optgroup>';
							} else {
								echo '<option value="' . esc_attr( $group_or_key ) . '"' . selected( $current_wc_map, $group_or_key, false ) . '>' . esc_html( $label_or_group ) . '</option>';
							}
						}
						echo '</select>';
						?>
						<p class="description"><?php esc_html_e( "Map the data from this field to the WooCommerce user profile (e.g. first name).", 'woocommerce-wholesale-pro' ); ?></p>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Conditional logic', 'woocommerce-wholesale-pro' ); ?></th>
					<td>
						<label>
							<input type="checkbox" id="wcwp-cond-enable" name="cond_enabled" value="1" <?php checked( ! empty( $cond['enabled'] ) ); ?>>
							<?php esc_html_e( 'Enable conditional logic for this field', 'woocommerce-wholesale-pro' ); ?>
						</label>
					</td>
				</tr>
				<tr id="wcwp-cond-fields-row" <?php echo empty( $cond['enabled'] ) ? 'style="display:none"' : ''; ?>>
					<td colspan="2">
						<div id="wcwp-cond-fields">
							<div class="wcwp-cond-table-wrap">
							<div class="wcwp-cond-header">
								<select name="cond_action">
									<option value="show" <?php selected( $cond['action'] ?? 'show', 'show' ); ?>><?php esc_html_e( 'Show', 'woocommerce-wholesale-pro' ); ?></option>
									<option value="hide" <?php selected( $cond['action'] ?? 'show', 'hide' ); ?>><?php esc_html_e( 'Hide', 'woocommerce-wholesale-pro' ); ?></option>
								</select>
								<span><?php esc_html_e( 'this field if', 'woocommerce-wholesale-pro' ); ?></span>
								<select name="cond_match" id="wcwp-cond-match">
									<option value="all" <?php selected( $cond['match'] ?? 'all', 'all' ); ?>><?php esc_html_e( 'All', 'woocommerce-wholesale-pro' ); ?></option>
									<option value="any" <?php selected( $cond['match'] ?? 'all', 'any' ); ?>><?php esc_html_e( 'Any', 'woocommerce-wholesale-pro' ); ?></option>
								</select>
								<span><?php esc_html_e( 'of the following match:', 'woocommerce-wholesale-pro' ); ?></span>
							</div>
							<table class="wcwp-cond-table">
								<thead>
									<tr>
										<th><?php esc_html_e( 'Condition', 'woocommerce-wholesale-pro' ); ?></th>
										<th><?php esc_html_e( 'Comparison', 'woocommerce-wholesale-pro' ); ?></th>
										<th><?php esc_html_e( 'Value', 'woocommerce-wholesale-pro' ); ?></th>
										<th></th>
									</tr>
								</thead>
								<tbody id="wcwp-cond-tbody">
									<?php
									$saved_conditions = $cond['conditions'] ?? [];
									if ( empty( $saved_conditions ) ) {
										$saved_conditions = [ [ 'when_field' => '', 'operator' => 'equals', 'has_value' => '' ] ];
									}
									foreach ( $saved_conditions as $ci ) :
										$ci_field    = $ci['when_field'] ?? '';
										$ci_operator = $ci['operator'] ?? 'equals';
										$ci_value    = $ci['has_value'] ?? '';
										$needs_value = ! in_array( $ci_operator, [ 'is_empty', 'is_not_empty' ], true );
									?>
									<tr class="wcwp-cond-row">
										<td>
											<select name="cond_when_field[]" class="wcwp-cond-when-field">
												<option value=""><?php esc_html_e( '— Select a field —', 'woocommerce-wholesale-pro' ); ?></option>
												<?php foreach ( Field_Schema::get_fields() as $f ) :
													if ( isset( $field['key'] ) && $f['key'] === $field['key'] ) continue; ?>
													<option value="<?php echo esc_attr( $f['key'] ); ?>"
														data-type="<?php echo esc_attr( $f['type'] ); ?>"
														<?php selected( $ci_field, $f['key'] ); ?>>
														<?php echo esc_html( $f['label'] ); ?>
													</option>
												<?php endforeach; ?>
											</select>
											<span class="wcwp-cond-checkbox-hint">
												<?php esc_html_e( 'Use "1" (checked) or "" (unchecked)', 'woocommerce-wholesale-pro' ); ?>
											</span>
										</td>
										<td>
											<select name="cond_operator[]" class="wcwp-cond-operator">
												<option value="equals" <?php selected( $ci_operator, 'equals' ); ?>><?php esc_html_e( 'Equals', 'woocommerce-wholesale-pro' ); ?></option>
												<option value="not_equals" <?php selected( $ci_operator, 'not_equals' ); ?>><?php esc_html_e( 'Does not equal', 'woocommerce-wholesale-pro' ); ?></option>
												<option value="is_empty" <?php selected( $ci_operator, 'is_empty' ); ?>><?php esc_html_e( 'Is empty', 'woocommerce-wholesale-pro' ); ?></option>
												<option value="is_not_empty" <?php selected( $ci_operator, 'is_not_empty' ); ?>><?php esc_html_e( 'Is not empty', 'woocommerce-wholesale-pro' ); ?></option>
												<option value="greater_than" <?php selected( $ci_operator, 'greater_than' ); ?>><?php esc_html_e( 'Greater than', 'woocommerce-wholesale-pro' ); ?></option>
												<option value="less_than" <?php selected( $ci_operator, 'less_than' ); ?>><?php esc_html_e( 'Less than', 'woocommerce-wholesale-pro' ); ?></option>
											</select>
										</td>
										<td>
											<input type="text" name="cond_has_value[]"
												value="<?php echo esc_attr( $ci_value ); ?>"
												placeholder="<?php esc_attr_e( 'e.g. Yes, Other, 1', 'woocommerce-wholesale-pro' ); ?>"
												<?php echo $needs_value ? '' : 'style="display:none"'; ?>>
										</td>
										<td class="wcwp-cond-remove-col">
											<button type="button" class="button wcwp-cond-remove-row"
												aria-label="<?php esc_attr_e( 'Remove condition', 'woocommerce-wholesale-pro' ); ?>">−</button>
										</td>
									</tr>
									<?php endforeach; ?>
								</tbody>
							</table>
							<button type="button" id="wcwp-cond-add-row" class="button"
								title="<?php esc_attr_e( 'Add condition', 'woocommerce-wholesale-pro' ); ?>"
								<?php echo count( $saved_conditions ) >= 5 ? 'disabled' : ''; ?>>+</button>
							</div><!-- /.wcwp-cond-table-wrap -->
						</div>
					</td>
				</tr>
			</table>

			<p class="submit wcwp-submit">
				<?php if ( $is_edit ) : ?>
					<button type="submit" name="wcwp_edit_field" value="1" class="button button-primary"><?php esc_html_e( 'Save Changes', 'woocommerce-wholesale-pro' ); ?></button>
				<?php else : ?>
					<button type="submit" name="wcwp_add_field" value="1" class="button button-primary"><?php esc_html_e( 'Add field', 'woocommerce-wholesale-pro' ); ?></button>
				<?php endif; ?>
			</p>
		</form>
		<?php
	}

	private static function type_labels(): array {
		return [
			'text'         => __( 'Text input', 'woocommerce-wholesale-pro' ),
			'email'        => __( 'Text input (email)', 'woocommerce-wholesale-pro' ),
			'tel'          => __( 'Text input (phone)', 'woocommerce-wholesale-pro' ),
			'number'       => __( 'Number', 'woocommerce-wholesale-pro' ),
			'textarea'     => __( 'Paragraph', 'woocommerce-wholesale-pro' ),
			'select'       => __( 'Dropdown select', 'woocommerce-wholesale-pro' ),
			'multiselect'  => __( 'Dropdown select (multi)', 'woocommerce-wholesale-pro' ),
			'radio'        => __( 'Radio buttons', 'woocommerce-wholesale-pro' ),
			'checkbox'     => __( 'Checkbox', 'woocommerce-wholesale-pro' ),
			'file'         => __( 'File upload', 'woocommerce-wholesale-pro' ),
			'display_text' => __( 'Display Text', 'woocommerce-wholesale-pro' ),
			'honeypot'     => __( 'Spam trap (honeypot)', 'woocommerce-wholesale-pro' ),
		];
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	private static function parse_posted_conditions(): array {
		$valid_operators = [ 'equals', 'not_equals', 'is_empty', 'is_not_empty', 'greater_than', 'less_than' ];
		$when_fields     = (array) ( $_POST['cond_when_field'] ?? [] );
		$operators       = (array) ( $_POST['cond_operator'] ?? [] );
		$has_values      = (array) ( $_POST['cond_has_value'] ?? [] );
		$conditions      = [];
		foreach ( $when_fields as $i => $wf ) {
			$wf = sanitize_key( wp_unslash( $wf ) );
			if ( $wf === '' ) {
				continue;
			}
			$op           = sanitize_key( wp_unslash( $operators[ $i ] ?? 'equals' ) );
			$conditions[] = [
				'when_field' => $wf,
				'operator'   => in_array( $op, $valid_operators, true ) ? $op : 'equals',
				'has_value'  => sanitize_text_field( wp_unslash( $has_values[ $i ] ?? '' ) ),
			];
			if ( count( $conditions ) >= 5 ) {
				break;
			}
		}
		return $conditions;
	}

	private function get_existing_sections(): array {
		$sections = [];
		foreach ( Field_Schema::get_fields() as $f ) {
			if ( ! empty( $f['section'] ) && ! in_array( $f['section'], $sections, true ) ) {
				$sections[] = $f['section'];
			}
		}
		return $sections;
	}

	private function parse_role_map( string $raw ): array {
		$map   = [];
		$lines = preg_split( '/\r?\n/', $raw );
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( strpos( $line, '=' ) === false ) {
				continue;
			}
			[ $option, $role ] = array_map( 'trim', explode( '=', $line, 2 ) );
			if ( $option !== '' && $role !== '' ) {
				$map[ $option ] = sanitize_key( $role );
			}
		}
		return $map;
	}

	/**
	 * Flat map of all WC billing/shipping meta keys to human-readable labels.
	 */
	private static function wc_map_labels(): array {
		return [
			'billing_first_name'  => 'Billing First Name',
			'billing_last_name'   => 'Billing Last Name',
			'billing_email'       => 'Billing Email',
			'billing_phone'       => 'Billing Phone',
			'billing_company'     => 'Billing Company',
			'billing_address_1'   => 'Billing Address Line 1',
			'billing_address_2'   => 'Billing Address Line 2',
			'billing_city'        => 'Billing City / Town',
			'billing_state'       => 'Billing County / State',
			'billing_postcode'    => 'Billing Postcode',
			'billing_country'     => 'Billing Country',
			'shipping_first_name' => 'Shipping First Name',
			'shipping_last_name'  => 'Shipping Last Name',
			'shipping_company'    => 'Shipping Company',
			'shipping_address_1'  => 'Shipping Address Line 1',
			'shipping_address_2'  => 'Shipping Address Line 2',
			'shipping_city'       => 'Shipping City / Town',
			'shipping_state'      => 'Shipping County / State',
			'shipping_postcode'   => 'Shipping Postcode',
			'shipping_country'    => 'Shipping Country',
		];
	}

	/**
	 * Returns a human-readable label for a wc_map value.
	 */
	private static function wc_map_label( string $wc_map ): string {
		$labels = self::wc_map_labels();
		return $labels[ $wc_map ] ?? $wc_map;
	}

	private function redirect_with_notice( string $msg ): void {
		delete_transient( 'wcwp_trade_preview_url' );
		wp_safe_redirect( Form_Builder_Page::section_url( [ 'wcwp_notice' => rawurlencode( $msg ) ] ) );
		exit;
	}

	private function redirect_with_error( string $msg ): void {
		wp_safe_redirect( Form_Builder_Page::section_url( [ 'wcwp_error' => rawurlencode( $msg ) ] ) );
		exit;
	}
}
