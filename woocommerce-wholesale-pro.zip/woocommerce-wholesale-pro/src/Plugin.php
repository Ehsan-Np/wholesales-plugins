<?php

namespace Barn2\Plugin\WC_Wholesale_Pro;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Plugin\Premium_Plugin;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Util as Lib_Util;
use Barn2\Plugin\WC_Wholesale_Pro\Admin\Plugin_Setup;

/**
 * The main plugin class. Responsible for setting up to core plugin services.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Plugin extends Premium_Plugin {

	const NAME    = 'WooCommerce Wholesale Pro';
	const ITEM_ID = 194346;

	/**
	 * Constructs and initalizes the main plugin class.
	 *
	 * @param string $file The root plugin __FILE__
	 * @param string $version The current plugin version
	 */
	public function __construct( $file = null, $version = '1.0' ) {
		parent::__construct(
			[
				'name'               => self::NAME,
				'id'                 => self::ITEM_ID,
				'version'            => $version,
				'file'               => $file,
				'is_woocommerce'     => true,
				'settings_path'      => 'admin.php?page=wc-settings&tab=wholesale-pro',
				'documentation_path' => 'kb-categories/woocommerce-wholesale-pro-kb/',
				'template_directory' => untrailingslashit( plugin_dir_path( $file ) ) . '/views/',
			]
		);
	}

	/**
	 * Setup the plugin services
	 */
	public function add_services() {
		$this->add_service( 'plugin_setup', new Plugin_Setup( $this->get_file(), $this ), true );
		$this->add_service( 'wizard', new Admin\Wizard\Setup_Wizard( $this ) );

		if ( is_admin() ) {
			$this->add_service( 'settings', new Admin\Admin( $this, $this->get_license_setting(), $this->get_license() ) );
			$this->add_service( 'product_edit', new Admin\Product_Edit() );
			$this->add_service( 'product_list', new Admin\Product_List() );
			$this->add_service( 'category_edit', new Admin\Category_Edit() );
			$this->add_service( 'order_edit', new Admin\Order_Edit() );
			$this->add_service( 'user_edit', new Admin\User_Edit() );
			$this->add_service( 'user_list', new Admin\User_List() );
			$this->add_service( 'page_list', new Admin\Page_List() );
			$this->add_service( 'order_list', new Admin\Order_List() );
			$this->add_service( 'ajax_actions', new Admin\Ajax_Actions() );
		}

		if ( Lib_Util::is_front_end() ) {
			$this->add_service( 'login_register', new Login_Register( $this->data['template_directory'] ) );
			$this->add_service( 'category_template_handler', new Handlers\Category_Template_Handler() );
			$this->add_service( 'category_protector', new Category_Protector() );
			$this->add_service( 'product_protector', new Product_Protector() );
			$this->add_service( 'navigation_menu', new Navigation_Menu() );
			$this->add_service( 'theme_compat', new Integration\Theme_Compat() );
			$this->add_service( 'quick_view_pro', new Integration\Quick_View_Pro() );
			$this->add_service( 'gateway_handler', new Handlers\Gateway_Handler() );
			$this->add_service( 'tax_handler', new Handlers\Tax_Handler() );
			$this->add_service( 'coupon_handler', new Handlers\Coupon_Handler() );
		}

		$this->add_service( 'widgets', new Widgets\Compatibility() );
		$this->add_service( 'emails', new Emails\Emails( $this->data['template_directory'] ) );
		$this->add_service( 'authenticate', new Authenticate() );
		$this->add_service( 'role_handler', new Handlers\Role_Handler() );
		$this->add_service( 'wholesale_store', new Wholesale_Store() );
		$this->add_service( 'price_handler', new Handlers\Price_Handler() );
		$this->add_service( 'cart_handler', new Handlers\Cart_Handler() );
		$this->add_service( 'shipping_handler', new Handlers\Shipping_Handler() );
		$this->add_service( 'order_handler', new Handlers\Order_Handler() );
		$this->add_service( 'registration_fields', new Registration_Fields() );
		$this->add_service( 'registration_form', new Registration_Form\Registration_Form( $this ) );
		$this->add_service( 'product_table', new Integration\Product_Table() );
		$this->add_service( 'all_import_pro', new Integration\All_Import_Pro() );
		$this->add_service( 'product_addons', new Integration\Product_Addons() );
		$this->add_service( 'aelia_cs', new Integration\Aelia_Currency_Switcher() );
		$this->add_service( 'woocommerce_multilingual', new Integration\WooCommerce_Multilingual() );
		$this->add_service( 'aio_seo', new Integration\AIO_SEO() );
		$this->add_service( 'hide_prices', new Hide_Prices() );
	}
}
