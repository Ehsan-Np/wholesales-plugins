<?php
namespace Barn2\Plugin\WC_Wholesale_Pro\Util;

use Barn2\Plugin\WC_Wholesale_Pro\Product_Visibility;
use Barn2\Plugin\WC_Wholesale_Pro\Util;

/**
 * Visibility utility functions
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
final class Visibility {

	/**
	 * Check query vars for excluded category
	 *
	 * @param array $tax_query
	 * @return array|null
	 */
	public static function tax_query_has_protected_terms( $tax_query ) {
		if ( empty( $tax_query ) ) {
			return [];
		}

		$protected_terms = [];

		foreach ( $tax_query as $key => $query ) {
			if ( ! is_array( $query ) ) {
				continue;
			}

			if ( isset( $query['wwp_protected'] ) && $query['wwp_protected'] === true && isset( $query['terms'] ) && ! empty( $query['terms'] ) ) {
				$protected_terms = array_merge( $protected_terms, (array) $query['terms'] );
			} elseif ( isset( $query['relation'] ) ) {
				// This is a nested query, so we need to recurse
				$nested_protected_terms = self::tax_query_has_protected_terms( $query );
				$protected_terms = array_merge( $protected_terms, $nested_protected_terms );
			} elseif ( is_numeric( $key ) && ! isset( $query['taxonomy'] ) ) {
				// This is a nested query without an explicit relation
				$nested_protected_terms = self::tax_query_has_protected_terms( $query );
				$protected_terms = array_merge( $protected_terms, $nested_protected_terms );
			}
		}

		return array_unique( array_filter( $protected_terms ) );
	}

	/**
	 * Remove protected terms from tax query
	 *
	 * @param mixed $tax_query
	 * @return array $tax_query
	 */
	public static function tax_query_remove_protected_terms( $tax_query ) {
		if ( empty( $tax_query ) ) {
			return $tax_query;
		}

		foreach ( $tax_query as $key => $query ) {
 			if ( ! is_array( $query ) ) {
				continue;
			}

			if ( isset( $query['wwp_visibility'] ) && $query['wwp_visibility'] === true ) {
				unset( $tax_query[ $key ] );
			} elseif ( isset( $query['relation'] ) ) {
				// This is a nested query, so we need to recurse
				$tax_query[ $key ] = self::tax_query_remove_protected_terms( $query );
			} elseif ( is_numeric( $key ) && ! isset( $query['taxonomy'] ) ) {
				// This is a nested query without an explicit relation
				$tax_query[ $key ] = self::tax_query_remove_protected_terms( $query );
			}
		}

		return $tax_query;
	}

	/**
	 * Protected category has unlocked 	products
	 *
	 * @param int $term_id
	 * @return array|null
	 */
	public static function protected_category_has_unlocked_products( $term_id ) {
		$category_visibility = Util::get_category_visibility( $term_id );

		if ( ! $category_visibility->is_protected() ) {
			return null;
		}

		$term_ids      = is_array( $term_id ) ? $term_id : [ $term_id ];
		$term_children = get_term_children( $term_id, 'product_cat' );

		if ( ! empty( $term_children ) ) {
			$term_id = array_merge( $term_ids, $term_children );
		}

		$category_product_ids = get_objects_in_term( $term_ids, 'product_cat' );

		// Get all the product categories, and check which are unlocked.
		$unlocked_product_ids = [];

		foreach ( self::get_product_visibilities() as $product_visibility ) {
			if ( $product_visibility->is_unlocked() ) {
				$product                = $product_visibility->get_product();
				$unlocked_product_ids[] = $product->get_id();
			}
		}

		// check for intersection and return those ids
		$intersection = array_filter( array_intersect( $unlocked_product_ids, $category_product_ids ) );

		if ( empty( $intersection ) ) {
			return null;
		}

		return $intersection;
	}

	/**
	 * Determines if the product is protected
	 *
	 * @param mixed $product_id
	 * @return bool
	 */
	public static function is_product_unlocked( $product_id ) {
		$visibility = self::get_product_visibility( $product_id );

		if ( ! $visibility ) {
			return false;
		}

		if ( $visibility->is_unlocked() ) {
			return true;
		}

		return false;
	}

	/**
	 * Gets the product visibility for a term ID.
	 *
	 * @param int|string $product_id
	 * @return Product_Visibility
	 */
	public static function get_product_visibility( $product_id ) {
		$product_id = absint( $product_id );

		if ( ! $product_id ) {
			return false;
		}

		$visibilities = self::get_product_visibility_cache();

		if ( ! array_key_exists( $product_id, $visibilities ) ) {
			$product                     = wc_get_product( $product_id );
			$visibilities[ $product_id ] = new Product_Visibility( $product );
			self::update_product_visibility_cache( $visibilities );
		}

		return $visibilities[ $product_id ];
	}

	/**
	 * Get's all product visibilities.
	 *
	 * @return Product_Visibility[]
	 */
	public static function get_product_visibilities() {
		$result = [];
		$cache  = self::get_product_visibility_cache();

		$product_ids = self::get_visibility_product_ids();

		foreach ( $product_ids as $product_id ) {
			if ( array_key_exists( $product_id, $cache ) ) {
				$result[] = $cache[ $product_id ];
				continue;
			}

			$product = wc_get_product( $product_id );

			if ( ! $product ) {
				continue;
			}

			$cache[ $product_id ] = new Product_Visibility( $product );
			$result[]             = $cache[ $product_id ];
		}

		self::update_product_visibility_cache( $cache );

		return $result;
	}

	/**
	 * Retrieve an array of all product IDs which have wcwp_visiblity meta not empty
	 *
	 * TODO: Currently done in direct sql as there is an issue with custom meta query on wc_get_products.
	 *
	 * @return array
	 */
	private static function get_visibility_product_ids() {
		global $wpdb;

		$product_ids = $wpdb->get_col( "SELECT DISTINCT post_id FROM $wpdb->postmeta WHERE meta_key = '_wwp_wholesale_visibility' AND meta_value <> ''" );

		return $product_ids ?: [];
	}

	/**
	 * Get the product visiblity cache.
	 *
	 * @return array
	 */
	private static function get_product_visibility_cache() {
		$cache = wp_cache_get( 'wcwp_product_visibilities' );

		if ( false !== $cache || ! is_array( $cache ) ) {
			$cache = [];
		}

		return $cache;
	}

	/**
	 * Updates the product visiblity cache.
	 *
	 * @param Product_Visibility[] $product_visibilities
	 */
	private static function update_product_visibility_cache( $product_visibilities ) {
		wp_cache_set( 'wcwp_product_visibilities', $product_visibilities );
	}
}
