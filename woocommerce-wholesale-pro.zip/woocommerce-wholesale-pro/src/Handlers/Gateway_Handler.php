<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Handlers;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

/**
 * Payment Gateway Handler
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Gateway_Handler implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'woocommerce_available_payment_gateways', [ $this, 'filter_payment_gateways' ], 999, 1 );
	}

	/**
	 * Filter WC Payment Gateways by role
	 *
	 * @param   \WC_Payment_Gateway[] $available_gateways
	 * @return  \WC_Payment_Gateway[] $available_gateways
	 */
	public function filter_payment_gateways( $available_gateways ) {
		$payment_roles = get_option( 'wcwp_payment_roles', [] );

		if ( empty( $payment_roles ) ) {
			return $available_gateways;
		}

		if ( is_user_logged_in() ) {
			$user  = wp_get_current_user();
			$roles = $user->roles;
		} else {
			$roles = [ 'guest_wcwp' ]; // indicator for logged out users
		}

		foreach ( $available_gateways as $gateway_key => $gateway ) {
			if ( empty( $payment_roles ) || ! isset( $payment_roles[ $gateway_key ] ) || empty( $payment_roles[ $gateway_key ] ) ) {
				continue;
			}

			if ( empty( array_intersect( $roles, $payment_roles[ $gateway_key ] ) ) ) {
				unset( $available_gateways[ $gateway_key ] );
			}
		}

		return $available_gateways;
	}
}
