<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Handlers;

use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Price;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Util as Lib_Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

use Automattic\WooCommerce\Utilities\OrderUtil;
use WP_User;
use WP_Post;
use WC_Product;
use WC_Product_Variable;

/**
 * Handles the display of wholesale prices
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Price_Handler implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {

		// modify the price
		add_filter( 'woocommerce_product_get_price', [ $this, 'get_price' ], 99, 2 );
		add_filter( 'woocommerce_product_get_sale_price', [ $this, 'get_sale_price' ], 99, 2 );

		add_action( 'wcwp_wholesale_price_before_get_pricing', [ $this, 'remove_sale_price_filter' ] );
		add_action( 'wcwp_wholesale_price_after_get_pricing', [ $this, 'add_sale_price_filter' ] );

		// modify the on sale status
		add_filter( 'woocommerce_product_is_on_sale', [ $this, 'is_on_sale' ], 99, 2 );

		// html output
		add_filter( 'woocommerce_get_price_html', [ $this, 'get_price_html' ], 999, 2 );

		// variation specifics
		add_filter( 'woocommerce_product_variation_get_price', [ $this, 'get_price' ], 99, 2 );
		add_filter( 'woocommerce_product_variation_get_sale_price', [ $this, 'get_sale_price' ], 99, 2 );
		add_filter( 'woocommerce_variation_prices_price', [ $this, 'get_price' ], 99, 2 );
		add_filter( 'woocommerce_variation_prices_sale_price', [ $this, 'get_sale_price' ], 99, 2 );
		add_filter( 'woocommerce_variation_prices_array', [ $this, 'variation_prices' ], 99, 2 );
		add_filter( 'woocommerce_get_variation_prices_hash', [ $this, 'variation_prices_hash' ], 99, 3 );
		add_filter( 'woocommerce_show_variation_price', [ $this, 'show_variation_prices' ], 99, 3 );

		// disable sale flash
		add_action( 'woocommerce_sale_flash', [ $this, 'disable_sale_flash' ], 10, 3 );

		// general product update handler
		add_action( 'woocommerce_update_product', [ $this, 'update_product' ] );

		// variation update handlers
		add_action( 'woocommerce_update_product_variation', [ $this, 'clear_product_transients' ] );
		add_action( 'woocommerce_save_product_variation', [ $this, 'clear_product_transients' ] );

		// Clear product transients when WooCommerce clear transients
		add_action( 'woocommerce_delete_product_transients', [ $this, 'clear_transients_with_woocommerce' ] );

		// Clear transients when the category or role discounts change
		add_action( 'wcwp_category_discount_changed', [ $this, 'clear_role_transients' ] );
		add_action( 'wcwp_role_details_updated', [ $this, 'clear_role_transients' ] );

		// All Import Product Update
		add_action( 'wcwp_all_import_update_product', [ $this, 'clear_product_transients' ] );

		// deleted category
		add_action( 'delete_product_cat', [ $this, 'clear_all_transients' ], 10, 0 );

		add_action( 'wp_head', [ $this, 'add_inline_css' ] );
	}

	/**
	 * Determine whether to disregard the wholesale pricing
	 *
	 * @since 2.0.9
	 * @param  WC_Product $product The current product.
	 * @return boolean
	 */
	private function disregard_wholesale_pricing( WC_Product $product ) {
		/**
		 * Filters whether to skip wholesale calculations for a product altogether
		 * before even running any additional checks.
		 *
		 * @param bool $skip Whether to skip wholesale calculations.
		 * @param WC_Product $product The product which is being calculated.
		 *
		 * @since 2.3.1
		 */
		if ( apply_filters( 'wcwp_skip_wholesale_calculations', false, $product ) ) {
			return true;
		}

		$disregard = false;

		switch ( true ) {
			case ! Lib_Util::is_front_end() || $this->is_inside_cart() || is_checkout():
			case ! in_array( $product->get_type(), [ 'simple', 'variation', 'variable' ], true ):
			case ! is_user_logged_in():
			case Util::get_current_user_wholesale_role_object() === false:
			case $this->has_price_changed( $product ):
			case wp_doing_ajax() && filter_input( INPUT_POST, 'action', FILTER_DEFAULT ) === 'inline-save':
			case did_filter( 'woocommerce_product_export_product_query_args' ) > 0:
				$disregard = true;
				break;

			case is_admin() && wp_doing_ajax():
				$admin_url = wp_parse_url( wp_get_referer() );
				$query     = [];

				if ( $admin_url['query'] ?? '' ) {
					wp_parse_str( $admin_url['query'], $query );
				}

				$order_id = $query['post'] ?? 0;

				if ( OrderUtil::is_order( $order_id, wc_get_order_types() ) ) {
					$disregard = true;
				}

				$post_type = $query['post_type'] ?? '';
				$page      = $query['page'] ?? '';
				$action    = $query['action'] ?? '';

				if ( ( $post_type === 'shop_order' || $page === 'wc-orders' ) && $action === 'new' ) {
					$disregard = true;
				}

				break;
		}

		return apply_filters( 'wcwp_disregard_wholesale_pricing', $disregard, $product );
	}

	/**
	 * Filters the product price
	 *
	 * @param   string|float $price   The product price
	 * @param   WC_Product   $product The product object
	 * @param   boolean      $strict  Whether to return the price without any sale price considerations
	 * @return  float        $price   The filtered price
	 */
	public function get_price( $price, WC_Product $product, $strict = false ) {
		if ( $this->disregard_wholesale_pricing( $product ) ) {
			return $price;
		}

		// if we are getting the price from the Wholesale_Price class, then return immediately
		if ( did_action( 'wcwp_wholesale_price_before_get_pricing' ) > did_action( 'wcwp_wholesale_price_after_get_pricing' ) ) {
			return $price;
		}

		/**
		 * Filters whether to allow wholesale price calculation on a product.
		 *
		 * @param bool $enable Whether to allow wholesale price calculation on a product.
		 * @param WC_Product $product The product which is being calculated.
		 * @param WP_User $user The currently logged-in user, for which the price is being calculated.
		 * @param float $price The wholesale price.
		 * @param array|null $cart_item The cart item if this is calculated in the cart.
		 */
		$calculation_enabled = apply_filters( 'wcwp_enable_wholesale_price_calculation', true, $product, wp_get_current_user(), $price, null );

		if ( ! $calculation_enabled ) {
			return $price;
		}

		$wholesale_price = new Wholesale_Price( $product, Util::get_current_user_wholesale_role_object() );

		if ( $wholesale_price->get_price() === false ) {
			return $price;
		}

		$price = $wholesale_price->get_price();

		if ( $strict ) {
			return $price;
		}

		$sale_price = $this->get_sale_price( false, $product );

		if ( $sale_price ) {
			$price = $sale_price;
		}

		return $price;
	}

	/**
	 * Filters the product sale price
	 *
	 * @param   string|float $sale_price
	 * @param   WC_Product  $product
	 * @return  float        $sale_price
	 */
	public function get_sale_price( $sale_price, WC_Product $product ) {
		if ( $this->disregard_wholesale_pricing( $product ) ) {
			return $sale_price;
		}

		$wholesale_price = new Wholesale_Price( $product, Util::get_current_user_wholesale_role_object() );

		if ( $wholesale_price->get_sale_price() === false ) {
			return $sale_price;
		}

		return $wholesale_price->get_sale_price();
	}

	/**
	 * Alter the array with the variation prices
	 *
	 * @param  array $prices_array   The array with the variation prices
	 * @param  WC_Product $variation The variation product
	 * @return array
	 */
	public function variation_prices( $prices_array, $variation ) {
		$variation_id                                = $variation->get_id();
		$prices_array['price'][ $variation_id ]      = $this->get_price( $prices_array['price'][ $variation_id ], $variation ) ?: $prices_array['price'][ $variation_id ];
		$prices_array['sale_price'][ $variation_id ] = $this->get_sale_price( $prices_array['sale_price'][ $variation_id ], $variation ) ?: $prices_array['sale_price'][ $variation_id ];

		return $prices_array;
	}

	/**
	 * Outputs the wholesale price html
	 *
	 * @param   string     $price_html
	 * @param   WC_Product $product
	 * @return  string     $price_html
	 */
	public function get_price_html( $price_html, WC_Product $product ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $price_html;
		}

		if ( Util::is_price_hidden( $product ) ) {
			return '';
		}

		if ( ! in_array( $product->get_type(), [ 'simple', 'variation', 'variable' ], true ) ) {
			return $price_html;
		}

		if ( ! is_user_logged_in() ) {
			return $price_html;
		}

		if ( $this->disregard_wholesale_pricing( $product ) ) {
			return $price_html;
		}

		$role = Util::get_current_user_wholesale_role_object();

		if ( $role === false ) {
			return $price_html;
		}

		do_action( 'wcwp_price_handler_before_price_html' );

		if ( is_a( $product, 'WC_Product_Variable' ) ) {
			$prices = $product->get_variation_prices( true );

			$min_ws_price = min( (float) current( $prices['price'] ), (float) current( $prices['sale_price'] ) );
			$max_ws_price = min( (float) end( $prices['price'] ), (float) end( $prices['sale_price'] ) );
			$price_class  = '';

			if ( $min_ws_price !== $max_ws_price ) {
				$wholesale_price = wc_format_price_range(
					wc_get_price_to_display( $product, [ 'price' => $min_ws_price ] ),
					wc_get_price_to_display( $product, [ 'price' => $max_ws_price ] )
				);
				$price_class     = 'wcwp-wholesale-price-range';
			} else {
				$wholesale_price = wc_price( wc_get_price_to_display( $product, [ 'price' => $min_ws_price ] ) );
			}

			$regular_prices = array_filter(
				array_map(
					'floatval',
					$prices['regular_price']
				)
			);

			// if regular prices are all zero, it means all variations are wholesale-only
			$is_wholesale_only = empty( $regular_prices );

			if ( get_option( 'wcwp_show_original_price', 'show' ) === 'hide' || $is_wholesale_only ) {
				$price_html = $wholesale_price . $product->get_price_suffix();
			} else {
				$min_price = (float) current( $regular_prices );
				$max_price = (float) end( $regular_prices );

				if ( $min_price !== $max_price ) {
					$price       = wc_format_price_range(
						$min_price,
						$max_price
					);
					$price_class = 'wcwp-wholesale-price-range';
				} else {
					$price = wc_price( $min_price );
				}

				if ( $price === $wholesale_price ) {
					$price_html = $price . $product->get_price_suffix();
				} else {
					$price_html = str_replace(
						'<del ',
						'<del class="' . $price_class . '" ',
						wc_format_sale_price( $price, $wholesale_price )
					);
				}
			}
		} else {
			$wholesale_price_object = new Wholesale_Price( $product, $role );

			if ( $wholesale_price_object === false ) {
				return $price_html;
			}

			$is_on_sale          = Util::is_product_on_sale( $product->is_on_sale( 'edit' ), $product );
			$show_original_price = get_option( 'wcwp_show_original_price', 'show' ) === 'show';
			$regular_price       = $product->get_regular_price();
			$wholesale_price     = $wholesale_price_object->get_price();
			$display_price       = $is_on_sale ? $wholesale_price_object->get_sale_price() : $wholesale_price;

			if ( ! is_numeric( $regular_price ) || ! $show_original_price ) {
				$regular_price = $wholesale_price;
			}

			if ( (float) $regular_price === (float) $display_price ) {
				$price_html = wc_price( wc_get_price_to_display( $product, [ 'price' => $display_price ] ) ) . $product->get_price_suffix();
			} else {
				$price_html = wc_format_sale_price(
					wc_get_price_to_display( $product, [ 'price' => $regular_price ] ),
					wc_get_price_to_display( $product, [ 'price' => $display_price ] )
				);
			}
		}

		do_action( 'wcwp_price_handler_after_price_html' );

		return $price_html;
	}

	/**
	 * Add inline CSS to fix the display of the wholesale price range
	 *
	 * @return void
	 */
	public function add_inline_css() {
		?>
<style>
	.woocommerce .product.product-type-variable .price del.wcwp-wholesale-price-range,
	.woocommerce .product.product-type-variable .price ins.wcwp-wholesale-price-range{
		display:block;
	}
	.product-type-variable .price ins.wcwp-wholesale-price-range{
		line-height: .85em;
	}
	ul.products li.product.product-type-variable .price ins.wcwp-wholesale-price-range,
	.woocommerce .product.product-type-variable .price ins.wcwp-wholesale-price-range{
		margin-left:0;
	}

	.woocommerce .product.product-type-variable .price del.wcwp-wholesale-price-range+ins {
		margin-left: 0;
	}
</style>
		<?php
	}

	/**
	 * Determine whether a product is on sale based on the wholesale role of the user currently logged in
	 *
	 * @param  boolean $onsale
	 * @param  WC_Product $product
	 * @return boolean
	 */
	public function is_on_sale( $onsale, WC_Product $product ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $onsale;
		}

		if ( ! in_array( $product->get_type(), [ 'simple', 'variation', 'variable' ], true ) ) {
			return $onsale;
		}

		if ( ! is_user_logged_in() ) {
			return $onsale;
		}

		$role = Util::get_current_user_wholesale_role_object();

		if ( ! $role ) {
			return $onsale;
		}

		$onsale = Util::is_product_on_sale( $onsale, $product );

		return apply_filters( 'wcwp_product_is_on_sale', $onsale, $this, $role->get_name(), $product );
	}

	/**
	 * Add a custom price hash for the variation price range cache
	 *
	 * @param   array       $price_hash
	 * @param   WC_Product $product
	 * @param   boolean     $for_display
	 * @return  array       $price_hash
	 */
	public function variation_prices_hash( $price_hash, $product, $for_display ) {
		$price_hash   = is_array( $price_hash ) ? $price_hash : [ $price_hash ];
		$price_hash[] = $product->get_category_ids();
		$price_hash[] = get_current_user_id();

		$role = Util::get_wholesale_role_for_user( wp_get_current_user() );

		if ( $role ) {
			$price_hash[] = $role;
		}

		return $price_hash;
	}

	/**
	 * Show variation prices for wholesale always
	 *
	 * @param   bool                    $show
	 * @param   WC_Product_Variable    $parent_product
	 * @param   WC_Product             $variation_product
	 * @return  bool
	 */
	public function show_variation_prices( $show, $parent_product, $variation_product ) {
		if ( $show || ! is_user_logged_in() ) {
			return $show;
		}

		if ( ! Util::shall_apply_wholesale_pricing() ) {
			return $show;
		}

		return true;
	}

	/**
	 * Clears the product transients
	 *
	 * @param int $product_id
	 */
	public function update_product( $product_id ) {
		$product = wc_get_product( $product_id );

		if ( $variations = $product->get_children() ) {
			foreach ( $variations as $variation_id ) {
				$this->clear_product_transients( $variation_id );
			}
		}

		$this->clear_product_transients( $product_id );
	}

	/**
	 * Delete all wholesale price transients for a specific product
	 *
	 * @param int $product_id
	 */
	public function clear_product_transients( $product_id ) {
		global $wpdb;

		$sql = $wpdb->prepare(
			"DELETE
				FROM {$wpdb->options}
				WHERE (`option_name` LIKE %s OR `option_name` LIKE %s)
				AND `option_name` LIKE %s",
			$wpdb->esc_like( '_transient_wcwp_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_wcwp' ) . '%',
			'%' . $wpdb->esc_like( $product_id )
		);

		// phpcs:reason The query is prepared above
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$wpdb->query( $sql );

		\WC_Cache_Helper::get_transient_version( 'product', true );
	}

	/**
	 * Delete all wholesale price transients for a specific role
	 *
	 * @param string $role_name
	 */
	public function clear_role_transients( $role_name ) {
		global $wpdb;

		// fail safe
		if ( substr( $role_name, 0, 4 ) !== 'wcwp' ) {
			return;
		}

		$wpdb->query(
			$wpdb->prepare(
				"DELETE
            FROM {$wpdb->options}
            WHERE `option_name` LIKE %s
            OR `option_name` LIKE %s",
				$wpdb->esc_like( '_transient_' . $role_name ) . '%',
				$wpdb->esc_like( '_transient_timeout_' . $role_name ) . '%'
			)
		);

		\WC_Cache_Helper::get_transient_version( 'product', true );
	}

	/**
	 * Delete all wholesale price transients
	 */
	public function clear_all_transients() {
		global $wpdb;

		$wpdb->query(
			$wpdb->prepare(
				"DELETE
            FROM {$wpdb->prefix}options
            WHERE `option_name` LIKE %s
            OR `option_name` LIKE %s",
				$wpdb->esc_like( '_transient_wcwp_' ) . '%',
				$wpdb->esc_like( '_transient_timeout_wcwp_' ) . '%'
			)
		);

		\WC_Cache_Helper::get_transient_version( 'product', true );
	}

	public function clear_transients_with_woocommerce( $product_id ) {
		if ( in_array( get_post_type( $product_id ), [ 'product', 'product_variation' ], true ) ) {
			$this->clear_product_transients( $product_id );
		} else {
			$this->clear_all_transients();
		}
	}

	/**
	 * Disables the Sale Tag
	 *
	 * @param string        $html
	 * @param WP_Post      $post
	 * @param WC_Product   $product
	 * @return string       $html
	 */
	public function disable_sale_flash( $html, $post, $product ) {
		if ( ! is_user_logged_in() ) {
			return $html;
		}

		$role = Util::get_current_user_wholesale_role_object();

		if ( $role === false ) {
			return $html;
		}

		if ( false !== get_transient( sprintf( '%s_%s', $role->get_name(), $product->get_id() ) ) ) {
			if ( $role->get_apply_to_sale_price() === 'no' && $role->get_product_sale_pricing() === 'no' ) {
				$html = '';
			}
		}

		return $html;
	}

	/**
	 * Remove the sale price filter to avoid endless loop within the `woocommerce_product_get_sale_price` filter
	 *
	 * @return void
	 */
	public function remove_sale_price_filter() {
		remove_filter( 'woocommerce_product_get_sale_price', [ $this, 'get_sale_price' ], 99, 2 );
	}

	/**
	 * Add the sale price filter once there is no risks of endless loop
	 *
	 * @return void
	 */
	public function add_sale_price_filter() {
		add_filter( 'woocommerce_product_get_sale_price', [ $this, 'get_sale_price' ], 99, 2 );
	}

	/**
	 * Determine whether the product price has changed
	 *
	 * This usually happens when a plugin alters the price of a product
	 * attached to a cart item (e.g. with `$cart_item['data']->set_price( $some_price )` )
	 * Excluding this case, we prevent the wholesale price from overriding any changes
	 * when the cart is recalculated (i.e. after `woocommerce_before_calculate_totals`)
	 *
	 * @param  WC_Product $product
	 * @return boolean
	 */
	public function has_price_changed( $product ) {
		$changes = $product->get_changes();

		// If there is any change to the product price, we disregard the wholesale price
		if ( Util::is_between_actions( 'woocommerce_before_calculate_totals', 'woocommerce_after_calculate_totals' ) && isset( $changes['price'] ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Determine whether we are inside the cart
	 * 
	 * @since 2.3.4
	 * @return boolean
	 */
	private function is_inside_cart() {
		return did_action( 'woocommerce_before_cart_table' ) > did_action( 'woocommerce_after_cart_table' );
	}
}
