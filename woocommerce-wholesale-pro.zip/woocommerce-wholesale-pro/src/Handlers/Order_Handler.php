<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Handlers;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Util;

use WC_REST_Authentication;

/**
 * Order handler
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Order_Handler implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'woocommerce_new_order', [ $this, 'add_wholesale_metadata' ], 10, 2 );
		add_action( 'woocommerce_update_order', [ $this, 'add_wholesale_metadata' ], 10, 2 );
	}

	/**
	 * Add a `_wholesale` meta_key to the an order if the current user has a wholesale role
	 *
	 * @param int $order_id The ID of the order that has just been created or updated
	 * @param WC_Order|null $order The order that has just been created or updated
	 */
	public function add_wholesale_metadata( $order_id, $order = null ) {
		if ( is_null( $order ) ) {
			$order = wc_get_order( $order_id );
		}

		if ( ! is_a( $order, 'WC_Order' ) || is_a( $order, 'WC_Subscription' ) ) {
			return;
		}

		$user_id = $order->get_customer_id();

		if ( $user_id ) {
			if ( Util::is_wholesale_user( $user_id ) ) {
				$order->update_meta_data( '_wholesale', 1 );
			} else {
				$order->update_meta_data( '_wholesale', null );
			}

			remove_action( 'woocommerce_update_order', [ $this, 'add_wholesale_metadata' ], 10 );
			$order->save();
			add_action( 'woocommerce_update_order', [ $this, 'add_wholesale_metadata' ], 10, 2 );
		}
	}
}
