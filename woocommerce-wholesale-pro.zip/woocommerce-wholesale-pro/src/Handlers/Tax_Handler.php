<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Handlers;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Role;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Exception;

/**
 * Handles the frontend display and saving of custom registration fields
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Tax_Handler implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'wp', [ $this, 'manage_tax_for_customer' ], PHP_INT_MAX );
		add_filter( 'pre_option_woocommerce_tax_display_shop', [ $this, 'manage_tax_display_shop' ], 999 );
		add_filter( 'woocommerce_calc_tax', [ $this, 'calc_tax' ], 999, 4 );
	}

	/**
	 * Sets the current customer tax exempt state
	 */
	public function manage_tax_for_customer() {
		if ( ! is_user_logged_in() || is_admin() || ! isset( WC()->customer ) ) {
			return;
		}

		$role = Util::get_current_user_wholesale_role_object();

		if ( $role === false ) {
			return;
		}

		try {
			$is_vat_exempt = $this->is_tax_exempt( $role );

			WC()->customer->set_is_vat_exempt( $is_vat_exempt );
		} catch ( Exception $e ) {
			// not a valid wholesale role
			return;
		}
	}

	/**
	 * Filters the WC tax display in shop setting to respect the tax status
	 *
	 * @param   string $pre_option
	 * @return  string $pre_option
	 */
	public function manage_tax_display_shop( $pre_option ) {
		if ( ! is_user_logged_in() ) {
			return $pre_option;
		}

		$role = Util::get_current_user_wholesale_role_object();

		if ( $role === false ) {
			return $pre_option;
		}

		try {
			$pre_option = $this->get_tax_display_mode( $role, $pre_option );
		} catch ( Exception $e ) {
			// not a valid wholesale role
			return $pre_option;
		}

		return $pre_option;
	}

	/**
	 * Determine if a wholesale role is tax exempt
	 *
	 * @param   Wholesale_Role $role
	 * @return  boolean $exempt
	 */
	private function is_tax_exempt( $role ) {
		$disable_tax_global = get_option( 'wcwp_disable_tax', 'no' ) === 'yes';

		switch ( $role->get_disable_tax() ) {
			case 'inherit':
				$disable_tax_global ? $exempt = true : $exempt = false;
				break;
			case 'enable':
				$exempt = false;
				break;
			case 'disable':
				$exempt = true;
				break;
			default:
				$exempt = false;
		}

		return $exempt;
	}

	/**
	 * Determine the tax display mode (shop) for a wholesale role
	 *
	 * @param   Wholesale_Role $role
	 * @param   string $current_option
	 * @return  string $tax_display_mode
	 */
	private function get_tax_display_mode( $role, $current_option ) {
		if ( $this->is_tax_exempt( $role ) ) {
			return 'excl';
		}

		switch ( $role->get_tax_display_shop() ) {
			case 'inherit':
				$tax_display_mode = $current_option;
				break;
			case 'excl':
				$tax_display_mode = 'excl';
				break;
			case 'incl':
				$tax_display_mode = 'incl';
				break;
			default:
				$tax_display_mode = $current_option;
		}

		return $tax_display_mode;
	}

	/**
	 * Filter the tax calculation based on the wholesale role
	 *
	 * This method uses the 'wcwp_prices_follow_tax_display' filter to determine
	 * whether the original price follows the tax display mode set in the wholesale role.
	 * If the tax display mode is set to 'excl' and `wcwp_prices_follow_tax_display` returns true,
	 * then the price is considered to be exclusive of taxes.
	 *
	 * @param   array   $taxes              The calculated taxes
	 * @param   float   $price              The product price
	 * @param   array   $rates              The tax rates
	 * @param   boolean $price_includes_tax Whether the price includes tax
	 * @return  array   $taxes
	 */
	public function calc_tax( $taxes, $price, $rates, $price_includes_tax ) {
		if ( ! is_user_logged_in() ) {
			return $taxes;
		}

		$role = Util::get_current_user_wholesale_role_object();

		if ( $role === false ) {
			return $taxes;
		}

		if ( $role->get_disable_tax() === 'disable' && $price_includes_tax && apply_filters( 'wcwp_prices_follow_tax_status', false, $taxes, $price, $role ) ) {
			$price_includes_tax = false;
			return [];
		}

		return $taxes;
	}
}
