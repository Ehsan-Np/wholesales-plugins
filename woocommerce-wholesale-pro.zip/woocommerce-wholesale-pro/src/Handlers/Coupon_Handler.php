<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Handlers;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Util;

/**
 * Handles the WooCommerce coupon status
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Coupon_Handler implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'woocommerce_coupons_enabled', [ $this, 'disable_coupons' ], \PHP_INT_MAX, 1 );
	}

	/**
	 * Disable WooCommerce coupons
	 *
	 * @param   boolean $enabled
	 * @return  boolean $enabled
	 */
	public function disable_coupons( $enabled ) {
		// bail if already disabled or guest
		if ( ! $enabled || ! is_user_logged_in() ) {
			return $enabled;
		}

		// check if we have disabled coupons
		$disable_coupons = get_option( 'wcwp_disable_coupons', 'no' );

		if ( $disable_coupons === 'no' ) {
			return $enabled;
		}

		if ( Util::shall_apply_wholesale_pricing() ) {
			$enabled = false;
		}

		return $enabled;
	}
}
