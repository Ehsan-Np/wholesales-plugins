<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Handlers;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Shipping\Flat_Rate;
use Barn2\Plugin\WC_Wholesale_Pro\Shipping\Free_Shipping;
use Barn2\Plugin\WC_Wholesale_Pro\Shipping\Local_Pickup;

/**
 * Shipping Method Handler
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Shipping_Handler implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'woocommerce_shipping_methods', [ $this, 'add_shipping_methods' ] );
		add_filter( 'woocommerce_package_rates', [ $this, 'filter_shipping_methods' ] );
		add_filter( 'woocommerce_shipping_method_add_rate', [ $this, 'shipping_method_add_rate' ], 10, 3 );
		add_filter( 'wcwp_is_shipping_rate_hidden', [ $this, 'is_shipping_rate_hidden' ], 10, 4 );
	}

	/**
	 * Add all the Wholesale shipping methods to the list of available shipping methods.
	 *
	 * @param  \WC_Shipping_Method[] $shipping_methods
	 * @return \WC_Shipping_Method[]
	 */
	public function add_shipping_methods( $shipping_methods ) {
		new Flat_Rate();
		new Free_Shipping();
		new Local_Pickup();

		$shipping_methods['wcwp_flat_rate']     = 'Barn2\Plugin\WC_Wholesale_Pro\Shipping\Flat_Rate';
		$shipping_methods['wcwp_free_shipping'] = 'Barn2\Plugin\WC_Wholesale_Pro\Shipping\Free_Shipping';
		$shipping_methods['wcwp_local_pickup']  = 'Barn2\Plugin\WC_Wholesale_Pro\Shipping\Local_Pickup';

		return $shipping_methods;
	}

	/**
	 * Filter WC Shipping Method by roles
	 *
	 * @param   \WC_Shipping_Rate[] $shipping_rates
	 * @return  \WC_Shipping_Rate[]
	 */
	public function filter_shipping_methods( $shipping_rates ) {
		$shipping_roles = get_option( 'wcwp_shipping_roles', [] );

		if ( empty( $shipping_roles ) ) {
			return $shipping_rates;
		}

		if ( is_user_logged_in() ) {
			$user  = \wp_get_current_user();
			$roles = $user->roles;
		} else {
			$roles = [ 'guest_wcwp' ]; // indicator for logged out users
		}

		foreach ( $shipping_rates as $key => $shipping_rate ) {
			if ( empty( $shipping_roles ) || ! isset( $shipping_roles[ $shipping_rate->method_id ] ) || empty( $shipping_roles[ $shipping_rate->method_id ] ) ) {
				continue;
			}

			$is_rate_hidden = empty( array_intersect( $roles, $shipping_roles[ $shipping_rate->method_id ] ) );

			/**
			 * Whether to hide the current shipping rate.
			 *
			 * @param bool $is_rate_hidden                Whether to hide the current shipping rate.
			 * @param array $roles                        The user roles.
			 * @param \WC_Shipping_Rate $shipping_rate    The shipping rate being evaluated.
			 * @param \WC_Shipping_Rate[] $shipping_rates All the available shipping rates.
			 */
			$is_rate_hidden = apply_filters(
				'wcwp_is_shipping_rate_hidden',
				$is_rate_hidden,
				$roles,
				$shipping_rate,
				$shipping_rates
			);

			if ( $is_rate_hidden ) {
				unset( $shipping_rates[ $key ] );
			}
		}

		return $shipping_rates;
	}

	/**
	 * Add the hide property to the instances of the Wholesale Flat Rate shipping method
	 *
	 * @param  \WC_Shipping_Rate $rate
	 * @param  array $args
	 * @param  \WC_Shipping_Method $method
	 * @return \WC_Shipping_Rate
	 */
	public function shipping_method_add_rate( $rate, $args, $method ) {
		if ( 'wcwp_flat_rate' !== $rate->get_method_id() ) {
			return $rate;
		}

		$rate->__set( 'hide', wc_string_to_bool( $method->get_option( 'hide', 'no' ) ) );

		return $rate;
	}

	/**
	 * Whether the wholesale free shipping method is available for the current user
	 *
	 * @param  \WC_Shipping_Rates[] $shipping_rates The shipping rates available for the current package
	 * @return bool
	 */
	public function is_free_shipping_rate_available( $shipping_rates ) {
		return count(
			array_filter(
				$shipping_rates,
				function ( $rate ) {
					return $rate->get_method_id() === 'wcwp_free_shipping';
				}
			)
		) > 0;
	}

	/**
	 * Alter the Flat Rate visibility based on whether or not a free shipping rate is available
	 *
	 * @param  bool $is_rate_hidden
	 * @param  array $roles
	 * @param  \WC_Shipping_Rate $shipping_rate
	 * @param  \WC_Shipping_Rate[] $shipping_rates
	 * @return bool
	 */
	public function is_shipping_rate_hidden( $is_rate_hidden, $roles, $shipping_rate, $shipping_rates ) {
		if (
			! $is_rate_hidden &&
			'wcwp_flat_rate' === $shipping_rate->method_id &&
			$shipping_rate->__get( 'hide' ) &&
			$this->is_free_shipping_rate_available( $shipping_rates )
		) {
			$shipping_roles = get_option( 'wcwp_shipping_roles', [] );
			$is_rate_hidden = ! empty( array_intersect( $roles, $shipping_roles['wcwp_flat_rate'] ) );
		}

		return $is_rate_hidden;
	}
}
