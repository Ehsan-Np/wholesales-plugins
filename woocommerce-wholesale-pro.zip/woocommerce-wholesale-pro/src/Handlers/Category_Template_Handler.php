<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Handlers;

use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Util\Visibility as Visibility_Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

/**
 * Handles the protection of product categories and products by overriding the template
 * Adapted from WooCommerce Protected Categories.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Category_Template_Handler implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		// Run on 'wp' hook so we can set cache constants.
		add_action( 'wp', [ $this, 'protect_shop_pages' ], 20 );
	}

	/**
	 * Protect the shop pages.
	 */
	public function protect_shop_pages() {
		global $wp_did_header;

		// Return if we're not loading a template on the front-end.
		if ( ! $wp_did_header ) {
			return;
		}

		$protection_level = false;
		$product_unlocked = false;

		if ( is_product_category() ) {
			$protection_level = Util::is_protected( Util::get_category_visibility( get_queried_object_id() ) );
			$product_unlocked = $protection_level && Visibility_Util::protected_category_has_unlocked_products( get_queried_object_id() );
		} elseif ( is_product() ) {
			$protection_level = Util::is_protected( Util::get_the_category_visibility() );
			$product_unlocked = $protection_level && Visibility_Util::is_product_unlocked( get_queried_object_id() );
		}

		if ( $product_unlocked ) {
			return;
		}

		switch ( $protection_level ) {
			case 'wholesale_only':
				wp_safe_redirect( Util::get_wholesale_login_url() );
				break;
			case 'public_only':
				$this->handle_404();
				break;
		}

		if ( $protection_level ) {
			/**
			 * Triggered on 'wp' action if protection is enabled.
			 */
			do_action( 'wcwp_protected_woocommerce_page' );

			$this->prevent_indexing();
			$this->prevent_caching();
		}
	}

	/**
	 * Handle 404
	 */
	private function handle_404() {
		global $wp, $wp_query;

		$wp->handle_404();
		$wp_query->is_404      = true;
		$wp_query->is_single   = false;
		$wp_query->is_singular = false;
		$wp_query->is_tax      = false;
		$wp_query->is_archive  = false;

		/**
		 * Triggered after a 404 is handled for Public Only protection.
		 */
		do_action( 'wcwp_handle_404' );
	}

	/**
	 * Prevent search engine indexing.
	 */
	private function prevent_indexing() {
		if ( ! headers_sent() ) {
			header( 'X-Robots-Tag: noindex, nofollow' );
		}

		add_action( 'wp_head', [ $this, 'meta_robots_noindex_head' ], 5 );

		/**
		 * Triggered after search engine index prevention on protected pages.
		 */
		do_action( 'wcwp_prevent_indexing' );
	}

	/**
	 * Add noindex nofollow <meta>
	 */
	public function meta_robots_noindex_head() {
		echo '<meta name="robots" content="noindex, nofollow" />' . "\n";
	}

	/**
	 * Attempt to prevent caching.
	 */
	private function prevent_caching() {
		// Set headers to prevent caching
		nocache_headers();

		// Set constants to prevent caching in certain caching plugins
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		if ( ! defined( 'DONOTCACHEOBJECT' ) ) {
			define( 'DONOTCACHEOBJECT', true );
		}
		if ( ! defined( 'DONOTCACHEDB' ) ) {
			define( 'DONOTCACHEDB', true );
		}

		/**
		 * Triggered after cache prevention is processed on a protected page.
		 */
		do_action( 'wcwp_prevent_caching' );
	}
}
