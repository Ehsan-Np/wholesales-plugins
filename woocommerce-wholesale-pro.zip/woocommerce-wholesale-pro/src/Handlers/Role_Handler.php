<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Handlers;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Util;

use WP_User_Query;

/**
 * Handles some technicalities around WP_Roles
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Role_Handler implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'init', [ $this, 'init' ] );
	}

	/**
	 * Initializes the Role Handler
	 *
	 * @return void
	 */
	public function init() {
		global $wp_roles;

		add_filter( 'pre_update_option_' . $wp_roles->role_key, [ $this, 'handle_deleted_role' ], 10, 2 );
		add_filter( 'editable_roles', [ $this, 'editable_roles' ] );
	}

	/**
	 * Monitors if a role has been deleted.
	 * There is no WP filter/hook for this so we need to check pre_update_option
	 *
	 * @param   array $value
	 * @param   array $old_value
	 * @return  array $value
	 */
	public function handle_deleted_role( $value, $old_value ) {
		// determine if any removed roles are wholesale based
		$removed_wholesale_roles = array_values(
			array_filter(
				array_diff( array_keys( $old_value ), array_keys( $value ) ),
				function ( $role ) {
					return substr( $role, 0, 4 ) === 'wcwp';
				}
			)
		);

		// Nothing to do, bail!
		if ( empty( $removed_wholesale_roles ) ) {
			return $value;
		}

		// make sure you can't remove the special wholesale roles
		$special_roles = [ 'wcwp_wholesale', 'wcwp_pending' ];
		$intersections = array_intersect( $removed_wholesale_roles, $special_roles );

		if ( count( $intersections ) > 0 ) {
			foreach ( $intersections as $role ) {
				$value[ $role ] = $old_value[ $role ];
			}

			$removed_wholesale_roles = array_diff( $removed_wholesale_roles, $special_roles );
		}

		// Nothing to do, bail!
		if ( empty( $removed_wholesale_roles ) ) {
			return $value;
		}

		// get our users who need to go back to the default or core role
		$user_query   = new WP_User_Query( [ 'role__in' => $removed_wholesale_roles ] );
		$default_role = Util::get_default_role();

		foreach ( $user_query->get_results() as $user ) {
			// TODO: Investigate this not removing old role caps
			// https://core.trac.wordpress.org/ticket/45879
			$user->set_role( $default_role );
		}

		return $value;
	}

	/**
	 * Removes pending role from add and edit user screens.
	 *
	 * @param   \WP_Role[] $all_roles
	 * @return  \WP_Role[] $all_roles
	 */
	public function editable_roles( $all_roles ) {
		if ( ! is_admin() ) {
			return $all_roles;
		}

		if ( ! function_exists( 'get_current_screen' ) ) {
			return $all_roles;
		}

		$current_screen = get_current_screen();

		if ( ! $current_screen instanceof \WP_Screen ) {
			return $all_roles;
		}

		// Remove from Add New
		if ( $current_screen->base === 'user' && $current_screen->action === 'add' ) {
			unset( $all_roles['wcwp_pending'] );
		}

		$user_id = filter_input( INPUT_GET, 'user_id', FILTER_SANITIZE_NUMBER_INT );

		// Only show on Edit User if is currently pending
		if ( $current_screen->base === 'user-edit' && $user_id ) {
			$user = get_user_by( 'id', absint( $user_id ) );

			if ( ! in_array( 'wcwp_pending', $user->roles, true ) ) {
				unset( $all_roles['wcwp_pending'] );
			}
		}

		return $all_roles;
	}
}
