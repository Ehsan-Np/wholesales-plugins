<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Handlers;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Price;
use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Role;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Util;

/**
 * Cart Pricing Handler
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Cart_Handler implements Registerable, Standard_Service {

	/**
	 * The role of the current user
	 *
	 * @var Wholesale_Role
	 */
	private $role;

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_action( 'woocommerce_before_calculate_totals', [ $this, 'cart_calculate' ] );
	}

	/**
	 * Set the wholesale role for the current user.
	 *
	 * @param Wholesale_Role $role The role of the current user.
	 * @return self
	 */
	public function set_role( Wholesale_Role $role ) {
		$this->role = $role;

		return $this;
	}

	/**
	 * Get the wholesale role for the current user.
	 *
	 * @return Wholesale_Role
	 */
	public function get_role() {
		return $this->role;
	}

	/**
	 * Calculates the wholesale price inside the cart.
	 *
	 * @param WC_Cart $cart
	 */
	public function cart_calculate( $cart ) {
		$this->role = Util::get_current_user_wholesale_role_object();

		if ( ! $this->role || ! Util::shall_apply_wholesale_pricing() ) {
			return;
		}

		/**
		 * Filters whether to calculate wholesale price in the cart.
		 *
		 * @param bool $should_calculate Whether to calculate wholesale price in the cart.
		 * @param WC_Cart $cart The cart object.
		 * @param Wholesale_Role $role The wholesale role object.
		 * @return bool
		 */
		$should_calculate = apply_filters( 'wcwp_calculate_wholesale_price_in_cart', true, $cart, $this->role );

		if ( ! $should_calculate ) {
			return;
		}

		foreach ( $cart->get_cart_contents() as $cart_item_key => $cart_item ) {
			$price = $this->calculate_wholesale_price( $cart_item );

			if ( is_numeric( $price ) ) {
				$cart_item['data']->set_price( $price );

				// set a flag so we know this is a wholesale price
				$cart->cart_contents[ $cart_item_key ]['wholesale_pro']['is_wholesale_price'] = true;
				$cart->cart_contents[ $cart_item_key ]['wholesale_pro']['wholesale_price']    = $price;
			}
		}
	}

	/**
	 * Filter the cart item price for the mini cart
	 *
	 * @param  string $price
	 * @param  array $cart_item
	 * @return string
	 */
	public function cart_item_price( $price, $cart_item ) {
		if ( ! Util::shall_apply_wholesale_pricing() ) {
			return $price;
		}

		$wholesale_price = $this->calculate_wholesale_price( $cart_item );

		if ( is_numeric( $wholesale_price ) ) {
			$price = wc_price( $wholesale_price );
		}

		return $price;
	}

	/**
	 * Calculate the cart item price based on the current user
	 *
	 * @param  array  $cart_item The cart item.
	 * @return string
	 */
	public function calculate_wholesale_price( $cart_item ) {
		$product = $cart_item['data'];

		if ( ! $product->is_type( 'simple' ) && ! $product->is_type( 'variation' ) ) {
			return false;
		}

		$wholesale_price = new Wholesale_Price( $product, $this->role );

		$price = $wholesale_price->get_final_price();

		/**
		 * Filters whether to allow wholesale price calculation on a product.
		 *
		 * @param bool $enable Whether to allow wholesale price calculation on a product.
		 * @param \WC_Product $product The product which is being calculated.
		 * @param \WP_User $user The user for which the price is being calculated.
		 * @param float $price The wholesale price.
		 * @param array|null $cart_item The cart item if this is calculated in the cart.
		 */
		$calculation_enabled = apply_filters( 'wcwp_enable_wholesale_price_calculation', true, $product, wp_get_current_user(), $price, $cart_item );

		if ( ! $calculation_enabled ) {
			return false;
		}

		return $price;
	}
}
