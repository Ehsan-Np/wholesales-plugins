<?php

namespace Barn2\Plugin\WC_Wholesale_Pro;

use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;

/**
 * Navigation Menu Visiblity Handler
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Navigation_Menu implements Registerable, Standard_Service {

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		add_filter( 'wp_get_nav_menu_items', [ $this, 'protect_nav_menus' ] );
		add_filter( 'wp_list_pages_excludes', [ $this, 'protect_list_pages' ] );
	}

	/**
	 * Hide pages from list_pages based on wholesale status.
	 *
	 * @param array $excludes
	 * @return array
	 */
	public function protect_list_pages( $excludes ) {
		$wcwp_excludes = [];
		$logged_in     = false;
		$is_wholesale  = false;

		if ( is_user_logged_in() ) {
			$logged_in    = true;
			$user         = wp_get_current_user();
			$is_wholesale = Util::is_wholesale_user( $user );
		}

		if ( ! $logged_in && ! Util::site_uses_wc_shop_page() ) {
			$wcwp_excludes[] = get_option( 'wcwp_wholesale_store_page_id' );
		}

		// if logged in, don't show wholesale login page
		if ( $logged_in ) {
			$wcwp_excludes[] = get_option( 'wcwp_wholesale_login_page_id' );
		}

		// if logged and NOT a wholesaler don't show wholesale store page
		if ( $logged_in && ! $is_wholesale && ! Util::site_uses_wc_shop_page() ) {
			$wcwp_excludes[] = get_option( 'wcwp_wholesale_store_page_id' );
		}

		// if logged in and a wholesaler don't show the default shop page
		if ( $logged_in && $is_wholesale && ! Util::site_uses_wc_shop_page() ) {
			$wcwp_excludes[] = wc_get_page_id( 'shop' );
		}

		return array_unique( array_merge( $excludes, $wcwp_excludes ) );
	}

	/**
	 * Hide pages from WP nave menus based on wholesale status.
	 *
	 * @param array $menu_items
	 * @return array
	 */
	public function protect_nav_menus( $menu_items ) {
		$removed_items = [];

		$logged_in    = false;
		$is_wholesale = false;

		if ( is_user_logged_in() ) {
			$logged_in     = true;
			$is_wholesale  = Util::is_wholesale_user();
			$is_shop_admin = Util::is_shop_administrator();
		}

		// loop through menu_items and enforce our requirements as necessary
		foreach ( $menu_items as $key => $menu_item ) {
			if ( 'page' !== $menu_item->object ) {
				continue;
			}

			if ( ! $logged_in && $menu_item->object_id === get_option( 'wcwp_wholesale_store_page_id' ) && ! Util::site_uses_wc_shop_page() ) {
				$removed_items[] = $menu_item->ID;
				unset( $menu_items[ $key ] );
			}

			// if logged in, don't show wholesale login page
			if ( $logged_in && $menu_item->object_id === get_option( 'wcwp_wholesale_login_page_id' ) ) {
				$removed_items[] = $menu_item->ID;
				unset( $menu_items[ $key ] );
			}

			// if logged and NOT a wholesaler or shop admin don't show wholesale store page
			if ( $logged_in && ! $is_wholesale && ! $is_shop_admin && $menu_item->object_id === get_option( 'wcwp_wholesale_store_page_id' ) && ! Util::site_uses_wc_shop_page() ) {
				$removed_items[] = $menu_item->ID;
				unset( $menu_items[ $key ] );
			}

			// if logged in and a wholesaler don't show the default shop page
			if ( $is_wholesale && (int) $menu_item->object_id === wc_get_page_id( 'shop' ) && ! Util::site_uses_wc_shop_page() ) {

				$removed_items[] = $menu_item->ID;
				unset( $menu_items[ $key ] );
			}
		}

		// Now find and remove any children of any removed menu item
		while ( $removed_items ) {
			$child_items_removed = [];

			foreach ( $menu_items as $key => $menu_item ) {
				if ( in_array( (int) $menu_item->menu_item_parent, $removed_items, true ) ) {
					$child_items_removed[] = $menu_item->ID;
					unset( $menu_items[ $key ] );
				}
			}

			// Update the removed list with the removed child items and start over
			$removed_items = $child_items_removed;
		}

		return array_values( $menu_items );
	}

	/**
	 * Fix active class in nav for wholesale store page.
	 *
	 * @param   array $menu_items
	 * @return  array $menu_items
	 */
	public function nav_menu_item_classes( $menu_items ) {
		if ( ! Util::is_wholesale_store_page() && ! is_singular( 'product' ) ) {
			return $menu_items;
		}

		$wholesale_store_page = (int) get_option( 'wcwp_wholesale_store_page_id' );
		$shop_page            = wc_get_page_id( 'shop' );

		if ( ! empty( $menu_items ) && is_array( $menu_items ) ) {
			foreach ( $menu_items as $key => $menu_item ) {
				$classes = (array) $menu_item->classes;
				$menu_id = (int) $menu_item->object_id;

				if ( $wholesale_store_page === $menu_id && 'page' === $menu_item->object ) {
					$menu_items[ $key ]->current = true;
					$classes                     = array_merge( $classes, [ 'current-menu-item', 'current_page_item' ] );
				}

				if ( $shop_page === $menu_id && 'page' === $menu_item->object ) {
					$menu_items[ $key ]->current = false;
					$classes                     = array_diff( $classes, [ 'current-menu-item', 'current_page_item' ] );
				}

				$menu_items[ $key ]->classes = array_unique( $classes );
			}
		}

		return $menu_items;
	}
}
