<?php

namespace Barn2\Plugin\WC_Wholesale_Pro;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Standard_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Util\Visibility as Visibility_Util;

/**
 * This class protects categories (and their products) inside product loops, the main shop page,
 * search results, widgets, navigation menus, and in WooCommerce shortcodes.
 * Adapted from WooCommerce Protected Categories.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Category_Protector implements Registerable, Standard_Service {

	private $hidden_category_ids = false;
	private $unlocked_categories = false;

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		// Adjust query to exclude products in protected categories
		add_action( 'pre_get_posts', [ $this, 'protect_products_in_loop' ], 11, 1 );

		// Protect products in WC shortcodes
		add_filter( 'woocommerce_shortcode_products_query', [ $this, 'protect_products_in_shortcode' ], 10, 3 );

		// Protect product categories, e.g. in product categories widget
		add_filter( 'get_terms_args', [ $this, 'protect_product_categories' ], 10, 2 );

		// Adjust category counts - priority 15 to run after 'wc_change_term_counts' filter
		add_filter( 'get_terms', [ $this, 'update_category_counts' ], 15, 3 );

		// Protect categories and products in nav menus
		add_filter( 'wp_get_nav_menu_items', [ $this, 'protect_nav_menus' ], 10, 3 );

		// Ensure protected products are not purchasable
		add_filter( 'woocommerce_is_purchasable', [ $this, 'is_product_purchasable' ], 10, 2 );

		// Ensure protected products are not displayed in upsells.
		add_filter( 'woocommerce_product_get_upsell_ids', [ $this, 'protect_upsells' ] );

		// Ensure protected products are not displayed in cross-sells.
		add_filter( 'woocommerce_product_get_cross_sell_ids', [ $this, 'protect_upsells' ] );

		// Ensure protected products are not displayed in related products.
		add_filter( 'woocommerce_related_products', [ $this, 'protect_upsells' ] );
	}

	/**
	 * Protect products in the loop.
	 *
	 * @param WP_Query $query
	 */
	public function protect_products_in_loop( $query ) {
		if ( $query->get( 'wcwp_disable_loop_protector' ) === true ) {
			return;
		}

		// phpcs:disable Generic.CodeAnalysis.EmptyStatement.DetectedElseif
		// phpcs:ignore Generic.CodeAnalysis.EmptyStatement.DetectedIf
		if ( isset( $query->query_vars['post_type'] ) && in_array( 'product', (array) $query->query_vars['post_type'], true ) ) {
			// Query is for product post type
		} elseif ( $query->is_search() ) {
			// Search results page
		} elseif ( $query->is_tax( get_object_taxonomies( 'product' ) ) ) {
			// Product category, product tag or other archive (e.g. product attribute)
		} elseif ( $query->get_queried_object() && ( $query->is_post_type_archive( 'product' ) || $query->is_page( wc_get_page_id( 'shop' ) ) ) ) {
			// Main shop page
		} else {
			return;
		}
		// phpcs:enable Generic.CodeAnalysis.EmptyStatement.DetectedElseif

		$query->set( 'tax_query', $this->build_tax_query( $query->query_vars ) );
	}

	/**
	 * Protect products in shortcode.
	 *
	 * @param array $query_args
	 * @param array $atts
	 * @param bool|string $loop_name
	 * @return array
	 */
	public function protect_products_in_shortcode( $query_args, $atts, $loop_name = false ) {
		// Exclude protected categories from query used in shortcode
		$query_args['tax_query'] = $this->build_tax_query( $query_args );

		if ( 'product' === $loop_name && ! empty( $query_args['p'] ) ) {
			$query_args['post__in'] = [ $query_args['p'] ];
			unset( $query_args['p'] );
		}
		return $query_args;
	}

	/**
	 * Protect product categories.
	 *
	 * @param array $args
	 * @param array $taxonomies
	 * @return array
	 */
	public function protect_product_categories( $args, $taxonomies ) {
		// Check we have the right taxonomy
		if ( ! in_array( 'product_cat', (array) $taxonomies, true ) ) {
			return $args;
		}

		// Bail if our internal flag is set ('wcwp')
		if ( ! empty( $args['wcwp'] ) ) {
			return $args;
		}

		// Bail if we're getting the terms for one or more objects
		if ( ! empty( $args['object_ids'] ) ) {
			return $args;
		}

		// Bail if 'get' => 'all' set, e.g. when getting the term hierarchy or get_term_by() called
		if ( 'all' === $args['get'] || 1 === $args['number'] ) {
			return $args;
		}

		// Bail if we're building the exclusions list within get_terms() itself.
		// get_terms() is recursive when 'exclude_tree' is specified so we need to check here to avoid an infinite loop.
		if ( ! empty( $args['child_of'] ) && 'ids' === $args['fields'] && ! $args['hide_empty'] ) {
			return $args;
		}

		// Fix WP bug where 'include' is set to the non-empty array "Array ( [0] => null )"
		if ( is_array( $args['include'] ) ) {
			$args['include'] = array_filter( $args['include'] );
		}

		// Bail if 'include' is set, as 'exclude_tree' will be ignored.
		if ( ! empty( $args['include'] ) ) {
			return $args;
		}

		// Bail if there are no hidden categories.
		if ( ! ( $hidden_category_ids = $this->hidden_category_ids() ) ) {
			return $args;
		}

		// unhide if protected category has unlocked products
		foreach ( $hidden_category_ids as $key => $hidden_category_id ) {
			if ( Visibility_Util::protected_category_has_unlocked_products( $hidden_category_id ) ) {
				unset( $hidden_category_ids[ $key ] );
			}
		}
		$hidden_category_ids = array_values( $hidden_category_ids );

		// Merge in any other exclude trees.
		if ( ! empty( $args['exclude_tree'] ) ) {
			$hidden_category_ids = array_unique( array_merge( wp_parse_id_list( $args['exclude_tree'] ), $hidden_category_ids ) );
		}

		$args['exclude_tree'] = $hidden_category_ids;

		return $args;
	}

	/**
	 * Update the category counts to reflect hidden ones.
	 *
	 * @param array $terms
	 * @param array $taxonomies
	 * @param array $args
	 * @return array
	 */
	public function update_category_counts( $terms, $taxonomies, $args ) {
		// Bail if there are no terms, we have the wrong taxonomy, we're not padding term counts, or we're not returning term objects
		if ( ! $terms || ( is_array( $taxonomies ) && ! in_array( 'product_cat', $taxonomies, true ) ) || empty( $args['pad_counts'] ) || ( 'all' !== $args['fields'] && 'all_with_object_id' !== $args['fields'] ) ) {
			return $terms;
		}

		// Adjust category counts - loop through each top-level category or sub-category
		foreach ( $terms as $term ) {
			if ( $hidden_descendants = array_intersect( $this->hidden_category_ids(), get_term_children( $term->term_id, 'product_cat' ) ) ) {
				// Get number of (unique) products in the hidden child categories
				$count = count( array_unique( get_objects_in_term( $hidden_descendants, 'product_cat' ) ) );

				if ( $count && $count <= $term->count ) {
					$term->count = $term->count - $count;
				}
			}
		}

		return $terms;
	}

	/**
	 * Protect WP navigation menus.
	 *
	 * @param array $menu_items
	 * @param string $menu
	 * @param array $args
	 * @return array
	 */
	public function protect_nav_menus( $menu_items, $menu, $args ) {
		$items_to_remove = [];

		foreach ( $menu_items as $key => $menu_item ) {
			$categories = false;

			if ( 'product' === $menu_item->object ) {
				// Product menu item
				$categories = Util::get_the_category_visibility( $menu_item->object_id );
			} elseif ( 'product_cat' === $menu_item->object ) {
				// Product category menu item
				$categories = Util::get_category_visibility( $menu_item->object_id );
			}

			if ( $categories && $protection = Util::is_protected( $categories ) ) {
				if ( in_array( $protection, [ 'public_only', 'wholesale_only' ], true ) ) {
					$items_to_remove[ $menu_item->ID ] = $menu_item;
				}
			}
		}

		/**
		 * Filter the items to remove.
		 *
		 * @param \WP_Post[] $items_to_remove
		 * @param array $menu_items
		 * @param string $menu
		 * @param array $args
		 * @return array
		 */
		$items_to_remove = apply_filters( 'wcwp_category_nav_protector_items_to_remove', $items_to_remove, $menu_items, $menu, $args );

		// Remove the items
		$menu_items = array_filter(
			$menu_items,
			function ( $menu_item ) use ( $items_to_remove ) {
				return ! isset( $items_to_remove[ $menu_item->ID ] );
			}
		);

		// Now find and remove any children of any removed menu item - simples!
		$removed_items = array_keys( $items_to_remove );

		while ( $removed_items ) {
			$child_items_removed = [];

			foreach ( $menu_items as $key => $menu_item ) {
				if ( in_array( $menu_item->menu_item_parent, $removed_items, true ) ) {
					$child_items_removed[] = $menu_item->ID;
					unset( $menu_items[ $key ] );
				}
			}

			// Update the removed list with the removed child items and start over
			$removed_items = $child_items_removed;
		}

		return array_values( $menu_items );
	}

	/**
	 * Determine if the product is purchasable.
	 *
	 * @param boolean $purchasable
	 * @param WC_Product $product
	 * @return boolean
	 */
	public function is_product_purchasable( $purchasable, $product ) {
		$product_id = Util::get_product_id_for_protection_check( $product );
		$categories = Util::get_the_category_visibility( $product_id );

		if ( Util::is_protected( $categories ) ) {
			return false;
		}

		return $purchasable;
	}

	/**
	 * Protect upsells from being displayed if they are in a protected category.
	 *
	 * @param array $ids Array of upsell IDs.
	 * @return array Array of upsell IDs.
	 */
	public function protect_upsells( $ids ) {
		$protected_ids = [];

		foreach ( $ids as $id ) {
			$categories = Util::get_the_category_visibility( $id );

			if ( Util::is_protected( $categories ) ) {
				$protected_ids[] = $id;
			}
		}

		$protected_ids = apply_filters( 'wcwp_category_upsell_protected_ids', $protected_ids, $ids );

		return array_diff( $ids, $protected_ids );
	}

	/**
	 * Build the taxonomy query.
	 *
	 * @param array $query_args
	 * @return array
	 */
	private function build_tax_query( $query_args ) {
		$tax_query         = isset( $query_args['tax_query'] ) ? $query_args['tax_query'] : [];
		$hidden_categories = $this->hidden_category_ids();

		// Bail early if no categories to protect.
		if ( ! $hidden_categories ) {
			return $tax_query;
		}

		// Is there already a tax query present?
		if ( ! empty( $tax_query ) ) {
			// If current tax query is an 'OR' we need to nest it and wrap our query outside with an 'AND' relation
			if ( ! empty( $tax_query['relation'] ) && ( 'OR' === $tax_query['relation'] ) && count( $tax_query ) > 2 ) {
				$tax_query = [ $tax_query ];
			}

			$tax_query = [ 'relation' => 'AND' ] + $tax_query;
		}

		$visibility_tax_query = [
			'taxonomy'      => 'product_cat',
			'field'         => 'term_id',
			'terms'         => $hidden_categories,
			'operator'      => 'NOT IN',
			'wwp_protected' => true,
		];

		if ( $unlocked = $this->unlocked_categories() ) {
			// If we have unlocked categories, we need to ensure that these are not parents of a hidden category.
			// In this case, the hidden category will take precedence over the unlocked parent, as it's lower in the category hierarchy.
			$hidden_ancestors = [];

			// Get the ancestors for each hidden category.
			foreach ( $hidden_categories as $hidden_id ) {
				$hidden_ancestors = array_merge( $hidden_ancestors, get_ancestors( $hidden_id, 'product_cat', 'taxonomy' ) );
			}

			// Remove duplicates.
			$hidden_ancestors = array_unique( $hidden_ancestors );

			// Now remove any hidden ancestors from the list of unlocked categories.
			$unlocked = array_diff( $unlocked, $hidden_ancestors );

			// If we still have unlocked categories, make sure we include these (IN) in our tax query.
			if ( $unlocked ) {
				$visibility_tax_query             = [ $visibility_tax_query ];
				$visibility_tax_query['relation'] = 'OR';
				$visibility_tax_query[]           = [
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $unlocked,
					'operator' => 'IN',
				];
			}
		}

		$visibility_tax_query['wwp_visibility'] = true;

		$tax_query[] = $visibility_tax_query;
		return $tax_query;
	}

	/**
	 * Set and retrieve hidden category ids.
	 *
	 * @return array
	 */
	private function hidden_category_ids() {
		if ( false === $this->hidden_category_ids ) {
			$this->hidden_category_ids = [];

			// Get all the product categories, and check which are hidden.
			foreach ( Util::to_category_visibilities( Util::get_product_categories() ) as $category ) {
				if ( $category->is_protected() ) {
					$this->hidden_category_ids[] = $category->get_term_id();
				}
			}
		}
		return $this->hidden_category_ids;
	}

	/**
	 * Set and retrieve unlocked category ids.
	 *
	 * @return array
	 */
	private function unlocked_categories() {
		if ( false === $this->unlocked_categories ) {
			$this->unlocked_categories = [];

			// Get all the product categories, and check which are unlocked.
			foreach ( Util::to_category_visibilities( Util::get_product_categories() ) as $category ) {
				if ( $category->is_unlocked() ) {
					$this->unlocked_categories[] = $category->get_term_id();
				}
			}
		}

		return $this->unlocked_categories;
	}
}
