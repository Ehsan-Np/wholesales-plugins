<?php

namespace Barn2\Plugin\WC_Wholesale_Pro;

use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Registerable;
use Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service\Premium_Service;
use Barn2\Plugin\WC_Wholesale_Pro\Util\Visibility as Visibility_Util;

/**
 * This class protects protect products inside product loops, the main shop page,
 * search results, widgets, navigation menus, and in WooCommerce shortcodes.
 *
 * This class is responsible for product level wholesale visibility protection.
 * See Category_Protector for similar functionality at the category level.
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Product_Protector implements Registerable, Premium_Service {

	private $protected_product_ids = false;
	private $unlocked_product_ids  = false;

	/**
	 * {@inheritdoc}
	 */
	public function register() {
		// Protect single products
		add_action( 'template_redirect', [ $this, 'protect_single_product' ], 100, 0 );

		// Add unlocked products to the loop when relevant
		add_filter( 'posts_where', [ $this, 'include_unlocked_products' ], 902, 2 );

		// Remove protected products from the loop when relevant
		add_filter( 'posts_where', [ $this, 'exclude_protected_products' ], 900, 2 );

		// Adjust category counts - priority 16 to run after 'wc_change_term_counts' filter and our category protector filter.
		add_filter( 'get_terms', [ $this, 'update_category_counts' ], 16, 3 );

		// Protect products in nav menus
		add_filter( 'wp_get_nav_menu_items', [ $this, 'protect_nav_menus' ], 10, 3 );

		// Show any unlocked menu items which are category protected
		add_filter( 'wcwp_category_nav_protector_items_to_remove', [ $this, 'show_nav_menus' ], 10, 3 );

		// Ensure protected products are not purchasable (fires at 11, after category check)
		add_filter( 'woocommerce_is_purchasable', [ $this, 'is_product_purchasable' ], 11, 2 );

		// Ensure protected products are not displayed in upsells.
		add_filter( 'woocommerce_product_get_upsell_ids', [ $this, 'protect_upsells' ], 11, 1 );

		// Ensure protected products are not displayed in cross-sells.
		add_filter( 'woocommerce_product_get_cross_sell_ids', [ $this, 'protect_upsells' ], 11, 1 );

		// Ensure protected products are not displayed in related products.
		add_filter( 'woocommerce_related_products', [ $this, 'protect_upsells' ], 11, 1 );

		// Show any unlocked products which were protected on the category level
		add_filter( 'wcwp_category_upsell_protected_ids', [ $this, 'unprotect_upsells' ], 10, 1 );
	}

	/**
	 * Protect single product pages
	 */
	public function protect_single_product() {
		if ( ! is_singular( 'product' ) ) {
			return;
		}

		$id = get_the_ID();

		if ( ! $id ) {
			return;
		}

		$product = wc_get_product( $id );

		if ( ! is_a( $product, 'WC_Product' ) ) {
			return;
		}

		$product_visibility = new Product_Visibility( $product );

		if ( ! $product_visibility->is_protected() ) {
			return;
		}

		// redirect to shop page
		wp_safe_redirect( get_permalink( wc_get_page_id( 'shop' ) ) );
		exit;
	}

	/**
	 * Add unlocked products to the loop when relevant.
	 *
	 * @param string $where
	 * @param WP_Query $query
	 */
	public function include_unlocked_products( $where, $query ) {
		if ( did_action( 'woocommerce_init' ) * did_action( 'woocommerce_after_register_taxonomy' ) * did_action( 'woocommerce_after_register_post_type' ) === 0 ) {
			// Bail if any of those actions have not fired yet
			return $where;
		}

		global $wpdb;

		if ( $query->get( 'wcwp_disable_loop_protector' ) === true ) {
			return $where;
		}

		$unlocked_product_ids = $this->unlocked_product_ids();

		if ( empty( $unlocked_product_ids ) || ! is_array( $unlocked_product_ids ) ) {
			return $where;
		}

		$post_status = $query->get( 'post_status' ) ? $query->get( 'post_status' ) : 'publish';

		/**
		 * Product taxonomies archives
		 */
		if ( $query->is_tax( get_object_taxonomies( 'product' ) ) && $query->is_main_query() ) {
			$term_ids = [ $query->get_queried_object_id() ];
			$taxonomy = $query->get_queried_object();
			$children = get_term_children( $query->get_queried_object_id(), $taxonomy->taxonomy );

			if ( ! empty( $children ) ) {
				$term_ids = array_merge( [ $query->get_queried_object_id() ], $children );
			}

			$taxonomy_objects = get_objects_in_term( $term_ids, $taxonomy->taxonomy );

			if ( is_wp_error( $taxonomy_objects ) ) {
				return $where;
			}

			$intersecting_unlocked_products = array_intersect( $unlocked_product_ids, $taxonomy_objects );

			if ( ! empty( $intersecting_unlocked_products ) ) {
				$include_ids = implode( ',', array_map( 'intval', $intersecting_unlocked_products ) );
				$where      .= " OR ({$wpdb->posts}.ID IN ($include_ids) AND {$wpdb->posts}.post_status = '$post_status')";
			}

			if ( get_option( 'woocommerce_hide_out_of_stock_items' ) === 'yes' ) {
				$where .= " AND {$wpdb->posts}.ID IN (
					SELECT post_id FROM {$wpdb->postmeta}
					WHERE meta_key = '_stock_status'
					AND meta_value != 'outofstock'
				)";
			}

			return $where;
		}

		/**
		 * Shop page.
		 *
		 * We add all unlocked products to the loop.
		 */
		if ( $query->get_queried_object() && ( $query->is_post_type_archive( 'product' ) && $query->is_page( wc_get_page_id( 'shop' ) ) ) ) {
			$include_ids = implode( ',', array_map( 'intval', $unlocked_product_ids ) );
			$where      .= " OR ({$wpdb->posts}.ID IN ($include_ids) AND {$wpdb->posts}.post_status = '$post_status')";

			if ( get_option( 'woocommerce_hide_out_of_stock_items' ) === 'yes' ) {
				$where .= " AND {$wpdb->posts}.ID IN (
					SELECT post_id FROM {$wpdb->postmeta}
					WHERE meta_key = '_stock_status'
					AND meta_value != 'outofstock'
				)";
			}

			return $where;
		}

		/**
		 * Other product loops catch-all.
		 *
		 * Since we may have unlocked products in locked categories, we need to run the query without protection
		 * to determine if any of the unlocked products would be in the original unprotected result.
		 */
		$is_product_loop_query = isset( $query->query_vars['post_type'] ) && in_array( 'product', (array) $query->query_vars['post_type'], true ) && ! $query->is_singular && ! $query->is_search();

		if ( ! $is_product_loop_query ) {
			return $where;
		}

		$protected_terms = Visibility_Util::tax_query_has_protected_terms( $query->get( 'tax_query' ) );

		if ( ! empty( $protected_terms ) ) {

			// unhook product include/exclude
			remove_filter( 'posts_where', [ $this, 'include_unlocked_products' ], 902, 2 );
			remove_filter( 'posts_where', [ $this, 'exclude_protected_products' ], 900, 2 );

			// clone the query
			$unprotected_query = clone $query;

			// remove protected terms
			$unprotected_query->set( 'tax_query', Visibility_Util::tax_query_remove_protected_terms( $unprotected_query->get( 'tax_query' ) ) );
			$unprotected_query->set( 'wcwp_disable_loop_protector', true );
			$unprotected_query->set( 'fields', 'ids' );

			// get the results without the protected terms
			$unprotected_results = $unprotected_query->get_posts();

			// destroy the cloned query
			unset( $cloned_query );

			// re-hook product include/exclude
			add_filter( 'posts_where', [ $this, 'include_unlocked_products' ], 902, 2 );
			add_filter( 'posts_where', [ $this, 'exclude_protected_products' ], 900, 2 );

			// get intersecting results
			$intersecting_unlocked_products = array_intersect( $unlocked_product_ids, $unprotected_results );

			if ( ! empty( $intersecting_unlocked_products ) ) {
				$include_ids = implode( ',', array_map( 'intval', $intersecting_unlocked_products ) );
				$where      .= " OR ({$wpdb->posts}.ID IN ($include_ids) AND {$wpdb->posts}.post_status = '$post_status')";
			}

			return $where;
		}

		return $where;
	}

	/**
	 * Protect products in the loop.
	 *
	 * @param string $where
	 * @param WP_Query $query
	 */
	public function exclude_protected_products( $where, $query ) {
		if ( did_action( 'woocommerce_init' ) * did_action( 'woocommerce_after_register_taxonomy' ) * did_action( 'woocommerce_after_register_post_type' ) === 0 ) {
			// Bail if any of those actions have not fired yet
			return $where;
		}

		// TODO:
		// Removing the following condition was necessary to prevent protected products
		// from being displayed on product archive pages (not the shop page but the category listings).
		//
		// We need to verify that the removal of the condition below has no impact in other

		// if ( $query->get( 'post_type' ) !== 'product' ) {
		// 	return $where;
		// }

		global $wpdb;

		if ( $query->get( 'wcwp_disable_loop_protector' ) === true ) {
			return $where;
		}

		$protected_product_ids = $this->protected_product_ids();

		if ( empty( $this->protected_product_ids() ) || ! is_array( $protected_product_ids ) ) {
			return $where;
		}

		$is_product_loop_query = isset( $query->query_vars['post_type'] ) && in_array( 'product', (array) $query->query_vars['post_type'], true ) && ! $query->is_singular;
		$is_main_shop_page     = $query->get_queried_object() && ( $query->is_post_type_archive( 'product' ) || $query->is_page( wc_get_page_id( 'shop' ) ) );

		if ( ! $is_product_loop_query && ! $query->is_search() && ! $is_main_shop_page && ! $query->is_tax( get_object_taxonomies( 'product' ) ) ) {
			return $where;
		}

		$exclude_ids = implode( ',', array_map( 'intval', $protected_product_ids ) );
		$where      .= " AND {$wpdb->posts}.ID NOT IN ($exclude_ids)";

		return $where;
	}

	/**
	 * Update the category counts to reflect hidden ones.
	 *
	 * @param array $terms
	 * @param array $taxonomies
	 * @param array $args
	 * @return array
	 */
	public function update_category_counts( $terms, $taxonomies, $args ) {
		// Bail if there are no terms, we have the wrong taxonomy, we're not padding term counts, or we're not returning term objects
		if ( ! $terms || ( is_array( $taxonomies ) && ! in_array( 'product_cat', $taxonomies, true ) ) || empty( $args['pad_counts'] ) || ( 'all' !== $args['fields'] && 'all_with_object_id' !== $args['fields'] ) ) {
			return $terms;
		}

		$protected_products = $this->protected_product_ids();

		// Adjust category counts - loop through each top-level category or sub-category
		foreach ( $terms as $term ) {
			// check if we have intersecting products in this category
			$children = get_term_children( $term->term_id, 'product_cat' );
			$term_ids = [ $term->term_id ];

			if ( ! empty( $children ) ) {
				$term_ids = array_merge( $term_ids, $children );
			}

			$category_products               = get_objects_in_term( $term_ids, 'product_cat' );
			$intersecting_protected_products = array_intersect( $category_products, $protected_products );

			$term_count = (int) $term->count;

			// remove the intersecting protectewd products from the term count
			if ( ! empty( $intersecting_protected_products ) ) {
				$term_count -= count( $intersecting_protected_products );
			}

			// Update the term count
			$term->count = max( 0, $term_count );

			// handle product visibility changes
			$unlocked_product_count = Visibility_Util::protected_category_has_unlocked_products( $term->term_id );

			if ( $unlocked_product_count = Visibility_Util::protected_category_has_unlocked_products( $term->term_id ) ) {
				$term->count = count( $unlocked_product_count );
			}

			foreach ( $children as $child_term_id ) {
				if ( Visibility_Util::protected_category_has_unlocked_products( $child_term_id ) ) {
					$term->count += count( Visibility_Util::protected_category_has_unlocked_products( $child_term_id ) );
				}
			}
		}

		return $terms;
	}

	/**
	 * Protect WP navigation menus.
	 *
	 * @param array $menu_items
	 * @param string $menu
	 * @param array $args
	 * @return array
	 */
	public function protect_nav_menus( $menu_items, $menu, $args ) {
		$items_to_remove = [];

		foreach ( $menu_items as $key => $menu_item ) {
			if ( 'product' !== $menu_item->object ) {
				continue;
			}

			$product = wc_get_product( $menu_item->object_id );

			if ( ! is_a( $product, 'WC_Product' ) ) {
				continue;
			}

			$product_visibility = new Product_Visibility( $product );

			if ( $product_visibility->is_protected() ) {
				$items_to_remove[ $menu_item->ID ] = $menu_item;
			}
		}

		/**
		 * Filter the list of menu items to remove for product level visibility protection.
		 *
		 * @param array $items_to_remove
		 * @param array $menu_items
		 * @param string $menu
		 * @param array $args
		 */
		$items_to_remove = apply_filters( 'wcwp_product_nav_protector_items_to_remove', $items_to_remove, $menu_items, $menu, $args );

		// Remove the items
		$menu_items = array_filter(
			$menu_items,
			function ( $menu_item ) use ( $items_to_remove ) {
				return ! isset( $items_to_remove[ $menu_item->ID ] );
			}
		);

		$removed_items = array_keys( $items_to_remove );

		// Now find and remove any children of any removed menu item
		while ( $removed_items ) {
			$child_items_removed = [];

			foreach ( $menu_items as $key => $menu_item ) {
				if ( in_array( $menu_item->menu_item_parent, $removed_items, true ) ) {
					$child_items_removed[] = $menu_item->ID;
					unset( $menu_items[ $key ] );
				}
			}

			// Update the removed list with the removed child items and start over
			$removed_items = $child_items_removed;
		}

		return array_values( $menu_items );
	}

	/**
	 * Show nav menu items with unlocked products.
	 *
	 * @param WP_Post[] $items_to_remove
	 * @param string $menu
	 * @param array $args
	 */
	public function show_nav_menus( $items_to_remove, $menu, $args ) {
		if ( empty( $items_to_remove ) ) {
			return $items_to_remove;
		}

		foreach ( $items_to_remove as $menu_id => $menu_item ) {
			// check if product item which is unlocked
			if ( 'product' === $menu_item->object ) {
				$product            = wc_get_product( $menu_item->object_id );

				if ( ! is_a( $product, 'WC_Product' ) ) {
					continue;
				}

				$product_visibility = new Product_Visibility( $product );

				if ( $product_visibility->is_unlocked() ) {
					unset( $items_to_remove[ $menu_id ] );
				}
			}

			// check if protected category with unlocked products
			if ( 'product_cat' === $menu_item->object ) {
				$term_ids = array_merge( [ $menu_item->object_id ], get_term_children( $menu_item->object_id, 'product_cat' ) );

				foreach ( $term_ids as $term_id ) {
					if ( Visibility_Util::protected_category_has_unlocked_products( $term_id ) ) {
						unset( $items_to_remove[ $menu_id ] );
						break;
					}
				}
			}
		}

		return $items_to_remove;
	}

	/**
	 * Determine if the product is purchasable.
	 *
	 * @param boolean $purchasable
	 * @param \WC_Product $product
	 * @return boolean
	 */
	public function is_product_purchasable( $purchasable, $product ) {
		if ( ! is_a( $product, 'WC_Product' ) ) {
			return $purchasable;
		}

		$product_visibility = new Product_Visibility( $product );

		if ( $product_visibility->is_protected() ) {
			return false;
		}

		if ( $product_visibility->is_unlocked() ) {
			return true;
		}

		return $purchasable;
	}

	/**
	 * Protect upsells from being displayed if they are protected on the product level
	 *
	 * @param array $ids Array of upsell IDs.
	 * @return array Array of upsell IDs.
	 */
	public function protect_upsells( $ids ) {
		$protected_ids = [];

		foreach ( $ids as $id ) {
			$product = wc_get_product( $id );

			if ( ! is_a( $product, 'WC_Product' ) ) {
				continue;
			}

			$product_visibility = new Product_Visibility( $product );

			if ( $product_visibility->is_protected() ) {
				$protected_ids[] = $id;
			}
		}

		return array_diff( $ids, $protected_ids );
	}

	/**
	 * Unprotect upsells which are unlocked on the product level
	 *
	 * @param array $protected_ids
	 * @return array
	 */
	public function unprotect_upsells( $protected_ids ) {
		foreach ( $protected_ids as $id ) {
			$product = wc_get_product( $id );

			if ( ! is_a( $product, 'WC_Product' ) ) {
				continue;
			}

			$product_visibility = new Product_Visibility( $product );

			if ( $product_visibility->is_unlocked() ) {
				$protected_ids = array_values( array_diff( $protected_ids, [ $id ] ) );
			}
		}

		return $protected_ids;
	}

	/**
	 * Set and retrieve hidden product ids.
	 *
	 * @return array
	 */
	private function protected_product_ids() {
		if ( false === $this->protected_product_ids ) {
			$this->protected_product_ids = [];

			// Get all the product categories, and check which are hidden.
			foreach ( Visibility_Util::get_product_visibilities() as $product_visibility ) {
				if ( $product_visibility->is_protected() ) {
					$product                       = $product_visibility->get_product();
					$this->protected_product_ids[] = $product->get_id();
				}
			}
		}

		return $this->protected_product_ids;
	}

	/**
	 * Set and retrieve unlocked product ids.
	 *
	 * @return array
	 */
	private function unlocked_product_ids() {
		if ( false === $this->unlocked_product_ids ) {
			$this->unlocked_product_ids = [];

			// Get all the product categories, and check which are unlocked.
			foreach ( Visibility_Util::get_product_visibilities() as $product_visibility ) {
				if ( $product_visibility->is_unlocked() ) {
					$product                      = $product_visibility->get_product();
					$this->unlocked_product_ids[] = $product->get_id();
				}
			}
		}

		return $this->unlocked_product_ids;
	}
}
