<?php
namespace Barn2\Plugin\WC_Wholesale_Pro;

use Barn2\Plugin\WC_Wholesale_Pro\Controller\Wholesale_Role;
use WP_User;

use function Barn2\Plugin\WC_Wholesale_Pro\woocommerce_wholesale_pro;

/**
 * Utility functions
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
final class Util {
	/**
	 * Return a user object
	 *
	 * @param int|WP_User $user Either a user object or a user ID. Default to current user.
	 */
	public static function get_user_object( $user = null ) {
		if ( is_numeric( $user ) ) {
			$user = get_user_by( 'id', $user );
		} elseif ( is_null( $user ) && get_current_user_id() ) {
			$user = wp_get_current_user();
		}

		return $user;
	}

	/**
	 * Determins if the user is a wholesale user
	 *
	 * @param int|WP_User $user
	 * @return boolean
	 */
	public static function is_wholesale_user( $user = null ) {
		$user = self::get_user_object( $user );

		return $user ? count( array_intersect( self::get_wholesale_roles(), $user->roles ) ) > 0 : false;
	}

	/**
	 * Whether wholesale pricing shall be applied to the website
	 * for the user currently being logged in
	 *
	 * @return bool
	 */
	public static function shall_apply_wholesale_pricing() {
		return self::is_wholesale_user() || self::admin_has_wholesale_pricing();
	}

	/**
	 * Checks if user requires admin moderation
	 *
	 * @param int|WP_User $user
	 * @return bool
	 */
	public static function is_moderation_required( $user = null ) {
		$user = self::get_user_object( $user );

		return $user ? in_array( 'wcwp_pending', $user->roles, true ) : false;
	}


	/**
	 * Retrives all the wholesale role names (key)
	 *
	 * @param string $set 'all' or 'editable'
	 * @return array
	 */
	public static function get_wholesale_roles( $set = 'all' ) {
		global $wp_roles;

		$all_roles = array_keys( $wp_roles->roles );

		$wholesale_roles = array_values(
			array_filter(
				$all_roles,
				function ( $role ) {
					return substr( $role, 0, 4 ) === 'wcwp';
				}
			)
		);

		if ( $set === 'editable' ) {
			$wholesale_roles = array_diff( $wholesale_roles, [ 'wcwp_pending' ] );
		}

		$ordered_roles   = get_option( 'wcwp_role_order', [] );
		$ordered_roles   = is_array( $ordered_roles ) ? $ordered_roles : []; // fail safe for previous bug
		$wholesale_roles = array_merge( array_diff( $wholesale_roles, $ordered_roles ), $ordered_roles );

		return $wholesale_roles;
	}

	/**
	 * Retrieves the wholesale role for a user.
	 *
	 * @param int|WP_User $user
	 * @return false|string
	 */
	public static function get_wholesale_role_for_user( $user = null ) {
		$user            = self::get_user_object( $user );
		$wholesale_roles = $user ? array_values( array_intersect( self::get_wholesale_roles( 'editable' ), $user->roles ) ) : [];

		if ( self::admin_has_wholesale_pricing( $user ) ) {
			// display default wholesale prices for shop administrators
			$wholesale_roles = [ self::get_default_role() ] + $wholesale_roles;
		}

		if ( empty( $wholesale_roles ) ) {
			return false;
		}

		// we get the first role, as we only support a single role
		// possible administrators could add multiple wholesale roles via a role editor plugin
		return $wholesale_roles[0];
	}

	/**
	 * Get a Wholesale_Role object for the current user.
	 *
	 * @return false|Wholesale_Role
	 */
	public static function get_current_user_wholesale_role_object() {
		try {
			$role = new Wholesale_Role( self::get_wholesale_role_for_user() );
		} catch ( \Exception $e ) {
			$role = false;
		}

		return $role;
	}

	/**
	 * Determine if a user is a shop administrator.
	 *
	 * @param int|WP_User $user
	 * @return bool
	 */
	public static function is_shop_administrator( $user = null ) {
		$user                = self::get_user_object( $user );
		$administrator_roles = $user ? array_values( array_intersect( [ 'administrator', 'shop_manager' ], $user->roles ) ) : [];

		if ( empty( $administrator_roles ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Determine if the administrator views the default wholesale role pricing.
	 *
	 * @param int|WP_User $user
	 * @return bool
	 */
	public static function admin_has_wholesale_pricing( $user = null ) {
		$user = self::get_user_object( $user );

		$admin_wholesale_pricing = get_option( 'wcwp_admin_wholesale_pricing', 'yes' );

		if ( self::is_shop_administrator( $user ) && $admin_wholesale_pricing === 'yes' ) {
			return true;
		}

		return false;
	}

	/**
	 * Determines if the SITE has more than one wholesale role setup.
	 *
	 * @return boolean
	 */
	public static function has_multiple_wholesale_roles() {
		$roles = self::get_wholesale_roles();

		return count( $roles ) > 1;
	}

	/**
	 * Returns the default role option
	 *
	 * @return string
	 */
	public static function get_default_role() {
		return get_option( 'wcwp_default_role', 'wcwp_wholesale' );
	}

	/**
	 * Same as wp_is_json_request(), only available in 5.0
	 *
	 * @return boolean
	 */
	public static function is_rest_json_request() {

		if ( isset( $_SERVER['HTTP_ACCEPT'] ) && self::is_json_media_type( $_SERVER['HTTP_ACCEPT'] ) ) {
			return true;
		}

		if ( isset( $_SERVER['CONTENT_TYPE'] ) && self::is_json_media_type( $_SERVER['CONTENT_TYPE'] ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Determine if media request type is JSON.
	 *
	 * @param mixed $media_type
	 * @return mixed
	 */
	public static function is_json_media_type( $media_type ) {
		static $cache = [];

		if ( ! isset( $cache[ $media_type ] ) ) {
			$cache[ $media_type ] = (bool) preg_match( '/(^|\s|,)application\/([\w!#\$&-\^\.\+]+\+)?json(\+oembed)?($|\s|;|,)/i', $media_type );
		}

		return $cache[ $media_type ];
	}


	/**
	 * Get the login redirect URL.
	 *
	 * @return string
	 */
	public static function get_login_redirect_url() {
		$custom_url = get_option( 'wcwp_login_redirect', '' );

		if ( ! empty( $custom_url ) ) {
			return $custom_url;
		}

		return self::get_wholesale_store_url();
	}

	/**
	 * Get the registration redirect URL.
	 *
	 * @return string|false
	 */
	public static function get_registration_redirect_url() {
		$custom_url = get_option( 'wcwp_registration_redirect', false );

		if ( empty( $custom_url ) ) {
			return false;
		}

		return $custom_url;
	}

	/**
	 * Returns the permalink for the login page
	 *
	 * @return string|false
	 */
	public static function get_wholesale_login_url() {
		$login_page_id = get_option( 'wcwp_wholesale_login_page_id' );

		if ( ! $login_page_id ) {
			return false;
		}

		return get_permalink( $login_page_id );
	}

	/**
	 * Returns the permalink for the store page
	 *
	 * @return string|false
	 */
	public static function get_wholesale_store_url() {
		$store_page_id = get_option( 'wcwp_wholesale_store_page_id' );

		if ( ! $store_page_id ) {
			return false;
		}

		return get_permalink( $store_page_id );
	}

	/**
	 * Check if we are on wholesale store page
	 *
	 * @return boolean
	 */
	public static function is_wholesale_store_page() {
		if ( self::site_uses_wc_shop_page() && is_shop() ) {
			return true;
		}

		$store_page_id = get_option( 'wcwp_wholesale_store_page_id' );

		if ( ! $store_page_id ) {
			return false;
		}

		return is_page( absint( $store_page_id ) );
	}

	/**
	 * Check if the current wholesale store page is the WC shop page
	 *
	 * @return boolean
	 */
	public static function site_uses_wc_shop_page() {
		$store_page_id   = get_option( 'wcwp_wholesale_store_page_id' );
		$wc_shop_page_id = wc_get_page_id( 'shop' );

		if ( ! $store_page_id || ! $wc_shop_page_id ) {
			return false;
		}

		return (int) $store_page_id === (int) $wc_shop_page_id;
	}


	/**
	 * Check if we are on wholesale login page
	 *
	 * @return boolean
	 */
	public static function is_wholesale_login_page() {
		$login_page_id = get_option( 'wcwp_wholesale_login_page_id' );

		if ( ! $login_page_id ) {
			return false;
		}

		return is_page( absint( $login_page_id ) );
	}

	/**
	 * Check if we are on a WC frontend page.
	 */
	public static function is_wc_frontend_page() {
		return is_shop() || is_product_category() || is_product_tag() || is_product() || is_cart() || is_checkout() || is_account_page();
	}

	/**
	 * Checks if the price of a product should be hidden
	 *
	 * If the product parameter is missing, then return the global setting.
	 *
	 * @since 2.0.0 Added $product parameter to support category-based 'Hide price until login' option
	 *
	 * @param WC_Product $product The product being considered
	 * @return boolean
	 */
	public static function is_price_hidden( $product = null ) {
		if ( is_user_logged_in() ) {
			return false;
		}

		$hide_prices = false;

		if ( get_option( 'wcwp_hide_prices', 'no' ) === 'yes' ) {
			$hide_prices = true;
		}

		if ( is_a( $product, 'WC_Product' ) ) {
			$category_ids = wc_get_product_terms( $product->get_id(), 'product_cat', [ 'fields' => 'ids' ] );

			if ( ! empty( $category_ids ) ) {
				foreach ( $category_ids as $category_id ) {
					$category_visibility = self::get_category_visibility( $category_id );

					if ( $category_visibility ) {
						$cat_hide_prices = $category_visibility->is_price_hidden( true );
						if ( ! is_null( $cat_hide_prices ) ) {
							$hide_prices = $cat_hide_prices;
							break;
						}
					}
				}
			}
		}

		return $hide_prices;
	}

	public static function is_product_on_sale( $onsale, $product ) {
		if ( ! is_a( $product, 'WC_Product' ) ) {
			return false;
		}

		if ( $product->get_date_on_sale_from() && $product->get_date_on_sale_from()->getTimestamp() > time() ) {
			return false;
		}

		if ( $product->get_date_on_sale_to() && $product->get_date_on_sale_to()->getTimestamp() < time() ) {
			return false;
		}

		$role = self::get_current_user_wholesale_role_object();

		if ( ! $role ) {
			return $onsale;
		}

		$role_name = $role->get_name();
		$options   = get_option( 'wcwp_apply_to_sale_price' );

		$apply_to_sale_price = $options && isset( $options[ $role_name ] ) && $options[ $role_name ] === 'yes';

		if ( $onsale && $apply_to_sale_price ) {
			return true;
		}

		$has_wholesale_sale_price = false;

		if ( $product->is_type( 'variable' ) ) {
			$variations = $product->get_children();

			foreach ( $variations as $variation_id ) {
				if ( is_numeric( get_post_meta( $variation_id, $role_name . '_sale', true ) ) ) {
					$has_wholesale_sale_price = true;
					break;
				}
			}
		} else {
			$has_wholesale_sale_price = is_numeric( $product->get_meta( $role_name . '_sale', true ) );
		}

		return $has_wholesale_sale_price;
	}

	/**
	 * Retrieve an array of all product category IDs.
	 *
	 * @return array
	 */
	public static function get_product_categories() {
		$terms = get_terms(
			[
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'fields'     => 'ids',
				'wcwp'       => true,
			]
		);

		return is_array( $terms ) ? $terms : [];
	}


	/**
	 * Gets the category visibility for a term ID.
	 *
	 * @param int|string $term_id
	 * @return Category_Visibility
	 */
	public static function get_category_visibility( $term_id ) {
		$term_id = absint( $term_id );

		if ( ! $term_id ) {
			return false;
		}

		$visibilities = self::get_category_visibility_cache();

		if ( ! array_key_exists( $term_id, $visibilities ) ) {
			$visibilities[ $term_id ] = new Category_Visibility( $term_id );
			self::update_category_visibility_cache( $visibilities );
		}

		return $visibilities[ $term_id ];
	}

	/**
	 * Gets the Category_Visiblity objects for a WP_Post.
	 *
	 * @param WP_Post $post
	 * @return Category_Visiblity[]
	 */
	public static function get_the_category_visibility( $post = null ) {
		$categories = get_the_terms( $post, 'product_cat' );

		if ( $categories && is_array( $categories ) ) {
			return self::to_category_visibilities( $categories );
		}

		return [];
	}


	/**
	 * Convers an array of WP_Terms to an array of Category_Visibility.
	 *
	 * @param WP_Term[] $terms
	 * @return Category_Visiblity[]
	 */
	public static function to_category_visibilities( $terms ) {
		if ( ! $terms || ! is_array( $terms ) ) {
			return [];
		}

		$result = [];
		$cache  = self::get_category_visibility_cache();

		foreach ( $terms as $term ) {
			$term_id = ( $term instanceof \WP_Term ) ? $term->term_id : absint( $term );

			if ( array_key_exists( $term_id, $cache ) ) {
				$result[] = $cache[ $term_id ];
			} else {
				$cache[ $term_id ] = new Category_Visibility( $term_id );
				$result[]          = $cache[ $term_id ];
			}
		}

		self::update_category_visibility_cache( $cache );

		return $result;
	}

	/**
	 * Get the category visiblity cache.
	 *
	 * @return array
	 */
	private static function get_category_visibility_cache() {
		$cache = wp_cache_get( 'wcwp_cat_visibilities' );

		if ( false !== $cache || ! \is_array( $cache ) ) {
			$cache = [];
		}
		return $cache;
	}

	/**
	 * Updates the category visiblity cache.
	 *
	 * @param Category_Visibility[] $term_visibilities
	 */
	private static function update_category_visibility_cache( $term_visibilities ) {
		wp_cache_set( 'wcwp_cat_visibilities', $term_visibilities );
	}

	/**
	 * Determines whether the supplied category or categories are protected.
	 *
	 * Checks the supplied categories including all ancestors of those categories (if any). Returns
	 * one of the following values:
	 *
	 *  - 'wholesale_only' - One or more categories is protected to wholesale users only
	 *  - 'public_only'    - One or more categories is protected to specific users
	 *  - false            - All categories are public or at least one category has been 'unlocked' (see below).
	 *
	 * The function will return false (i.e. not protected) if all categories including ancestors are public.
	 *
	 * It also returns false if at least one protected category has been unlocked.
	 *
	 * The function will always return false (i.e. unlocked) if at least one category is unlocked, regardless
	 * of the other categories supplied, even if the other categories are protected.
	 *
	 * If two or more protected categories are found, or if one protected category has multiple types of protection,
	 * the function will return the first type of protection found, in the following order of precedence:
	 * wholesale_only, public_only. This can be controlled using the 'wcwp_category_protection_priority_order' filter.
	 *
	 * @param array|Category_Visibility $categories The category or array of Category_Visibility objects to check.
	 * @return boolean|string false if not protected, otherwise 'wholesale_only' or 'public_only',
	 */
	public static function is_protected( $categories ) {
		if ( ! $categories ) {
			return false;
		}

		if ( $categories instanceof Category_Visibility ) {
			$categories = [ $categories ];
		}

		if ( ! is_array( $categories ) ) {
			return false;
		}

		$protection = [];

		foreach ( $categories as $category ) {
			$full_hierarchy = $category->ancestors();
			array_unshift( $full_hierarchy, $category );

			$level = 0;

			foreach ( $full_hierarchy as $category ) {
				if ( $category->is_public() ) {
					++$level;
				} else {
					if ( $category->is_unlocked() ) {
						return false;
					}

					if ( $category->has_wholesale_protection() ) {
						$protection[ $level ][] = 'wholesale_only';
					}

					if ( $category->has_wholesale_exclusion() ) {
						$protection[ $level ][] = 'public_only';
					}

					break;
				}
			}
		}

		if ( empty( $protection ) ) {
			return false;
		}

		$lowest_protection = reset( $protection );

		/**
		 * Filters the category protection priority.
		 *
		 * @param string[] $protection_order The protections in order of priority. Default is `[ 'wholesale_only', 'public_only' ]`.
		 */
		foreach ( apply_filters( 'wcwp_category_protection_priority_order', [ 'wholesale_only', 'public_only' ] ) as $protection_type ) {
			if ( in_array( $protection_type, $lowest_protection, true ) ) {
				return $protection_type;
			}
		}

		// Shouldn't ever get here, but return false (not protected) just in case.
		return false;
	}

	/**
	 * Retrieve the product ID for protection check.
	 *
	 * @param WC_Product $product
	 * @return int
	 */
	public static function get_product_id_for_protection_check( $product ) {
		if ( ! $product ) {
			return false;
		}

		$product_id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();

		/**
		 * Filters the product ID for a category protection check.
		 *
		 * @param int $product_id The product ID.
		 * @param \WC_Product $product The WC Product.
		 */
		return apply_filters( 'wcwp_product_id_for_protection_check', $product_id, $product );
	}

	/**
	 * Create a page and store the ID in an option.
	 * This is a copy of wc_create_page so we can do WP CLI activations without WooCommerce
	 *
	 * @param mixed  $slug Slug for the new page.
	 * @param string $option Option name to store the page's ID.
	 * @param string $page_title (default: '') Title for the new page.
	 * @param string $page_content (default: '') Content for the new page.
	 * @param int    $post_parent (default: 0) Parent for the new page.
	 * @return int page ID.
	 */
	public static function create_page( $slug, $option = '', $page_title = '', $page_content = '', $post_parent = 0 ) {
		global $wpdb;

		$option_value = get_option( $option );

		if ( $option_value > 0 ) {
			$page_object = get_post( $option_value );

			if ( $page_object && 'page' === $page_object->post_type && ! in_array( $page_object->post_status, [ 'pending', 'trash', 'future', 'auto-draft' ], true ) ) {
				// Valid page is already in place.
				return $page_object->ID;
			}
		}

		if ( strlen( $page_content ) > 0 ) {
			// Search for an existing page with the specified page content (typically a shortcode).
			$shortcode        = str_replace( [ '<!-- wp:shortcode -->', '<!-- /wp:shortcode -->' ], '', $page_content );
			$valid_page_found = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type='page' AND post_status NOT IN ( 'pending', 'trash', 'future', 'auto-draft' ) AND post_content LIKE %s LIMIT 1;", "%{$shortcode}%" ) );
		} else {
			// Search for an existing page with the specified page slug.
			$valid_page_found = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type='page' AND post_status NOT IN ( 'pending', 'trash', 'future', 'auto-draft' )  AND post_name = %s LIMIT 1;", $slug ) );
		}

		$valid_page_found = apply_filters( 'woocommerce_create_page_id', $valid_page_found, $slug, $page_content );

		if ( $valid_page_found ) {
			if ( $option ) {
				update_option( $option, $valid_page_found );
			}
			return $valid_page_found;
		}

		// Search for a matching valid trashed page.
		if ( strlen( $page_content ) > 0 ) {
			// Search for an existing page with the specified page content (typically a shortcode).
			$trashed_page_found = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type='page' AND post_status = 'trash' AND post_content LIKE %s LIMIT 1;", "%{$page_content}%" ) );
		} else {
			// Search for an existing page with the specified page slug.
			$trashed_page_found = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_type='page' AND post_status = 'trash' AND post_name = %s LIMIT 1;", $slug ) );
		}

		if ( $trashed_page_found ) {
			$page_id   = $trashed_page_found;
			$page_data = [
				'ID'          => $page_id,
				'post_status' => 'publish',
			];
			wp_update_post( $page_data );
		} else {
			$page_data = [
				'post_status'    => 'publish',
				'post_type'      => 'page',
				'post_author'    => 1,
				'post_name'      => $slug,
				'post_title'     => $page_title,
				'post_content'   => $page_content,
				'post_parent'    => $post_parent,
				'comment_status' => 'closed',
			];
			$page_id   = wp_insert_post( $page_data );
		}

		if ( $option ) {
			update_option( $option, $page_id );
		}

		return $page_id;
	}

	/**
	 * Helper function to replace wp_localize_script
	 *
	 * @param string $script_handle
	 * @param string $variable_name
	 * @param array $script_params
	 */
	public static function add_inline_script_params( $script_handle, $variable_name, $script_params ) {
		$script_data = sprintf( 'var %1$s = %2$s', $variable_name, wp_json_encode( $script_params ) );
		wp_add_inline_script( $script_handle, $script_data, 'before' );
	}

	/**
	 * Determine whether at least one wholesale role has sale pricing active
	 *
	 * Every time a role is updated, the `wcwp_roles_with_sale_pricing` option
	 * is updated with an array containing all the role that have sale pricing active.
	 *
	 * @return boolean
	 */
	public static function some_roles_have_sale_pricing() {
		return count( array_filter( (array) get_option( 'wcwp_roles_with_sale_pricing', [] ) ) ) > 0;
	}

	/**
	 * Determine whether the plugin has a valid license
	 *
	 * @return boolean
	 */
	public static function has_valid_license() {
		return woocommerce_wholesale_pro()->has_valid_license();
	}

	/**
	 * Determine whether the execution is happening between two actions
	 * (and the first action has already completed)
	 *
	 * @param  string $hook1 The first action hook
	 * @param  string $hook2 The second action hook
	 * @return boolean
	 */
	public static function is_between_actions( $hook1, $hook2 ) {
		return did_action( $hook1 ) >= did_action( $hook2 ) && ! doing_action( $hook1 );
	}

	/**
	 * Retrieve all the registration fields for a specific user
	 *
	 * @param int $user_id
	 * @return array $user_fields
	 */
	public static function get_user_registration_fields( $user_id ) {
		$fields      = get_option( 'wcwp_registration_fields', [] );
		$user_fields = [];

		// fields are prefixed with wcwp- in user_meta
		$user_meta = get_user_meta( $user_id );

		foreach ( $user_meta as $key => $value ) {
			if ( 0 === strpos( $key, 'wcwp-' ) ) {
				$user_fields[ $key ] = [
					'value' => $value[0],
					'label' => $fields[ $key ]['label'],
				];
			}
		}

		return $user_fields;
	}
}
