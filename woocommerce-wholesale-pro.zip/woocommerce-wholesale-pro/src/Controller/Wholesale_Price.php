<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Controller;

use WC_Product;

/**
 * Controller to get wholesale pricing
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Wholesale_Price {

	/**
	 * The current product
	 *
	 * @var WC_Product
	 */
	private $product;

	/**
	 * The current role
	 *
	 * @var Wholesale_Role
	 */
	private $role;

	/**
	 * The transient used to store the price
	 *
	 * @var mixed
	 */
	private $transient_key;

	/**
	 * Constructor.
	 *
	 * @param WC_Product|null $product
	 * @param Wholesale_Role|null $role
	 */
	public function __construct( ?WC_Product $product = null, ?Wholesale_Role $role = null ) {
		$this->product = $product;
		$this->role    = $role;
		/**
		 * Filter the transient key name for a generated wholesale price on a product.
		 *
		 * @param string $key The transient key.
		 * @param \WC_Product $product The WooCommerce product.
		 * @param Wholesale_Role $wholesale_role The wholesale role object.
		 */
		$this->transient_key = apply_filters( 'wcwp_product_price_transient_key', sprintf( '%s_%s', $this->role->get_name(), $this->product->get_id() ), $this->product, $this->role );
	}

	/**
	 * Retrieve the wholesale price.
	 *
	 * @return mixed
	 */
	public function get_price() {
		$price = false;

		if ( false === ( $cached_wholesale_price = get_transient( $this->transient_key ) ) ) {
			$wholesale_price = $this->calculate_product_price();

			if ( is_numeric( $wholesale_price ) ) {
				set_transient( $this->transient_key, $wholesale_price, WEEK_IN_SECONDS );
				$price = $wholesale_price;
			}
		} else {
			$price = $cached_wholesale_price;
		}

		/**
		 * Filters the calculated wholesale price for a product.
		 *
		 * @param float $price The calculated price.
		 * @param \WC_Product $product The WooCommerce product.
		 * @param Wholesale_Role $wholesale_role The wholesale role object.
		 */
		return apply_filters( 'wcwp_calculated_wholesale_price', $price, $this->product, $this->role );
	}

	/**
	 * Retrieve the wholesale sale price.
	 *
	 * @return mixed
	 */
	public function get_sale_price() {
		$sale_price = $this->get_product_sale_pricing();
		$price      = $this->get_price();

		if ( ! is_numeric( $sale_price ) ) {
			$exact_price = $this->get_product_pricing();

			if ( $exact_price ) {
				// We have an exact wholesale price which has higher priority over the "Apply to Sale Price" setting
				return $exact_price;
			}

			// We don't have a product-based wholesale sale price...
			if ( $this->role->get_apply_to_sale_price() === 'yes' ) {
				// ...and we should apply the discount to the sale price
				$original_sale_price = $this->product->get_sale_price( 'edit' );

				if ( is_numeric( $original_sale_price ) ) {
					// The original sale price is valid, so apply the discount to that
					$discount = $this->get_category_discount();

					if ( ! $discount ) {
						$discount = $this->role->get_global_discount() ?: 0;
					}

					$sale_price = (string) round( (float) $original_sale_price * ( 1 - ( $discount / 100 ) ), wc_get_price_decimals() );
				} else {
					// The original sale price is not valid, so use the wholesale price instead
					$sale_price = $price;
				}
			} else {
				// The retail sale price does not affect the wholesale sale price
				// so we'll just use the wholesale price
				$sale_price = $price;
			}
		}

		/**
		 * Filters the calculated wholesale sale price for a product.
		 *
		 * @param bool|string|float $sale_price The calculated sale price.
		 * @param \WC_Product $product The WooCommerce product.
		 * @param Wholesale_Role $wholesale_role The wholesale role object.
		 */
		return apply_filters( 'wcwp_calculated_wholesale_sale_price', $sale_price, $this->product, $this->role );
	}

	/**
	 * Get the final price of a product
	 *
	 * This is just a shorthand of the `get_sale_price()` method
	 * that ultimately returns the product price if no sale price is available,
	 * which corresponds to the following two scenarios:
	 * * the product does not have a product-specific wholesale sale price
	 * * the wholesale role does not enjoy discounts on the retail sale price
	 *
	 * This shorthand is aimed at dispelling any confusion that may arise
	 * when the `get_sale_price()` method is called in the code
	 * with the intention of getting the final price of a product.
	 *
	 * @return mixed
	 */
	public function get_final_price() {
		return $this->get_sale_price();
	}

	/**
	 * Calculate the correct price for a wholesale role
	 *
	 * @return  false|float     $price_hash
	 */
	private function calculate_product_price() {
		$price = false;

		if ( is_numeric( $product_price = $this->get_product_pricing() ) ) { // 1st: Product Specific Pricing
			$price = $product_price;
		} elseif ( is_numeric( $category_price = $this->get_category_pricing() ) ) { // 2nd: Category Pricing Discount
			$price = $category_price;
		} elseif ( is_numeric( $global_price = $this->get_global_pricing() ) ) { // 3rd: Global Pricing Discount
			$price = $global_price;
		}

		return $price;
	}

	/**
	 * Retrieve product pricing if available
	 *
	 * @return  false|float     $product_price
	 */
	private function get_product_pricing() {
		if ( $this->role->get_product_pricing() !== 'yes' ) {
			return '';
		}

		$product_price = $this->product->get_meta( $this->role->get_name() );

		if ( ! is_numeric( $product_price ) ) {
			return '';
		}

		return $product_price;
	}

	/**
	 * Retrieve product sale pricing if available
	 *
	 * @return  false|float     $product_sale_price
	 */
	private function get_product_sale_pricing() {
		if ( $this->role->get_product_sale_pricing() !== 'yes' ) {
			return '';
		}

		$product_sale_price = $this->product->get_meta( $this->role->get_name() . '_sale' );

		if ( ! is_numeric( $product_sale_price ) ) {
			return '';
		}

		return $product_sale_price;
	}

	/**
	 * Retrieve the Category Pricing if available
	 *
	 * @return false|float
	 */
	private function get_category_pricing() {
		$price = $this->get_pricing();

		if ( ! is_numeric( $price ) ) {
			return false;
		}

		$discount = $this->get_category_discount();

		if ( ! $discount ) {
			return false;
		}

		// Calculate the price
		$price = round( $price * ( 1 - ( $discount / 100 ) ), wc_get_price_decimals() );

		return $price;
	}

	/**
	 * Retrieve Global pricing if available
	 *
	 * @return false|float
	 */
	private function get_global_pricing() {
		$price = $this->get_pricing();

		if ( ! is_numeric( $price ) ) {
			return $price;
		}

		$discount = (float) $this->role->get_global_discount();

		$price = round( $price * ( 1 - ( $discount / 100 ) ), wc_get_price_decimals() );

		return $price;
	}

	/**
	 * Retrieve the pricing for a product
	 *
	 * @return string
	 */
	private function get_pricing() {
		do_action( 'wcwp_wholesale_price_before_get_pricing' );

		$price = $this->product->get_regular_price();

		do_action( 'wcwp_wholesale_price_after_get_pricing' );

		return $price;
	}

	private function get_category_discount() {
		$id = $this->product->is_type( 'variation' ) ? $this->product->get_parent_id() : $this->product->get_id();

		$categories = get_the_terms( $id, 'product_cat' );

		if ( ! $categories || empty( $categories ) ) {
			return false;
		}

		$discounts = [];

		// Grab our discounts
		foreach ( $categories as $category ) {
			$category_discount = get_term_meta( $category->term_id, $this->role->get_name(), true );

			if ( $category_discount ) {
				$discounts[ $category->name ] = $category_discount;
				continue;
			}

			$ancestors = get_ancestors( $category->term_id, 'product_cat', 'taxonomy' );

			foreach ( $ancestors as $ancestor_id ) {
				$category_discount = get_term_meta( $ancestor_id, $this->role->get_name(), true );

				if ( $category_discount ) {
					$ancestor                     = get_term( $ancestor_id, 'product_cat' );
					$discounts[ $ancestor->name ] = $category_discount;
					continue;
				}
			}
		}

		// Bail if none set
		if ( empty( $discounts ) ) {
			return false;
		}

		// Return the highest discount if we have multiple categories assigned
		return max( $discounts );
	}
}
