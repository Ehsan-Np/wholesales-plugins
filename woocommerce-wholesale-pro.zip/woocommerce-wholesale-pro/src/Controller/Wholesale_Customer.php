<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Controller;

use Barn2\Plugin\WC_Wholesale_Pro\Util;
use Exception;
use InvalidArgumentException;

/**
 * Controller to manage wholesale customer operations
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Wholesale_Customer {

	/**
	 * The user object.
	 *
	 * @var \WP_User
	 */
	private $object;

	/**
	 * The user ID.
	 *
	 * @var int
	 */
	private $user_id;

	/**
	 * The username.
	 *
	 * @var string
	 */
	private $username;

	/**
	 * The email address.
	 *
	 * @var string
	 */
	private $email;

	/**
	 * Whether moderation is required.
	 *
	 * @var bool
	 */
	private $moderation_required;

	/**
	 * Constructor.
	 *
	 * @param int $id
	 * @throws InvalidArgumentException Non-numeric user ID supplied.
	 * @throws Exception User does not exist.
	 * @throws Exception Not a wholesale user.
	 */
	public function __construct( $id = 0 ) {
		if ( ! is_numeric( $id ) ) {
			throw new InvalidArgumentException( 'Non-numeric user ID supplied.' );
		}

		if ( is_numeric( $id ) ) {
			$user = \get_user_by( 'id', $id );
		}

		if ( ! $user ) {
			throw new Exception( 'User does not exist.' );
		}

		if ( ! Util::is_wholesale_user( $user ) ) {
			throw new Exception( 'Not a wholesale user.' );
		}

		$this->object              = $user;
		$this->user_id             = $user->ID;
		$this->username            = $user->user_login;
		$this->email               = $user->user_email;
		$this->moderation_required = Util::is_moderation_required( $user );
	}

	/**
	 * Approve a customer if they are pending
	 */
	public function approve() {
		if ( ! $this->moderation_required ) {
			return false;
		}

		$this->object->set_role( Util::get_default_role() );
		$password = $this->regenerate_password();

		/**
		 * Triggered after a pending customer is approved.
		 *
		 * @param int $user_id The user_id of the approved customer.
		 */
		do_action( 'wcwp_user_after_approved', $this->user_id, $password );
	}

	/**
	 * Reject a customer if they are pending
	 */
	public function reject() {
		if ( ! $this->moderation_required ) {
			return false;
		}

		/**
		 * Triggered after pending customer is rejected, but before deleted.
		 *
		 * @param int $user_id The user_id of the rejected customer.
		 */
		do_action( 'wcwp_user_before_reject', $this->user_id );

		wp_delete_user( $this->user_id );
	}

	/**
	 * Regenerate the password after approval
	 *
	 * @return string $password
	 */
	private function regenerate_password() {
		$password = wp_generate_password();

		wp_set_password( $password, $this->user_id );

		return $password;
	}
}
