<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Controller;

use Barn2\Plugin\WC_Wholesale_Pro\Util;
use WP_Role;
use Exception;

/**
 * Controller to manage wholesale role operations
 *
 * @package   Barn2\woocommerce-wholesale-pro
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 */
class Wholesale_Role {
	/**
	 * Reference for wp_options keys
	 *
	 * @var string
	 */
	protected $default_role_option        = 'wcwp_default_role';
	protected $discount_option            = 'wcwp_global_discounts';
	protected $pricing_option             = 'wcwp_product_pricing';
	protected $sale_pricing_option        = 'wcwp_product_sale_pricing';
	protected $apply_to_sale_price_option = 'wcwp_apply_to_sale_price';
	protected $tax_option                 = 'wcwp_disable_tax_role';
	protected $tax_display_shop_option    = 'wcwp_tax_display_shop_role';

	/**
	 * Default data for a wholesale role
	 *
	 * @var array
	 */
	protected $data = [
		'name'                 => false,
		'display_name'         => '',
		'default'              => 'no',
		'global_discount'      => 0,
		'disable_tax'          => 'inherit',
		'product_pricing'      => 'no',
		'product_sale_pricing' => 'no',
		'apply_to_sale_price'  => 'no',
		'tax_display_shop'     => 'inherit',
	];

	/**
	 * Constructor.
	 *
	 * @param string $name
	 * @throws Exception Invalid role.
	 * @throws Exception Invalid role.
	 */
	public function __construct( $name = 'new' ) {
		global $wp_roles;

		if ( $name !== 'new' && substr( $name, 0, 4 ) !== 'wcwp' ) {
			throw new Exception( __( 'Invalid role.', 'woocommerce-wholesale-pro' ) );
		}

		$role = $name === 'new' ? 'new' : get_role( $name );

		if ( $role === null ) {
			throw new Exception( __( 'Invalid role.', 'woocommerce-wholesale-pro' ) );
		} elseif ( $role !== 'new' ) {
			$this->data['name']                 = $role->name;
			$this->data['display_name']         = $wp_roles->roles[ $this->data['name'] ]['name'];
			$this->data['default']              = Util::get_default_role() === $this->data['name'] ? 'yes' : 'no';
			$this->data['global_discount']      = $this->read_group_option( $this->discount_option );
			$this->data['product_pricing']      = $this->read_group_option( $this->pricing_option );
			$this->data['product_sale_pricing'] = $this->read_group_option( $this->sale_pricing_option );
			$this->data['apply_to_sale_price']  = $this->read_group_option( $this->apply_to_sale_price_option );
			$this->data['disable_tax']          = empty( $this->read_group_option( $this->tax_option ) ) ? 'inherit' : $this->read_group_option( $this->tax_option );
			$this->data['tax_display_shop']     = empty( $this->read_group_option( $this->tax_display_shop_option ) ) ? 'inherit' : $this->read_group_option( $this->tax_display_shop_option );
		}
	}

	/**
	 * Returns the wholesale role data
	 *
	 * @return array
	 */
	public function get_data() {
		return $this->data;
	}

	/**
	 * Update a role
	 *
	 * @param array $data
	 */
	public function update( $data ) {
		if ( $this->data['name'] === 'wcwp_pending' ) {
			return;
		}

		if ( isset( $data['display_name'] ) ) {
			$this->set_display_name( $data['display_name'] );
		}

		if ( isset( $data['global_discount'] ) ) {
			$this->set_group_option( $this->discount_option, $data['global_discount'], true );
		}

		if ( isset( $data['product_pricing'] ) ) {
			$this->set_group_option( $this->pricing_option, $data['product_pricing'] );
		}

		if ( isset( $data['product_sale_pricing'] ) ) {
			$this->update_roles_with_sale_pricing( $data['product_sale_pricing'] === 'yes' );
			$this->set_group_option( $this->sale_pricing_option, $data['product_sale_pricing'] );
		}

		if ( isset( $data['apply_to_sale_price'] ) ) {
			$this->set_group_option( $this->apply_to_sale_price_option, $data['apply_to_sale_price'] );
		}

		if ( isset( $data['disable_tax'] ) ) {
			$this->set_group_option( $this->tax_option, $data['disable_tax'] );
		}

		if ( isset( $data['tax_display_shop'] ) ) {
			$this->set_group_option( $this->tax_display_shop_option, $data['tax_display_shop'] );
		}

		if ( isset( $data['default'] ) ) {
			$this->set_default( $data['default'] );
		}

		/**
		 * Triggered after a Wholesale Role is updated.
		 *
		 * @param string $role_name The name of the role which was updated.
		 * @param array $data The new data.
		 */
		do_action( 'wcwp_role_details_updated', $this->data['name'], $this->data );
	}

	/**
	 * Delete a role
	 */
	public function delete() {
		if ( ! in_array( $this->data['name'], [ 'wcwp_wholesale', 'wcwp_pending' ], true ) ) {
			remove_role( $this->data['name'] );

			// delete pricing and
			$this->delete_group_option( $this->pricing_option );
			$this->delete_group_option( $this->sale_pricing_option );
			$this->delete_group_option( $this->apply_to_sale_price_option );
			$this->delete_group_option( $this->discount_option );
			$this->delete_group_option( $this->tax_option );
			$this->delete_group_option( $this->tax_display_shop_option );

			// clean up the role ordering option
			$ordered_roles = get_option( 'wcwp_role_order', [] );

			$cleaned_roles = array_values(
				array_filter(
					$ordered_roles,
					function ( $role ) {
						return $role !== $this->data['name'];
					}
				)
			);

			update_option( 'wcwp_role_order', $cleaned_roles, false );
			$this->update_roles_with_sale_pricing( false );

			// Revert to default role if this is the current default
			if ( $this->data['default'] === 'yes' ) {
				update_option( $this->default_role_option, 'wcwp_wholesale' );
			}
		}
	}

	/**
	 * Update the
	 *
	 * @param  mixed $is_sale_pricing_active
	 * @return void
	 */
	private function update_roles_with_sale_pricing( $is_sale_pricing_active ) {
		$roles_with_sale_pricing = (array) get_option( 'wcwp_roles_with_sale_pricing', '' );

		if ( $is_sale_pricing_active ) {
			$roles_with_sale_pricing = array_unique( array_merge( $roles_with_sale_pricing, [ $this->data['name'] ] ) );
		} else {
			$roles_with_sale_pricing = array_diff( $roles_with_sale_pricing, [ $this->data['name'] ] );
		}

		update_option( 'wcwp_roles_with_sale_pricing', $roles_with_sale_pricing, false );
	}

	/**
	 * Creates a new role or updates the display name
	 *
	 * @param string $display_name
	 */
	private function set_display_name( $display_name ) {
		global $wp_roles;

		$capabilities = [ 'read' => 'true' ];

		if ( ! $this->data['name'] ) {
			$name               = sanitize_title( $display_name );
			$this->data['name'] = 'wcwp_' . $name;
			add_role( $this->data['name'], $display_name, $capabilities );
		} else {
			$wp_roles->roles[ $this->data['name'] ] = [
				'name'         => $display_name,
				'capabilities' => $capabilities,
			];

			update_option( $wp_roles->role_key, $wp_roles->roles );

			$wp_roles->role_objects[ $this->data['name'] ] = new WP_Role( $this->data['name'], $capabilities );
			$wp_roles->role_names[ $this->data['name'] ]   = $display_name;
		}
	}

	/**
	 * Sets the role as the default role.
	 *
	 * @param string $default
	 */
	private function set_default( $default ) {
		$default_role = Util::get_default_role();

		if ( $default === 'yes' && $this->data['name'] !== $default_role ) {
			update_option( $this->default_role_option, $this->data['name'], false );
		}

		$this->data['default'] = $default;
	}

	/**
	 * Sets role data inside a group option
	 *
	 * @param string $option_key
	 * @param string|int|bool $value
	 * @param boolean $autoload
	 */
	private function set_group_option( $option_key, $value, $autoload = false ) {
		$options = get_option( $option_key, [] );

		$options[ $this->data['name'] ] = $value;

		update_option( $option_key, $options, $autoload );

		$this->data[ $option_key ] = $value;
	}

	/**
	 * Reads role data from inside a group option
	 *
	 * @param string $option_key
	 * @return string|int|bool
	 */
	private function read_group_option( $option_key ) {
		$options = get_option( $option_key, [] );

		if ( ! empty( $options ) && isset( $options[ $this->data['name'] ] ) ) {
			return $options[ $this->data['name'] ];
		}

		return false;
	}

	/**
	 * Deletes a role's data from a group option
	 *
	 * @param string $option_key
	 * @param bool $autoload
	 * @return bool
	 */
	private function delete_group_option( $option_key, $autoload = false ) {
		$options = get_option( $option_key, [] );

		if ( ! empty( $options ) && isset( $options[ $this->data['name'] ] ) ) {
			unset( $options[ $this->data['name'] ] );
		}

		return update_option( $option_key, $options, $autoload );
	}

	/**
	 * Gets the role name as used by WP
	 *
	 * @return string
	 */
	public function get_name() {
		return $this->data['name'];
	}

	/**
	 * Gets the role display name
	 *
	 * @return string
	 */
	public function get_display_name() {
		return $this->data['display_name'];
	}

	/**
	 * Gets the global discount amount
	 *
	 * @return int
	 */
	public function get_global_discount() {
		return $this->data['global_discount'];
	}

	/**
	 * Gets the default status
	 *
	 * @return string
	 */
	public function get_default() {
		return $this->data['default'];
	}

	/**
	 * Gets the product pricing status
	 *
	 * @return string
	 */
	public function get_product_pricing() {
		return $this->data['product_pricing'];
	}

	/**
	 * Gets the product sale pricing status
	 *
	 * @return string
	 */
	public function get_product_sale_pricing() {
		return $this->data['product_sale_pricing'];
	}

	/**
	 * Gets the apply-to-sale-price status
	 *
	 * @return string
	 */
	public function get_apply_to_sale_price() {
		return $this->data['apply_to_sale_price'];
	}

	/**
	 * Gets the disable tax status
	 *
	 * @return string
	 */
	public function get_disable_tax() {
		return $this->data['disable_tax'];
	}

	/**
	 * Gets the price display status
	 *
	 * @return string
	 */
	public function get_tax_display_shop() {
		return $this->data['tax_display_shop'];
	}

	/**
	 * Get the number of users with this role
	 *
	 * @return int
	 */
	public function get_user_count() {
		$count_users = count_users();

		return $count_users['avail_roles'][ $this->data['name'] ] ?? 0;
	}
}
