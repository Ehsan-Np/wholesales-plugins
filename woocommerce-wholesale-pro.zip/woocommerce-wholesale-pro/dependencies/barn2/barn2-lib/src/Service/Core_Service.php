<?php

namespace Barn2\Plugin\WC_Wholesale_Pro\Dependencies\Lib\Service;

/**
 * Marker interface to denote a core service.
 *
 * @package   Barn2\barn2-lib
 * @author    Barn2 Plugins <support@barn2.com>
 * @license   GPL-3.0
 * @copyright Barn2 Media Ltd
 * @version   1.0
 * @internal
 */
interface Core_Service extends Service
{
}
