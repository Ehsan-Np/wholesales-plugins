<?php
/**
 * Login Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/wholesale-login-register-form.php.
 *
 * HOWEVER, on occasion Barn2 will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package   Barn2\woocommerce-wholesale-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Filters the column class for the Login/Register form wrapper.
 *
 * @param string $class The CSS class.
 */
$columns_wrap_class = apply_filters( 'wcwp_login_register_columns_wrap_class', 'u-columns col2-set' );

/**
 * Filters the column class for the Login form.
 *
 * @param string $class The CSS class.
 */
$login_column_class = apply_filters( 'wcwp_login_column_class', 'u-column1 col-1' );

/**
 * Filters the column class for the Register form.
 *
 * @param string $class The CSS class.
 */
$register_column_class = apply_filters( 'wcwp_register_column_class', 'u-column2 col-2' );

/**
 * Output before the HTML of the Login/Register form.
 */
do_action( 'wcwp_before_login_register_form' ); ?>

<div class="woocommerce">

<?php woocommerce_output_all_notices(); ?>

<?php if ( 'yes' === get_option( 'wcwp_enable_registration', 'yes' ) ) : ?>

<div class="<?php echo esc_attr( $columns_wrap_class ); ?>" id="customer_login">

	<div class="<?php echo esc_attr( $login_column_class ); ?>">

<?php endif; ?>
		<h2><?php esc_html_e( 'Login', 'woocommerce-wholesale-pro' ); ?></h2>

		<form class="woocommerce-form woocommerce-form-login login" method="post">

			<?php do_action( 'woocommerce_login_form_start' ); ?>

			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="username"><?php esc_html_e( 'Username or email address', 'woocommerce-wholesale-pro' ); ?>&nbsp;<span class="required">*</span></label>
				<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
			</p>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="password"><?php esc_html_e( 'Password', 'woocommerce-wholesale-pro' ); ?>&nbsp;<span class="required">*</span></label>
				<input class="woocommerce-Input woocommerce-Input--text input-text" type="password" name="password" id="password" autocomplete="current-password" />
			</p>

			<?php do_action( 'woocommerce_login_form' ); ?>

			<p class="form-row">
				<label class="woocommerce-form__label woocommerce-form__label-for-checkbox woocommerce-form-login__rememberme">
					<input class="woocommerce-form__input woocommerce-form__input-checkbox" name="rememberme" type="checkbox" id="rememberme" value="forever" /> <span><?php esc_html_e( 'Remember me', 'woocommerce-wholesale-pro' ); ?></span>
				</label>
				<?php wp_nonce_field( 'wcwp-login', 'wcwp-login-nonce' ); ?>
				<button type="submit" class="woocommerce-button button woocommerce-form-login__submit<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" name="login" value="<?php esc_attr_e( 'Log in', 'woocommerce-wholesale-pro' ); ?>"><?php esc_html_e( 'Log in', 'woocommerce-wholesale-pro' ); ?></button>
			</p>
			<p class="woocommerce-LostPassword lost_password">
				<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Lost your password?', 'woocommerce-wholesale-pro' ); ?></a>
			</p>

			<?php do_action( 'woocommerce_login_form_end' ); ?>

		</form>

<?php if ( 'yes' === get_option( 'wcwp_enable_registration', 'yes' ) ) : ?>

	</div>

	<div class="<?php echo esc_attr( $register_column_class ); ?>">

		<h2><?php esc_html_e( 'Register', 'woocommerce-wholesale-pro' ); ?></h2>

		<form method="post" class="woocommerce-form woocommerce-form-register register" <?php do_action( 'woocommerce_register_form_tag' ); ?> >

			<?php do_action( 'woocommerce_register_form_start' ); ?>

			<?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>

				<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
					<label for="reg_username"><?php esc_html_e( 'Username', 'woocommerce-wholesale-pro' ); ?>&nbsp;<span class="required">*</span></label>
					<input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="username" id="reg_username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
				</p>

			<?php endif; ?>

			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label for="reg_email"><?php esc_html_e( 'Email address', 'woocommerce-wholesale-pro' ); ?>&nbsp;<span class="required">*</span></label>
				<input type="email" class="woocommerce-Input woocommerce-Input--text input-text" name="email" id="reg_email" autocomplete="email" value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
			</p>


			<?php
			/**
			 * Output after the Email input on the Login/Register form.
			 */
			do_action( 'wcwp_register_form' );

			do_action( 'woocommerce_register_form' );
			?>


			<?php if ( 'yes' === \get_option( 'wcwp_moderate_registrations', 'yes' ) ) : ?>
				<p><?php esc_html_e( 'A link to set a password will be sent to your email address when your account is approved.', 'woocommerce-wholesale-pro' ); ?></p>
			<?php else : ?>
				<p><?php esc_html_e( 'A link to set a password will be sent to your email address.', 'woocommerce-wholesale-pro' ); ?></p>
			<?php endif; ?>

			<p class="woocommerce-FormRow form-row">
				<?php wp_nonce_field( 'wcwp-register', 'wcwp-register-nonce' ); ?>
				<button type="submit" class="woocommerce-Button woocommerce-button button woocommerce-form-register__submit<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" name="register" value="<?php esc_attr_e( 'Register', 'woocommerce-wholesale-pro' ); ?>"><?php esc_html_e( 'Register', 'woocommerce-wholesale-pro' ); ?></button>
			</p>

			<?php do_action( 'woocommerce_register_form_end' ); ?>

		</form>

	</div>

</div>
<?php endif; ?>

</div>

<?php
/**
 * Output after the HTML of the Login/Register form.
 */
do_action( 'wcwp_after_login_register_form' ); ?>
