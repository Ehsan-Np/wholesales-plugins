<?php
/**
 * Login Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/wholesale-register-form.php.
 *
 * HOWEVER, on occasion Barn2 will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package   Barn2\woocommerce-wholesale-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Output before the HTML of the Register form.
 */
do_action( 'wcwp_before_register_form' ); ?>

<div class="woocommerce">

	<?php woocommerce_output_all_notices(); ?>

	<h2><?php esc_html_e( 'Register', 'woocommerce-wholesale-pro' ); ?></h2>

	<form method="post" class="woocommerce-form woocommerce-form-register register" <?php do_action( 'woocommerce_register_form_tag' ); ?> >

		<?php do_action( 'woocommerce_register_form_start' ); ?>

		<div class="wcwp-form-section">
			<div class="wcwp-form-fields">

			<?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>

				<div class="wcwp-field-wrap wcwp-field-type-text">
					<label for="reg_username"><?php esc_html_e( 'Username', 'woocommerce-wholesale-pro' ); ?>&nbsp;<span class="required">*</span></label>
					<input type="text" class="woocommerce-Input woocommerce-Input--text input-text wcwp-input" name="username" id="reg_username" autocomplete="username" value="<?php echo ( ! empty( $_POST['username'] ) ) ? esc_attr( wp_unslash( $_POST['username'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
				</div>

			<?php endif; ?>

			<div class="wcwp-field-wrap wcwp-field-type-email">
				<label for="reg_email"><?php esc_html_e( 'Email address', 'woocommerce-wholesale-pro' ); ?>&nbsp;<span class="required">*</span></label>
				<input type="email" class="woocommerce-Input woocommerce-Input--text input-text wcwp-input" name="email" id="reg_email" autocomplete="email" value="<?php echo ( ! empty( $_POST['email'] ) ) ? esc_attr( wp_unslash( $_POST['email'] ) ) : ''; ?>" /><?php // @codingStandardsIgnoreLine ?>
			</div>

			</div>
		</div>

		<?php
		/**
		 * Output after the Email input on the Login/Register form.
		 */
		do_action( 'wcwp_register_form' );

		do_action( 'woocommerce_register_form' );
		?>


		<?php if ( 'yes' === get_option( 'wcwp_moderate_registrations', 'yes' ) ) : ?>
			<p><?php esc_html_e( 'A password will be sent to your email address when your account is approved.', 'woocommerce-wholesale-pro' ); ?></p>
		<?php else : ?>
			<p><?php esc_html_e( 'A password will be sent to your email address.', 'woocommerce-wholesale-pro' ); ?></p>
		<?php endif; ?>

		<p class="woocommerce-FormRow form-row">
			<?php wp_nonce_field( 'wcwp-register', 'wcwp-register-nonce' ); ?>
			<button type="submit" class="woocommerce-Button woocommerce-button button woocommerce-form-register__submit<?php echo esc_attr( wc_wp_theme_get_element_class_name( 'button' ) ? ' ' . wc_wp_theme_get_element_class_name( 'button' ) : '' ); ?>" name="register" value="<?php esc_attr_e( 'Register', 'woocommerce-wholesale-pro' ); ?>"><?php esc_html_e( 'Register', 'woocommerce-wholesale-pro' ); ?></button>
		</p>

		<?php do_action( 'woocommerce_register_form_end' ); ?>

	</form>

</div>

<?php
/**
 * Output after the HTML of the Register form.
 */
do_action( 'wcwp_after_register_form' ); ?>
