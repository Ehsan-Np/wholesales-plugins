# Security Policy

## Reporting a Vulnerability

Please report security bugs found in the source code for the *WooCommerce Wholesale Pro* plugin through the [Patchstack Vulnerability Disclosure Program](https://patchstack.com/database/vdp/woocommerce-wholesale-pro). 

The Patchstack team will assist you with verification, CVE assignment, and notify the developers of this plugin.