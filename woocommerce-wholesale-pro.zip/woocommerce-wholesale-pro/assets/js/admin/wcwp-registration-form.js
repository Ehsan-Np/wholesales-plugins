/* global jQuery, wcwpTradeAdmin */
(function ($) {
    'use strict';

    // -----------------------------------------------------------------------
    // Auto-scroll to edit form when ?edit_field= is present
    // -----------------------------------------------------------------------

    var $editAnchor = $('#wcwp-edit-form-anchor');
    if ($editAnchor.length) {
        // Small delay lets WP admin finish its own layout paint.
        setTimeout(function () {
            $('html, body').animate({
                scrollTop: $editAnchor.offset().top - 32
            }, 400);
        }, 100);
    }

    // -----------------------------------------------------------------------
    // Drag-and-drop reorder
    // -----------------------------------------------------------------------

    var $sortable = $('#wcwp-field-sortable');

    if ($sortable.length) {
        $sortable.sortable({
            handle: '.wcwp-drag-handle',
            items: 'tr',
            axis: 'y',
            cursor: 'grabbing',
            placeholder: 'wcwp-sortable-placeholder',
            forcePlaceholderSize: true,
            update: function () {
                saveOrder();
            }
        });
    }

    function saveOrder() {
        var order = [];
        $sortable.find('tr[data-field-key]').each(function () {
            order.push($(this).data('field-key'));
        });
        $.post(wcwpTradeAdmin.ajaxUrl, {
            action:      'wcwp_reorder_fields',
            _wpnonce:    wcwpTradeAdmin.reorderNonce,
            field_order: order
        });
    }

    // -----------------------------------------------------------------------
    // Live meta key preview (add form only)
    // -----------------------------------------------------------------------

    var $labelInput = $('#field_label');
    var $keyPreview = $('#wcwp-key-preview');

    if ($labelInput.length && $keyPreview.length) {
        $labelInput.on('input', function () {
            var slug = $(this).val()
                .toLowerCase()
                .replace(/[^a-z0-9\s_]/g, '')
                .trim()
                .replace(/\s+/g, '_');
            $keyPreview.text((wcwpTradeAdmin.keyPrefix || 'wwp_trade_') + slug);
        });
    }

    // -----------------------------------------------------------------------
    // Conditional field-type visibility in the form builder
    // -----------------------------------------------------------------------

    var $typeSelect = $('#field_type');

    // Declared here so updateTypeVisibility (called on load below) can reference them.
    var $roleToggle       = $('#wcwp-assign-role-toggle');
    var $roleMapContainer = $('#wcwp-role-map-container');

    function updateTypeVisibility() {
        var type = $typeSelect.val();
        var hasOptions  = ['select', 'multiselect', 'radio'].indexOf(type) !== -1;
        var isContent   = type === 'textarea' || type === 'display_text';
        var isFile      = type === 'file';
        var hasRole     = ['select', 'radio'].indexOf(type) !== -1;

        $('#wcwp-options-row').toggle(hasOptions || isContent);
        $('#wcwp-multiple-row').toggle(isFile);
        $('#wcwp-assign-role-row').toggle(hasRole);

        if (isContent) {
            $('#wcwp-options-label').text('Content');
            $('#wcwp-options-desc').html('This text will be displayed on the registration form. Allowed HTML: <code>&lt;strong&gt;</code>, <code>&lt;em&gt;</code>, <code>&lt;u&gt;</code>, <code>&lt;a href&gt;</code>, <code>&lt;img&gt;</code>, <code>&lt;p&gt;</code>, <code>&lt;br&gt;</code>.');
        } else {
            $('#wcwp-options-label').text('Options');
            $('#wcwp-options-desc').text('One option per line, or comma-separated.');
        }

        if (hasRole && $roleToggle.length && $roleToggle.is(':checked')) {
            rebuildRoleMapTable();
        }
    }

    if ($typeSelect.length) {
        $typeSelect.on('change', updateTypeVisibility);
        updateTypeVisibility(); // Run on load for edit form.
    }

    // Rebuild role-map table when the options textarea changes.
    var $optionsTextarea = $('#field_options');
    if ($optionsTextarea.length) {
        $optionsTextarea.on('input change', function () {
            if ($roleToggle.length && $roleToggle.is(':checked')) {
                rebuildRoleMapTable();
            }
        });
    }

    // -----------------------------------------------------------------------
    // Conditional logic toggle
    // -----------------------------------------------------------------------

    var $condEnable    = $('#wcwp-cond-enable');
    var $condFieldsRow = $('#wcwp-cond-fields-row');

    if ($condEnable.length) {
        $condEnable.on('change', function () {
            $condFieldsRow.toggle(this.checked);
        });
        // Initial state handled by PHP inline style on the <tr>.
    }

    // -----------------------------------------------------------------------
    // Conditions table: add/remove rows + per-row checkbox hint
    // -----------------------------------------------------------------------

    var MAX_CONDITIONS = 5;

    function getFieldOptionsHtml() {
        return $('#wcwp-cond-tbody .wcwp-cond-when-field').first().html() || '';
    }

    function updateCondAddButtonState() {
        var count = $('#wcwp-cond-tbody .wcwp-cond-row').length;
        $('#wcwp-cond-add-row').prop('disabled', count >= MAX_CONDITIONS);
    }

    function updateCondRemoveButtonState() {
        var $rows = $('#wcwp-cond-tbody .wcwp-cond-row');
        $rows.find('.wcwp-cond-remove-row').prop('disabled', $rows.length <= 1);
    }

    function buildConditionRow() {
        var $select = $('<select>', { name: 'cond_when_field[]', 'class': 'wcwp-cond-when-field' })
            .html(getFieldOptionsHtml())
            .val('');
        var $hint = $('<span>', { 'class': 'wcwp-cond-checkbox-hint' })
            .text('Use "1" (checked) or "" (unchecked)');
        var $operator = $('<select>', { name: 'cond_operator[]', 'class': 'wcwp-cond-operator' }).append(
            $('<option>', { value: 'equals',        text: 'Equals' }),
            $('<option>', { value: 'not_equals',    text: 'Does not equal' }),
            $('<option>', { value: 'is_empty',      text: 'Is empty' }),
            $('<option>', { value: 'is_not_empty',  text: 'Is not empty' }),
            $('<option>', { value: 'greater_than',  text: 'Greater than' }),
            $('<option>', { value: 'less_than',     text: 'Less than' })
        );
        var $input = $('<input>', { type: 'text', name: 'cond_has_value[]' })
            .attr('placeholder', 'e.g. Yes, Other, 1');
        var $remove = $('<button>', { type: 'button', 'class': 'button wcwp-cond-remove-row', 'aria-label': 'Remove condition' })
            .text('−');
        return $('<tr>', { 'class': 'wcwp-cond-row' }).append(
            $('<td>').append($select, $hint),
            $('<td>').append($operator),
            $('<td>').append($input),
            $('<td>', { 'class': 'wcwp-cond-remove-col' }).append($remove)
        );
    }

    $('#wcwp-cond-add-row').on('click', function () {
        $('#wcwp-cond-tbody').append(buildConditionRow());
        updateCondAddButtonState();
        updateCondRemoveButtonState();
        updateDuplicateFieldState();
    });

    $(document).on('click', '.wcwp-cond-remove-row', function () {
        $(this).closest('.wcwp-cond-row').remove();
        updateCondAddButtonState();
        updateCondRemoveButtonState();
        updateDuplicateFieldState();
    });

    // Per-row checkbox hint (delegated).
    $(document).on('change', '.wcwp-cond-when-field', function () {
        var type = $(this).find(':selected').data('type');
        $(this).siblings('.wcwp-cond-checkbox-hint').toggle(type === 'checkbox');
        updateDuplicateFieldState();
    });

    // Hide value input when operator is is_empty / is_not_empty (delegated).
    $(document).on('change', '.wcwp-cond-operator', function () {
        var op = $(this).val();
        var noValue = (op === 'is_empty' || op === 'is_not_empty');
        $(this).closest('tr').find('input[name="cond_has_value[]"]').toggle(!noValue);
    });

    // -----------------------------------------------------------------------
    // Duplicate field detection (All mode = disable; Any mode = warn)
    // -----------------------------------------------------------------------

    function isAllMode() {
        return $('#wcwp-cond-match').val() === 'all';
    }

    function updateDuplicateFieldState() {
        var $selects = $('#wcwp-cond-tbody .wcwp-cond-when-field');
        var allMode  = isAllMode();

        // Collect all currently selected non-empty values.
        var selected = [];
        $selects.each(function () {
            var v = $(this).val();
            if (v !== '') { selected.push(v); }
        });

        // Find which values appear more than once.
        var counts = {};
        $.each(selected, function (i, v) { counts[v] = (counts[v] || 0) + 1; });
        var duplicates = {};
        $.each(counts, function (v, c) { if (c > 1) { duplicates[v] = true; } });
        var hasDuplicates = Object.keys(duplicates).length > 0;

        // Remove any existing warning.
        $('#wcwp-cond-duplicate-warning').remove();

        if (allMode) {
            // Disable duplicate options in every select except the one that owns the value.
            $selects.each(function () {
                var $sel  = $(this);
                var myVal = $sel.val();
                $sel.find('option').each(function () {
                    var optVal = $(this).val();
                    if (optVal === '' || optVal === myVal) {
                        $(this).prop('disabled', false);
                    } else {
                        // Disable if another row already uses this value.
                        $(this).prop('disabled', !!duplicates[optVal] || selected.indexOf(optVal) !== -1);
                    }
                });
            });

            // If duplicates somehow exist (e.g. loaded from saved data), show warning.
            if (hasDuplicates) {
                $('<p id="wcwp-cond-duplicate-warning" class="wcwp-cond-warning">' +
                    'Duplicate fields detected. In "All" mode each field should appear once.' +
                  '</p>').insertAfter('#wcwp-cond-add-row');
            }
        } else {
            // Any mode — re-enable all options, just warn if duplicates exist.
            $selects.each(function () {
                $(this).find('option').prop('disabled', false);
            });

        }
    }

    // Re-run when the All/Any mode select changes.
    $('#wcwp-cond-match').on('change', function () {
        updateDuplicateFieldState();
    });

    // Init state for pre-filled rows on edit form load.
    $('.wcwp-cond-when-field').trigger('change');
    updateCondRemoveButtonState();
    updateCondAddButtonState();
    updateDuplicateFieldState();

    // -----------------------------------------------------------------------
    // Assign-role toggle
    // -----------------------------------------------------------------------

    if ($roleToggle.length) {
        $roleToggle.on('change', function () {
            $roleMapContainer.toggle(this.checked);
            if (this.checked) {
                rebuildRoleMapTable();
            }
        });
    }

    // -----------------------------------------------------------------------
    // Role-map table helpers
    // -----------------------------------------------------------------------

    function parseOptions() {
        var raw = $('#field_options').val() || '';
        var parts = raw.split(/[\r\n,]+/);
        var result = [];
        for (var i = 0; i < parts.length; i++) {
            var v = parts[i].trim();
            if (v !== '') { result.push(v); }
        }
        return result;
    }

    function buildRoleMapRow(optionValue, selectedRole) {
        var roles = (wcwpTradeAdmin && wcwpTradeAdmin.roles) ? wcwpTradeAdmin.roles : {};
        var selected = Array.isArray(selectedRole) ? (selectedRole[0] || '') : (selectedRole || '');
        var $select = $('<select>', {
            name:    'role_map[' + optionValue + ']',
            'class': 'wcwp-role-select'
        });
        $select.append($('<option>', { value: '', text: '— No role —' }));
        $.each(roles, function (slug, label) {
            var $opt = $('<option>', { value: slug, text: label });
            if (slug === selected) { $opt.prop('selected', true); }
            $select.append($opt);
        });
        return $('<tr>', { 'data-option-value': optionValue }).append(
            $('<td>').text(optionValue),
            $('<td>').append($select)
        );
    }

    function rebuildRoleMapTable() {
        var $tbody     = $('#wcwp-role-map-tbody');
        var newOptions = parseOptions();

        // Capture current selections before clearing.
        var existing = {};
        $tbody.find('tr[data-option-value]').each(function () {
            var val = $(this).data('option-value');
            existing[val] = $(this).find('.wcwp-role-select').val() || '';
        });

        $tbody.empty();

        if (newOptions.length === 0) {
            $tbody.append(
                $('<tr>', { id: 'wcwp-role-map-empty-row' }).append(
                    $('<td>', { colspan: 2 }).append($('<em>').text('Add options above to configure role mapping.'))
                )
            );
            return;
        }

        $.each(newOptions, function (i, optVal) {
            $tbody.append(buildRoleMapRow(optVal, existing[optVal] || ''));
        });
    }

    // -----------------------------------------------------------------------
    // Disable submit button on form submit to prevent duplicate submissions
    // -----------------------------------------------------------------------

    $('button[name="wcwp_add_field"], button[name="wcwp_edit_field"]').closest('form').on('submit', function (e) {
        var $btn = $(this).find('button[name="wcwp_add_field"], button[name="wcwp_edit_field"]');
        if ($btn.prop('disabled')) {
            e.preventDefault();
            return;
        }
        $('<input>').attr({ type: 'hidden', name: $btn.attr('name'), value: $btn.val() }).appendTo(this);
        $btn.prop('disabled', true).text('Saving…');
    });

    // Section combo-box: existing sections as options, free-text new values allowed.
    var $sectionSelect = $('#field_section');
    if ($sectionSelect.length && typeof $.fn.selectWoo === 'function') {
        $sectionSelect.selectWoo({
            width:                '25em',
            allowClear:           true,
            placeholder:          $sectionSelect.data('placeholder') || '',
            tags:                 true,
            createTag:            function (params) {
                var term = $.trim(params.term);
                if (term === '') { return null; }
                return { id: term, text: term, newTag: true };
            },
            templateResult:       function (data) {
                if (data.newTag) {
                    return $('<span>').text('New section: "' + data.text + '"');
                }
                return data.text;
            }
        });
    }

}(jQuery));
