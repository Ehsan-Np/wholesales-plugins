/**
 * WCWP Trade Registration — frontend conditional logic engine.
 *
 * Each field with conditional rules is wrapped in a div with:
 *   data-conditions — JSON: { action, match, conditions: [{when_field, has_value}] }
 *
 * Checkbox triggers use "1" (checked) or "" (unchecked) as the value.
 * match="all" requires every condition to match; match="any" requires at least one.
 */
(function ($) {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        // File uploads require multipart encoding — set it on the WC register form.
        var regForm = document.querySelector('form.woocommerce-form-register');
        if (regForm) {
            regForm.setAttribute('enctype', 'multipart/form-data');
        }

        initMultiSelects();

        var conditionalWrappers = document.querySelectorAll('[data-conditions]');

        // Collect all unique trigger field keys so we can attach listeners once.
        var allTriggerKeys = {};

        conditionalWrappers.forEach(function (wrapper) {
            var condData;
            try {
                condData = JSON.parse(wrapper.dataset.conditions);
            } catch (e) {
                return;
            }
            if (!condData || !Array.isArray(condData.conditions)) {
                return;
            }

            var action = condData.action || 'show';
            var match  = condData.match  || 'all';

            function evaluate() {
                var results = condData.conditions.map(function (cond) {
                    var triggers = document.querySelectorAll(
                        '[name="' + CSS.escape(cond.when_field) + '"],' +
                        '[name="' + CSS.escape(cond.when_field) + '[]"]'
                    );
                    if (!triggers.length) {
                        return false;
                    }
                    var val = getCurrentValue(triggers);
                    var op  = cond.operator || 'equals';
                    switch (op) {
                        case 'is_empty':      return val === '';
                        case 'is_not_empty':  return val !== '';
                        case 'not_equals':    return val !== cond.has_value;
                        case 'greater_than':  return parseFloat(val) > parseFloat(cond.has_value);
                        case 'less_than':     return parseFloat(val) < parseFloat(cond.has_value);
                        default:              return val === cond.has_value; // equals
                    }
                });

                var conditionMet = match === 'any'
                    ? results.some(Boolean)
                    : results.every(Boolean);

                var shouldShow = (action === 'show') ? conditionMet : !conditionMet;

                if (shouldShow) {
                    wrapper.style.display = '';
                    setRequiredState(wrapper, true);
                } else {
                    wrapper.style.display = 'none';
                    setRequiredState(wrapper, false);
                }

                updateSectionVisibility(wrapper);
            }

            // Register each trigger key and associate this wrapper's evaluate fn.
            condData.conditions.forEach(function (cond) {
                if (!allTriggerKeys[cond.when_field]) {
                    allTriggerKeys[cond.when_field] = [];
                }
                allTriggerKeys[cond.when_field].push(evaluate);
            });

            // Run immediately to set initial state.
            evaluate();
        });

        // Attach listeners to all trigger fields (once per field key).
        Object.keys(allTriggerKeys).forEach(function (key) {
            var triggers = document.querySelectorAll(
                '[name="' + CSS.escape(key) + '"],' +
                '[name="' + CSS.escape(key) + '[]"]'
            );
            triggers.forEach(function (trigger) {
                trigger.addEventListener('change', function () {
                    allTriggerKeys[key].forEach(function (fn) { fn(); });
                });
                trigger.addEventListener('input', function () {
                    allTriggerKeys[key].forEach(function (fn) { fn(); });
                });
            });
        });
    });

    // -----------------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------------

    /**
     * Get the current value for a field, handling text, select, radio, checkbox.
     */
    function getCurrentValue(triggers) {
        var first = triggers[0];

        if (first.type === 'checkbox') {
            return first.checked ? '1' : '';
        }

        if (first.type === 'radio') {
            var checked = null;
            triggers.forEach(function (t) {
                if (t.checked) checked = t;
            });
            return checked ? checked.value : '';
        }

        return first.value;
    }

    // -----------------------------------------------------------------------
    // Enhanced multi-select (selectWoo / Select2)
    // -----------------------------------------------------------------------

    function initMultiSelects() {
        if (typeof $ === 'undefined' || typeof $.fn.selectWoo !== 'function') {
            return;
        }
        $('select.wcwp-select[multiple]').each(function () {
            if (!$(this).hasClass('select2-hidden-accessible')) {
                $(this).selectWoo({ width: '100%' });
            }
        });
    }

    /**
     * Hide a section if all its field wrappers are hidden; show it otherwise.
     */
    function updateSectionVisibility(wrapper) {
        var section = wrapper.closest('.wcwp-form-section');
        if (!section) {
            return;
        }
        var fields = section.querySelectorAll('.wcwp-field-wrap, .wcwp-field-type-paragraph, .wcwp-field-type-display-text');
        var allHidden = Array.prototype.every.call(fields, function (f) {
            return f.style.display === 'none';
        });
        section.style.display = allHidden ? 'none' : '';
    }

    /**
     * Toggle the required attribute on inputs inside a wrapper.
     * Stores original required state in data-wcwp-required.
     */
    function setRequiredState(wrapper, required) {
        var inputs = wrapper.querySelectorAll('input, select, textarea');
        inputs.forEach(function (input) {
            if (required) {
                // Restore original required state if we stored it.
                if (input.dataset.wcwpRequired === '1') {
                    input.required = true;
                }
            } else {
                // Save current required state before removing it.
                if (input.required) {
                    input.dataset.wcwpRequired = '1';
                }
                input.required = false;
            }
        });
    }

}(window.jQuery));
