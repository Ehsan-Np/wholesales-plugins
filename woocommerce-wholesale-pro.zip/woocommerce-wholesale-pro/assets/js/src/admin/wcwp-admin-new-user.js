jQuery( function( $ ) {
	/**
	 * Admin New User JS
	 */
	const wcwpAdminNewUser = function() {
		$( document.body ).ready( this.handleWholesaleUserListReferred );
		$( document.body ).ready( this.handleWholesaleRole );
    };

    /**
	 * Init Wholesale Role Dropdown Handler
	 */
	wcwpAdminNewUser.prototype.handleWholesaleRole = function( event ) {
		const wholesaleRoles = wcwp_admin_object.wholesale_roles;
		const setRole = wcwp_admin_object.wholesale_add_new;
		const customLabel = '<td class="wcwp-password-notice" style="display: none;">' + wcwp_admin_object.password_notice + '</td>';

		const $roleSelect =  $( '#role' );
		const $sendEmailCheckbox = $( '#send_user_notification' );
		const $passwordInput = $( '#pass1' );
		const $passwordRow = $( '.user-pass1-wrap' );
		const $passwordCell = $( '.user-pass1-wrap > td' );

		// on page load handle pre-selection
		if ( setRole !== 'no' ) {
			let visibleRoles = [];
			$roleSelect.find('option').each( (index, option) => {
				const isVisible = $( option ).val().indexOf('wcwp_') === 0 && $( option ).val() !== 'wcwp_pending';
				$( option ).toggle( isVisible );

				if ( isVisible ) {
					visibleRoles.push( $( option ).val() );
				}
			})

			$roleSelect.val( setRole );
			$roleSelect.toggleClass( 'disabled', visibleRoles.length === 1 );
			$roleSelect.style( 'pointer-events', visibleRoles.length === 1 ? 'none' : 'auto' );
		}

		// add our hidden password notice
		$passwordRow.append( customLabel );

		// on page load check if we need to hide password
		if ( $sendEmailCheckbox.is( ':checked' ) && wholesaleRoles.indexOf( $roleSelect.val() ) > - 1 ) {
			$passwordCell.hide();
			$passwordRow.find( '.wcwp-password-notice' ).show();
		}


		$sendEmailCheckbox.on( 'change', function( event ) {
			if ( $( this ).is( ':checked' ) && ( wholesaleRoles.indexOf( $roleSelect.val() ) > - 1 ) ) {
				$passwordCell.hide();
				$passwordInput.val( $passwordInput.data( 'pw' ) );
				window.generatePassword();
				$passwordRow.find( '.wcwp-password-notice' ).show();
			} else {
				$passwordCell.show();
				$passwordRow.find( '.wcwp-password-notice' ).hide();
			}
		} );

        $roleSelect.on( 'change', function( event ) {
			const selectedRole = event.target.value;

			if ( wholesaleRoles.indexOf( selectedRole ) > -1 && $sendEmailCheckbox.is( ':checked' ) ) {
				$passwordCell.hide();
				$passwordInput.val( $passwordInput.data( 'pw' ) );
				window.generatePassword();
				$passwordRow.find( '.wcwp-password-notice' ).show();
			} else {
				$passwordCell.show();
				$passwordRow.find( '.wcwp-password-notice' ).hide();
			}
        } );
	};

	wcwpAdminNewUser.prototype.handleWholesaleUserListReferred = function( event ) {
		const { referrer } = document;

		if ( referrer.includes('users.php?role=') ) {
			const url = new URL( referrer );
			const params = new URLSearchParams( url.search );
			const role = params.get('role');
			const $roleSelect =  $( '#role' );

			$roleSelect.val( role );
		}
	};

	/**
	 * Init wcwpAdminNewUser.
	 */
	new wcwpAdminNewUser();
} );