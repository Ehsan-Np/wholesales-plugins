import { __ } from '@wordpress/i18n';

( function ( $, wp, woocommerce_admin, undefined ) {
	$( function () {
		/**
		 * Product Visibility
		 */

		// - Edit
		$( '#wholesale-visibility' )
			.find( '.edit-wholesale-visibility' )
			.on( 'click', function () {
				if ( $( '#wholesale-visibility-container' ).is( ':hidden' ) ) {
					$( '#wholesale-visibility-container' ).slideDown( 'fast' );
					$( this ).hide();
				}
				return false;
			} );

		// - Save
		$( '#wholesale-visibility' )
			.find( '.save-wholesale-visibility' )
			.on( 'click', function () {
				$( '#wholesale-visibility-container' ).slideUp( 'fast' );
				$( '#wholesale-visibility' ).find( '.edit-wholesale-visibility' ).show();

				const label = $( '#wholesale-visibility-container' ).find( 'option:selected' ).text();

				$( '#wholesale-visibility-display' ).text( label );
				$( '#current-wholesale-visibility' ).val(
					$( '#wholesale-visibility-container' ).find( 'option:selected' ).val()
				);

				return false;
			} );

		// - Cancel
		$( '#wholesale-visibility' )
			.find( '.cancel-wholesale-visibility' )
			.on( 'click', function () {
				$( '#wholesale-visibility-container' ).slideUp( 'fast' );
				$( '#wholesale-visibility' ).find( '.edit-wholesale-visibility' ).show();

				const visibility = $( '#current-wholesale-visibility' ).val() ?? '';

				const label = $( '#wholesale-visibility-container' )
					.find( 'option[value="' + visibility + '"]' )
					.text();

				$( '#wholesale-visibility-select' ).val( visibility );
				$( '#wholesale-visibility-display' ).text( label );

				return false;
			} );

		/**
		 * Sale Price
		 */

		const sale_price_error = __(
			'Please enter in a value less than the corresponding wholesale price',
			'woocommerce-wholesale-pro'
		);

		$( document.body )
			.on( 'keyup', '.wcwp_wholesale_sale_field .wc_input_price[type=text]', function ( event ) {
				const wholesale_sale_price_field = $( event.target );

				if ( false === validateSalePrice( event.target ) ) {
					add_error_tip( wholesale_sale_price_field, sale_price_error );
				} else {
					remove_error_tip( wholesale_sale_price_field );
				}
			} )

			.on( 'blur', '.wcwp_wholesale_field .wc_input_price[type=text]', function ( event ) {
				const wholesale_sale_price_field = $( event.target )
					.closest( 'p' )
					.next()
					.find( '.wc_input_price[type=text]' );

				if ( false === validateSalePrice( event.target ) ) {
					add_error_tip( wholesale_sale_price_field, sale_price_error );
				} else {
					remove_error_tip( wholesale_sale_price_field );
				}
			} )

			.on( 'blur', '.wcwp_wholesale_sale_field .wc_input_price[type=text]', function ( event ) {
				if ( false === validateSalePrice( event.target ) ) {
					$( event.target ).val( '' );
				}
			} );

		const validateSalePrice = ( target ) => {
			let wholesale_sale_price_field, wholesale_price_field;

			if ( target.matches( '.wcwp_wholesale_sale_field .wc_input_price[type=text]' ) ) {
				wholesale_sale_price_field = $( target );
				wholesale_price_field = wholesale_sale_price_field
					.closest( 'p' )
					.prev()
					.find( '.wc_input_price[type=text]' );
			} else if ( target.matches( '.wcwp_wholesale_field .wc_input_price[type=text]' ) ) {
				( wholesale_price_field = $( target ) ),
					( wholesale_sale_price_field = wholesale_price_field
						.closest( 'p' )
						.next()
						.find( '.wc_input_price[type=text]' ) );
			}

			if ( ! wholesale_sale_price_field ) {
				return;
			}

			var wholesale_sale_price = parseFloat(
				window.accounting.unformat( wholesale_sale_price_field.val(), woocommerce_admin.mon_decimal_point )
			);
			var wholesale_price = parseFloat(
				window.accounting.unformat( wholesale_price_field.val(), woocommerce_admin.mon_decimal_point )
			);

			return (
				Number.parseFloat( wholesale_price_field.val() ) &&
				Number.parseFloat( wholesale_sale_price_field.val() ) &&
				wholesale_sale_price < wholesale_price
			);
		};

		const add_error_tip = ( $el, error ) => {
			const offset = $el.position();

			$el.after( '<div class="wc_error_tip">' + error + '</div>' );
			$el.parent()
				.find( '.wc_error_tip' )
				.css( 'left', offset.left + $el.width() - $el.width() / 2 - $( '.wc_error_tip' ).width() / 2 )
				.css( 'top', offset.top + $el.height() )
				.fadeIn( '100' );
		};

		const remove_error_tip = ( $el ) => {
			$el.parent()
				.find( '.wc_error_tip' )
				.fadeOut( '100', function () {
					$( this ).remove();
				} );
		};
	} );
} )( jQuery, wp, woocommerce_admin );
