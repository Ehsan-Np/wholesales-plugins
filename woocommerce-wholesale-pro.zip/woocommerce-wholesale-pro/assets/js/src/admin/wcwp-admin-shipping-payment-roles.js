jQuery( function( $ ) {
	/**
	 * Admin Shipping & Payment Roles JS
	 */
	var wcwpAdminShippingPaymentRoles = function() {
        $( document.body ).ready( this.handleSelectWoo );
    };

    /**
	 * Init selectWoo
	 */
	wcwpAdminShippingPaymentRoles.prototype.handleSelectWoo = function( event ) {
        $( '.wcwp-role-multiselect' ).selectWoo({ width: '95%' });
    };

	/**
	 * Init wcwpAdminShippingPaymentRoles.
	 */
	new wcwpAdminShippingPaymentRoles();
} );