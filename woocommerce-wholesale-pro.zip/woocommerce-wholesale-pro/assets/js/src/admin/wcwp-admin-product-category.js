jQuery( function ( $ ) {
	/**
	 * Admin Product Category JS
	 */
	var wcwpAdminProductCategory = function () {
		$( document.body ).ready( this.handleVisiblityControl );
	};

	/**
	 * Init Protected Categories Integration Handler
	 */
	wcwpAdminProductCategory.prototype.handleVisiblityControl = function ( event ) {
		var $wholesaleProFields = $( '#wcwp_product_cat_visibility' );
		var $protectedCategoriesFields = $( '#product_cat_visibility' );
		var $visiblityControlInput = $( 'input[name="wcwp_cat_visibility_control"]' );
		var startingSelection = $( 'input[name="wcwp_cat_visibility_control"]:checked' ).val();

		// on load
		if ( startingSelection === 'protected_categories' ) {
			$wholesaleProFields.addClass( 'wcwp-field-lock' );
		} else if ( startingSelection === 'wholesale_pro' ) {
			$protectedCategoriesFields.addClass( 'wcwp-field-lock' );
		}

		// on change
		$visiblityControlInput.on( 'change', function ( event ) {
			var selection = event.target.value;

			if ( selection === 'protected_categories' ) {
				$wholesaleProFields.addClass( 'wcwp-field-lock' );
				$protectedCategoriesFields.removeClass( 'wcwp-field-lock' );
				$( '#wcwp_public_wholesale_visibility' ).prop( 'checked', true );
			} else if ( selection === 'wholesale_pro' ) {
				$protectedCategoriesFields.addClass( 'wcwp-field-lock' );
				$wholesaleProFields.removeClass( 'wcwp-field-lock' );
				$( '#public_visibility' ).prop( 'checked', true );
			}
		} );
	};

	/**
	 * Init wcwpAdminProductCategory.
	 */
	new wcwpAdminProductCategory();
} );
