jQuery( function( $ ) {
	/**
	 * Admin Edit User JS
	 */
	var wcwpAdminEditUser = function() {
        $( document.body ).ready( this.handleRoleSelect );
        $( document.body ).on( 'click', '.wcwp-continue', this.handleNoticeContinue );
        $( document.body ).on( 'click', '.wcwp-cancel', this.handleNoticeCancel );
        $( document.body).on( 'mouseenter', '#submit', this.handleSubmitButton );
    };

    var wcwpAdminEditUserFunctions = {};

    /**
	 * Object variables
	 */
    wcwpAdminEditUser.roleNoticeVisiblity = false;

    /**
	 * Init Wholesale Role Dropdown Handler
	 */
	wcwpAdminEditUser.prototype.handleRoleSelect = function( event ) {
        var $roleSelect = $( '#role' );
        var $roleTD = $( '.user-role-wrap > td' );
        var $roleNotice = $( '<p class="wcwp-role-notice" style="display: none;">' + wcwp_admin_object.role_notice + '</p>' );

        // add our hidden notice
        $roleTD.append( $roleNotice );

        wcwpAdminEditUserFunctions.maybeShowNotice( $roleSelect.val() );

        // handle the role select
        $roleSelect.on( 'change', function( event ) {
            var selectedRole = event.target.value;

            wcwpAdminEditUserFunctions.maybeShowNotice( selectedRole );
        } );
    };

    wcwpAdminEditUserFunctions.maybeShowNotice = function( selectedRole ) {
        var wholesaleRoles = wcwp_admin_object.wholesale_roles;
        var $approvalSection = $( '#wcwp-approval-section' );
        var $updateButton = $( '#submit' );
        var $roleNotice = $( '.wcwp-role-notice' );

        if ( wholesaleRoles.indexOf( selectedRole ) > -1 ) {
            $approvalSection.show();
            $updateButton.prop( 'disabled', false );
            $roleNotice.hide();
        } else {
            $approvalSection.hide();
            $updateButton.prop( 'disabled', true );
            $roleNotice.show();
        }
    };

    /**
	 * Handle Notice Continue
	 */
	wcwpAdminEditUser.prototype.handleNoticeContinue = function( event ) {
        $( '.wcwp-role-notice' ).hide();
        $( '#submit' ).prop( 'disabled', false );
    };

    /**
	 * Handle Notice Cancel
	 */
	wcwpAdminEditUser.prototype.handleNoticeCancel = function( event ) {
        $( '#role' ).val( 'wcwp_pending' ).trigger( 'change' );
    };

    /**
	 * Handle Submit Button
	 */
	wcwpAdminEditUser.prototype.handleSubmitButton = function( event ) {
        if ( $( this ).prop( 'disabled' ) ) {
            $( 'body, html' ).animate( { scrollTop: $( '#role' ).offset().top - 50 }, 'slow' );
        }
	};


	/**
	 * Init wcwpAdminEditUser.
	 */
	new wcwpAdminEditUser();
} );