jQuery( function( $ ) {
	/**
	 * Registration Fields Settings JS
	 */
	var wcwpRegistrationFields = function() {
		$( document.body ).ready( this.handleSorting );
		$( document.body ).ready( this.handleChangesWarning );
    };

    /**
	 * Handle Sorting
	 */
	wcwpRegistrationFields.prototype.handleSorting = function( event ) {
        $( 'tbody.wcwp-registration-field-rows' ).sortable( {
			items: 'tr',
			cursor: 'move',
			axis: 'y',
			handle: 'td.wcwp-registration-field-sort',
            scrollSensitivity: 40,
		} );
	};

	/**
	 * Handle Error
	 */
	wcwpRegistrationFields.prototype.handleChangesWarning = function( event ) {
        $( 'input.saved' ).on( 'input', function( event ) {
			$( this ).siblings( '.wcwp-fields-error' ).css( 'visibility', 'inherit' );
		} );
	};

	/**
	 * Init wcwpRegistrationFields.
	 */
	new wcwpRegistrationFields();
} );