( function ( $ ) {
	$( function () {
		// Quick edit: move wholesale visibility field to appear right after the native visibility group.
		const $nativeVisibilityGroup = $( '#woocommerce-fields select.visibility' ).closest( '.inline-edit-group' );
		const $wholesaleQuickField = $( '#woocommerce-fields .wcwp-wholesale-visibility-field' );

		if ( $nativeVisibilityGroup.length && $wholesaleQuickField.length ) {
			$nativeVisibilityGroup.after( $wholesaleQuickField );
		}

		// Bulk edit: move wholesale visibility field to appear right after the native visibility label.
		const $nativeBulkVisibilityLabel = $( '#woocommerce-fields-bulk select.visibility' ).closest( 'label' );
		const $wholesaleBulkField = $( '#woocommerce-fields-bulk .wcwp-wholesale-visibility-field' );

		if ( $nativeBulkVisibilityLabel.length && $wholesaleBulkField.length ) {
			$nativeBulkVisibilityLabel.after( $wholesaleBulkField );
		}

		// Quick edit: populate the wholesale visibility select when the form opens.
		$( '#the-list' ).on( 'click', '.editinline', function () {
			const postId = $( this ).closest( 'tr' ).attr( 'id' ).replace( 'post-', '' );
			const wholesaleVisibility = $( '#post-' + postId )
				.find( '.wcwp-wholesale-visibility-data' )
				.text()
				.trim();

			$( 'select[name="_wwp_wholesale_visibility"]', '.inline-edit-row' )
				.val( wholesaleVisibility );
		} );
	} );
} )( jQuery );
