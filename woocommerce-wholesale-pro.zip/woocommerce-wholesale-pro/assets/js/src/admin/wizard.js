import { __ } from '@wordpress/i18n';
import { addFilter } from '@wordpress/hooks';
import { Button } from '@wordpress/components';

/**
 * Customize the footer buttons.
 */
addFilter('barn2_setup_wizard_after_navigation', 'wwp-wizard', (original, goToNextStep, goToPreviousStep, activeStep, steps ) => {
	const upsellStep = steps.find( step => step.key === 'more' )

	if (activeStep === 'layout' && upsellStep) {
		return <Button
				variant={ 'primary' }
				onClick={() => {
					sessionStorage.setItem( 'wwp-wizard-upsell', true );
					goToNextStep()
				}}
			>
				{__('Add Product Table')}
			</Button>
	}

	return original;

});