jQuery( function( $ ) {
	/**
	 * WC Role Sorting JS
	 */
	var wcwpRoleSorting = function() {
		$( document.body ).ready( this.handleSorting );
    };

    /**
	 * Handle Sorting
	 */
	wcwpRoleSorting.prototype.handleSorting = function( event ) {
        $( 'tbody.wcwp-wholesale-rows-custom' ).sortable( {
			items: 'tr',
			cursor: 'move',
			axis: 'y',
			handle: 'td.wcwp-wholesale-role-sort',
            scrollSensitivity: 40,
            update: function() {
                var $this = $( this );
                var ordered_roles = $this.sortable( 'toArray' );

                $.post(
                    wcwp_role_sorting_object.ajax_url,
                    {
                        action: 'wcwp_role_sorting',
                        security: wcwp_role_sorting_object.security,
                        ordered_roles: ordered_roles
                    },
                    function ( response ) {
                        if ( ! response.success ) {
                            $this.sortable( 'cancel' );
                        }
                    }
                );
            }
		} );
	};

	/**
	 * Init wcwpRoleSorting.
	 */
	new wcwpRoleSorting();
} );